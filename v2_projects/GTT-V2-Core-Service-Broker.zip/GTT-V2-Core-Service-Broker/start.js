'use strict'; 

const Broker = require('@sap/sbf'); 
const request = require('request').defaults({
  'https_proxy': 'http://proxy.wdf.sap.corp:8080'
});

const CREATE_SERVICE_MILLIS = 20 * 1000;
const OPERATION = {
	provision: 'provision',
	deprovision: 'deprovision',
	update: 'update'
};
let provisionData = {};  // instance procesing done: true or false;
let responseCode = {};  // manager response code;
let responseMsg = {};   // manager response body;

function getToken() {
	let credentials = JSON.parse(process.env.VCAP_SERVICES).xsuaa[0].credentials;
	let clientId = credentials.clientid;
	let clientSecret = credentials.clientsecret;

	var promise = new Promise(function(resolve, reject) {
		request({
			method: "GET",
			uri: credentials.url + "/oauth/token?grant_type=client_credentials"
		}, (err, res, bd) => {
			if (err) {
				reject(err);
				return;
			}

			resolve(JSON.parse(res.body).access_token);
		}).auth(clientId, clientSecret, false);
	});

	return promise;	
}

function postCode(obj){
	var promise = new Promise(function(resolve, reject) {
		const LISTENER_URL = process.env.SERVICE_MANAGER_URL;

		getToken().then(function(token) {

			let reqObj = {
				method: obj.method,
				uri:  LISTENER_URL + obj.url,
				json: true,
				auth: {
					'bearer': token
				}
			};
			if (obj.reqBody) {
				reqObj.body = obj.reqBody;
			}
			request(reqObj, (err, res, bd) => {
				let instanceid = obj.instanceId;
				provisionData[instanceid] = true;
				responseCode[instanceid] = res.statusCode;
				responseMsg[instanceid] = res.body;
	
				if(err) {
                                        console.log("failed:");
					console.log(err);
					reject(err);
				} else{
                                        console.log("sucessed:");
					console.log(bd);
                                        if (bd) {
                                            //let result = JSON.parse(bd);
                                            reject(bd);
                                        } else {
                                            resolve();
                                        }
				}
			});
		}, function(err) {
			console.log(err);
			reject(err);
		});
	});
	return promise;
}

function sendRequest(reqParams, callback) {
	postCode(reqParams).then(function() {
		if (callback && typeof callback === 'function') {
			callback();
		}
	}, function(err) {
		console.log("err", err);
                if (callback && typeof callback === 'function') {
                    callback(responseError(err, 500));
                }
	});
}

function responseError(message, status) {
    var error = new Error();
    if (status) {
        error.status = status;
        error.message = JSON.stringify(message);
    }

    return error;
};

function handleError(instanceid) {
	provisionData[instanceid] = true;
	responseCode[instanceid] = 402;
	responseMsg[instanceid] = "bad parameters";
}

function handleHooks(params, reqParams, opera, callback) {
	let instanceid = params['instance_id'];
        let context = params.req.body.context || {};
	provisionData[instanceid] = false;
	responseCode[instanceid] = "";
	responseMsg[instanceid] = "";

	reqParams.instanceId = instanceid;
	
	if(opera === OPERATION.provision || opera === OPERATION.update) {
		let newPra = params['parameters'];  //{ "databaseServiceInstanceName":"lbn-gtt-core-storage-hana" }
		if (newPra) {
			newPra['cloneServiceInstanceId'] = instanceid;
                        if (context.platform === "sapcp") {
                            newPra['cloneServiceTenantId'] = context.subaccount_id;
                        }
			console.log('provision service instance %s', instanceid);

			//{
			// "databaseServiceInstanceName":"lbn-gtt-core-storage-hana",
			// "cloneServiceInstanceId":  instanceid
			//}
			reqParams.reqBody = newPra;
			console.log('=========================');
			console.log(JSON.stringify(reqParams.reqBody));
			sendRequest(reqParams, callback);
		} else {
			// provisionData[params['instance_id']] = true;
			// responseCode[instanceid] = 402;
			// responseMsg[instanceid] = "bad parameters";
			handleError(instanceid);
		}
	} else {
		reqParams.reqBody = {
			cloneServiceInstanceId: instanceid,
			cloneServiceTenantId: (context.platform === "sapcp" ? context.subaccount_id : ''),
			databaseServiceInstanceName: ''
		};
		sendRequest(reqParams, callback);
	}
}

 const broker = new Broker({
	autoCredentials: true,
	hooks: {
		onProvision: (params, callback) => {
			let instanceid = params['instance_id'];
			// // provisionData[instanceid] = false;
			// // responseCode[instanceid] = "";
			// // responseMsg[instanceid] = "";
			// initData(instanceid);

			// console.log('provision service instance %s', params.instance_id);
			// 	//console.log('params: ', params);
				

			// 	console.log('send parameters to %s', LISTENER_URL);
			// 	console.log('parameters:', params['parameters']);
			// 	let newPra = params['parameters'];
			// 	if (newPra) {
			// 		newPra['cloneServiceInstanceId'] = instanceid;
			// 		postCode({
			// 			method: 'POST',
			// 			instanceId: instanceid,
			// 			url: '/broker/onProvision',
			// 			reqBody: newPra
			// 		}).then(function() {
			// 			callback(null, {
			// 				async: true,
			// 				dashboard_url: `https://lbn-gtt-sandbox-gtt-v2-service-broker-dashboard-approuter.cfapps.sap.hana.ondemand.com/comsapgttdashboardapp-1.0.0/index.html#/instance/${instanceid}/modelList` 
			// 			});
			// 		}, function(err) {
			// 			console.log("err", err);
			// 		});
			// 	} else {
			// 		// provisionData[params['instance_id']] = true;
			// 		// responseCode[instanceid] = 402;
			// 		// responseMsg[instanceid] = "bad parameters";
			// 		handleError(instanceid);
			// 	}

			handleHooks(params, {
				method: 'POST',
				url: '/sap/logistics/gtt/service-manager/v1/broker/onProvision'
			}, OPERATION.provision, function(err) {
				callback(err, {
					async: true,
					dashboard_url: `https://lbn-gtt-sandbox-gtt-v2-service-broker-dashboard-approuter.cfapps.sap.hana.ondemand.com/comsapgttdashboardapp-1.0.0/index.html#/instance/${instanceid}/modelList` 
				});
			});

			// node js send a post request:

			// Delay the response with async function to simulate resource creation (like database schemas etc.)
		//       setTimeout(() => {
		//        provisionData[params['instance_id']] = true;
		//        responseCode[instanceid] = 504;
		//        responseMsg[instanceid] = "time out";
		//       }, CREATE_SERVICE_MILLIS);


			// Because of { async: true } provision operation will be asynchronous

		},

		onDeprovision: (params, callback) => {
			console.log('deprovision service instance %s', params.instance_id);
			//console.log('params: ', params);
			// Free any resources created during provision of the service instance
			handleHooks(params, {
				method: 'POST',
				url: '/sap/logistics/gtt/service-manager/v1/broker/onDeprovision'
			}, OPERATION.deprovision, function(err) {
				callback(err, {});
			});
		},

		onBind: (params, callback) => {
			console.log('Bind service instance %s', params.instance_id);
			//console.log('params: ', params);
			// custom bind actions
			callback(null, {});
		},

		onUnbind: (params, callback) => {
			console.log('Unbind service instance %s', params.instance_id);
			//console.log('params: ', params);
			// custom unbind actions
			callback(null, {});
		},

		onUpdate: (params, callback) => {
			console.log('update service %s ', params.service_id, params.plan_id);
			//console.log('params: ', params);
			// custom update actions
			handleHooks(params, {
				method: 'POST',
				url: '/sap/logistics/gtt/service-manager/v1/broker/onUpdate'
			}, OPERATION.update, function() {
				callback(null, {});
			});
		},

		onLastOperation: (params, callback) => {
			let state = 'in progress';
			let instanceId = params['instance_id'];
			if (provisionData[instanceId]) {
				if (responseCode[instanceId] < 300) {
					state = 'succeeded';
				} else {
					state = 'failed';
				}
			} 
			callback(null, { state }); 
		}
	}
 }); 
 broker.start(); 
