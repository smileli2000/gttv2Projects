const expect = require('chai').expect;
describe('TEST', function() {
  it('TEST', function() {
    expect(1+1).to.be.equal(2);
  });
});