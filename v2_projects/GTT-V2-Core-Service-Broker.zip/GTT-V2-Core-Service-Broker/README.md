# GTT Core Service
In our case, a stable broker should be deployed in acceptance space for consumers to connected.  this document shows
how do we to deploy it.
## catalog.json:
1.  id is set as lbn-gtt-core-sbf-release.

2. give some meaning descriptions


## package.json,

in most cases, just use this file.

## start.js

it's the main function of this project. there are some hooks added to extend service broker standard behavior, for example, onProvision function is an asynchronously hook example.

## manifest.yml
this file is used to deploy this app.
application name: gtt-core-sbf-release
* SBF_BROKER_CREDENTIALS_HASH, just use **gtt_v2_sandbox** and do NOT　change it. it will be used the create service instance.
* SBF_CATALOG_SUFFIX, use LBN, it is postfix of master service instance name. this value could be changed when add a new path to create service instance.
* SBR_BROKER_CUST_ENV: yourenvhere, it is example of how to set env for this broker application, in the start.js, the value could be get
* const yourenv = process.env.SBR_BROKER_CUST_ENV;
* SBF_SERVICE_CONFIG, the values will be shared to each clone instance
* SERVICE_MANAGER_URL, the service broker manage URL
* services information is the list of bound service instance list.
    - audit-logs
    - lbn-gtt-core-uaa

    the services instances MUST be created before deployment.
## xs-security.json

currently, only xsappname is mandatory

## other information
service broker name: gtt-service-broker-test

## how to deploy it manually

### compile this app

```
cd broker

npm install

cd ..
```
### create services which are used by this application.

```
cf create-service xsuaa broker gtt-test-sbf-uaa -c xs-security.json

cf create-service auditlog standard gtt-test-sbf-audit
```
### deploy service broker
cf push -f manifest.yml

### create service broker, the link is https://{{brokerapp-name}}.cfapps.sap.hana.ondemand.com
```
cf create-service-broker gtt-service-broker-release gtt_v2_sandbox gtt_v2_sandbox  https://gtt-core-sbf-release.cfapps.sap.hana.ondemand.com
Or
cf create-service-broker gtt-service-broker-test gtt_v2_sandbox gtt_v2_sandbox-your-suffix  https://gtt-core-sbf-release.cfapps.sap.hana.ondemand.com/your-suffix --space-scoped
```
### check the service in market place.
```
cf m1
```
