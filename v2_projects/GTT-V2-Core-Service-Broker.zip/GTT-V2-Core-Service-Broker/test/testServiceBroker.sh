#!/usr/bin/env bash
set -x

echo
echo "**** cloudfoundry login Section"
echo "**** =========================="
echo


echo "**** INSTALL # Login to cloudfoundry"
mkdir -p /tmp/${JOB_BASE_NAME//\ /-}
export CF_HOME="/tmp/${JOB_BASE_NAME//\ /-}"
export CF_PLUGIN_HOME=~
# Use dynamic space from template for pull request pipelines
[ -z "${SPACE_NAME_GENERATED}" ] && SPACE="${Space}" || SPACE="${SPACE_NAME_GENERATED}"

echo "**** DEBUG # login to cloudfoundry: ${cloudfoundry_api}, organization: ${Organization}, space: ${SPACE} with user: ${cf_user_var}"
cf login -a "api.cf.sap.hana.ondemand.com" -u track_trace@163.com -p ${CF_PASS_XXT} -o "lbn-gtt" -s "integration" --skip-ssl-validation

echo "create service broker for test only"
cf create-service-broker gtt-core-service-broker-testonly lbn-gtt-core lbn-gtt-core https://gtt-core-service-broker-integration.cfapps.sap.hana.ondemand.com/testonly--space-scoped
retrval=$?
if  [[ $retval -ne 0 ]]; then
    echo "create the service broker failed."
	exit -1
fi
#create the service broker with the right paramter.

cf create-service  lbn-gtt-core-sbf-testonly  shared  lbn-gtt-core-testonly -c rightpara.json
retrval=$?
if  [[ $retval -ne 0 ]]; then
    echo "create the service failed."
	cf purge-service-instance lbn-gtt-core-testonly -f
	exit -1
fi

# check the instance status 10 seconds later, if succeed, continue, else exit.
 cf service lbn-gtt-core-testonly | grep Status | awk -F: '{print $2}' | tee >(sleep 10; [[ `tail -n1` =~ 'create succeeded' ]] && echo OK || exit -2)
 
# try to deleted it  

cf ds lbn-gtt-core-testonly -f
retrval=$?
if  [[ $retval -ne 0 ]]; then
    echo "deleted the service failed."
	cf purge-service-instance lbn-gtt-core-testonly -f
	exit -1
fi

echo "remove the service broker"
cf delete-service-broker gtt-core-service-broker-testonly -f