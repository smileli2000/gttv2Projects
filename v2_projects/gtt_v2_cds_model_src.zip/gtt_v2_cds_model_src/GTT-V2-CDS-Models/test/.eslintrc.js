module.exports = {
  "root": false,
  "extends": [
    // "../.eslintrc.js"
  ],
  "env": {
    "node": true,
    "mocha": true,
  },
  "globals": {
  },
  "rules": {
    "dot-notation": ["error", {"allowKeywords": true}],
  }
};
