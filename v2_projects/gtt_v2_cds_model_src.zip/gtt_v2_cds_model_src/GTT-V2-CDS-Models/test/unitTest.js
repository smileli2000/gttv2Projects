const path = require('path');
const fs = require('fs-extra');
const chai = require('chai');
const httpMocks = require('node-mocks-http');

const build = require('../bin/build');
const expect = chai.expect;

const cwd = path.join (__dirname, '..');

const cdsSourcePath = 'src/delivery';
const modelFullName = 'com.sap.gtt.app.deliverysample.DeliveryService';

const paths = {
  src: cdsSourcePath,
  output: 'target/output',
  files: {
    csn: path.join(cwd, `out/${modelFullName}_csn.json`),
    metadata: path.join(cwd, `out/${modelFullName}_metadata.xml`),
    annotations: path.join(cwd, `out/${modelFullName}_annotations.xml`),
  }
};

const compile = (req, res) => {
  return build.compile(req.body).then(results => {
    res.setHeader('Content-Type', 'application/json');
    res.statusCode = 200;
    res.send(results, 'utf8');
    res.end();

    return res;
  });
};

const testPost = (body) => {
  const request = httpMocks.createRequest({
    method: 'POST',
    url: '/compile',
    body: body
  });

  const response = httpMocks.createResponse();

  return compile(request, response).then(res => res._getData());
};


// generate hashes
const hashPromise = Promise.all(Object.keys(paths.files).map((key) => {
  const filepath = paths.files[key];
  return build.hashFile(filepath).then(hash => [key, hash]);
}));

describe('CDS Compiler Unit Test', () => {

  before((done) => {
    fs.ensureDir(path.join(cwd, paths.output), done);
  });

  it('Test compile', () => {
    // Act
    const compilePromise = build.load(paths.src).then(testPost);

    // Assert
    return Promise.all([compilePromise, hashPromise]).then(([results, hashes]) => {
      // save results
      build.store(results, paths.output, paths.output);

      // compare results
      const hashMap = new Map(hashes);
      ['csn', 'metadata', 'annotations'].forEach((key) => {
        let value = results[key];
        if (typeof value === 'object') {
           value = JSON.stringify(value, null, '\t')
        }
        const hash = build.hashString(value);
        expect(hash).to.be.equal(hashMap.get(key), `${key} file content should not be changed`);
      });
    });
  });
});
