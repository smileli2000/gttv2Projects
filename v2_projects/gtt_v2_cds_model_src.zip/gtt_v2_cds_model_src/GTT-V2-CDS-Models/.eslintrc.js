module.exports = {
  "root": true,
  "extends": [
    "eslint:recommended"
  ],
  "parserOptions": {
    "ecmaVersion": 6,
    "sourceType": "module",
  },
  "env": {
    "node": true,
    "es6": true,
  },
  "plugins": [
  ],
  "globals": {
  },
  "rules": {
    "max-len": ["warn", {"code": 100, "tabWidth": 2}],
    "no-console": "off",
  }
};
