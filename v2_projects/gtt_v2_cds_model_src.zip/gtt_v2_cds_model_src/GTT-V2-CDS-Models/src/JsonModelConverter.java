package com.sap.gtt.v2.metadataservice.utils;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.sap.gtt.v2.metadataservice.domain.*;
import com.sap.gtt.v2.metadataservice.exception.CdsInfoGeneratorException;
import com.sap.gtt.v2.util.JsonUtils;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;

import javax.swing.text.html.parser.Entity;
import java.lang.reflect.InvocationTargetException;
import java.util.*;
import java.util.stream.Collectors;

import static com.sap.gtt.v2.metadataservice.exception.CdsInfoGeneratorException.MESSAGE_CODE_ERROR_JSON_MODEL_CONVERT_FAILED;


public class JsonModelConverter {
    public static final String NAMESPACE = "namespace";
    public static final String DOT = ".";
    public static final String KEY = "key";
    public static final String COMMA = ",";
    private static final String NAME = "name";
    protected static final String CUSTOMMODEL = "customModel";
    private static final String SUBMODELS = "subModels";
    private static final String RESIDENCEPERIOD = "residencePeriod";
    private static final String BLOCKINGPERIOD = "blockingPeriod";
    private static final String CORE_RESIDENCE_PERIOD_UNIT_ANNOTAITON = "@CoreModel.ResidencePeriod.Unit:";
    private static final String CORE_RESIDENCE_PERIOD_VALUE_ANNOTAITON = "@CoreModel.ResidencePeriod.Value:";
    private static final String CORE_BLOCKING_PERIOD_UNIT_ANNOTAITON = "@CoreModel.blockingPeriod.Unit:";
    private static final String CORE_BLOCKING_PERIOD_VALUE_ANNOTAITON = "@CoreModel.blockingPeriod.Value:";
    private static final String PROCESS_TYPES = "processTypes";
    private static final String ELEMENTS = "elements";
    private static final String TYPE = "type";
    private static final String REQUIRED = "required";
    private static final String READABLE = "readable";
    private static final String WRITABLE = "writable";
    private static final String LENGTH = "length";
    private static final String PRECISION = "precision";
    private static final String SCALE = "scale";
    private static final String TARGET = "target";
    private static final String CARDINALITY = "cardinality";
    private static final String MAX = "max";
    private static final String PARENT = "parent";
    private static final String PLANNEDEVENTS = "admissiblePlannedEvents";
    private static final String ADMISSIBLE_UNPLANNED_EVENTS = "admissibleUnplannedEvents";
    private static final String EVENTTYPE = "eventType";
    private static final String MATCHLOCATION = "matchLocation";
    private static final String BUSINESS_TOLERANCE_VALUE = "businessToleranceValue";
    private static final String TECHNICAL_TOLERANCE_VALUE = "technicalToleranceValue";
    private static final String PERIOD_OVERDUE_DETECTION = "periodicOverdueDetection";
    private static final String BUSINESS_TOLERANCE_UNIT = "businessToleranceUnit";
    private static final String TECHNICAL_TOLERANCE_UNIT = "technicalToleranceUnit";
    private static final String PERIOD_OVERDUE_DETECTION_UNIT = "periodicOverdueDetectionUnit";
    private static final String FORMAT_TOLERANCE_VALUE = "PT%s%s";
    private static final String MAX_OVERDUE_DETECTION = "maxOverdueDetection";
    private static final String ITEM_TYPES = "itemTypes";
    private static final String CODE_LISTS = "codeLists";
    private static final String CODE_LIST = "codelist";
    private static final String TRACKED_PROCESS_ANNOTATION = "@CoreModel.BaseType: #TrackedProcess";
    private static final String EVENT_TYPES = "eventTypes";
    private static final String EVENT_ANNOTATION = "@CoreModel.BaseType: #Event";
    private static final String IS_PROCESS_EVENT_ANNOTATION = "@CoreModel.IsProcessEvent: true";
    private static final String EVENT = "Event";
    public static final String COMPOSITION = "composition";
    public static final String ASSOCIATION = "association";
    private static final String CORE_MODEL_EVENT_FOR_WRITE = "CoreModel.EventForWrite";
    private static final String CORE_MODEL_GTT_DELAYED_EVENT_FOR_WRITE = "CoreModel.GTTDelayedEventForWrite";
    private static final String FORWRITE = "ForWrite";
    private static final String PLANNED_EVENTS_ANNOTATION = "@CoreModel.PlannedEvents: [%s]";
    private static final String UNPLANNED_EVENTS_ANNOTATION = "@CoreModel.AdmissibleUnplannedEvents: [%s]";
    private static final String CORE_MODEL_TRACKED_PROCESS = "CoreModel.TrackedProcess";
    private static final String DPP = "dpp";
    private static final String PII = "pii";
    private static final String SPI = "spi";
    private static final String DATA_SUBJECT_ID = "datasubjectid";
    private static final String DPP_PII_ANNOTATION = "@DPP.PII";
    private static final String DPP_SPI_ANNOTATION = "@DPP.SPI";
    private static final String DPP_DATA_SUBJECT_ID_ANNOTATION = "@DPP.DATASUBJECTID";
    static final String LABEL = "label";
    private static final String TRANSLATION = "translation";
    private static final String TEXT_TYPE = "textType";
    static final String OBJECT_TYPE_ELEMENT = "EL";
    private static final String UNDERSCORE = "_";
    static final String I18NELEMENTKEY = "%s_%s_%s_%s";
    private static final String BAR = "-";
    private static final String I18N = "i18n";
    static final String DEFAULT_I18N_FILE_NAME = "i18n.properties";
    private static final String PROPERTIES = "properties";
    static final String I18N_ANNOTATION = "@title:'{@i18n>%s}'";
    private static final String UUID = "UUID";
    private static final String CORE_MODEL_PROCESS_EVENT = "CoreModel.ProcessEvent";
    private static final String DELAYED_EVENT = "DelayedEvent";
    private static final String SCHEMA_VERSION = "schemaVersion";
    private static final String CORE_PROCESS_EVENT_FOR_WRITE = "CoreModel.ProcessEventForWrite";
    private static final String TRACKING_ID_TYPE = "trackingIdType";
    private static final String TRACKING_ID_TYPE_ANNOTATION = "@CoreModel.TrackingIdType: '%s'";
    private static final String DEFAULT = "default";
    private static final String CODE = "code";
    private static final String VALUES = "values";
    private static final String CODE_LIST_ANNOTATION_TEMPLATE = " @CoreModel.Enum.DefaultValue : '%s'";
    private static final String UNIT = "unit";
    private static final String VALUE = "value";
    private static final String CONTEXT = "context";
    private static final String ITEM_TYPE = "ITEM_TYPE";
    private static final String PROCESS_EVENT_TYPE = "PROCESS_EVENT_TYPE";
    private static final String ALIAS = "Alias";
    private static final String CORE_MODEL_WITH_NAME_SPACE = "com.sap.gtt.core.CoreModel";
    private static final String ALTKEY = "AltKey";
    private static final String STRING = "String";
    private static final int LENGTH_OF_ASSOCIATION_ADDED_ATTRIBUTE = 255;
    private static final String CORE_MODEL_NAVIGATION_PROPERTY = "@CoreModel.NavigationProperty.SourceAltKey : '%s'";
    private static final String PROCESS_TYPE = "PROCESS_TYPE";
    private static final String LOCALIZED = "localized";


    private JsonModelConverter() {
    }


    public static DraftModelBean convertJsonToModelBean(String jsonModel) {
        JsonObject tempModelBean = JsonUtils.generateJsonObjectFromJsonString(jsonModel);
        DraftModelBean draftModelBean = new DraftModelBean();
        Map<String, Map<String, String>> i18nFileInfoMap = draftModelBean.getI18nFileInfo();
        Map<String, Set<CodeListValue>> codeListValueInfoMap = draftModelBean.getCodeListValueInfoMap();
        draftModelBean.setName(tempModelBean.get(NAME).getAsString());
        String namespace = tempModelBean.get(NAMESPACE).getAsString();
        draftModelBean.setNamespace(namespace);
        JsonObject customModel = tempModelBean.get(CUSTOMMODEL).getAsJsonObject();

        draftModelBean.setSchemaVersion(customModel.get(SCHEMA_VERSION).getAsString());
        JsonArray submodels = customModel.get(SUBMODELS).getAsJsonArray();
        setOriginItemTypesEntities(draftModelBean, submodels);
        if (submodels != null) {
            List<SubModelsBean> subModelsBeans = new ArrayList();
            //get item entities info from draft Model:
            submodels.forEach(submodel -> {
                SubModelsBean subModelsBean = new SubModelsBean();
                subModelsBeans.add(subModelsBean);
                String subModelName = "";
                JsonObject submodelObj = submodel.getAsJsonObject();
                if (submodelObj.has(NAME)) {
                    subModelName = submodelObj.get(NAME).getAsString();
                    subModelsBean.setName(subModelName);
                }
                setUsingNameInfo(draftModelBean, subModelName, CORE_MODEL_WITH_NAME_SPACE);
                setSubModelAnnotation(subModelsBean, submodelObj);
                setCodeListEntities(null, subModelsBean, submodelObj, i18nFileInfoMap, codeListValueInfoMap);
                setProcessTypesEntities(draftModelBean, subModelsBean, i18nFileInfoMap, namespace, submodelObj);
                setEventTypesEntities(draftModelBean, subModelsBean, i18nFileInfoMap, submodelObj);

                //forWrite entities:
                setWriteEntitiesOfSubModel(subModelsBean);
            });
            draftModelBean.setSubModels(subModelsBeans);
            draftModelBean.setI18nFileInfo(i18nFileInfoMap);
        }
        return draftModelBean;
    }

    private static void setCodeListEntities(DraftModelBean draftModelBean, SubModelsBean subModelsBean, JsonObject submodelObj, Map<String, Map<String, String>> i18nFileInfoMap, Map<String, Set<CodeListValue>> codeListValueInfoMap) {
        List<CodeListEntity> entities = subModelsBean.getCodeLists();
        if (submodelObj.has(CODE_LISTS)) {
            JsonArray entityArray = submodelObj.get(CODE_LISTS).getAsJsonArray();
            entityArray.forEach(entityJson -> {
                JsonObject entityObj = entityJson.getAsJsonObject();
                String entityName = entityObj.get(NAME).getAsString();
                CodeListEntity codeListEntity = new CodeListEntity();
                codeListEntity.setName(entityName);
                setElementsOfEntity(draftModelBean, subModelsBean, i18nFileInfoMap, codeListEntity, entityObj);
                setCodeListValues(subModelsBean.getName(), entityObj, codeListEntity, codeListValueInfoMap);
                entities.add(codeListEntity);
            });
        }
    }

    private static void setCodeListValues(String subModelName, JsonObject entityObj, CodeListEntity entity, Map<String, Set<CodeListValue>> codeListValueInfoMap) {
        if (entityObj.has(VALUES)) {
            JsonArray valuesJsonArray = entityObj.get(VALUES).getAsJsonArray();
            List<CodeListValue> values = entity.getValues();
            valuesJsonArray.forEach(e -> {
                JsonObject codeListValueObj = e.getAsJsonObject();
                CodeListValue codeListValue = new CodeListValue();
                values.add(codeListValue);
                if (codeListValueObj.has(CODE)) {
                    codeListValue.setCode(codeListValueObj.get(CODE).getAsString());
                }
                if (codeListValueObj.has(NAME)) {
                    codeListValue.setName(codeListValueObj.get(NAME).getAsString());
                }
                setCodeListValueInfo(subModelName, entity.getName(), codeListValueInfoMap, codeListValue);
            });
            entity.setValues(values);

        }
    }

    //set codeListValueInfo for the whole draft model:
    private static void setCodeListValueInfo(String subModelName, String entityName, Map<String, Set<CodeListValue>> codeListValueInfoMap, CodeListValue codeListValue) {
        String codeListFullName = subModelName + DOT + entityName;
        if (codeListValueInfoMap.get(codeListFullName) != null) {
            Set<CodeListValue> codeListValues = codeListValueInfoMap.get(codeListFullName);
            codeListValues.add(codeListValue);
            codeListValueInfoMap.put(codeListFullName, codeListValues);
        } else {
            Set<CodeListValue> codeListValues = new HashSet();
            codeListValues.add(codeListValue);
            codeListValueInfoMap.put(codeListFullName, codeListValues);
        }
    }


    private static void setWriteEntitiesOfSubModel(SubModelsBean subModelsBean) {
        //for each event type entities should have a corresponding forwrite service in CDS file:
        List<EventTypeEntity> eventTypeEntities = subModelsBean.getEventTypes();
        List<BaseEntity> forWriteEntities = subModelsBean.getForWriteEntities();
        for (BaseEntity eventEntity : eventTypeEntities) {
            BaseEntity forWriteEntity = new BaseEntity();
            String entityName = eventEntity.getName();
            forWriteEntity.setName(entityName + FORWRITE);
            List<BaseEntity> forWriteParents = new ArrayList();
            BaseEntity parentEntity1 = new BaseEntity();
            forWriteParents.add(parentEntity1);
            if (entityName.equalsIgnoreCase(DELAYED_EVENT)) {
                parentEntity1.setName(CORE_MODEL_GTT_DELAYED_EVENT_FOR_WRITE);
            } else if (eventEntity.getEntityType().equalsIgnoreCase(PROCESS_EVENT_TYPE)) {
                parentEntity1.setName(CORE_PROCESS_EVENT_FOR_WRITE);
            } else {
                parentEntity1.setName(CORE_MODEL_EVENT_FOR_WRITE);
            }
            forWriteEntity.setParents(forWriteParents);
            forWriteEntities.add(forWriteEntity);
            copyEntityAttributesToWriteEntity(eventEntity, forWriteEntity);
            subModelsBean.setForWriteEntities(forWriteEntities);
        }

    }

    private static void copyEntityAttributesToWriteEntity(BaseEntity eventEntity, BaseEntity forwriteEntity) {
        List<EntityElement> eventEntityElements = eventEntity.getElements();
        List<EntityElement> forWriteEntityElements = forwriteEntity.getElements();
        for (EntityElement eventEntityElement : eventEntityElements) {
            EntityElement forWriteElement = new EntityElement();
            try {
                BeanUtils.copyProperties(forWriteElement, eventEntityElement);
            } catch (IllegalAccessException | InvocationTargetException e) {
                throw new CdsInfoGeneratorException(e.getMessage(), e, MESSAGE_CODE_ERROR_JSON_MODEL_CONVERT_FAILED, new Object[]{});
            }
            forWriteEntityElements.add(forWriteElement);
        }
        forwriteEntity.setElements(forWriteEntityElements);
    }

    private static void setSubModelAnnotation(SubModelsBean subModelsBean, JsonObject submodelObj) {
        List<String> subModelAnnotations = subModelsBean.getAnnotations();
        if (submodelObj.has(RESIDENCEPERIOD)) {
            JsonObject residencePeriodObj = submodelObj.get(RESIDENCEPERIOD).getAsJsonObject();
            String unit = residencePeriodObj.get(UNIT).getAsString();
            String value = residencePeriodObj.get(VALUE).getAsString();
            String residencePeriodUnitAnnotation = CORE_RESIDENCE_PERIOD_UNIT_ANNOTAITON + unit;
            String residencePeriodValueAnnotation = CORE_RESIDENCE_PERIOD_VALUE_ANNOTAITON + value;
            subModelAnnotations.add(residencePeriodUnitAnnotation);
            subModelAnnotations.add(residencePeriodValueAnnotation);
        }
        if (submodelObj.has(BLOCKINGPERIOD)) {
            JsonObject blockingPeriodObj = submodelObj.get(BLOCKINGPERIOD).getAsJsonObject();
            String unit = blockingPeriodObj.get(UNIT).getAsString();
            String value = blockingPeriodObj.get(VALUE).getAsString();
            String blockingPeriodUnitAnnotation = CORE_BLOCKING_PERIOD_UNIT_ANNOTAITON + unit;
            String blockingPeriodValueAnnotation = CORE_BLOCKING_PERIOD_VALUE_ANNOTAITON + value;
            subModelAnnotations.add(blockingPeriodUnitAnnotation);
            subModelAnnotations.add(blockingPeriodValueAnnotation);
        }
        subModelsBean.setAnnotations(subModelAnnotations);

    }

    private static void setProcessTypesEntities(DraftModelBean draftModelBean, SubModelsBean subModelsBean, Map<String, Map<String, String>> i18nFileInfoMap, String namespace, JsonObject submodelObj) {
        List<ProcessTypeEntity> entities = new ArrayList();
        if (submodelObj.has(PROCESS_TYPES)) {
            JsonArray entityArray = submodelObj.get(PROCESS_TYPES).getAsJsonArray();
            entityArray.forEach(entity -> {
                JsonObject entityObj = entity.getAsJsonObject();
                //processTypeEntity:
                ProcessTypeEntity processTypeEntity = new ProcessTypeEntity();
                if (entityObj.get(NAME) != null) {
                    processTypeEntity.setName(entityObj.get(NAME).getAsString());
                }
                setElementsOfEntity(draftModelBean, subModelsBean, i18nFileInfoMap, processTypeEntity, entityObj);
                setParentsOfEntity(processTypeEntity, entityObj);
                setProcessTypeEntityAnnotation(entityObj, processTypeEntity, namespace);
                entities.add(processTypeEntity);
                //each processTypeEntity should create a corresponding eventProcessTypeEntity:
                setProcessEventTypesEntities(draftModelBean, subModelsBean, i18nFileInfoMap, entityObj);

            });
        }
        subModelsBean.setProcessTypes(entities);
    }

    private static void setProcessTypeEntityAnnotation(JsonObject entityObj, ProcessTypeEntity processTypeEntity, String namespace) {
        List<String> annotationList = processTypeEntity.getAnnotations();
        annotationList.add(TRACKED_PROCESS_ANNOTATION);
        if (entityObj.has(TRACKING_ID_TYPE)) {
            String trackingIdType = entityObj.get(TRACKING_ID_TYPE).getAsString();
            annotationList.add(String.format(TRACKING_ID_TYPE_ANNOTATION, trackingIdType));
        }

        processTypeEntity.setAnnotations(annotationList);
        //set plannedEvent annotation and unplanned annotation:
        setPlannedAndUnPlannedEventsOfEntity(namespace, processTypeEntity, entityObj);
    }


    private static void setProcessEventTypesEntities(DraftModelBean draftModelBean, SubModelsBean subModelsBean, Map<String, Map<String, String>> i18nFileInfoMap, JsonObject entityObj) {
        List<EventTypeEntity> eventTypeEntities = subModelsBean.getEventTypes();
        ProcessEventTypeEntity processEventTypeEntity = new ProcessEventTypeEntity();
        if (entityObj.get(NAME) != null) {
            String entityName = entityObj.get(NAME).getAsString();
            String convertedEntityName = entityName + EVENT;
            processEventTypeEntity.setName(convertedEntityName);
        }
        setElementsOfEntity(draftModelBean, subModelsBean, i18nFileInfoMap, processEventTypeEntity, entityObj);
        setParentsOfEntity(processEventTypeEntity, entityObj);
        List<String> annotations = processEventTypeEntity.getAnnotations();
        annotations.add(EVENT_ANNOTATION);
        annotations.add(IS_PROCESS_EVENT_ANNOTATION);
        processEventTypeEntity.setAnnotations(annotations);
        eventTypeEntities.add(processEventTypeEntity);
    }

    private static void setEventTypesEntities(DraftModelBean draftModelBean, SubModelsBean subModelsBean, Map<String, Map<String, String>> i18nFileInfoMap, JsonObject submodelObj) {
        List<EventTypeEntity> entities = new ArrayList();
        if (submodelObj.has(EVENT_TYPES)) {
            JsonArray entityArray = submodelObj.get(EVENT_TYPES).getAsJsonArray();
            entityArray.forEach(entity -> {
                JsonObject entityObj = entity.getAsJsonObject();
                String entityName = entityObj.get(NAME).getAsString();
                EventTypeEntity eventTypeEntity = new EventTypeEntity();
                eventTypeEntity.setName(entityName);
                setElementsOfEntity(draftModelBean, subModelsBean, i18nFileInfoMap, eventTypeEntity, entityObj);
                setParentsOfEntity(eventTypeEntity, entityObj);
                List<String> annotations = eventTypeEntity.getAnnotations();
                annotations.add(EVENT_ANNOTATION);
                eventTypeEntity.setAnnotations(annotations);
                entities.add(eventTypeEntity);
            });
        }
        List<EventTypeEntity> eventTypeEntities = subModelsBean.getEventTypes();
        eventTypeEntities.addAll(entities);
    }


    private static void setOriginItemTypesEntities(DraftModelBean draftModelBean, JsonArray submodels) {
        Map<String, ItemTypeEntity> itemTypeEntityMap = draftModelBean.getOrignalItemTypeEntityMap();
        Map<String, ItemTypeEntity> itemTypeEntityMapWithComposition = new HashMap();
        if (submodels != null) {
            //get item entities info from draft Model:
            submodels.forEach(submodel -> {
                JsonObject subModelObj = submodel.getAsJsonObject();
                setOriginItemTypesEntities(draftModelBean, subModelObj, itemTypeEntityMapWithComposition, itemTypeEntityMap);
            });
        }
        //need to add a recursive handleItemWithComposition(); private static void handleItemWithComposition(Map<String,ItemTypeEntity> itemTypeEntityMap,Map<String,ItemTypeEntity> itemTypeEntityMapWithComposition) {
        handleItemWithComposition( draftModelBean,  itemTypeEntityMapWithComposition);
        draftModelBean.setOrignalItemTypeEntityMap(itemTypeEntityMap);
    }

    private static void handleItemWithComposition(DraftModelBean draftModelBean,Map<String,ItemTypeEntity> itemTypeEntityMapWithComposition) {
        if(!itemTypeEntityMapWithComposition.isEmpty()) {
            Map<String,ItemTypeEntity> orignalItemTypeEntityMap = draftModelBean.getOrignalItemTypeEntityMap();
            Set<String> itemEntityFullNames = itemTypeEntityMapWithComposition.keySet();
            for(String itemEntityFullName :itemEntityFullNames) {
                ItemTypeEntity itemEntity = itemTypeEntityMapWithComposition.get(itemEntityFullName);
                if(itemEntity !=null) {
                    Set<EntityElement> entityElements = itemEntity.getElements().stream().filter(e->e.getType().equalsIgnoreCase(COMPOSITION) && !e.isCompositionHandled()).collect(Collectors.toSet());
                    for(EntityElement compositionElement:entityElements) {
                        String itemCompositionTarget = compositionElement.getTarget();
                        if(orignalItemTypeEntityMap.get(itemCompositionTarget)!=null) {
                            //each composition attribute should have a corresponding item entity:
                            setItemEntityOfSubModel( draftModelBean, itemEntity.getSubModelBeanName(),  compositionElement,  itemEntity);
                            orignalItemTypeEntityMap.put(itemEntityFullName,itemEntity);
                            compositionElement.setCompositionHandled(true);
                            orignalItemTypeEntityMap.remove(itemEntity);
                        }else{
                            //recursive call:
                            handleItemWithComposition( draftModelBean, itemTypeEntityMapWithComposition);
                        }
                    }

                }

            }
        }
    }



    private static void setOriginItemTypesEntities(DraftModelBean draftModelBean, JsonObject subModelObj, Map<String, ItemTypeEntity> itemTypeEntityMapWithComposition, Map<String, ItemTypeEntity> itemTypeEntityMap) {
        SubModelsBean subModelsBean = new SubModelsBean();
        String subModleName = "";
        if (subModelObj.has(NAME)) {
            subModleName = subModelObj.get(NAME).getAsString();
        }
        final String subModelBeanName = subModleName;
        subModelsBean.setName(subModleName);
        if (subModelObj.has(ITEM_TYPES)) {
            JsonArray itemEntityArray = subModelObj.get(ITEM_TYPES).getAsJsonArray();
            itemEntityArray.forEach(itemEntity -> {
                JsonObject itemEntityObj = itemEntity.getAsJsonObject();
                String entityName = "";
                if (itemEntityObj.get(NAME) != null) {
                    entityName = itemEntityObj.get(NAME).getAsString();
                }
                ItemTypeEntity itemTypeEntity = new ItemTypeEntity();
                itemTypeEntity.setName(entityName);
                setElementsOfEntity(draftModelBean, subModelsBean, null, itemTypeEntity, itemEntityObj);
                String fullName = subModelsBean.getName() + DOT + entityName;
                if (itemTypeEntity.isHasCompositionAttribute()) {
                    itemTypeEntityMapWithComposition.put(fullName, itemTypeEntity);
                    itemTypeEntity.setSubModelBeanName(subModelBeanName);
                } else {
                    itemTypeEntityMap.put(fullName, itemTypeEntity);
                }
            });
        }
    }


    private static void setPlannedAndUnPlannedEventsOfEntity(String namepace, BaseEntity entity, JsonObject entityObj) {
        List<String> annotationsOfProcesstype = entity.getAnnotations();
        if (entityObj.has(PLANNEDEVENTS)) {
            JsonArray plannedEventsJsonArray = entityObj.get(PLANNEDEVENTS).getAsJsonArray();
            List<ProcessPlannedEvent> plannedEvents = createPlannedEventsForProcessType(namepace, plannedEventsJsonArray);
            if (!plannedEvents.isEmpty()) {
                ((ProcessTypeEntity) entity).setPlannedEvents(plannedEvents);
                String plannedEventsStr = StringUtils.join(plannedEvents, COMMA);
                String plannedEventsAnnotation = String.format(PLANNED_EVENTS_ANNOTATION, plannedEventsStr);
                annotationsOfProcesstype.add(plannedEventsAnnotation);
                entity.setAnnotations(annotationsOfProcesstype);
            }
        }
        if (entityObj.has(ADMISSIBLE_UNPLANNED_EVENTS)) {
            JsonArray unPlannedEventsJsonArray = entityObj.get(ADMISSIBLE_UNPLANNED_EVENTS).getAsJsonArray();
            List<ProcessUnplannedEvent> unPlannedEvents = createUnplannedEventsForProcessType(namepace, unPlannedEventsJsonArray);
            if (!unPlannedEvents.isEmpty()) {
                ((ProcessTypeEntity) entity).setAdmissibleUnplannedEvents(unPlannedEvents);
                String unPlannedEventsStr = StringUtils.join(unPlannedEvents, COMMA);
                String unPlannedEventsAnnotation = String.format(UNPLANNED_EVENTS_ANNOTATION, unPlannedEventsStr);
                annotationsOfProcesstype.add(unPlannedEventsAnnotation);
                entity.setAnnotations(annotationsOfProcesstype);
            }
        }
    }

    private static void setParentsOfEntity(BaseEntity entity, JsonObject entityObj) {
        if (entityObj.has(PARENT)) {
            List<BaseEntity> parents = new ArrayList();
            BaseEntity parentBaseEntity = new BaseEntity();
            JsonObject parentObj = entityObj.get(PARENT).getAsJsonObject();
            if (parentObj.has(TARGET)) {
                String target = parentObj.get(TARGET).getAsString();
                if (entity.getEntityType().equalsIgnoreCase(PROCESS_EVENT_TYPE) && target.equalsIgnoreCase(CORE_MODEL_TRACKED_PROCESS)) {
                    parentBaseEntity.setName(CORE_MODEL_PROCESS_EVENT);
                } else {
                    parentBaseEntity.setName(target);
                }
                parents.add(parentBaseEntity);
                entity.setParents(parents);
            }
        }
    }

    private static void setElementsOfEntity(DraftModelBean draftModelBean, SubModelsBean subModelsBean, Map<String, Map<String, String>> i18nFileInfoMap, BaseEntity entity, JsonObject entityObj) {
        if (entityObj.has(ELEMENTS)) {
            JsonArray entityElements = entityObj.get(ELEMENTS).getAsJsonArray();
            List<EntityElement> elements = new ArrayList();
            entityElements.forEach(e -> {
                JsonObject elementObj = e.getAsJsonObject();
                EntityElement element = new EntityElement();
                setBasicEntityElement(element, elementObj);
                handleCompositionElement(draftModelBean, subModelsBean, element, entity, elementObj);

                EntityElement newaddedElement = handleAssociationElement(draftModelBean, subModelsBean, element, entity, elementObj);
                if (newaddedElement != null) {
                    elements.add(newaddedElement);
                    handleDppAnnotationOfTheElement(newaddedElement, elementObj);
                    handleI18nOfTheElement(i18nFileInfoMap, entity, newaddedElement, elementObj);
                }
                elements.add(element);
                handleDppAnnotationOfTheElement(element, elementObj);
                handleI18nOfTheElement(i18nFileInfoMap, entity, element, elementObj);
                handleCodeListElement(draftModelBean, subModelsBean, element, elementObj);
            });
            if (!elements.isEmpty()) {
                entity.setElements(elements);
            }
        }
    }

    private static List<ProcessUnplannedEvent> createUnplannedEventsForProcessType(String namespace, JsonArray plannedEventsJsonArray) {
        List<ProcessUnplannedEvent> unPlannedEvents = new ArrayList();
        plannedEventsJsonArray.forEach(e -> {
            ProcessUnplannedEvent processUnplannedEvent = new ProcessUnplannedEvent();
            unPlannedEvents.add(processUnplannedEvent);
            String eventType = getEventType(namespace, e.getAsJsonObject());
            processUnplannedEvent.setEventType((eventType));
        });
        return unPlannedEvents;
    }

    private static List<ProcessPlannedEvent> createPlannedEventsForProcessType(String namespace, JsonArray plannedEventsJsonArray) {
        List<ProcessPlannedEvent> plannedEvents = new ArrayList();
        plannedEventsJsonArray.forEach(e -> {
            ProcessPlannedEvent processPlannedEvent = new ProcessPlannedEvent();
            plannedEvents.add(processPlannedEvent);
            JsonObject plannedEventObj = e.getAsJsonObject();
            String eventType = getEventType(namespace, plannedEventObj);
            processPlannedEvent.setEventType(eventType);
            if (plannedEventObj.has(MATCHLOCATION)) {
                processPlannedEvent.setMatchLocation((plannedEventObj.get(MATCHLOCATION).getAsBoolean()));
            }
            if (plannedEventObj.has(BUSINESS_TOLERANCE_VALUE) && plannedEventObj.has(BUSINESS_TOLERANCE_UNIT)) {
                processPlannedEvent.setBusinessToleranceValue(String.format(FORMAT_TOLERANCE_VALUE,
                        plannedEventObj.get(BUSINESS_TOLERANCE_VALUE).getAsString(),
                        plannedEventObj.get(BUSINESS_TOLERANCE_UNIT).getAsString()));
            }
            if (plannedEventObj.has(TECHNICAL_TOLERANCE_VALUE) && plannedEventObj.has(TECHNICAL_TOLERANCE_UNIT)) {
                processPlannedEvent.setTechnicalToleranceValue(String.format(FORMAT_TOLERANCE_VALUE,
                        plannedEventObj.get(TECHNICAL_TOLERANCE_VALUE).getAsString(),
                        plannedEventObj.get(TECHNICAL_TOLERANCE_UNIT).getAsString()));
            }
            if (plannedEventObj.has(PERIOD_OVERDUE_DETECTION) && plannedEventObj.has(PERIOD_OVERDUE_DETECTION_UNIT)) {
                processPlannedEvent.setPeriodicOverdueDetection(String.format(FORMAT_TOLERANCE_VALUE,
                        plannedEventObj.get(PERIOD_OVERDUE_DETECTION).getAsString(),
                        plannedEventObj.get(PERIOD_OVERDUE_DETECTION_UNIT).getAsString()));
            }
            if (plannedEventObj.has(MAX_OVERDUE_DETECTION)) {
                processPlannedEvent.setMaxOverdueDetection((plannedEventObj.get(MAX_OVERDUE_DETECTION).getAsInt()));
            }
        });
        return plannedEvents;
    }

    private static String getEventType(String namespace, JsonObject eventObject) {
        String eventType = "";
        if (eventObject.has(EVENTTYPE)) {
            JsonObject eventTypeObj = eventObject.get(EVENTTYPE).getAsJsonObject();
            eventType = eventTypeObj.get(TARGET).getAsString();
            if (namespace != null) {
                eventType = namespace + DOT + eventType;
            }
        }
        return eventType;
    }

    private static EntityElement handleAssociationElement(DraftModelBean draftModelBean, SubModelsBean subModelsBean, EntityElement element, BaseEntity entity, JsonObject elementObj) {
        EntityElement newAddedEntityElement = null;
        if (element.getType().equals(ASSOCIATION)) {
            setAssociationCardinality(element);
            if (entity.getEntityType().equalsIgnoreCase(ITEM_TYPE)) {
                String elementName = StringUtils.uncapitalize(entity.getName());
                element.setName(elementName);
                //if the entity type is item ,the association attribute should be generated automatically
                //it will not be given by the item entity of the draftModel
                element.setTarget("");
                setElementTargetInfo(draftModelBean, subModelsBean, element);
            } else {
                if (elementObj.has(TARGET)) {
                    String target = elementObj.get(TARGET).getAsString();
                    element.setTarget(target);
                    setElementTargetInfo(draftModelBean, subModelsBean, element);
                }
            }
            //if the entity is a TP, should add additional attributes for the assocication attribute:
            if (entity.getEntityType().equalsIgnoreCase(PROCESS_TYPE) || entity.getEntityType().equalsIgnoreCase(PROCESS_EVENT_TYPE)) {
                String newAddedElementName = element.getName() + ALTKEY;
                newAddedEntityElement = new EntityElement();
                newAddedEntityElement.setHidden(true);
                newAddedEntityElement.setName(newAddedElementName);
                newAddedEntityElement.setType(STRING);
                newAddedEntityElement.setLength(LENGTH_OF_ASSOCIATION_ADDED_ATTRIBUTE);
                newAddedEntityElement.setWritable(element.isWritable());
                newAddedEntityElement.setReadable(element.isReadable());
                List<String> annotations = element.getAnnotations();
                annotations.add(String.format(CORE_MODEL_NAVIGATION_PROPERTY, newAddedElementName));
                element.setWritable(Boolean.FALSE);
                element.setHidden(true);
            }
        }
        return newAddedEntityElement;
    }

    private static void setElementTargetInfo(DraftModelBean draftModelBean, SubModelsBean subModelsBean, EntityElement element) {
        String target = element.getTarget();
        if (StringUtils.isNotBlank(target)) {
            String subModelsBeanName = subModelsBean.getName();
            int indexOfDot = target.indexOf(DOT);
            if (indexOfDot > 0) {
                String targetModelName = target.substring(0, indexOfDot);
                String targetEntityName = target.substring(indexOfDot + 1);

                if (targetModelName.equalsIgnoreCase(subModelsBeanName)) {
                    element.setTargetModelName("");
                } else {
                    element.setTargetModelName(targetModelName + ALIAS);
                    setUsingNameInfo(draftModelBean, subModelsBeanName, targetModelName);
                }
                element.setTargetEntityName(targetEntityName);
            }
        }
    }

    private static void handleCompositionElement(DraftModelBean draftModelBean, SubModelsBean subModelsBean, EntityElement element, BaseEntity entity, JsonObject elementObj) {
        String entityName = entity.getName();
        if (element.getType().equalsIgnoreCase(COMPOSITION)) {
            if (entity instanceof ItemTypeEntity) {
                ((ItemTypeEntity) entity).setHasCompositionAttribute(true);
            }
            setElementCardinality(element, elementObj);
            String targetName = elementObj.get(TARGET).getAsString();
            element.setTarget(targetName);
            String convertedTargetEntityName = "";
            setElementTargetInfo(draftModelBean, subModelsBean, element);
            convertedTargetEntityName = entityName + StringUtils.capitalize(element.getName());
            element.setTargetEntityName(convertedTargetEntityName);
            String targetOnKey = element.getName() + DOT + StringUtils.uncapitalize(entityName);
            String targetOnValue = "$self";
            String targetOnInfo = targetOnKey + "=" + targetOnValue;
            Set<String> targetOnInfoSet = element.getTargetOnInfo();
            targetOnInfoSet.add(targetOnInfo);
            element.setTargetOnInfo(targetOnInfoSet);
            //each composition attribute should have a corresponding item entity:
            if(!entity.getEntityType().equalsIgnoreCase(ITEM_TYPE)) {
                setItemEntityOfSubModel(draftModelBean, subModelsBean.getName(), element, entity);
            }
        }
    }


    private static void setItemEntityOfSubModel(DraftModelBean draftModelBean, String subModleName, EntityElement compositionElement, BaseEntity compositionEntity) {
        Map<String, ItemTypeEntity> orignalItemTypeEntityMap = draftModelBean.getOrignalItemTypeEntityMap();
        Map<String, Set<ItemTypeEntity>> itemTypeEntityInfoMap = draftModelBean.getItemTypeEntityInfoMap();
        String target = compositionElement.getTarget();
        if (orignalItemTypeEntityMap.get(target) != null) {
            String compositionElementName = compositionElement.getName();
            //for item entity, the target should be set to the association target. the composition entity's target is not
            //the target of the item entity's target. the item entity's target is the composition entity itself as the assocation
            // refers back to the composition element.
            //String targetModelNameOfAssociation = subModelsBean.getName();
            String targetModelNameOfAssociation = subModleName;
            String compositionTargetModelWithoutConvert = getModelNameFromTargetWhoutConvert(target);
            String targetEntityNameOfAssociation = compositionEntity.getName();
            String targetOfAssociation = targetModelNameOfAssociation + DOT + targetEntityNameOfAssociation;
            String compositionTargetModelName = getModelNameFromTargetWhoutConvert(target);
            ItemTypeEntity itemTypeEntityOrigin = orignalItemTypeEntityMap.get(target);
            ItemTypeEntity itemTypeEntity = new ItemTypeEntity();
            Set<ItemTypeEntity> itemTypeEntitySet;
            if (itemTypeEntityInfoMap.get(compositionTargetModelName) != null) {
                itemTypeEntitySet = itemTypeEntityInfoMap.get(compositionTargetModelName);
                itemTypeEntitySet.add(itemTypeEntity);
            } else {
                itemTypeEntitySet = new HashSet();
                itemTypeEntitySet.add(itemTypeEntity);
            }
            itemTypeEntityInfoMap.put(compositionTargetModelName, itemTypeEntitySet);
            String itemTypeEntityName = compositionEntity.getName() + StringUtils.capitalize(compositionElementName);
            itemTypeEntity.setName(itemTypeEntityName);
            try {
                List<EntityElement> entityElementsOfOrigin = itemTypeEntityOrigin.getElements();
                List<EntityElement> entityElements = itemTypeEntity.getElements();
                for (EntityElement entityElementOrigin : entityElementsOfOrigin) {
                    EntityElement entityElement = new EntityElement();
                    BeanUtils.copyProperties(entityElement, entityElementOrigin);
                    entityElements.add(entityElement);
                }
                EntityElement newAddedElement = new EntityElement();
                entityElements.add(newAddedElement);
                newAddedElement.setType(ASSOCIATION);
                newAddedElement.setReadable(Boolean.TRUE);
                newAddedElement.setWritable(Boolean.FALSE);
                String newAddedElementName = StringUtils.uncapitalize(compositionEntity.getName());
                newAddedElement.setName(newAddedElementName);
                String convertedTargetModelNameOfAssociation;
                if (targetModelNameOfAssociation.equalsIgnoreCase(compositionTargetModelWithoutConvert)) {
                    convertedTargetModelNameOfAssociation = "";
                } else {
                    convertedTargetModelNameOfAssociation = targetModelNameOfAssociation + ALIAS;
                    setUsingNameInfo(draftModelBean, subModleName, compositionTargetModelName);
                    //for the item entity create, the target model also need to refer the current submodel in the association define.
                    setUsingNameInfo(draftModelBean, compositionTargetModelName, subModleName);
                }
                newAddedElement.setTarget(targetOfAssociation);
                newAddedElement.setTargetEntityName(targetEntityNameOfAssociation);
                newAddedElement.setTargetModelName(convertedTargetModelNameOfAssociation);
                newAddedElement.setContext(compositionTargetModelName);
                setAssociationCardinality(newAddedElement);
                itemTypeEntity.setElements(entityElements);

            } catch (IllegalAccessException | InvocationTargetException e) {
                throw new CdsInfoGeneratorException(e.getMessage(), e, MESSAGE_CODE_ERROR_JSON_MODEL_CONVERT_FAILED, new Object[]{});
            }
        }
    }

    private static void setAssociationCardinality(EntityElement element) {
        ElementCardinality cardinality = new ElementCardinality();
        cardinality.setMax("1");
        element.setCardinality(cardinality);
    }

    private static String getEntityNameFromTarget(String target) {
        String entityName = "";
        int indexOfDot = target.indexOf(DOT);
        if (indexOfDot > 0) {
            entityName = target.substring(indexOfDot + 1);
        } else {
            entityName = target;
        }
        return entityName;
    }


    private static String getModelNameFromTargetWhoutConvert(String target) {
        int indexOfDot = target.indexOf(DOT);
        String targetModelName = "";
        if (indexOfDot > 0) {
            targetModelName = target.substring(0, indexOfDot);
        } else {
            targetModelName = target;
        }
        return targetModelName;
    }

    private static String getModelNameFromTarget(String target, SubModelsBean subModelsBean) {
        int indexOfDot = target.indexOf(DOT);
        String targetModelName = "";
        if (indexOfDot > 0) {
            targetModelName = target.substring(0, indexOfDot);
            if (targetModelName.equalsIgnoreCase(subModelsBean.getName())) {
                targetModelName = "";
            }
        } else {
            targetModelName = target;
        }
        return targetModelName;
    }

    private static void setElementCardinality(EntityElement element, JsonObject elementObj) {
        if (elementObj.has(CARDINALITY) && elementObj.get(CARDINALITY).getAsJsonObject().has(MAX)) {
            ElementCardinality cardinality = new ElementCardinality();
            cardinality.setMax(elementObj.get(CARDINALITY).getAsJsonObject().get(MAX).getAsString());
            element.setCardinality(cardinality);
        }
    }

    private static void setBasicEntityElement(EntityElement entityElement, JsonObject entityElementObj) {
        if (entityElementObj.has(NAME)) {
            entityElement.setName(entityElementObj.get(NAME).getAsString());
        }
        if (entityElementObj.has(CONTEXT)) {
            entityElement.setContext(entityElementObj.get(CONTEXT).getAsString());
        }
        if (entityElementObj.has(TYPE)) {
            String elementType = entityElementObj.get(TYPE).getAsString();
            if (elementType.equalsIgnoreCase(UUID)) {
                elementType = UUID;
            }
            entityElement.setType(elementType);
        }
        if (entityElementObj.has(KEY)) {
            entityElement.setKey(entityElementObj.get(KEY).getAsBoolean());
        }
        if (entityElementObj.has(REQUIRED)) {
            entityElement.setNotNull(entityElementObj.get(REQUIRED).getAsBoolean());
        }
        if (entityElementObj.has(READABLE)) {
            entityElement.setReadable(entityElementObj.get(READABLE).getAsBoolean());
        }
        if (entityElementObj.has(WRITABLE)) {
            entityElement.setWritable(entityElementObj.get(WRITABLE).getAsBoolean());
        }
        if (entityElementObj.has(LENGTH)) {
            entityElement.setLength(entityElementObj.get(LENGTH).getAsInt());
        }
        if (entityElementObj.has(PRECISION)) {
            entityElement.setPrecision(entityElementObj.get(PRECISION).getAsInt());
        }
        if (entityElementObj.has(SCALE)) {
            entityElement.setScale(entityElementObj.get(SCALE).getAsInt());
        }
        if (entityElementObj.has(LOCALIZED)) {
            entityElement.setLocalized(entityElementObj.get(LOCALIZED).getAsBoolean());
        }
    }

    private static void handleCodeListElement(DraftModelBean draftModelBean, SubModelsBean subModelsBean, EntityElement entityElement, JsonObject elementObj) {
        if (entityElement.getType().equalsIgnoreCase(CODE_LIST)) {
            entityElement.setType(CODE_LIST);
            ElementCardinality cardinality = new ElementCardinality();
            cardinality.setMax("1");
            entityElement.setCardinality(cardinality);
            if (elementObj.has(TARGET)) {
                String targetTemp = elementObj.get(TARGET).getAsString();
                entityElement.setTarget(targetTemp);
                String targetModelName = getModelNameFromTarget(targetTemp, subModelsBean);
                String targetEntityName = getEntityNameFromTarget(targetTemp);
                if (StringUtils.isNotBlank(targetModelName)) {
                    String convertedModelName = targetModelName + ALIAS;
                    entityElement.setTargetModelName(convertedModelName);
                    setUsingNameInfo(draftModelBean, subModelsBean.getName(), targetModelName);
                } else {
                    entityElement.setTargetModelName("");
                }
                entityElement.setTargetEntityName(targetEntityName);
            }
            if (elementObj.has(DEFAULT)) {
                entityElement.setDefaultValue(elementObj.get(DEFAULT).getAsString());
                handleEntityElementAnnotation(entityElement, CODE_LIST_ANNOTATION_TEMPLATE, entityElement.getDefaultValue());

            }
        }
    }

    private static void setUsingNameInfo(DraftModelBean draftModelBean, String currentEntitySubModelName, String targetModelName) {
        Map<String, Set<String>> usingNameMap = draftModelBean.getUsingEntityNameMap();
        if (usingNameMap.get(currentEntitySubModelName) != null) {
            Set<String> usingNameSet = usingNameMap.get(currentEntitySubModelName);
            usingNameSet.add(targetModelName);
            usingNameMap.put(currentEntitySubModelName, usingNameSet);
        } else {
            Set<String> usingNameSet = new HashSet();
            usingNameSet.add(targetModelName);
            usingNameMap.put(currentEntitySubModelName, usingNameSet);
        }
        draftModelBean.setUsingEntityNameMap(usingNameMap);
    }

    private static void handleEntityElementAnnotation(EntityElement entityElement, String annotationTemplate, String annotationValue) {
        List<String> annotations = entityElement.getAnnotations();
        String annotationScript = String.format(annotationTemplate, annotationValue);
        annotations.add(annotationScript);
        entityElement.setAnnotations(annotations);
    }

    private static void handleI18nOfTheElement(Map<String, Map<String, String>> i18nFileInfoMap, BaseEntity entity, EntityElement element, JsonObject elementObj) {
        if (elementObj.has(LABEL)) {
            String elementName = element.getName();
            String i18nElementKey = geti18nElementKey(entity.getName(), elementName);
            if (i18nFileInfoMap != null) {
                handledefaultI18nInfo(i18nFileInfoMap, elementObj, element, i18nElementKey);
                handleOtherI18nInfo(i18nFileInfoMap, elementObj, i18nElementKey);
            }
        }
    }

    protected static String geti18nElementKey(String entityName, String elementName) {
        return String.format(I18NELEMENTKEY, OBJECT_TYPE_ELEMENT, entityName, elementName, LABEL.toUpperCase());
    }

    private static void handleOtherI18nInfo(Map<String, Map<String, String>> i18nFileInfoMap, JsonObject elementObj, String i18nElementKey) {
        if (elementObj.has(TRANSLATION)) {
            JsonObject translationObj = elementObj.get(TRANSLATION).getAsJsonObject();
            if (translationObj.get(LABEL) != null) {
                JsonObject tranlationLabelObj = translationObj.get(LABEL).getAsJsonObject();
                if (tranlationLabelObj.get(TEXT_TYPE) != null && tranlationLabelObj.get(TEXT_TYPE).getAsString().equalsIgnoreCase(LABEL)) {
                    JsonObject i18nTranslation = tranlationLabelObj.get(TRANSLATION).getAsJsonObject();
                    createI18nContent(i18nTranslation, i18nFileInfoMap, i18nElementKey);
                }
            }
        }
    }

    private static void createI18nContent(JsonObject i18nTranslation, Map<String, Map<String, String>> i18nFileInfoMap, String i18nElementKey) {
        i18nTranslation.entrySet().forEach(entry -> {
            String fileNamekey = entry.getKey();
            String fileName = "";
            if (fileNamekey != null) {
                fileName = I18N + UNDERSCORE + fileNamekey.replace(BAR, UNDERSCORE) + DOT + PROPERTIES;
                Map<String, String> i18nFileContentMap = null;
                if (i18nFileInfoMap.get(fileName) != null) {
                    i18nFileContentMap = i18nFileInfoMap.get(fileName);
                } else {
                    i18nFileContentMap = new HashMap();
                    i18nFileInfoMap.put(fileName, i18nFileContentMap);
                }
                i18nFileContentMap.put(i18nElementKey, entry.getValue().getAsString());
            }
        });
    }

    private static void handledefaultI18nInfo(Map<String, Map<String, String>> i18nFileInfoMap, JsonObject elementObj, EntityElement element, String i18nElementKey) {
        String i18nDefaultValue = elementObj.get(LABEL).getAsString();
        handleEntityElementAnnotation(element, I18N_ANNOTATION, i18nElementKey);
        Map<String, String> i18nDefaultFileContentMap = null;
        if (i18nFileInfoMap.get(DEFAULT_I18N_FILE_NAME) != null) {
            i18nDefaultFileContentMap = i18nFileInfoMap.get(DEFAULT_I18N_FILE_NAME);
        } else {
            i18nDefaultFileContentMap = new HashMap();
            i18nFileInfoMap.put(DEFAULT_I18N_FILE_NAME, i18nDefaultFileContentMap);
        }
        i18nDefaultFileContentMap.put(i18nElementKey, i18nDefaultValue);
    }

    private static void handleDppAnnotationOfTheElement(EntityElement element, JsonObject elementObj) {
        if (elementObj.has(DPP)) {
            List<String> annotations = element.getAnnotations();
            JsonArray dppArray = elementObj.get(DPP).getAsJsonArray();
            dppArray.forEach(dpp -> {
                if (dpp.getAsString().equals(PII)) {
                    annotations.add(DPP_PII_ANNOTATION);
                }
                if (dpp.getAsString().equals(SPI)) {
                    annotations.add(DPP_SPI_ANNOTATION);
                }
                if (dpp.getAsString().equals(DATA_SUBJECT_ID)) {
                    annotations.add(DPP_DATA_SUBJECT_ID_ANNOTATION);
                }
            });
            element.setAnnotations(annotations);
        }
    }
}
