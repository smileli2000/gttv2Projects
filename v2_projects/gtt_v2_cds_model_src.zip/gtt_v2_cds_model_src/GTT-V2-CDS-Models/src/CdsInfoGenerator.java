package com.sap.gtt.v2.metadataservice.utils;

import com.google.gson.JsonObject;
import com.sap.gtt.v2.metadataservice.domain.*;
import com.sap.gtt.v2.metadataservice.exception.CdsInfoGeneratorException;
import com.sap.gtt.v2.util.JsonUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.util.*;

import static com.sap.gtt.v2.metadataservice.utils.JsonModelConverter.*;

public class CdsInfoGenerator {
    private CdsInfoGenerator() {

    }

    private static final String DOT_CDS = ".cds";
    private static final String SPACE = " ";
    private static final String SEMICOLON = " ; ";
    private static final String COLON = " : ";
    private static final String COLON_WITHSPACE = "                       : ";
    private static final String LEFT_BRACE = " { ";
    private static final String RIGHT_BRACE = " } ";
    private static final String USING = "using";
    private static final String NEWLINE = "\n";
    private static final String CORE_MODEL_NAMESPACE = "com.sap.gtt.core.CoreModel";
    private static final String CONTEXT = "context";
    private static final String ENTITY = "entity";
    private static final String NOT_NULL = "not null";
    private static final String ASSOCIATION = "Association";
    private static final String COMPOSITION = "Composition";
    private static final String LEFT_PARENTTHESIS = "(";
    private static final String RIGHT_PARENTTHESIS = ")";
    private static final String COMMA = " , ";
    private static final String STAR = "*";
    private static final String ONE = "1";
    private static final String TO_ONE = "to one";
    private static final String OF_MANY = "of many";
    private static final String ON = "on";
    private static final String SERVICE = "Service";
    private static final String READ_SERVICE_TEMPLATE_FILE = "readServiceTemplate.cds";
    private static final String WRITE_SERVICE_TEMPLATE_FILE = "writeServiceTemplate.cds";
    private static final String TAB = "\t";
    private static final String SWAGGER_TEMPLATE_FILE = "swaggerTemplate.cds";
    private static final String READ_SERVICE_ENTITY_TEMPLATE = "entity %s as projection on %s.%s";
    private static final String READ_ONLY_ANNOTATION = "@readonly";
    private static final String EXCLUDING_TEMPLATE = " excluding { \n\t\t%s \n\t}";
    private static final String WRITE_SERVICE = "WriteService";
    private static final String I18N_FILE_CONTENT = "%s=%s\n";
    private static final String UI_TEMPLATE_FILE = "uiCdsTemplate.cds";
    private static final Map<String, List<String>> coreModelUISelectionFieldsMap = new HashMap();
    private static final Map<String, List<String>> coreModelUILineItemsMap = new HashMap();
    private static final Map<String, List<String>> coreModelUIFieldGroupsMap = new HashMap();
    private static final Map<String,List<String>> newCoreModelUIFieldGroupMap = new HashMap();
    private static final String CORE_MODEL_TRACKEDPROCESS = "CoreModel.TrackedProcess";
    private static final String CORE_MODEL_PLANNEDEVENT = "CoreModel.PlannedEvent";
    private static final String CORE_MODEL_EVENT = "CoreModel.Event";
    private static final String UI_ANNOTATION_BODY_TEMPLATE = "\nannotate %s.%s with @(\n%s\n)\n%s;";
    private static final String UI_SELECTIONFILEDS_TEMPLATE = "\n\tUI.SelectionFields: [\n\t\t%s\n\t]";
    private static final String UI_LINEITEMS_TEMPLATE = "\n\tUI.LineItem: [\n\t\t%s\n\t]";
    private static final String UI_FILEDGROUP_TEMPLATE = "\n\tUI.FieldGroup #DisplayFields : {\n\t\tLabel : '{@i18n>com.sap.gtt.core.DisplayFields}',\n\t\tData  : [\n\t\t%s\n\t]\n\t}";
    private static final String UI_CORE_MODEL_FILEDGROUP_TEMPLATE = "\n\tUI.FieldGroup #CoreModelFields : {\n\t\tLabel : '{@i18n>com.sap.gtt.core.DisplayFields}',\n\t\tData  : [\n\t\t%s\n\t]\n\t}";
    private static final String UI_USER_MODEL_FILEDGROUP_TEMPLATE = "\n\tUI.FieldGroup #UserModelFields : {\n\t\tLabel : '{@i18n>com.sap.gtt.core.DisplayFields}',\n\t\tData  : [\n\t\t%s\n\t]\n\t}";
    private static final String PACKAGE_TEMPLATE = "{\n\"name\": \"%s\",\n\"version\":\"%s\",\n\"Description\":\"%s\"\n}";
    private static final String PAKCAGE_FILE_NAME = "package.json";
    private static final String EVENT = "Event";
    private static final String LINE_SEPERATOR = ",\n\t\t";
    private static final String CORE_MODEL_QUALIFIED_TRACKING_ID = "CoreModel.QualifiedTrackingId";
    private static final String CORE_MODEL_REFERENCE = "CoreModel.Reference";
    private static final int SELECTION_FIELDS_COUNT = 5;
    private static final int LINE_ITEM_COUNT = 7;
    private static final String LABEL_VALUE_FORMAT = "{Label : '{@i18n>%s}', Value : \"%s\"} ";
    private static final String ALIAS = "Alias";
    private static final String LAST_CHANGED_DATE_TIME_LABEL = "{Label : '{@i18n>EL_TrackedProcess_lastChangeDateTime_LABEL}',Value :lastChangeDateTime}";
    private static final String LAST_CHANGED_BY_USER_LABEL = "{Label : '{@i18n>EL_TrackedProcess_lastChangedByUser_LABEL}',Value :lastChangedByUser}";
    private static final String VALID_FROM = "validFrom";
    private static final String CODE_LIST = "codelist";
    private static final String CODE_LIST_ATTRIBUTE_TEMPLATE = "%s                      : Association to one %s ";
    private static final String CODE_LIST_DEFAULT_TEMPLATE = "\tdefault '%s';";
    private static final String ENUM_TEMPLATE = "%s : String(50) enum { \n";
    private static final String ENUM_KEY_VALUE_TEMPLATE = "\t%s = '%s';";
    private static final String DRAFT_MODEL_CUSTOM_FILE = "jsonModel.json";
    private static final String AS = "as";
    private static final String EVENT_TO_ACTION_SCRIPT = "eventToAction.script";
    private static final String EVENT_TO_ACTION = "eventToAction";
    private static final String LOCALIZED = "localized";
    private static final String STRING = "String";
    private static final String ITEM_TYPE = "ITEM_TYPE";
    private static final String PROCESS_TYPE = "PROCESS_TYPE";
    private static final String ATTRIBUTE_HIDDEN_ANNOTATION_TEMPLATE = "%s @Common.FieldControl:#Hidden;";
    private static final String ATTIBUTE_ANNOTATION_TEXTONLY = "\t@Common: { Text: %s.name, TextArrangement: #TextOnly }";
    private static final String VALUE_LIST_WITH_FIXED_VALUES_ANNOTATION = "\t@Common.ValueListWithFixedValues: true";
    private static final String VALUE_LIST_FIXED_ANNOTATION = "\t@ValueList: {type: #fixed, entity: '%s'}";
    private static final String ALTKEY = "AltKey";
    private static final String CORE_MODEL = "CoreModel";
    private static final String ID = "id";
    private static final String TEXTS = "_texts";
    private static final String CAPACITIES_TEMPLATE = "\n\tCapabilities: {\n\tFilterRestrictions: {\n\t\tNonFilterableProperties: [\n\t\t\t%s\n\t\t]\n\t}\n\t}";
    private static final String PREFIX_OF_CODE_LIST_ENUM_KEY = "V_";
    private static final String TP_TRACKINGID_LABEL = "{Label : '{@i18n>EL_TrackedProcess_trackingId_LABEL}',Value :trackingId}";
    private  static final String TP_LOGICALSYSTEM_LABEL = "{Label : '{@i18n>EL_TrackedProcess_logicalSystem_LABEL}',Value :logicalSystem}";
    private static final String TP_LIFECYCLESTATUS_LABEL = "{Label : '{@i18n>EL_TrackedProcess_lifeCycleStatus_LABEL}',Value :lifeCycleStatus}";
    private static final String TP_PROCESSSTATUS_LABEL = "{Label : '{@i18n>EL_TrackedProcess_processStatus_LABEL}',Value :processStatus}";
    private static final String EVENT_ID_LABLE = "{Label : '{@i18n>EL_Event_id_LABEL}',Value :id}";
    private static final String EVENT_ACTUALBUSINESSTIMESTATMP_LABEL = "{Label : '{@i18n>EL_Event_actualBusinessTimestamp_LABEL}',Value :actualBusinessTimestamp}";
    private static final String EVENT_ACTUALBUSINESSSTIMEZONE_LABEL = "{Label : '{@i18n>EL_Event_actualBusinessTimeZone_LABEL}',Value :actualBusinessTimeZone}";
    private static final String EVENT_EVENTREASONTEXT_LABEL = "{Label : '{@i18n>EL_Event_eventReasonText_LABEL}',Value :eventReasonText}";

    static {
        //******************core model selection filed: ************************
        //tracked process:
        ArrayList<String> trackedProcessSelectionFiledList = new ArrayList();
        trackedProcessSelectionFiledList.add("altKey");
        trackedProcessSelectionFiledList.add("trackingId");
        trackedProcessSelectionFiledList.add("logicalSystem");
        trackedProcessSelectionFiledList.add("lifeCycleStatus");
        trackedProcessSelectionFiledList.add("processStatus");
        coreModelUISelectionFieldsMap.put(CORE_MODEL_TRACKEDPROCESS, trackedProcessSelectionFiledList);
        //planned event:
        ArrayList<String> plannedEventSelectionFiledList = new ArrayList();
        plannedEventSelectionFiledList.add("id");
        plannedEventSelectionFiledList.add("eventType");
        plannedEventSelectionFiledList.add("locationAltKey");
        plannedEventSelectionFiledList.add("eventMatchKey");
        plannedEventSelectionFiledList.add("eventStatus");
        coreModelUISelectionFieldsMap.put(CORE_MODEL_PLANNEDEVENT, plannedEventSelectionFiledList);

        //event
        ArrayList<String> eventSelectionFiledList = new ArrayList();
        eventSelectionFiledList.add("id");
        eventSelectionFiledList.add("eventType");
        eventSelectionFiledList.add("locationAltKey");
        eventSelectionFiledList.add("eventMatchKey");
        eventSelectionFiledList.add("actualBusinessTimestamp");
        coreModelUISelectionFieldsMap.put(CORE_MODEL_EVENT, eventSelectionFiledList);

        //QualifiedTrackingId
        ArrayList<String> qualifiedTrackingIdSelectionFieldList = new ArrayList();
        qualifiedTrackingIdSelectionFieldList.add("observedProcess.altKey");
        qualifiedTrackingIdSelectionFieldList.add(VALID_FROM);
        qualifiedTrackingIdSelectionFieldList.add("validTo");
        coreModelUISelectionFieldsMap.put(CORE_MODEL_QUALIFIED_TRACKING_ID, qualifiedTrackingIdSelectionFieldList);

        //Reference
        ArrayList<String> referenceSelectionFieldList = new ArrayList();
        referenceSelectionFieldList.add("id");
        referenceSelectionFieldList.add("event_id");
        referenceSelectionFieldList.add("referenceType");
        referenceSelectionFieldList.add("altKey");
        referenceSelectionFieldList.add(VALID_FROM);
        coreModelUISelectionFieldsMap.put(CORE_MODEL_REFERENCE, referenceSelectionFieldList);

        //******************core model line items ************************
        //tracked process:
        ArrayList<String> trackedProcessLineItemList = new ArrayList();
        trackedProcessLineItemList.add("{Label : '{@i18n>EL_TrackedProcess_altKey_LABEL}', Value : altKey}");
        trackedProcessLineItemList.add(TP_TRACKINGID_LABEL);
        trackedProcessLineItemList.add(TP_LOGICALSYSTEM_LABEL);

        trackedProcessLineItemList.add(TP_LIFECYCLESTATUS_LABEL);

        trackedProcessLineItemList.add(TP_PROCESSSTATUS_LABEL);
        trackedProcessLineItemList.add(LAST_CHANGED_BY_USER_LABEL);
        trackedProcessLineItemList.add(LAST_CHANGED_DATE_TIME_LABEL);
        coreModelUILineItemsMap.put(CORE_MODEL_TRACKEDPROCESS, trackedProcessLineItemList);

        //planned event:
        ArrayList<String> plannedEventLineItemList = new ArrayList();
        plannedEventLineItemList.add("{Label : '{@i18n>EL_PlannedEvent_id_LABEL}',Value :id}");
        plannedEventLineItemList.add("{Label : '{@i18n>EL_PlannedEvent_eventType_LABEL}',Value :eventType}");
        plannedEventLineItemList.add("{Label : '{@i18n>EL_PlannedEvent_locationAltKey_LABEL}',Value :locationAltKey}");
        plannedEventLineItemList.add("{Label : '{@i18n>EL_PlannedEvent_eventMatchKey_LABEL}',Value :eventMatchKey}");
        plannedEventLineItemList.add("{Label : '{@i18n>EL_PlannedEvent_eventStatus_LABEL}',Value :eventStatus}");
        plannedEventLineItemList.add("{Label : '{@i18n>EL_PlannedEvent_plannedBusinessTimestamp_LABEL}',Value :plannedBusinessTimestamp}");
        plannedEventLineItemList.add("{Label : '{@i18n>EL_PlannedEvent_plannedBusinessTimeZone_LABEL}',Value :plannedBusinessTimeZone}");
        coreModelUILineItemsMap.put(CORE_MODEL_PLANNEDEVENT, plannedEventLineItemList);

        //event
        ArrayList<String> eventLineItemList = new ArrayList();
        eventLineItemList.add(EVENT_ID_LABLE);
        eventLineItemList.add("{Label : '{@i18n>EL_Event_eventType_LABEL}',Value :eventType}");
        eventLineItemList.add("{Label : '{@i18n>EL_Event_locationAltKey_LABEL}',Value :locationAltKey}");
        eventLineItemList.add("{Label : '{@i18n>EL_Event_eventMatchKey_LABEL}',Value :eventMatchKey}");
        eventLineItemList.add(EVENT_ACTUALBUSINESSTIMESTATMP_LABEL);

        eventLineItemList.add(EVENT_ACTUALBUSINESSSTIMEZONE_LABEL);

        eventLineItemList.add(EVENT_EVENTREASONTEXT_LABEL);
        coreModelUILineItemsMap.put(CORE_MODEL_EVENT, eventLineItemList);

        //QualifiedTrackingId
        ArrayList<String> qualifiedTrackingIdLineItemList = new ArrayList();
        qualifiedTrackingIdLineItemList.add("{Label : '{@i18n>EL_QualifiedTrackingId_ObservedProcess_altKey_LABEL}', Value : observedProcess.altKey}");
        qualifiedTrackingIdLineItemList.add("{Label : '{@i18n>EL_QualifiedTrackingId_validFrom_LABEL}', Value : validFrom}");
        qualifiedTrackingIdLineItemList.add("{Label : '{@i18n>EL_QualifiedTrackingId_validTo_LABEL}', Value : validTo}");
        coreModelUILineItemsMap.put(CORE_MODEL_QUALIFIED_TRACKING_ID, qualifiedTrackingIdLineItemList);

        //Reference
        ArrayList<String> referenceLineItemList = new ArrayList();
        referenceLineItemList.add("{Label : '{@i18n>EL_Reference_id_LABEL}',Value : id}");
        referenceLineItemList.add("{Label : '{@i18n>EL_Reference_event_id_LABEL}',Value : event_id}");
        referenceLineItemList.add("{Label : '{@i18n>EL_Reference_referenceType_LABEL}',Value : referenceType}");
        referenceLineItemList.add("{Label : '{@i18n>EL_Reference_altKey_LABEL}',Value : altKey}");
        referenceLineItemList.add("{Label : '{@i18n>EL_Reference_validFrom_LABEL}',Value : validFrom}");
        referenceLineItemList.add("{Label : '{@i18n>EL_Reference_validTo_LABEL}',Value : validTo}");
        referenceLineItemList.add("{Label : '{@i18n>EL_Reference_action_LABEL}',Value : action}");
        coreModelUILineItemsMap.put(CORE_MODEL_REFERENCE, referenceLineItemList);

        //****************** filed group: ************************
        //tracked process:
        ArrayList<String> trackedProcessFieldGroupList = new ArrayList();
        trackedProcessFieldGroupList.add("{Label : '{@i18n>EL_TrackedProcess_altKey_LABEL}',Value :altKey}");
        trackedProcessFieldGroupList.add(TP_TRACKINGID_LABEL);
        trackedProcessFieldGroupList.add(TP_LOGICALSYSTEM_LABEL);
        trackedProcessFieldGroupList.add(TP_LIFECYCLESTATUS_LABEL);
        trackedProcessFieldGroupList.add(TP_PROCESSSTATUS_LABEL);
        trackedProcessFieldGroupList.add(LAST_CHANGED_BY_USER_LABEL);
        trackedProcessFieldGroupList.add(LAST_CHANGED_DATE_TIME_LABEL);
        trackedProcessFieldGroupList.add("{Label : '{@i18n>EL_TrackedProcess_id_LABEL}',Value :id}");
        trackedProcessFieldGroupList.add("{Label : '{@i18n>EL_TrackedProcess_subaccountId_LABEL}',Value :subaccountId}");
        trackedProcessFieldGroupList.add("{Label : '{@i18n>EL_TrackedProcess_cloneInstanceId_LABEL}',Value :cloneInstanceId}");
        trackedProcessFieldGroupList.add("{Label : '{@i18n>EL_TrackedProcess_trackedProcessType_LABEL}',Value :trackedProcessType}");
        trackedProcessFieldGroupList.add("{Label : '{@i18n>EL_TrackedProcess_scheme_LABEL}',Value :scheme}");
        trackedProcessFieldGroupList.add("{Label : '{@i18n>EL_TrackedProcess_partyId_LABEL}',Value :partyId}");
        trackedProcessFieldGroupList.add("{Label : '{@i18n>EL_TrackedProcess_trackingIdType_LABEL}',Value :trackingIdType}");
        trackedProcessFieldGroupList.add("{Label : '{@i18n>EL_TrackedProcess_lastChangedAtBusinessTime_LABEL}',Value :lastChangedAtBusinessTime}");
        trackedProcessFieldGroupList.add("{Label : '{@i18n>EL_TrackedProcess_createdByUser_LABEL}',Value :createdByUser}");
        trackedProcessFieldGroupList.add("{Label : '{@i18n>EL_TrackedProcess_creationDateTime_LABEL}',Value :creationDateTime}");
        trackedProcessFieldGroupList.add("{Label : '{@i18n>EL_TrackedProcess_version_LABEL}',Value :version}");
        coreModelUIFieldGroupsMap.put(CORE_MODEL_TRACKEDPROCESS, trackedProcessFieldGroupList);

        //event:
        ArrayList<String> eventFieldGroupList = new ArrayList();
        eventFieldGroupList.add(EVENT_ID_LABLE);
        eventFieldGroupList.add("{Label : '{@i18n>EL_Event_eventType_LABEL}',Value :eventType}");
        eventFieldGroupList.add("{Label : '{@i18n>EL_Event_locationAltKey_LABEL}',Value :locationAltKey}");
        eventFieldGroupList.add("{Label : '{@i18n>EL_Event_eventMatchKey_LABEL}',Value :eventMatchKey}");
        eventFieldGroupList.add(EVENT_ACTUALBUSINESSTIMESTATMP_LABEL);
        eventFieldGroupList.add(EVENT_ACTUALBUSINESSSTIMEZONE_LABEL);
        eventFieldGroupList.add(EVENT_EVENTREASONTEXT_LABEL);
        eventFieldGroupList.add("{Label : '{@i18n>EL_Event_subaccountId_LABEL}',Value :subaccountId}");
        eventFieldGroupList.add("{Label : '{@i18n>EL_Event_cloneInstanceId_LABEL}',Value :cloneInstanceId}");
        eventFieldGroupList.add("{Label : '{@i18n>EL_Event_modelNamespace_LABEL}',Value :modelNamespace}");
        eventFieldGroupList.add("{Label : '{@i18n>EL_Event_eventReasonCode_LABEL}',Value :eventReasonCode}");
        eventFieldGroupList.add("{Label : '{@i18n>EL_Event_senderPartyId_LABEL}',Value :senderPartyId}");
        eventFieldGroupList.add("{Label : '{@i18n>EL_Event_altKey_LABEL}',Value :altKey}");
        eventFieldGroupList.add("{Label : '{@i18n>EL_Event_scheme_LABEL}',Value :scheme}");
        eventFieldGroupList.add("{Label : '{@i18n>EL_Event_partyId_LABEL}',Value :partyId}");
        eventFieldGroupList.add("{Label : '{@i18n>EL_Event_logicalSystem_LABEL}',Value :logicalSystem}");
        eventFieldGroupList.add("{Label : '{@i18n>EL_Event_trackingIdType_LABEL}',Value :trackingIdType}");
        eventFieldGroupList.add("{Label : '{@i18n>EL_Event_trackingId_LABEL}',Value :trackingId}");
        eventFieldGroupList.add("{Label : '{@i18n>EL_Event_actualTechnicalTimestamp_LABEL}',Value :actualTechnicalTimestamp}");
        eventFieldGroupList.add("{Label : '{@i18n>EL_Event_longitude_LABEL}',Value :longitude}");
        eventFieldGroupList.add("{Label : '{@i18n>EL_Event_latitude_LABEL}',Value :latitude}");
        eventFieldGroupList.add("{Label : '{@i18n>EL_Event_messageSourceType_LABEL}',Value :messageSourceType}");
        eventFieldGroupList.add("{Label : '{@i18n>EL_Event_createdByUser_LABEL}',Value :createdByUser}");
        eventFieldGroupList.add("{Label : '{@i18n>EL_Event_creationDateTime_LABEL}',Value :creationDateTime}");
        eventFieldGroupList.add("{Label : '{@i18n>EL_Event_reportedBy_LABEL}',Value :reportedBy}");
        coreModelUIFieldGroupsMap.put(CORE_MODEL_EVENT, eventFieldGroupList);

        //QualifiedTrackingId:
        ArrayList<String> qualifiedTrackingIdFieldGroupList = new ArrayList();
        qualifiedTrackingIdFieldGroupList.add("{Label : '{@i18n>EL_QualifiedTrackingId_observedProcess.altKey_LABEL}', Value : observedProcess.altKey}");
        qualifiedTrackingIdFieldGroupList.add("{Label : '{@i18n>EL_QualifiedTrackingId_validFrom_LABEL}',Value : validFrom}");
        qualifiedTrackingIdFieldGroupList.add("{Label : '{@i18n>EL_QualifiedTrackingId_validTo_LABEL}',Value : validTo}");
        coreModelUIFieldGroupsMap.put(CORE_MODEL_QUALIFIED_TRACKING_ID, qualifiedTrackingIdFieldGroupList);

        //Reference
        ArrayList<String> referenceFieldGroupList = new ArrayList();
        referenceFieldGroupList.add("{Label : '{@i18n>EL_Reference_id_LABEL}',Value :id}");
        referenceFieldGroupList.add("{Label : '{@i18n>EL_Reference_event_id_LABEL}',Value :event_id}");
        referenceFieldGroupList.add("{Label : '{@i18n>EL_Reference_referenceType_LABEL}',Value :referenceType}");
        referenceFieldGroupList.add("{Label : '{@i18n>EL_Reference_altKey_LABEL}',Value :altKey}");
        referenceFieldGroupList.add("{Label : '{@i18n>EL_Reference_validFrom_LABEL}',Value :validFrom}");
        referenceFieldGroupList.add("{Label : '{@i18n>EL_Reference_validTo_LABEL}',Value :validTo}");
        referenceFieldGroupList.add("{Label : '{@i18n>EL_Reference_action_LABEL}',Value : action}");
        coreModelUIFieldGroupsMap.put(CORE_MODEL_REFERENCE, referenceFieldGroupList);

        //******************core model filed group: ************************
        //tracked process:
        ArrayList<String> coreModeltrackedProcessFieldGroupList = new ArrayList();
        coreModeltrackedProcessFieldGroupList.add(TP_TRACKINGID_LABEL);
        coreModeltrackedProcessFieldGroupList.add(TP_LOGICALSYSTEM_LABEL);
        coreModeltrackedProcessFieldGroupList.add(TP_LIFECYCLESTATUS_LABEL);
        coreModeltrackedProcessFieldGroupList.add(TP_PROCESSSTATUS_LABEL);
        coreModeltrackedProcessFieldGroupList.add(LAST_CHANGED_BY_USER_LABEL);
        coreModeltrackedProcessFieldGroupList.add(LAST_CHANGED_DATE_TIME_LABEL);
        coreModeltrackedProcessFieldGroupList.add("{Label : '{@i18n>EL_TrackedProcess_id_LABEL}',Value :id}");
        coreModeltrackedProcessFieldGroupList.add("{Label : '{@i18n>EL_TrackedProcess_subaccountId_LABEL}',Value :subaccountId}");
        coreModeltrackedProcessFieldGroupList.add("{Label : '{@i18n>EL_TrackedProcess_cloneInstanceId_LABEL}',Value :cloneInstanceId}");
        coreModeltrackedProcessFieldGroupList.add("{Label : '{@i18n>EL_TrackedProcess_trackedProcessType_LABEL}',Value :trackedProcessType}");
        coreModeltrackedProcessFieldGroupList.add("{Label : '{@i18n>EL_TrackedProcess_scheme_LABEL}',Value :scheme}");
        coreModeltrackedProcessFieldGroupList.add("{Label : '{@i18n>EL_TrackedProcess_partyId_LABEL}',Value :partyId}");
        coreModeltrackedProcessFieldGroupList.add("{Label : '{@i18n>EL_TrackedProcess_trackingIdType_LABEL}',Value :trackingIdType}");
        coreModeltrackedProcessFieldGroupList.add("{Label : '{@i18n>EL_TrackedProcess_lastChangedAtBusinessTime_LABEL}',Value :lastChangedAtBusinessTime}");
        coreModeltrackedProcessFieldGroupList.add("{Label : '{@i18n>EL_TrackedProcess_createdByUser_LABEL}',Value :createdByUser}");
        coreModeltrackedProcessFieldGroupList.add("{Label : '{@i18n>EL_TrackedProcess_creationDateTime_LABEL}',Value :creationDateTime}");
        coreModeltrackedProcessFieldGroupList.add("{Label : '{@i18n>EL_TrackedProcess_version_LABEL}',Value :version}");

        newCoreModelUIFieldGroupMap.put(CORE_MODEL_TRACKEDPROCESS, coreModeltrackedProcessFieldGroupList);

        //event:
        ArrayList<String> coreModelventFieldGroupList = new ArrayList();
        coreModelventFieldGroupList.add(EVENT_ID_LABLE);
        coreModelventFieldGroupList.add(EVENT_ACTUALBUSINESSTIMESTATMP_LABEL);
        coreModelventFieldGroupList.add(EVENT_ACTUALBUSINESSSTIMEZONE_LABEL);
        coreModelventFieldGroupList.add(EVENT_EVENTREASONTEXT_LABEL);
        coreModelventFieldGroupList.add("{Label : '{@i18n>EL_Event_subaccountId_LABEL}',Value :subaccountId}");
        coreModelventFieldGroupList.add("{Label : '{@i18n>EL_Event_cloneInstanceId_LABEL}',Value :cloneInstanceId}");
        coreModelventFieldGroupList.add("{Label : '{@i18n>EL_Event_modelNamespace_LABEL}',Value :modelNamespace}");
        coreModelventFieldGroupList.add("{Label : '{@i18n>EL_Event_eventReasonCode_LABEL}',Value :eventReasonCode}");
        coreModelventFieldGroupList.add("{Label : '{@i18n>EL_Event_senderPartyId_LABEL}',Value :senderPartyId}");
        coreModelventFieldGroupList.add("{Label : '{@i18n>EL_Event_altKey_LABEL}',Value :altKey}");
        coreModelventFieldGroupList.add("{Label : '{@i18n>EL_Event_scheme_LABEL}',Value :scheme}");
        coreModelventFieldGroupList.add("{Label : '{@i18n>EL_Event_partyId_LABEL}',Value :partyId}");
        coreModelventFieldGroupList.add("{Label : '{@i18n>EL_Event_logicalSystem_LABEL}',Value :logicalSystem}");
        coreModelventFieldGroupList.add("{Label : '{@i18n>EL_Event_trackingIdType_LABEL}',Value :trackingIdType}");
        coreModelventFieldGroupList.add("{Label : '{@i18n>EL_Event_trackingId_LABEL}',Value :trackingId}");
        coreModelventFieldGroupList.add("{Label : '{@i18n>EL_Event_actualTechnicalTimestamp_LABEL}',Value :actualTechnicalTimestamp}");
        coreModelventFieldGroupList.add("{Label : '{@i18n>EL_Event_longitude_LABEL}',Value :longitude}");
        coreModelventFieldGroupList.add("{Label : '{@i18n>EL_Event_latitude_LABEL}',Value :latitude}");
        coreModelventFieldGroupList.add("{Label : '{@i18n>EL_Event_messageSourceType_LABEL}',Value :messageSourceType}");
        coreModelventFieldGroupList.add("{Label : '{@i18n>EL_Event_createdByUser_LABEL}',Value :createdByUser}");
        coreModelventFieldGroupList.add("{Label : '{@i18n>EL_Event_creationDateTime_LABEL}',Value :creationDateTime}");
        coreModelventFieldGroupList.add("{Label : '{@i18n>EL_Event_reportedBy_LABEL}',Value :reportedBy}");
        newCoreModelUIFieldGroupMap.put(CORE_MODEL_EVENT, eventFieldGroupList);

        //panned event
        ArrayList<String> coreModelplannedEventFieldGroupList = new ArrayList();
        coreModelplannedEventFieldGroupList.add("{Label : '{@i18n>EL_PlannedEvent_id_LABEL}',Value :id}");
        coreModelplannedEventFieldGroupList.add("{Label : '{@i18n>EL_PlannedEvent_eventStatus _LABEL}',Value :eventStatus }");
        coreModelplannedEventFieldGroupList.add("{Label : '{@i18n>EL_PlannedEvent_plannedBusinessTimestamp_LABEL}',Value :plannedBusinessTimestamp }");
        coreModelplannedEventFieldGroupList.add("{Label : '{@i18n>EL_PlannedEvent_plannedBusinessTimeZone_LABEL}',Value :plannedBusinessTimeZone }");
        coreModelplannedEventFieldGroupList.add("{Label : '{@i18n>EL_PlannedEvent_longitude_LABEL}',Value :longitude }");
        coreModelplannedEventFieldGroupList.add("{Label : '{@i18n>EL_PlannedEvent_latitude_LABEL}',Value :latitude }");
        coreModelplannedEventFieldGroupList.add("{Label : '{@i18n>EL_PlannedEvent_payloadSequence_LABEL}',Value :payloadSequence }");
        coreModelplannedEventFieldGroupList.add("{Label : '{@i18n>EL_PlannedEvent_isFinalPlannedEvent_LABEL}',Value :isFinalPlannedEvent }");
        coreModelplannedEventFieldGroupList.add("{Label : '{@i18n>EL_PlannedEvent_nextOverdueDetection_LABEL}',Value :nextOverdueDetection }");
        coreModelplannedEventFieldGroupList.add("{Label : '{@i18n>EL_PlannedEvent_overdueDetectionCounter_LABEL}',Value :overdueDetectionCounter }");
        coreModelplannedEventFieldGroupList.add("{Label : '{@i18n>EL_PlannedEvent_process_id_LABEL}',Value :process_id }");
        coreModelplannedEventFieldGroupList.add("{Label : '{@i18n>EL_PlannedEvent_Process_altKey_LABEL}',Value :process.altKey }");
        coreModelplannedEventFieldGroupList.add("{Label : '{@i18n>EL_PlannedEvent_plannedTechnicalTimestamp_LABEL}',Value :plannedTechnicalTimestamp }");
        coreModelplannedEventFieldGroupList.add("{Label : '{@i18n>EL_PlannedEvent_plannedTechTsEarliest_LABEL}',Value :plannedTechTsEarliest }");
        coreModelplannedEventFieldGroupList.add("{Label : '{@i18n>EL_PlannedEvent_plannedBizTsEarliest_LABEL}',Value :plannedBizTsEarliest }");
        coreModelplannedEventFieldGroupList.add("{Label : '{@i18n>EL_PlannedEvent_plannedBizTsLatest_LABEL}',Value :plannedBizTsLatest }");
        newCoreModelUIFieldGroupMap.put(CORE_MODEL_EVENT, coreModelplannedEventFieldGroupList);
    }


    public static Map<String, String> generateCdsModelInfo(String jsonModel) {
        DraftModelBean draftModelBean = JsonModelConverter.convertJsonToModelBean(jsonModel);
        Map<String, String> cdsFileInfo = generateCdsModelInfo(draftModelBean);
        Map<String, String> readServiceFileInfo = generateCdsInfoForReadService(draftModelBean);
        Map<String, String> writeServiceFileInfo = generateCdsInfoForWriteService(draftModelBean);
        Map<String, String> uiFileInfo = generateCdsInfoForUIAnnotation(draftModelBean);
        Map<String, String> i18nFileInfo = generateI18nModelInfo(draftModelBean);
        Map<String, String> packageInfo = generatePackageInfo(draftModelBean);
        Map<String, String> allCdsFileInfo = new HashMap();
        Map<String, String> customDraftMdoel = getCusomJsonModel(jsonModel);
        Map<String, String> eventToActionMap = getEventToActionJson(jsonModel);
        allCdsFileInfo.putAll(cdsFileInfo);
        allCdsFileInfo.putAll(readServiceFileInfo);
        allCdsFileInfo.putAll(writeServiceFileInfo);
        allCdsFileInfo.putAll(i18nFileInfo);
        allCdsFileInfo.putAll(uiFileInfo);
        allCdsFileInfo.putAll(packageInfo);
        allCdsFileInfo.putAll(customDraftMdoel);
        allCdsFileInfo.putAll(eventToActionMap);
        return allCdsFileInfo;
    }

    private static Map<String, String> getCusomJsonModel(String jsonModel) {
        Map<String, String> customModelMap = new HashMap();
        JsonObject tempModelBean = JsonUtils.generateJsonObjectFromJsonString(jsonModel);
        String customModel = tempModelBean.get(CUSTOMMODEL).toString();
        customModelMap.put(DRAFT_MODEL_CUSTOM_FILE, customModel);
        return customModelMap;
    }

    private static Map<String, String> getEventToActionJson(String jsonModel) {
        Map<String, String> eventToActionMap = new HashMap();
        JsonObject tempModelBean = JsonUtils.generateJsonObjectFromJsonString(jsonModel);
        JsonObject customModel = tempModelBean.get(CUSTOMMODEL).getAsJsonObject();
        if (customModel.has(EVENT_TO_ACTION)) {
            String eventToActionInfo = customModel.get(EVENT_TO_ACTION).getAsString();
            eventToActionMap.put(EVENT_TO_ACTION_SCRIPT, eventToActionInfo);
        }
        return eventToActionMap;
    }

    private static Map<String, String> generateI18nModelInfo(DraftModelBean draftModelBean) {
        Map<String, String> i18nModelInfoMap = new HashMap();
        Map<String, Map<String, String>> i18nFileInfo = draftModelBean.getI18nFileInfo();
        Set<String> fileNames = i18nFileInfo.keySet();
        for (String fileName : fileNames) {
            Map<String, String> i18nContentMap = i18nFileInfo.get(fileName);
            String fileContent = createI18nFileContent(i18nContentMap);
            i18nModelInfoMap.put(fileName, fileContent);
        }
        return i18nModelInfoMap;
    }

    private static String createI18nFileContent(Map<String, String> i18nContentMap) {
        StringBuilder sb = new StringBuilder();
        if (i18nContentMap != null) {
            for (Map.Entry<String, String> entry : i18nContentMap.entrySet()) {
                String key = entry.getKey();
                String value = entry.getValue();
                sb.append(String.format(I18N_FILE_CONTENT, key, value));
            }
        }
        return sb.toString();
    }


    public static Map<String, String> generateCdsModelInfo(DraftModelBean draftModel) {
        Map<String, String> returnMap = new HashMap();
        String namespace = draftModel.getNamespace();
        List<SubModelsBean> subModels = draftModel.getSubModels();
        Map<String, Set<ItemTypeEntity>> itemTypeEntityMap = draftModel.getItemTypeEntityInfoMap();
        Map<String, Set<CodeListValue>> codeListValueInfoMap = draftModel.getCodeListValueInfoMap();
        subModels.stream().forEach(e -> {
            StringBuilder cdsFileSb = new StringBuilder();
            String subModelName = e.getName();
            Set<ItemTypeEntity> itemTypeEntities = itemTypeEntityMap.get(subModelName);

            cdsFileSb.append(applyGeneralCdsStatementTemplate(NAMESPACE, SPACE, namespace, SEMICOLON)).append(NEWLINE)
                    .append(getUsingScript(namespace, e, draftModel)).append(NEWLINE);
            List<String> subModelAnnotations = e.getAnnotations();
            for (String annotation : subModelAnnotations) {
                cdsFileSb.append(annotation).append(NEWLINE);
            }
            cdsFileSb.append(applyGeneralCdsStatementTemplate(CONTEXT, SPACE, subModelName, LEFT_BRACE));
            List<ProcessTypeEntity> processTypeEntities = e.getProcessTypes();
            //tracked process entity
            String processEntityScript = createEntitiesScript(processTypeEntities);
            // events entities:
            List eventTypeEntities = e.getEventTypes();
            String eventEntityScript = createEntitiesScript(eventTypeEntities);
            //item entities:
            List<ItemTypeEntity> itemTypeEntyList = new ArrayList();
            if (itemTypeEntities != null && !itemTypeEntities.isEmpty()) {
                itemTypeEntyList.addAll(itemTypeEntities);
            }
            String itemTypeEntityForProcessScript = createEntitiesScript(itemTypeEntyList);
            //code list entities:
            List<CodeListEntity> codeListEntities = e.getCodeLists();
            String codeListEntityScript = createEntitiesScript(codeListEntities);

            //forWrite entities:
            List<BaseEntity> forWriteEntities = e.getForWriteEntities();
            String forWriteScript = createForWriteEntitiesScript(codeListValueInfoMap, forWriteEntities);
            cdsFileSb.append(processEntityScript)
                    .append(eventEntityScript)
                    .append(itemTypeEntityForProcessScript)
                    .append(codeListEntityScript)
                    .append(forWriteScript)
                    .append(NEWLINE).append(RIGHT_BRACE).append(SEMICOLON);
            String cdsFileName = subModelName.concat(DOT_CDS);
            returnMap.put(cdsFileName, cdsFileSb.toString());
        });
        return returnMap;
    }

    private static String getUsingScript(String nameSpace, SubModelsBean subModelsBean, DraftModelBean draftModelBean) {
        String subModelName = subModelsBean.getName();
        StringBuilder sb = new StringBuilder();
        Map<String, Set<String>> usingEntityNameMap = draftModelBean.getUsingEntityNameMap();
        if (usingEntityNameMap.get(subModelName) != null) {
            Set<String> usingEntityNameSet = usingEntityNameMap.get(subModelName);
            for (String usingEntityName : usingEntityNameSet) {
                if (usingEntityName.equalsIgnoreCase(CORE_MODEL_NAMESPACE)) {
                    sb.append(applyGeneralCdsStatementTemplate(USING, SPACE, CORE_MODEL_NAMESPACE, SEMICOLON)).append(NEWLINE);
                } else {
                    String usingEntityFullName = "";
                    usingEntityFullName = nameSpace + DOT + usingEntityName + SPACE + AS + SPACE + usingEntityName + ALIAS;
                    sb.append(applyGeneralCdsStatementTemplate(USING, SPACE, usingEntityFullName, SEMICOLON)).append(NEWLINE);
                }
            }
        }
        return sb.toString();

    }

    private static String createForWriteEntitiesScript(Map<String, Set<CodeListValue>> codeListValueInfoMap, List<BaseEntity> forWriteEntities) {
        StringBuilder forWriteEntitySb = new StringBuilder("");
        for (BaseEntity forWriteEntity : forWriteEntities) {
            String entityName = forWriteEntity.getName();
            //process entity annotations:
            forWriteEntitySb.append(TAB).append(ENTITY).append(SPACE).append(entityName);
            //processEntity and it's elements:
            List<BaseEntity> parentEntities = forWriteEntity.getParent();
            buildParent(forWriteEntitySb, parentEntities);
            List<EntityElement> writeEntityElements = forWriteEntity.getElements();
            //deal with code list enum values:
            String codeListEnumValueScript = getCodeListEnumValueScript(codeListValueInfoMap, writeEntityElements);
            List<EntityElement> nonCodeListElements = getNonCodeListElement(writeEntityElements);
            String attributesScript = createAttributesScript(nonCodeListElements, Boolean.FALSE);
            forWriteEntitySb.append(LEFT_BRACE).append(NEWLINE);
            if (StringUtils.isNotBlank(codeListEnumValueScript)) {
                forWriteEntitySb.append(codeListEnumValueScript);
            }
            forWriteEntitySb.append(attributesScript);
            forWriteEntitySb.append(RIGHT_BRACE).append(NEWLINE);
        }
        return forWriteEntitySb.toString();
    }

    private static List<EntityElement> getNonCodeListElement(List<EntityElement> entityElements) {
        List<EntityElement> nonCodeListElement = new ArrayList();
        for (EntityElement entityElement : entityElements) {
            if (!entityElement.getType().equalsIgnoreCase(CODE_LIST)) {
                nonCodeListElement.add(entityElement);
            }
        }
        return nonCodeListElement;
    }

    private static String getCodeListEnumValueScript(Map<String, Set<CodeListValue>> codeListValueInfoMap, List<EntityElement> forWriteEntityElements) {
        ArrayList<String> codeListEnumInfoList = new ArrayList();
        if (!codeListValueInfoMap.isEmpty()) {
            for (EntityElement forWriteEntityElement : forWriteEntityElements) {
                if (forWriteEntityElement.getType().equalsIgnoreCase(CODE_LIST)) {
                    String codeListEnumInfo = getCodeListEnumInfoScript(forWriteEntityElement, codeListValueInfoMap);
                    if (StringUtils.isNotBlank(codeListEnumInfo)) {
                        codeListEnumInfoList.add(codeListEnumInfo);
                    }
                }
            }
        }
        if (!codeListEnumInfoList.isEmpty()) {
            return StringUtils.join(codeListEnumInfoList, NEWLINE);
        }
        return "";
    }

    private static String getCodeListEnumInfoScript(EntityElement forWriteEntityElement, Map<String, Set<CodeListValue>> codeListValueInfoMap) {
        StringBuilder sb = new StringBuilder("");
        String target = forWriteEntityElement.getTarget();
        Set<CodeListValue> codeListValues = codeListValueInfoMap.get(target);
        if (!codeListValues.isEmpty()) {
            String enumName = forWriteEntityElement.getName() + "_code";
            sb.append(TAB + String.format(ENUM_TEMPLATE, enumName));
            for (CodeListValue codeListValue : codeListValues) {
                String code = codeListValue.getCode();
                String key = PREFIX_OF_CODE_LIST_ENUM_KEY + code;
                sb.append(String.format(ENUM_KEY_VALUE_TEMPLATE, key,code)).append(NEWLINE);
            }
            String defaultValue = forWriteEntityElement.getDefaultValue();
            if (StringUtils.isNotBlank(defaultValue)) {
                sb.append(String.format(CODE_LIST_DEFAULT_TEMPLATE, defaultValue)).append(NEWLINE);
            } else {
                sb.append(TAB).append(RIGHT_BRACE).append(SEMICOLON).append(NEWLINE);
            }
        }
        return sb.toString();
    }


    private static String createEntitiesScript(List entities) {
        StringBuilder entitySb = new StringBuilder("");
        for (Object obj : entities) {
            BaseEntity entity = (BaseEntity) obj;
            String entityName = entity.getName();
            List<String> annotations = entity.getAnnotations();
            if (annotations != null) {
                for (String annotation : annotations) {
                    entitySb.append(TAB).append(annotation).append(NEWLINE);
                }
            }
            //entity annotations:
            entitySb.append(TAB).append(ENTITY).append(SPACE).append(entityName);
            //entity and it's elements:
            List<BaseEntity> parentEntities = entity.getParent();
            buildParent(entitySb, parentEntities);
            entitySb.append(LEFT_BRACE).append(NEWLINE);
            List<EntityElement> entityElements = entity.getElements();
            String attributesScript = createAttributesScript(entityElements, Boolean.TRUE);
            entitySb.append(attributesScript);
            entitySb.append(TAB).append(RIGHT_BRACE).append(SEMICOLON).append(NEWLINE).append(NEWLINE);
        }
        return entitySb.toString();
    }

    private static void buildParent(StringBuilder sb, List<BaseEntity> parentEntities) {
        if (parentEntities != null && !parentEntities.isEmpty()) {
            sb.append(COLON);
            int size = parentEntities.size();
            for (int i = 0; i < size; i++) {
                BaseEntity parentEntity = parentEntities.get(i);
                if (StringUtils.isNotBlank(parentEntity.getName())) {
                    sb.append(parentEntity.getName());
                }
                if (i < size - 1) {
                    sb.append(COMMA);
                }
            }
        }
    }

    private static String createAttributesScript(List<EntityElement> entityElements, boolean isCodeListEntityElement) {
        StringBuilder entityElementsSb = new StringBuilder();
        entityElements.stream().forEach(e -> {
            StringBuilder sb = new StringBuilder("");
            String attributeName = e.getName();
            List<String> attributeAnnotations = e.getAnnotations();
            if (!attributeAnnotations.isEmpty()) {
                for (String annotation : attributeAnnotations) {
                    sb.append(TAB).append(annotation).append(NEWLINE);
                }
            }
            int length = e.getLength();
            int precision = e.getPrecision();
            int scale = e.getScale();
            String type = e.getType();
            boolean isKey = e.isKey();
            boolean isNotNull = e.isNotNull();
            boolean isLocalized = e.isLocalized();
            sb.append(TAB);
            appendPrimaryKey(sb, isKey, KEY);
            if (type.equalsIgnoreCase(CODE_LIST)) {
                dealWithCodeListTypeAttribute(e, sb);
            } else if (isCodeListEntityElement && type.equalsIgnoreCase(STRING)) {
                sb.append(attributeName)
                        .append(COLON_WITHSPACE);
                appendLocalized(sb, isLocalized, type);
                sb.append(StringUtils.capitalize(type));
            } else {
                sb.append(attributeName)
                        .append(COLON_WITHSPACE)
                        .append(StringUtils.capitalize(type));
            }
            String compositionOrAssociationStr = getCompositionOrAssociationAttributeStr(e);
            sb.append(compositionOrAssociationStr);
            appendLength(sb, length);
            if (scale > 0) {
                sb.append(LEFT_PARENTTHESIS).append(precision).append(COMMA).append(scale).append(RIGHT_PARENTTHESIS);
            }
            if (isNotNull) {
                sb.append(SPACE).append(NOT_NULL);
            }
            sb.append(SEMICOLON).append(NEWLINE);
            entityElementsSb.append(sb.toString());
        });
        return entityElementsSb.toString();
    }

    private static void dealWithCodeListTypeAttribute(EntityElement entityElement, StringBuilder sb) {
        String codeListTargetEntity = entityElement.getTargetEntityName();
        String codeListTargetModel = entityElement.getTargetModelName();
        String codeListTargetFullName = codeListTargetEntity;
        String attributeName = entityElement.getName();
        if (StringUtils.isNotBlank(codeListTargetModel)) {
            codeListTargetFullName = codeListTargetModel + DOT + codeListTargetFullName;
        }
        sb.append(String.format(CODE_LIST_ATTRIBUTE_TEMPLATE, attributeName, codeListTargetFullName));
    }

    private static void appendLength(StringBuilder sb, int length) {
        if (length > 0) {
            sb.append(LEFT_PARENTTHESIS).append(length).append(RIGHT_PARENTTHESIS);
        }
    }


    private static void appendPrimaryKey(StringBuilder sb, boolean isKey, String key) {
        if (isKey) {
            sb.append(key).append(SPACE);
        }
    }

    private static void appendLocalized(StringBuilder sb, boolean isLocalized, String type) {
        if (isLocalized && type.equalsIgnoreCase(STRING)) {
            sb.append(LOCALIZED).append(SPACE);
        }
    }

    private static String getCompositionOrAssociationAttributeStr(EntityElement entityElement) {
        StringBuilder sb = new StringBuilder("");
        if (entityElement.getType().equalsIgnoreCase(COMPOSITION) || entityElement.getType().equalsIgnoreCase(ASSOCIATION)) {
            ElementCardinality cardinality = entityElement.getCardinality();
            if (cardinality != null) {
                String max = cardinality.getMax();
                if (max.equals(STAR)) {
                    sb.append(SPACE)
                            .append(OF_MANY);
                } else if (max.endsWith(ONE)) {
                    sb.append(SPACE)
                            .append(TO_ONE);
                }
            }
            String targetEntityName = entityElement.getTargetEntityName();
            String targetModelName = entityElement.getTargetModelName();
            sb.append(SPACE);
            if (StringUtils.isNotBlank(targetModelName)) {
                sb.append(targetModelName).append(DOT);
            }
            if (StringUtils.isNotBlank(targetEntityName)) {
                sb.append(targetEntityName);
            }
            Set<String> targetOnInfoSet = entityElement.getTargetOnInfo();
            String targetOnInfoStr = StringUtils.join(targetOnInfoSet, " ");
            if (StringUtils.isNotBlank(targetOnInfoStr)) {
                sb.append(SPACE).append(ON).append(SPACE);
                sb.append(targetOnInfoStr);
            }

        }
        return sb.toString();
    }

    private static String applyGeneralCdsStatementTemplate(String key, String seperator, String value, String endCharactor) {
        return new StringBuilder(key)
                .append(seperator)
                .append(value)
                .append(SPACE)
                .append(endCharactor)
                .append(NEWLINE).toString();
    }

    private static Map<String, String> generateCdsInfoForReadService(DraftModelBean draftModel) {
        return generateCdsInfoService(draftModel, true);
    }

    private static Map<String, String> generateCdsInfoForWriteService(DraftModelBean draftModel) {
        return generateCdsInfoService(draftModel, false);
    }

    private static Map<String, String> generateCdsInfoService(DraftModelBean draftModel, boolean isForReadService) {
        Map<String, String> returnMap = new HashMap();
        String namespace = draftModel.getNamespace();
        String serviceName = draftModel.getName();
        Map<String, Set<ItemTypeEntity>> itemTypeEntityMap = draftModel.getItemTypeEntityInfoMap();
        String serviceTemplate;
        String fileName;
        if (isForReadService) {
            fileName = serviceName + SERVICE;
            serviceTemplate = getTemplateFile(READ_SERVICE_TEMPLATE_FILE);
        } else {
            //write service:
            fileName = serviceName + WRITE_SERVICE;
            serviceName += WRITE_SERVICE;
            serviceTemplate = getTemplateFile(WRITE_SERVICE_TEMPLATE_FILE);
        }
        List<SubModelsBean> subModels = draftModel.getSubModels();
        StringBuilder subModelUsingBuider = new StringBuilder();
        StringBuilder customServiceInfoBuilder = new StringBuilder();
        for (SubModelsBean subModelBean : subModels) {
            String subModelName = subModelBean.getName();
            Set<ItemTypeEntity> itemTypeEntitySet = itemTypeEntityMap.get(subModelName);
            List<BaseEntity> entities = getEntitiesForService(itemTypeEntitySet, subModelBean, isForReadService);
            String subModelNameAlias = subModelName + ALIAS;
            //add codelist entities for read service:
            List<CodeListEntity> codeListEntities = subModelBean.getCodeLists();
            String customServiceEntityInfo = generateScriptForService(subModelNameAlias, entities, isForReadService, codeListEntities);
            subModelUsingBuider.append(USING + " " + namespace + DOT + subModelName
                    + " as " + subModelNameAlias + ";" + NEWLINE);
            customServiceInfoBuilder.append(customServiceEntityInfo);
        }
        String cdsInfo = String.format(serviceTemplate, namespace, subModelUsingBuider.toString()
                , serviceName, customServiceInfoBuilder.toString());
        returnMap.put(fileName.concat(".cds"), cdsInfo);
        return returnMap;
    }

    private static List<BaseEntity> getEntitiesForService(Set<ItemTypeEntity> itemTypeEntitySet, SubModelsBean subModelBean, boolean isForReadService) {
        List<BaseEntity> entities = new ArrayList();
        List<ProcessTypeEntity> processTypeEntities = subModelBean.getProcessTypes();
        List<ItemTypeEntity> itemTypeEntities = new ArrayList();
        if (itemTypeEntitySet != null && !itemTypeEntitySet.isEmpty()) {
            itemTypeEntities.addAll(itemTypeEntitySet);
        }
        List<EventTypeEntity> eventTypeEntities = subModelBean.getEventTypes();
        if (isForReadService) {
            entities.addAll(processTypeEntities);
            entities.addAll(itemTypeEntities);
            entities.addAll(eventTypeEntities);
        } else {
            //write service:
            entities.addAll(eventTypeEntities);
            for (ItemTypeEntity itemTypeEntity : itemTypeEntities) {
                if (itemTypeEntity.getName().contains(EVENT)) {
                    entities.add(itemTypeEntity);
                }
            }
        }
        return entities;
    }


    private static String getTemplateFile(String templateFileName) {
        String templateFileContent;
        try (InputStream writeServiceTemplateStream = CdsInfoGenerator.class.getClassLoader()
                .getResourceAsStream(templateFileName)) {
            templateFileContent = IOUtils.toString(writeServiceTemplateStream, Charset.defaultCharset());
        } catch (IOException e) {
            throw new CdsInfoGeneratorException(e.getMessage(), e, CdsInfoGeneratorException.MESSAGE_CODE_ERROR_FIND_TEMPLATE_FILE_FAILED, new Object[]{templateFileName});
        }
        return templateFileContent;
    }

    private static String generateScriptForService(String subModelName, List entities, boolean isForReadService, List<CodeListEntity> codeListEntities) {
        StringBuilder entitySb = new StringBuilder("");
        for (Object obj : entities) {
            BaseEntity baseEntity = (BaseEntity) obj;
            String entityType = baseEntity.getEntityType();
            String entityName = baseEntity.getName();

            List<EntityElement> entityElements = baseEntity.getElements();
            Set<String> excludeAttributes = getExcludeAttributesOfTheEntity(entityElements, isForReadService);
            if (!isForReadService) {
                boolean hascoreModelParents = hasCoreModelParents(baseEntity);
                if (hascoreModelParents) {
                    excludeAttributes.add(ID);
                }
            }
            entitySb.append(createServiceScript(entityName, entityType, subModelName, excludeAttributes, isForReadService)).append(NEWLINE).append(TAB);
        }
        if (isForReadService) {
            for (CodeListEntity codeListEntity : codeListEntities) {
                String codeListEntityName = codeListEntity.getName();
                generateCodeListReadServiceProjection(codeListEntityName, subModelName, entitySb);
                generateCodeListReadServiceProjection(codeListEntityName + TEXTS, subModelName, entitySb);
            }
        }
        return entitySb.toString();
    }

    private static void generateCodeListReadServiceProjection(String codeListEntityName, String subModelName, StringBuilder entitySb) {
        String projectionStr = String.format(READ_SERVICE_ENTITY_TEMPLATE, codeListEntityName, subModelName, codeListEntityName);
        entitySb.append(projectionStr).append(SEMICOLON);
        entitySb.append(NEWLINE).append(TAB);
    }

    private static boolean hasCoreModelParents(BaseEntity baseEntity) {
        boolean hasCoreModelParents = false;
        List<BaseEntity> parentEntities = baseEntity.getParent();
        for (BaseEntity parentEntity : parentEntities) {
            String parentEntityName = parentEntity.getName();
            int indexOfDot = parentEntityName.indexOf(DOT);
            if (indexOfDot > 0) {
                String name = parentEntityName.substring(0, indexOfDot);
                if (name.equalsIgnoreCase(CORE_MODEL)) {
                    hasCoreModelParents = true;
                }
            }
        }
        return hasCoreModelParents;
    }


    private static Set<String> getExcludeAttributesOfTheEntity(List<EntityElement> entityElements, boolean isForReadService) {
        Set<String> excludeAttributes = new HashSet();
        for (EntityElement entityElement : entityElements) {
            if ((!isForReadService && !entityElement.isWritable()) || (isForReadService && !entityElement.isReadable())) {
                excludeAttributes.add(entityElement.getName());
            }
        }
        return excludeAttributes;
    }


    private static String createServiceScript(String entityName, String entityType, String subModelName, Set<String> excludeAttributes, boolean isForReadService) {
        StringBuilder sb = new StringBuilder("");
        String projectionEntity = entityName;
        //for the write service cds, the item entities defined in the write service should not end with ForWrite.
        if (!isForReadService && !entityType.equalsIgnoreCase(ITEM_TYPE)) {
            projectionEntity = entityName + "ForWrite";
        }
        String projectionStr = String.format(READ_SERVICE_ENTITY_TEMPLATE, entityName, subModelName, projectionEntity);
        if (isForReadService) {
            StringBuilder sbTemp = new StringBuilder(READ_ONLY_ANNOTATION).append(NEWLINE);
            projectionStr = sbTemp.append(projectionStr).toString();
        }
        if (excludeAttributes != null && !excludeAttributes.isEmpty()) {
            StringBuilder excludingColumnsSb = new StringBuilder("");
            excludingColumnsSb.append(StringUtils.join(excludeAttributes, LINE_SEPERATOR));
            String excludingStr = String.format(EXCLUDING_TEMPLATE, excludingColumnsSb.toString());
            sb.append(projectionStr).append(excludingStr);
        } else {
            sb.append(projectionStr);
        }
        //swager:
        // the item entity defined in the write service do not need action:
        if (!isForReadService && entityName.endsWith(EVENT)) {
            sb.append(TAB);
            String swagerTemplateStr = getTemplateFile(SWAGGER_TEMPLATE_FILE);
            sb.append(NEWLINE).append(String.format(swagerTemplateStr, entityName, entityName, entityName));
        }
        return sb.toString();
    }


    private static Map<String, String> generateCdsInfoForUIAnnotation(DraftModelBean draftModel) {
        String uiTemplate = getTemplateFile(UI_TEMPLATE_FILE);
        Map<String, String> returnMap = new HashMap();
        String namespace = draftModel.getNamespace();
        String serviceName = draftModel.getName();
        StringBuilder subModelUsingBuider = new StringBuilder();
        StringBuilder customUIAnnotationInfoBuilder = new StringBuilder();

        List<SubModelsBean> subModels = draftModel.getSubModels();
        Map<String, Set<ItemTypeEntity>> itemTypeEntityMap = draftModel.getItemTypeEntityInfoMap();
        Map<String, Map<String, String>> i18nFileInfo = draftModel.getI18nFileInfo();
        Map<String, String> defaultiI18nFileMap = i18nFileInfo.get(DEFAULT_I18N_FILE_NAME);
        for (SubModelsBean subModelBean : subModels) {
            String subModelName = subModelBean.getName();
            Set<ItemTypeEntity> itemTypeEntitySet = itemTypeEntityMap.get(subModelName);
            //get process entities name and the corresponding process events entities name:
            List<ProcessTypeEntity> processTypeEntities = subModelBean.getProcessTypes();
            List<ItemTypeEntity> itemTypeEntities = new ArrayList();
            if (itemTypeEntitySet != null && !itemTypeEntitySet.isEmpty()) {
                itemTypeEntities.addAll(itemTypeEntitySet);
            }
            List<EventTypeEntity> eventTypeEntities = subModelBean.getEventTypes();
            List<BaseEntity> entitiesForUIAnnotation = new ArrayList();
            entitiesForUIAnnotation.addAll(processTypeEntities);
            entitiesForUIAnnotation.addAll(itemTypeEntities);
            entitiesForUIAnnotation.addAll(eventTypeEntities);
            String subModelNameAlias = subModelName + ALIAS;
            subModelUsingBuider.append(USING + " " + namespace + DOT + subModelName
                    + " as " + subModelNameAlias + ";" + NEWLINE);
            String customUIAnnotationInfo = generateScriptForUiAnnotation(defaultiI18nFileMap, subModelNameAlias, entitiesForUIAnnotation);
            customUIAnnotationInfoBuilder.append(customUIAnnotationInfo);
        }
        String cdsInfo = String.format(uiTemplate, namespace, subModelUsingBuider.toString(),
                customUIAnnotationInfoBuilder.toString());
        returnMap.put(serviceName.concat("ServiceUI").concat(".cds"), cdsInfo);
        return returnMap;
    }

    private static String generateScriptForUiAnnotation(Map<String, String> defaultiI18nFileMap, String subModelName, List<BaseEntity> entitiesForUIAnnotation) {
        StringBuilder uiAnnotationBody = new StringBuilder("");
        for (BaseEntity entity : entitiesForUIAnnotation) {
            String entityName = entity.getName();
            String parentEntityName = getParentModelOfCore(entity);
            List<EntityElement> entityElements = entity.getElements();
            String uiSelectionFieldsOfTheEntity = getSelectionFiledsScript(parentEntityName, entityElements);
            List<String> uiElements = new ArrayList();
            if (StringUtils.isNotBlank(uiSelectionFieldsOfTheEntity)) {
                uiElements.add(uiSelectionFieldsOfTheEntity);
            }
            String uiLineItemsOfTheEntity = getLineItemsScript(entityName, parentEntityName, entityElements);
            if (StringUtils.isNotBlank(uiLineItemsOfTheEntity)) {
                uiElements.add(uiLineItemsOfTheEntity);
            }
            String uiFieldGroupsOfTheEntity = getFieldGroupScript(defaultiI18nFileMap, entityName, parentEntityName, entityElements);
            if (StringUtils.isNotBlank(uiFieldGroupsOfTheEntity)) {
                uiElements.add(uiFieldGroupsOfTheEntity);
            }
            String uiCoreModelFieldGroupsOfTheEntity = getCoreModelFieldGroupScript(parentEntityName);
            if (StringUtils.isNotBlank(uiCoreModelFieldGroupsOfTheEntity)) {
                uiElements.add(uiCoreModelFieldGroupsOfTheEntity);
            }
            String uiUserModelFieldGroupsOfTheEntity = getUserModelFieldGroupScript(defaultiI18nFileMap, entityName, entityElements);
            if (StringUtils.isNotBlank(uiUserModelFieldGroupsOfTheEntity)) {
                uiElements.add(uiUserModelFieldGroupsOfTheEntity);
            }
            Map<String, EntityElement> codeListAttributesMap = getCodeListAttribute(entityElements);
            String capabilitiesScript = getCapabilitiesScript(codeListAttributesMap.keySet());
            if (StringUtils.isNotBlank(capabilitiesScript)) {
                uiElements.add(capabilitiesScript);
            }
            List<String> hiddenAttriutesForTPEntityList = getHiddenScriptForTPEntity(entity);
            List<String> codeListAttributesUIAnnotationScript = getCodeListAttributeUIAnnotation(codeListAttributesMap);
            List<String> hiddenAndCodeList = new ArrayList();
            hiddenAndCodeList.addAll(hiddenAttriutesForTPEntityList);
            hiddenAndCodeList.addAll(codeListAttributesUIAnnotationScript);
            StringBuilder sb = new StringBuilder("");
            if (!hiddenAndCodeList.isEmpty()) {
                sb.append(LEFT_BRACE).append(NEWLINE);
                sb.append(StringUtils.join(hiddenAndCodeList, NEWLINE));
                sb.append(NEWLINE).append(RIGHT_BRACE);
            }
            uiAnnotationBody.append(String.format(UI_ANNOTATION_BODY_TEMPLATE, subModelName, entityName, StringUtils.join(uiElements, ","), sb.toString()));
        }
        return uiAnnotationBody.toString();
    }

    private static Map<String, EntityElement> getCodeListAttribute(List<EntityElement> entityElements) {
        Map<String, EntityElement> codeListAttributesMap = new HashMap();
        for (EntityElement entityElement : entityElements) {
            if (entityElement.getType().equalsIgnoreCase(CODE_LIST)) {
                codeListAttributesMap.put(entityElement.getName(), entityElement);
            }
        }
        return codeListAttributesMap;
    }

    private static String getCapabilitiesScript(Set<String> codeListAttributes) {
        String capabilityScript = "";
        if (!codeListAttributes.isEmpty()) {
            capabilityScript = String.format(CAPACITIES_TEMPLATE, StringUtils.join(codeListAttributes, LINE_SEPERATOR));
        }
        return capabilityScript;
    }

    private static List<String> getCodeListAttributeUIAnnotation(Map<String, EntityElement> codeListAttributeMap) {
        List<String> annotationList = new ArrayList();
        Set<String> codeListAttributes = codeListAttributeMap.keySet();
        for (String codeListAttribute : codeListAttributes) {
            annotationList.add(String.format(ATTIBUTE_ANNOTATION_TEXTONLY, codeListAttribute));
            annotationList.add(VALUE_LIST_WITH_FIXED_VALUES_ANNOTATION);
            EntityElement entityElement = codeListAttributeMap.get(codeListAttribute);
            String targetEntityName = entityElement.getTargetEntityName();
            annotationList.add(String.format(VALUE_LIST_FIXED_ANNOTATION, targetEntityName));
            annotationList.add(TAB + codeListAttribute);
        }
        return annotationList;
    }

    private static List<String> getHiddenScriptForTPEntity(BaseEntity entity) {
        List<String> hiddenAnnotation = new ArrayList();
        if (entity.getEntityType().equalsIgnoreCase(PROCESS_TYPE)) {
            List<EntityElement> entityElements = entity.getElements();
            for (EntityElement entityElement : entityElements) {
                if (entityElement.getType().equalsIgnoreCase(ASSOCIATION)) {
                    String associationElementName = entityElement.getName();
                    hiddenAnnotation.add(String.format(ATTRIBUTE_HIDDEN_ANNOTATION_TEMPLATE, associationElementName));
                    hiddenAnnotation.add(String.format(ATTRIBUTE_HIDDEN_ANNOTATION_TEMPLATE, associationElementName + ALTKEY));
                }
            }
        }
        return hiddenAnnotation;
    }

    private static String getSelectionFiledsScript(String parentCoreEntityName, List<EntityElement> entityElements) {
        String selectionFieldsContent = "";
        List<String> selectionFiledsAttributes = new ArrayList();
        if (coreModelUISelectionFieldsMap.get(parentCoreEntityName) != null) {
            List<String> parentSelectionFileds = coreModelUISelectionFieldsMap.get(parentCoreEntityName);
            selectionFiledsAttributes.addAll(parentSelectionFileds);
        }
        if (selectionFiledsAttributes.size() < SELECTION_FIELDS_COUNT) {
            int iCount = selectionFiledsAttributes.size();
            for (EntityElement entityElement : entityElements) {
                ++iCount;
                if (iCount > SELECTION_FIELDS_COUNT) {
                    break;
                }
                String entityElementName = entityElement.getName();
                if (!entityElement.isHidden()) {
                    selectionFiledsAttributes.add(entityElementName);
                }
            }
        }
        selectionFieldsContent = StringUtils.join(selectionFiledsAttributes, LINE_SEPERATOR);
        return String.format(UI_SELECTIONFILEDS_TEMPLATE, selectionFieldsContent);
    }


    private static String getLineItemsScript(String entityName, String parentCoreEntityName, List<EntityElement> entityElements) {
        String lineItemFieldContent = "";
        List<String> lineItemsAttributes = new ArrayList();
        if (coreModelUILineItemsMap.get(parentCoreEntityName) != null) {
            List<String> parentLineItemsFileds = coreModelUILineItemsMap.get(parentCoreEntityName);
            lineItemsAttributes.addAll(parentLineItemsFileds);
        }
        if (lineItemsAttributes.size() < LINE_ITEM_COUNT) {
            int iCount = lineItemsAttributes.size();
            for (EntityElement entityElement : entityElements) {
                ++iCount;
                if (iCount > LINE_ITEM_COUNT) {
                    break;
                }
                String entityElementName = entityElement.getName();
                String i18nKey = geti18nElementKey(entityName, entityElementName);
                entityElementName = String.format(LABEL_VALUE_FORMAT, i18nKey, entityElementName);
                if (!entityElement.isHidden()) {
                    lineItemsAttributes.add(entityElementName);
                }
            }
        }
        lineItemFieldContent = StringUtils.join(lineItemsAttributes, LINE_SEPERATOR);
        return String.format(UI_LINEITEMS_TEMPLATE, lineItemFieldContent);
    }

    private static String getFieldGroupScript(Map<String, String> defaultiI18nFileMap, String entityName, String parentCoreEntityName, List<EntityElement> entityElements) {
        List<String> filedGroupList = new ArrayList();
        if (coreModelUIFieldGroupsMap.get(parentCoreEntityName) != null) {
            List<String> parentFieldGroups = coreModelUIFieldGroupsMap.get(parentCoreEntityName);
            filedGroupList.addAll(parentFieldGroups);
        }
        List<String> orninaryFields = getOrdinaryFields(entityElements);
        for (String filedName : orninaryFields) {
            String i18nKey = geti18nElementKey(entityName, filedName);
            filedGroupList.add(String.format(LABEL_VALUE_FORMAT, i18nKey, filedName));
        }
        List<String> assocationFields = getAssociationFields(entityName, defaultiI18nFileMap, entityElements);
        for (String filedName : assocationFields) {
            String i18nKey = geti18nElementKey(entityName, filedName);
            filedGroupList.add(String.format(LABEL_VALUE_FORMAT, i18nKey, filedName));
        }
        List<String> compositionFields = getCompositionFields(entityElements);
        for (String filedName : compositionFields) {
            String i18nKey = geti18nElementKey(entityName, filedName);
            filedGroupList.add(String.format(LABEL_VALUE_FORMAT, i18nKey, filedName));
        }
        String filedGroupContent = StringUtils.join(filedGroupList, LINE_SEPERATOR);
        return String.format(UI_FILEDGROUP_TEMPLATE, filedGroupContent);

    }

    private static String getCoreModelFieldGroupScript(String parentCoreEntityName) {
        List<String> filedGroupList = new ArrayList();
        if (newCoreModelUIFieldGroupMap.get(parentCoreEntityName) != null) {
            List<String> parentFieldGroups = newCoreModelUIFieldGroupMap.get(parentCoreEntityName);
            filedGroupList.addAll(parentFieldGroups);
        }
        String filedGroupContent = StringUtils.join(filedGroupList, LINE_SEPERATOR);
        return String.format(UI_CORE_MODEL_FILEDGROUP_TEMPLATE, filedGroupContent);
    }

    private static String getUserModelFieldGroupScript(Map<String, String> defaultiI18nFileMap, String entityName, List<EntityElement> entityElements) {
        List<String> filedGroupList = new ArrayList();
        List<String> orninaryFields = getOrdinaryFields(entityElements);
        for (String filedName : orninaryFields) {
            String i18nKey = geti18nElementKey(entityName, filedName);
            filedGroupList.add(String.format(LABEL_VALUE_FORMAT, i18nKey, filedName));
        }
        List<String> assocationFields = getAssociationFields(entityName, defaultiI18nFileMap, entityElements);
        for (String filedName : assocationFields) {
            String i18nKey = geti18nElementKey(entityName, filedName);
            filedGroupList.add(String.format(LABEL_VALUE_FORMAT, i18nKey, filedName));
        }
        List<String> compositionFields = getCompositionFields(entityElements);
        for (String filedName : compositionFields) {
            String i18nKey = geti18nElementKey(entityName, filedName);
            filedGroupList.add(String.format(LABEL_VALUE_FORMAT, i18nKey, filedName));
        }
        String filedGroupContent = StringUtils.join(filedGroupList, LINE_SEPERATOR);
        return String.format(UI_USER_MODEL_FILEDGROUP_TEMPLATE, filedGroupContent);
    }

    private static List<String> getOrdinaryFields(List<EntityElement> entityElements) {
        List<String> ordinaryFields = new ArrayList();
        for (EntityElement entityElement : entityElements) {
            String type = entityElement.getType();
            if (type.equalsIgnoreCase(ASSOCIATION) || type.equalsIgnoreCase(COMPOSITION)) {
                continue;
            }
            if (!entityElement.isHidden()) {
                ordinaryFields.add(entityElement.getName());
            }
        }
        return ordinaryFields;
    }

    private static List<String> getAssociationFields(String entityName, Map<String, String> defaultiI18nFileMap, List<EntityElement> entityElements) {
        List<String> associationOrCompositionFields = new ArrayList();
        for (EntityElement entityElement : entityElements) {
            String elementName = entityElement.getName();
            String orignalElementName = elementName;
            if (entityElement.getType().equalsIgnoreCase(ASSOCIATION)) {
                if (isAssociationTargetAProcess(entityElement)) {
                    elementName = elementName + DOT + StringUtils.uncapitalize(ALTKEY);
                    associationOrCompositionFields.add(elementName);
                    String i18nKey = geti18nElementKey(entityName, elementName);
                    defaultiI18nFileMap.put(i18nKey, orignalElementName);
                } else {
                    if (!entityElement.isHidden()) {
                        associationOrCompositionFields.add(elementName);
                    }
                }
            }
        }
        return associationOrCompositionFields;
    }

    private static List<String> getCompositionFields(List<EntityElement> entityElements) {
        List<String> associationOrCompositionFields = new ArrayList();
        for (EntityElement entityElement : entityElements) {
            String elementName = entityElement.getName();
            if (entityElement.getType().equalsIgnoreCase(COMPOSITION) && !entityElement.isHidden()) {
                associationOrCompositionFields.add(elementName);
            }
        }
        return associationOrCompositionFields;
    }

    private static boolean isAssociationTargetAProcess(EntityElement entityElement) {
        String target = entityElement.getTarget();
        int indexOfDot = target.indexOf(DOT);
        if (indexOfDot > 0) {
            String modelName = target.substring(0, indexOfDot);
            String entityName = target.substring(indexOfDot + 1);
            if (modelName.equalsIgnoreCase(entityName)) {
                return true;
            }
        }
        return false;
    }

    private static String getParentModelOfCore(BaseEntity entity) {
        List<BaseEntity> parentEntities = entity.getParent();
        for (BaseEntity parentEntity : parentEntities) {
            if (parentEntity.getName().startsWith(CORE_MODEL)) {
                return parentEntity.getName();
            }
        }
        return null;
    }

    private static Map<String, String> generatePackageInfo(DraftModelBean draftModel) {
        Map<String, String> packageInfoMap = new HashMap();
        String version = draftModel.getSchemaVersion();
        String nameSpace = draftModel.getNamespace();
        String name = draftModel.getName();
        String packageContent = String.format(PACKAGE_TEMPLATE, nameSpace, version, name);
        packageInfoMap.put(PAKCAGE_FILE_NAME, packageContent);
        return packageInfoMap;
    }

}