const express = require('express');
const compression = require('compression');
const proxy = require('express-http-proxy');

const dir = {
  static: 'app/webapp',
};

const contexts = {
  public: '/app',
  sapui5: '/sapui5',
};

const servers = {
  nexus: 'http://nexus.wdf.sap.corp:8081',
};

const app = express();
app.use(compression());

// proxy for SAPUI5
const SAPUI5_VERSION = '1.56.12';
const SAPUI5_NEXUS_UNZIP_PATH = ((ui5Version) => {
  const gavct = `com.sap.ui5.dist:sapui5-sdk-dist:${ui5Version}:opt-static:zip`;
  const [group, artifact, version, classifier, type] = gavct.split(':');
  const groupPath = group.split('.').join('/');

  return `/nexus/content/unzip/build.snapshots.unzip/${groupPath}/${artifact}/${version}/${artifact}-${version}-${classifier}.${type}-unzip`;
})(SAPUI5_VERSION);

app.use(contexts.sapui5, proxy(servers.nexus, {
  proxyReqPathResolver: (req) => SAPUI5_NEXUS_UNZIP_PATH + req.url, // req.baseUrl => '/sap/ui5/1', req.url => '/resources/sap-ui-core.js'
}));


// local resources
app.use(contexts.public, express.static(dir.static));

// local server
const port = 8080;
app.listen(port, () => {
  console.log(`Server has been started. You can visit http://localhost:${port}${contexts.public}/`);
});
