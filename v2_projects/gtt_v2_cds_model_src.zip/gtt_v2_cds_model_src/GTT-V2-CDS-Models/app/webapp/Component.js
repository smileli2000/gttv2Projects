sap.ui.define([
  "sap/ui/generic/app/AppComponent"
], function(AppComponent) {
  "use strict";

  return AppComponent.extend("com.sap.gtt.app.generic.Component", {
    metadata: {
      manifest: "json"
    }
  });
});
