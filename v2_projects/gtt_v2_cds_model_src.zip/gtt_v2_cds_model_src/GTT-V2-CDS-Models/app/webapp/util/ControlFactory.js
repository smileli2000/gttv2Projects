sap.ui.define([
  "jquery.sap.global",
  "./AnnotationUtil",
  "./type/ODataTypes",
  "sap/ui/comp/smartfield/SmartLabel",
  "sap/ui/comp/smartfield/SmartField",
  "sap/ui/comp/smartfield/DisplayBehaviour",
  "sap/ui/core/ListItem",
  "sap/m/Label",
  "sap/m/Input",
  "sap/m/ComboBox",
  "sap/m/DateTimePicker"
], function(jQuery, AnnotationUtil, ODataTypes,
  SmartLabel, SmartField, DisplayBehaviour,
  ListItem, Label, Input, ComboBox, DateTimePicker) {
  "use strict";

  var odataModel;
  var modelName;
  var useODataActionContext = true;

  /**
   * Utility class for smart form controls
   *
   */
  var ControlFactory = {

    init: function(options) {
      odataModel = options.odataModel;
      modelName = options.modelName;
    },

    getTextLabel: function(formField) {
      var textLabel = this.isSmartField(formField.field)
        ? formField.field.getTextLabel()
        : formField.label.getText();

      return textLabel;
    },

    isMandatoryField: function(field) {
      if (this.isSmartField(field)) {
        return field.getMandatory();
      } else if (field instanceof sap.m.InputBase) {
        return field.getRequired();
      }
    },

    isEmptyMandatoryField: function(field) {
      var isEmpty = false;

      if (this.isSmartField(field)) {
        isEmpty = field.getValue() === "" && field.getDataType() !== "Edm.Boolean";
      } else if (field instanceof sap.m.ComboBox) {
        isEmpty = field.getSelectedKey() === "" || field.getSelectedKey() == null;
      } else if (field instanceof sap.m.InputBase) {
        isEmpty = field.getValue() === "";
      }

      return this.isMandatoryField(field) && isEmpty;
    },


    // ============================================================
    // Edm Field
    // ============================================================

    createEdmField: function(property, model) {
      var formField;

      switch (property.type) {
        case "Edm.Boolean":
          formField = this.createEdmBooleanField(property, model);
          break;
        case "Edm.Decimal":
        case "Edm.Double":
        case "Edm.Float":
        case "Edm.Single":
        case "Edm.Int16":
        case "Edm.Int32":
        case "Edm.Int64":
        case "Edm.Byte":
        case "Edm.SByte":
          formField = this.createEdmNumberField(property, model);
          break;
        case "Edm.DateTime":
          formField = this.createEdmDateTimeField(property, model);
          break;
        case "Edm.DateTimeOffset":
          formField = this.createEdmDateTimeOffsetField(property, model);
          break;
        case "Edm.String":
        default:
          formField = this.createEdmStringField(property, model);
          break;
      }

      this.onCreateEdmField(formField, property);

      return formField;
    },

    onCreateEdmField: function(formField, property) {
      var field = formField.field;

      // set mandatory if requested
      if (AnnotationUtil.isPropertyMandatory(property)) {
        if (formField.label) {
          field.setMandatory(true);
        } else {
          field.setRequired(true);
        }
      }

      if (!formField.label) {
        var label = new Label({
          text: AnnotationUtil.getPropertyLabel(property)
        });
        label.setLabelFor(field);

        formField.label = label;
      }
    },

    createEdmStringField: function(property, model) {
      var formField = {};
      var field;

      // check combobox
      var isComboBox = this.checkComboBox(property);

      // use smart field for non-combobox input field
      if (useODataActionContext && !isComboBox) {
        return ControlFactory.createSmartField(property, model);
      }

      if (isComboBox) {
        // use normal ComboBox control to support secondary value in the list
        field = this.createComboBoxField(property);
      } else {
        field = this.createInputField(property);
      }

      formField.field = field;

      return formField;
    },

    createEdmDateTimeOffsetField: function(property) {
      var formField = {};

      var isUTC = true;
      var field = this.createDateTimePicker(property, isUTC);

      formField.field = field;

      return formField;
    },

    createEdmDateTimeField: function(property) {
      return this.createSmartField(property, odataModel);
    },

    createEdmNumberField: function(property) {
      return this.createSmartField(property, odataModel);
    },

    createEdmBooleanField: function(property) {
      return this.createSmartField(property, odataModel);
    },


    // ============================================================
    // SmartField
    // ============================================================

    isSmartField: function(field) {
      return field instanceof SmartField;
    },

    createSmartField: function(property, model) {
      // Create a smartfield with data form outside
      var field = new SmartField({
        value: {
          path: property.name,
          model: modelName
        },
        textLabel: AnnotationUtil.getPropertyLabel(property),
        editable: AnnotationUtil.isPropertyEditable(property)
      });

      var isValueList = AnnotationUtil.isValueList(property);
      var valueListMode = AnnotationUtil.getValueListMode(property);

      var isComboBox = isValueList && valueListMode === "fixed-values";
      // var isValueHelpField = isValueList && valueListMode !== "fixed-values";

      var valueList;
      if (isComboBox) {
        if (property.propertyInfo) {
          valueList = property.propertyInfo.fullQualifiedName;
        }
      } else {
        valueList = property["com.sap.vocabularies.Common.v1.ValueList"];
      }

      field.data("configdata", {
        isInnerControl: isComboBox,
        configdata: {
          isInnerControl: false,
          path: property.name,
          entitySetObject: {},
          annotations: {
            text: {
              path: AnnotationUtil.getPropertyTextPath(property)
            },
            valuelist: valueList,
            valuelistType: valueListMode
          },
          model: modelName,
          modelObject: model,
          entityType: property.type,
          property: {
            property: property,
            typePath: property.name
          }
        }
      });

      field.attachInnerControlsCreated(function(event) {
        var smartField = event.getSource();
        this.setValueHelpOnly(smartField);
      }.bind(this));

      field.attachChange(function(event) {
        var smartField = event.getSource();

        if (this.isValueHelpField(smartField)) {
          // valueListChanged is fired after change,
          // we clear value list out fields in change event,
          // and later if there is valueListChanged event it will fill values again
          this.clearValueListOutFields(smartField);
        }
      }.bind(this));

      var label = new SmartLabel();
      label.setLabelFor(field);

      var formField = {
        label: label,
        field: field
      };

      return formField;
    },

    isValueHelpField: function(smartField) {
      var result = false;
      var innerControl = (smartField.getInnerControls() || [])[0];
      if (innerControl) {
        result = innerControl.getMetadata().getName() === "sap.m.Input" && innerControl.getShowValueHelp();
      }

      return result;
    },

    setValueHelpOnly: function(smartField) {
      if (this.isValueHelpField(smartField)) {
        var valueHelpField = smartField.getInnerControls()[0];
        valueHelpField.setValueHelpOnly(true);
      }
    },

    clearValueListOutFields: function(smartField) {
      if (!this.isValueHelpField(smartField)) {
        return;
      }

      // clear value list out parameter fields
      var dataProperty = smartField.getDataProperty();
      var property = dataProperty.property;
      var valueListInfo = AnnotationUtil.getValueListInfo(property);
      var outParams = valueListInfo.outParams;

      var bindingContext = smartField.getBindingContext();
      var model = bindingContext.getModel();

      var localDataProperty;
      for (localDataProperty in outParams) {
        if (localDataProperty !== property.name) {
          jQuery.sap.log.info("Clear value list output field in smart field change event", localDataProperty);
          model.setProperty(localDataProperty, null, bindingContext);
        }
      }
    },


    // ============================================================
    // Input
    // ============================================================

    createInputField: function(property) {
      // var dateTimeType = new DateTime({strictParsing: true, UTC: true});
      var type = new sap.ui.model.type.String();
      var inputField = new Input({
        value: {
          path: property.name,
          model: modelName,
          type: type
        }
      });

      return inputField;
    },


    // ============================================================
    // ComboBox
    // ============================================================

    checkComboBox: function(property) {
      var isEditable = AnnotationUtil.isPropertyEditable(property);

      return isEditable && AnnotationUtil.getValueListMode(property) === "fixed-values";
    },

    createComboBoxField: function(property) {
      var type = ODataTypes.getType(property);

      var combobox = new ComboBox({
        selectedKey: {
          path: property.name,
          model: modelName,
          type: type
        },
        showSecondaryValues: true
      });

      var valueListInfo = AnnotationUtil.getValueListInfo(property);
      var collectionPath = "/" + valueListInfo.valueListEntitySetName;
      var keyPropName = valueListInfo.keyField;
      var textPropName = valueListInfo.descriptionField;
      var displayBehavior = AnnotationUtil.getDisplayBehavior(property);

      combobox.bindItems({
        path: collectionPath,
        key: keyPropName,
        length: 1000, // load all items
        template: new ListItem({
          key: {
            path: keyPropName
          },
          text: this.getComboBoxTextBindingInfo(keyPropName, textPropName, displayBehavior),
          additionalText: this.getComboBoxSecondaryTextBindingInfo(keyPropName, textPropName, displayBehavior)
        })
      });

      return combobox;
    },

    getComboBoxTextBindingInfo: function(keyPropName, textPropName, displayBehavior) {
      var bindingInfo = {
        path: textPropName
      };

      switch (displayBehavior) {
        case DisplayBehaviour.idOnly:
        case DisplayBehaviour.idAndDescription:
          bindingInfo.path = keyPropName;
          break;
        case DisplayBehaviour.descriptionOnly:
        case DisplayBehaviour.descriptionAndId:
        default:
          bindingInfo.path = textPropName;
          break;
      }

      return bindingInfo;
    },

    getComboBoxSecondaryTextBindingInfo: function(keyPropName, textPropName, displayBehavior) {
      var bindingInfo = {
        path: null
      };

      switch (displayBehavior) {
        case DisplayBehaviour.idAndDescription:
          bindingInfo.path = textPropName;
          break;
        case DisplayBehaviour.descriptionAndId:
          bindingInfo.path = keyPropName;
          break;
        case DisplayBehaviour.idOnly:
        case DisplayBehaviour.descriptionOnly:
        default:
          bindingInfo = null;
          break;
      }

      return bindingInfo;
    },


    // ============================================================
    // DateTimePicker
    // ============================================================

    createDateTimePicker: function(property, isUTC) {
      var type = ODataTypes.getType(property, {
        strictParsing: true,
        UTC: isUTC
      });

      var field = new DateTimePicker({
        value: {
          path: property.name,
          model: modelName,
          type: type
        }
      });

      return field;
    }
  };

  return ControlFactory;
});
