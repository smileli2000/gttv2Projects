sap.ui.define([
  "sap/ui/core/format/NumberFormat",
  "sap/ui/model/odata/type/Boolean",
  "sap/ui/comp/smartfield/type/DateTime",
  "./DateTime",
  "sap/ui/comp/smartfield/type/Decimal",
  "sap/ui/comp/smartfield/type/Int16",
  "sap/ui/comp/smartfield/type/Int32",
  "sap/ui/comp/smartfield/type/Int64",
  "sap/ui/comp/smartfield/type/SByte",
  "sap/ui/comp/smartfield/type/String",
  "sap/ui/comp/smartfield/type/AbapBool",
  "sap/ui/model/type/Currency",
  "sap/ui/comp/smartfield/type/Time",
  "sap/ui/model/ParseException",
  "../AnnotationUtil"
], function(NumberFormat, BooleanType, DateTimeType, DateTimeOffsetType, DecimalType, Int16Type, Int32Type, Int64Type, SByteType, StringType, AbapBoolean, CurrencyType, TimeType,
    ParseException, AnnotationUtil) {
  "use strict";

  /**
   * Utility class for OData Types
   *
   */
  var ODataTypes = {

    getType: function(property, oFormatOptions, mConstraints) {
      var type = null;

      // select the type by EDM type.
      if (property && property.type) {
        var oConstraints;

        switch (property.type) {
          case "Edm.Boolean":
            type = new BooleanType();
            break;
          case "Edm.Decimal":
          case "Edm.Double":
          case "Edm.Float":
          case "Edm.Single":
            oConstraints = this._getDecimalConstraints(property);
            type = new DecimalType(oFormatOptions, oConstraints);
            break;
          case "Edm.Int16":
            type = new Int16Type();
            break;
          case "Edm.Int32":
            type = new Int32Type();
            break;
          case "Edm.Int64":
            type = new Int64Type();
            break;
          case "Edm.Byte":
          case "Edm.SByte":
            type = new SByteType();
            break;
          case "Edm.DateTimeOffset":
            type = new DateTimeOffsetType(oFormatOptions, oConstraints);
            break;
          case "Edm.DateTime":
            oConstraints = this._getDateTimeConstraints(property, mConstraints);
            type = new DateTimeType(oFormatOptions, oConstraints);
            break;
          case "Edm.String":
            oConstraints = this._getStringConstraints(property);
            type = new StringType(oFormatOptions, oConstraints);
            break;
          case "Edm.Time":
            type = new TimeType(oFormatOptions, mConstraints);
            break;
          default:
            break;
        }

        // set mandatory check
        if (type && AnnotationUtil.isPropertyMandatory(property)) {
          type.oFieldControl = this.getMandatoryCheck(property);
        }
      }

      return type;
    },

    getMandatoryCheck: function(property) {
      var fReturn;

      if (property) {
        switch (property.type) {
          case "Edm.DateTimeOffset":
          case "Edm.DateTime":
          case "Edm.Time":
          case "Edm.String":
            fReturn = function(sValue) {
              if (AnnotationUtil.isPropertyMandatory(property)) {
                if (!sValue) {
                  throw new ParseException(sap.ui.getCore().getLibraryResourceBundle("sap.ui.comp").getText("VALUEHELPVALDLG_FIELDMESSAGE"));
                }
              }
            };
            break;
          case "Edm.Decimal":
          case "Edm.Double":
          case "Edm.Float":
          case "Edm.Single":
          case "Edm.Int16":
          case "Edm.Int32":
          case "Edm.Int64":
          case "Edm.Byte":
          case "Edm.SByte":
            fReturn = function(sValue) {
              if (AnnotationUtil.isPropertyMandatory(property)) {
                if (sValue === null || sValue === undefined || sValue === "") {
                  throw new ParseException(sap.ui.getCore().getLibraryResourceBundle("sap.ui.comp").getText("VALUEHELPVALDLG_FIELDMESSAGE"));
                }
              }
            };
            break;
          default:
            break;
        }
      }

      return fReturn;
    },

    /**
     * Calculates the constraints for <code>Edm.DateTime</code>.
     *
     * @param {object} property the definition of a property of an OData entity.
     * @param {map} mConstraints optional constraints.
     * @returns {map} the constraints.
     * @private
     */
    _getDateTimeConstraints: function(property, mConstraints) {
      var oConstraints = {},
        n;

      // this method is only invoked for Edm.DateTime,
      // so no need exists to replace it with V4 annotations,
      // as Edm.DateTime is "pruned" in V4.
      if (property["sap:display-format"] === "Date") {
        oConstraints = {
          displayFormat: "Date"
        };
      }

      // constraints from control have priority.
      for (n in mConstraints) {
        if (Object.prototype.hasOwnProperty.call(mConstraints, n)) {
          oConstraints[n] = mConstraints[n];
        }
      }

      return oConstraints;
    },

    /**
     * Calculates the value of the control's <code>maxLength</code> property. The value can be configured in the <code>maxLength</code> attribute
     * of the OData property to which the the control's <code>value</code> property is bound to. Alternatively it can be configured in the the
     * control's <code>maxLength</code> property. If both are available the minimum value of both is returned.
     *
     * @param {object} property the property from which to take the <code>maxLength</code>.
     * @returns {int} maximum number of characters, <code>0</code> means the feature is switched off.
     * @public
     */
    getMaxLength: function(property) {
      var iResult = 0;

      // is a max length available from oData property.
      if (property && property.maxLength) {
        var iProp = parseInt(property.maxLength, 10);

        if (iProp > -1) {
          iResult = iProp;
        }
      }

      return iResult;
    },

    /**
     * Calculates the constraints for a numeric Edm.Type, with optional <code>scale</code> and <code>precision</code> attributes of the OData
     * property set.
     *
     * @param {object} property the definition of a property of an OData entity.
     * @returns {map} the constraints.
     * @private
     */
    _getDecimalConstraints: function(property) {
      var mArgs = null;

      if (property.precision) {
        mArgs = {};
        mArgs.precision = parseInt(property.precision, 10);
      }

      if (property.scale) {
        if (!mArgs) {
          mArgs = {};
        }

        mArgs.scale = parseInt(property.scale, 10);
      }

      return mArgs;
    },

    /**
     * Calculates the constraints for a property of type <code>Edm.String</code>.
     *
     * @param {object} property the definition of a property of an OData entity
     * @returns {object} The constraints
     */
    _getStringConstraints: function(property) {
      var iMaxLength,
        mConstraints = {};

      // get max length
      iMaxLength = this.getMaxLength(property);

      // create the return value
      if (iMaxLength > 0) {
        mConstraints.maxLength = iMaxLength;
      }

      // if (MetadataAnalyser.isDigitSequence(property)) {
      //   mConstraints.isDigitSequence = true;
      // }

      return mConstraints;
    }
  };

  return ODataTypes;
});
