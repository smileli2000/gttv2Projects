sap.ui.define([
  "sap/ui/model/type/DateTime",
  "sap/ui/model/ParseException"
], function(DateTimeBase, ParseException) {
  "use strict";

  // extend DateTime type
  var DateTime = DateTimeBase.extend("com.sap.gtt.app.generic.util.type.DateTime", {
    constructor: function() {
      DateTimeBase.apply(this, arguments);
      this.oFieldControl = null;
    }
  });

  DateTime.prototype.parseValue = function(sValue, sSourceType) {
    try {
      var oReturn = DateTimeBase.prototype.parseValue.apply(this, [sValue, sSourceType]);
    } catch (exception) {
      if (exception instanceof ParseException) {
        exception.message = this.getErrorMessage();
      }

      throw exception;
    }

    this.oFieldControl(sValue, sSourceType);

    return oReturn;
  };

  DateTime.prototype.getName = function() {
    return this.getMetadata().getName();
  };

  var _demoDate = new Date(2014, 10, 27, 13, 47, 26);

  /*
   * Returns the matching locale-dependent error message for the type based on the constraints.
   *
   * @returns {string}
   *   The locale-dependent error message
   */
  DateTime.prototype.getErrorMessage = function() {
    var bundle = sap.ui.getCore().getLibraryResourceBundle();
    return bundle.getText("EnterDateTime", [this.formatValue(_demoDate, "string")]);
  };

  return DateTime;
});
