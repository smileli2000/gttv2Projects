sap.ui.define([
  "jquery.sap.global",
  "sap/ui/comp/smartfield/AnnotationHelper"
], function(jQuery, AnnotationHelper) {
  "use strict";

  var annotationHelper = new AnnotationHelper();
  var metaModel;

  /**
   * Utility class for processing OData Annotations
   *
   */
  var AnnotationUtil = {

    init: function(options) {
      metaModel = options.metaModel;
    },

    /**
    * Returns true if the annotation marked as true
    *
    * @param {object} term The Term annotation object
    * @returns {boolean} <code>true</code>, if the annotation exists and is set to true
    */
    isTermTrue: function(term) {
      return !!term && term.Bool === "true";
    },


    // ============================================================
    // Entity
    // ============================================================

    getEntityTypeShortName: function(fullQualifiedName) {
      return fullQualifiedName.slice(fullQualifiedName.lastIndexOf(".") + 1);
    },

    getEntityTypeByEntitySet: function(entitySetName) {
      var entitySet = metaModel.getODataEntitySet(entitySetName);
      var entityType = metaModel.getODataEntityType(entitySet.entityType);

      return entityType;
    },

    getEntityTypeFullQualifiedName: function(entityType) {
      var namespace = entityType.namespace;

      return jQuery.sap.formatMessage("{0}.{1}", namespace, entityType.name);
    },

    getEntitySetFullQualifiedName: function(entitySetName) {
      var entityContainer = metaModel.getODataEntityContainer();
      var namespace = entityContainer.namespace;

      return jQuery.sap.formatMessage("{0}.{1}/{2}", namespace, entityContainer.name, entitySetName);
    },

    getFunctionImportFullQualifiedName: function(functionImportName) {
      var entityContainer = metaModel.getODataEntityContainer();
      var namespace = entityContainer.namespace;

      return jQuery.sap.formatMessage("{0}.{1}/{2}", namespace, entityContainer.name, functionImportName);
    },

    getPropertyFullQualifiedName: function(propertyName, entityType) {
      var namespace = entityType.namespace;

      return jQuery.sap.formatMessage("{0}.{1}/{2}", namespace, entityType.name, propertyName);
    },

    getKeyProperties: function(entityType) {
      var keyMap = {};

      if (entityType && entityType.key && entityType.key.propertyRef) {
        for (var i = 0; i < entityType.key.propertyRef.length; i++) {
          var keyName = entityType.key.propertyRef[i].name;
          keyMap[keyName] = true;
        }
      }

      return keyMap;
    },


    // ============================================================
    // Property
    // ============================================================

    getProperty: function(propertyName, entityType) {
      return metaModel.getODataProperty(entityType, propertyName, false);
    },

    isPropertyNullable: function(property) {
      return property.nullable !== "false";
    },

    isPropertyMandatory: function(property) {
      var isMandatory = false;

      if (!this.isPropertyNullable(property)) {
        isMandatory = true;
      }

      if (property["com.sap.vocabularies.Common.v1.FieldControl"]
          && property["com.sap.vocabularies.Common.v1.FieldControl"].EnumMember
          && property["com.sap.vocabularies.Common.v1.FieldControl"].EnumMember === "com.sap.vocabularies.Common.v1.FieldControlType/Mandatory") {
        isMandatory = true;
      }

      return isMandatory;
    },

    isPropertyVisible: function(property) {
      var result = annotationHelper.getVisible(property);
      return result === "true";
    },

    isPropertyEditable: function(property) {
      return annotationHelper.canUpdateProperty(property);
    },

    getPropertyLabel: function(property) {
      // if no label is set for property use property name as fallback
      return property["com.sap.vocabularies.Common.v1.Label"]
        ? property["com.sap.vocabularies.Common.v1.Label"].String
        : property.name;
    },

    getPropertyTextPath: function(property) {
      var textAnno = property["com.sap.vocabularies.Common.v1.Text"];
      return textAnno && textAnno.Path ? textAnno.Path : property.name;
    },

    addLabelToParameter: function(parameter, entityType) {
      if (entityType && parameter && !parameter["com.sap.vocabularies.Common.v1.Label"]) {
        var property = this.getProperty(parameter.name, entityType);
        if (property && property["com.sap.vocabularies.Common.v1.Label"]) {
          // copy label from property to parameter with same name as default if no label is set for function import parameter
          parameter["com.sap.vocabularies.Common.v1.Label"] = property["com.sap.vocabularies.Common.v1.Label"];
        }
      }
    },


    // ============================================================
    // Value List
    // ============================================================

    getValueListInfo: function(property) {
      var valueListInfo = {};

      var annotation = property["com.sap.vocabularies.Common.v1.ValueList"];

      if (annotation) {
        // collection path
        valueListInfo.valueListEntitySetName = this.getValueListEntitySetName(annotation);

        // parameters
        valueListInfo.inParams = {};
        valueListInfo.outParams = {};

        var parameters = annotation["Parameters"] || [];
        parameters.forEach(function(parameter) {
          var valueListProperty;
          if (parameter["ValueListProperty"]) {
            valueListProperty = parameter["ValueListProperty"].String;
          }
          var localDataProperty;
          if (parameter["LocalDataProperty"]) {
            localDataProperty = parameter["LocalDataProperty"].PropertyPath;
          }

          var bIsInParam = false;
          if (parameter.RecordType === "com.sap.vocabularies.Common.v1.ValueListParameterInOut" || parameter.RecordType === "com.sap.vocabularies.Common.v1.ValueListParameterIn") {
            bIsInParam = true;
          }
          var bIsOutParam = false;
          if (parameter.RecordType === "com.sap.vocabularies.Common.v1.ValueListParameterInOut" || parameter.RecordType === "com.sap.vocabularies.Common.v1.ValueListParameterOut") {
            bIsOutParam = true;
          }

          // Mapping for In/InOut params
          if (bIsInParam) {
            valueListInfo.inParams[localDataProperty] = valueListProperty;
          }

          // Mapping for Out/InOut params
          if (bIsOutParam) {
            valueListInfo.outParams[localDataProperty] = valueListProperty;
          }

          // LocalDataProperty
          if (localDataProperty === property.name) {
            valueListInfo.keyField = valueListProperty;
          }
        });

        valueListInfo.descriptionField = this.getValueListDescriptionFieldName(valueListInfo.keyField, valueListInfo.valueListEntitySetName);
      }

      return valueListInfo;
    },

    /**
     * Checks whether <code>property</code> is annotated as value list.
     *
     * @param {object} property The OData property from the meta model
     * @returns {boolean} <code>true</code>, if the OData property is annotated with the following
     *          <code>com.sap.vocabularies.Common.v1.ValueList</code> annotation.
     */
    isValueList: function(property) {
      var term = "com.sap.vocabularies.Common.v1.ValueList";

      return !!(property && (property["sap:value-list"] || property[term]));
    },

    /**
     * Checks whether <code>property</code> is annotated as value list with fixed values.
     *
     * @param {object} property The OData property from the meta model
     * @returns {boolean} <code>true</code>, if the OData property is annotated with the following
     *          <code>"com.sap.vocabularies.Common.v1.ValueListWithFixedValues": { "Bool" : "true" }</code> annotation.
     */
    isValueListWithFixedValues: function(property) {
      var term = "com.sap.vocabularies.Common.v1.ValueListWithFixedValues";
      return this.isTermTrue(property[term]);
    },

    getValueListMode: function(property) {
      var sValueList = property["sap:value-list"];

      if (sValueList) {
        return sValueList;
      }

      if (this.isValueListWithFixedValues(property)) {
        return "fixed-values";
      }

      return "";
    },

    getValueListEntitySetName: function(annotation) {
      var valueListEntitySetName;

      if (annotation) {
        // collection path
        if (annotation["CollectionPath"]) {
          valueListEntitySetName = annotation["CollectionPath"].String;
        }
      }

      return valueListEntitySetName;
    },

    getValueListDescriptionFieldName: function(propertyName, entitySetName) {
      var entityType = this.getEntityTypeByEntitySet(entitySetName);
      var property = this.getProperty(propertyName, entityType);
      var fieldName = this.getPropertyTextPath(property);

      return fieldName;
    },

    getDisplayBehavior: function(property) {
      var displayBehavior = annotationHelper.getTextArrangement(property);

      return displayBehavior;
    }

  };

  return AnnotationUtil;
});
