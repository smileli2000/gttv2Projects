sap.ui.define([], function() {
  "use strict";

  /**
   * Parse semantic version to a version info object
   * @param  {String} version The semantic version with an optional build info, like "1.0.2-MS3"
   * @return {Object} The version info object
   */
  function parseSemanticVersion(version) {
    var rSemanticVersion = /(\d+)\.(\d+)\.(\d+)(?:-(\w+))?/; // "1.0.2-MS3"
    var matches = rSemanticVersion.exec(version);

    var versionInfo = {};

    if (matches && matches.length > 3) {
      versionInfo = {
        major: Number(matches[1]),
        minor: Number(matches[2]),
        patch: Number(matches[3]),
        build: matches[4]
      };
    }

    return versionInfo;
  }

  /**
   * Compare versions
   * @param  {String} version1 Version 1
   * @param  {String} version2 Version 2
   * @return {Integer} `1` for greater than, `0` for equals and `-1` for less than
   */
  function compareVersion(version1, version2) {
    var result = {
      GT: 1,
      EQ: 0,
      LT: -1
    };

    var versionInfo1 = parseSemanticVersion(version1);
    var versionInfo2 = parseSemanticVersion(version2);

    if (versionInfo1.major !== versionInfo2.major) {
      return versionInfo1.major > versionInfo2.major ? result.GT : result.LT;
    } else {
      if (versionInfo1.minor !== versionInfo2.minor) {
        return versionInfo1.minor > versionInfo2.minor ? result.GT : result.LT;
      } else {
        if (versionInfo1.patch !== versionInfo2.patch) {
          return versionInfo1.patch > versionInfo2.patch ? result.GT : result.LT;
        } else {
          return result.EQ;
        }
      }
    }
  }

  return {
    parseSemanticVersion: parseSemanticVersion,
    compareVersion: compareVersion
  };
});
