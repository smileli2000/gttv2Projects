sap.ui.define([
  "jquery.sap.global",
  "./AnnotationUtil",
  "./ControlFactory",
  "sap/ui/model/Context"
], function(jQuery, AnnotationUtil, ControlFactory, Context) {
  "use strict";

  /**
   * Utility class for Function Import action
   *
   */
  var ActionUtil = {
    callAction: function(functionImportName, options) {
      var promise = new Promise(function(resolve, reject) {
        // resolve later
        var actionPromiseCallback = {
          resolve: resolve,
          reject: reject
        };
        options.actionPromiseCallback = actionPromiseCallback;

        var controller = options.controller;
        if (!controller) {
          reject("Controller not provided");
        }

        var odataModel = controller.getView().getModel();
        var metaModel = odataModel.getMetaModel();

        var functionImport = metaModel.getODataFunctionImport(functionImportName);

        if (!functionImport) {
          reject("Unknown Function Import " + functionImportName);
        }

        var entityContext = options.entityContext;

        var model;
        if (options.useODataActionContext) {
          model = odataModel;
        } else {
          model = controller.getView().getModel(options.actionModelName);
          model.setData({});
        }
        options.model = model;

        var mActionParams = this.prepareParameters(functionImport, entityContext);
        this.initiateCall(functionImport, entityContext, mActionParams, options);
      }.bind(this));

      return promise.then(function(result) {
        return result;
      }, function(error) {
        // function is called, when the user cancels the action (on the popup to enter parameters - before sending a request to the backend)
        var actionContext = error.actionContext;
        this.cleanUpContext(actionContext);

        throw error;
      }.bind(this));
    },

    prepareParameters: function(functionImport, context) {
      if (!functionImport || !context) {
        return;
      }

      var metaModel = context.getModel().getMetaModel();
      var metaContext = metaModel.getMetaContext(context.getPath());
      var entityType = metaContext.getObject();
      var contextObject = context.getObject();

      var keyProperties = AnnotationUtil.getKeyProperties(entityType);
      var parameterValue;
      var actionParams = {
        parameterData: {},
        additionalParameters: []
      };

      if (functionImport.parameter) {
        for (var i = 0; i < functionImport.parameter.length; i++) {
          var parameter = functionImport.parameter[i];

          this.addParameterLabel(parameter, entityType);

          var parameterName = parameter.name;
          var isKey = !!keyProperties[parameterName];

          parameterValue = undefined;
          parameter.propertyInfo = {};

          if (contextObject.hasOwnProperty(parameterName)) {
            parameterValue = contextObject[parameterName];

            // add property metadata
            parameter.propertyInfo.name = parameterName;
            parameter.propertyInfo.fullQualifiedName = AnnotationUtil.getPropertyFullQualifiedName(parameterName, entityType);
            parameter.propertyInfo.property = AnnotationUtil.getProperty(parameterName, entityType);
          } else if (AnnotationUtil.getPropertyTextPath(parameter) !== parameter.name) {
            // set value by @Common.Text
            var textPath = AnnotationUtil.getPropertyTextPath(parameter);
            parameterValue = context.getProperty(textPath);
          } else if (isKey) {
            // parameter is key but not part of the current projection - raise error
            jQuery.sap.log.error("Key parameter of action not found in current context: " + parameterName);
            throw new Error("Key parameter of action not found in current context: " + parameterName);
          }

          actionParams.parameterData[parameterName] = parameterValue;

          if (!isKey && parameter.mode.toUpperCase() === "IN") {
            // offer as optional parameter with default value from context
            actionParams.additionalParameters.push(parameter);
          }
        }
      }

      return actionParams;
    },

    initiateCall: function(functionImport, entityContext, mActionParams, options) {
      var oFuncHandle = this.getNewActionContext(functionImport, entityContext, options);

      oFuncHandle.context.then(function(oActionContext) {
        var model = options.model;
        if (!options.useODataActionContext) {
          model.setProperty(oActionContext.getPath(), {});
        }

        var parameterData = mActionParams.parameterData;
        for (var sKey in parameterData) {
          if (Object.prototype.hasOwnProperty.call(parameterData, sKey)
            && parameterData[sKey] !== null
            && parameterData[sKey] !== undefined) {
            model.setProperty(sKey, parameterData[sKey], oActionContext);
          }
        }

        sap.ui.require([
          "sap/m/Dialog",
          "sap/m/VBox",
          "sap/m/Text",
          "sap/m/Button",
          "sap/m/MessageBox",
          "sap/ui/layout/form/SimpleForm"
        ], function(Dialog, VBox, Text, Button, MessageBox, SimpleForm) {
          var that = this;
          var actionPromiseCallback = options.actionPromiseCallback;
          var resourceBundle = sap.ui.getCore().getLibraryResourceBundle("sap.m");

          var form = new SimpleForm({
            editable: true
          });
          var parameterForm = this.buildParametersForm(form, mActionParams, oActionContext, options);

          var bActionPromiseDone = false;

          var oParameterDialog = new Dialog({
            title: options.title,
            content: [parameterForm.form],
            beginButton: new Button({
              text: resourceBundle.getText("MSGBOX_OK"),
              press: function() {
                if (parameterForm.hasNoClientErrors()) {
                  var emptyMandatoryFields = parameterForm.getEmptyMandatoryFields();

                  // show mandatory validation errors
                  if (emptyMandatoryFields.length === 0) {
                    oParameterDialog.close();

                    options.actionPromiseCallback.resolve({
                      executionPromise: oFuncHandle.result.then(function(data) {
                        return data;
                      }, function(error) {
                        // when function import call is failed
                        this.cleanUpContext(oActionContext);
                        throw error;
                      }.bind(that))
                    });

                    bActionPromiseDone = true;

                    // invoke server side action
                    that.submitActionContext(oActionContext);
                  } else {
                    var oContent = new VBox();

                    var sRootMessage = sap.ui.getCore().getLibraryResourceBundle("sap.ui.generic.app").getText("ACTION_MISSING_MANDATORY");

                    jQuery.each(emptyMandatoryFields, function(index, formField) {
                      var textLabel = ControlFactory.getTextLabel(formField);
                      var text = jQuery.sap.formatMessage(sRootMessage, textLabel);
                      oContent.addItem(new Text({text: text}));
                    });

                    MessageBox.error(oContent, {
                      // sClass: that._getCompactModeStyleClass()
                    });
                  }
                }
              }
            }),
            endButton: new Button({
              text: resourceBundle.getText("MSGBOX_CANCEL"),
              press: function() {
                oParameterDialog.close();
                actionPromiseCallback.reject({
                  actionContext: oActionContext
                });

                bActionPromiseDone = true;
              }
            }),
            afterClose: function() {
              that.unregisterValidation(oParameterDialog);
              oParameterDialog.destroy();

              // Tidy up at the end: if the action hasn't been triggered, do the same as it was cancelled.
              if (!bActionPromiseDone) {
                actionPromiseCallback.reject({
                  actionContext: oActionContext
                });
              }
            }
          });

          var view = options.controller.getView();
          view.addDependent(oParameterDialog);
          this.registerValidation(oParameterDialog);

          oParameterDialog.open();
        }.bind(this));
      }.bind(this));
    },

    getNewActionContext: function(functionImport, oEntityContext, options) {
      var oFuncHandle;

      if (options.useODataActionContext) {
        oFuncHandle = this.getNewODataActionContext(functionImport, options.model, oEntityContext);
      } else {
        oFuncHandle = this.getNewJSONActionContext(functionImport, options.model, oEntityContext);
      }

      return oFuncHandle;
    },

    getNewODataActionContext: function(functionImport, model, oEntityContext) {
      var mParameters = {
        batchGroupId: "Changes",
        changeSetId: "SingleAction",
        successMsg: "Call of action succeeded",
        failedMsg: "Call of action failed",
        forceSubmit: true,
        context: oEntityContext,
        functionImport: functionImport,
        urlParameters: {}
      };

      var oFuncHandle = this.createFunctionContext(model, mParameters);

      // Add "formatters" for error and success messages
      oFuncHandle.result = oFuncHandle.result.then(function(oResponse) {
        return this.normalizeResponse(oResponse);
      }.bind(this), function(oResponse) {
        var oOut = this.normalizeError(oResponse);
        throw oOut;
      }.bind(this));

      return oFuncHandle;
    },

    getNewJSONActionContext: function(functionImport, model) {
      var oFuncHandle = {};

      oFuncHandle.context = new Promise(function(resolve) {
        var contextPath = "/" + functionImport.name;
        var actionContext = new Context(model, contextPath);

        resolve(actionContext);
      });

      return oFuncHandle;
    },

    createFunctionContext: function(model, mParameters) {
      var mActionHandles = {};
      var mCallbacks;

      mActionHandles.result = new Promise(function(resolve, reject) {
        mCallbacks = {
          success: function(oData, oResponse) {
            // resolve the promise.
            resolve({
              responseData: oData,
              httpResponse: oResponse
            });
          },
          error: function(oResponse) {
            // reject the promise.
            reject(oResponse);
          }
        };
      });

      mActionHandles.context = model.callFunction("/" + mParameters.functionImport.name, {
        method: mParameters.functionImport.httpMethod,
        urlParameters: mParameters.urlParameters,
        success: mCallbacks.success,
        error: mCallbacks.error,
        batchGroupId: mParameters.batchGroupId,
        changeSetId: mParameters.changeSetId,
        headers: mParameters.headers
      }).contextCreated();

      return mActionHandles;
    },

    normalizeResponse: function(oResponse) {
      if (oResponse && (oResponse.httpResponse || oResponse.responseData)) {
        return {
          data: oResponse.responseData,
          response: oResponse.httpResponse || null
          // context: bContext ? this._oModelUtil.getContextFromResponse(oResponse.responseData) : null
        };
      }

      return oResponse;
    },

    normalizeError: function(oResponse) {
      if (oResponse && oResponse.message) {
        return {
          response: oResponse
        };
      }

      return oResponse;
    },

    submitActionContext: function(actionContext) {
      var model = actionContext.getModel();
      model.submitChanges({
        batchGroupId: "Changes"
      });
    },

    cleanUpContext: function(actionContext) {
      // remove pending request from the last change of the model actually
      if (actionContext) {
        var oModel = actionContext.getModel();
        if (oModel && oModel.hasPendingChanges()) {
          oModel.resetChanges();
        }
      }
    },

    buildParametersForm: function(form, parameters, context, options) {
      form.setBindingContext(context, options.actionModelName);

      var model = context.getModel();
      var odataModel = options.controller.getView().getModel();

      // list of all smart fields for input check
      var formField;
      var formFields = [];
      var field;
      var fields = [];

      for (var i = 0; i < parameters.additionalParameters.length; i++) {
        var parameter = parameters.additionalParameters[i];

        formField = this.createParameterFormField(parameter, model, odataModel);
        if (formField) {
          formFields.push(formField);

          field = formField.field;
          fields.push(field);

          form.addContent(formField.label);
          form.addContent(field);
        }
      }

      // for now: always return false, as smart fields currently do not handle JSON models correctly
      var fnHasNoClientErrors = function() {
        var bNoClientErrors = true;
        for (var i = 0; i < fields.length; i++) {
          if (fields[i].getValueState() !== "None") {
            bNoClientErrors = false;
            break;
          }
        }

        return bNoClientErrors;
      };

      var fnGetEmptyMandatoryFields = function() {
        var aMandatoryFields = jQuery.grep(formFields, function(fieldObj) {
          return ControlFactory.isEmptyMandatoryField(fieldObj.field);
        });

        return aMandatoryFields;
      };

      return {
        form: form,
        hasNoClientErrors: fnHasNoClientErrors,
        getEmptyMandatoryFields: fnGetEmptyMandatoryFields
      };
    },

    addParameterLabel: function(parameter, entityType) {
      AnnotationUtil.addLabelToParameter(parameter, entityType);
    },

    createParameterFormField: function(parameter, model, odataModel) {
      if (!AnnotationUtil.isPropertyVisible(parameter)) {
        return;
      }

      return ControlFactory.createEdmField(parameter, model, odataModel);
    },

    registerValidation: function(element) {
      // Register the view with the message manager
      sap.ui.getCore().getMessageManager().registerObject(element, true);
    },

    unregisterValidation: function(element) {
      sap.ui.getCore().getMessageManager().unregisterObject(element);
    }
  };

  return ActionUtil;
});
