sap.ui.define([], function() {
  "use strict";

  var namespace = "com.sap.gtt.app.generic";

  sap.ui.controller(namespace + ".ext.controller.ListReportExtension", {
    onInitSmartFilterBarExtension: function() {
      // this.enableAutoLoadTable();
    },

    enableAutoLoadTable: function() {
      var smartTable = this.byId("listReport");
      smartTable.setEnableAutoBinding(true);
    }
  });
});
