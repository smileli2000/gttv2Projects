sap.ui.define([
  "jquery.sap.global",
  "../../util/ActionUtil",
  "../../util/AnnotationUtil",
  "../../util/ControlFactory",
  "../../util/VersionUtil",
  "sap/ui/model/json/JSONModel",
  "sap/m/MessageBox",
  "sap/m/MessageToast"
], function(jQuery, ActionUtil, AnnotationUtil, ControlFactory, VersionUtil,
  JSONModel, MessageBox, MessageToast) {
  "use strict";

  var namespace = "com.sap.gtt.app.generic";

  sap.ui.controller(namespace + ".ext.controller.ObjectPageExtension", {
    onInit: function() {
      this.useODataActionContext = true;

      this.actionModelName = undefined;
      if (!this.useODataActionContext) {
        this.actionModelName = "action";

        var jsonModel = new JSONModel({});
        var view = this.getView();
        view.setModel(jsonModel, this.actionModelName);
      }
    },

    onBeforeRendering: function() {
      var view = this.getView();
      var odataModel = view.getModel();
      var metaModel = odataModel.getMetaModel();

      ControlFactory.init({
        odataModel: odataModel,
        modelName: this.actionModelName
      });
      AnnotationUtil.init({
        metaModel: metaModel
      });
    },

    /**
     * Use tab navigation mode instead of the default Anchor bar mode.
     */
    useTabNavigationMode: function() {
      var objectPage = this.getView().byId("objectPage");
      objectPage.setUseIconTabBar(true);
    },

    onRefreshAction: function() {
      this.refreshObjectPage();
    },

    refreshObjectPage: function() {
      var component = this.getOwnerComponent();
      var componentContainer = component.getComponentContainer();
      var elementBinding = componentContainer.getElementBinding();

      if (elementBinding) {
        var forceUpdate = true;
        elementBinding.refresh(forceUpdate);
      }
    },

    /**
     * Apply custom logic when a table is being refreshed.
     *
     * @param {sap.ui.base.Event} oEvent the event object
     */
    onBeforeRebindTableExtension: function(oEvent) {
      var table = oEvent.getSource();
      var tableId = table.getId();

      // hierarchy table
      if (tableId === this.getHierarchyTableId()) {
        var bindingParams = oEvent.getParameter("bindingParams");
        this.rebindHierarchyTable(bindingParams);
      }
    },

    /**
     * Replace the standard navigation from the object page.
     *
     * @param {sap.ui.base.Event} oEvent The event object
     * @returns {boolean} `true` if prevent further default navigation
     */
    onListNavigationExtension: function(oEvent) {
      var source = oEvent.getSource();
      var table = source.getParent();
      var bindingPath = table.getBindingPath("items");

      if (bindingPath === "processEvents") {
        var bindingContext = source.getBindingContext();
        var item = bindingContext.getObject();

        // for planned/overdue event we use internal navigation
        if (item.eventStatus === "PLANNED" || item.eventStatus === "OVERDUE") {
          // return false to trigger the default internal navigation
          // return false;

          // NOTE: show message box for now until backend can support single PED object
          var message = this.getText("eventNavigationNotSupportedError");
          MessageBox.information(message);
        } else {
          // for others we trigger external navigation
          var eventId = bindingContext.getProperty("event/id");
          var eventType = item.eventType;

          // if the event is internal, navigate to custom event
          if (eventType.indexOf("com.sap.gtt.core") === 0) {
            var entitySetName = AnnotationUtil.getEntityTypeShortName(eventType);
            var entityType = AnnotationUtil.getEntityTypeByEntitySet(entitySetName);
            eventType = AnnotationUtil.getEntityTypeFullQualifiedName(entityType);
          }

          var navigationController = this.extensionAPI.getNavigationController();
          navigationController.navigateExternal("eventDisplay", {
            eventType: eventType,
            id: eventId
          });
        }

        // return true is necessary to prevent further default navigation
        return true;
      }
    },

    onReportUnplannedEventAction: function(oEvent) {
      var actionButton = oEvent.getSource();
      var view = this.getView();
      var context = view.getBindingContext();

      if (!context) {
        return;
      }

      var functionImportName = "ReportUnplannedEvent";

      var component = this.getOwnerComponent().getAppComponent();
      var config = component.getManifestEntry("/sap.ui5/config");

      if (VersionUtil.compareVersion(config.compilerVersion, "1.2.0") >= 0) {
        var metaModel = actionButton.getModel().getMetaModel();
        var metaContext = metaModel.getMetaContext(actionButton.getBindingContext().getPath());
        var entityName = metaContext.getObject("name");
        functionImportName = jQuery.sap.formatMessage("{0}_{1}", entityName, functionImportName);
      }

      this.callAction(functionImportName, {
        title: actionButton.getText(),
        controller: this,
        entityContext: context,
        useODataActionContext: this.useODataActionContext,
        actionModelName: this.actionModelName,
        success: function() {
          var message = this.getText("actionReportUnplannedEventSuccess");
          MessageToast.show(message);
        }.bind(this),
        error: function() {
          var message = this.getText("actionReportUnplannedEventError");
          MessageBox.error(message);
        }.bind(this)
      });
    },

    onReportEventAction: function(oEvent) {
      var actionButton = oEvent.getSource();
      var table = actionButton.getParent().getParent().getTable();
      var tableId = table.getId();
      var contexts = this.extensionAPI.getSelectedContexts(tableId);

      if (contexts.length > 1) {
        MessageBox.error("Multi selection is currently not supported", {});
      } else {
        if (contexts.length === 0) {
          MessageBox.error("Please select an item", {});
        } else {
          var context = contexts[0];
          var functionImportName = "EditEvent";

          var component = this.getOwnerComponent().getAppComponent();
          var config = component.getManifestEntry("/sap.ui5/config");

          if (VersionUtil.compareVersion(config.compilerVersion, "1.2.0") >= 0) {
            var odataModel = table.getModel();
            var metaModel = odataModel.getMetaModel();
            var contextPath = odataModel.resolve(table.getBindingPath("items"), table.getBindingContext());
            var metaContext = metaModel.getMetaContext(contextPath);
            var entityName = metaContext.getObject("name");
            functionImportName = jQuery.sap.formatMessage("{0}_{1}", entityName, functionImportName);
          }

          this.callAction(functionImportName, {
            title: actionButton.getText(),
            controller: this,
            entityContext: context,
            useODataActionContext: this.useODataActionContext,
            actionModelName: this.actionModelName,
            success: function() {
              var message = this.getText("actionReportEventSuccess");
              MessageToast.show(message);
            }.bind(this),
            error: function() {
              var message = this.getText("actionReportEventError");
              MessageBox.error(message);
            }.bind(this)
          });
        }
      }
    },

    onRefreshHierarchyByEventAction: function(oEvent) {
      var actionButton = oEvent.getSource();
      var smartTable = actionButton.getParent().getParent();
      var table = smartTable.getTable();
      var tableId = table.getId();
      var contexts = this.extensionAPI.getSelectedContexts(tableId);

      if (contexts.length > 1) {
        MessageBox.error("Multi selection is currently not supported", {});
        return;
      }

      if (contexts.length === 0) {
        MessageBox.error("Please select an item", {});
        return;
      }

      // find hierarchy table
      var hierarchyTableId = this.getHierarchyTableId();
      var hierarchyTable = this.getSmartTable(hierarchyTableId);

      if (hierarchyTable) {
        // trigger rebind hierarchy table
        hierarchyTable.rebindTable();
      }
    },

    /**
     * Update custom query on the binding of hierarchy table
     *
     * @param {object} bindingParams The binding parameters to be changed
     */
    rebindHierarchyTable: function(bindingParams) {
      // get time from event table
      var eventTableId = this.getEventTableId();
      var contexts = this.extensionAPI.getSelectedContexts(eventTableId);

      if (contexts.length > 0) {
        var context = contexts[0];
        var actualEventTime = context.getObject("actualBusinessTimestampUTC");

        if (actualEventTime) {
          // add custom query
          this.addCustomQuery(bindingParams, {
            time: actualEventTime.getTime() // FIXME: change to `toJSON()` when backend API is changed to use ISO-8601 string for date time
          });

          return;
        }
      }

      // remove custom query
      this.removeCustomQuery(bindingParams, "time");
    },

    /**
     * Add custom query to binding
     *
     * @param {object} bindingParams The binding parameters to be changed
     * @param {object} customQuery The custom query object
     */
    addCustomQuery: function(bindingParams, customQuery) {
      var parameters = bindingParams.parameters;

      if (!parameters.custom) {
        parameters.custom = {};
      }

      jQuery.extend(parameters.custom, customQuery);
    },

    /**
     * Remove a custom query from binding
     *
     * @param {object} bindingParams The binding parameters to be changed
     * @param {string} name The custom query name to be removed
     */
    removeCustomQuery: function(bindingParams, name) {
      var parameters = bindingParams.parameters;
      var customQuery = parameters.custom;

      if (customQuery) {
        delete customQuery[name];
      }
    },

    getSmartTable: function(tableId) {
      var view = this.getView();
      var smartTable = view.byId(view.getLocalId(tableId));

      return smartTable;
    },

    getHierarchyTableId: function() {
      var smartTableId;

      var component = this.getOwnerComponent().getAppComponent();
      var config = component.getManifestEntry("/sap.ui5/config/hierarchy");
      if (config && config.navigationProperty) {
        var navigationProperty = config.navigationProperty;

        if (navigationProperty) {
          // "{viewId}--hierarchy::com.sap.vocabularies.UI.v1.LineItem::Table"
          var view = this.getView();
          smartTableId = view.createId(jQuery.sap.formatMessage("{0}::com.sap.vocabularies.UI.v1.LineItem::Table", navigationProperty));
        }
      }

      return smartTableId;
    },

    getEventTableId: function() {
      var smartTableId;

      var component = this.getOwnerComponent().getAppComponent();
      var config = component.getManifestEntry("/sap.ui5/config/event");
      if (config && config.navigationProperty) {
        var navigationProperty = config.navigationProperty;
        var lineItemQualifier = config.lineItemQualifier;

        if (navigationProperty) {
          // "{viewId}--processEvents::com.sap.vocabularies.UI.v1.LineItem::EpcisEvents::Table"
          var view = this.getView();
          smartTableId = view.createId(jQuery.sap.formatMessage("{0}::com.sap.vocabularies.UI.v1.LineItem::{1}::Table", navigationProperty, lineItemQualifier));
        }
      }

      return smartTableId;
    },

    /**
     * Navigates to the given intent
     *
     * @param {string} sOutbound The name of the outbound defined in the manifest
     * @param {object} [mParameters] map with parameters for the navigation. If no parameters are provided, default are the parameters defined in the manifest
     * @public
     */
    navigateExternal: function(sOutbound, mParameters) {
      var oManifestEntry = this.getOwnerComponent().getAppComponent().getManifestEntry("sap.app");
      var oOutbound = oManifestEntry.crossNavigation.outbounds[sOutbound];

      if (!oOutbound) {
        jQuery.sap.log.error("navigateExternal: mandatory parameter 'Outbound' is missing, or different from manifest entry");
        return;
      }

      if (mParameters) {
        oOutbound.parameters = mParameters;
      } else {
        // TODO: evaluate parameters
      }

      // trigger cross navigation
      var navService = sap.ushell.Container.getService("CrossApplicationNavigation");
      navService.toExternal({
        target: {
          semanticObject: oOutbound.semanticObject,
          action: oOutbound.action
        },
        params: oOutbound.parameters
      });
    },

    callAction: function(functionImportName, options) {
      ActionUtil.callAction(functionImportName, options).then(function(result) {
        result.executionPromise.then(function(data) {
          this.handleSuccess(data, options.success);
        }.bind(this), function(error) {
          this.handleError(error, options.error);
        }.bind(this));
      }.bind(this));
    },

    getText: function(key) {
      var view = this.getView();
      var resourceModel = view.getModel("i18n");
      var resourceBundle = resourceModel.getResourceBundle();
      var text = resourceBundle.getText(key);

      return text;
    },

    handleSuccess: function(data, callback) {
      var message = this.getText("actionSuccess");
      jQuery.sap.log.debug(message, JSON.stringify(data));

      if (callback) {
        callback(data);
      } else {
        MessageToast.show(message);
      }
    },

    handleError: function(error, callback) {
      var message = this.getText("actionError");
      jQuery.sap.log.error(message, JSON.stringify(error));

      if (callback) {
        callback(error);
      } else {
        MessageBox.error(message);
      }
    }
  });
});
