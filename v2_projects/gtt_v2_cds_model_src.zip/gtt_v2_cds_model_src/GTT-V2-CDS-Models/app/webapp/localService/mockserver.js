sap.ui.define([
  "jquery.sap.global",
  "sap/ui/core/util/MockServer"
], function(jQuery, MockServer) {
  "use strict";

  var oMockServer;
  var componentName;

  return {

    /**
     * Initializes the mock server.
     * You can configure the delay with the URL parameter "serverDelay".
     * The local mock data in this folder is returned instead of the real data for testing.
     * @public
     */
    init: function(options) {
      var manifest = this.loadManifest(options.manifestUrl);
      componentName = manifest["sap.app"].id; // com.sap.gtt.app.delivery

      var oUriParameters = jQuery.sap.getUriParameters();

      // data source
      var oDataSource = manifest["sap.app"].dataSources;
      var oMainDataSource = oDataSource.mainService;
      var sMockServerUrl = this.getRelativePath(oMainDataSource.uri); // "/odata/v1/com.sap.gtt.app.delivery/"

      // ensure there is a trailing slash
      sMockServerUrl = (/.*\/$/).test(sMockServerUrl)
        ? sMockServerUrl
        : sMockServerUrl + "/";

      oMockServer = new MockServer({rootUri: sMockServerUrl});

      // configure mock server with a delay of 1s
      MockServer.config({
        autoRespond: true,
        autoRespondAfter: oUriParameters.get("serverDelay") || 1000
      });

      // load local mock data
      var metadataLocalUri = oMainDataSource.settings.localUri;
      var sMetadataUrl = this.getRelativePath(metadataLocalUri);

      var mockdataLocalUri = metadataLocalUri.replace("metadata.xml", "mockdata");
      var sJsonFilesUrl = this.getRelativePath(mockdataLocalUri);

      oMockServer.simulate(sMetadataUrl, {
        sMockdataBaseUrl: sJsonFilesUrl,
        bGenerateMissingMockData: true
      });

      // handle requests
      var aRequests = oMockServer.getRequests();
      var fnResponse = function(iErrCode, sMessage, aRequest) {
        aRequest.response = function(oXhr) {
          oXhr.respond(iErrCode, {
            "Content-Type": "text/plain;charset=utf-8"
          }, sMessage);
        };
      };

      // handling the metadata error test
      if (oUriParameters.get("metadataError")) {
        aRequests.forEach(function(aEntry) {
          if (aEntry.path.toString().indexOf("$metadata") > -1) {
            fnResponse(500, "metadata Error", aEntry);
          }
        });
      }

      // Handling request errors
      var sErrorParam = oUriParameters.get("errorType");
      var iErrorCode = sErrorParam === "badRequest" ? 400 : 500;
      var pages = manifest["sap.ui.generic.app"].pages;
      var key = Object.keys(pages)[0];
      var listReportPage = pages[key];
      var entitySet = listReportPage.entitySet;

      if (sErrorParam) {
        aRequests.forEach(function(aEntry) {
          if (aEntry.path.toString().indexOf(entitySet) > -1) {
            fnResponse(iErrorCode, sErrorParam, aEntry);
          }
        });
      }

      // handle FunctionImport
      function getUrlParamFunc(urlParams) {
        return function(name) {
          var value = urlParams.get(name);
          return stripQuote(value);
        };
      }

      function stripQuote(str) {
        var value = str;
        var matches = (/'(.*)'/).exec(str);
        if (matches && matches.length > 1) {
          value = matches[1];
        }

        return value;
      }

      var functionImportNames = ["ReportUnplannedEvent", "EditEvent"];
      functionImportNames.forEach(function(functionImportName) {
        var request = {
          method: "POST",
          path: new RegExp(functionImportName + "(.*)"),
          response: function(oXhr) {
            jQuery.sap.log.debug("Incoming request for " + functionImportName + ": " + oXhr.url);
            var urlParams = jQuery.sap.getUriParameters(oXhr.url);
            var getUrlParam = getUrlParamFunc(urlParams);

            var result = {
              "d": {}
            };
            result.d[functionImportName] = getUrlParam("eventCode");

            oXhr.respondJSON(200, {}, result);
            return true;
          }
        };

        aRequests.push(request);
      });

      oMockServer.setRequests(aRequests);

      oMockServer.start();

      jQuery.sap.log.info("Running the app with mock data");

      // annotations
      var aAnnotations = oMainDataSource.settings.annotations || [];
      aAnnotations.forEach(function(sAnnotationName) {
        var oAnnotation = oDataSource[sAnnotationName];

        if (oAnnotation.uri === oAnnotation.settings.localUri) {
          return;
        }

        var sUri = this.getRelativePath(oAnnotation.uri);
        var sLocalUri = this.getRelativePath(oAnnotation.settings.localUri);

        // annotations
        new MockServer({
          rootUri: sUri,
          requests: [
            {
              method: "GET",
              path: /(?:\?.+)?/, // "annotations.xml?sap-language=EN"
              response: function(oXhr) {
                jQuery.sap.require("jquery.sap.xml");

                var oAnnotations = jQuery.sap.sjax({url: sLocalUri, dataType: "xml"}).data;

                oXhr.respondXML(200, {}, jQuery.sap.serializeXML(oAnnotations));
                return true;
              }
            }
          ]
        }).start();
      }, this);
    },

    /**
     * @public returns the mockserver of the app, should be used in integration tests
     * @returns {sap.ui.core.util.MockServer}
     */
    getMockServer: function() {
      return oMockServer;
    },

    getComponentName: function() {
      return componentName;
    },

    loadManifest: function(manifestUrl) {
      var manifest = jQuery.sap.syncGetJSON(manifestUrl).data;

      return manifest;
    },

    getRelativePath: function(path) {
      // start with protocal, keep no changed
      if (path.search("http:") === 0 || path.search("https:") === 0) {
        return path;
      }

      // start with slash, it means root path
      if (path.search("/") === 0) {
        return path;
      }

      // service/odata/v1/com.sap.service/
      // service/odata/v1/service.svc/
      // service/odata/v1/service.svc
      var relativePath = jQuery.sap.getModulePath(componentName) + "/" + path;

      return relativePath;
    }
  };
});
