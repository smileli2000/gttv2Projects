package com.sap.gtt.v2.core.odata.exception;

import com.sap.gtt.v2.exception.BaseRuntimeException;
import org.apache.http.HttpStatus;

public class ODataServiceException extends BaseRuntimeException {
    private static final long serialVersionUID = 1L;

    public static final String MESSAGE_CODE = ODataServiceException.class.getName();
    public static final String MESSAGE_CODE_ERROR_UNKNOWN_MODEL_NAME = ODataServiceException.class.getName() + ".UnknownModelName";
    public static final String MESSAGE_CODE_ERROR_METADATA_BACKLINK_NOT_FOUND = ODataServiceException.class.getName() + ".MetadataBacklinkNotFound";
    public static final String MESSAGE_CODE_ERROR_WRONG_FILTER_EXPRESSION_FORMAT = ODataServiceException.class.getName() + ".WrongFilterExpressionFormat";
    public static final String MESSAGE_CODE_ERROR_METADATA_CORETABLE_JOINKEY_NOT_FOUND = ODataServiceException.class.getName() + ".MetadataCoreTableJoinKeyNotFound";
    public static final String MESSAGE_CODE_ERROR_NAVIGATION_PROPERTY_NOT_FOUND = ODataServiceException.class.getName() + ".NavigationPropertyNotFound";
    public static final String MESSAGE_CODE_ERROR_NO_DATA_FOUND = ODataServiceException.class.getName() + ".NoDataFound";

    public ODataServiceException(String internalMessage, Throwable cause, String messageCode) {
        super(internalMessage, cause, messageCode, new Object[]{});
    }

    public ODataServiceException(String internalMessage, Throwable cause, String messageCode, Object[] localizedMsgParams) {
        super(internalMessage, cause, messageCode, localizedMsgParams);
    }

    public ODataServiceException(String messageCode) {
        super(messageCode, new Object[]{});
    }

    public ODataServiceException(Throwable cause) {
        super(cause.getMessage(), cause, MESSAGE_CODE, new Object[]{});
    }

    public ODataServiceException(String messageCode, Object[] localizedMsgParams) {
        super(messageCode, localizedMsgParams);
    }

    @Override
    public int getHttpStatus() {
        return HttpStatus.SC_BAD_REQUEST;
    }
}
