package com.sap.gtt.v2.core.odata.domain;

import java.util.Objects;

public class Table {

    private String tableName;
    private String entityName;

    public Table(String tableName, String entityName) {
        this.tableName = tableName;
        this.entityName = entityName;
    }

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public String getEntityName() {
        return entityName;
    }

    public void setEntityName(String entityName) {
        this.entityName = entityName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Table table = (Table) o;
        return Objects.equals(tableName, table.tableName) &&
                Objects.equals(entityName, table.entityName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(tableName, entityName);
    }

    @Override
    public String toString() {
        return "Table{" +
                "tableName='" + tableName + '\'' +
                ", entityName='" + entityName + '\'' +
                '}';
    }
}
