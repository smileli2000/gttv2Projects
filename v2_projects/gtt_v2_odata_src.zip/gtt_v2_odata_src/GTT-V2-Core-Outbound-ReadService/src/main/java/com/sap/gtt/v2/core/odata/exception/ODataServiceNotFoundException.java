package com.sap.gtt.v2.core.odata.exception;

import org.apache.http.HttpStatus;

public class ODataServiceNotFoundException extends ODataServiceException{

    public static final String MESSAGE_CODE_ERROR_METADATA_NOT_FOUND = ODataServiceNotFoundException.class.getName() + ".MetadataNotFound";

    public ODataServiceNotFoundException(String internalMessage, Throwable cause, String messageCode, Object[] localizedMsgParams){
        super(internalMessage, cause, messageCode, localizedMsgParams);
    }

    public ODataServiceNotFoundException(String messageCode) {
        super(messageCode, new Object[]{});
    }

    public ODataServiceNotFoundException(String messageCode, Object[] localizedMsgParams) {
        super(messageCode, localizedMsgParams);
    }

    @Override
    public int getHttpStatus() {
        return HttpStatus.SC_NOT_FOUND;
    }

}
