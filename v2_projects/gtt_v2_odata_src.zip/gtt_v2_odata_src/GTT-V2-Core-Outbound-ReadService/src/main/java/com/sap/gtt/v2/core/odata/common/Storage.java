package com.sap.gtt.v2.core.odata.common;

import com.sap.gtt.v2.core.odata.repository.DefaultSearchClient;

public enum Storage {
    DEFAULT(DefaultSearchClient.class);// Hana as default data base implementation

    private Class<?> clazz;

    Storage(Class<?> clazz) {
        this.clazz = clazz;
    }

    public String getHandler() {
        return clazz.getSimpleName();
    }

}
