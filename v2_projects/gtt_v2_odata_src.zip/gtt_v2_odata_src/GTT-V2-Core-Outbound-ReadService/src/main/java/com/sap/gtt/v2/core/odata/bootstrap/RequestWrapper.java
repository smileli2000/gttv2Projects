package com.sap.gtt.v2.core.odata.bootstrap;

import com.sap.gtt.v2.core.odata.common.Constants;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

public class RequestWrapper extends HttpServletRequestWrapper {

    public RequestWrapper(HttpServletRequest request) {
        super(request);
    }

    @Override
    public String getPathInfo() {
        return normalize(super.getPathInfo());
    }

    @Override
    public String getRequestURI() {
        return normalize(super.getRequestURI());
    }

    @Override
    public String getContextPath() {
        return normalize(super.getContextPath());
    }

    private String normalize(String uri) {
        String u = uri == null ? "" : uri;
        Object model = getAttribute(Constants.MODEL_ATTRIBUTE_KEY);
        String replaced = u;
        if (model != null) {
            int start = u.indexOf(model.toString());
            if (start >= 0) {
                replaced = u.substring(0, start).concat(u.substring(start + model.toString().length()));
            }
        }

        return replaced;
    }
}

