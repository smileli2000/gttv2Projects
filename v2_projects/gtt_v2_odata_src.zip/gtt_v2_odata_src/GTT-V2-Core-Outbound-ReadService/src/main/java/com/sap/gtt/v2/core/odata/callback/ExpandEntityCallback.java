package com.sap.gtt.v2.core.odata.callback;

import com.sap.gtt.v2.core.odata.utils.ODataUtils;
import com.sap.gtt.v2.exception.InternalErrorException;
import org.apache.olingo.odata2.api.ODataCallback;
import org.apache.olingo.odata2.api.edm.EdmEntitySet;
import org.apache.olingo.odata2.api.edm.EdmException;
import org.apache.olingo.odata2.api.edm.EdmNavigationProperty;
import org.apache.olingo.odata2.api.ep.EntityProviderWriteProperties;
import org.apache.olingo.odata2.api.ep.callback.OnWriteEntryContent;
import org.apache.olingo.odata2.api.ep.callback.WriteEntryCallbackContext;
import org.apache.olingo.odata2.api.ep.callback.WriteEntryCallbackResult;
import org.apache.olingo.odata2.api.uri.KeyPredicate;

import java.net.URI;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public class ExpandEntityCallback implements OnWriteEntryContent {

    private URI serviceRoot;

    public ExpandEntityCallback() {
        super();
    }

    public void setServiceRoot(URI serviceRoot) {
        this.serviceRoot = serviceRoot;
    }

    @Override
    public WriteEntryCallbackResult retrieveEntryResult(WriteEntryCallbackContext context) {
        WriteEntryCallbackResult result = new WriteEntryCallbackResult();

        Map<String, ODataCallback> callbacks = context.getCurrentWriteProperties().getCallbacks();
        EdmNavigationProperty property = context.getNavigationProperty();
        String propertyName = null;
        Map<String, Object> entryData = context.getEntryData();

        try {
            propertyName = property.getName();
            EdmEntitySet target = context.getSourceEntitySet().getRelatedEntitySet(property);

            Map<String, Object> keys = ODataUtils.extractAssociationKey(property, context.getEntryData());

            if (!keys.isEmpty() && entryData.get(propertyName) != null) {
                Map<String, Object> naviData;
                if(entryData.get(propertyName) instanceof Map){
                    naviData = (Map<String, Object>)entryData.get(propertyName);
                } else {
                    naviData = ((List<Map<String, Object>>)entryData.get(propertyName)).get(0);
                }
                List<KeyPredicate> transformed = ODataUtils.mapToKeyPredicateList(keys, target.getEntityType());
                String naviKey = transformed.get(0).getProperty().getName();
                if (naviData.containsKey(naviKey) && naviData.get(naviKey) != null) {
                    result.setEntryData(naviData);
                } else {
                    result.setEntryData(Collections.emptyMap());
                }
            } else {
                result.setEntryData(Collections.emptyMap());
            }

        } catch (EdmException e) {
            throw new InternalErrorException(e);
        }

        EntityProviderWriteProperties inlineProperties = EntityProviderWriteProperties.serviceRoot(this.serviceRoot)
                .expandSelectTree(context.getCurrentExpandSelectTreeNode())
                .callbacks(callbacks)
                .build();

        result.setInlineProperties(inlineProperties);
        return result;
    }
}
