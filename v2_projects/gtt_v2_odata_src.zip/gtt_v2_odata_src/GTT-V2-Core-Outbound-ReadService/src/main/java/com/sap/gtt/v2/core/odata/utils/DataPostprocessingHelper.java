package com.sap.gtt.v2.core.odata.utils;

import com.sap.gtt.v2.core.domain.metadata.MetadataConstants;
import com.sap.gtt.v2.core.domain.metadata.MetadataEntityElement;
import com.sap.gtt.v2.core.management.metadata.IMetadataManagement;
import com.sap.gtt.v2.core.odata.common.Tuple;
import com.sap.gtt.v2.core.odata.domain.ExpandEntityInfo;
import com.sap.gtt.v2.exception.InternalErrorException;
import org.apache.olingo.odata2.api.edm.EdmEntitySet;
import org.apache.olingo.odata2.api.edm.EdmException;
import org.apache.olingo.odata2.api.edm.EdmType;
import org.apache.olingo.odata2.core.edm.EdmDateTimeOffset;
import org.apache.olingo.odata2.core.edm.EdmGuid;

import java.sql.Timestamp;
import java.util.*;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import static com.sap.gtt.v2.core.odata.utils.ODataUtils.*;

public class DataPostprocessingHelper {

    private IMetadataManagement metadataService;
    private String model;

    private Map<Class<? extends EdmType>, Function> dataTypeFunctionMap = new HashMap<>();

    public DataPostprocessingHelper(IMetadataManagement metadataService, String model) {
        this.metadataService = metadataService;
        this.model = model;
        this.dataTypeFunctionMap.put(EdmGuid.class, replaceStringWithUUID());
        this.dataTypeFunctionMap.put(EdmDateTimeOffset.class, replaceTimestampWithLong());

    }

    public Function<List<Map<String, Object>>, List<Map<String, Object>>> replaceDataType(EdmEntitySet entitySet, List<List<Tuple<String, String>>> expand) {
        return (replacedData) -> {
            try {
                // covert String to UUID in GUID column
                List<String> guidCol = findMainEntityColByType(entitySet, EdmGuid.class);
                List<List<Tuple<String, List<String>>>> naviGuidColList = findNaviEntityColByType(expand, MetadataConstants.CdsDataType.CDS_UUID);

                // covert Timestamp to Long in DateTimeOffset column
                List<String> dateTimeOffsetCol = findMainEntityColByType(entitySet, EdmDateTimeOffset.class);
                List<List<Tuple<String, List<String>>>> naviDateTimeOffsetColList = findNaviEntityColByType(expand, MetadataConstants.CdsDataType.CDS_TIMESTAMP);


                replaceCol(guidCol, naviGuidColList, replacedData, EdmGuid.class);
                replaceCol(dateTimeOffsetCol, naviDateTimeOffsetColList, replacedData, EdmDateTimeOffset.class);

                return replacedData;
            } catch (EdmException e) {
                throw new InternalErrorException(e);
            }
        };
    }

    private List<String> findMainEntityColByType(EdmEntitySet entitySet, Class<? extends EdmType> clazz) throws EdmException {
        return entitySet.getEntityType().getPropertyNames().stream().filter(col -> {
            try {
                return entitySet.getEntityType().getProperty(col).getType().getClass().isAssignableFrom(clazz);
            } catch (EdmException e) {
                throw new InternalError(e);
            }
        }).collect(Collectors.toList());
    }

    private List<List<Tuple<String, List<String>>>> findNaviEntityColByType(List<List<Tuple<String, String>>> expand, MetadataConstants.CdsDataType dataType) {
        List<List<Tuple<String, List<String>>>> naviEntityColList = new ArrayList<>();
        if (expand != null) {
            expand.stream().forEach(ele -> {
                List<Tuple<String, List<String>>> naviEntityCol = new ArrayList<>();
                ele.stream().forEach(col -> {
                    String naviCol = col.getK1();
                    String naviEntity = col.getK2();
                    List<MetadataEntityElement> allColumnsOfExpandEntity = getAllColumnsOfEntity(naviEntity, metadataService, model);
                    List<String> naviTableCol = findAllColumnsOfGivenType(allColumnsOfExpandEntity, dataType);
                    naviEntityCol.add(new Tuple(naviCol, naviTableCol));
                });
                naviEntityColList.add(naviEntityCol);
            });
        }

        return naviEntityColList;
    }

    public Function<List<Map<String, Object>>, List<Map<String, Object>>> convertJdbcResToNestedList(String mainEntityName,
                                                                                                     List<List<Tuple<String, String>>> expand) {
        return (sqlExecutionList) -> {
            if (sqlExecutionList != null && !sqlExecutionList.isEmpty()) {
                Map<String, ExpandEntityInfo> expandEntityInfoMap = getExpandPropertyAndEntity(expand);
                Map<String, List<Map<String, Object>>> entityNamePropertiesValueMap = getEntityPropertiesValue(sqlExecutionList, expandEntityInfoMap,
                        mainEntityName);
                return entityNamePropertiesValueMap.get(mainEntityName);
            }
            return Collections.EMPTY_LIST;
        };
    }

    private List<Map<String, Object>> replaceCol(List<String> replacedCol, List<List<Tuple<String, List<String>>>> naviReplacedColList,
                                                 List<Map<String, Object>> replacedData, Class<? extends EdmType> dataType) {
        Function functionDef = dataTypeFunctionMap.get(dataType);
        if (!replacedCol.isEmpty()) {
            replacedCol.forEach(col ->
                    replacedData.forEach(d -> {
                        if (d.get(col) != null && !"\\?".equals(d.get(col))) {
                            d.put(col, functionDef.apply(d.get(col)));
                        }
                    })
            );
        }

        if (!naviReplacedColList.isEmpty()) {
            naviReplacedColList.forEach(naviGuidCol ->
                    replacedData.forEach(d -> {
                        String naviKey = naviGuidCol.get(0).getK1();
                        if (d.get(naviKey) != null && d.get(naviKey) instanceof List) {
                            d.put(naviKey, replaceNaviCol((List<Map<String, Object>>) d.get(naviKey), naviGuidCol, functionDef));
                        }
                    }));
        }

        return replacedData;
    }

    private Function<Object, UUID> replaceStringWithUUID() {
        return (data) -> {
            if (data instanceof String) {
                return UUID.fromString((String) data);
            } else if (data instanceof UUID) {
                return (UUID) data;
            }
            throw new InternalErrorException(String.format("Wrong data type for %s", data));
        };
    }

    private Function<Object, Long> replaceTimestampWithLong() {
        return (data) -> {
            if (data instanceof Timestamp) {
                return ((Timestamp) data).getTime();
            } else if (data instanceof Long) {
                return (Long) data;
            }
            throw new InternalErrorException(String.format("Wrong data type for %s", data));
        };
    }

    private List<Map<String, Object>> replaceNaviCol(List<Map<String, Object>> data, List<Tuple<String,
            List<String>>> naviReplacedCol, Function functionDef) {
        if (naviReplacedCol.size() != 0) {
            List<String> naviCol = naviReplacedCol.get(0).getK2();
            List<Map<String, Object>> replacedData = new ArrayList<>();
            data.forEach(d -> {
                naviCol.forEach(col -> {
                    if (d.get(col) != null && !"\\?".equals(d.get(col))) {
                        d.put(col, functionDef.apply(d.get(col)));
                    }
                });
                if (naviReplacedCol.size() > 1) {
                    String nestedNaviKey = naviReplacedCol.get(1).getK1();
                    List<Tuple<String, List<String>>> nestedNaviReplacedCol = naviReplacedCol.subList(1, naviReplacedCol.size());
                    if (d.get(nestedNaviKey) != null && d.get(nestedNaviKey) instanceof List) {
                        List<Map<String, Object>> nestedNaviColList = replaceNaviCol((List<Map<String, Object>>) d.get(nestedNaviKey), nestedNaviReplacedCol, functionDef);
                        d.put(nestedNaviKey, nestedNaviColList);
                    }
                }
                replacedData.add(d);
            });
            return replacedData;
        }
        return data;
    }

    private Map<String, ExpandEntityInfo> getExpandPropertyAndEntity(List<List<Tuple<String, String>>> expand) {
        Map<String, ExpandEntityInfo> expandEntityInfoMap = new HashMap<>();
        if (expand != null) {
            expand.forEach(expandEntities -> {
                for (int j = 0; j < expandEntities.size(); j++) {
                    Tuple expandNodeInfo = expandEntities.get(j);
                    String propertyName = (String) expandNodeInfo.getK1();
                    String entityName = (String) expandNodeInfo.getK2();
                    String childPropertyName = null;
                    String childEntityName = null;
                    String parentPropertyName = null;
                    String parentEntityName = null;
                    if (j + 1 < expandEntities.size()) {
                        Tuple expandChildNodeInfo = expandEntities.get(j + 1);
                        childPropertyName = (String) expandChildNodeInfo.getK1();
                        childEntityName = (String) expandChildNodeInfo.getK2();
                    }
                    if (j > 0) {
                        Tuple expandParentNodeInfo = expandEntities.get(j - 1);
                        parentPropertyName = (String) expandParentNodeInfo.getK1();
                        parentEntityName = (String) expandParentNodeInfo.getK2();
                    }
                    ExpandEntityInfo expandEntityInfo = new ExpandEntityInfo();
                    expandEntityInfo.setEntityName(entityName);
                    expandEntityInfo.setPropertyName(propertyName);
                    expandEntityInfo.setChildPropertyName(childPropertyName);
                    expandEntityInfo.setChildEntityName(childEntityName);
                    expandEntityInfo.setParentEntityName(parentEntityName);
                    expandEntityInfo.setParentPropertyName(parentPropertyName);
                    expandEntityInfoMap.put(entityName, expandEntityInfo);
                }
            });
        }
        return expandEntityInfoMap;
    }

    private Optional<Map<String, Object>> isExisted(List<Map<String, Object>> existedData, Map<String, Object> pkValues) {
        Predicate<Map<String, Object>> isExistedPredicate = (data) -> true;
        Set<Map.Entry<String, Object>> set = pkValues.entrySet();
        for (Map.Entry<String, Object> keyValue : set) {
            isExistedPredicate = isExistedPredicate.and(isEqual(keyValue.getKey(), keyValue.getValue()));
        }

        Predicate<Map<String, Object>> finalIsExistedPredicate = isExistedPredicate;
        return existedData.stream().filter(ele -> finalIsExistedPredicate.test(ele)).findAny();
    }

    private Predicate<Map<String, Object>> isEqual(Object key, Object value) {
        return (data) -> !notEqual(data.get(key), value);
    }

    private Map<String, List<String>> getPrimaryKeysOfEntities(Map<String, ExpandEntityInfo> expandEntityInfoMap,
                                                               String mainEntityName) {
        Map<String, List<String>> primaryKeysOfEntity = new LinkedHashMap<>();
        primaryKeysOfEntity.put(mainEntityName, getEntityPrimaryKey(mainEntityName, model, metadataService));
        expandEntityInfoMap.entrySet().forEach(ele -> {
            List<String> primaryKeys = getEntityPrimaryKey(ele.getKey(), model, metadataService);
            primaryKeysOfEntity.put(ele.getKey(), primaryKeys);
        });

        return primaryKeysOfEntity;
    }

    private Map<String, List<Map<String, Object>>> getEntityPropertiesValue(List<Map<String, Object>> sqlExecutionList, Map<String, ExpandEntityInfo> expandEntityInfoMap,
                                                                            String mainEntityName) {
        Map<String, List<String>> entityNamePrimaryKeyMap = getPrimaryKeysOfEntities(expandEntityInfoMap, mainEntityName);
        Map<String, List<Map<String, Object>>> nestedResForEntities = new HashMap<>();

        sqlExecutionList.forEach(sqlExecutionMap -> {

            Map<String, Map<String, Object>> rowObjectMap = new LinkedHashMap<>();

            // warp sql execution result into rowObjectMap with different entities as keys
            generateRowObjectMap(sqlExecutionMap, rowObjectMap);

            // compare rowObjectMap with existed result and find the lastedRowObjectMap
            Map<String, Map<String, Object>> lastedRowObjectMap = new LinkedHashMap<>();
            generateLastedRowObjectMap(rowObjectMap, entityNamePrimaryKeyMap, nestedResForEntities, lastedRowObjectMap);

            // nested lastedRowObjectedMap
            ListIterator<Map.Entry<String, Map<String, Object>>> i = new ArrayList<>(
                    lastedRowObjectMap.entrySet()).listIterator(lastedRowObjectMap.size());
            while (i.hasPrevious()) {
                Map.Entry<String, Map<String, Object>> entry = i.previous();
                String currentEntityName = entry.getKey();
                if (expandEntityInfoMap != null && expandEntityInfoMap.get(currentEntityName) != null) {
                    nestedLastedRowObjectMap(mainEntityName, currentEntityName, lastedRowObjectMap, entityNamePrimaryKeyMap, expandEntityInfoMap);
                }
            }

            // combine lastedRowObjectedMap into existed result
            combineLastedRowObjectMap(lastedRowObjectMap, entityNamePrimaryKeyMap, nestedResForEntities);
        });
        return nestedResForEntities;
    }

    private void combineLastedRowObjectMap(Map<String, Map<String, Object>> lastedRowObjectMap, Map<String, List<String>> entityNamePrimaryKeyMap,
                                           Map<String, List<Map<String, Object>>> nestedResForEntities) {
        lastedRowObjectMap.entrySet().stream().forEach(entity -> {
            String entityName = entity.getKey();
            Map<String, Object> entityValueMap = entity.getValue();

            if (nestedResForEntities.get(entityName) == null) {
                List<Map<String, Object>> currentEntityList = new ArrayList<>();
                currentEntityList.add(entityValueMap);
                nestedResForEntities.put(entityName, currentEntityList);
            } else {
                List<Map<String, Object>> currentEntityList = nestedResForEntities.get(entityName);

                Map<String, Object> pkValues = getPKValues(entityNamePrimaryKeyMap, entityName, entityValueMap);
                if (!isExisted(currentEntityList, pkValues).isPresent()) {
                    currentEntityList.add(entityValueMap);
                    nestedResForEntities.put(entityName, currentEntityList);
                } else {
                    Map<String, Object> existedData = isExisted(currentEntityList, pkValues).get();
                    currentEntityList.set(currentEntityList.indexOf(existedData), entityValueMap);
                    nestedResForEntities.put(entityName, currentEntityList);
                }
            }
        });

    }

    private void generateLastedRowObjectMap(Map<String, Map<String, Object>> rowObjectMap, Map<String, List<String>> entityNamePrimaryKeyMap,
                                            Map<String, List<Map<String, Object>>> nestedResForEntities, Map<String, Map<String, Object>> lastedRowObjectMap) {
        rowObjectMap.entrySet().stream().forEach(entity -> {
            String entityName = entity.getKey();
            Map<String, Object> entityValueMap = entity.getValue();
            Map<String, Object> pkValues = getPKValues(entityNamePrimaryKeyMap, entityName, entityValueMap);
            pkValues.entrySet().stream().forEach(pkValue -> {
                // null primary key check
                if (pkValue.getValue() != null) {
                    if (nestedResForEntities.get(entityName) == null) {
                        lastedRowObjectMap.put(entityName, entity.getValue());
                    } else {
                        Optional<Map<String, Object>> duplicatedData = isExisted(nestedResForEntities.get(entityName), pkValues);
                        if (duplicatedData.isPresent()) {
                            lastedRowObjectMap.put(entityName, duplicatedData.get());
                        } else {
                            lastedRowObjectMap.put(entityName, entity.getValue());
                        }
                    }
                }
            });
        });
    }

    private void generateRowObjectMap(Map<String, Object> sqlExecutionMap, Map<String, Map<String, Object>> rowObjectMap) {
        sqlExecutionMap.entrySet().stream().forEach(ele -> {
            String[] sqlProperty = ele.getKey().split("\\.");
            String entityName = sqlProperty[0];
            String propertyName = sqlProperty[1];
            Object value = ele.getValue();

            if (rowObjectMap.get(entityName) != null) {
                Map<String, Object> entityProperties = rowObjectMap.get(entityName);
                entityProperties.put(propertyName, value);
            } else {
                Map<String, Object> entityProperties = new HashMap<>();
                entityProperties.put(propertyName, value);
                rowObjectMap.put(entityName, entityProperties);
            }
        });
    }

    private void nestedLastedRowObjectMap(String mainEntityName, String currentEntityName, Map<String, Map<String, Object>> lastedRowObjectMap,
                                          Map<String, List<String>> entityNamePrimaryKeyMap, Map<String, ExpandEntityInfo> expandEntityInfoMap) {

        ExpandEntityInfo expandEntityInfo = expandEntityInfoMap.get(currentEntityName);
        String parentEntityName = expandEntityInfo.getParentEntityName();
        //note: propertyNameInParentEntity is the propertyName of the composition object in the parent node.(for example: plannedEvents)
        String propertyNameInParentEntity = expandEntityInfo.getPropertyName();
        if (notEqual(currentEntityName, mainEntityName)) {
            if (parentEntityName == null || parentEntityName.isEmpty()) {
                parentEntityName = mainEntityName;
            }
            Map<String, Object> parentEntityMap = lastedRowObjectMap.get(parentEntityName);
            Map<String, Object> currentEntityMap = lastedRowObjectMap.get(currentEntityName);

            if (parentEntityMap.isEmpty()) {
                return;
            }

            if (parentEntityMap.get(propertyNameInParentEntity) == null) {
                List<Map<String, Object>> currentEntityList = new ArrayList<>();
                currentEntityList.add(currentEntityMap);
                parentEntityMap.put(propertyNameInParentEntity, currentEntityList);
                lastedRowObjectMap.put(parentEntityName, parentEntityMap);
            } else {
                Map<String, Object> pkValues = getPKValues(entityNamePrimaryKeyMap, currentEntityName, currentEntityMap);

                List<Map<String, Object>> currentEntityList = (List<Map<String, Object>>) parentEntityMap.get(propertyNameInParentEntity);
                if (!isExisted(currentEntityList, pkValues).isPresent()) {
                    currentEntityList.add(currentEntityMap);
                    parentEntityMap.put(propertyNameInParentEntity, currentEntityList);
                    lastedRowObjectMap.put(parentEntityName, parentEntityMap);
                }
            }
        }
    }

    private Map<String, Object> getPKValues(Map<String, List<String>> entityNamePrimaryKeyMap, String currentEntityName,
                                            Map<String, Object> currentEntityMap) {
        List<String> primaryKeys;
        if (entityNamePrimaryKeyMap.get(currentEntityName) != null) {
            primaryKeys = entityNamePrimaryKeyMap.get(currentEntityName);
        } else {
            primaryKeys = getEntityPrimaryKey(currentEntityName, model, metadataService);
            entityNamePrimaryKeyMap.put(currentEntityName, primaryKeys);
        }
        Map<String, Object> pkValues = new HashMap();
        primaryKeys.forEach(key -> pkValues.put(key, currentEntityMap.get(key)));

        return pkValues;
    }
}
