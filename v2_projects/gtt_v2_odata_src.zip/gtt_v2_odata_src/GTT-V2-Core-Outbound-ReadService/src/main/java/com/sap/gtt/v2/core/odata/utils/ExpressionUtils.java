package com.sap.gtt.v2.core.odata.utils;

import com.sap.gtt.v2.core.domain.metadata.*;
import com.sap.gtt.v2.core.management.metadata.IMetadataManagement;
import com.sap.gtt.v2.core.odata.common.Constants;
import com.sap.gtt.v2.core.odata.common.Tuple;
import com.sap.gtt.v2.core.odata.domain.Column;
import com.sap.gtt.v2.core.odata.domain.Expression;
import com.sap.gtt.v2.core.odata.domain.ExpressionDbEdmMapping;
import com.sap.gtt.v2.core.odata.domain.Table;
import com.sap.gtt.v2.core.odata.exception.ODataServiceException;
import com.sap.gtt.v2.exception.InternalErrorException;
import com.sap.gtt.v2.util.DBUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.*;
import java.util.stream.Collectors;

import static com.sap.gtt.v2.core.odata.common.Constants.CORE_PREFIX;
import static com.sap.gtt.v2.core.odata.common.Constants.DEFAULT_WINDOW_SIZE;
import static com.sap.gtt.v2.core.odata.exception.ODataServiceException.MESSAGE_CODE_ERROR_METADATA_BACKLINK_NOT_FOUND;
import static com.sap.gtt.v2.core.odata.exception.ODataServiceException.MESSAGE_CODE_ERROR_METADATA_CORETABLE_JOINKEY_NOT_FOUND;
import static com.sap.gtt.v2.core.odata.utils.ODataUtils.copy;

public class ExpressionUtils {

    private ExpressionUtils() {

    }

    public static List<String> combineColumnWithTableByDot(List<Column> tableColumn) {
        if (tableColumn != null) {
            List<String> columnList = new ArrayList<>();
            tableColumn.forEach(col -> {
                String entity = col.getTable().getEntityName();
                String columnName = col.getName();
                if (!entity.startsWith(CORE_PREFIX)) {
                    columnList.add(String.format("%s.%s AS \"%s.%s\"", entity, columnName, entity, columnName));
                } else {
                    columnList.add(String.format("%s.%s AS \"%s.%s\"", entity, columnName, entity.replaceFirst(CORE_PREFIX, ""), columnName));
                }
            });
            return columnList;
        }
        return Collections.emptyList();
    }

    public static String combineListWithComma(List<String> col) {
        return col.stream().collect(Collectors.joining(", "));
    }

    public static String combineAllTableName(List<Table> joinTableName) {
        List<String> tableList = new ArrayList<>();
        if (joinTableName == null || joinTableName.isEmpty()) {
            return null;
        } else {
            joinTableName.stream().forEach(ele -> tableList.add(String.format("%s %s", ele.getTableName(), ele.getEntityName())));
            return String.format(String.format("LEFT JOIN %s", tableList.stream().collect(Collectors.joining(", LEFT JOIN "))));
        }
    }

    public static String combineJoinColumn(List<Tuple<Column, Column>> joinColumnName) {
        List<String> joinColumnList = new ArrayList<>();
        if (!joinColumnName.isEmpty()) {
            joinColumnName.forEach(ele ->
                    joinColumnList.add(String.format("%s.%s = %s.%s",
                            ele.getK1().getTable().getEntityName(), ele.getK1().getName(),
                            ele.getK2().getTable().getEntityName(), ele.getK2().getName())));
            return combineListWithComma(joinColumnList);
        }
        return "";
    }

    public static String covertSqlPrepareStmt(Expression expression) {
        final String subQueryString = "SubQuery";

        String prepareStmt = "SELECT";

        prepareStmt += String.format(" %s FROM", expression.getSelectToString());

        List<String> primaryKeys = getPrimaryKeys(expression);
        String primaryTable = getPrimaryTable(expression);
        String primaryEntity = getPrimaryEntity(expression);
        String subQueryPrepareStmt = convertMainEntitySubQuery(expression, primaryKeys, primaryTable, primaryEntity, false);
        prepareStmt += subQueryPrepareStmt;

        StringBuilder mainEntityWhere = new StringBuilder(subQueryString)
                .append(String.format(" INNER JOIN %s %s ON (", primaryTable, primaryEntity));

        int pkSize = primaryKeys.size();
        for (int i = 0; i < pkSize; i++) {
            String k = primaryKeys.get(i);
            mainEntityWhere.append(String.format(" %s.%s = %s.%s ", subQueryString, k, primaryEntity, k));
            if (i < pkSize - 1) {
                mainEntityWhere.append(" AND ");
            }
        }
        mainEntityWhere.append(")");
        prepareStmt += String.format(" %s ", mainEntityWhere.toString());

        prepareStmt += convertFromTableAndJoinColumnToString(expression);

        if (expression.getOrderByWhole() != null && !expression.getOrderByWhole().isEmpty()) {
            List<String> orderByList = new ArrayList<>();
            expression.getOrderByWhole().forEach(sortByElem -> orderByList.add(
                    sortByElem.getK1().getTable().getEntityName() + "."
                            + sortByElem.getK1().getName()
                            + " "
                            + sortByElem.getK2().toString()));
            prepareStmt += String.format(" ORDER BY %s", orderByList.stream().collect(Collectors.joining(",")));
        }

        prepareStmt = String.format("SELECT DISTINCT * FROM ( %s )", prepareStmt);

        return prepareStmt;
    }

    public static String convertCountSqlPrepareStmt(Expression expression) {
        String prepareStmt = String.format("SELECT COUNT(*) AS %s FROM ", Constants.QUERY_TOTAL_COUNT);

        String subQueryPrepareStmt = convertMainEntitySubQuery(expression,
                getPrimaryKeys(expression),
                getPrimaryTable(expression),
                getPrimaryEntity(expression),
                true);
        prepareStmt += subQueryPrepareStmt;

        return prepareStmt;
    }

    private static String convertMainEntitySubQuery(Expression expression,
                                                    List<String> primaryKeys,
                                                    String primaryTable,
                                                    String primaryEntity,
                                                    boolean isConvertCountSql) {
        String subQueryPrepareStmt = "";

        String mainEntitySelect = convertSelectMainEntity(primaryKeys, primaryEntity);
        subQueryPrepareStmt += ("( " + mainEntitySelect);

        if (expression.getOrderByMainEntity() != null && !expression.getOrderByMainEntity().isEmpty()) {

            subQueryPrepareStmt = addOrderbyMainEntity(expression, subQueryPrepareStmt, primaryKeys);
        }

        subQueryPrepareStmt += String.format(" FROM %s %s", primaryTable, primaryEntity);

        subQueryPrepareStmt += convertFromTableAndJoinColumnToString(expression);

        if (expression.getWhere() != null && !"".equals(expression.getWhere())) {
            subQueryPrepareStmt += String.format(" WHERE %s", expression.getWhere());
        }

        subQueryPrepareStmt += convertOrderBy(expression);
        subQueryPrepareStmt += convertTopAndSkip(expression, isConvertCountSql);

        subQueryPrepareStmt += " ) ";
        return subQueryPrepareStmt;
    }

    private static String convertSelectMainEntity(List<String> primaryKeys, String primaryEntity) {

        StringBuilder mainEntitySelect = new StringBuilder("SELECT DISTINCT ");
        int pkSize = primaryKeys.size();
        for (int i = 0; i < pkSize; i++) {
            String k = primaryKeys.get(i);
            mainEntitySelect.append(primaryEntity).append(".").append(k);
            if (i < pkSize - 1) {
                mainEntitySelect.append(", ");
            }
        }
        return mainEntitySelect.toString();
    }

    private static String convertOrderBy(Expression expression) {
        String subQueryPrepareStmt = "";

        if (expression.getOrderByMainEntity() != null && !expression.getOrderByMainEntity().isEmpty()) {
            List<String> orderByList = new ArrayList<>();
            expression.getOrderByMainEntity().forEach(sortByElem -> orderByList.add(
                    sortByElem.getK1().getTable().getEntityName() + "."
                            + sortByElem.getK1().getName()
                            + " "
                            + sortByElem.getK2().toString()));
            subQueryPrepareStmt += String.format(" ORDER BY %s", orderByList.stream().collect(Collectors.joining(",")));
        }

        return subQueryPrepareStmt;

    }

    private static String convertTopAndSkip(Expression expression, boolean isConvertCountSql) {

        String subQueryPrepareStmt = "";

        if (expression.getTop() == null) {
            subQueryPrepareStmt += String.format(" LIMIT %s", isConvertCountSql ? Constants.QUERY_VALUE_NULL : Constants.DEFAULT_WINDOW_SIZE);
        } else if (expression.getTop() > DEFAULT_WINDOW_SIZE) {
            subQueryPrepareStmt += String.format(" LIMIT %s", String.valueOf(DEFAULT_WINDOW_SIZE));
        } else {
            subQueryPrepareStmt += String.format(" LIMIT %s", String.valueOf(expression.getTop().intValue()));
        }

        if (expression.getSkip() != null) {
            subQueryPrepareStmt += String.format(" OFFSET %s", String.valueOf(expression.getSkip().intValue()));
        }

        return subQueryPrepareStmt;
    }

    private static String addOrderbyMainEntity(Expression expression, String subQueryPrepareStmt, List<String> primaryKeys) {
        List<String> orderByList = new ArrayList<>();
        final List<String> finalPrimaryKeys = copy(primaryKeys);
        expression.getOrderByMainEntity().forEach(sortByElem -> {
            if (!finalPrimaryKeys.contains(sortByElem.getK1().getName())) {
                orderByList.add(sortByElem.getK1().getTable().getEntityName() + "." + sortByElem.getK1().getName());
            }
        });
        if (!orderByList.isEmpty()) {
            subQueryPrepareStmt += ", ";
            subQueryPrepareStmt += orderByList.stream().collect(Collectors.joining(", "));
        }
        return subQueryPrepareStmt;

    }

    private static String getPrimaryTable(Expression expression) {
        return expression.getPrimaryKeys().get(0).getTable().getTableName();
    }

    private static String getPrimaryEntity(Expression expression) {
        return expression.getPrimaryKeys().get(0).getTable().getEntityName();
    }

    private static List<String> getPrimaryKeys(Expression expression) {
        List<String> primaryKeys;

        List<Column> primaryKeyCols = expression.getPrimaryKeys();
        if (primaryKeyCols != null) {
            primaryKeys = primaryKeyCols.stream().map(Column::getName).collect(Collectors.toList());
        } else {
            throw new InternalErrorException("Primary key not found when querying");
        }
        return primaryKeys;
    }

    private static String convertFromTableAndJoinColumnToString(Expression expression) {
        final String emptyString = "";
        String prepareStmt = "";
        if (expression.getJoinColumn() != null && !emptyString.equals(expression.getJoinColumn())) {
            String[] fromList = expression.getFrom().split(", ");
            String[] joinColumnList = expression.getJoinColumn().split(", ");

            for (int i = 0; i <= fromList.length - 1; i++) {
                prepareStmt += String.format(" %s ON (%s)", fromList[i], joinColumnList[i]);
            }
        } else {
            if (expression.getFrom() != null && emptyString.equals(expression.getFrom())) {
                prepareStmt += " " + expression.getFrom();
            }
        }
        return prepareStmt;
    }

    public static MetadataForeignKey findBackLinkForeignKey(List<MetadataEntity> naviEntities, String targetEntityName) {
        Optional<MetadataEntity> naviEntityOptional = naviEntities.stream()
                .filter(navi -> navi.getName().equals(targetEntityName))
                .findFirst();
        if (!naviEntityOptional.isPresent()) {
            throw new ODataServiceException(MESSAGE_CODE_ERROR_METADATA_BACKLINK_NOT_FOUND, new Object[]{targetEntityName});
        }
        MetadataEntity naviEntity = naviEntityOptional.get();
        Optional<MetadataEntityElement> naviKeyOptional = naviEntity.getElements().stream()
                .filter(ele -> ele.isBackLink()).findFirst();
        if (!naviKeyOptional.isPresent()) {
            throw new ODataServiceException(MESSAGE_CODE_ERROR_METADATA_BACKLINK_NOT_FOUND, new Object[]{naviEntity.getName()});
        }

        return naviKeyOptional.get().getForeignKey();
    }

    public static List<String> findNonCoreTableColumn(List<MetadataEntityElement> columnList) {
        return filterAssociationAndCompositionCols(columnList).stream().filter(col -> col.isCustomizedField() || col.isKey())
                .map(ele -> ele.getName()).collect(Collectors.toList());
    }

    public static List<String> findCoreTableColumn(List<MetadataEntityElement> columnList) {
        return filterAssociationAndCompositionCols(columnList).stream().filter(col -> !col.isCustomizedField() && !col.isKey())
                .map(ele -> ele.getName()).collect(Collectors.toList());
    }

    public static List<MetadataEntityElement> filterAssociationAndCompositionCols(List<MetadataEntityElement> elements) {
        elements.forEach(e->{e.get})
        return elements.stream().filter(col -> !(MetadataConstants.CdsDataType.CDS_ASSOCIATION.equals(col.getType())
                || MetadataConstants.CdsDataType.CDS_COMPOSITION.equals(col.getType()))).collect(Collectors.toList());
    }

    public static ExpressionDbEdmMapping findEntityEdmMapping(String mainEntity, PhysicalName table, List<MetadataEntityElement> allColumn) {
        ExpressionDbEdmMapping edmMapping = new ExpressionDbEdmMapping();

        //find columns from main table
        String mainTable = table.getName();
        List<String> mainTableCol = findNonCoreTableColumn(allColumn);

        //find columns from core table
        String mainCoreTable = table.getCorePhysicalName();
        List<String> mainCoreTableCol = findCoreTableColumn(allColumn);

        edmMapping.addColumnName(Arrays.asList(new Tuple<>(new Table(mainTable, mainEntity), mainTableCol)));

        // if the main core table and main table are the same, only one table in this main entity
        if (mainCoreTable != null && !mainCoreTable.equals(mainTable)) {
            //if the main core table and main table are the different, default set the primary key as the foreign key in the core table
            Optional<MetadataEntityElement> joinKeyOptional = allColumn.stream().filter(col -> col.isKey()).findFirst();
            if (joinKeyOptional.isPresent()) {
                String joinKey = joinKeyOptional.get().getName();
                edmMapping.addColumnName(Arrays.asList(new Tuple<>(new Table(mainCoreTable, getCoreEntityName(mainEntity)), mainCoreTableCol)));
                edmMapping.addJoinTableName(Arrays.asList(new Table(mainCoreTable, getCoreEntityName(mainEntity))));
                Tuple<Column, Column> foreignKeyMap =
                        new Tuple<>(new Column(joinKey, new Table(mainCoreTable, getCoreEntityName(mainEntity))),
                                new Column(joinKey, new Table(mainTable, mainEntity)));

                edmMapping.addJoinColumnName(Arrays.asList(foreignKeyMap));
                edmMapping.addCoreTableCol(mainCoreTableCol);
            } else {
                throw new ODataServiceException(MESSAGE_CODE_ERROR_METADATA_CORETABLE_JOINKEY_NOT_FOUND, new Object[]{mainCoreTable});
            }
        } else {
            edmMapping.addColumnName(Arrays.asList(new Tuple<>(new Table(mainTable, mainEntity), mainCoreTableCol)));
        }

        return edmMapping;
    }

    public static Tuple<List<Table>, List<Tuple<Column, Column>>> getNaviTableAndNaviColList(List<MetadataEntity> naviEntities, List<String> naviPath,
                                                                                             String mainEntity, IMetadataManagement metadataService, String model) {
        List<Table> naviTableList = new ArrayList<>();
        List<Tuple<Column, Column>> naviColList = new ArrayList<>();

        //add navigation tables
        naviEntities.stream().forEach(entity -> {
            PhysicalName tableName = metadataService.getPhysicalNameOfEntity(model, entity.getName());
            String entityName = extractedEntityNameFromFullName(entity.getName());

            //if the entity is main entity, do not put it in navigation table list
            if (!mainEntity.equals(entityName)) {
                naviTableList.add(new Table(tableName.getName(), entityName));
                if (tableName.isExtensionEntity() && StringUtils.isNotBlank(tableName.getCorePhysicalName())) {
                    naviTableList.add(new Table(tableName.getCorePhysicalName(), CORE_PREFIX + entityName));
                }
            }

            //find navigation property
            Optional<MetadataEntityElement> naviOptional = entity.getElements().stream()
                    .filter(col -> !naviPath.isEmpty() && naviPath.get(0).equals(col.getName())
                            && (MetadataConstants.CdsDataType.CDS_ASSOCIATION.equals(col.getType())
                            || MetadataConstants.CdsDataType.CDS_COMPOSITION.equals(col.getType())))
                    .findFirst();

            if (naviOptional.isPresent()) {
                addNaviJoinColumn(naviOptional.get(), tableName, entityName, naviEntities, naviColList, naviPath);
            }

        });
        return new Tuple<>(naviTableList, naviColList);
    }

    private static void addNaviJoinColumn(MetadataEntityElement naviElement, PhysicalName tableName, String entityName,
                                          List<MetadataEntity> naviEntities, List<Tuple<Column, Column>> naviColList, List<String> naviPath) {
        //add navigation join columns
        String naviTableName = DBUtils.toTableName(naviElement.getTarget());
        String naviEntityName = extractedEntityNameFromFullName(naviElement.getTarget());
        MetadataForeignKey foreignKey = naviElement.getForeignKey();
        Tuple<Column, Column> foreignKeyMap;
        if (foreignKey != null) {
            if (MetadataConstants.CdsDataType.CDS_COMPOSITION.equals(naviElement.getType())) {
                foreignKeyMap = new Tuple(new Column(foreignKey.getReferenceFieldName(), new Table(tableName.getName(), entityName)),
                        new Column(foreignKey.getGeneratedFieldName(), new Table(naviTableName, naviEntityName)));
            } else {
                foreignKeyMap = new Tuple(new Column(foreignKey.getReferenceFieldName(), new Table(naviTableName, naviEntityName)),
                        new Column(foreignKey.getGeneratedFieldName(), new Table(tableName.getName(), entityName)));
            }
        } else {
            foreignKey = ExpressionUtils.findBackLinkForeignKey(naviEntities, naviElement.getTarget());
            foreignKeyMap = new Tuple(new Column(foreignKey.getGeneratedFieldName(), new Table(naviTableName, naviEntityName)),
                    new Column(foreignKey.getReferenceFieldName(), new Table(tableName.getName(), entityName)));
        }

        naviColList.add(foreignKeyMap);
        if (!naviPath.isEmpty()) {
            naviPath.remove(0);
        }
    }

    public static String extractedEntityNameFromFullName(String fullEntityName) {
        String[] entityNameList = fullEntityName.split("\\.");
        return entityNameList[entityNameList.length - 1];
    }

    public static String getCoreEntityName(String mainEntityName) {
        return CORE_PREFIX + mainEntityName;
    }
}
