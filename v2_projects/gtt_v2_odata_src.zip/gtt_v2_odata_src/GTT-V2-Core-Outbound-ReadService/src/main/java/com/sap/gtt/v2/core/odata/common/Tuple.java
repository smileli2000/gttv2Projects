package com.sap.gtt.v2.core.odata.common;

public class Tuple<K1, K2> {

    private K1 k1;
    private K2 k2;

    public Tuple(K1 k1, K2 k2) {
        this.k1 = k1;
        this.k2 = k2;
    }

    public K1 getK1() {
        return k1;
    }

    public void setK1(K1 k1) {
        this.k1 = k1;
    }

    public K2 getK2() {
        return k2;
    }

    public void setK2(K2 k2) {
        this.k2 = k2;
    }
    public String toString() {
        return String.format("k1=%s, k2=%s", k1, k2);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Tuple tuple = (Tuple) o;

        if (k1 != null ? !k1.equals(tuple.getK1()) : (tuple.getK1() != null)) return false;
        if (k2 != null ? !k2.equals(tuple.getK2()) : (tuple.getK2() != null)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = k1 != null ? k1.hashCode() : 0;
        result = 31 * result + (k2 != null ? k2.hashCode() : 0);
        return result;
    }
}
