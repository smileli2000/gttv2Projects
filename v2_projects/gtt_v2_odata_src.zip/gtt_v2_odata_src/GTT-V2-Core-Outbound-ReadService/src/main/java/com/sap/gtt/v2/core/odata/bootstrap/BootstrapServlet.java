package com.sap.gtt.v2.core.odata.bootstrap;

import com.sap.gtt.v2.core.odata.common.Constants;
import com.sap.gtt.v2.core.odata.exception.ODataServiceException;
import org.apache.olingo.odata2.api.ODataServiceFactory;
import org.apache.olingo.odata2.core.servlet.ODataServlet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static com.sap.gtt.v2.core.odata.utils.ODataUtils.validate;
import static com.sap.gtt.v2.core.odata.exception.ODataServiceException.MESSAGE_CODE_ERROR_UNKNOWN_MODEL_NAME;

@Component
public class BootstrapServlet extends ODataServlet {

	private static final long serialVersionUID = -8717057046558442096L;
	@Autowired
    private BootstrapServiceFactory factory;

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws IOException {

        String model = extractModelInfo(req);
        RequestWrapper wrapper = new RequestWrapper(req);
        if (validate(model)) {
			wrapper.setAttribute(Constants.MODEL_ATTRIBUTE_KEY, model);
			wrapper.setAttribute(ODataServiceFactory.FACTORY_INSTANCE_LABEL, factory);
		} else {
        	throw new ODataServiceException("Wrong model format");
		}

        super.service(wrapper, resp);
    }

	private String extractModelInfo(HttpServletRequest req) {
		List<String> splitted = Arrays.stream(req.getPathInfo().split(Constants.URL_SPLITTER)).filter(e -> e.trim().length() != 0)
				.collect(Collectors.toList());

		if (splitted.isEmpty()) {
			throw new ODataServiceException(MESSAGE_CODE_ERROR_UNKNOWN_MODEL_NAME, new Object[]{req.getPathInfo()});
		}

		return splitted.get(0);
	}
}
