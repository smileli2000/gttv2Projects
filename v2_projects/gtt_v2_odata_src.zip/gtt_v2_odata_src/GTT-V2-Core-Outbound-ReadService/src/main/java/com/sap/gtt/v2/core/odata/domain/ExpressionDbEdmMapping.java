package com.sap.gtt.v2.core.odata.domain;

import com.sap.gtt.v2.core.domain.metadata.MetadataEntityElement;
import com.sap.gtt.v2.core.domain.metadata.PhysicalName;
import com.sap.gtt.v2.core.odata.common.Tuple;
import com.sap.gtt.v2.core.odata.repository.SearchClient;
import com.sap.gtt.v2.core.odata.utils.ExpressionEdmMappingHelper;
import com.sap.gtt.v2.exception.InternalErrorException;
import org.apache.olingo.odata2.api.edm.EdmException;
import org.apache.olingo.odata2.api.edm.provider.Mapping;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.sap.gtt.v2.core.odata.utils.ExpressionUtils.*;
import static com.sap.gtt.v2.core.odata.utils.ODataUtils.copy;
import static com.sap.gtt.v2.core.odata.utils.ODataUtils.getAllColumnsOfEntity;

public class ExpressionDbEdmMapping extends Mapping {

    private List<String> mainTablePrimaryKeys;

    /**
     * table, columns
     */
    private List<Tuple<Table, List<String>>> columnName;

    /**
     * table name, entity name
     */
    private Table mainTableName;

    /**
     * core table name column
     */
    private List<String> coreTableCol;

    /**
     * column in main entity and column in navigation entity
     */
    private List<Tuple<Column, Column>> joinColumnName;

    /**
     * table name, entity name
     */
    private List<Table> joinTableName;

    /**
     * navigation column, related navigation entity
     */
    private Map<String, String> expandCol;

    public List<String> getMainTablePrimaryKeys() {
        return copy(mainTablePrimaryKeys);
    }

    public void setMainTablePrimaryKeys(List<String> mainTablePrimaryKeys) {
        this.mainTablePrimaryKeys = copy(mainTablePrimaryKeys);
    }

    public void setExpandCol(Map<String, String> expandCol) {
        this.expandCol = expandCol;
    }

    public Map<String, String> getExpandCol() {
        return expandCol;
    }

    public void addExpandCol(Map<String, String> expandCol) {
        if (this.expandCol != null && !this.expandCol.isEmpty()) {
            this.expandCol.putAll(expandCol);
        } else {
            this.expandCol = expandCol;
        }
    }

    public void setColumnName(List<Tuple<Table, List<String>>> columnName) {
        this.columnName = copy(columnName);
    }

    public List<Tuple<Table, List<String>>> getColumnName() {
        return copy(columnName);
    }

    public void addColumnName(List<Tuple<Table, List<String>>> columnNames) {
        if (this.columnName != null && !this.columnName.isEmpty()) {
            this.columnName = Stream.concat(this.columnName.stream(), columnNames.stream())
                    .collect(Collectors.toList());
        } else {
            this.columnName = copy(columnNames);
        }
    }

    public void setTableName(Table mainTableName) {
        this.mainTableName = mainTableName;
    }

    public Table getTableName() {
        return mainTableName;
    }

    public void setJoinColumnName(List<Tuple<Column, Column>> joinColumnName) {
        this.joinColumnName = copy(joinColumnName);
    }

    public List<Tuple<Column, Column>> getJoinColumnName() {
        return copy(joinColumnName);
    }

    public void addJoinColumnName(List<Tuple<Column, Column>> joinColumnName) {
        if (this.joinColumnName != null && !this.joinColumnName.isEmpty()) {
            this.joinColumnName = Stream.concat(this.joinColumnName.stream(), joinColumnName.stream())
                    .collect(Collectors.toList());
        } else {
            this.joinColumnName = copy(joinColumnName);
        }
    }

    public void setJoinTableName(List<Table> joinTableName) {
        this.joinTableName = copy(joinTableName);
    }

    public List<Table> getJoinTableName() {
        return copy(joinTableName);
    }

    public void addJoinTableName(List<Table> joinTableName) {
        if (this.joinTableName != null && !this.joinTableName.isEmpty()) {
            this.joinTableName = Stream.concat(this.joinTableName.stream(), joinTableName.stream().filter(e -> !e.equals(mainTableName)))
                    .collect(Collectors.toList());
        } else {
            this.joinTableName = copy(joinTableName);
        }
    }

    public void setCoreTableCol(List<String> coreTableCol) {
        this.coreTableCol = copy(coreTableCol);
    }

    public List<String> getCoreTableCol() {
        return copy(coreTableCol);
    }

    public void addCoreTableCol(List<String> coreTableCols) {
        if (this.coreTableCol != null && !this.coreTableCol.isEmpty()) {
            this.coreTableCol = Stream.concat(this.coreTableCol.stream(), coreTableCols.stream())
                    .collect(Collectors.toList());
        } else {
            this.coreTableCol = copy(coreTableCols);
        }
    }

    public void addTableAndColumnInfo(ExpressionDbEdmMapping edmMapping) {
        this.addExpandCol(edmMapping.getExpandCol());
        this.addColumnName(edmMapping.getColumnName());
        this.addJoinColumnName(edmMapping.getJoinColumnName());
        this.addJoinTableName(edmMapping.getJoinTableName());
        this.addCoreTableCol(edmMapping.getCoreTableCol());
    }

    public List<Column> getSelectToColumn() {
        List<Column> selectColumn = new ArrayList<>();
        columnName.stream().forEach(tableEle ->
                tableEle.getK2().stream().forEach(col ->
                        selectColumn.add(new Column(col, tableEle.getK1()))
                ));
        return selectColumn;
    }

    public String getFromToString() {
        return combineAllTableName(joinTableName);
    }

    public String getJoinColumnToString() {
        return combineJoinColumn(joinColumnName);
    }

    public List<Column> getPrimaryKeyToColumn() {
        List<Column> ret = new ArrayList<>();
        mainTablePrimaryKeys.forEach(e -> {
            ret.add(new Column(e, mainTableName));
        });
        return ret;
    }

    public static ExpressionDbEdmMapping getExpressionDbEdmMappingInstance(SearchClient searchClient) {
        ExpressionDbEdmMapping expressionDbEdmMapping = new ExpressionDbEdmMapping();
        try {
            String mainEntity = searchClient.getEntitySet().getName();
            String mainEntityType = searchClient.getEntitySet().getEntityType().toString();
            PhysicalName table = searchClient.getMetadataService().getPhysicalNameOfEntity(searchClient.getModel(), mainEntityType);
            List<MetadataEntityElement> allColumn = getAllColumnsOfEntity(mainEntity, searchClient.getMetadataService(), searchClient.getModel());
            List<String> mainTablePrimaryKeys = searchClient.getEntitySet().getEntityType().getKeyPropertyNames();

            String mainTableName = table.getName();
            Table mainTable = new Table(mainTableName, mainEntity);
            ExpressionDbEdmMapping edmMapping = findEntityEdmMapping(mainEntity, table, allColumn);
            expressionDbEdmMapping.addTableAndColumnInfo(edmMapping);

            List<Tuple<Table, List<String>>> tableColumn = new ArrayList<>();
            List<Table> joinTableName = new ArrayList<>();
            List<Tuple<Column, Column>> joinColumn = new ArrayList<>();
            Map<String, String> expandCol = new HashMap<>();
            ExpressionEdmMappingHelper helper = new ExpressionEdmMappingHelper(searchClient.getMetadataService(), searchClient.getModel());

            helper.buildJoinTableColumnForExpand(searchClient.getEntitySet(), expressionDbEdmMapping, searchClient.getExpand(), tableColumn, joinTableName, joinColumn, expandCol);
            helper.buildJoinTableColumnForNavigation(mainTable, searchClient.getNavigationPath(), joinTableName, joinColumn);
            helper.buildJoinTableColumnForOrderBy(searchClient.getEntitySet(), searchClient.getOrderBy(), joinTableName, joinColumn);

            expressionDbEdmMapping.setMainTablePrimaryKeys(mainTablePrimaryKeys);
            expressionDbEdmMapping.setTableName(mainTable);
            expressionDbEdmMapping.addColumnName(tableColumn);
            expressionDbEdmMapping.addJoinColumnName(joinColumn);
            expressionDbEdmMapping.addJoinTableName(joinTableName);
            expressionDbEdmMapping.addExpandCol(expandCol);
        } catch (EdmException e) {
            throw new InternalErrorException(e);
        }

        return expressionDbEdmMapping;
    }
}

