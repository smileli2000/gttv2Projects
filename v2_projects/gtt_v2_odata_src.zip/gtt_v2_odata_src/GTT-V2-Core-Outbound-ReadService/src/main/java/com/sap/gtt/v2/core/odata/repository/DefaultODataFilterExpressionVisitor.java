package com.sap.gtt.v2.core.odata.repository;

import com.sap.gtt.v2.core.domain.metadata.MetadataEntity;
import com.sap.gtt.v2.core.management.metadata.IMetadataManagement;
import com.sap.gtt.v2.core.odata.common.Storage;
import com.sap.gtt.v2.core.odata.common.Tuple;
import com.sap.gtt.v2.core.odata.domain.Column;
import com.sap.gtt.v2.core.odata.domain.Expression;
import com.sap.gtt.v2.core.odata.domain.ExpressionDbEdmMapping;
import com.sap.gtt.v2.core.odata.domain.Table;
import com.sap.gtt.v2.core.odata.exception.ODataServiceException;
import com.sap.gtt.v2.core.odata.exception.ODataServiceNotImplException;
import com.sap.gtt.v2.exception.InternalErrorException;
import org.apache.olingo.odata2.api.edm.EdmException;
import org.apache.olingo.odata2.api.edm.EdmLiteral;
import org.apache.olingo.odata2.api.edm.EdmTyped;
import org.apache.olingo.odata2.api.uri.expression.*;
import org.apache.olingo.odata2.core.edm.EdmDateTime;
import org.springframework.util.StringUtils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static com.sap.gtt.v2.core.odata.common.Constants.CORE_PREFIX;
import static com.sap.gtt.v2.core.odata.utils.ExpressionUtils.extractedEntityNameFromFullName;
import static com.sap.gtt.v2.core.odata.utils.ExpressionUtils.getNaviTableAndNaviColList;
import static com.sap.gtt.v2.core.odata.exception.ODataServiceException.MESSAGE_CODE_ERROR_WRONG_FILTER_EXPRESSION_FORMAT;
import static com.sap.gtt.v2.core.odata.exception.ODataServiceNotImplException.*;

public class DefaultODataFilterExpressionVisitor implements ExpressionVisitor {

    private static final String BLANK = " ";
    private static final String DOT = ".";
    private static final String LIKE = "LIKE";
    private static final String QUESTION_MARK = "?";
    private static final String NOT_LIKE = "NOT LIKE";

    // generate an expression to use for SQL generation
    private Storage storage;
    private ExpressionDbEdmMapping expressionDbEdmMapping;
    private IMetadataManagement metadataService;
    private String mainEntityType;
    private String model;

    public DefaultODataFilterExpressionVisitor(Storage storage, ExpressionDbEdmMapping expressionDbEdmMapping, IMetadataManagement metadataService, String mainEntityType, String model) {
        this.storage = storage;
        this.expressionDbEdmMapping = expressionDbEdmMapping;
        this.metadataService = metadataService;
        this.mainEntityType = mainEntityType;
        this.model = model;
    }

    public ExpressionDbEdmMapping getExpressionDbEdmMapping() {
        return expressionDbEdmMapping;
    }

    @Override
    public Object visitFilterExpression(FilterExpression filterExpression, String expressionString, Object expression) {
        return expression;
    }

    @Override
    public Object visitBinary(BinaryExpression binaryExpression, BinaryOperator operator, Object leftSide, Object rightSide) {

        // Transform the OData filter operator into an equivalent sql operator
        String sqlOperator;
        switch (operator) {
            case EQ:
                sqlOperator = "=";
                break;
            case NE:
                sqlOperator = "<>";
                break;
            case OR:
                sqlOperator = "OR";
                break;
            case AND:
                sqlOperator = "AND";
                break;
            case GE:
                sqlOperator = ">=";
                break;
            case GT:
                sqlOperator = ">";
                break;
            case LE:
                sqlOperator = "<=";
                break;
            case LT:
                sqlOperator = "<";
                break;
            case PROPERTY_ACCESS:
                throw new ODataServiceNotImplException(MESSAGE_CODE_ERROR_UNSUPPORTED_OPERATOR,
                        new Object[]{operator.toUriLiteral()});
            default:
                // Other operators are not supported for SQL Statements
                throw new ODataServiceNotImplException(MESSAGE_CODE_ERROR_UNSUPPORTED_OPERATOR,
                        new Object[]{operator.toUriLiteral()});
        }

        if (leftSide instanceof List || leftSide instanceof Column) {
            return visitBinaryListOrColumn(operator, leftSide, rightSide, sqlOperator);
        } else if (leftSide instanceof Expression && rightSide instanceof Expression) {
            return visitBinaryExpression(operator, leftSide, rightSide, sqlOperator);
        } else if (leftSide instanceof Expression && rightSide instanceof String) {
            return visitBinaryExpressionAndString(operator, leftSide, rightSide, sqlOperator);
        } else if (leftSide instanceof String && rightSide instanceof String) {
            Expression expression = new Expression(operator);
            expression.setWhere(leftSide + BLANK + sqlOperator + BLANK
                    + rightSide);
            return expression;
        } else {
            throw new ODataServiceException(MESSAGE_CODE_ERROR_WRONG_FILTER_EXPRESSION_FORMAT, new Object[]{});
        }
    }

    @Override
    public Object visitOrderByExpression(OrderByExpression orderByExpression, String expressionString, List<Object> orders) {
        return null;
    }

    @Override
    public Object visitOrder(OrderExpression orderExpression, Object filterResult, SortOrder sortOrder) {
        return null;
    }

    @Override
    public Object visitLiteral(LiteralExpression literal, EdmLiteral edmLiteral) {
        if (edmLiteral.getType() instanceof EdmDateTime) {
            DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ss");
            try {
                return df.parse(edmLiteral.getLiteral());
            } catch (ParseException e) {
                throw new InternalErrorException(e);
            }
        } else {
            return edmLiteral.getLiteral();
        }
    }

    @Override
    public Object visitMethod(MethodExpression methodExpression, MethodOperator method, List<Object> parameters) {
        Object firstObj = parameters.get(0);
        Object secondObj = parameters.size() > 1 ? parameters.get(1) : "";
        Expression expression = new Expression();
        expression.setMethodOperator(methodExpression.getMethod());
        Tuple<String, String> paras = visitMethodTwoParas(firstObj, secondObj);
        String first = paras.getK1();
        String second = paras.getK2();
        String whereExpression;
        String from = "";

        if (Storage.DEFAULT.equals(storage)) {
            switch (methodExpression.getMethod()) {
                case SUBSTRINGOF:
                    if (!StringUtils.isEmpty(second)) {
                        whereExpression = String.format("%s %s %s", second, LIKE, QUESTION_MARK);
                        expression.setWhere(whereExpression);
                        expression.addParameter("%" + first + "%");
                        expression.setMethodOperator(MethodOperator.SUBSTRINGOF);
                    }
                    expression.setFrom(from);

                    return expression;
                case STARTSWITH:
                    if (!StringUtils.isEmpty(first)) {
                        whereExpression = String.format("%s %s %s", first, LIKE, QUESTION_MARK);
                        expression.setWhere(whereExpression);
                        expression.addParameter(second + "%");
                        expression.setMethodOperator(MethodOperator.STARTSWITH);
                    }
                    expression.setFrom(from);

                    return expression;
                case ENDSWITH:
                    if (!StringUtils.isEmpty(first)) {
                        whereExpression = String.format("%s %s %s", first, LIKE, QUESTION_MARK);
                        expression.setWhere(whereExpression);
                        expression.addParameter("%" + second);
                        expression.setMethodOperator(MethodOperator.ENDSWITH);
                    }
                    expression.setFrom(from);

                    return expression;
                default:
                    throw new ODataServiceNotImplException(MESSAGE_CODE_ERROR_UNSUPPORTED_METHOD,
                            new Object[]{methodExpression.getMethod().toString()});
            }
        } else {
            throw new ODataServiceNotImplException(MESSAGE_CODE_ERROR_UNSUPPORTED_DATABASE);
        }
    }

    @Override
    public Object visitMember(MemberExpression memberExpression, Object path, Object property) {
        List<Table> naviTableList = new ArrayList<>();
        List<Tuple<Column, Column>> naviColList;
        if (property instanceof Column) {

            //find navigation entities
            List<String> naviPath = new ArrayList<>();
            if (path instanceof List) {
                List<Column> pathList = ((List<Column>) path);
                pathList.stream().forEach(p ->
                        naviPath.add(p.getName())
                );
                naviPath.add(((Column) property).getName());
            } else {
                naviPath.addAll(Arrays.asList(((Column) path).getName(), ((Column) property).getName()));
            }
            String naviPathStr = naviPath.stream().collect(Collectors.joining("/"));
            List<MetadataEntity> naviEntities = metadataService.findODataNavigationEntitiesByPath(mainEntityType, naviPathStr);

            Tuple<List<Table>, List<Tuple<Column, Column>>> naviList = getNaviTableAndNaviColList(naviEntities, naviPath,
                    extractedEntityNameFromFullName(mainEntityType), metadataService, model);
            naviTableList = naviList.getK1();
            naviColList = naviList.getK2();

            final List<Tuple<Column, Column>> naviColumns = naviColList;
            // check if the navigation table already exists
            List<Table> joinTable = expressionDbEdmMapping.getJoinTableName();
            List<Tuple<Column, Column>> joinCol = expressionDbEdmMapping.getJoinColumnName();
            List<String> joinTableName = joinTable.stream().map(table -> table.getTableName()).collect(Collectors.toList());

            naviTableList.forEach(naviTable -> {
                if (!joinTableName.contains(naviTable.getTableName())) {
                    joinTable.add(naviTable);
                    joinCol.add(naviColumns.get(0));
                }
                naviColumns.remove(0);
            });

            expressionDbEdmMapping.setJoinTableName(joinTable);
            expressionDbEdmMapping.setJoinColumnName(joinCol);
        }

        if (property instanceof Column) {
            if (path instanceof List) {
                ArrayList<Column> res = new ArrayList();
                res.addAll((List) path);
                res.add(new Column(((Column) property).getName(),
                        naviTableList.get(naviTableList.size() - 1)));
                return res;
            } else {
                return Arrays.asList(path, new Column(((Column) property).getName(),
                        naviTableList.get(naviTableList.size() - 1)));
            }
        } else {
            return property;
        }
    }

    @Override
    public Object visitProperty(PropertyExpression propertyExpression, String uriLiteral, EdmTyped edmProperty) {
        String mainEntity = expressionDbEdmMapping.getTableName().getEntityName();
        List<String> coreTableCol = expressionDbEdmMapping.getCoreTableCol();
        try {
            if (coreTableCol != null && !coreTableCol.isEmpty() && coreTableCol.contains(edmProperty.getName())) {
                return new Column(edmProperty.getName(), new Table(null, CORE_PREFIX + mainEntity));
            } else {
                return new Column(edmProperty.getName(), new Table(null, mainEntity));
            }
        } catch (EdmException e) {
            throw new InternalErrorException(e);
        }
    }

    @Override
    public Object visitUnary(UnaryExpression unaryExpression, UnaryOperator operator, Object operand) {
        if (operator == UnaryOperator.NOT) {
            String where = ((Expression) operand).getWhere();
            if (!where.isEmpty()) {
                where = "NOT( " + where + " )";
                ((Expression) operand).setWhere(where);
            }
            return operand;
        } else {
            throw new ODataServiceNotImplException(MESSAGE_CODE_ERROR_UNSUPPORTED_OPERATOR);
        }
    }

    private Tuple<String, String> visitMethodTwoParas(Object firstObj, Object secondObj) {
        String first;
        String second;

        if (secondObj instanceof Column) {
            first = firstObj.toString();
            Column secondProperty = (Column) secondObj;
            second = String.format("%s.%s", secondProperty.getTable().getEntityName(), secondProperty.getName());
        } else if (secondObj instanceof List) {
            first = firstObj.toString();
            Column secondProperty = (Column) ((List) secondObj).get(((List) secondObj).size() - 1);
            second = String.format("%s.%s", secondProperty.getTable().getEntityName(), secondProperty.getName());
        } else if (firstObj instanceof List) {
            second = secondObj.toString();
            Column firstProperty = (Column) ((List) firstObj).get(((List) firstObj).size() - 1);
            first = String.format("%s.%s", firstProperty.getTable().getEntityName(), firstProperty.getName());
        } else {
            second = secondObj.toString();
            Column firstProperty = (Column) firstObj;
            first = String.format("%s.%s", firstProperty.getTable().getEntityName(), firstProperty.getName());
        }

        return new Tuple<>(first, second);
    }

    private Object visitBinaryExpressionAndString(BinaryOperator operator, Object leftSide, Object rightSide, String sqlOperator) {
        Expression returnExpression = new Expression(operator);
        Expression leftSideExpression = (Expression) leftSide;
        if (isBinaryExpression(leftSideExpression)) {
            leftSideExpression.setWhere("("
                    + leftSideExpression.toString() + ")");
        }
        returnExpression.setFrom(leftSideExpression
                .getFrom());
        returnExpression.getNavigationProperties().addAll(
                leftSideExpression.getNavigationProperties());

        // if left side express is blank, then return it directly
        if (StringUtils.isEmpty(leftSideExpression.toString())) {
            return returnExpression;
    }

        String returnExp = leftSideExpression.toString();
        if (isMethodExpression(leftSideExpression)) {
            if ((("<>").equals(sqlOperator) && ("true").equals(rightSide))
                    || (("==".equals(sqlOperator) && ("false").equals(rightSide)))) {
                returnExp = returnExp.replace(LIKE, NOT_LIKE);
            }
        }

        returnExpression.setWhere(returnExp);

        for (Object parameter : leftSideExpression.getParameters()) {
            returnExpression.addParameter(parameter);
        }

        return returnExpression;
    }

    private Object visitBinaryExpression(BinaryOperator operator, Object leftSide, Object rightSide, String sqlOperator) {
        Expression leftSideExpression = (Expression) leftSide;
        Expression rightSideExpression = (Expression) rightSide;
        Expression returnExpression = leftSideExpression;

        // if one side is empty, return expression in other side
        if (StringUtils.isEmpty(leftSideExpression.getWhere())) {
            returnExpression = rightSideExpression;
            return returnExpression;
        }
        if (StringUtils.isEmpty(rightSideExpression.getWhere())) {
            return returnExpression;
        }
        returnExpression = new Expression(operator);

        // if one side is 'AND' or 'OR', add bracket to show priority
        if (isBinaryExpression(leftSideExpression)) {
            leftSideExpression.setWhere("("
                    + leftSideExpression.toString() + ")");
        }
        if (isBinaryExpression(rightSideExpression)) {
            rightSideExpression.setWhere("("
                    + rightSideExpression.toString() + ")");
        }

        // join 'where' clause with two expressions together
        StringBuilder returnExpSb = new StringBuilder();
        returnExpSb.append(leftSideExpression.toString());
        if (!StringUtils.isEmpty(rightSideExpression.toString())) {
            returnExpSb.append(BLANK).append(sqlOperator).append(" ")
                    .append(rightSideExpression.toString());
        }
        returnExpression.setWhere(returnExpSb.toString());

        // join parameters in two expressions together
        for (Object parameter : leftSideExpression.getParameters()) {
            returnExpression.addParameter(parameter);
        }
        for (Object parameter : rightSideExpression.getParameters()) {
            returnExpression.addParameter(parameter);
        }

        returnExpression.getNavigationProperties().addAll(
                leftSideExpression.getNavigationProperties());
        returnExpression.getNavigationProperties().addAll(
                rightSideExpression.getNavigationProperties());
        return returnExpression;
    }

    private Object visitBinaryListOrColumn(BinaryOperator operator, Object leftSide, Object rightSide, String sqlOperator) {
        Column leftCol;
        if (leftSide instanceof List) {
            leftCol = (Column) ((List) leftSide).get(((List) leftSide).size() - 1);
        } else {
            leftCol = (Column) leftSide;
        }
        Expression expression = new Expression(operator);
        String leftSideName = String.format("%s%s%s", leftCol.getTable().getEntityName(), DOT, leftCol.getName());
        expression.setWhere(leftSideName + BLANK + sqlOperator
                + " ?");
        expression.addParameter(rightSide);
        return expression;
    }

    private Boolean isBinaryExpression(Expression expression) {
        return BinaryOperator.AND.equals(expression.getOperator())
                || BinaryOperator.OR.equals(expression
                .getOperator());
    }

    private Boolean isMethodExpression(Expression expression) {
        return MethodOperator.SUBSTRINGOF.equals(expression.getMethodOperator())
                || MethodOperator.STARTSWITH.equals(expression.getMethodOperator())
                || MethodOperator.ENDSWITH.equals(expression.getMethodOperator());
    }
}