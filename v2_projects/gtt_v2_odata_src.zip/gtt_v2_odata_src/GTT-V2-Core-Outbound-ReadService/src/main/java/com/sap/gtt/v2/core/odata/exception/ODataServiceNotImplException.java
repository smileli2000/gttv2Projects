package com.sap.gtt.v2.core.odata.exception;

import org.apache.http.HttpStatus;

public class ODataServiceNotImplException extends ODataServiceException {
    public static final String MESSAGE_CODE_ERROR_UNSUPPORTED_OPERATOR = ODataServiceNotImplException.class.getName() + ".UnsupportedOperator";
    public static final String MESSAGE_CODE_ERROR_UNSUPPORTED_METHOD = ODataServiceNotImplException.class.getName() + ".UnsupportedMethod";
    public static final String MESSAGE_CODE_ERROR_UNSUPPORTED_DATABASE = ODataServiceNotImplException.class.getName() + ".UnsupportedDatabase";

    public ODataServiceNotImplException(String internalMessage, Throwable cause, String messageCode, Object[] localizedMsgParams) {
        super(internalMessage, cause, messageCode, localizedMsgParams);
    }

    public ODataServiceNotImplException(String messageCode) {
        super(messageCode, new Object[]{});
    }

    public ODataServiceNotImplException(String messageCode, Object[] localizedMsgParams) {
        super(messageCode, localizedMsgParams);
    }

    @Override
    public int getHttpStatus() {
        return HttpStatus.SC_NOT_IMPLEMENTED;
    }

}
