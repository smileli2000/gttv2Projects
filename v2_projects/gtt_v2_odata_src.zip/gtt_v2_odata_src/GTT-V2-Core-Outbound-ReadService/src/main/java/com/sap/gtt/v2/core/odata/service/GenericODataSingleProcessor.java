package com.sap.gtt.v2.core.odata.service;

import com.sap.gtt.v2.configuration.ISAPCloudPlatformAgent;
import com.sap.gtt.v2.core.odata.bootstrap.RequestWrapper;
import com.sap.gtt.v2.core.odata.callback.ExpandEntityCallback;
import com.sap.gtt.v2.core.odata.callback.ExpandEntitySetCallback;
import com.sap.gtt.v2.core.odata.common.Constants;
import com.sap.gtt.v2.core.odata.domain.PagedEntitySetList;
import com.sap.gtt.v2.core.odata.exception.ODataServiceNotFoundException;
import com.sap.gtt.v2.core.odata.repository.GenericDataStore;
import com.sap.gtt.v2.core.odata.utils.UriInfoHelper;
import org.apache.olingo.odata2.api.ODataCallback;
import org.apache.olingo.odata2.api.batch.BatchHandler;
import org.apache.olingo.odata2.api.batch.BatchRequestPart;
import org.apache.olingo.odata2.api.batch.BatchResponsePart;
import org.apache.olingo.odata2.api.commons.InlineCount;
import org.apache.olingo.odata2.api.edm.EdmException;
import org.apache.olingo.odata2.api.edm.EdmMultiplicity;
import org.apache.olingo.odata2.api.edm.EdmNavigationProperty;
import org.apache.olingo.odata2.api.ep.EntityProvider;
import org.apache.olingo.odata2.api.ep.EntityProviderBatchProperties;
import org.apache.olingo.odata2.api.ep.EntityProviderWriteProperties;
import org.apache.olingo.odata2.api.exception.ODataException;
import org.apache.olingo.odata2.api.processor.ODataContext;
import org.apache.olingo.odata2.api.processor.ODataResponse;
import org.apache.olingo.odata2.api.processor.ODataSingleProcessor;
import org.apache.olingo.odata2.api.uri.ExpandSelectTreeNode;
import org.apache.olingo.odata2.api.uri.NavigationPropertySegment;
import org.apache.olingo.odata2.api.uri.PathInfo;
import org.apache.olingo.odata2.api.uri.UriParser;
import org.apache.olingo.odata2.api.uri.info.GetEntitySetCountUriInfo;
import org.apache.olingo.odata2.api.uri.info.GetEntitySetUriInfo;
import org.apache.olingo.odata2.api.uri.info.GetEntityUriInfo;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.io.InputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.*;
import java.util.stream.Collectors;

import static org.apache.olingo.odata2.api.processor.ODataContext.HTTP_SERVLET_REQUEST_OBJECT;

@Component
@Scope("prototype") // every time different odata context will be set into the
// processor instance. so must be prototype
public class GenericODataSingleProcessor extends ODataSingleProcessor {

    private Locale getLocale() {
        return ISAPCloudPlatformAgent.ICurrentAccessContext.getLocale();
    }

    private URI getServiceRoot() throws ODataException {
        try {
            return new URI(getContext().getPathInfo().getServiceRoot().toString().concat(getNameSpace()).concat("/"));
        } catch (URISyntaxException e) {
            throw new ODataException(e);
        }
    }

    protected String getNameSpace() {
        String nameSpace = null;
        Object reqObject = this.getContext().getParameter(HTTP_SERVLET_REQUEST_OBJECT);
        ODataContext odataBatchParentContext = (ODataContext) this.getContext().getParameter(Constants.ODATA_BATCH_PARENT_CONTEXT);
        while (reqObject == null && odataBatchParentContext != null) {
            reqObject = odataBatchParentContext.getParameter(HTTP_SERVLET_REQUEST_OBJECT);
            if (reqObject == null) {
                odataBatchParentContext = (ODataContext) odataBatchParentContext.getParameter(Constants.ODATA_BATCH_PARENT_CONTEXT);
            }
        }

        if (reqObject != null) {
            Object modelAttr = ((RequestWrapper) reqObject).getRequest().getAttribute(Constants.MODEL_ATTRIBUTE_KEY);
            if (modelAttr != null) {
                nameSpace = modelAttr.toString();
            }
        }
        if (nameSpace == null) {
            throw new ODataServiceNotFoundException("Model not found!!");
        }

        return nameSpace;
    }


    protected String getModel() {
        String nameSpace = getNameSpace();
        String[] strList = nameSpace.split("\\.");
        String serviceName = strList[strList.length - 1];
        String model = nameSpace.replace("." + serviceName, "");

        return model;
    }

    protected GenericDataStore createDataStore() {
        return GenericDataStore.createInstance(this.getModel());
    }

    @Override
    public ODataResponse readEntitySet(GetEntitySetUriInfo uriInfo, String contentType) throws ODataException {

        //prepare query parameters from URI Info
        UriInfoHelper uriInfoHelper = new UriInfoHelper().initialize(uriInfo.getStartEntitySet(), uriInfo.getKeyPredicates(), uriInfo.getExpand(), uriInfo.getNavigationSegments());

        //Query results from database
        PagedEntitySetList<Map<String, Object>> result;
        result = createDataStore().queryEntitySet(uriInfo.getTargetEntitySet(), uriInfoHelper.getKeyMap(),
                uriInfoHelper.getNavigationPath(), uriInfo.getFilter(), uriInfo.getSkip(), uriInfo.getTop(),
                uriInfo.getOrderBy(), uriInfo.getInlineCount(), uriInfo.getCustomQueryOptions(),
                uriInfoHelper.getExpand(), getLocale());

        //Build displayed items
        EntityProviderWriteProperties.ODataEntityProviderPropertiesBuilder propertiesBuilder = EntityProviderWriteProperties
                .serviceRoot(this.getServiceRoot());
        ExpandSelectTreeNode expandSelectTreeNode = UriParser.createExpandSelectTree(uriInfo.getSelect(), uriInfo.getExpand());
        Map<String, ODataCallback> callbacks = setExpandOptionCallback(uriInfo.getExpand());
        propertiesBuilder.expandSelectTree(expandSelectTreeNode).callbacks(callbacks).inlineCountType(uriInfo.getInlineCount());
        propertiesBuilder.inlineCount(InlineCount.ALLPAGES.equals(uriInfo.getInlineCount()) ? result.getTotalCount() : null);
        EntityProviderWriteProperties properties = propertiesBuilder.build();

        return EntityProvider.writeFeed(contentType, uriInfo.getTargetEntitySet(), result.getData(), properties);
    }

    @Override
    public ODataResponse readEntity(GetEntityUriInfo uriInfo, String contentType) throws ODataException {

        //prepare query parameters from URI Info
        UriInfoHelper uriInfoHelper = new UriInfoHelper().initialize(uriInfo.getStartEntitySet(), uriInfo.getKeyPredicates(), uriInfo.getExpand(), uriInfo.getNavigationSegments());

        //Query results from database
        Map<String, Object> result;
        result = createDataStore().queryEntity(uriInfo.getTargetEntitySet(), uriInfoHelper.getKeyMap(),
                uriInfoHelper.getNavigationPath(), uriInfo.getCustomQueryOptions(),
                uriInfoHelper.getExpand(), getLocale());

        //Build displayed items
        ExpandSelectTreeNode expandSelectTreeNode = UriParser.createExpandSelectTree(uriInfo.getSelect(), uriInfo.getExpand());
        EntityProviderWriteProperties.ODataEntityProviderPropertiesBuilder propertiesBuilder = EntityProviderWriteProperties
                .serviceRoot(this.getServiceRoot());
        Map<String, ODataCallback> callbacks = setExpandOptionCallback(uriInfo.getExpand());
        propertiesBuilder.expandSelectTree(expandSelectTreeNode).callbacks(callbacks);
        EntityProviderWriteProperties properties = propertiesBuilder.build();

        return EntityProvider.writeEntry(contentType, uriInfo.getTargetEntitySet(), result, properties);
    }

    @Override
    public ODataResponse countEntitySet(GetEntitySetCountUriInfo uriInfo, String contentType) throws ODataException {
        //prepare query parameters from URI Info
        UriInfoHelper uriInfoHelper = new UriInfoHelper().initialize(uriInfo.getStartEntitySet(), uriInfo.getKeyPredicates(), null, uriInfo.getNavigationSegments());

        Integer resultSetCount = createDataStore().queryEntitySetCount(uriInfo.getTargetEntitySet(), uriInfoHelper.getKeyMap(),
                uriInfoHelper.getNavigationPath(), uriInfo.getFilter(), uriInfo.getSkip(),
                uriInfo.getTop(), uriInfo.getCustomQueryOptions(), getLocale());
        return EntityProvider.writeText(resultSetCount.toString());
    }

    @Override
    public ODataResponse executeBatch(BatchHandler handler, String contentType, InputStream content)
            throws ODataException {
        PathInfo pathInfo = getContext().getPathInfo();
        EntityProviderBatchProperties batchProperties = EntityProviderBatchProperties.init().pathInfo(pathInfo).build();
        List<BatchRequestPart> batchRequestParts = EntityProvider.parseBatchRequest(contentType, content, batchProperties);
        List<BatchResponsePart> batchResponseParts = new ArrayList<>();

        for (BatchRequestPart part : batchRequestParts) {
            batchResponseParts.add(handler.handleBatchPart(part));
        }

        return EntityProvider.writeBatchResponse(batchResponseParts);
    }


    private Map<String, ODataCallback> setExpandOptionCallback(List<ArrayList<NavigationPropertySegment>> expand) throws ODataException {
        Map<String, ODataCallback> callbacks = new HashMap<>();
        ExpandEntityCallback expandEntityCallback = new ExpandEntityCallback();
        ExpandEntitySetCallback expandEntitySetCallback = new ExpandEntitySetCallback();
        expandEntityCallback.setServiceRoot(getServiceRoot());
        expandEntitySetCallback.setServiceRoot(getServiceRoot());

        List<NavigationPropertySegment> navi = expand.stream().flatMap(Collection::stream).collect(Collectors.toList());

        for (NavigationPropertySegment prop : navi) {
            EdmNavigationProperty navigationProperty = prop.getNavigationProperty();
            try {
                if (navigationProperty.getMultiplicity().equals(EdmMultiplicity.MANY)) {
                    callbacks.put(prop.getNavigationProperty().getName(), expandEntitySetCallback);
                } else {
                    callbacks.put(prop.getNavigationProperty().getName(), expandEntityCallback);
                }
            } catch (EdmException e) {
                throw new ODataException(e);
            }
        }

        return callbacks;
    }

}