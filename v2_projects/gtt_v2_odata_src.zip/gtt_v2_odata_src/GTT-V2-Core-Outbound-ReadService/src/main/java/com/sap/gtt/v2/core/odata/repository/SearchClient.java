package com.sap.gtt.v2.core.odata.repository;

import com.sap.gtt.v2.core.management.metadata.IMetadataManagement;
import com.sap.gtt.v2.core.odata.common.Constants;
import com.sap.gtt.v2.core.odata.common.Tuple;
import com.sap.gtt.v2.core.odata.domain.PagedEntitySetList;
import org.apache.olingo.odata2.api.commons.InlineCount;
import org.apache.olingo.odata2.api.edm.EdmEntitySet;
import org.apache.olingo.odata2.api.uri.KeyPredicate;
import org.apache.olingo.odata2.api.uri.expression.FilterExpression;
import org.apache.olingo.odata2.api.uri.expression.OrderByExpression;

import java.util.List;
import java.util.Locale;
import java.util.Map;

public abstract class SearchClient {

    protected String model;
    protected Integer skip;
    protected Integer top;
    protected InlineCount inlineCount;
    protected FilterExpression filter;
    protected OrderByExpression orderBy;
    protected EdmEntitySet entitySet;
    protected List<EdmEntitySet> navigationPath;
    protected Map<String, List<KeyPredicate>> keys;
    protected Locale locale;
    protected Map<String, String> customQueryOptions;
    protected List<List<Tuple<String, String>>> expand;
    protected boolean scroll;
    protected IMetadataManagement metadataService;


    protected SearchClient(String model){
        this.model = model;
    }

    public SearchClient setMetadataService(IMetadataManagement metadataService) {
        this.metadataService = metadataService;

        return this;
    }

    public SearchClient setNavigationPath(List<EdmEntitySet> navigationPath) {
        this.navigationPath = navigationPath;

        return this;
    }

    public SearchClient setEntitySet(EdmEntitySet entitySet) {
        this.entitySet = entitySet;

        return this;
    }

    public SearchClient setFilter(FilterExpression filter) {
        this.filter = filter;

        return this;
    }

    public SearchClient setTop(Integer top) {
        this.top = top;

        return this;
    }

    public SearchClient setSkip(Integer skip) {
        this.skip = skip == null ? Constants.DEFAULT_OFFSET : skip;

        return this;
    }

    public SearchClient setInlineCount(InlineCount inlineCount) {
        this.inlineCount = inlineCount;

        return this;
    }

    public SearchClient setOrderBy(OrderByExpression orderBy) {
        this.orderBy = orderBy;

        return this;
    }

    public SearchClient setKeys(Map<String,List<KeyPredicate>> keys){
        this.keys = keys;

        return this;
    }

    public SearchClient setExpand(List<List<Tuple<String, String>>> expand){
        this.expand = expand;

        return this;
    }

    public SearchClient applyAuthorizationFilter()  {
        return this;
    }

    public SearchClient setLocale(Locale locale) {
        this.locale = locale == null ? Locale.US : locale;

        return this;
    }

    public SearchClient setCustomQueryOption(Map<String, String> customQueryOptions) {
        this.customQueryOptions = customQueryOptions;

        return this;
    }

    public SearchClient setScroll(boolean scroll) {
        this.scroll = scroll;
        return this;
    }

    public String getModel() {
        return this.model;
    }

    public Integer getSkip() {
        return this.skip;
    }

    public Integer getTop() {
        return this.top;
    }

    public FilterExpression getFilter() {
        return this.filter;
    }

    public OrderByExpression getOrderBy() {
        return this.orderBy;
    }

    public EdmEntitySet getEntitySet() {
        return this.entitySet;
    }

    public List<EdmEntitySet> getNavigationPath() {
        return this.navigationPath;
    }

    public Map<String, List<KeyPredicate>> getKeys() {
        return this.keys;
    }

    public List<List<Tuple<String, String>>> getExpand() {
        return this.expand;
    }

    public IMetadataManagement getMetadataService() {
        return this.metadataService;
    }

    public abstract SearchClient execute() ;

    public abstract PagedEntitySetList<Map<String, Object>> getSearchResult() ;

    public abstract Integer getResultCount();

}
