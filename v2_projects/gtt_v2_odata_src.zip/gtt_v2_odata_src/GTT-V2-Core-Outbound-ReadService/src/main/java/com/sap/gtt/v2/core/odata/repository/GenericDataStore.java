package com.sap.gtt.v2.core.odata.repository;

import com.sap.gtt.v2.configuration.EnvironmentsConfiguration.VcapServiceParser.DatabaseServiceInstance;
import com.sap.gtt.v2.configuration.EnvironmentsConfiguration.VcapServiceParser.DatabaseServiceInstance.DatabaseType;
import com.sap.gtt.v2.configuration.ISAPCloudPlatformAgent;
import com.sap.gtt.v2.core.management.metadata.IMetadataManagement;
import com.sap.gtt.v2.core.odata.common.Tuple;
import com.sap.gtt.v2.core.odata.domain.PagedEntitySetList;
import com.sap.gtt.v2.core.odata.exception.ODataServiceException;
import com.sap.gtt.v2.util.SpringContextUtils;
import org.apache.olingo.odata2.api.commons.InlineCount;
import org.apache.olingo.odata2.api.edm.EdmEntitySet;
import org.apache.olingo.odata2.api.uri.KeyPredicate;
import org.apache.olingo.odata2.api.uri.expression.FilterExpression;
import org.apache.olingo.odata2.api.uri.expression.OrderByExpression;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Locale;
import java.util.Map;

import static com.sap.gtt.v2.core.odata.exception.ODataServiceException.MESSAGE_CODE_ERROR_NO_DATA_FOUND;

@Repository  // make it per request since the `model` used in nested level needs to be isolated
@Scope("prototype")
public class GenericDataStore {

    @Autowired
    private ISAPCloudPlatformAgent.ICurrentAccessContext currentContext;
    
    private String model;

    protected GenericDataStore(String model){
        this.model = model;
    }

    public String getModel() {
        return model;
    }

    public static GenericDataStore createInstance(String model){
        return SpringContextUtils.getBean(GenericDataStore.class, model);
    }

    public IMetadataManagement createMetadataService(){
        return currentContext.createBusinessOperator().getMetadataManagement();
    }

    protected SearchClient createSearchClient() {
    	DatabaseServiceInstance databaseServiceInstance = currentContext.getDatabaseServiceInstance();
    	DatabaseType databaseType = databaseServiceInstance.getDatabaseType();
    	if(databaseType == DatabaseType.hana || databaseType == DatabaseType.h2){
    		return DefaultSearchClient.createInstance(model);
    	}
    	else{
    		throw new UnsupportedOperationException(String.format("Database type '%s' not supported", databaseType.name()));
    	}
    }

    public PagedEntitySetList<Map<String, Object>> queryEntitySet(EdmEntitySet entitySet, Map<String,List<KeyPredicate>> keys, List<EdmEntitySet> navigationPath,
                                                                  FilterExpression filter, Integer skip, Integer top, OrderByExpression orderBy,
                                                                  InlineCount inlineCountType, Map<String, String> customQueryOption,
                                                                  List<List<Tuple<String, String>>> expand, Locale locale) {

        SearchClient client = createSearchClient();
        IMetadataManagement metadataService = createMetadataService();
        PagedEntitySetList<Map<String, Object>> result;

        synchronized (client) {
            result = client.setMetadataService(metadataService).setLocale(locale).setEntitySet(entitySet)
                    .setNavigationPath(navigationPath).setKeys(keys).setCustomQueryOption(customQueryOption).setFilter(filter)
                    .setInlineCount(inlineCountType).setSkip(skip).setTop(top).setOrderBy(orderBy).setExpand(expand)
                    .applyAuthorizationFilter().execute().getSearchResult();
        }

        if (InlineCount.ALLPAGES.equals(inlineCountType)) {
            Integer totalCount = queryEntitySetCount(entitySet, keys, navigationPath, filter, null, null, customQueryOption, locale);
            result.setTotalCount(totalCount);
        }
        return result;
    }

    public Integer queryEntitySetCount(EdmEntitySet entitySet, Map<String,List<KeyPredicate>> keys, List<EdmEntitySet> navigationPath,
                                    FilterExpression filter, Integer skip, Integer top,
                                    Map<String, String> customQueryOption, Locale locale) {

        SearchClient client = createSearchClient();
        IMetadataManagement metadataService = createMetadataService();
        Integer resultCount;

        synchronized (client) {
            resultCount = client.setMetadataService(metadataService).setLocale(locale).setEntitySet(entitySet)
                    .setNavigationPath(navigationPath).setKeys(keys).setCustomQueryOption(customQueryOption).setFilter(filter)
                    .setSkip(skip).setTop(top)
                    .applyAuthorizationFilter().execute().getResultCount();

            return resultCount;
        }
    }

    public Map<String, Object> queryEntity(EdmEntitySet targetEntitySet, Map<String, List<KeyPredicate>> keyMap,
                                           List<EdmEntitySet> navigationPath, Map<String, String> customQueryOption,
                                           List<List<Tuple<String, String>>> expand, Locale locale) {
        PagedEntitySetList<Map<String, Object>> resultSet = queryEntitySet(targetEntitySet,keyMap,navigationPath,null,null,null,null,null,customQueryOption,expand,locale);
        List<Map<String, Object>> data = resultSet.getData();
        if (data == null || data.size() == 0) {
            throw new ODataServiceException(MESSAGE_CODE_ERROR_NO_DATA_FOUND);
        }
        return data.get(0);
    }
}