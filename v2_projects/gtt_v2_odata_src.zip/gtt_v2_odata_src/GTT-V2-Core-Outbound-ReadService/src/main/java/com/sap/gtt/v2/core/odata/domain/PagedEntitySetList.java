package com.sap.gtt.v2.core.odata.domain;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class PagedEntitySetList<T> implements Iterable<T> {

    private List<T> data;
    private T foreignKeys;
    private Integer totalCount; // should be lazy

    public PagedEntitySetList() {
        this.data = Collections.emptyList();
        this.totalCount = 0;
    }

    public PagedEntitySetList(List<T> list) {
        if (list != null) {
            this.data = new ArrayList<>(list);
            this.totalCount = list.size();
        }
    }

    public static <T> PagedEntitySetList<T> newInstance(Type type) {
        return new PagedEntitySetList<>();
    }

    public List<T> getData() {
        return this.data == null ? null : new ArrayList<>(this.data);
    }

    public void setData(List<T> data) {
        this.data = new ArrayList<>(data);
    }

    public Integer getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(Integer totalCount) {
        this.totalCount = totalCount;
    }

    public T getForeignKeys() {
        return foreignKeys;
    }

    public void setForeignKeys(T foreignKeys) {
        this.foreignKeys = foreignKeys;
    }

    @Override
    public Iterator<T> iterator() {
        return data.iterator();
    }
}
