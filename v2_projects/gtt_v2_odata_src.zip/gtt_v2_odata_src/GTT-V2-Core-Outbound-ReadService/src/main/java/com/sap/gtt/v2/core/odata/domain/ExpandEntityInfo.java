package com.sap.gtt.v2.core.odata.domain;

public class ExpandEntityInfo {
    String propertyName;
    String entityName;
    String childPropertyName;
    String childEntityName;
    String parentPropertyName;
    String parentEntityName;

    public String getParentPropertyName() {
        return parentPropertyName;
    }

    public void setParentPropertyName(String parentPropertyName) {
        this.parentPropertyName = parentPropertyName;
    }

    public void setParentEntityName(String parentEntityName) {
        this.parentEntityName = parentEntityName;
    }

    public String getParentEntityName() {
        return parentEntityName;
    }

    public String getPropertyName() {
        return propertyName;
    }

    public String getEntityName() {
        return entityName;
    }

    public String getChildPropertyName() {
        return childPropertyName;
    }

    public String getChildEntityName() {
        return childEntityName;
    }

    public void setPropertyName(String propertyName) {
        this.propertyName = propertyName;
    }

    public void setEntityName(String entityName) {
        this.entityName = entityName;
    }

    public void setChildPropertyName(String childPropertyName) {
        this.childPropertyName = childPropertyName;
    }

    public void setChildEntityName(String childEntityName) {
        this.childEntityName = childEntityName;
    }
}
