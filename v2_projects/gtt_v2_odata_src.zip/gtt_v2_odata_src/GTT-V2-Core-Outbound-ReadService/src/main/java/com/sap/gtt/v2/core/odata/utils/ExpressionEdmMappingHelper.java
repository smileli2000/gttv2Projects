package com.sap.gtt.v2.core.odata.utils;

import com.sap.gtt.v2.core.domain.metadata.*;
import com.sap.gtt.v2.core.management.metadata.CsnParser;
import com.sap.gtt.v2.core.management.metadata.IMetadataManagement;
import com.sap.gtt.v2.core.odata.common.Constants;
import com.sap.gtt.v2.core.odata.common.Tuple;
import com.sap.gtt.v2.core.odata.domain.Column;
import com.sap.gtt.v2.core.odata.domain.ExpressionDbEdmMapping;
import com.sap.gtt.v2.core.odata.domain.Table;
import com.sap.gtt.v2.exception.InternalErrorException;
import org.apache.olingo.odata2.api.edm.EdmEntitySet;
import org.apache.olingo.odata2.api.edm.EdmException;
import org.apache.olingo.odata2.api.uri.expression.OrderByExpression;

import java.util.*;
import java.util.stream.Collectors;

import static com.sap.gtt.v2.core.odata.utils.ExpressionUtils.*;
import static com.sap.gtt.v2.core.odata.utils.ODataUtils.copy;

public class ExpressionEdmMappingHelper {

    private IMetadataManagement metadataService;
    private String model;


    public ExpressionEdmMappingHelper(IMetadataManagement metadataService, String model) {
        this.metadataService = metadataService;
        this.model = model;
    }

    public void buildJoinTableColumnForExpand(EdmEntitySet mainEntitySet,
                                              ExpressionDbEdmMapping expressionDbEdmMapping,
                                              List<List<Tuple<String, String>>> expands,
                                              List<Tuple<Table, List<String>>> tableColumn,
                                              List<Table> joinTableName,
                                              List<Tuple<Column, Column>> joinColumn,
                                              Map<String, String> entityColNameMappingOfExpand) {

        if (expands != null && !expands.isEmpty()) {
            expands.stream().forEach(singleExpand -> {
                Tuple<List<Table>, List<Tuple<Column, Column>>> naviList = getNavigationList(singleExpand, mainEntitySet);
                addTableAndColumnIfNotExist(expressionDbEdmMapping.getJoinTableName(),
                        naviList.getK1(), naviList.getK2(), joinTableName, joinColumn);
                addJoinColumnForSpecialFieldsForExpand(singleExpand, tableColumn);
                addEntityColumnNameMappingForSingleExpand(singleExpand, entityColNameMappingOfExpand);
            });
        }
    }

    private void addEntityColumnNameMappingForSingleExpand(List<Tuple<String, String>> singleExpand,
                                                           Map<String, String> entityColNameMappingOfExpand) {
        singleExpand.stream().forEach(col -> entityColNameMappingOfExpand.put(col.getK2(), col.getK1()));
    }

    private void addJoinColumnForSpecialFieldsForExpand(List<Tuple<String, String>> expand,
                                                        List<Tuple<Table, List<String>>> tableColumn) {
        expand.forEach(filedInSingleExpand -> {
            PhysicalName naviTableName = metadataService.getPhysicalNameOfEntity(model, filedInSingleExpand.getK2());
            List<MetadataEntityElement> allNaviColumn = getAllColumnsOfEntity(filedInSingleExpand.getK2());
            String naviTable = naviTableName.getName();
            List<String> naviTableCol = filterAssociationAndCompositionCols(allNaviColumn)
                    .stream().map(e -> e.getName()).collect(Collectors.toList());
            tableColumn.add(new Tuple<>(new Table(naviTable, filedInSingleExpand.getK2()), naviTableCol));
        });
    }

    private void addTableAndColumnIfNotExist(
            List<Table> existedJoinTable,
            List<Table> naviTableList,
            List<Tuple<Column, Column>> naviColList,
            List<Table> joinTableName,
            List<Tuple<Column, Column>> joinColumn
    ) {
        final List<Tuple<Column, Column>> naviColumns = copy(naviColList);
        naviTableList.forEach(naviTable -> {
            if (!existedJoinTable.contains(naviTable)) {
                joinTableName.add(naviTable);
                joinColumn.add(naviColumns.get(0));
            }
            naviColumns.remove(0);
        });
    }

    private Tuple<List<Table>, List<Tuple<Column, Column>>> getNavigationList(List<Tuple<String, String>> expandElem,
                                                                              EdmEntitySet mainEntitySet) {
        try {
            String mainEntityType = mainEntitySet.getEntityType().toString();
            List<String> expandPath = expandElem.stream().map(col -> col.getK1()).collect(Collectors.toList());
            List<MetadataEntity> naviEntities = metadataService.findODataNavigationEntitiesByPath(mainEntityType, getExpandPathStr(expandElem));
            return getNaviTableAndNaviColList(naviEntities, expandPath,
                    extractedEntityNameFromFullName(mainEntityType), metadataService, model);
        } catch (EdmException e) {
            throw new InternalErrorException(e);
        }
    }

    private String getExpandPathStr(List<Tuple<String, String>> expandElem) {
        List<String> expandPath = expandElem.stream().map(col -> col.getK1()).collect(Collectors.toList());
        return expandPath.stream().collect(Collectors.joining("/"));
    }

    public void buildJoinTableColumnForNavigation(Table targetTable,
                                                  List<EdmEntitySet> navigationPath,
                                                  List<Table> joinTable,
                                                  List<Tuple<Column, Column>> joinColumn) {
        List<Table> navJoinTable = new ArrayList<>();
        List<Tuple<Column, Column>> navJoinColumn = new ArrayList<>();

        if (navigationPath != null && navigationPath.size() > 1) {
            for (int i = 0; i < navigationPath.size() - 1; i++) {

                EdmEntitySet firstEntitySet = navigationPath.get(i);
                EdmEntitySet secondEntitySet = navigationPath.get(i + 1);

                processAssociation(firstEntitySet, secondEntitySet, navJoinTable, navJoinColumn);
                processComposition(firstEntitySet, secondEntitySet, navJoinTable, navJoinColumn);
            }
        }

        for (int i = navJoinTable.size() - 1; i >= 0; i--) {
            if (!navJoinTable.get(i).equals(targetTable)
                    && !joinTable.contains(navJoinTable.get(i)))
                joinTable.add(navJoinTable.get(i));
        }

        for (int i = navJoinColumn.size() - 1; i >= 0; i--) {
            joinColumn.add(navJoinColumn.get(i));
        }
    }

    // Relationship: 1..1
    private void processAssociation(EdmEntitySet startEntitySet, EdmEntitySet endEntitySet, List<Table> joinTable, List<Tuple<Column, Column>> joinColumn) {
        try {
            String startEntityName = startEntitySet.getName();
            String endEntityName = endEntitySet.getName();
            Map<String, MetadataEntityElement> allFieldsInStartEntity = metadataService.findAllFieldsOfEntity(model, startEntityName);
            for (String key : allFieldsInStartEntity.keySet()) {
                MetadataEntityElement entityElement = allFieldsInStartEntity.get(key);
                if (entityElement.getType().equals(MetadataConstants.CdsDataType.CDS_ASSOCIATION)
                        && CsnParser.getEntityAbbrName(entityElement.getTarget()).equals(CsnParser.getEntityAbbrName(endEntitySet.getEntityType().toString()))) {
                    MetadataForeignKey foreignKey = entityElement.getForeignKey();
                    PhysicalName startTableName = metadataService.getPhysicalNameOfEntity(model, startEntityName);
                    PhysicalName endTableName = metadataService.getPhysicalNameOfEntity(model, endEntityName);
                    Tuple<Column, Column> foreignKeyMap = new Tuple(new Column(foreignKey.getGeneratedFieldName(), new Table(startTableName.getName(), startEntityName)),
                            new Column(foreignKey.getReferenceFieldName(), new Table(endTableName.getName(), endEntityName)));
                    joinTable.add(new Table(startTableName.getName(), startEntityName));
                    joinTable.add(new Table(endTableName.getName(), endEntityName));
                    joinColumn.add(foreignKeyMap);
                    break;
                }
            }
        } catch (EdmException e) {
            throw new InternalErrorException(e);
        }
    }

    //Relationship:1..*
    private void processComposition(EdmEntitySet startEntitySet, EdmEntitySet endEntitySet, List<Table> joinTable, List<Tuple<Column, Column>> joinColumn) {
        try {
            String startEntityName = startEntitySet.getName();
            String endEntityName = endEntitySet.getName();
            Map<String, MetadataEntityElement> allColumnInStartEntity = metadataService.findAllFieldsOfEntity(model, startEntityName);

            for (String key : allColumnInStartEntity.keySet()) {
                MetadataEntityElement elemInStartEntity = allColumnInStartEntity.get(key);
                if (elemInStartEntity.getType().equals(MetadataConstants.CdsDataType.CDS_COMPOSITION)
                ) {
                    PhysicalName startEntityTableName = metadataService.getPhysicalNameOfEntity(model, startEntityName);
                    String mainTableName = startEntityTableName.getName();
                    String coreTableName = startEntityTableName.getCorePhysicalName();
                    String targetType = elemInStartEntity.getTarget();
                    String targetTypeName = targetType.substring(targetType.lastIndexOf(".") + 1);
                    if (targetTypeName.equals(endEntityName)) {
                        Optional<MetadataEntityElement> firstElem = allColumnInStartEntity.values().stream().filter(col -> col.isKey()).findFirst();
                        if (firstElem.isPresent()) {
                            String joinKey = firstElem.get().getName();
                            updateJoinTableColumn(joinTable, joinColumn,
                                    new Table(mainTableName, startEntityName),
                                    new Table(coreTableName, ExpressionUtils.getCoreEntityName(startEntityName)),
                                    new Tuple(new Column(joinKey, new Table(mainTableName, startEntityName)),
                                            new Column(joinKey, new Table(coreTableName, ExpressionUtils.getCoreEntityName(startEntityName)))));
                        }
                        MetadataForeignKey foreignKey = elemInStartEntity.getForeignKey();
                        String endEntityTableName = metadataService.getPhysicalNameOfEntity(model, endEntityName).getName();
                        updateJoinTableColumn(joinTable, joinColumn,
                                new Table(coreTableName, ExpressionUtils.getCoreEntityName(startEntityName)),
                                new Table(endEntityTableName, endEntityName),
                                new Tuple<>(new Column(foreignKey.getReferenceFieldName(), new Table(coreTableName, ExpressionUtils.getCoreEntityName(startEntityName))),
                                        new Column(foreignKey.getGeneratedFieldName(), new Table(endEntityTableName, endEntityName))));
                    }
                }
            }
        } catch (EdmException e) {
            throw new InternalErrorException(e);
        }
    }

    public void buildJoinTableColumnForOrderBy(EdmEntitySet entitySet,
                                               OrderByExpression orderBy,
                                               List<Table> joinTableList,
                                               List<Tuple<Column, Column>> joinColumn) throws EdmException {
        if (orderBy == null || orderBy.getOrders().isEmpty())
            return;
        List<Tuple<Column, Column>> naviColList;
        List<String> naviPathStrList = Arrays.stream(orderBy.getExpressionString().split(Constants.QUERY_PARAMS_SPLITER))
                .collect(Collectors.toList());

        for (String naviPathStr : naviPathStrList) {
            List<String> naviPath = Arrays.stream(naviPathStr.split(Constants.URL_SPLITTER)).collect(Collectors.toList());
            List<MetadataEntity> naviEntities = metadataService.findODataNavigationEntitiesByPath(entitySet.getEntityType().toString(), naviPathStr);
            Tuple<List<Table>, List<Tuple<Column, Column>>> naviList = getNaviTableAndNaviColList(naviEntities, naviPath,
                    extractedEntityNameFromFullName(entitySet.getEntityType().toString()), metadataService, model);
            List<Table> naviTableList = naviList.getK1();
            naviColList = naviList.getK2();
            addTableAndColumnIfNotExist(joinTableList, naviTableList, naviColList, joinTableList, joinColumn);
        }
    }

    private List<MetadataEntityElement> getAllColumnsOfEntity(String entityName) {
        return metadataService.findAllFieldsOfEntity(model, entityName).values().stream().collect(Collectors.toList());
    }

    private void updateJoinTableColumn(List<Table> joinTableList, List<Tuple<Column, Column>> joinColumnList, Table firstTable, Table secondTable, Tuple<Column, Column> joinColumn) {
        joinTableList.add(firstTable);
        joinTableList.add(secondTable);
        joinColumnList.add(joinColumn);
    }
}
