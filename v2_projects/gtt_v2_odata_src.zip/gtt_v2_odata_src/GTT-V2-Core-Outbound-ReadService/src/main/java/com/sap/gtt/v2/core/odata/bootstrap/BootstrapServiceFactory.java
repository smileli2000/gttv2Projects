package com.sap.gtt.v2.core.odata.bootstrap;

import com.sap.gtt.v2.configuration.ISAPCloudPlatformAgent;
import com.sap.gtt.v2.controller.DefaultExceptionHandler;
import com.sap.gtt.v2.core.management.metadata.IMetadataManagement;
import com.sap.gtt.v2.core.odata.common.Constants;
import com.sap.gtt.v2.core.odata.exception.ODataServiceException;
import com.sap.gtt.v2.core.odata.exception.ODataServiceNotFoundException;
import com.sap.gtt.v2.core.odata.service.GenericODataSingleProcessor;
import com.sap.gtt.v2.exception.FormattedErrorMessage;
import com.sap.gtt.v2.util.GTTUtils;
import com.sap.gtt.v2.util.SpringContextUtils;
import org.apache.olingo.odata2.api.ODataCallback;
import org.apache.olingo.odata2.api.ODataService;
import org.apache.olingo.odata2.api.ODataServiceFactory;
import org.apache.olingo.odata2.api.commons.HttpStatusCodes;
import org.apache.olingo.odata2.api.ep.EntityProvider;
import org.apache.olingo.odata2.api.exception.ODataException;
import org.apache.olingo.odata2.api.processor.ODataContext;
import org.apache.olingo.odata2.api.processor.ODataErrorCallback;
import org.apache.olingo.odata2.api.processor.ODataErrorContext;
import org.apache.olingo.odata2.api.processor.ODataResponse;
import org.apache.olingo.odata2.core.edm.provider.EdmxProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;

import static com.sap.gtt.v2.core.odata.exception.ODataServiceNotFoundException.MESSAGE_CODE_ERROR_METADATA_NOT_FOUND;
import static org.apache.olingo.odata2.api.processor.ODataContext.HTTP_SERVLET_REQUEST_OBJECT;

@Component
public class BootstrapServiceFactory extends ODataServiceFactory {

    @Autowired
    private ISAPCloudPlatformAgent.ICurrentAccessContext currentContext;

    private IMetadataManagement metadataService;

    @Override
    public ODataService createService(ODataContext ctx) {
        String model = null;
        Object reqObject = ctx.getParameter(HTTP_SERVLET_REQUEST_OBJECT);
        if (reqObject != null) {
            Object modelAttr = ((RequestWrapper) reqObject).getRequest().getAttribute(Constants.MODEL_ATTRIBUTE_KEY);
            if (modelAttr != null) {
                model = modelAttr.toString();
            }
        }
        if (model == null) {
            throw new ODataServiceNotFoundException("Model not found!!");
        }

        try {
            metadataService = getMetadataService();
            String edmx = metadataService.getODataEdmx(model);
            if (edmx.isEmpty()) {
                throw new ODataServiceNotFoundException(MESSAGE_CODE_ERROR_METADATA_NOT_FOUND);
            }
            EdmxProvider provider = new EdmxProvider().parse(new ByteArrayInputStream(edmx.getBytes(StandardCharsets.UTF_8)), false);
            GenericODataSingleProcessor singleProcessor = SpringContextUtils.getBean(GenericODataSingleProcessor.class);
            return createODataSingleProcessorService(provider, singleProcessor);

        } catch (ODataException e) {
            throw new ODataServiceException(e);
        }

    }

    @SuppressWarnings("unchecked")
    @Override
    public <T extends ODataCallback> T getCallback(final Class<T> callbackInterface) {
        T result;
        if (callbackInterface.isAssignableFrom(GlobalErrorCallback.class)) {
            result = (T) new GlobalErrorCallback();
        } else {
            result = (T) super.getCallback(callbackInterface);
        }

        return result;
    }

    public static class GlobalErrorCallback implements ODataErrorCallback {
        @Override
        public ODataResponse handleError(ODataErrorContext context) {
            ODataErrorContext transformedContext = GTTUtils.createAndCopyBean(context, ODataErrorContext.class, false);
            Exception exception = context.getException();
            DefaultExceptionHandler exceptionHandler = SpringContextUtils.getBean(DefaultExceptionHandler.class);

            String errorCode;
            String message;
            if (exception instanceof ODataException) {
                errorCode = exception.toString().split(":")[0];
            } else {
                FormattedErrorMessage formattedErrorMessage = exceptionHandler.handleExceptionAndTransformMessage(exception);

                transformedContext.setHttpStatus(HttpStatusCodes.fromStatusCode(formattedErrorMessage.getHttpStatus()));
                com.sap.gtt.v2.exception.FormattedErrorMessage.Error error = formattedErrorMessage.getError();
                if (error == null) {
                    error = formattedErrorMessage.getErrors().get(0); // OData do not support multiple exception, return the first one
                }
                errorCode = error.getCode();
                message = error.getMessage().getValue();
                transformedContext.setMessage(message);
            }

            transformedContext.setErrorCode(errorCode);
            transformedContext.setLocale(context.getLocale());
            transformedContext.setInnerError(null);

            return EntityProvider.writeErrorDocument(transformedContext);
        }

    }

    public IMetadataManagement getMetadataService() {
        return currentContext.createBusinessOperator().getMetadataManagement();
    }

}
