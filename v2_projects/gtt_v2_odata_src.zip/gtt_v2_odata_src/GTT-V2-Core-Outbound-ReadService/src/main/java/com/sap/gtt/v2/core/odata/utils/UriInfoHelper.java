package com.sap.gtt.v2.core.odata.utils;

import com.sap.gtt.v2.core.odata.common.Tuple;
import com.sap.gtt.v2.exception.InternalErrorException;
import org.apache.olingo.odata2.api.edm.EdmEntitySet;
import org.apache.olingo.odata2.api.edm.EdmException;
import org.apache.olingo.odata2.api.uri.KeyPredicate;
import org.apache.olingo.odata2.api.uri.NavigationPropertySegment;
import org.apache.olingo.odata2.api.uri.NavigationSegment;

import java.util.*;

public class UriInfoHelper {

    private List<EdmEntitySet> navigationPath;
    private Map<String, List<KeyPredicate>> keyMap;
    private List<List<Tuple<String, String>>> expand;

    public List<EdmEntitySet> getNavigationPath() {
        return Collections.unmodifiableList(navigationPath) ;
    }

    public Map<String, List<KeyPredicate>> getKeyMap() {
        return keyMap;
    }

    public List<List<Tuple<String, String>>> getExpand() {
        return Collections.unmodifiableList(expand);
    }

    public UriInfoHelper initialize(EdmEntitySet startEntitySet, List<KeyPredicate> keyPredicates,
                                                                List<ArrayList<NavigationPropertySegment>> expandInUriInfo,
                                                                List<NavigationSegment> navigationSegments) throws EdmException {
        expand = extractedExpand(expandInUriInfo);
        //record the sequence of entities
        navigationPath = new ArrayList<>();
        //find key predicates for all entities
        keyMap = new HashMap<>();
        buildNavigationPath(startEntitySet, navigationPath, keyMap, keyPredicates, navigationSegments);
        return this;
    }

    private void buildNavigationPath(EdmEntitySet startEntitySet, List<EdmEntitySet> navigationPath, Map<String, List<KeyPredicate>> keyMap, List<KeyPredicate> keyPredicates, List<NavigationSegment> navigationSegments) throws EdmException {
        String startEntityName = startEntitySet.getEntityType().getName();
        List<KeyPredicate> startEntityKeyPredicate = new ArrayList<>();
        startEntityKeyPredicate.addAll(keyPredicates);
        keyMap.put(startEntityName, startEntityKeyPredicate);
        navigationPath.add(startEntitySet);

        navigationSegments.forEach(e -> {
            try {
                String currentEntityName = e.getEntitySet().getEntityType().getName();
                List<KeyPredicate> currentKeyPredicate = e.getKeyPredicates();
                keyMap.put(currentEntityName, currentKeyPredicate);
                navigationPath.add(e.getEntitySet());
            } catch (EdmException ex) {
                throw new InternalErrorException(ex);
            }
        });
    }

    private List<List<Tuple<String, String>>> extractedExpand(List<ArrayList<NavigationPropertySegment>> expand) {
        if (expand != null) {
            List<List<Tuple<String, String>>> extractedExpand = new ArrayList<>();
            expand.forEach(ele -> {
                List<Tuple<String, String>> singleExpand = new ArrayList<>();
                ele.forEach(n -> {
                    try {
                        String naviProp = n.getNavigationProperty().getName().toString();
                        String naviEntity = n.getTargetEntitySet().getName().toString();
                        singleExpand.add(new Tuple<>(naviProp, naviEntity));
                    } catch (EdmException e) {
                        throw new InternalErrorException(e);
                    }
                });
                if (!singleExpand.isEmpty()) {
                    extractedExpand.add(singleExpand);
                }
            });
            return extractedExpand;
        }
        return Collections.emptyList();
    }
}
