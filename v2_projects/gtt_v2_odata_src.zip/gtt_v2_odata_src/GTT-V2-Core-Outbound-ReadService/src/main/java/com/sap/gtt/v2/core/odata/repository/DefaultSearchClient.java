package com.sap.gtt.v2.core.odata.repository;

import com.sap.gtt.v2.core.odata.common.Constants;
import com.sap.gtt.v2.core.odata.domain.Expression;
import com.sap.gtt.v2.core.odata.domain.ExpressionDbEdmMapping;
import com.sap.gtt.v2.core.odata.domain.PagedEntitySetList;
import com.sap.gtt.v2.core.odata.utils.DataPostprocessingHelper;
import com.sap.gtt.v2.log.TenantAwareLogService;
import com.sap.gtt.v2.util.SpringContextUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service(DefaultSearchClient.BEAN_NAME)
@Scope("prototype")
public class DefaultSearchClient extends SearchClient {
    public static final String BEAN_NAME = "com.sap.gtt.v2.core.odata.repository.DefaultSearchClient";

    protected DefaultSearchClient(String model) {
        super(model);
    }

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    protected TenantAwareLogService logService;

    private ExpressionDbEdmMapping expressionDbEdmMapping;
    private Expression expression;

    @Override
    public DefaultSearchClient execute() {
        initialize();
        return this;
    }

    @Override
    public PagedEntitySetList<Map<String, Object>> getSearchResult() {
        logService.info("Before expression.toSqlPrepareStmt() ");
        String sqlPrepareStmt = expression.toSqlPrepareStmt();
        logService.info("Query Sql is {}", sqlPrepareStmt);
        List<Map<String, Object>> resultList = performQuery(sqlPrepareStmt, expression.getParameters());
        PagedEntitySetList pageEntitySetList = new PagedEntitySetList(postProcessing(resultList));
        return pageEntitySetList;
    }

    @Override
    public Integer getResultCount() {
        logService.info("Before expression.toSqlPrepareStmt() ");
        String sqlPrepareStmt = expression.toCountSqlPrepareStmt();
        logService.info("Query Sql is {}", sqlPrepareStmt);
        return performQueryCount(sqlPrepareStmt, expression.getParameters());
    }

    private void initialize() {
        expressionDbEdmMapping = ExpressionDbEdmMapping.getExpressionDbEdmMappingInstance(this);
        expression = Expression.getExpressionInstance(this,expressionDbEdmMapping);
    }

    private List<Map<String, Object>> performQuery(String sqlPrepareStmt, List<Object> args) {
        return jdbcTemplate.queryForList(sqlPrepareStmt, args.toArray());
    }

    private Integer performQueryCount(String sqlPrepareStmt, List<Object> args) {
        List<Map<String, Object>> sqlExecutionList = jdbcTemplate.queryForList(sqlPrepareStmt, args.toArray());
        return Integer.parseInt(sqlExecutionList.get(0).get(Constants.QUERY_TOTAL_COUNT).toString());
    }

    private List<Map<String, Object>> postProcessing(List<Map<String, Object>> dataList) {
        String mainEntityName = expressionDbEdmMapping.getTableName().getEntityName();
        DataPostprocessingHelper helper = new DataPostprocessingHelper(metadataService, model);
        //nested sql query result data list
        List<Map<String, Object>> nestDataList = helper.convertJdbcResToNestedList(mainEntityName, expand).apply(dataList);
        //replace specific data type, e.g. GUID column
        List<Map<String, Object>> replacedDataList = helper.replaceDataType(entitySet, expand).apply(nestDataList);

        logService.info("ResultList is {} ", replacedDataList.toString());

        return replacedDataList;
    }

    public static DefaultSearchClient createInstance(String model) {
        return (DefaultSearchClient) SpringContextUtils.getBean(BEAN_NAME, model);
    }

}
