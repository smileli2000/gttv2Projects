package com.sap.gtt.v2.core.odata.utils;

import com.sap.gtt.v2.core.domain.metadata.MetadataConstants;
import com.sap.gtt.v2.core.domain.metadata.MetadataEntityElement;
import com.sap.gtt.v2.core.management.metadata.IMetadataManagement;
import com.sap.gtt.v2.exception.InternalErrorException;
import org.apache.olingo.odata2.api.edm.*;
import org.apache.olingo.odata2.api.uri.KeyPredicate;
import org.apache.olingo.odata2.core.uri.KeyPredicateImpl;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class ODataUtils {
    private final static String PARENT_KEY = "id";
    private final static String FOREIGN_KEY = "processid";

    public static List<KeyPredicate> mapToKeyPredicateList(Map<String, Object> keys, EdmEntityType entityType) {
        try {
            List<EdmProperty> keyProperties = entityType.getKeyProperties();

            return keyProperties.stream().filter(key -> {
                String name;
                try {
                    name = key.getName();
                } catch (EdmException e) {
                    throw new InternalErrorException(e);
                }
                return keys.containsKey(name);
            }).map(key -> {
                String name = "";
                try {
                    name = key.getName();
                } catch (EdmException e) {
                    throw new InternalErrorException(e);
                }
                return new KeyPredicateImpl(keys.get(name).toString(), key);
            }).collect(Collectors.toList());
        } catch (EdmException e) {
            throw new InternalErrorException(e);
        }
    }

    public static Map<String, Object> extractAssociationKey(EdmNavigationProperty navigationProperty, Map<String, Object> entryData) throws EdmException {
        EdmReferentialConstraint referentialConstraint = navigationProperty.getRelationship().getReferentialConstraint();
        EdmReferentialConstraintRole dependent = referentialConstraint.getDependent();
        EdmReferentialConstraintRole principal = referentialConstraint.getPrincipal();

        List<String> dependentRefNames;
        List<String> principalRefNames;

        if (EdmMultiplicity.ZERO_TO_ONE.equals(navigationProperty.getMultiplicity())
                && dependent.getPropertyRefNames().stream().noneMatch(name -> PARENT_KEY.equalsIgnoreCase(name))) {
            dependentRefNames = Stream.of(dependent.getPropertyRefNames(), Collections.singletonList(PARENT_KEY)).flatMap(List::stream)
                    .collect(Collectors.toList());
            principalRefNames = Stream.of(principal.getPropertyRefNames(), Collections.singletonList(FOREIGN_KEY)).flatMap(List::stream)
                    .collect(Collectors.toList());
        } else {
            dependentRefNames = dependent.getPropertyRefNames();
            principalRefNames = principal.getPropertyRefNames();
        }

        return entryData.entrySet().stream()
                .filter(entry -> dependentRefNames.indexOf(entry.getKey()) != -1)
                .map(entry -> {
                    String originalKey = entry.getKey();
                    String newKey = principalRefNames.get(dependentRefNames.indexOf(originalKey));

                    return new AbstractMap.SimpleEntry<>(newKey, Optional.ofNullable(entry.getValue()).orElse(""));
                })
                .collect(Collectors.toMap(AbstractMap.SimpleEntry::getKey, AbstractMap.SimpleEntry::getValue));
    }

    public static <T> List<T> copy(List<T> existedList) {
        List<T> list = new ArrayList<>();
        if (existedList != null) {
            list.addAll(existedList);
        }
        return list;
    }

    public static boolean validate(String str) {
        return str.matches("[0-9a-zA-Z_.]+");
    }

    public static String inputStreamToString(InputStream input) throws IOException {
        Scanner s = new Scanner(input, StandardCharsets.UTF_8.toString());
        StringBuilder sb = new StringBuilder();

        while (s.hasNext()) {
            sb.append(s.nextLine());
        }
        s.close();

        input.close();

        return sb.toString();
    }

    public static boolean notEqual(Object one, Object two) {
        return (one != null && two != null && !one.toString().equalsIgnoreCase(two.toString()));
    }

    public static List<String> getEntityPrimaryKey(String entityName, String model, IMetadataManagement metadataService) {
        List<MetadataEntityElement> allColumn = metadataService.findAllFieldsOfEntity(model, entityName).values().stream().collect(Collectors.toList());
        return allColumn.stream().filter(col -> col.isKey()).map(MetadataEntityElement::getName).collect(Collectors.toList());
    }

    public static List<String> findAllColumnsOfGivenType(List<MetadataEntityElement> allColumns, MetadataConstants.CdsDataType cdsDataType) {
        return allColumns
                .stream().filter(c -> cdsDataType.getValue().equals(c.getType().getValue()))
                .map(e -> e.getName()).collect(Collectors.toList());
    }

    public static List<MetadataEntityElement> getAllColumnsOfEntity(String entityName, IMetadataManagement metadataService, String model) {
        return metadataService.findAllFieldsOfEntity(model, entityName).values().stream().collect(Collectors.toList());
    }
}
