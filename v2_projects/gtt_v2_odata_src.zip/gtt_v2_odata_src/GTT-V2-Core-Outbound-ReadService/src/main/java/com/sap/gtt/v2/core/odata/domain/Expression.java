package com.sap.gtt.v2.core.odata.domain;

import com.sap.gtt.v2.core.domain.metadata.MetadataConstants;
import com.sap.gtt.v2.core.domain.metadata.MetadataEntityElement;
import com.sap.gtt.v2.core.management.metadata.CsnParser;
import com.sap.gtt.v2.core.management.metadata.IMetadataManagement;
import com.sap.gtt.v2.core.odata.common.Constants;
import com.sap.gtt.v2.core.odata.common.Storage;
import com.sap.gtt.v2.core.odata.common.Tuple;
import com.sap.gtt.v2.core.odata.repository.DefaultODataFilterExpressionVisitor;
import com.sap.gtt.v2.core.odata.repository.SearchClient;
import com.sap.gtt.v2.exception.InternalErrorException;
import org.apache.olingo.odata2.api.edm.EdmEntitySet;
import org.apache.olingo.odata2.api.edm.EdmException;
import org.apache.olingo.odata2.api.edm.EdmNavigationProperty;
import org.apache.olingo.odata2.api.exception.ODataApplicationException;
import org.apache.olingo.odata2.api.uri.expression.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static com.sap.gtt.v2.core.odata.utils.ExpressionUtils.*;
import static com.sap.gtt.v2.core.odata.utils.ODataUtils.copy;

public class Expression {

    private List<Object> parameters = new ArrayList<>();
    private BinaryOperator operator;
    private MethodOperator methodOperator;
    private List<Column> select = new ArrayList<>();// SQL SELECT part
    private String from = ""; // SQL FROM part
    private String where = "";// SQL WHERE part
    private List<Tuple<Column, SortOrder>> orderByWhole;
    private List<Tuple<Column, SortOrder>> orderByMainEntity;
    private Integer top;
    private Integer skip;
    private List<EdmNavigationProperty> navigationProperties = new ArrayList<EdmNavigationProperty>();
    private String joinColumn;
    private List<Column> primaryKeys;

    public Expression() {
    }

    public Expression(final BinaryOperator operator) {
        this.operator = operator;
    }

    public List<Column> getPrimaryKeys() {
        return copy(primaryKeys);
    }

    public void setPrimaryKeys(List<Column> primaryKeys) {
        this.primaryKeys = copy(primaryKeys);
    }

    public void addParameter(Object parameter) {
        parameters.add(parameter);
    }

    public String getWhere() {
        return where;
    }

    public List<Object> getParameters() {
        return copy(parameters);
    }

    public BinaryOperator getOperator() {
        return operator;
    }

    public MethodOperator getMethodOperator() {
        return methodOperator;
    }

    public void setMethodOperator(MethodOperator methodOperator) {
        this.methodOperator = methodOperator;
    }

    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public List<Column> getSelect() {
        return copy(select);
    }

    public void setSelect(List<Column> select) {
        this.select = copy(select);
    }

    public void setWhere(String where) {
        this.where = where;
    }

    public List<Tuple<Column, SortOrder>> getOrderByWhole() {
        return copy(orderByWhole);
    }

    public void setOrderByWhole(List<Tuple<Column, SortOrder>> orderByWhole) {
        this.orderByWhole = copy(orderByWhole);
    }

    public List<Tuple<Column, SortOrder>> getOrderByMainEntity() {
        return copy(orderByMainEntity);
    }

    public void setOrderByMainEntity(List<Tuple<Column, SortOrder>> orderByMainEntity) {
        this.orderByMainEntity = copy(orderByMainEntity);
    }

    public List<EdmNavigationProperty> getNavigationProperties() {
        return copy(navigationProperties);
    }

    public Integer getTop() {
        return top;
    }

    public void setTop(int top) {
        this.top = top;
    }

    public Integer getSkip() {
        return skip;
    }

    public void setSkip(int skip) {
        this.skip = skip;
    }

    public String getJoinColumn() {
        return joinColumn;
    }

    public void setJoinColumn(String joinColumn) {
        this.joinColumn = joinColumn;
    }

    @Override
    public String toString() {
        return where;
    }

    public String getSelectToString() {
        return combineListWithComma(combineColumnWithTableByDot(select));
    }

    public String toSqlPrepareStmt() {

        return covertSqlPrepareStmt(this);
    }

    public String toCountSqlPrepareStmt() {
        return convertCountSqlPrepareStmt(this);
    }

    public static void transformOrderExpression(EdmEntitySet entitySet,
                                                IMetadataManagement metadataService,
                                                String model,
                                                OrderExpression orderExpression,
                                                List<Tuple<Column, SortOrder>> orderByListWhole,
                                                List<Tuple<Column, SortOrder>> orderByListMainEntity) throws EdmException {

        boolean isMainEntity = orderExpression.getExpression().getKind() == ExpressionKind.PROPERTY ? true : false;

        CommonExpression currentExpression = orderExpression.getExpression();
        String entityName = entitySet.getName();
        String colName = currentExpression.getUriLiteral();

        while (currentExpression.getKind() == ExpressionKind.MEMBER) {
            entityName = ((MemberExpression) currentExpression).getPath().getEdmType().getName();
            colName = ((MemberExpression) currentExpression).getProperty().getUriLiteral();
            currentExpression = ((MemberExpression) currentExpression).getPath();
        }

        String tableName = metadataService.getPhysicalNameOfEntity(model, entityName).getName();

        Column column;
        Map<String, MetadataEntityElement> allFieldsOfEntity = metadataService.findAllFieldsOfEntity(model, entityName);
        boolean isCoreModelEntity = CsnParser.isCoreModelEntity(MetadataConstants.CORE_MODEL_PREFIX + Constants.MODEL_SPLITTER + entityName);

        MetadataEntityElement colElem = allFieldsOfEntity.get(colName);
        if (!isCoreModelEntity && !colElem.isKey() && !colElem.isCustomizedField()) {
            column = new Column(colName, new Table(tableName, getCoreEntityName(entityName)));
        } else {
            column = new Column(colName, new Table(tableName, entityName));
        }
        Tuple sortByElem = new Tuple<>(column, orderExpression.getSortOrder());
        orderByListWhole.add(sortByElem);
        if (isMainEntity) {
            orderByListMainEntity.add(sortByElem);
        }
    }

    public static Expression getExpressionInstance(SearchClient searchClient,
                                                   ExpressionDbEdmMapping expressionDbEdmMapping) {

        final Expression expression;
        try {
            if (searchClient.getFilter() != null) {
                DefaultODataFilterExpressionVisitor filterExpressionVisitor =
                        new DefaultODataFilterExpressionVisitor(Storage.DEFAULT, expressionDbEdmMapping, searchClient.getMetadataService(),
                                searchClient.getEntitySet().getEntityType().toString(), searchClient.getModel());
                expression = (Expression) searchClient.getFilter().accept(filterExpressionVisitor);
                expressionDbEdmMapping = filterExpressionVisitor.getExpressionDbEdmMapping();
            } else {
                expression = new Expression();
            }
        } catch (ExceptionVisitExpression | ODataApplicationException | EdmException e) {
            throw new InternalErrorException(e);
        }

        if (searchClient.getTop() != null) {
            expression.setTop(searchClient.getTop());
        }
        expression.setSkip(searchClient.getSkip());
        expression.setPrimaryKeys(expressionDbEdmMapping.getPrimaryKeyToColumn());
        expression.setSelect(expressionDbEdmMapping.getSelectToColumn());
        expression.setFrom(expressionDbEdmMapping.getFromToString());
        expression.setJoinColumn(expressionDbEdmMapping.getJoinColumnToString());

        //covert orderby expression to orderby mapping
        if (searchClient.getOrderBy() != null) {
            covertOrderby2OrderbyMapping(searchClient, expression);
        }

        //covert 'navigationProperty' into sql prepare statement - where
        if (searchClient.getKeys() != null && !searchClient.getKeys().isEmpty()) {
            covertNaviProperty2Sql(searchClient, expression);
        }
        return expression;
    }

    private static void covertOrderby2OrderbyMapping(SearchClient searchClient, Expression expression) {
        List<OrderExpression> orderExpressionList = searchClient.getOrderBy().getOrders();
        List<Tuple<Column, SortOrder>> orderByListWhole = new ArrayList<>();
        List<Tuple<Column, SortOrder>> orderByListMainEntity = new ArrayList<>();

        orderExpressionList.forEach(order -> {
            try {
                transformOrderExpression(searchClient.getEntitySet(), searchClient.getMetadataService(), searchClient.getModel(), order, orderByListWhole, orderByListMainEntity);
            } catch (EdmException e) {
                throw new InternalErrorException(e);
            }
        });
        expression.setOrderByMainEntity(orderByListMainEntity);
        expression.setOrderByWhole(orderByListWhole);
    }

    private static void covertNaviProperty2Sql(SearchClient searchClient, Expression expression) {
        searchClient.getKeys().forEach((entityName, keyPredicateList) -> {
            if (!keyPredicateList.isEmpty()) {
                keyPredicateList.forEach(predicate -> {
                    String where = expression.getWhere();
                    try {
                        if (where != null && !where.equals("")) {
                            expression.setWhere(String.format("%s AND %s.%s = ?", where, entityName, predicate.getProperty().getName()));
                            expression.addParameter(predicate.getLiteral());
                        } else {
                            expression.setWhere(String.format("%s.%s = ?", entityName, predicate.getProperty().getName()));
                            expression.addParameter(predicate.getLiteral());
                        }
                    } catch (EdmException e) {
                        throw new InternalErrorException(e);
                    }
                });
            }
        });
    }
}

