package com.sap.gtt.v2.core.odata;

import com.sap.gtt.v2.GTTBaseSpringApplication;
import com.sap.gtt.v2.GTTSpringApplicationLauncher;

public class App extends GTTBaseSpringApplication {

    public static void main(String[] args) {
        GTTSpringApplicationLauncher.run(new App(), args);
    }

    @Override
	protected String[] getMessageSourceBasenamesTobeAdded() {
		return new String[]{"classpath:i18n/messages-outbound-readservice"};
	}
    
    
}