package com.sap.gtt.v2.core.odata.common;

public class Constants {
    private Constants() {
        // Constant class, mark it private
    }
    public static final Integer DEFAULT_WINDOW_SIZE = 128;
    public static final Integer DEFAULT_OFFSET = 0;
    public static final String CORE_PREFIX = "CoreTable";
    public static final String URL_SPLITTER = "/";
    public static final String MODEL_ATTRIBUTE_KEY = "GTT_CORE_ENGINE_MODEL";
    public static final String MODEL_SPLITTER = ".";
    public static final String QUERY_PARAMS_SPLITER = ",";
    public static final String QUERY_TOTAL_COUNT = "TotalCount";
    public static final String QUERY_VALUE_NULL = "null";
    public static final String ODATA_BATCH_PARENT_CONTEXT = "~odataBatchParentContext";

}
