package com.sap.gtt.v2.core.odata.domain;

import com.sap.gtt.v2.core.domain.metadata.MetadataEntityElement;
import com.sap.gtt.v2.core.domain.metadata.PhysicalName;
import com.sap.gtt.v2.core.management.metadata.CsnParser;
import com.sap.gtt.v2.core.management.metadata.IMetadataManagement;
import com.sap.gtt.v2.core.odata.common.Tuple;
import com.sap.gtt.v2.core.odata.repository.DefaultSearchClient;
import com.sap.gtt.v2.core.odata.repository.GenericDataStore;
import com.sap.gtt.v2.core.odata.utils.ExpressionUtils;
import com.sap.gtt.v2.core.odata.utils.ODataUtils;
import com.sap.gtt.v2.util.SpringContextUtils;
import org.apache.olingo.odata2.api.edm.EdmEntitySet;
import org.apache.olingo.odata2.api.edm.EdmException;
import org.apache.olingo.odata2.api.uri.KeyPredicate;
import org.apache.olingo.odata2.api.uri.expression.*;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import java.util.*;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.BDDMockito.given;

@RunWith(PowerMockRunner.class)
@PrepareForTest({CsnParser.class})
public class ExpressionTest {

    @Mock
    private IMetadataManagement metadataService;

    @Test
    public void testConstructor() {
        Expression expression = new Expression();
        assertNotNull(expression);

        expression = new Expression(BinaryOperator.AND);
        assertNotNull(expression);
        assertEquals(BinaryOperator.AND, expression.getOperator());
    }

    @Test
    public void testSettersAndGetters() {
        Expression expression = new Expression();
        assertNotNull(expression);

        expression.setWhere("where");
        expression.setFrom("from");
        expression.setMethodOperator(MethodOperator.SUBSTRINGOF);
        expression.setJoinColumn("join column");
        expression.setOrderByWhole(Collections.emptyList());
        expression.setOrderByMainEntity(Collections.emptyList());
        expression.setSelect(Collections.emptyList());
        expression.setSkip(1);
        expression.setTop(1);

        assertEquals("where", expression.getWhere());
        assertEquals("from", expression.getFrom());
        assertEquals(MethodOperator.SUBSTRINGOF, expression.getMethodOperator());
        assertEquals("join column", expression.getJoinColumn());
        assertEquals(Collections.emptyList(), expression.getOrderByWhole());
        assertEquals(Collections.emptyList(), expression.getOrderByMainEntity());
        assertEquals(Collections.emptyList(), expression.getSelect());
        assertEquals(1, expression.getSkip().intValue());
        assertEquals(1, expression.getTop().intValue());
    }

    @Test
    public void testGetExpressionInstance(){

        ExpressionDbEdmMapping expressionDbEdmMapping = Mockito.mock(ExpressionDbEdmMapping.class);
        EdmEntitySet entitySet = Mockito.mock(EdmEntitySet.class);
        String model = "";
        Map<String, List<KeyPredicate>> keys = new HashMap<>();
        OrderByExpression orderBy = Mockito.mock(OrderByExpression.class);
        Integer top = 10;
        Integer skip = 3;

        DefaultSearchClient defaultSearchClient = Mockito.mock(DefaultSearchClient.class);
        Mockito.when(defaultSearchClient.getEntitySet()).thenReturn(entitySet);
        Mockito.when(defaultSearchClient.getModel()).thenReturn(model);
        Mockito.when(defaultSearchClient.getMetadataService()).thenReturn(metadataService);
        Mockito.when(defaultSearchClient.getKeys()).thenReturn(keys);
        Mockito.when(defaultSearchClient.getOrderBy()).thenReturn(orderBy);
        Mockito.when(defaultSearchClient.getTop()).thenReturn(top);
        Mockito.when(defaultSearchClient.getSkip()).thenReturn(skip);

        Expression expression = Expression.getExpressionInstance(defaultSearchClient,expressionDbEdmMapping);
        assertNotNull(expression);
    }

    @Test
    public void transformOrderExpression() throws EdmException{
        EdmEntitySet entitySet = Mockito.mock(EdmEntitySet.class);
        Mockito.when(entitySet.getName()).thenReturn("FreightOrderProcess");
        String model = "";
        OrderExpression orderExpression = Mockito.mock(OrderExpression.class);
        CommonExpression currentExpression = Mockito.mock(CommonExpression.class);
        Mockito.when(orderExpression.getExpression()).thenReturn(currentExpression);
        Mockito.when(orderExpression.getSortOrder()).thenReturn(SortOrder.asc);
        Mockito.when(currentExpression.getKind()).thenReturn(ExpressionKind.PROPERTY);
        Mockito.when(currentExpression.getUriLiteral()).thenReturn("totalWeight");
        PhysicalName physicalName = Mockito.mock(PhysicalName.class);
        Mockito.when(physicalName.getName()).thenReturn("FREIGHTORDERPROCESS");
        Mockito.when(metadataService.getPhysicalNameOfEntity(model,"FreightOrderProcess")).thenReturn(physicalName);
        List<Tuple<Column, SortOrder>> orderByListWhole = new ArrayList<>();
        List<Tuple<Column, SortOrder>> orderByListMainEntity = new ArrayList<>();

        Map<String, MetadataEntityElement> allFieldsOfEntity = new HashMap<>();
        MetadataEntityElement totalWeight = Mockito.mock(MetadataEntityElement.class);
        Mockito.when(totalWeight.isKey()).thenReturn(false);
        Mockito.when(totalWeight.isFromCoreModel()).thenReturn(false);
        allFieldsOfEntity.put("totalWeight",totalWeight);
        Mockito.when(metadataService.findAllFieldsOfEntity(model,"FreightOrderProcess")).thenReturn(allFieldsOfEntity);

        PowerMockito.mockStatic(CsnParser.class);
        given(CsnParser.isCoreModelEntity(anyString())).willReturn(false);

        Expression.transformOrderExpression(entitySet,metadataService,model,orderExpression,orderByListWhole,orderByListMainEntity);
        assertEquals(orderByListWhole.size(),1);
        assertEquals(orderByListMainEntity.size(),1);
        System.out.println("ok");

    }
}
