package com.sap.gtt.v2.core.odata.domain;

import org.junit.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.*;

public class PagedEntitySetListTest {

    @Test
    public void testNewInstance() {
        PagedEntitySetList<String> stringList = PagedEntitySetList.newInstance(String.class);

        assertNotNull(stringList);
        assertNotNull(stringList.getData());
        assertNotNull(stringList.getTotalCount());
        assertTrue(stringList.getData() instanceof List);
    }

    @Test
    public void testConstructor() {
        PagedEntitySetList<String> stringList = new PagedEntitySetList<String>();

        assertNotNull(stringList);
        assertNotNull(stringList.getData());
        assertNotNull(stringList.getTotalCount());
        assertTrue(stringList.getData() instanceof List);
    }

    @Test
    public void testConstructorWithValue() {
        PagedEntitySetList<String> dummy = new PagedEntitySetList<String>(Arrays.asList("this", "is", "a", "list"));

        assertNotNull(dummy);
        assertNotNull(dummy.getData());
        assertEquals(4, dummy.getData().size());
    }

    @Test
    public void testConstructorWithNull() {
        PagedEntitySetList<String> dummy = new PagedEntitySetList<String>(null);

        assertNotNull(dummy);
        assertNull(dummy.getData());
    }

    @Test
    public void testSetData() {
        PagedEntitySetList<String> stringList = PagedEntitySetList.newInstance(String.class);
        stringList.setData(Arrays.asList("1", "2"));

        assertEquals(stringList.getData(), Arrays.asList("1", "2"));
    }

    @Test
    public void testGetData() {
        PagedEntitySetList<String> stringList = PagedEntitySetList.newInstance(String.class);

        assertTrue(stringList.getData().isEmpty());
    }

    @Test
    public void testSetTotalCount() {
        PagedEntitySetList<String> stringList = PagedEntitySetList.newInstance(String.class);
        stringList.setTotalCount(42);

        assertEquals(stringList.getTotalCount(), new Integer(42));
    }

    @Test
    public void testGetTotalCount() {
        PagedEntitySetList<String> stringList = PagedEntitySetList.newInstance(String.class);

        assertEquals(stringList.getTotalCount(), new Integer(0));
    }
}
