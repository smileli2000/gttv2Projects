package com.sap.gtt.v2.core.odata.callback;

import com.sap.gtt.v2.exception.InternalErrorException;
import org.apache.olingo.odata2.api.edm.*;
import org.apache.olingo.odata2.api.ep.callback.WriteEntryCallbackContext;
import org.apache.olingo.odata2.api.ep.callback.WriteEntryCallbackResult;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Answers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.net.URI;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class ExpandEntityCallbackTest {

    @InjectMocks
    private ExpandEntityCallback expCallback;

    @Mock(answer = Answers.RETURNS_DEEP_STUBS)
    private WriteEntryCallbackContext context;

    @Mock(answer = Answers.RETURNS_DEEP_STUBS)
    private EdmNavigationProperty property;

    @Mock
    private EdmReferentialConstraintRole dependent;

    @Mock
    private EdmReferentialConstraintRole principal;

    private Map<String, Object> entryData;

    private Map<String, Object> returnedData;

    @Mock(answer = Answers.RETURNS_DEEP_STUBS)
    private EdmEntitySet target;

    @Before
    public void setup() throws EdmException {
        List<String> dependentRefNames = Arrays.asList("Col1", "Col2");
        List<String> principalRefNames = Arrays.asList("ColA", "ColB");
        Map<String, Object> naviData = new HashMap<>();
        naviData.put("Col2", "Val2");
        List<Map<String, Object>> naviList = Arrays.asList(naviData);
        entryData = new HashMap<>();
        entryData.put("Col1", naviList);
        entryData.put("Col2", naviList);

        returnedData = new HashMap<>();

        EdmProperty edmProperty = mock(EdmProperty.class);
        when(edmProperty.getName()).thenReturn("ColA");
        List<EdmProperty> keyProperties = Arrays.asList(edmProperty);

        when(context.getNavigationProperty()).thenReturn(property);
        when(context.getEntryData()).thenReturn(entryData);
        when(context.getSourceEntitySet().getRelatedEntitySet(property)).thenReturn(target);
        when(target.getEntityType().getKeyProperties()).thenReturn(keyProperties);
        try {
            when(property.getName()).thenReturn("Col1");
            when(property.getRelationship().getReferentialConstraint()
                        .getDependent()).thenReturn(dependent);
            when(property.getRelationship().getReferentialConstraint()
                        .getPrincipal()).thenReturn(principal);
            when(dependent.getPropertyRefNames()).thenReturn(dependentRefNames);
            when(principal.getPropertyRefNames()).thenReturn(principalRefNames);
        } catch (EdmException e) {
            fail(e.getMessage());
        }
    }

    @Test
    public void testRetrieveFeedResult() {
        URI uri = URI.create("http://localhost:8080");
        expCallback.setServiceRoot(uri);

        WriteEntryCallbackResult result = expCallback.retrieveEntryResult(context);
        assertEquals(returnedData, result.getEntryData());
    }

    @Test(expected = InternalErrorException.class)
    public void testRetrieveEntryResultException() throws InternalErrorException {
        WriteEntryCallbackContext ctx = mock(WriteEntryCallbackContext.class, RETURNS_DEEP_STUBS);
        EdmException exception = mock(EdmException.class);

        try {
            when(ctx.getNavigationProperty().getRelationship()).thenThrow(exception);
        } catch (EdmException e) {
            fail(e.getMessage());
        }
        expCallback.retrieveEntryResult(ctx);
    }
}

