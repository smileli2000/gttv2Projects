package com.sap.gtt.v2.core.odata.utils;

import com.sap.gtt.v2.core.domain.metadata.MetadataEntity;
import com.sap.gtt.v2.core.domain.metadata.MetadataEntityElement;
import com.sap.gtt.v2.core.domain.metadata.MetadataForeignKey;
import com.sap.gtt.v2.core.domain.metadata.PhysicalName;
import com.sap.gtt.v2.core.odata.common.Tuple;
import com.sap.gtt.v2.core.odata.domain.Column;
import com.sap.gtt.v2.core.odata.domain.Expression;
import com.sap.gtt.v2.core.odata.domain.ExpressionDbEdmMapping;
import com.sap.gtt.v2.core.odata.domain.Table;
import org.apache.olingo.odata2.api.uri.expression.MethodOperator;
import org.apache.olingo.odata2.api.uri.expression.SortOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.*;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ExpressionUtilsTest {

    @Test
    public void testCombineColumnWithTableByDot() {
        Column one = new Column("Col1", new Table("Table1", "Entity1"));
        Column two = new Column("Col2", new Table("Table1", "Entity1"));
        Column three = new Column("Col1", new Table("Table2", "Entity2"));
        Column four = new Column("Col2", new Table("Table2", "Entity2"));
        List<Column> columns = Arrays.asList(one, two, three, four);
        List<String> res = ExpressionUtils.combineColumnWithTableByDot(columns);

        assertEquals("Entity1.Col1 AS \"Entity1.Col1\"", res.get(0));
        assertEquals("Entity1.Col2 AS \"Entity1.Col2\"", res.get(1));
        assertEquals("Entity2.Col1 AS \"Entity2.Col1\"", res.get(2));
        assertEquals("Entity2.Col2 AS \"Entity2.Col2\"", res.get(3));

    }

    @Test
    public void testCombineListWithComma() {
        String res = ExpressionUtils.combineListWithComma(Arrays.asList("Hello", "GTT"));

        assertEquals("Hello, GTT", res);
    }

    @Test
    public void testCombineAllTableName() {
        Table table1 = new Table("Table2", "Entity2");
        Table table2 = new Table("Table3", "Entity3");
        List<Table> joinTable = Arrays.asList(table1, table2);

        String res = ExpressionUtils.combineAllTableName(joinTable);

        assertEquals("LEFT JOIN Table2 Entity2, LEFT JOIN Table3 Entity3", res);
    }

    @Test
    public void testCombineJoinColumn() {
        Column col1 = new Column("Col1", new Table("Table1", "Entity1"));
        Column col2 = new Column("Col2", new Table("Table2", "Entity2"));
        Column col3 = new Column("Col3", new Table("Table3", "Entity3"));
        Column col4 = new Column("Col4", new Table("Table4", "Entity4"));
        Tuple<Column, Column> joinCol1 = new Tuple<>(col1, col2);
        Tuple<Column, Column> joinCol2 = new Tuple<>(col3, col4);
        List<Tuple<Column, Column>> joinColList = Arrays.asList(joinCol1, joinCol2);

        String res = ExpressionUtils.combineJoinColumn(joinColList);

        assertEquals("Entity1.Col1 = Entity2.Col2, Entity3.Col3 = Entity4.Col4", res);
    }

    @Test
    public void testCovertSqlPrepareStmt() {
        Expression expression = new Expression();
        assertNotNull(expression);

        Column col = new Column("Col1",
                new Table("Table1", "Entity1"));
        List<Column> primaryKeys = new ArrayList<>();
        primaryKeys.add(col);
        expression.setWhere("Col1 = \'Col1\'");
        expression.setFrom("LEFT JOIN Table2 Entity2");
        expression.setMethodOperator(MethodOperator.SUBSTRING);
        expression.setJoinColumn("Entity1.Col1 = Entity2.Col2");
        expression.setOrderByWhole(Collections.emptyList());
        expression.setSelect(Arrays.asList(col));
        expression.setSkip(0);
        expression.setTop(0);
        expression.setPrimaryKeys(primaryKeys);
        expression.setOrderByMainEntity(Arrays.asList(new Tuple<>(new Column("Col1",
                new Table("Table1", "Entity1")), SortOrder.asc)));
        expression.setOrderByWhole(Arrays.asList(new Tuple<>(new Column("Col1",
                new Table("Table1", "Entity1")), SortOrder.asc)));

        String res = ExpressionUtils.covertSqlPrepareStmt(expression);

        String expected = "SELECT DISTINCT * FROM ( SELECT Entity1.Col1 AS \"Entity1.Col1\" FROM( " +
                "SELECT DISTINCT Entity1.Col1 FROM Table1 Entity1 LEFT JOIN Table2 Entity2 ON (Entity1.Col1 = Entity2.Col2) WHERE Col1 = 'Col1' ORDER BY Entity1.Col1 asc LIMIT 0 OFFSET 0 )  " +
                "SubQuery INNER JOIN Table1 Entity1 ON ( SubQuery.Col1 = Entity1.Col1 )  LEFT JOIN Table2 Entity2 ON (Entity1.Col1 = Entity2.Col2) ORDER BY Entity1.Col1 asc )";
        assertEquals(expected, res);
    }

    @Test
    public void testConvertCountSqlPrepareStmt() {
        Expression expression = new Expression();
        assertNotNull(expression);

        Column col = new Column("Col1",
                new Table("Table1", "Entity1"));
        List<Column> primaryKeys = new ArrayList<>();
        primaryKeys.add(col);
        expression.setWhere("Col1 = \'Col1\'");
        expression.setFrom("LEFT JOIN Table2 Entity2");
        expression.setMethodOperator(MethodOperator.SUBSTRING);
        expression.setJoinColumn("Entity1.Col1 = Entity2.Col2");
        expression.setOrderByWhole(Collections.emptyList());
        expression.setSelect(Arrays.asList(col));
        expression.setSkip(0);
        expression.setTop(0);
        expression.setPrimaryKeys(primaryKeys);

        String res = ExpressionUtils.convertCountSqlPrepareStmt(expression);

        String expected = "SELECT COUNT(*) AS TotalCount FROM ( SELECT DISTINCT Entity1.Col1 FROM Table1 Entity1 LEFT JOIN Table2 Entity2 ON (Entity1.Col1 = Entity2.Col2) WHERE Col1 = 'Col1' LIMIT 0 OFFSET 0 ) ";
        assertEquals(expected, res);
    }

    @Test
    public void testFindBackLinkForeignKey() {
        String targetEntityName = "Entity";
        MetadataForeignKey foreignKey = new MetadataForeignKey();

        MetadataEntity metadataEntity = mock(MetadataEntity.class);
        MetadataEntityElement element = mock(MetadataEntityElement.class);
        when(metadataEntity.getName()).thenReturn(targetEntityName);
        when(metadataEntity.getElements()).thenReturn(Arrays.asList(element));
        when(element.isBackLink()).thenReturn(Boolean.TRUE);
        when(element.getForeignKey()).thenReturn(foreignKey);

        MetadataForeignKey res = ExpressionUtils.findBackLinkForeignKey(Arrays.asList(metadataEntity), targetEntityName);

        assertEquals(foreignKey, res);
    }

    @Test
    public void testFindEntityEdmMapping() {
        String mainEntity = "MainEntity";
        PhysicalName table = new PhysicalName();
        table.setName("Table");
        table.setCorePhysicalName("CoreTable");

        MetadataEntityElement nonCoreTableColumn = new MetadataEntityElement();
        nonCoreTableColumn.setFromCoreModel(Boolean.FALSE);
        nonCoreTableColumn.setKey(Boolean.TRUE);

        MetadataEntityElement coreTableColumn = new MetadataEntityElement();
        coreTableColumn.setFromCoreModel(Boolean.TRUE);
        coreTableColumn.setKey(Boolean.FALSE);

        List<MetadataEntityElement> allColumn = Arrays.asList(nonCoreTableColumn, coreTableColumn);

        ExpressionDbEdmMapping res = ExpressionUtils.findEntityEdmMapping(mainEntity, table, allColumn);

        assertNotNull(res.getColumnName());
        assertEquals(2, res.getColumnName().size());
        assertNotNull(res.getJoinTableName());
        assertEquals(1, res.getJoinTableName().size());
    }
}
