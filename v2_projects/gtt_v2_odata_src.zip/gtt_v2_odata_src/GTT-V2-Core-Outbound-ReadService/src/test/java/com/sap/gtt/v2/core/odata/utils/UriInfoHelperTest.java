package com.sap.gtt.v2.core.odata.utils;

import com.sap.gtt.v2.core.odata.utils.UriInfoHelper;
import org.apache.olingo.odata2.api.edm.*;
import org.apache.olingo.odata2.api.uri.KeyPredicate;
import org.apache.olingo.odata2.api.uri.NavigationPropertySegment;
import org.apache.olingo.odata2.api.uri.NavigationSegment;
import org.junit.Test;
import org.mockito.Mockito;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;

public class UriInfoHelperTest {

    @Test
    public void testInitialize() throws EdmException {

        UriInfoHelper uriInfoHelper = new UriInfoHelper();

        //Mock expand
        NavigationPropertySegment navPropertySeg = Mockito.mock(NavigationPropertySegment.class);
        EdmNavigationProperty navProperty = Mockito.mock(EdmNavigationProperty.class);
        Mockito.when( navProperty.getName() ).thenReturn("process");
        Mockito.when(navPropertySeg.getNavigationProperty()).thenReturn(navProperty);
        EdmEntitySet tpEntitySet = Mockito.mock(EdmEntitySet.class);
        Mockito.when(tpEntitySet.getName()).thenReturn("TrackedProcess");
        Mockito.when(navPropertySeg.getTargetEntitySet()).thenReturn(tpEntitySet);
        List<ArrayList<NavigationPropertySegment>> expandInUriInfo = new ArrayList<>();
        expandInUriInfo.add(new ArrayList<>());
        expandInUriInfo.get(0).add(navPropertySeg);

        //Mock startEntitySet
        EdmEntitySet startEntitySet = Mockito.mock(EdmEntitySet.class);
        EdmEntityType freightOrderEntityType = Mockito.mock(EdmEntityType.class);
        Mockito.when(freightOrderEntityType.getName()).thenReturn("FreightOrderProcess");
        Mockito.when(startEntitySet.getEntityType()).thenReturn(freightOrderEntityType);

        //Mock keyPredicates
        KeyPredicate keyElem = Mockito.mock(KeyPredicate.class);
        Mockito.when(keyElem.getLiteral()).thenReturn("cbb83013-bf3f-5e1f-a6c9-c5fca8b19f15");
        EdmProperty edmProperty = Mockito.mock(EdmProperty.class);
        Mockito.when(edmProperty.getName()).thenReturn("Id");
        Mockito.when(keyElem.getProperty()).thenReturn(edmProperty);
        List<KeyPredicate> keyPredicates = new ArrayList<>();
        keyPredicates.add(keyElem);

        //Mock NavigationSegments
        NavigationSegment navSeg = Mockito.mock(NavigationSegment.class);
        EdmEntitySet plannedEventEntitySet = Mockito.mock(EdmEntitySet.class);
        EdmEntityType plannedEventEntityType = Mockito.mock(EdmEntityType.class);
        Mockito.when(plannedEventEntityType.getName()).thenReturn("PlannedEvent");
        Mockito.when(plannedEventEntitySet.getEntityType()).thenReturn(plannedEventEntityType);
        Mockito.when(navSeg.getEntitySet()).thenReturn(plannedEventEntitySet);
        List<KeyPredicate> keyPredicatesMock = new ArrayList<>();
        Mockito.when(navSeg.getKeyPredicates()).thenReturn(keyPredicatesMock);
        List<NavigationSegment> navigationSegments = new ArrayList();
        navigationSegments.add(navSeg);

        //call method
        uriInfoHelper.initialize(startEntitySet,keyPredicates,expandInUriInfo,navigationSegments);

        final List<EdmEntitySet> actNavigationPath = uriInfoHelper.getNavigationPath();
        Map<String, List<KeyPredicate>> actKeyMap = uriInfoHelper.getKeyMap();

        assertEquals(actNavigationPath.size(),2);
        assertEquals(actNavigationPath.get(0).getEntityType().getName(),"FreightOrderProcess");
        assertEquals(actNavigationPath.get(1).getEntityType().getName(),"PlannedEvent");

        assertEquals(actKeyMap.size(),2);
        assertEquals(actKeyMap.get("FreightOrderProcess").get(0).getLiteral(),"cbb83013-bf3f-5e1f-a6c9-c5fca8b19f15");
        assertEquals(actKeyMap.get("FreightOrderProcess").get(0).getProperty().getName(),"Id");
        assertEquals(actKeyMap.get("PlannedEvent").size(),0);
    }

}