package com.sap.gtt.v2.core.odata.exception;

import org.apache.http.HttpStatus;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class ODataServiceNotFoundExceptionTest {
    @Test
    public void testODataServiceNotFoundExceptionWithMsgCode() {
        new ODataServiceNotFoundException("OData service not found exception");
    }

    @Test
    public void testODataServiceNotFoundExceptionWithMsgCodeAndLocalizedMsgParams() {
        new ODataServiceNotFoundException("OData service not found exception", new Object[]{});
    }

    @Test
    public void testODataServiceNotFoundExceptionWithAll() {
        Throwable cause = new Throwable();
        new ODataServiceNotFoundException("Internal Message", cause, "OData service not found exception", new Object[]{});
    }

    @Test(expected = ODataServiceNotFoundException.class)
    public void testThrowODataServiceNotFoundException() throws ODataServiceException {
        throw new ODataServiceNotFoundException("OData service not found exception");
    }

    @Test
    public void testGetHttpStatus() {
        ODataServiceNotFoundException exception = new ODataServiceNotFoundException("OData service out found exception");
        assertEquals(HttpStatus.SC_NOT_FOUND, exception.getHttpStatus());
    }
}
