package com.sap.gtt.v2.core.odata.repository;


import com.sap.gtt.v2.core.domain.metadata.MetadataConstants;
import com.sap.gtt.v2.core.domain.metadata.MetadataEntityElement;
import com.sap.gtt.v2.core.domain.metadata.PhysicalName;
import com.sap.gtt.v2.core.management.metadata.IMetadataManagement;
import com.sap.gtt.v2.core.odata.common.Tuple;
import com.sap.gtt.v2.core.odata.domain.*;
import com.sap.gtt.v2.log.TenantAwareLogService;
import org.apache.olingo.odata2.api.edm.EdmEntitySet;
import org.apache.olingo.odata2.api.edm.EdmException;
import org.apache.olingo.odata2.api.uri.KeyPredicate;
import org.apache.olingo.odata2.api.uri.expression.OrderByExpression;
import org.apache.olingo.odata2.core.edm.EdmGuid;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.powermock.reflect.Whitebox;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.*;

import static com.sap.gtt.v2.core.odata.common.Constants.QUERY_TOTAL_COUNT;
import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class DefaultSearchClientTest {
    private final static String MODEL = "com.sap.gtt.app.mim";

    private DefaultSearchClientDummy defaultSearchClient;

    private Expression expression;
    private JdbcTemplate jdbcTemplate;
    private ExpressionDbEdmMapping expressionDbEdmMapping;
    private EdmEntitySet entitySet;
    private IMetadataManagement metadataService;

    @Before
    public void setup() {
        defaultSearchClient = new DefaultSearchClientDummy(MODEL);
        defaultSearchClient.logService = mock(TenantAwareLogService.class);
        expression = mock(Expression.class);
        jdbcTemplate = mock(JdbcTemplate.class);
        expressionDbEdmMapping = mock(ExpressionDbEdmMapping.class);
        entitySet = mock(EdmEntitySet.class, RETURNS_DEEP_STUBS);
        metadataService = mock(IMetadataManagement.class);

        Whitebox.setInternalState(defaultSearchClient, "jdbcTemplate", jdbcTemplate);
        Whitebox.setInternalState(defaultSearchClient, "expressionDbEdmMapping", expressionDbEdmMapping);
        Whitebox.setInternalState(defaultSearchClient, "entitySet", entitySet);
        Whitebox.setInternalState(defaultSearchClient, "metadataService", metadataService);

        Table tableInfo = new Table("com_sap_gtt_core_CoreModel_ProcessEventDirectory", "ProcessEventDirectory");
        when(expressionDbEdmMapping.getTableName()).thenReturn(tableInfo);
        Map<String, MetadataEntityElement> createEntityElementMap = createEntityElementMap();
        when(metadataService.findAllFieldsOfEntity(eq(MODEL), eq("ProcessEventDirectory"))).thenReturn(createEntityElementMap);
        when(metadataService.findAllFieldsOfEntity(eq(MODEL), eq("Event"))).thenReturn(createEntityElementMap);
        try {
            when(entitySet.getEntityType().getPropertyNames()).thenReturn(Arrays.asList("id"));
            when(entitySet.getEntityType().getProperty(eq("id")).getType()).thenReturn(EdmGuid.getInstance());
        } catch (EdmException e) {
            fail(e.getMessage());
        }

    }

    @Test
    public void testGetSearchResult() {
        Whitebox.setInternalState(defaultSearchClient, "expression", expression);
        final String querySql = "SELECT DISTINCT * FROM ( " +
                "SELECT ProcessEventDirectory.id AS \"ProcessEventDirectory.id\", " +
                "ProcessEventDirectory.process_id AS \"ProcessEventDirectory.process_id\", " +
                "ProcessEventDirectory.event_id AS \"ProcessEventDirectory.event_id\", " +
                "ProcessEventDirectory.plannedEvent_id AS \"ProcessEventDirectory.plannedEvent_id\", " +
                "ProcessEventDirectory.correlationType AS \"ProcessEventDirectory.correlationType\" " +
                "Event.id AS \"Event.id\" " +
                "FROM( SELECT DISTINCT ProcessEventDirectory.id FROM com_sap_gtt_core_CoreModel_ProcessEventDirectory ProcessEventDirectory " +
                "LIMIT 128 OFFSET 0 )  SubQuery " +
                "INNER JOIN com_sap_gtt_core_CoreModel_ProcessEventDirectory ProcessEventDirectory ON ( SubQuery.id = ProcessEventDirectory.id ) " +
                "LEFT JOIN com_sap_gtt_core_CoreModel_event Event ON ( ProcessEventDirectory.event_id = Event.id ) )";

        List<Map<String, Object>> sqlExecutionList = createSqlExecutionList();
        when(expression.toSqlPrepareStmt()).thenReturn(querySql);
        when(jdbcTemplate.queryForList(eq(querySql), Mockito.any(Object[].class))).thenReturn(sqlExecutionList);

        Tuple<String, String> expandItem = new Tuple<>("event", "Event");
        List<List<Tuple<String, String>>> expand = Arrays.asList(Arrays.asList(expandItem));
        defaultSearchClient.setExpand(expand);

        PagedEntitySetList<Map<String, Object>> pageEntitySetList = defaultSearchClient.getSearchResult();
        List<Map<String, Object>> res = pageEntitySetList.getData();
        assertNotNull(res);
        assertEquals(1, res.size());
        Map<String, Object> ped = res.get(0);
        assertNotNull(ped.get("id"));
        assertEquals(UUID.fromString("6b26865c-a160-11e9-9cae-ab70638be8ea"), ped.get("id"));
        assertNotNull(ped.get("event"));
        List<Map<String, Object>> eventList = (List<Map<String, Object>>) ped.get("event");
        assertEquals(1, eventList.size());
        Map<String, Object> event = eventList.get(0);
        assertEquals(UUID.fromString("6aa28a33-a160-11e9-9cae-17713d798650"), event.get("id"));
    }

    @Test
    public void testGetResultCount() {
        Whitebox.setInternalState(defaultSearchClient, "expression", expression);
        final String sqlPrepareStmt = "SELECT COUNT(*) AS TotalCount " +
                "FROM ( SELECT DISTINCT ProcessEventDirectory.id " +
                "FROM com_sap_gtt_core_CoreModel_ProcessEventDirectory ProcessEventDirectory " +
                "LIMIT null OFFSET 0 ) ";
        Map<String, Object> countNum = new LinkedHashMap<>();
        countNum.put(QUERY_TOTAL_COUNT, new Long(1));

        when(expression.toCountSqlPrepareStmt()).thenReturn(sqlPrepareStmt);
        when(jdbcTemplate.queryForList(eq(sqlPrepareStmt), Mockito.any(Object[].class))).thenReturn(Arrays.asList(countNum));

        Integer res = defaultSearchClient.getResultCount();
        assertEquals(1, res.intValue());
    }

    @Test
    public void testExecute() throws EdmException {
        String tableName = "com_sap_gtt_core_CoreModel_ProcessEventDirectory";
        String entityName = "ProcessEventDirectory";
        String entityType = "com.sap.gtt.app.tfo.TFOService.ProcessEventDirectory";

        PhysicalName table = new PhysicalName();
        table.setName(tableName);
        table.setCorePhysicalName(tableName);

        when(entitySet.getName()).thenReturn(entityName);
        when(entitySet.getEntityType().toString()).thenReturn(entityType);
        when(metadataService.getPhysicalNameOfEntity(eq(MODEL), eq(entityType))).thenReturn(table);
        when(entitySet.getEntityType().getKeyPropertyNames()).thenReturn(Arrays.asList("id"));
        OrderByExpression orderBy = mock(OrderByExpression.class);
        when(orderBy.getOrders()).thenReturn(Collections.emptyList());
        defaultSearchClient.setOrderBy(orderBy);

        Map<String, List<KeyPredicate>> keys = new HashMap<>();
        KeyPredicate predicate = mock(KeyPredicate.class, RETURNS_DEEP_STUBS);
        keys.put("ProcessEventDirectory", Arrays.asList(predicate));
        when(predicate.getProperty().getName()).thenReturn("id");
        when(predicate.getLiteral()).thenReturn("6b26865c-a160-11e9-9cae-ab70638be8ea");
        defaultSearchClient.setKeys(keys);

        defaultSearchClient.setSkip(1);
        defaultSearchClient.execute();
    }

    private List<Map<String, Object>> createSqlExecutionList() {
        List<Map<String, Object>> sqlExecutionList = new ArrayList();
        Map<String, Object> resultMap = new LinkedHashMap<>();
        resultMap.put("ProcessEventDirectory.id", "6b26865c-a160-11e9-9cae-ab70638be8ea");
        resultMap.put("ProcessEventDirectory.process_id", "4307660d-6ac5-55e5-9d7e-a155c7c62d21");
        resultMap.put("ProcessEventDirectory.event_id", "6aa28a33-a160-11e9-9cae-17713d798650");
        resultMap.put("ProcessEventDirectory.plannedEvent_id", "9b9f869e-531f-e111-bdf8-bc305bd0c8e7");
        resultMap.put("ProcessEventDirectory.correlationType", "UNPLANNED_PROCESS_CREATION_UPDATE");
        resultMap.put("Event.id", "6aa28a33-a160-11e9-9cae-17713d798650");
        sqlExecutionList.add(resultMap);
        return sqlExecutionList;
    }

    private Map<String, MetadataEntityElement> createEntityElementMap() {
        Map<String, MetadataEntityElement> metadataEntityElementMap = new HashMap<>();

        MetadataEntityElement element = new MetadataEntityElement();
        element.setName("id");
        element.setType(MetadataConstants.CdsDataType.CDS_UUID);
        element.setKey(true);
        element.setLength(0);
        element.setFromCoreModel(false);
        metadataEntityElementMap.put("id", element);

        return metadataEntityElementMap;
    }
}

class DefaultSearchClientDummy extends DefaultSearchClient {
    public DefaultSearchClientDummy(String model) {
        super(model);
    }
}
