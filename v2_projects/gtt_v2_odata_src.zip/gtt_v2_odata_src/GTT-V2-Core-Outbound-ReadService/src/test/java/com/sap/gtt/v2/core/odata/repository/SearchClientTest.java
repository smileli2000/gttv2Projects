package com.sap.gtt.v2.core.odata.repository;

import com.sap.gtt.v2.core.odata.domain.PagedEntitySetList;
import org.apache.olingo.odata2.api.commons.InlineCount;
import org.junit.Test;

import java.util.Collections;
import java.util.Locale;
import java.util.Map;

import static org.junit.Assert.assertNotNull;


public class SearchClientTest {

    private SearchClientTestDummy dummy = new SearchClientTestDummy("com.sap.iot.tnt.DeliveryService");

    @Test
    public void testSetEntitySet() {
        SearchClient client = dummy.setEntitySet(null);

        assertNotNull(client);
    }

    @Test
    public void testSetFilterWithNull() {
        SearchClient client = dummy.setFilter(null);

        assertNotNull(client);
    }

    @Test
    public void testSetTopWithNull() {
        SearchClient client = dummy.setTop(null);

        assertNotNull(client);
    }

    @Test
    public void testSetTop() {
        SearchClient client = dummy.setTop(10);

        assertNotNull(client);
    }

    @Test
    public void testSetSkipWithNull() {
        SearchClient client = dummy.setSkip(null);

        assertNotNull(client);
    }

    @Test
    public void testSetSkip() {
        SearchClient client = dummy.setSkip(10);

        assertNotNull(client);
    }

    @Test
    public void testSetInlineCountWithNull() {
        SearchClient client = dummy.setInlineCount(null);

        assertNotNull(client);
    }

    @Test
    public void testSetInlineCount() {
        SearchClient client = dummy.setInlineCount(InlineCount.ALLPAGES);

        assertNotNull(client);
    }

    @Test
    public void testSetOrderByWithNull() {
        SearchClient client = dummy.setOrderBy(null);

        assertNotNull(client);
    }

    @Test
    public void testSetKeys() {
        SearchClient client = dummy.setKeys(Collections.emptyMap());

        assertNotNull(client);
    }

    @Test
    public void testApplyAuthorizationFilter() {
        SearchClient client = dummy.applyAuthorizationFilter();

        assertNotNull(client);
    }

    @Test
    public void testSetLocale() {
        SearchClient client = dummy.setLocale(Locale.US);

        assertNotNull(client);
    }

    @Test
    public void testSetCustomQueryOption() {
        SearchClient client = dummy.setCustomQueryOption(Collections.emptyMap());

        assertNotNull(client);
    }

    @Test
    public void testExecute() {
        SearchClient client = dummy.execute();

        assertNotNull(client);
    }

    @Test
    public void testGetSearchResult() {
        PagedEntitySetList<Map<String, Object>> result = dummy.getSearchResult();

        assertNotNull(result);
    }

    class SearchClientTestDummy extends SearchClient {

        protected SearchClientTestDummy(String model) {
            super(model);
        }

        @Override
        public SearchClient execute() {
            return this;
        }

        @Override
        public PagedEntitySetList<Map<String, Object>> getSearchResult() {
            return new PagedEntitySetList<>();
        }

        @Override
        public Integer getResultCount() {
            return null;
        }

    }

}

