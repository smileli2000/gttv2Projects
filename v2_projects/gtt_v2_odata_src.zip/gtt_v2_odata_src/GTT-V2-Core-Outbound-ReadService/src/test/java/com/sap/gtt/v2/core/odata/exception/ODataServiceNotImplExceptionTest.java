package com.sap.gtt.v2.core.odata.exception;

import org.apache.http.HttpStatus;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class ODataServiceNotImplExceptionTest {
    @Test
    public void testODataServiceNotImplExceptionWithMsgCode() {
        new ODataServiceNotImplException("OData service not impl exception");
    }

    @Test
    public void testODataServiceNotImplExceptionWithMsgCodeAndLocalizedMsgParams() {
        new ODataServiceNotImplException("OData service not impl exception", new Object[]{});
    }

    @Test
    public void testODataServiceNotImplExceptionWithAll() {
        Throwable cause = new Throwable();
        new ODataServiceNotImplException("Internal Message", cause, "OData service not impl exception", new Object[]{});
    }

    @Test(expected = ODataServiceNotImplException.class)
    public void testThrowODataServiceNotImplException() throws ODataServiceNotImplException {
        throw new ODataServiceNotImplException("OData service not impl exception");
    }

    @Test
    public void testGetHttpStatus() {
        ODataServiceNotImplException exception = new ODataServiceNotImplException("OData service exception");
        assertEquals(HttpStatus.SC_NOT_IMPLEMENTED, exception.getHttpStatus());
    }
}
