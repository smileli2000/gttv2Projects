package com.sap.gtt.v2.core.odata.utils;

import com.sap.gtt.v2.core.domain.metadata.MetadataEntityElement;
import com.sap.gtt.v2.core.management.metadata.IMetadataManagement;
import com.sap.gtt.v2.core.odata.common.Tuple;
import org.junit.Test;

import java.util.*;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class DataPostprocessingHelperTest {

    @Test
    public void testConvertJdbcResToNestedList() {
        List<Map<String, Object>> sqlExecList = createSqlExecList();
        String mainEntityName = "FreightOrderProcess";
        List<List<Tuple<String, String>>> expand = createExpand();
        String model = "com.sap.gtt.app.tfo";
        IMetadataManagement metadataService = mock(IMetadataManagement.class);
        DataPostprocessingHelper helper = new DataPostprocessingHelper(metadataService, model);

        MetadataEntityElement ele1 = new MetadataEntityElement();
        ele1.setKey(Boolean.TRUE);
        ele1.setName("id");
        Map<String, MetadataEntityElement> allElements1 = new HashMap<>();
        allElements1.put("id", ele1);

        when(metadataService.findAllFieldsOfEntity(eq(model), eq("FreightOrderProcess"))).thenReturn(allElements1);
        when(metadataService.findAllFieldsOfEntity(eq(model), eq("ProcessEventDirectory"))).thenReturn(allElements1);
        when(metadataService.findAllFieldsOfEntity(eq(model), eq("Event"))).thenReturn(allElements1);

        MetadataEntityElement ele2 = new MetadataEntityElement();
        ele2.setKey(Boolean.TRUE);
        ele2.setName("freightOrderProcess_id");
        MetadataEntityElement ele3 = new MetadataEntityElement();
        ele3.setKey(Boolean.TRUE);
        ele3.setName("sequentialNumber");
        Map<String, MetadataEntityElement> allElements2 = new HashMap<>();
        allElements2.put("freightOrderProcess_id", ele2);
        allElements2.put("sequentialNumber", ele3);

        when(metadataService.findAllFieldsOfEntity(eq(model), eq("StopsForProcess"))).thenReturn(allElements2);


        List<Map<String, Object>> res = helper.convertJdbcResToNestedList(mainEntityName, expand).apply(sqlExecList);

        assertNotNull(res);
        assertEquals(1, res.size());
        Map<String, Object> freightOrder = res.get(0);
        assertNotNull(freightOrder);
        assertEquals("4307660d-6ac5-55e5-9d7e-a155c7c62d21", freightOrder.get("id"));

        List<Map<String, Object>> processEvents = (List<Map<String, Object>>) freightOrder.get("processEvents");
        assertEquals(1, processEvents.size());
        Map<String, Object> processEvent = processEvents.get(0);
        assertNotNull(processEvent);
        assertEquals("6b26865c-a160-11e9-9cae-ab70638be8ea", processEvent.get("id"));
        List<Map<String, Object>> events = (List<Map<String, Object>>) processEvent.get("event");
        assertEquals(1, events.size());
        Map<String, Object> event = events.get(0);
        assertEquals("6aa28a33-a160-11e9-9cae-17713d798650", event.get("id"));

        List<Map<String, Object>> stops = (List<Map<String, Object>>) freightOrder.get("stops");
        assertEquals(2, stops.size());
        assertEquals(1, stops.get(0).get("sequentialNumber"));
        assertEquals(2, stops.get(1).get("sequentialNumber"));

    }

    private List<Map<String, Object>> createSqlExecList() {
        List<Map<String, Object>> sqlExecList = new ArrayList<>();

        Map<String, Object> freightOrderSqlData1 = new LinkedHashMap<>();
        freightOrderSqlData1.put("FreightOrderProcess.id", "4307660d-6ac5-55e5-9d7e-a155c7c62d21");
        freightOrderSqlData1.put("ProcessEventDirectory.id", "6b26865c-a160-11e9-9cae-ab70638be8ea");
        freightOrderSqlData1.put("ProcessEventDirectory.process_id", "4307660d-6ac5-55e5-9d7e-a155c7c62d21");
        freightOrderSqlData1.put("ProcessEventDirectory.event_id", "6aa28a33-a160-11e9-9cae-17713d798650");
        freightOrderSqlData1.put("Event.id", "6aa28a33-a160-11e9-9cae-17713d798650");
        freightOrderSqlData1.put("StopsForProcess.freightOrderProcess_id", "4307660d-6ac5-55e5-9d7e-a155c7c62d21");
        freightOrderSqlData1.put("StopsForProcess.sequentialNumber", 1);
        Map<String, Object> freightOrderSqlData2 = new LinkedHashMap<>();
        freightOrderSqlData2.put("FreightOrderProcess.id", "4307660d-6ac5-55e5-9d7e-a155c7c62d21");
        freightOrderSqlData2.put("ProcessEventDirectory.id", "6b26865c-a160-11e9-9cae-ab70638be8ea");
        freightOrderSqlData2.put("ProcessEventDirectory.process_id", "4307660d-6ac5-55e5-9d7e-a155c7c62d21");
        freightOrderSqlData2.put("ProcessEventDirectory.event_id", "6aa28a33-a160-11e9-9cae-17713d798650");
        freightOrderSqlData2.put("Event.id", "6aa28a33-a160-11e9-9cae-17713d798650");
        freightOrderSqlData2.put("StopsForProcess.freightOrderProcess_id", "4307660d-6ac5-55e5-9d7e-a155c7c62d21");
        freightOrderSqlData2.put("StopsForProcess.sequentialNumber", 2);
        Map<String, Object> freightOrderSqlData3 = new LinkedHashMap<>();
        freightOrderSqlData3.put("FreightOrderProcess.id", "4307660d-6ac5-55e5-9d7e-a155c7c62d21");
        freightOrderSqlData3.put("ProcessEventDirectory.id", null);
        freightOrderSqlData3.put("ProcessEventDirectory.process_id", "4307660d-6ac5-55e5-9d7e-a155c7c62d21");
        freightOrderSqlData3.put("ProcessEventDirectory.event_id", "6aa28a33-a160-11e9-9cae-17713d798650");
        freightOrderSqlData3.put("Event.id", null);
        freightOrderSqlData3.put("StopsForProcess.freightOrderProcess_id", null);
        freightOrderSqlData3.put("StopsForProcess.sequentialNumber", null);

        sqlExecList.add(freightOrderSqlData1);
        sqlExecList.add(freightOrderSqlData2);
        sqlExecList.add(freightOrderSqlData3);

        return sqlExecList;
    }

    private List<List<Tuple<String, String>>> createExpand() {
        List<List<Tuple<String, String>>> expandList = new ArrayList<>();

        List<Tuple<String, String>> expand1 = Arrays.asList(
                new Tuple<>("processEvents", "ProcessEventDirectory"),
                new Tuple<>("event", "Event"));
        List<Tuple<String, String>> expand2 = Arrays.asList(
                new Tuple<>("stops", "StopsForProcess"));

        expandList.add(expand1);
        expandList.add(expand2);

        return expandList;
    }
}
