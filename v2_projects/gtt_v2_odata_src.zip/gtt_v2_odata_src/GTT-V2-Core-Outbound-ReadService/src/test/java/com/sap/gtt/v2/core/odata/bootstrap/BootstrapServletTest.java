package com.sap.gtt.v2.core.odata.bootstrap;

import com.sap.gtt.v2.core.odata.exception.ODataServiceException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import java.io.IOException;

import static org.junit.Assert.fail;
import static org.mockito.Mockito.mock;

@RunWith(MockitoJUnitRunner.class)
public class BootstrapServletTest {

    @Mock
    private BootstrapServiceFactory factory;

    @InjectMocks
    private BootstrapServlet bootstrapServlet;

    @Test
    public void testService() {
        MockHttpServletRequest req = new MockHttpServletRequest();
        MockHttpServletResponse res = new MockHttpServletResponse();
        req.setPathInfo("answer/42");
        ServletConfig config = mock(ServletConfig.class);
        try {
            bootstrapServlet.init(config);
            bootstrapServlet.service(req, res);
        } catch (ServletException | IOException e) {
            fail(e.getMessage());
        }
    }

    @Test(expected = ODataServiceException.class)
    public void testServiceWithoutModel() throws IOException {
        MockHttpServletRequest req = new MockHttpServletRequest();
        MockHttpServletResponse res = new MockHttpServletResponse();
        req.setPathInfo("");

        bootstrapServlet.service(req, res);

    }

}
