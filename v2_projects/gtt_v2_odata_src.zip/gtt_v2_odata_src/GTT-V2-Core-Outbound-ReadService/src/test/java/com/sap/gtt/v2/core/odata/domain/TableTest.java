package com.sap.gtt.v2.core.odata.domain;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class TableTest {
    @Test
    public void testConstructor() {
        Table table = new Table("table", "entity");
        assertNotNull(table);
        assertEquals("table", table.getTableName());
        assertEquals("entity", table.getEntityName());
    }

    @Test
    public void testSettersAndGetters() {
        Table table = new Table("table", "entity");
        assertNotNull(table);

        table.setEntityName("entity2");
        table.setTableName("table2");

        assertEquals("table2", table.getTableName());
        assertEquals("entity2", table.getEntityName());
    }

    @Test
    public void testToString() {
        Table table = new Table("table", "entity");
        assertNotNull(table);

        assertEquals(table.toString(), "Table{tableName='table', entityName='entity'}");


    }
}
