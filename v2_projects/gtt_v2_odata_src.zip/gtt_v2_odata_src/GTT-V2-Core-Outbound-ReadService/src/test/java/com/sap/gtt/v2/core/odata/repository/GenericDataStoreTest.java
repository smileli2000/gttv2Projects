package com.sap.gtt.v2.core.odata.repository;

import com.sap.gtt.v2.configuration.EnvironmentsConfiguration;
import com.sap.gtt.v2.configuration.ISAPCloudPlatformAgent;
import com.sap.gtt.v2.core.management.metadata.IMetadataManagement;
import com.sap.gtt.v2.core.odata.common.Tuple;
import com.sap.gtt.v2.core.odata.domain.PagedEntitySetList;
import com.sap.gtt.v2.util.SpringContextUtils;
import org.apache.olingo.odata2.api.commons.InlineCount;
import org.apache.olingo.odata2.api.edm.EdmEntitySet;
import org.apache.olingo.odata2.api.uri.KeyPredicate;
import org.apache.olingo.odata2.api.uri.expression.FilterExpression;
import org.apache.olingo.odata2.api.uri.expression.OrderByExpression;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Answers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import java.util.*;

import static com.sap.gtt.v2.core.odata.repository.DefaultSearchClient.BEAN_NAME;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(PowerMockRunner.class)
@PrepareForTest({SpringContextUtils.class})
public class GenericDataStoreTest {

    @Mock(answer = Answers.RETURNS_DEEP_STUBS)
    private ISAPCloudPlatformAgent.ICurrentAccessContext currentContext;

    private DefaultSearchClient client;

    @InjectMocks
    private GenericDataStoreDummy dataStore;

    @Before
    public void setup() {
        PagedEntitySetList<Map<String, Object>> list = new PagedEntitySetList<>();
        Map<String, Object> obj = new HashMap<>();
        obj.put("ID", "000001");
        obj.put("DeliveryID", "DLN000001");
        obj.put("plannedTechnicalTimeZone", "CET");
        obj.put("plannedTechnicalTimestampUTC", 1490545624117L);
        obj.put("actualBusinessTimeZone", "UTC+8");
        obj.put("actualBusinessTimestampUTC", 1490545624117L);
        obj.put("delivery", "0080000254");
        obj.put("id", "66c4bb60-689e-11e7-a198-f984fdc6dad6");
        list.setData(Arrays.asList(obj));
        list.setTotalCount(1);

        EnvironmentsConfiguration.VcapServiceParser.DatabaseServiceInstance databaseServiceInstance = mock(EnvironmentsConfiguration.VcapServiceParser.DatabaseServiceInstance.class);

        when(currentContext.getDatabaseServiceInstance()).thenReturn(databaseServiceInstance);
        when(databaseServiceInstance.getDatabaseType()).thenReturn(EnvironmentsConfiguration.VcapServiceParser.DatabaseServiceInstance.DatabaseType.hana);

        PowerMockito.mockStatic(SpringContextUtils.class);
        client = mock(DefaultSearchClient.class);
        given(SpringContextUtils.getBean(eq(BEAN_NAME), anyString())).willReturn(client);

        when(client.setMetadataService(any(IMetadataManagement.class))).thenReturn(client);
        when(client.setEntitySet(any(EdmEntitySet.class))).thenReturn(client);
        when(client.setNavigationPath(anyList())).thenReturn(client);
        when(client.setExpand(anyList())).thenReturn(client);
        when(client.setKeys(any())).thenReturn(client);
        when(client.setFilter(any())).thenReturn(client);
        when(client.setInlineCount(any())).thenReturn(client);
        when(client.setTop(any())).thenReturn(client);
        when(client.setSkip(any())).thenReturn(client);
        when(client.setOrderBy(any())).thenReturn(client);
        when(client.setCustomQueryOption(any())).thenReturn(client);
        when(client.execute()).thenReturn(client);
        when(client.applyAuthorizationFilter()).thenReturn(client);
        when(client.setLocale(any())).thenReturn(client);
        when(client.setScroll(Mockito.anyBoolean())).thenReturn(client);
        when(client.getSearchResult()).thenReturn(list);
        when(client.getResultCount()).thenReturn(1);
    }

    @Test
    public void testQueryEntitySet() {

        EdmEntitySet entitySet = mock(EdmEntitySet.class);
        Map<String, List<KeyPredicate>> keys = new HashMap<>();
        List<EdmEntitySet> navigationPath = new ArrayList<>();
        FilterExpression filterExpression = mock(FilterExpression.class);
        OrderByExpression orderBy = mock(OrderByExpression.class);
        List<List<Tuple<String, String>>> expand = new ArrayList<>();

        PagedEntitySetList<Map<String, Object>> list = dataStore.queryEntitySet(entitySet, keys, navigationPath, filterExpression, 0, 0, orderBy, InlineCount.ALLPAGES, Collections.emptyMap(), expand, Locale.US);

        assertNotNull(list);
        assertNotNull(list.getData());
        assertEquals(1, list.getData().size());
        assertEquals("000001", list.getData().get(0).get("ID"));
        assertEquals("DLN000001", list.getData().get(0).get("DeliveryID"));
        assertEquals(new Integer(1), list.getTotalCount());
    }

    @Test
    public void testQueryEntity() {

        EdmEntitySet entitySet = mock(EdmEntitySet.class);
        Map<String, List<KeyPredicate>> keys = new HashMap<>();
        List<EdmEntitySet> navigationPath = new ArrayList<>();
        List<List<Tuple<String, String>>> expand = new ArrayList<>();

        Map<String, Object> data = dataStore.queryEntity(entitySet, keys, navigationPath, Collections.emptyMap(), expand, Locale.US);

        assertNotNull(data);
        assertEquals("000001", data.get("ID"));
        assertEquals("DLN000001", data.get("DeliveryID"));
    }

    @Test
    public void testQueryEntitySetCount() {

        EdmEntitySet entitySet = mock(EdmEntitySet.class);
        Map<String, List<KeyPredicate>> keys = new HashMap<>();
        List<EdmEntitySet> navigationPath = new ArrayList<>();
        FilterExpression filterExpression = mock(FilterExpression.class);

        Integer count = dataStore.queryEntitySetCount(entitySet, keys, navigationPath, filterExpression, 0, 0, Collections.emptyMap(), Locale.US);

        assertNotNull(count);
        assertEquals(1, count.intValue());
    }
}

class GenericDataStoreDummy extends GenericDataStore {

    public GenericDataStoreDummy() {
        super("com.sap.model");
    }
}