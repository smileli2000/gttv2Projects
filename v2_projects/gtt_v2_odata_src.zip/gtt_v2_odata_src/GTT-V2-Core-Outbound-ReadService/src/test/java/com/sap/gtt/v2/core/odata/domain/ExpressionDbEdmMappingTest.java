package com.sap.gtt.v2.core.odata.domain;

import com.sap.gtt.v2.core.odata.common.Tuple;
import org.junit.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;

public class ExpressionDbEdmMappingTest {

    private ExpressionDbEdmMapping edmMapping = new ExpressionDbEdmMapping();

    @Test
    public void testSettersAndGetters () {
        Map<String, String> expandCol = new HashMap<>();
        edmMapping.setExpandCol(expandCol);
        assertEquals(expandCol, edmMapping.getExpandCol());
        edmMapping.setExpandCol(null);
        edmMapping.addExpandCol(expandCol);
        assertEquals(expandCol, edmMapping.getExpandCol());

        List<Tuple<Table, List<String>>> columnName = new ArrayList<>();
        edmMapping.setColumnName(columnName);
        assertEquals(columnName, edmMapping.getColumnName());
        edmMapping.setColumnName(null);
        edmMapping.addColumnName(columnName);
        assertEquals(columnName, edmMapping.getColumnName());

        Table mainTableName = new Table("Table", "Entity");
        edmMapping.setTableName(mainTableName);
        assertEquals(mainTableName, edmMapping.getTableName());

        List<Tuple<Column, Column>> joinColumnName = new ArrayList<>();
        edmMapping.setJoinColumnName(joinColumnName);
        assertEquals(columnName, edmMapping.getJoinColumnName());
        edmMapping.setJoinColumnName(null);
        edmMapping.addJoinColumnName(joinColumnName);
        assertEquals(columnName, edmMapping.getJoinColumnName());

        List<Table> joinTableName = new ArrayList<>();
        edmMapping.setJoinTableName(joinTableName);
        assertEquals(joinTableName, edmMapping.getJoinTableName());
        edmMapping.setJoinTableName(null);
        edmMapping.addJoinTableName(joinTableName);
        assertEquals(joinTableName, edmMapping.getJoinTableName());

        List<String> coreTableCol = new ArrayList<>();
        edmMapping.setCoreTableCol(coreTableCol);
        assertEquals(coreTableCol, edmMapping.getCoreTableCol());
        edmMapping.setCoreTableCol(null);
        edmMapping.addCoreTableCol(coreTableCol);
        assertEquals(coreTableCol, edmMapping.getCoreTableCol());

        edmMapping.getJoinColumnToString();
        edmMapping.getFromToString();

        ExpressionDbEdmMapping newEdmMapping = edmMapping;
        edmMapping = new ExpressionDbEdmMapping();
        edmMapping.addTableAndColumnInfo(edmMapping);
        assertEquals(newEdmMapping.getJoinTableName(), edmMapping.getJoinTableName());


    }
}
