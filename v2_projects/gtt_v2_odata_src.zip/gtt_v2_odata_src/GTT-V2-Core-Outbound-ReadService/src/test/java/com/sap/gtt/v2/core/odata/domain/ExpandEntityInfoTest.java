package com.sap.gtt.v2.core.odata.domain;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class ExpandEntityInfoTest {

    @Test
    public void testSetterAndGetter() {

        ExpandEntityInfo expandEntityInfo = new ExpandEntityInfo();

        expandEntityInfo.setEntityName("entityName");
        expandEntityInfo.setPropertyName("propertyName");
        expandEntityInfo.setParentEntityName("parentEntityName");
        expandEntityInfo.setParentPropertyName("parentPropertyName");
        expandEntityInfo.setChildEntityName("childEntityName");
        expandEntityInfo.setChildPropertyName("childPropertyName");

        assertEquals(expandEntityInfo.getEntityName(), "entityName");
        assertEquals(expandEntityInfo.getPropertyName(), "propertyName");
        assertEquals(expandEntityInfo.getParentEntityName(), "parentEntityName");
        assertEquals(expandEntityInfo.getParentPropertyName(), "parentPropertyName");
        assertEquals(expandEntityInfo.getChildEntityName(), "childEntityName");
        assertEquals(expandEntityInfo.getChildPropertyName(), "childPropertyName");
    }


}