package com.sap.gtt.v2.core.odata.callback;

import com.sap.gtt.v2.core.odata.domain.PagedEntitySetList;
import com.sap.gtt.v2.exception.InternalErrorException;
import org.apache.olingo.odata2.api.edm.EdmException;
import org.apache.olingo.odata2.api.ep.callback.WriteFeedCallbackContext;
import org.apache.olingo.odata2.api.ep.callback.WriteFeedCallbackResult;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Answers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.net.URI;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class ExpandEntitySetCallbackTest {

    @InjectMocks
    private ExpandEntitySetCallback expSetCallback;

    @Mock(answer = Answers.RETURNS_DEEP_STUBS)
    private WriteFeedCallbackContext context;

    private Map<String, Object> entryData;

    private PagedEntitySetList<Map<String, Object>> returnedData;

    @Before
    public void setup() throws EdmException {
        Map<String, Object> naviData = new HashMap<>();
        naviData.put("Col2", "Val2");
        List<Map<String, Object>> naviList = Arrays.asList(naviData);
        entryData = new HashMap<>();
        entryData.put("Col1", naviList);

        returnedData = new PagedEntitySetList<>();
        returnedData.setData(naviList);

        try {
            when(context.getEntryData()).thenReturn(entryData);
            when(context.getNavigationProperty().getName()).thenReturn("Col1");
        } catch (EdmException e) {
            fail(e.getMessage());
        }
    }

    @Test
    public void testRetrieveFeedResult() {
        URI uri = URI.create("http://localhost:8080");
        expSetCallback.setServiceRoot(uri);

        WriteFeedCallbackResult result = expSetCallback.retrieveFeedResult(context);
        assertEquals(returnedData.getData(), result.getFeedData());
    }

    @Test(expected = InternalErrorException.class)
    public void testRetrieveFeedResultException() throws InternalErrorException {
        WriteFeedCallbackContext ctx = mock(WriteFeedCallbackContext.class, RETURNS_DEEP_STUBS);
        EdmException exception = mock(EdmException.class);

        try {
            when(ctx.getNavigationProperty().getName()).thenThrow(exception);
        } catch (EdmException e) {
            fail(e.getMessage());
        }
        expSetCallback.retrieveFeedResult(ctx);
    }
}
