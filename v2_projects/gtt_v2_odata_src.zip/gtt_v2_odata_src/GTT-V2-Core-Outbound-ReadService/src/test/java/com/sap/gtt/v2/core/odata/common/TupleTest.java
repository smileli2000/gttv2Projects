package com.sap.gtt.v2.core.odata.common;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import org.junit.Test;

import static org.junit.Assert.*;

public class TupleTest {

    private final String k2 = "k2 value";
    private JsonElement k1 = new JsonPrimitive(1);

    @Test
    public void testConstructor() {
        Tuple<JsonElement, String> tuple = new Tuple<>(k1, k2);

        assertNotNull(tuple);
        assertNotNull(tuple.getK1());
        assertNotNull(tuple.getK2());
    }

    @Test
    public void testSetK1() {
        Tuple<JsonElement, String> tuple = new Tuple<>(k1, k2);
        tuple.setK1(new JsonPrimitive(2));

        assertEquals(new JsonPrimitive(2), tuple.getK1());
    }

    @Test
    public void testGetK1() {
        Tuple<JsonElement, String> tuple = new Tuple<>(k1, k2);

        assertEquals(new JsonPrimitive(1), tuple.getK1());
    }

    @Test
    public void testSetK2() {
        Tuple<JsonElement, String> tuple = new Tuple<>(k1, k2);
        tuple.setK2("k2 new value");

        assertEquals("k2 new value", tuple.getK2());
    }

    @Test
    public void testGetK2() {
        Tuple<JsonElement, String> tuple = new Tuple<>(k1, k2);

        assertEquals("k2 value", tuple.getK2());
    }

    @Test
    public void testToString() {
        Tuple<JsonElement, String> tuple = new Tuple<>(k1, k2);

        assertTrue(tuple.toString().length() > 0);
    }

    @Test
    public void testEquals() {
        Tuple<JsonElement, String> tuple1 = new Tuple<>(k1, k2);
        Tuple<JsonElement, String> tuple2 = new Tuple<>(k1, k2);

        assertTrue(tuple1.equals(tuple1));
        assertTrue(tuple1.equals(tuple2));
    }

    @Test
    public void testNullValueEquals() {
        Tuple<JsonElement, String> tuple1 = new Tuple<>(null, null);
        Tuple<JsonElement, String> tuple2 = new Tuple<>(null, null);

        assertTrue(tuple1.equals(tuple2));
        assertFalse(tuple1.equals(null));
    }

    @Test
    public void testNotEquals() {
        Tuple<JsonElement, String> tuple1 = new Tuple<>(k1, k2);
        Tuple<JsonElement, String> tuple2 = new Tuple<>(k1, "k2 new Value");
        Tuple<JsonElement, String> tuple3 = new Tuple<>(null, k2);
        Tuple<JsonElement, String> tuple4 = new Tuple<>(k1, null);

        assertFalse(tuple1.equals(tuple2));
        assertFalse(tuple1.equals(tuple3));
        assertFalse(tuple1.equals(tuple4));
        assertFalse(tuple1.equals("String"));
    }

    @Test
    public void testHashCode() {
        Tuple<JsonElement, String> tuple1 = new Tuple<>(k1, k2);

        assertEquals(-44238505, tuple1.hashCode());
    }

    @Test
    public void testNullValueHashCode() {
        Tuple<JsonElement, String> tuple1 = new Tuple<>(null, k2);
        Tuple<JsonElement, String> tuple2 = new Tuple<>(k1, null);
        Tuple<JsonElement, String> tuple3 = new Tuple<>(null, null);

        assertEquals(-44238536, tuple1.hashCode());
        assertEquals(31, tuple2.hashCode());
        assertEquals(0, tuple3.hashCode());
    }
}
