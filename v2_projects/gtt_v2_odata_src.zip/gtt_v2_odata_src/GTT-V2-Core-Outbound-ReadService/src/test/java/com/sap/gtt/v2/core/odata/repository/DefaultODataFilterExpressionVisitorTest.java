package com.sap.gtt.v2.core.odata.repository;


import com.sap.gtt.v2.core.domain.metadata.*;
import com.sap.gtt.v2.core.management.metadata.IMetadataManagement;
import com.sap.gtt.v2.core.odata.common.Storage;
import com.sap.gtt.v2.core.odata.common.Tuple;
import com.sap.gtt.v2.core.odata.domain.Column;
import com.sap.gtt.v2.core.odata.domain.Expression;
import com.sap.gtt.v2.core.odata.domain.ExpressionDbEdmMapping;
import com.sap.gtt.v2.core.odata.domain.Table;
import com.sap.gtt.v2.core.odata.exception.ODataServiceNotImplException;
import org.apache.olingo.odata2.api.edm.EdmException;
import org.apache.olingo.odata2.api.edm.EdmLiteral;
import org.apache.olingo.odata2.api.edm.EdmTyped;
import org.apache.olingo.odata2.api.uri.expression.*;
import org.apache.olingo.odata2.core.edm.EdmDateTime;
import org.apache.olingo.odata2.core.edm.EdmString;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class DefaultODataFilterExpressionVisitorTest {

    private DefaultODataFilterExpressionVisitor visitor;

    private IMetadataManagement metadataService;

    @Before
    public void setup() {
        metadataService = mock(IMetadataManagement.class);
        visitor = new DefaultODataFilterExpressionVisitor(Storage.DEFAULT, new ExpressionDbEdmMapping(), metadataService, "model.mainEntityType", "model");
    }

    @Test
    public void testVisitBinary() {

        BinaryExpression binaryExpression = mock(BinaryExpression.class);
        Column leftSide = new Column("Col1", new Table("Table1", "Entity1"));
        List<Column> primaryKeys = new ArrayList<>();
        primaryKeys.add(leftSide);
        Expression eqRes = (Expression) visitor.visitBinary(binaryExpression, BinaryOperator.EQ, leftSide, "Val1");
        eqRes.setPrimaryKeys(primaryKeys);
        assertEquals("Entity1.Col1 = ?", eqRes.getWhere());
        assertEquals("Val1", eqRes.getParameters().get(0));
        assertNotNull(eqRes.toSqlPrepareStmt());

        leftSide = new Column("Col2", new Table("Table2", "Entity2"));
        Expression neRes = (Expression) visitor.visitBinary(binaryExpression, BinaryOperator.NE, leftSide, "Val2");
        neRes.setPrimaryKeys(primaryKeys);
        assertEquals("Entity2.Col2 <> ?", neRes.getWhere());
        assertEquals("Val2", neRes.getParameters().get(0));
        assertNotNull(neRes.toSqlPrepareStmt());

        leftSide = new Column("Col3", new Table("Table3", "Entity3"));
        Expression gtRes = (Expression) visitor.visitBinary(binaryExpression, BinaryOperator.GT, leftSide, "Val3");
        gtRes.setPrimaryKeys(primaryKeys);
        assertEquals("Entity3.Col3 > ?", gtRes.getWhere());
        assertEquals("Val3", gtRes.getParameters().get(0));
        assertNotNull(gtRes.toSqlPrepareStmt());

        leftSide = new Column("Col4", new Table("Table4", "Entity4"));
        Expression geRes = (Expression) visitor.visitBinary(binaryExpression, BinaryOperator.GE, leftSide, "Val4");
        geRes.setPrimaryKeys(primaryKeys);
        assertEquals("Entity4.Col4 >= ?", geRes.getWhere());
        assertEquals("Val4", geRes.getParameters().get(0));
        assertNotNull(geRes.toSqlPrepareStmt());

        leftSide = new Column("Col5", new Table("Table5", "Entity5"));
        Expression ltRes = (Expression) visitor.visitBinary(binaryExpression, BinaryOperator.LT, leftSide, "Val5");
        ltRes.setPrimaryKeys(primaryKeys);
        assertEquals("Entity5.Col5 < ?", ltRes.getWhere());
        assertEquals("Val5", ltRes.getParameters().get(0));
        assertNotNull(ltRes.toSqlPrepareStmt());

        leftSide = new Column("Col6", new Table("Table6", "Entity6"));
        Expression leRes = (Expression) visitor.visitBinary(binaryExpression, BinaryOperator.LE, leftSide, "Val6");
        leRes.setPrimaryKeys(primaryKeys);
        assertEquals("Entity6.Col6 <= ?", leRes.getWhere());
        assertEquals("Val6", leRes.getParameters().get(0));
        assertNotNull(leRes.toSqlPrepareStmt());

        Expression eqRes1 = (Expression) visitor.visitBinary(binaryExpression, BinaryOperator.EQ, "Val7", "Val7");
        eqRes1.setPrimaryKeys(primaryKeys);
        assertEquals("Val7 = Val7", eqRes1.getWhere());
        assertNotNull(eqRes1.toSqlPrepareStmt());

        Expression andRes = (Expression) visitor.visitBinary(binaryExpression, BinaryOperator.AND, eqRes, neRes);
        andRes.setPrimaryKeys(primaryKeys);
        assertEquals("Entity1.Col1 = ? AND Entity2.Col2 <> ?", andRes.getWhere());
        assertEquals("Val1", andRes.getParameters().get(0));
        assertEquals("Val2", andRes.getParameters().get(1));
        assertNotNull(andRes.toSqlPrepareStmt());

        Expression orRes = (Expression) visitor.visitBinary(binaryExpression, BinaryOperator.OR, eqRes, neRes);
        orRes.setPrimaryKeys(primaryKeys);
        assertEquals("Entity1.Col1 = ? OR Entity2.Col2 <> ?", orRes.getWhere());
        assertEquals("Val1", orRes.getParameters().get(0));
        assertEquals("Val2", orRes.getParameters().get(1));
        assertNotNull(orRes.toSqlPrepareStmt());

        Expression leftsideExp = (Expression) visitor.visitBinary(binaryExpression, BinaryOperator.AND, "val1 = val1", "val2 = val2");
        Expression rightsideExp = (Expression) visitor.visitBinary(binaryExpression, BinaryOperator.AND, "val3 = val3", "val4 = val4");

        Expression eqRes2 = (Expression) visitor.visitBinary(binaryExpression, BinaryOperator.AND, leftsideExp, rightsideExp);
        eqRes2.setPrimaryKeys(primaryKeys);
        assertEquals("(val1 = val1 AND val2 = val2) AND (val3 = val3 AND val4 = val4)", eqRes2.getWhere());
        assertNotNull(eqRes2.toSqlPrepareStmt());
    }

    @Test(expected = ODataServiceNotImplException.class)
    public void testVisitBinaryException1() {
        BinaryExpression binaryExpression = mock(BinaryExpression.class);
        Column leftSide = new Column("Col1", new Table("Table1", "Entity1"));
        List<Column> primaryKeys = new ArrayList<>();
        primaryKeys.add(leftSide);
        leftSide = new Column("Col1", new Table("Table1", "Entity1"));
        visitor.visitBinary(binaryExpression, BinaryOperator.PROPERTY_ACCESS, leftSide, "Val1");
    }

    @Test(expected = ODataServiceNotImplException.class)
    public void testVisitBinaryException2() {
        BinaryExpression binaryExpression = mock(BinaryExpression.class);
        Column leftSide = new Column("Col1", new Table("Table1", "Entity1"));
        List<Column> primaryKeys = new ArrayList<>();
        primaryKeys.add(leftSide);
        leftSide = new Column("Col1", new Table("Table1", "Entity1"));
        visitor.visitBinary(binaryExpression, BinaryOperator.DIV, leftSide, "Val1");
    }


    @Test
    public void testVisitMethod() {

        MethodExpression methodExpression = mock(MethodExpression.class);
        when(methodExpression.getMethod()).thenReturn(MethodOperator.SUBSTRINGOF);
        Column property = new Column("Col1", new Table("Table1", "Entity1"));
        List<Column> primaryKeys = new ArrayList<>();
        primaryKeys.add(property);

        List<Object> parameters = Arrays.asList("Val1", property);

        Expression ssfRes = (Expression) visitor.visitMethod(methodExpression, MethodOperator.SUBSTRINGOF, parameters);
        ssfRes.setPrimaryKeys(primaryKeys);
        assertEquals("Entity1.Col1 LIKE ?", ssfRes.getWhere());
        assertEquals("%Val1%", ssfRes.getParameters().get(0));
        assertNotNull(ssfRes.toSqlPrepareStmt());

        BinaryExpression binaryExpression = mock(BinaryExpression.class);

        Expression neRes = (Expression) visitor.visitBinary(binaryExpression, BinaryOperator.EQ, ssfRes, "true");
        neRes.setPrimaryKeys(primaryKeys);
        assertEquals("Entity1.Col1 LIKE ?", neRes.getWhere());
        assertEquals("%Val1%", neRes.getParameters().get(0));
        assertNotNull(neRes.toSqlPrepareStmt());

        parameters = Arrays.asList(property, "Val1");

        when(methodExpression.getMethod()).thenReturn(MethodOperator.STARTSWITH);
        Expression swRes = (Expression) visitor.visitMethod(methodExpression, MethodOperator.STARTSWITH, parameters);
        swRes.setPrimaryKeys(primaryKeys);
        assertEquals("Entity1.Col1 LIKE ?", swRes.getWhere());
        assertEquals("Val1%", swRes.getParameters().get(0));
        assertNotNull(swRes.toSqlPrepareStmt());

        when(methodExpression.getMethod()).thenReturn(MethodOperator.ENDSWITH);
        Expression ewRes = (Expression) visitor.visitMethod(methodExpression, MethodOperator.ENDSWITH, parameters);
        ewRes.setPrimaryKeys(primaryKeys);
        assertEquals("Entity1.Col1 LIKE ?", ewRes.getWhere());
        assertEquals("%Val1", ewRes.getParameters().get(0));
        assertNotNull(ewRes.toSqlPrepareStmt());
    }

    @Test
    public void testVisitMember() {

        Column path = new Column("Col1", new Table("Table1", "Entity1"));
        Column property = new Column("Col2", new Table("Table2", "Entity2"));
        MetadataForeignKey foreignKey = new MetadataForeignKey();
        foreignKey.setGeneratedFieldName("Col3");
        foreignKey.setReferenceFieldName("Col4");

        MetadataEntity metadataEntity1 = mock(MetadataEntity.class);
        MetadataEntityElement element1 = mock(MetadataEntityElement.class);
        when(metadataEntity1.getName()).thenReturn("Entity2");
        PhysicalName physicalName1 = new PhysicalName();
        physicalName1.setName("Table2");
        when(metadataService.getPhysicalNameOfEntity(eq("model"), eq("Entity2"))).thenReturn(physicalName1);
        when(element1.getName()).thenReturn("Col1");
        when(element1.getType()).thenReturn(MetadataConstants.CdsDataType.CDS_ASSOCIATION);
        when(element1.getTarget()).thenReturn("Table1");
        when(element1.getForeignKey()).thenReturn(foreignKey);
        when(metadataEntity1.getElements()).thenReturn(Arrays.asList(element1));

        List<MetadataEntity> entities = Arrays.asList(metadataEntity1);

        MemberExpression memberExpression = mock(MemberExpression.class);
        when(metadataService.findODataNavigationEntitiesByPath(eq("model.mainEntityType"), eq("Col1/Col2"))).thenReturn(entities);

        Object res = visitor.visitMember(memberExpression, path, property);

        assertNotNull(res);
        assertEquals(path.getName(), ((Column) ((List) res).get(0)).getName());
        assertEquals(path.getTable().getTableName(), ((Column) ((List) res).get(0)).getTable().getTableName());
        assertEquals(path.getTable().getEntityName(), ((Column) ((List) res).get(0)).getTable().getEntityName());
        assertEquals(property.getName(), ((Column) ((List) res).get(1)).getName());
        assertEquals(property.getTable().getTableName(), ((Column) ((List) res).get(1)).getTable().getTableName());
        assertEquals(property.getTable().getEntityName(), ((Column) ((List) res).get(1)).getTable().getEntityName());
        Table joinTable = visitor.getExpressionDbEdmMapping().getJoinTableName().get(0);
        assertEquals("Table2", joinTable.getTableName());
        assertEquals("Entity2", joinTable.getEntityName());
        Tuple<Column, Column> joinColumnName = visitor.getExpressionDbEdmMapping().getJoinColumnName().get(0);
        assertEquals("Col4", joinColumnName.getK1().getName());
        assertEquals("Col3", joinColumnName.getK2().getName());
    }

    @Test
    public void testVisitProperty() {

        PropertyExpression propertyExpression = mock(PropertyExpression.class);

        ExpressionDbEdmMapping edmMapping = mock(ExpressionDbEdmMapping.class);
        visitor = new DefaultODataFilterExpressionVisitor(Storage.DEFAULT, edmMapping, metadataService, "model.mainEntityType", "model");
        Table table = new Table("Table1", "MainEntity");
        when(edmMapping.getTableName()).thenReturn(table);
        when(edmMapping.getCoreTableCol()).thenReturn(Arrays.asList("Col1"));
        try {
            EdmTyped edmProperty = mock(EdmTyped.class);
            when(edmProperty.getName()).thenReturn("Col1");

            Object res = visitor.visitProperty(propertyExpression, "Col1", edmProperty);
            assertNotNull(res);
            Column property = (Column) res;
            assertEquals("Col1", property.getName());
            assertEquals("CoreTableMainEntity", property.getTable().getEntityName());

        } catch (EdmException e) {
            fail(e.getMessage());
        }

    }

    @Test
    public void visitLiteral() {
        LiteralExpression literalExpression = mock(LiteralExpression.class);
        EdmDateTime edmDateTime = mock(EdmDateTime.class);
        EdmLiteral edmLiteral = new EdmLiteral(edmDateTime, "2019-01-01T00:00:00");

        Object res = visitor.visitLiteral(literalExpression, edmLiteral);
        assertNotNull(res);
        assertTrue(res instanceof Date);

        EdmString edmString = mock(EdmString.class);
        edmLiteral = new EdmLiteral(edmString, "2019-01-01T00:00:00");
        res = visitor.visitLiteral(literalExpression, edmLiteral);
        assertNotNull(res);
        assertEquals("2019-01-01T00:00:00", res);
    }

    @Test
    public void visitUnary() {
        UnaryExpression unaryExpression = mock(UnaryExpression.class);
        Expression expression = new Expression();
        expression.setWhere("Col = 1");

        Object res = visitor.visitUnary(unaryExpression, UnaryOperator.NOT, expression);
        assertNotNull(res);
        assertEquals("NOT( Col = 1 )", expression.getWhere());
    }
}
