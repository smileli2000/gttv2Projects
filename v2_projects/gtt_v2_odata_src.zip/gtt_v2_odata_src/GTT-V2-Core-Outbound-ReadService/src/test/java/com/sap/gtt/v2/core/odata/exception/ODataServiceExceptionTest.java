package com.sap.gtt.v2.core.odata.exception;

import org.apache.http.HttpStatus;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class ODataServiceExceptionTest {
    @Test
    public void testODataServiceExceptionWithMsgCode() {
        new ODataServiceException("OData service exception");
    }

    @Test
    public void testODataServiceExceptionWithCause() {
        Throwable cause = new Throwable();
        new ODataServiceException(cause);
    }

    @Test
    public void testODataServiceExceptionWithMsgCodeAndLocalizedMsgParams() {
        new ODataServiceException("OData service exception", new Object[]{});
    }

    @Test
    public void testODataServiceExceptionWithoutLocalizedMsgParams() {
        Throwable cause = new Throwable();
        new ODataServiceException("Internal Message", cause, "OData service exception");
    }

    @Test
    public void testODataServiceExceptionWithAll() {
        Throwable cause = new Throwable();
        new ODataServiceException("Internal Message", cause, "OData service exception", new Object[]{});
    }

    @Test(expected = ODataServiceException.class)
    public void testThrowODataServiceException() throws ODataServiceException {
        throw new ODataServiceException("OData service exception");
    }

    @Test
    public void testGetHttpStatus() {
        ODataServiceException exception = new ODataServiceException("OData service exception");
        assertEquals(HttpStatus.SC_BAD_REQUEST, exception.getHttpStatus());
    }
}
