package com.sap.gtt.v2.core.odata.bootstrap;

import com.sap.gtt.v2.configuration.ISAPCloudPlatformAgent;
import com.sap.gtt.v2.controller.DefaultExceptionHandler;
import com.sap.gtt.v2.core.management.metadata.IMetadataManagement;
import com.sap.gtt.v2.core.odata.common.Constants;
import com.sap.gtt.v2.core.odata.utils.ODataUtils;
import com.sap.gtt.v2.core.odata.service.GenericODataSingleProcessor;
import com.sap.gtt.v2.exception.FormattedErrorMessage;
import com.sap.gtt.v2.util.GTTUtils;
import com.sap.gtt.v2.util.SpringContextUtils;
import org.apache.olingo.odata2.api.ODataCallback;
import org.apache.olingo.odata2.api.ODataService;
import org.apache.olingo.odata2.api.processor.ODataContext;
import org.apache.olingo.odata2.api.processor.ODataErrorContext;
import org.apache.olingo.odata2.api.processor.ODataResponse;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Answers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import java.io.IOException;

import static org.apache.olingo.odata2.api.processor.ODataContext.HTTP_SERVLET_REQUEST_OBJECT;
import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.*;

@RunWith(PowerMockRunner.class)
@PrepareForTest({SpringContextUtils.class, GTTUtils.class})
public class BootstrapServiceFactoryTest {

    @Mock(answer = Answers.RETURNS_DEEP_STUBS)
    private ISAPCloudPlatformAgent.ICurrentAccessContext currentContext;

    @InjectMocks
    private BootstrapServiceFactory factory;

    @Test
    public void testCreateService() {
        final String model = "com.sap.gtt.app.mim.MIMService_metadata";
        RequestWrapper requestWrapper = mock(RequestWrapper.class, RETURNS_DEEP_STUBS);
        ODataContext context = mock(ODataContext.class);
        when(context.getParameter(eq(HTTP_SERVLET_REQUEST_OBJECT))).thenReturn(requestWrapper);
        when(requestWrapper.getRequest().getAttribute(Constants.MODEL_ATTRIBUTE_KEY)).thenReturn(model);

        IMetadataManagement metadataService = mock(IMetadataManagement.class);
        when(currentContext.createBusinessOperator().getMetadataManagement()).thenReturn(metadataService);

        try {
            String edmx = ODataUtils.inputStreamToString(Thread.currentThread().getContextClassLoader().getResourceAsStream( model + ".edmx"));
            when(metadataService.getODataEdmx(eq(model))).thenReturn(edmx);
        } catch (IOException e) {
            fail(e.getMessage());
        }

        PowerMockito.mockStatic(SpringContextUtils.class);
        GenericODataSingleProcessor processor = mock(GenericODataSingleProcessor.class);
        given(SpringContextUtils.getBean(eq(GenericODataSingleProcessor.class))).willReturn(processor);

        ODataService service = factory.createService(context);
        assertNotNull(service);
    }

    @Test
    public void testGetCallback() {

        ODataCallback res = factory.getCallback(BootstrapServiceFactory.GlobalErrorCallback.class);

        assertNotNull(res);
        assertTrue(res instanceof BootstrapServiceFactory.GlobalErrorCallback);
    }

    @Test
    public void testHandleError() {
        ODataErrorContext context = mock(ODataErrorContext.class);

        PowerMockito.mockStatic(GTTUtils.class);
        ODataErrorContext transformedContext = new ODataErrorContext();
        transformedContext.setContentType("application/json");
        given(GTTUtils.createAndCopyBean(eq(context), eq(ODataErrorContext.class), anyBoolean())).willReturn(transformedContext);

        Exception exception = mock(Exception.class);
        when(context.getException()).thenReturn(exception);

        PowerMockito.mockStatic(SpringContextUtils.class);
        DefaultExceptionHandler handler = mock(DefaultExceptionHandler.class);
        given(SpringContextUtils.getBean(eq(DefaultExceptionHandler.class))).willReturn(handler);

        FormattedErrorMessage errorMessage = mock(FormattedErrorMessage.class);
        when(handler.handleExceptionAndTransformMessage(exception)).thenReturn(errorMessage);
        when(errorMessage.getHttpStatus()).thenReturn(500);

        FormattedErrorMessage.Error error = mock(FormattedErrorMessage.Error.class, RETURNS_DEEP_STUBS);
        when(errorMessage.getError()).thenReturn(error);
        when(error.getCode()).thenReturn("Error Code");
        when(error.getMessage().getValue()).thenReturn("Error Message");

        BootstrapServiceFactory.GlobalErrorCallback errorCallback = new BootstrapServiceFactory.GlobalErrorCallback();
        ODataResponse res = errorCallback.handleError(context);
        assertNotNull(res);
    }
}
