package com.sap.gtt.v2.core.odata.service;

import com.sap.gtt.v2.configuration.ISAPCloudPlatformAgent;
import com.sap.gtt.v2.core.odata.bootstrap.RequestWrapper;
import com.sap.gtt.v2.core.odata.common.Constants;
import com.sap.gtt.v2.core.odata.domain.PagedEntitySetList;
import com.sap.gtt.v2.core.odata.repository.GenericDataStore;
import com.sap.gtt.v2.util.SpringContextUtils;
import org.apache.olingo.odata2.api.batch.BatchException;
import org.apache.olingo.odata2.api.batch.BatchHandler;
import org.apache.olingo.odata2.api.batch.BatchRequestPart;
import org.apache.olingo.odata2.api.batch.BatchResponsePart;
import org.apache.olingo.odata2.api.edm.*;
import org.apache.olingo.odata2.api.ep.EntityProvider;
import org.apache.olingo.odata2.api.ep.EntityProviderBatchProperties;
import org.apache.olingo.odata2.api.exception.ODataException;
import org.apache.olingo.odata2.api.processor.ODataContext;
import org.apache.olingo.odata2.api.processor.ODataResponse;
import org.apache.olingo.odata2.api.uri.KeyPredicate;
import org.apache.olingo.odata2.api.uri.NavigationSegment;
import org.apache.olingo.odata2.api.uri.PathInfo;
import org.apache.olingo.odata2.api.uri.info.GetEntitySetCountUriInfo;
import org.apache.olingo.odata2.api.uri.info.GetEntitySetUriInfo;
import org.apache.olingo.odata2.api.uri.info.GetEntityUriInfo;
import org.apache.olingo.odata2.core.ODataContextImpl;
import org.apache.olingo.odata2.core.PathInfoImpl;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Answers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import java.io.InputStream;
import java.net.URI;
import java.util.*;

import static org.apache.olingo.odata2.api.processor.ODataContext.HTTP_SERVLET_REQUEST_OBJECT;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;
import static org.mockito.BDDMockito.given;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.*;

@RunWith(PowerMockRunner.class)
@PrepareForTest({SpringContextUtils.class, EntityProvider.class})
public class GenericODataSingleProcessorTest {

    @InjectMocks
    private GenericODataSingleProcessor testDouble;

    private GenericODataSingleProcessor processor;

    @Mock(answer = Answers.RETURNS_DEEP_STUBS)
    private ISAPCloudPlatformAgent.ICurrentAccessContext currentContext;

    private GenericDataStore dataStore;

    @Before
    public void setup() {
        PagedEntitySetList<Map<String, Object>> result = new PagedEntitySetList<>();
        Map<String, Object> obj = new HashMap<>();
        obj.put("ID", "000001");
        obj.put("DeliveryID", "DLN000001");
        result.setData(Arrays.asList(obj));

        processor = spy(testDouble);

        PowerMockito.mockStatic(SpringContextUtils.class);
        dataStore = mock(GenericDataStore.class);
        given(SpringContextUtils.getBean(eq(GenericDataStore.class), anyString())).willReturn(dataStore);

        ODataContext context = mock(ODataContextImpl.class);
        PathInfo path = mock(PathInfoImpl.class);
        RequestWrapper requestWrapper = mock(RequestWrapper.class, RETURNS_DEEP_STUBS);
        try {
            when(path.getServiceRoot()).thenReturn(URI.create("http://example.com"));
            when(context.getPathInfo()).thenReturn(path);
            when(context.getAcceptableLanguages()).thenReturn(Arrays.asList(Locale.US));
            when(context.getParameter(eq(HTTP_SERVLET_REQUEST_OBJECT))).thenReturn(requestWrapper);
            when(requestWrapper.getRequest().getAttribute(eq(Constants.MODEL_ATTRIBUTE_KEY))).thenReturn("com.sap.gtt.app.tfo.TFOService");
            when(processor.getContext()).thenReturn(context);
            when(dataStore.queryEntitySet(any(EdmEntitySet.class), any(), any(), any(),
                    any(), any(), any(), any(), any(), any(), any())).thenReturn(result);
            when(dataStore.queryEntity(any(EdmEntitySet.class), any(), any(), any(),
                    any(), any())).thenReturn(obj);
        } catch (ODataException e) {
            fail(e.getMessage());
        }
    }


    @Test
    public void testReadEntitySet() {
        GetEntitySetUriInfo uriInfo = mock(GetEntitySetUriInfo.class);
        EdmNavigationProperty navigationProperty = mock(EdmNavigationProperty.class, RETURNS_DEEP_STUBS);
        EdmEntitySet entitySet = mock(EdmEntitySet.class, RETURNS_SMART_NULLS);
        EdmReferentialConstraint referentialConstraint = mock(EdmReferentialConstraint.class, RETURNS_DEEP_STUBS);
        EdmEntityType entityType = mock(EdmEntityType.class);
        EdmProperty edmProperty = mock(EdmProperty.class);
        KeyPredicate keyPredicate = mock(KeyPredicate.class, RETURNS_DEEP_STUBS);
        NavigationSegment navigationSegment = mock(NavigationSegment.class, RETURNS_DEEP_STUBS);
        EdmEntityContainer entityContainer = mock(EdmEntityContainer.class);

        try {
            when(entityContainer.getName()).thenReturn("EntityContainer");
            when(edmProperty.getName()).thenReturn("ID");
            when(navigationProperty.getRelationship().getReferentialConstraint()).thenReturn(referentialConstraint);
            when(referentialConstraint.getDependent().getPropertyRefNames()).thenReturn(Arrays.asList("ID"));
            when(referentialConstraint.getPrincipal().getPropertyRefNames()).thenReturn(Arrays.asList("ID"));
            when(keyPredicate.getLiteral()).thenReturn("000001");
            when(keyPredicate.getProperty().getName()).thenReturn("ID");
            when(navigationSegment.getNavigationProperty()).thenReturn(navigationProperty);
            when(navigationSegment.getEntitySet().getEntityType()).thenReturn(entityType);
            when(entitySet.getName()).thenReturn("Events");
            when(entitySet.getEntityType()).thenReturn(entityType);
            when(entitySet.getEntityContainer()).thenReturn(entityContainer);
            when(entityType.getKeyProperties()).thenReturn(Arrays.asList(edmProperty));
            when(entityType.getName()).thenReturn("com.sap.eventType");
            when(uriInfo.getNavigationSegments()).thenReturn(Arrays.asList(navigationSegment));
            when(uriInfo.getExpand()).thenReturn(Collections.emptyList());
            when(uriInfo.getTargetEntitySet()).thenReturn(entitySet);
            when(uriInfo.getStartEntitySet()).thenReturn(entitySet);
            when(uriInfo.getKeyPredicates()).thenReturn(Arrays.asList(keyPredicate));

            ODataResponse response = processor.readEntitySet(uriInfo, "application/json");

            assertNotNull(response);
        } catch (ODataException e) {
            fail(e.getMessage());
        }
    }

    @Test
    public void testReadEntity() {
        GetEntityUriInfo uriInfo = mock(GetEntityUriInfo.class);
        EdmEntitySet entitySet = mock(EdmEntitySet.class, RETURNS_SMART_NULLS);
        EdmEntityType entityType = mock(EdmEntityType.class);
        KeyPredicate keyPredicate = mock(KeyPredicate.class, RETURNS_DEEP_STUBS);
        EdmEntityContainer entityContainer = mock(EdmEntityContainer.class);

        try {
            when(entityContainer.getName()).thenReturn("EntityContainer");
            when(entitySet.getName()).thenReturn("Events");
            when(entitySet.getEntityType()).thenReturn(entityType);
            when(entitySet.getEntityContainer()).thenReturn(entityContainer);
            when(entityType.getKeyProperties()).thenReturn(Collections.emptyList());
            when(uriInfo.getNavigationSegments()).thenReturn(Collections.emptyList());
            when(uriInfo.getExpand()).thenReturn(Collections.emptyList());
            when(uriInfo.getStartEntitySet()).thenReturn(entitySet);
            when(uriInfo.getTargetEntitySet()).thenReturn(entitySet);
            when(uriInfo.getKeyPredicates()).thenReturn(Arrays.asList(keyPredicate));

            ODataResponse response = processor.readEntity(uriInfo, "application/json");

            assertNotNull(response);
        } catch (ODataException e) {
            fail(e.getMessage());
        }
    }

    @Test
    public void testCountEntitySet() {
        GetEntitySetCountUriInfo uriInfo = mock(GetEntitySetCountUriInfo.class);
        EdmEntitySet entitySet = mock(EdmEntitySet.class, RETURNS_SMART_NULLS);
        EdmEntityType entityType = mock(EdmEntityType.class);
        KeyPredicate keyPredicate = mock(KeyPredicate.class, RETURNS_DEEP_STUBS);
        try {
            when(dataStore.queryEntitySetCount(any(EdmEntitySet.class), any(), any(), any(),
                    any(), any(), any(), any())).thenReturn(1);
            when(entitySet.getName()).thenReturn("Events");
            when(entitySet.getEntityType()).thenReturn(entityType);
            when(uriInfo.getStartEntitySet()).thenReturn(entitySet);
            when(uriInfo.getTargetEntitySet()).thenReturn(entitySet);
            when(uriInfo.getKeyPredicates()).thenReturn(Arrays.asList(keyPredicate));


            ODataResponse response = processor.countEntitySet(uriInfo, "application/json");

            assertNotNull(response);
        } catch (ODataException e) {
            fail(e.getMessage());
        }
    }

    @Test
    public void testExecuteBatch() throws BatchException{
        BatchHandler handler = Mockito.mock(BatchHandler.class, RETURNS_DEEP_STUBS);
        String contentType = "multipart/mixed;boundary=batch_1f1e-8cdb-aefd";
        InputStream content = Mockito.mock(InputStream.class, RETURNS_DEEP_STUBS);

        BatchRequestPart reqPart1 = Mockito.mock(BatchRequestPart.class,RETURNS_DEEP_STUBS);
        BatchRequestPart reqPart2 = Mockito.mock(BatchRequestPart.class, RETURNS_DEEP_STUBS);
        List<BatchRequestPart> batchRequestParts = Arrays.asList(reqPart1, reqPart2);

        PowerMockito.mockStatic(EntityProvider.class);
        given(EntityProvider.parseBatchRequest(anyString(),any(InputStream.class), any(EntityProviderBatchProperties.class))).willReturn(batchRequestParts);
        try {
            processor.executeBatch(handler, contentType, content);
        } catch (ODataException e) {
            fail(e.getMessage());
        }
    }
}
