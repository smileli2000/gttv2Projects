package com.sap.gtt.v2.core.odata.domain;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class ColumnTest {

    @Test
    public void testConstructor() {
        Column column = new Column("col", new Table("table", "entity"));
        assertNotNull(column);
        assertEquals("col", column.getName());
        assertEquals("table", column.getTable().getTableName());
        assertEquals("entity", column.getTable().getEntityName());
    }

    @Test
    public void testSettersAndGetters() {
        Column column = new Column("col", new Table("table", "entity"));
        assertNotNull(column);

        Table table = new Table("table2", "entity2");
        column.setName("col2");
        column.setTable(table);

        assertEquals("col2", column.getName());
        assertEquals("table2", column.getTable().getTableName());
        assertEquals("entity2", column.getTable().getEntityName());
    }
}
