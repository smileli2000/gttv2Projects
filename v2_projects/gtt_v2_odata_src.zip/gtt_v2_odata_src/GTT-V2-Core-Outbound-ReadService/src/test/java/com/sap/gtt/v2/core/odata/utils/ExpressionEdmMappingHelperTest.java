package com.sap.gtt.v2.core.odata.utils;

import com.sap.gtt.v2.core.domain.metadata.*;
import com.sap.gtt.v2.core.management.metadata.DefaultMetadataManagement;
import com.sap.gtt.v2.core.management.metadata.IMetadataManagement;
import com.sap.gtt.v2.core.odata.common.Tuple;
import com.sap.gtt.v2.core.odata.domain.Column;
import com.sap.gtt.v2.core.odata.domain.ExpressionDbEdmMapping;
import com.sap.gtt.v2.core.odata.domain.Table;
import com.sap.gtt.v2.core.odata.utils.ExpressionEdmMappingHelper;
import org.apache.olingo.odata2.api.edm.EdmEntitySet;
import org.apache.olingo.odata2.api.edm.EdmEntityType;
import org.apache.olingo.odata2.api.edm.EdmException;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class ExpressionEdmMappingHelperTest {

    protected IMetadataManagement metadataService;
    private ExpressionEdmMappingHelper helper;

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void testNavigationForComposition() throws EdmException {
        String namespace = "";

        //mock start entity set
        String startEntityName = "ProcurementOrderItemProcess";
        EdmEntitySet startEntitySet = Mockito.mock(EdmEntitySet.class);
        EdmEntityType startEntityType = Mockito.mock(EdmEntityType.class);
        when(startEntitySet.getName()).thenReturn(startEntityName);
        when(startEntitySet.getEntityType()).thenReturn(startEntityType);
        when(startEntityType.toString()).thenReturn(startEntityName);

        //mock end entity set
        String targetEntityName = "QualifiedTrackingId";
        EdmEntitySet targetEntitySet = Mockito.mock(EdmEntitySet.class);
        EdmEntityType targetEntityType = Mockito.mock(EdmEntityType.class);
        when(targetEntitySet.getName()).thenReturn(targetEntityName);
        when(targetEntitySet.getEntityType()).thenReturn(targetEntityType);
        when(targetEntityType.toString()).thenReturn(targetEntityName);


        //mock metadata service
        PhysicalName startEntityTableName = Mockito.mock(PhysicalName.class);
        when(startEntityTableName.getName()).thenReturn("POITEMPROCESS");
        when(startEntityTableName.getCorePhysicalName()).thenReturn("TRACKEDPROCESS");
        PhysicalName targetEntityTableName = Mockito.mock(PhysicalName.class);
        when(targetEntityTableName.getName()).thenReturn("TRACKINGIDS");
        Table targetTable = new Table("TRACKINGIDS","QualifiedTrackingId");

        Map<String,MetadataEntityElement> allColumnInStartEntity = new HashMap<>();
        MetadataEntityElement elm1 = Mockito.mock(MetadataEntityElement.class);
        allColumnInStartEntity.put("trackingIds",elm1);
        when(elm1.getType()).thenReturn(MetadataConstants.CdsDataType.CDS_COMPOSITION);
        when(elm1.getTarget()).thenReturn(targetEntityName);
        when(elm1.isKey()).thenReturn(true);
        when(elm1.getName()).thenReturn("Id");

        MetadataForeignKey foreignKey = Mockito.mock(MetadataForeignKey.class);
        when(foreignKey.getGeneratedFieldName()).thenReturn("Id");
        when(foreignKey.getReferenceFieldName()).thenReturn("Process_id");
        when(elm1.getForeignKey()).thenReturn(foreignKey);


        this.metadataService = Mockito.mock(DefaultMetadataManagement.class);
        when(metadataService.findAllFieldsOfEntity(namespace,startEntityName)).thenReturn(allColumnInStartEntity);
        when(metadataService.getPhysicalNameOfEntity(namespace,targetEntityName)).thenReturn(targetEntityTableName);
        when(metadataService.getPhysicalNameOfEntity(namespace,startEntityName)).thenReturn(startEntityTableName);

        //Initial instance
        this.helper = new ExpressionEdmMappingHelper(this.metadataService,namespace);

        List<Table> joinTable = new ArrayList();
        List<Tuple<Column,Column>> joinColumn = new ArrayList<>();
        List<EdmEntitySet> navigationPath = new ArrayList<>();
        navigationPath.add(startEntitySet);
        navigationPath.add(targetEntitySet);

        //Call method
        helper.buildJoinTableColumnForNavigation(targetTable,navigationPath,joinTable,joinColumn);


        List<Table> expJoinTable = new ArrayList();
        List<Tuple<Column,Column>> expJoinColumn = new ArrayList<>();

        Table table1 = new Table("TRACKEDPROCESS","CoreTableProcurementOrderItemProcess");
        expJoinTable.add(table1);
        Table table2 = new Table("POITEMPROCESS","ProcurementOrderItemProcess");
        expJoinTable.add(table2);
        Table table3 = new Table("TRACKINGIDS","QualifiedTrackingId");


        expJoinColumn.add(new Tuple(new Column("Process_id",table1),new Column("Id",table3)));
        expJoinColumn.add(new Tuple(new Column("Id",table2),new Column("Id",table1)));

        compareJoinTable(joinTable,expJoinTable);
        compareJoinColumn(joinColumn,expJoinColumn);

    }

    @Test
    public void testNavigationForAssociation() throws EdmException{
        String namespace = "";

        //mock startEntitySet
        String startEntityName = "ProcessEventDirectory";
        EdmEntitySet startEntitySet = Mockito.mock(EdmEntitySet.class);
        EdmEntityType startEntityType = Mockito.mock(EdmEntityType.class);
        when(startEntitySet.getName()).thenReturn(startEntityName);
        when(startEntitySet.getEntityType()).thenReturn(startEntityType);
        when(startEntityType.toString()).thenReturn(startEntityName);

        //mock end entity set
        String targetEntityName = "PlannedEvent";
        EdmEntitySet targetEntitySet = Mockito.mock(EdmEntitySet.class);
        EdmEntityType targetEntityType = Mockito.mock(EdmEntityType.class);
        when(targetEntitySet.getName()).thenReturn(targetEntityName);
        when(targetEntitySet.getEntityType()).thenReturn(targetEntityType);
        when(targetEntityType.toString()).thenReturn(targetEntityName);
        Table targetTable = new Table("PLANNEDEVENT",targetEntityName);

        //mock metadata service
        PhysicalName startEntityTableName = Mockito.mock(PhysicalName.class);
        when(startEntityTableName.getName()).thenReturn("PROCESSEVENTDIRECTORY");
        PhysicalName targetEntityTableName = Mockito.mock(PhysicalName.class);
        when(targetEntityTableName.getName()).thenReturn("PLANNEDEVENT");


        Map<String,MetadataEntityElement> allColumnInStartEntity = new HashMap<>();
        MetadataEntityElement elm1 = Mockito.mock(MetadataEntityElement.class);
        allColumnInStartEntity.put("plannedEvent",elm1);
        when(elm1.getType()).thenReturn(MetadataConstants.CdsDataType.CDS_ASSOCIATION);
        when(elm1.getTarget()).thenReturn(targetEntityName);
        when(elm1.getName()).thenReturn("plannedEvent");

        MetadataForeignKey foreignKey = Mockito.mock(MetadataForeignKey.class);
        when(foreignKey.getGeneratedFieldName()).thenReturn("process_id");
        when(foreignKey.getReferenceFieldName()).thenReturn("id");
        when(elm1.getForeignKey()).thenReturn(foreignKey);

        this.metadataService = Mockito.mock(DefaultMetadataManagement.class);
        when(metadataService.findAllFieldsOfEntity(namespace,startEntityName)).thenReturn(allColumnInStartEntity);
        when(metadataService.getPhysicalNameOfEntity(namespace,targetEntityName)).thenReturn(targetEntityTableName);
        when(metadataService.getPhysicalNameOfEntity(namespace,startEntityName)).thenReturn(startEntityTableName);

        //Initial instance
        this.helper = new ExpressionEdmMappingHelper(this.metadataService,namespace);

        List<Table> joinTable = new ArrayList();
        List<Tuple<Column,Column>> joinColumn = new ArrayList<>();
        List<EdmEntitySet> navigationPath = new ArrayList<>();
        navigationPath.add(startEntitySet);
        navigationPath.add(targetEntitySet);

        //Call method
        helper.buildJoinTableColumnForNavigation(targetTable,navigationPath,joinTable,joinColumn);


        List<Table> expJoinTable = new ArrayList();
        List<Tuple<Column,Column>> expJoinColumn = new ArrayList<>();

        Table table1 = new Table("PROCESSEVENTDIRECTORY","ProcessEventDirectory");
        Table table2 = new Table("PLANNEDEVENT","PlannedEvent");
        expJoinTable.add(table1);

        expJoinColumn.add(new Tuple(new Column("process_id",table1), new Column("id",table2) ));

        compareJoinTable(joinTable,expJoinTable);
        compareJoinColumn(joinColumn,expJoinColumn);

    }

    @Test
    public void testbuildJoinTableColumnForExpandAssociation() throws EdmException{
        //Test case: plannedEvent/process
        String namespace = "";
        //mock mainEntitySet
        EdmEntitySet mainEntitySet = mock(EdmEntitySet.class);
        EdmEntityType mainEntityType = mock(EdmEntityType.class);
        when(mainEntitySet.getEntityType()).thenReturn(mainEntityType);
        when(mainEntityType.toString()).thenReturn("PlannedEvent");

        //mock metadataService
        this.metadataService = Mockito.mock(DefaultMetadataManagement.class);
        List<MetadataEntity> naviEntities = new ArrayList<>();

        MetadataEntity entity1 = mock(MetadataEntity.class);
        when(entity1.getName()).thenReturn("PlannedEvent");
        List<MetadataEntityElement> elemList1 = new ArrayList<>();
        MetadataEntityElement elem1 = mock(MetadataEntityElement.class);
        when(elem1.getName()).thenReturn("process");
        when(elem1.getType()).thenReturn(MetadataConstants.CdsDataType.CDS_ASSOCIATION);
        when(elem1.getTarget()).thenReturn("TrackedProcess");
        MetadataForeignKey foreignKey = mock(MetadataForeignKey.class);
        when(foreignKey.getReferenceFieldName()).thenReturn("id");
        when(foreignKey.getGeneratedFieldName()).thenReturn("process_id");
        when(elem1.getForeignKey()).thenReturn(foreignKey);
        elemList1.add(elem1);
        when(entity1.getElements()).thenReturn(elemList1);

        MetadataEntity entity2 = mock(MetadataEntity.class);
        when(entity2.getName()).thenReturn("TrackedProcess");
        naviEntities.add(entity1);
        naviEntities.add(entity2);

        PhysicalName mainEntityTableName = mock(PhysicalName.class);
        when(mainEntityTableName.getName()).thenReturn("PlannedEvent");
        when(mainEntityTableName.getCorePhysicalName()).thenReturn("PlannedEvent");
        when(metadataService.getPhysicalNameOfEntity("", "PlannedEvent")).thenReturn(mainEntityTableName);

        PhysicalName tableName = mock(PhysicalName.class);
        when(tableName.getName()).thenReturn("TrackedProcess");
        when(tableName.getCorePhysicalName()).thenReturn("TrackedProcess");
        when(metadataService.getPhysicalNameOfEntity("", "TrackedProcess")).thenReturn(tableName);


        when(metadataService.findODataNavigationEntitiesByPath("PlannedEvent","process")).thenReturn(naviEntities);


        //mock expressionDbEdmMapping
        ExpressionDbEdmMapping expressionDbEdmMapping = mock(ExpressionDbEdmMapping.class);
        List<Table> existedJoinTable = new ArrayList<>();
        when(expressionDbEdmMapping.getJoinTableName()).thenReturn(existedJoinTable);

        //mock tableColumn
        List<Tuple<Table, List<String>>> tableColumn = new ArrayList<>();

        //mock expand
        List<List<Tuple<String, String>>> expand = new ArrayList<>();
        expand.add(new ArrayList<>());
        expand.get(0).add(new Tuple<>("process","TrackedProcess"));

        //mock joinTableName
        List<Table> joinTableName = new ArrayList<>();

        //mock joinColumn
        List<Tuple<Column, Column>> joinColumn = new ArrayList<>();

        //mock expandCol
        Map<String, String> expandCol = new HashMap<>();
        expandCol.put("TrackedProcess","process");

        this.helper = new ExpressionEdmMappingHelper(this.metadataService,namespace);

        helper.buildJoinTableColumnForExpand(mainEntitySet,expressionDbEdmMapping, expand, tableColumn,joinTableName,joinColumn,expandCol);

        List<Table> expJoinTable = new ArrayList<>();
        expJoinTable.add(new Table("TrackedProcess","TrackedProcess"));

        List<Tuple<Column,Column>> expJoinColumn = new ArrayList<>();
        expJoinColumn.add(new Tuple<>(new Column("id",new Table("TrackedProcess","TrackedProcess")),
                                   new Column("process_id",new Table("PlannedEvent","PlannedEvent"))));
        compareJoinTable(joinTableName,expJoinTable);
        compareJoinColumn(joinColumn,expJoinColumn);

    }




    private void compareJoinTable(List<Table> table, List<Table> expTable){
        assertEquals(table.size(),expTable.size());

        for(int i=0;i<table.size();i++)
        {
            assertTableEquals(table.get(i),expTable.get(i));
        }
    }


    private void compareJoinColumn(List<Tuple<Column,Column>> joinColumn, List<Tuple<Column,Column>> expJoinColumn){
        assertEquals(joinColumn.size(), expJoinColumn.size());

        for(int i=0;i<joinColumn.size();i++){
            assertEquals(joinColumn.get(i).getK1().getName(),expJoinColumn.get(i).getK1().getName());
            assertEquals(joinColumn.get(i).getK2().getName(),expJoinColumn.get(i).getK2().getName());
            assertTableEquals(joinColumn.get(i).getK1().getTable(),expJoinColumn.get(i).getK1().getTable());
            assertTableEquals(joinColumn.get(i).getK2().getTable(),expJoinColumn.get(i).getK2().getTable());
        }

    }

    private void assertTableEquals(Table table, Table expTable){
        assertEquals(table.getTableName(),expTable.getTableName());
        assertEquals(table.getEntityName(),expTable.getEntityName());
    }

}