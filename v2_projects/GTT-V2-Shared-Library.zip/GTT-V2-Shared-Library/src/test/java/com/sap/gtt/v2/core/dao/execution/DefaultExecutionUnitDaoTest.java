package com.sap.gtt.v2.core.dao.execution;

import com.sap.gtt.v2.BaseTest;
import com.sap.gtt.v2.Dummy;
import com.sap.gtt.v2.core.entity.execution.ExecutionUnit;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = Dummy.class)
@ActiveProfiles("test")
public class DefaultExecutionUnitDaoTest extends BaseTest {
    private DefaultExecutionUnitDao executionUnitDao;

    @Before
    public void setUp() {
        super.setUp();
        executionUnitDao = DefaultExecutionUnitDao.getInstance();
    }

    @Test
    public void testQueryExecutionUnitWhenCorrelatedTpIdIsNotNull() {
        String eventId = "eventId";
        String correlatedTpId = "tpId";
        ExecutionUnit executionUnit = executionUnitDao.queryExecutionUnit(eventId, correlatedTpId);
        if (executionUnit == null) {
            insertExecutionUnit(eventId, correlatedTpId);
            executionUnit = executionUnitDao.queryExecutionUnit(eventId, correlatedTpId);
        }
        assertThat(executionUnit.getEventId()).isEqualTo(eventId);
        assertThat(executionUnit.getCorrelatedTpId()).isEqualTo(correlatedTpId);
    }

    @Test
    public void testQueryExecutionUnitWhenCorrelatedTpIdIsNull() {
        String eventId = "eventId";
        ExecutionUnit executionUnit = executionUnitDao.queryExecutionUnit(eventId, null);
        if (executionUnit == null) {
            insertExecutionUnit(eventId, null);
            executionUnit = executionUnitDao.queryExecutionUnit(eventId, null);
        }
        assertThat(executionUnit.getEventId()).isEqualTo(eventId);
        assertThat(executionUnit.getCorrelatedTpId()).isNull();
    }

    @Test
    public void testUpdateExecutionUnit() {
        String eventId = "eventId";
        ExecutionUnit executionUnit = executionUnitDao.queryExecutionUnit(eventId, null);
        if (executionUnit == null) {
            insertExecutionUnit(eventId, null);
            executionUnit = executionUnitDao.queryExecutionUnit(eventId, null);
        }
        String id = executionUnit.getId();
        int executionCount = executionUnit.getExecutionCount() + 1;
        String lastExecutionId = UUID.randomUUID().toString();
        executionUnitDao.updateExecutionUnit(id, executionCount, lastExecutionId);
        executionUnit = executionUnitDao.queryExecutionUnit(eventId, null);
        assertThat(executionUnit.getEventId()).isEqualTo(eventId);
        assertThat(executionUnit.getCorrelatedTpId()).isNull();
        assertThat(executionUnit.getId()).isEqualTo(id);
        assertThat(executionUnit.getExecutionCount()).isEqualTo(executionCount);
        assertThat(executionUnit.getLastExecutionId()).isEqualTo(lastExecutionId);
    }

    @Test
    public void testQueryExecutionUnitByExecutionId() {
        String executionId = "executionId";
        ExecutionUnit executionUnit = executionUnitDao.queryExecutionUnit(executionId);
        if (executionUnit == null) {
            ExecutionUnit newExecutionUnit = new ExecutionUnit("id", "requestId", "eventId", "eventtType", "altkey", "locationAltkey", "tpId", "processAltkey", 1, executionId, false);
            executionUnitDao.insertExecutionUnit(newExecutionUnit);
            executionUnit = executionUnitDao.queryExecutionUnit(executionId);
        }
        assertThat(executionUnit.getLastExecutionId()).isEqualTo(executionId);
    }

    private void insertExecutionUnit(String eventId, String correlatedTpId) {
        String id = UUID.randomUUID().toString();
        String executionId = UUID.randomUUID().toString();
        ExecutionUnit newExecutionUnit = new ExecutionUnit(id, "requestId", eventId, "eventtType", "altkey", "locationAltkey", correlatedTpId, "processAltkey", 1, executionId, false);
        executionUnitDao.insertExecutionUnit(newExecutionUnit);
    }
}
