package com.sap.gtt.v2.core.dao.tracking;


import com.sap.gtt.v2.BaseTest;
import com.sap.gtt.v2.Dummy;
import com.sap.gtt.v2.core.dao.metadata.*;
import com.sap.gtt.v2.core.domain.metadata.CurrentMetadataEntity;
import com.sap.gtt.v2.core.domain.metadata.MetadataConstants;
import com.sap.gtt.v2.core.domain.trackedprocess.CorrelationType;
import com.sap.gtt.v2.core.domain.trackedprocess.EventWrapper;
import com.sap.gtt.v2.core.domain.trackedprocess.LifeCycleStatus;
import com.sap.gtt.v2.core.entity.trackedprocess.*;
import com.sap.gtt.v2.core.management.metadata.DefaultMetadataManagement;
import com.sap.gtt.v2.core.management.metadata.IMetadataManagement;
import com.sap.gtt.v2.core.runtime.model.IPropertyValue;
import com.sap.gtt.v2.core.runtime.model.ListValue;
import com.sap.gtt.v2.exception.PropertyValidationException;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.IOException;
import java.time.Instant;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import static com.sap.gtt.v2.core.entity.trackedprocess.TrackedProcess.TRACKING_IDS;
import static org.assertj.core.api.Assertions.assertThat;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = Dummy.class)
@ActiveProfiles("test")
public class DefaultTrackedProcessDaoTest extends BaseTest {

    @Autowired
    private ITrackedProcessDao trackedProcessDao;

    @Autowired
    private IQualifiedTrackingIdDao qualifiedTrackingIdDao;

    @Autowired
    private IProcessEventDirectoryDao processEventDirectoryDao;

    @Autowired
    private IPlannedEventDao plannedEventDao;

    @Autowired
    private IEventDao eventDao;

    @Autowired
    private IMetadataDao metadataDao;

    @Autowired
    private ISysTableDao sysTableDao;

    @Test
    public void test() throws IOException {
        DefaultMetadataDaoTest test = new DefaultMetadataDaoTest();
        test.setDefaultMetadataDao((DefaultMetadataDao) metadataDao);
        test.insertMetadataProject();

        DefaultSysTableDaoTest test1 = new DefaultSysTableDaoTest();
        test1.setDefaultSysTableDao((DefaultSysTableDao)sysTableDao);
        test1.createTables();

        String entityType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        String entityName = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        String namespace = "com.sap.gtt.app.mim";

        IMetadataManagement metadataManagement = DefaultMetadataManagement.getInstance();
        CurrentMetadataEntity metadata = metadataManagement.findAllEntitiesRecursively(namespace, entityName);

        TrackedProcess tp = new TrackedProcess();
        tp.setId(UUID.randomUUID());
        tp.setTrackedProcessType(entityType);
        tp.setTrackingId("my-tracking-id");
        tp.setPartyId("666666");
        tp.setScheme("my-scheme");
        tp.setAltKey("my-alt-key");
        tp.setLifeCycleStatus(LifeCycleStatus.END_OF_BUSINESS);
        tp.setTrackingIdType("my-tracking-id-type");
        tp.setLogicalSystem("a-system");

        tp.setValue("procurementOrderNO", "12345");
        tp.setValue("procurementOrderItemQty", 88.8);
        tp.setMetadata(metadata);
        tp.setVersion(0);
        tp.setLifeCycleStatus(LifeCycleStatus.BUSINESS_ACTIVE);
        System.out.println(LifeCycleStatus.BUSINESS_ACTIVE.toString());
        ListValue nullList = null;
        tp.setValue(TRACKING_IDS, nullList);
        trackedProcessDao.insert(tp);

        TrackedProcess retrieved = trackedProcessDao.findOne(metadata, tp.getId().getInternalValue());
        Assert.assertEquals(tp.getId(), retrieved.getId());
        Assert.assertEquals(tp.getAltKey(), retrieved.getAltKey());

        //test namespace
        List<TrackedProcess> retrievedList = trackedProcessDao.findAllByNamespace(namespace);
        Assert.assertEquals(tp.getId(), retrievedList.get(0).getId());

        // no such uuid
        retrieved = trackedProcessDao.findOneWithValidStatus(UUID.randomUUID());
        assertThat(retrieved).isNull();

        retrieved = trackedProcessDao.findOneWithValidStatus(tp.getId().getInternalValue());
        Assert.assertEquals(tp.getId(), retrieved.getId());
        Assert.assertEquals(tp.getAltKey(), retrieved.getAltKey());

        tp.setLogicalSystem("within-10");
        tp.setVersion(1);
        trackedProcessDao.update(tp,0);

        retrieved = trackedProcessDao.findOneByAltKey(metadata, "my-alt-key");
        Assert.assertEquals(tp.getId(), retrieved.getId());
        Assert.assertEquals(tp.getAltKey(), retrieved.getAltKey());
        Assert.assertEquals("within-10", retrieved.getLogicalSystem());
        Assert.assertEquals(tp.getLifeCycleStatus(), retrieved.getLifeCycleStatus());
//        Assert.assertNotNull(retrieved.getLastChangedByUser());
//        Assert.assertNotNull(retrieved.getLastChangedDateTime());

        //
        QualifiedTrackingId qualifiedTrackingId = new QualifiedTrackingId();
        CurrentMetadataEntity metadata1 = new CurrentMetadataEntity();
        metadata1.setAllRelatedEntityMap(metadata.getAllRelatedEntityMap());
        metadata1.setCurrentEntityName(MetadataConstants.CoreModelEntity.QUALIFIED_TRACKING_ID.getFullName());
        qualifiedTrackingId.setMetadata(metadata1);
        qualifiedTrackingId.setProcessId(tp.getId().getInternalValue());
        qualifiedTrackingId.setObservedProcessId(UUID.randomUUID());
        qualifiedTrackingId.setValidTo(Instant.now());
        qualifiedTrackingId.setValidFrom(Instant.now());
        qualifiedTrackingIdDao.insert(qualifiedTrackingId);

        qualifiedTrackingId.setProcessId(tp.getId().getInternalValue());
        qualifiedTrackingId.setObservedProcessId(UUID.randomUUID());
        qualifiedTrackingId.setValidTo(Instant.now());
        qualifiedTrackingId.setValidFrom(Instant.now());
        qualifiedTrackingIdDao.insert(qualifiedTrackingId);

        qualifiedTrackingId.setValidFrom(Instant.now());
        qualifiedTrackingId.setValidTo(Instant.now());
        qualifiedTrackingIdDao.update(qualifiedTrackingId);

        List<UUID> uuids = qualifiedTrackingIdDao.getCorrelatedProcessId(
                qualifiedTrackingId.getMetadata(), qualifiedTrackingId.getObservedProcessId(), qualifiedTrackingId.getValidTo());
        assertThat(uuids).size().isGreaterThan(0);

        PlannedEvent plannedEvent = new PlannedEvent();
        plannedEvent.setId(UUID.randomUUID());
        plannedEvent.setProcessId(tp.getId());
        plannedEvent.setEventStatus("DELAYED");
        //plannedEvent.setLocationId(UUID.randomUUID());
        plannedEvent.setPlannedBusinessTimestamp(Instant.now());
        plannedEvent.setPlannedTechnicalTimestamp(Instant.now());
        plannedEvent.setPlannedBusinessTimeZone("+8");
        plannedEvent.setEventType("PLANNED");
        plannedEvent.setPlannedBizTsEarliest(Instant.now());
        plannedEvent.setPlannedBizTsLatest(Instant.now());
        plannedEvent.setPlannedTechTsEarliest(Instant.now());
        plannedEvent.setPlannedTechTsLatest(Instant.now());
        plannedEvent.setNextOverdueDetection(Instant.now());
        plannedEvent.setOverdueDetectionCounter(1);
        plannedEvent.setPayloadSequence(1);
        plannedEvent.setValue("mode", "abc");

        CurrentMetadataEntity metadata3 = new CurrentMetadataEntity();
        metadata3.setAllRelatedEntityMap(metadata.getAllRelatedEntityMap());
        metadata3.setCurrentEntityName(MetadataConstants.CoreModelEntity.PLANNED_EVENT.getFullName());
        plannedEvent.setMetadata(metadata3);
        plannedEventDao.insert(Arrays.asList(plannedEvent));

        //
        ProcessEventDirectory ped = new ProcessEventDirectory();
        CurrentMetadataEntity metadata2 = new CurrentMetadataEntity();
        metadata2.setAllRelatedEntityMap(metadata.getAllRelatedEntityMap());
        metadata2.setCurrentEntityName(MetadataConstants.CoreModelEntity.PROCESS_EVENT_DIRECTORY.getFullName());

        ped.setId(UUID.randomUUID());
        ped.setProcessId(tp.getId().getInternalValue());
        ped.setEventId(UUID.randomUUID());
        ped.setPlannedEventId(plannedEvent.getId());
        ped.setCorrelationType("dummy-correlation-type");
        ped.setMetadata(metadata2);
        processEventDirectoryDao.insert(ped);

        ped.setId(UUID.randomUUID());
        ped.setProcessId(tp.getId().getInternalValue());
        ped.setEventId(plannedEvent.getId());
        ped.setPlannedEventId(UUID.randomUUID());
        ped.setCorrelationType("dummy-correlation-type");
        processEventDirectoryDao.insert(ped);


        ProcessEventDirectory pedDummy = new ProcessEventDirectory();
        pedDummy.setMetadata(metadata2);
        pedDummy.setId(UUID.randomUUID());
        pedDummy.setProcessId(tp.getId().getInternalValue());
        pedDummy.setEventId(UUID.randomUUID());
        pedDummy.setPlannedEventId(plannedEvent.getId());
        pedDummy.setCorrelationType("dummy-correlation-type");
        assertThat(ped).isNotEqualTo(pedDummy);
        //
        retrieved = trackedProcessDao.findOne(metadata, tp.getId().getInternalValue());
        List<QualifiedTrackingId> trackingIds = retrieved.getTrackingIds();
        System.out.println(trackingIds);
        Assert.assertEquals(2, trackingIds.size());
        Assert.assertEquals(2, retrieved.getPEDs().size());
        Assert.assertEquals(1, retrieved.getPlannedEvents().size());
        PlannedEvent peRetrieved = retrieved.getPlannedEvents().get(0);
        assertThat(peRetrieved.getValue("mode")).isEqualTo(plannedEvent.getValue("mode"));

        tp.setTrackingIds(retrieved.getTrackingIds());
        tp.getTrackingIds().get(0).setValidTo(Instant.now());
        tp.setPEDs(retrieved.getPEDs());
        tp.getPEDs().get(0).setPlannedEventId(UUID.randomUUID());
        tp.setPlannedEvents(retrieved.getPlannedEvents());
        tp.getPlannedEvents().get(0).setOverdueDetectionCounter(8);
        int version = tp.getVersion();
        tp.setVersion(version+1);
        trackedProcessDao.update(tp, version);

        retrieved = trackedProcessDao.findOne(metadata, tp.getId().getInternalValue());
        Assert.assertEquals(2, retrieved.getTrackingIds().size());
        Assert.assertEquals(2, retrieved.getPEDs().size());
        Assert.assertEquals(1, retrieved.getPlannedEvents().size());

        Event event = new Event();
        CurrentMetadataEntity metadata4 = new CurrentMetadataEntity();
        metadata4.setAllRelatedEntityMap(metadata.getAllRelatedEntityMap());
        metadata4.setCurrentEntityName(MetadataConstants.CoreModelEntity.EVENT.getFullName());

        event.setMetadata(metadata4);
        event.setId(ped.getEventId());
        event.setSubaccountId(UUID.randomUUID());
        event.setCloneInstanceId(UUID.randomUUID());
        event.setActualBusinessTimestamp(Instant.now());
        event.setEventType("com.sap.gtt.app.tfo.FreightOrderModel.FreightOrderEvent");
        event.setEventReasonText("first event");
        event.setAltKey("xri://sap.com/id:LBN#01220003:Q8JCLNT774:FreightOrder:0001");
        eventDao.insert(event);

        ped.setId(UUID.randomUUID());
        ped.setProcessId(tp.getId().getInternalValue());
        ped.setEventId(UUID.randomUUID());
        ped.setPlannedEventId(plannedEvent.getId());
        ped.setCorrelationType("dummy-correlation-type");
        processEventDirectoryDao.insert(ped);

        event.setId(ped.getEventId());
        event.setSubaccountId(UUID.randomUUID());
        event.setCloneInstanceId(UUID.randomUUID());
        event.setActualBusinessTimestamp(Instant.now().plusSeconds(1));
        event.setEventType("com.sap.gtt.app.tfo.FreightOrderModel.FreightOrderEvent");
        event.setEventReasonText("second event");
        event.setAltKey("xri://sap.com/id:LBN#01220003:Q8JCLNT774:FreightOrder:0002");
        event.setPriority(0);
        eventDao.insert(event);

        List<Event> eventTypes = eventDao.findByAltKey("xri://sap.com/id:LBN#01220003:Q8JCLNT774:FreightOrder:0001");
        assertThat(eventTypes.size()).isEqualTo(1);

        List<DefaultEventDao.EventTypeAndId> eventTypeAndIds = eventDao
                .findEventTypeAndIdByAltKey("xri://sap.com/id:LBN#01220003:Q8JCLNT774:FreightOrder:0001");
        assertThat(eventTypeAndIds.size()).isEqualTo(1);
        assertThat(eventTypeAndIds.get(0)).isNotEqualTo(
                new DefaultEventDao.EventTypeAndId("", UUID.randomUUID()));
        assertThat(eventTypeAndIds.get(0).getEventType()).isNotBlank();
        assertThat(eventTypeAndIds.get(0).getId()).isNotNull();

        // include
        List<EventWrapper> eventWrappers = eventDao.getActualEventsForCurrentTPIncludeEventTypes(ped.getProcessId(),
                Arrays.asList("com.sap.gtt.app.tfo.FreightOrderModel.FreightOrderEvent"));
        assertThat(eventWrappers).size().isEqualTo(2);

        eventWrappers = eventDao.getActualEventsForCurrentTPIncludeEventTypes(ped.getProcessId(),
                Arrays.asList("com.sap.gtt.app.tfo.FreightOrderModel.FreightOrderEvent",
                        "no-such-event-type"));
        assertThat(eventWrappers).size().isEqualTo(2);

        eventWrappers = eventDao.getActualEventsForCurrentTPIncludeEventTypes(ped.getProcessId(),
                Arrays.asList("no-such-event-type"));
        assertThat(eventWrappers).size().isEqualTo(0);

        eventWrappers = eventDao.getActualEventsForCurrentTPIncludeEventTypes(ped.getProcessId(),
                Arrays.asList());
        assertThat(eventWrappers).size().isEqualTo(0);

        eventWrappers = eventDao.getActualEventsForCurrentTPIncludeEventTypes(ped.getProcessId(),
                Arrays.asList(""));
        assertThat(eventWrappers).size().isEqualTo(0);

        eventWrappers = eventDao.getActualEventsForCurrentTPIncludeEventTypes(ped.getProcessId(),
                null);
        assertThat(eventWrappers).size().isEqualTo(0);

        // exclude
        eventWrappers = eventDao.getActualEventsForCurrentTPExcludeEventTypes(ped.getProcessId(),
                Arrays.asList("com.sap.gtt.app.tfo.FreightOrderModel.FreightOrderEvent"));
        assertThat(eventWrappers).size().isEqualTo(0);

        eventWrappers = eventDao.getActualEventsForCurrentTPExcludeEventTypes(ped.getProcessId(),
                Arrays.asList("com.sap.gtt.app.tfo.FreightOrderModel.FreightOrderEvent",
                        "no-such-event-type"));
        assertThat(eventWrappers).size().isEqualTo(0);

        eventWrappers = eventDao.getActualEventsForCurrentTPExcludeEventTypes(ped.getProcessId(),
                Arrays.asList("no-such-event-type"));
        assertThat(eventWrappers).size().isEqualTo(2);

        eventWrappers = eventDao.getActualEventsForCurrentTPExcludeEventTypes(ped.getProcessId(),
                Arrays.asList(""));
        assertThat(eventWrappers).size().isEqualTo(2);

        eventWrappers = eventDao.getActualEventsForCurrentTPExcludeEventTypes(ped.getProcessId(),
                Arrays.asList());
        assertThat(eventWrappers).size().isEqualTo(2);

        eventWrappers = eventDao.getActualEventsForCurrentTPExcludeEventTypes(ped.getProcessId(),
                null);
        assertThat(eventWrappers).size().isEqualTo(2);
        eventWrappers.get(0).setPlannedEventId(plannedEvent.getId());
        eventWrappers.get(0).setCorrelationType(CorrelationType.REPORTED.toString());
        eventWrappers.get(0).setEvent(null);
        assertThat(eventWrappers.get(0).toString()).contains("plannedEventId=");

        Event eventFound = eventDao.findOneByTpIdAndEventType(metadata4, ped.getProcessId(),
                "com.sap.gtt.app.tfo.FreightOrderModel.FreightOrderEvent");
        assertThat(eventFound.getEventReasonText()).isEqualTo("first event");

        eventFound = eventDao.findLatestByTpIdAndEventTypeList(ped.getProcessId(),
                Arrays.asList("com.sap.gtt.app.tfo.FreightOrderModel.FreightOrderEvent"));
        assertThat(eventFound.getEventReasonText()).isEqualTo("second event");

        Event foundOne = eventDao.findOneById(eventFound.getIdAsInternalValue());
        assertThat(foundOne).isNotNull();
        eventDao.deleteByProcessId(ped.getProcessId());
        foundOne = eventDao.findOneById(eventFound.getIdAsInternalValue());
        assertThat(foundOne).isNull();
        Event eventNotExist = eventDao.findOneByTpIdAndEventType(metadata4, ped.getProcessId(),
                "com.sap.gtt.app.tfo.FreightOrderModel.FreightOrderEvent");
        assertThat(eventNotExist).isNull();

        TrackedProcess tpNew = new TrackedProcess();
        tpNew.setMetadata(tp.getMetadata());
        tpNew.setId(UUID.randomUUID());//tp.getId().getInternalValue());
        tpNew.setTrackedProcessType(tp.getTrackedProcessType());
        tpNew.setTrackingId("my-tracking-id");
        tpNew.setPartyId("666666");
        tpNew.setScheme("new-scheme");
        tpNew.setAltKey("my-alt-key");
        tpNew.setLifeCycleStatus(LifeCycleStatus.END_OF_PURPOSE);
        tpNew.setTrackingIdType("new-tracking-id-type");
        tpNew.setLogicalSystem("new-system");

        QualifiedTrackingId qualifiedTrackingId1 = QualifiedTrackingId.build(tp.getId().getInternalValue(), UUID.randomUUID(), Instant.now(), Instant.now());
        qualifiedTrackingId1.setMetadata(metadata1);
        List<QualifiedTrackingId> modifiedTrackingIds = retrieved.getTrackingIds();
        modifiedTrackingIds.add(qualifiedTrackingId1);
        tpNew.setTrackingIds(modifiedTrackingIds);
        retrieved.getPEDs().remove(0);
        tpNew.setPEDs(retrieved.getPEDs());
        retrieved.getPlannedEvents().remove(0);
        tpNew.setPlannedEvents(retrieved.getPlannedEvents());
        tpNew.setLifeCycleStatus(LifeCycleStatus.END_OF_BUSINESS);
        tpNew.setVersion(0);

        trackedProcessDao.insert(Arrays.asList(tpNew));
        assertThat(trackedProcessDao.versionExists(tpNew, 0)).isTrue();
        assertThat(trackedProcessDao.versionExists(tpNew, 1)).isFalse();
        retrieved = trackedProcessDao.findOne(metadata, tp.getId().getInternalValue());
 //       Assert.assertEquals(3, retrieved.getTrackingIds().size());

        retrieved = trackedProcessDao.findOneWithValidStatus(tpNew.getId().getInternalValue());
        trackedProcessDao.findAllByAltKeys(tpNew.getMetadata(), tpNew.getAltKey());
        trackedProcessDao.findAllByAltKeys(tpNew.getMetadata(), Arrays.asList(tpNew.getAltKey()));
        TrackedProcess tpRetrieved = trackedProcessDao.findOne(tpNew.getId().getInternalValue());
        assertThat(tpRetrieved).isNotNull();
        /*Assertions.assertThat(plannedEventDao.findOneById(UUID.randomUUID()))
                .isNull();*/
        qualifiedTrackingIdDao.findAll(retrieved.getId().getInternalValue(), Instant.now());
        qualifiedTrackingIdDao.exists(qualifiedTrackingId);

        qualifiedTrackingIdDao.deleteByProcessId(retrieved.getId().getInternalValue());

        plannedEventDao.deleteByProcessId(retrieved.getId().getInternalValue(), plannedEvent.getMetadata().getCurrentEntity().getPhysicalName());

        qualifiedTrackingIdDao.delete(qualifiedTrackingId);
        processEventDirectoryDao.delete(ped.getMetadata(), ped.getId());
        processEventDirectoryDao.deleteByProcessId(ped.getId());
        processEventDirectoryDao.deleteByPlannedEventId(ped.getPlannedEventId());

        trackedProcessDao.delete(tpNew);
        //trackedProcessDao.delete(tpNew.getMetadata(), tpNew.getId().getInternalValue());
        //plannedEventDao.delete(plannedEvent);
    }

    @Test
    public void testDataFieldCheck() throws IOException {
        DefaultMetadataDaoTest test = new DefaultMetadataDaoTest();
        test.setDefaultMetadataDao((DefaultMetadataDao) metadataDao);
        test.insertMetadataProject();

        DefaultSysTableDaoTest test1 = new DefaultSysTableDaoTest();
        test1.setDefaultSysTableDao((DefaultSysTableDao)sysTableDao);
        test1.createTables();

        String entityName = "com.sap.gtt.app.mim.InboundDeliveryItemModel.InboundDeliveryItemEvent";
        String namespace = "com.sap.gtt.app.mim";

        IMetadataManagement metadataManagement = DefaultMetadataManagement.getInstance();
        CurrentMetadataEntity metadata = metadataManagement.findAllEntitiesRecursively(namespace, entityName);

        Event event = new Event();
        event.setMetadata(metadata);
        event.setPartyId("party-id");
        Object obj = null;
        event.setValue("longitude", obj);
        IPropertyValue longitude = event.getValue("longitude");
        System.out.println(longitude);
        event.setValue("longitude", 180d);
        try {
            event.setValue("longitude", 180.1d);
            assertThat(event.getValue("longitude"))
            .isNull(); // not possible here
        } catch(PropertyValidationException e) {
            System.out.println(e.getMessage());
            assertThat(event.getValue("longitude"))
                    .isNotNull();
        }

        try {
            event.setValue("longitude", 179.999d);
            assertThat(event.getValue("longitude"))
                    .isNotNull(); // not possible here
        } catch(PropertyValidationException e) {
            System.out.println(e.getMessage());
            assertThat(event.getValue("longitude"))
                    .isNotNull();
        }
    }
}