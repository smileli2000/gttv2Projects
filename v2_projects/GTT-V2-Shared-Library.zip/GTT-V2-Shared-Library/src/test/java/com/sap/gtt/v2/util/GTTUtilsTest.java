package com.sap.gtt.v2.util;

import com.sap.gtt.v2.configuration.EnvironmentsConfiguration;
import com.sap.gtt.v2.configuration.GTTRestTemplate;
import com.sap.gtt.v2.core.management.execution.DefaultMessageLogManagement;
import com.sap.gtt.v2.core.management.metadata.DefaultMetadataManagement;
import com.sap.gtt.v2.core.management.overdue.DefaultOverdueManagement;
import com.sap.gtt.v2.core.management.tracking.DefaultEventManagement;
import com.sap.gtt.v2.core.management.tracking.DefaultTrackedProcessManagement;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;

import java.time.Instant;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import static com.sap.gtt.v2.configuration.EnvironmentsConfiguration.VcapServiceParser.DestinationServiceInstance.Destination;
import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;

@RunWith(PowerMockRunner.class)
@PrepareForTest({SpringContextUtils.class, UaaUtils.class, DefaultTrackedProcessManagement.class, DefaultEventManagement.class, DefaultMetadataManagement.class, DefaultOverdueManagement.class})
public class GTTUtilsTest {

    @Mock
    private GTTRestTemplate restTemplate;

    @Before
    public void setUp() {
        PowerMockito.mockStatic(SpringContextUtils.class, UaaUtils.class, DefaultTrackedProcessManagement.class, DefaultEventManagement.class, DefaultMetadataManagement.class, DefaultOverdueManagement.class);
        when(DefaultTrackedProcessManagement.getInstance()).thenReturn(mock(DefaultTrackedProcessManagement.class));
        when(DefaultEventManagement.getInstance()).thenReturn(mock(DefaultEventManagement.class));
        when(DefaultMetadataManagement.getInstance()).thenReturn(mock(DefaultMetadataManagement.class));
        when(DefaultOverdueManagement.getInstance()).thenReturn(mock(DefaultOverdueManagement.class));
        when(DefaultMessageLogManagement.getInstance()).thenReturn(mock(DefaultMessageLogManagement.class));
        when(SpringContextUtils.getBean(GTTRestTemplate.class)).thenReturn(restTemplate);

        String accessTokenUrl = "url";
        String accessTokenStr = "{\"access_token\": \"access_token\",\"token_type\": \"bearer\",\"expires_in\": 3599,\"scope\": \"lbn_gtt_core_acceptance!b5700.model.cp\",\"jti\": \"d9a3e44d1cd643138a8ff3e62409e35a\"}";

        String clientId = "clientId";
        String clientSecret = "clientSecret";
        String uaaUrl = "tokenServiceURL";
        when(UaaUtils.requestTechniqueToken(uaaUrl, clientId, clientSecret)).thenReturn(accessTokenStr);

        ResponseEntity<String> response = mock(ResponseEntity.class);
        when(restTemplate.exchange(eq(accessTokenUrl), any(HttpMethod.class), any(HttpHeaders.class), any(), eq(String.class))).thenReturn(response);
        when(response.getBody()).thenReturn(accessTokenStr);
    }

    @Test
    public void parseAltKey() {
        String altKey = "xri://sap.com/id:LBN#001220003:ABC123:FreightOrder:4711";
        GTTUtils.AltKey altKeyObj = GTTUtils.parseAltKey(altKey);
        assertEquals("xri://sap.com/id", altKeyObj.getScheme());
        assertEquals("LBN#001220003", altKeyObj.getParty());
        assertEquals("ABC123", altKeyObj.getLogicalSystem());
        assertEquals("FreightOrder", altKeyObj.getType());
        assertEquals("4711", altKeyObj.getId());

        String locationAltKey = "xri:sapgtt:LBN#666666:Q8JCLNT774:Location:shippingPoint:2005";
        altKeyObj = GTTUtils.parseAltKey(locationAltKey);
        assertEquals("xri:sapgtt", altKeyObj.getScheme());
        assertEquals("LBN#666666", altKeyObj.getParty());
        assertEquals("Q8JCLNT774", altKeyObj.getLogicalSystem());
        assertEquals("shippingPoint", altKeyObj.getType());
        assertEquals("2005", altKeyObj.getId());
    }

    @Test
    public void getDuplicateElements() {
        List<Integer> duplicateElements = GTTUtils.getDuplicateElements(Arrays.asList(1, 2, 3, 3, 6, 2, 8));
        assertEquals(2, duplicateElements.size());
    }

    @Test
    public void toLowerCaseFirstCharacter() {
        String helloWorld = GTTUtils.toLowerCaseFirstCharacter("HelloWorld");
        assertEquals("helloWorld", helloWorld);
    }

    @Test
    public void createBusinessOperator() {
        GTTUtils.BusinessOperator businessOperator = GTTUtils.createBusinessOperator(EnvironmentsConfiguration.VcapServiceParser.DatabaseServiceInstance.DatabaseType.h2);
        assertNotNull(businessOperator);
        assertNotNull(businessOperator.getTrackedProcessManagement());
        assertNotNull(businessOperator.getEventManagement());
        assertNotNull(businessOperator.getMetadataManagement());
        assertNotNull(businessOperator.getOverdueManagement());
        assertNotNull(businessOperator.getMessageLogManagement());
    }

    @Test
    public void getTZStringFromInstant() {
        Instant now = Instant.now();
        String fromInstant = GTTUtils.getTZStringFromInstant(now);
        assertNotNull(fromInstant);
    }

    @Test
    public void getInstantFromTZString() {
        Instant instant = GTTUtils.getInstantFromTZString("2019-12-03T10:15:30.00Z");
        assertNotNull(instant);
    }

    @Test
    public void createAndCopyBean() {
        List<String> aList = Arrays.asList("1", "3", "test");
        List andCopyBean = GTTUtils.createAndCopyBean(aList, List.class, true);
        assertEquals(aList, andCopyBean);

        try {
            // no getter and setter methods
            andCopyBean = GTTUtils.createAndCopyBean(aList, List.class, false);
            fail();
        } catch (Exception e) {
            assertTrue(true);
        }

        GTTUtils.AltKey altKey = new GTTUtils.AltKey();
        altKey.setScheme("schema");
        altKey.setParty("party");
        altKey.setLogicalSystem("system");
        altKey.setType("FreightOrder");
        altKey.setId("12345");

        GTTUtils.AltKey clonedAltKey = GTTUtils.createAndCopyBean(altKey, GTTUtils.AltKey.class, false);
        assertEquals(altKey.getScheme(), clonedAltKey.getScheme());
        assertEquals(altKey.getParty(), clonedAltKey.getParty());
        assertEquals(altKey.getLogicalSystem(), clonedAltKey.getLogicalSystem());
        assertEquals(altKey.getType(), clonedAltKey.getType());
        assertEquals(altKey.getId(), clonedAltKey.getId());
    }

    @Test
    public void sendRequest() {
        String destinationJsonStr = "{\"Name\": \"aa\",\"Description\": \"description\",\"Type\": \"type\", \"URL\": \"url\", \"CloudConnectorLocationId\":\"locationId\", \"Authentication\": \"OAuth2ClientCredentials\", \"ProxyType\":\"pType\", \"User\":\"user\", \"Password\":\"pwd\", \"clientId\": \"clientId\", \"tokenServiceUser\":\"tokenServiceUser\",\"tokenServiceURL\":\"tokenServiceURL\",\"clientSecret\":\"clientSecret\",\"tokenServicePassword\":\"tokenServicePassword\"}";

        Destination destination = Destination.fromJson(destinationJsonStr);
        String s = GTTUtils.sendRequest(destination, HttpMethod.GET, null, String.class);
        assertNotNull(s);
    }

    @Test
    public void from32ToUUID() {
        UUID uuid = GTTUtils.UUIDUtils.from32ToUUID("30bfcf58c34411e99f8a1d7ced3daa62");
        assertEquals("30bfcf58-c344-11e9-9f8a-1d7ced3daa62", uuid.toString());

        uuid = GTTUtils.UUIDUtils.from32ToUUID("30bfcf");
        assertNull(uuid);

        uuid = GTTUtils.UUIDUtils.from32ToUUID(null);
        assertNull(uuid);
    }

    @Test
    public void fromUUIDTo32() {
        String uuid32Str = GTTUtils.UUIDUtils.fromUUIDTo32(UUID.fromString("30bfcf58-c344-11e9-9f8a-1d7ced3daa62"));
        assertEquals("30bfcf58c34411e99f8a1d7ced3daa62", uuid32Str);
    }

    @Test
    public void generateNameBasedUUID() {
        UUID haha = GTTUtils.UUIDUtils.generateNameBasedUUID("haha");
        assertNotNull(haha.toString());
    }

    @Test
    public void generateTimeBasedUUID() {
        UUID timeHaha = GTTUtils.UUIDUtils.generateTimeBasedUUID();
        assertNotNull(timeHaha);
    }
}