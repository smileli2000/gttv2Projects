package com.sap.gtt.v2.core.management.tracking;

import com.sap.gtt.v2.core.dao.tracking.DefaultEventDao;
import com.sap.gtt.v2.core.dao.tracking.DefaultPlannedEventDao;
import com.sap.gtt.v2.core.dao.tracking.DefaultReferenceDao;
import com.sap.gtt.v2.core.domain.metadata.CurrentMetadataEntity;
import com.sap.gtt.v2.core.domain.trackedprocess.*;
import com.sap.gtt.v2.core.entity.trackedprocess.Event;
import com.sap.gtt.v2.core.entity.trackedprocess.PlannedEvent;
import com.sap.gtt.v2.core.entity.trackedprocess.Reference;
import com.sap.gtt.v2.core.management.metadata.DefaultMetadataManagement;
import com.sap.gtt.v2.core.runtime.model.IPropertyValue;
import com.sap.gtt.v2.core.runtime.model.UUIDValue;
import com.sap.gtt.v2.exception.MessageValidationException;
import com.sap.gtt.v2.log.TenantAwareLogService;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import java.time.Instant;
import java.util.*;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.*;

@RunWith(PowerMockRunner.class)
@PrepareForTest({DefaultEventDao.class, DefaultReferenceDao.class, DefaultMetadataManagement.class, DefaultPlannedEventDao.class})
public class DefaultEventManagementTest {

    @Mock
    private DefaultEventDao defaultEventDao;
    @Mock
    private DefaultReferenceDao defaultReferenceDao;
    @Mock
    private DefaultMetadataManagement defaultMetadataManagement;
    @Mock
    private DefaultPlannedEventDao defaultPlannedEventDao;
    @Mock
    private TenantAwareLogService logService;
    @InjectMocks
    private DefaultEventManagement eventManagement = new DefaultEventManagement();

    @Before
    public void setup() {
        PowerMockito.mockStatic(DefaultEventDao.class, DefaultReferenceDao.class, DefaultMetadataManagement.class, DefaultPlannedEventDao.class);
        PowerMockito.when(DefaultEventDao.getInstance()).thenReturn(defaultEventDao);
        PowerMockito.when(DefaultReferenceDao.getInstance()).thenReturn(defaultReferenceDao);
        PowerMockito.when(DefaultMetadataManagement.getInstance()).thenReturn(defaultMetadataManagement);
        PowerMockito.when(DefaultPlannedEventDao.getInstance()).thenReturn(defaultPlannedEventDao);
    }

    @Test
    public void testPostOneEvent() {
        Event event = new Event();
        event.setValue(Event.ID, "123");
        List<IPropertyValue> plannedEvents = new ArrayList<>();
        PlannedEvent plannedEvent = new PlannedEvent();
        plannedEvents.add(plannedEvent);
        event.setValue(Event.PLANNED_EVENTS, plannedEvents);
        List<IPropertyValue> references = new ArrayList<>();
        Reference reference = new Reference();
        references.add(reference);
        event.setValue(Event.REFERENCES, references);
        eventManagement.post(event);
        verify(defaultEventDao, times(1)).insert(Mockito.any(Event.class));
        verify(defaultPlannedEventDao, times(1)).insert(Mockito.anyList());
        verify(defaultReferenceDao, times(1)).insert(Mockito.anyList());
    }

    @Test
    public void testPostOneEventWithoutPlannedEvents() {
        Event event = new Event();
        event.setValue(Event.ID, "123");
        List<IPropertyValue> references = new ArrayList<>();
        Reference reference = new Reference();
        references.add(reference);
        event.setValue(Event.REFERENCES, references);
        eventManagement.post(event);
        verify(defaultEventDao, times(1)).insert(Mockito.any(Event.class));
        verify(defaultPlannedEventDao, times(0)).insert(Mockito.anyList());
        verify(defaultReferenceDao, times(1)).insert(Mockito.anyList());
    }

    @Test
    public void testPostOneEventWithoutReferences() {
        Event event = new Event();
        event.setValue(Event.ID, "123");
        List<IPropertyValue> plannedEvents = new ArrayList<>();
        PlannedEvent plannedEvent = new PlannedEvent();
        plannedEvents.add(plannedEvent);
        event.setValue(Event.PLANNED_EVENTS, plannedEvents);
        eventManagement.post(event);
        verify(defaultEventDao, times(1)).insert(Mockito.any(Event.class));
        verify(defaultPlannedEventDao, times(1)).insert(Mockito.anyList());
        verify(defaultReferenceDao, times(0)).insert(Mockito.anyList());
    }

    @Test
    public void testPostEvents() {
        List<Event> events = new ArrayList<>();
        Event event = new Event();
        event.setValue(Event.ID, "123");
        List<IPropertyValue> plannedEvents = new ArrayList<>();
        PlannedEvent plannedEvent = new PlannedEvent();
        plannedEvents.add(plannedEvent);
        event.setValue(Event.PLANNED_EVENTS, plannedEvents);
        List<IPropertyValue> references = new ArrayList<>();
        Reference reference = new Reference();
        references.add(reference);
        event.setValue(Event.REFERENCES, references);
        events.add(event);
        eventManagement.post(events);
        verify(defaultEventDao, times(1)).insert(Mockito.anyList());
        verify(defaultPlannedEventDao, times(1)).insert(Mockito.anyList());
        verify(defaultReferenceDao, times(1)).insert(Mockito.anyList());
    }

    @Test
    public void testPostEventsWithoutPlannedEvents() {
        List<Event> events = new ArrayList<>();
        Event event = new Event();
        event.setValue(Event.ID, "123");
        List<IPropertyValue> references = new ArrayList<>();
        Reference reference = new Reference();
        references.add(reference);
        event.setValue(Event.REFERENCES, references);
        events.add(event);
        eventManagement.post(events);
        verify(defaultEventDao, times(1)).insert(Mockito.anyList());
        verify(defaultPlannedEventDao, times(0)).insert(Mockito.anyList());
        verify(defaultReferenceDao, times(1)).insert(Mockito.anyList());
    }

    @Test
    public void testPostEventsWithoutReferences() {
        List<Event> events = new ArrayList<>();
        Event event = new Event();
        event.setValue(Event.ID, "123");
        List<IPropertyValue> plannedEvents = new ArrayList<>();
        PlannedEvent plannedEvent = new PlannedEvent();
        plannedEvents.add(plannedEvent);
        event.setValue(Event.PLANNED_EVENTS, plannedEvents);
        events.add(event);
        eventManagement.post(events);
        verify(defaultEventDao, times(1)).insert(Mockito.anyList());
        verify(defaultPlannedEventDao, times(1)).insert(Mockito.anyList());
        verify(defaultReferenceDao, times(0)).insert(Mockito.anyList());
    }

    @Test
    public void testGetCorrelatedEventsIncludeEventTypes() {
        UUIDValue tpId = UUIDValue.valueOf(UUID.randomUUID());
        List<String> eventTypes = Arrays.asList("event1", "event2");
        List<EventWrapper> eventWrappers = new ArrayList<>();

        PlannedEvent plannedEvent1 = new PlannedEvent();
        UUID plannedEventIdOfEvent1 = UUID.randomUUID();
        plannedEvent1.setId(plannedEventIdOfEvent1);
        Event event1 = new Event();
        event1.setModelNamespace("namespace");
        event1.setEventType("event1");
        event1.setActualBusinessTimestamp(Instant.now());
        EventWrapper eventWrapper1 = new EventWrapper(plannedEventIdOfEvent1, CorrelationType.REPORTED.name(), event1);
        eventWrappers.add(eventWrapper1);

        Event event2 = new Event();
        event2.setModelNamespace("namespace");
        event2.setEventType("event1");
        event2.setActualBusinessTimestamp(Instant.now());
        EventWrapper eventWrapper2 = new EventWrapper(plannedEventIdOfEvent1, CorrelationType.UNPLANNED_DELAYED.name(), event2);
        eventWrappers.add(eventWrapper2);

        PlannedEvent plannedEvent2 = new PlannedEvent();
        UUID plannedEventIdOfEvent2 = UUID.randomUUID();
        plannedEvent2.setId(plannedEventIdOfEvent2);
        Event event3 = new Event();
        event3.setModelNamespace("namespace");
        event3.setEventType("event2");
        event3.setActualBusinessTimestamp(Instant.now());
        EventWrapper eventWrapper3 = new EventWrapper(plannedEventIdOfEvent2, CorrelationType.UNPLANNED_OVERDUE.name(), event3);
        eventWrappers.add(eventWrapper3);
        Event event4 = new Event();
        event4.setModelNamespace("namespace");
        event4.setEventType("event3");
        event4.setActualBusinessTimestamp(Instant.now());
        EventWrapper eventWrapper4 = new EventWrapper(null, CorrelationType.UNPLANNED_PROCESS_CREATION_UPDATE.name(), event4);
        eventWrappers.add(eventWrapper4);

        given(defaultEventDao.getActualEventsForCurrentTPIncludeEventTypes(Mockito.any(), Mockito.anyList())).willReturn(eventWrappers);
        given(defaultPlannedEventDao.findOne(Mockito.any(), eq(plannedEventIdOfEvent1))).willReturn(plannedEvent1);
        given(defaultPlannedEventDao.findOne(Mockito.any(), eq(plannedEventIdOfEvent2))).willReturn(plannedEvent2);
        CorrelatedEvent correlatedEvent = eventManagement.getCorrelatedEventsIncludeEventTypes(tpId, eventTypes);
        List<CorrelatedEventInner> unplannedEvents = correlatedEvent.getUnmatched();
        assertThat(unplannedEvents.size()).isEqualTo(1);

        List<MatchedCorrelatedEvent> plannedEvents = correlatedEvent.getPlannedEvents();
        assertThat(plannedEvents.size()).isEqualTo(2);
        MatchedCorrelatedEvent correlatedEvent1 = plannedEvents.get(0);
        MatchedCorrelatedEvent correlatedEvent2 = plannedEvents.get(1);
        if (correlatedEvent1.getPlannedEvent().getId().equals(plannedEventIdOfEvent1)) {
            List<CorrelatedEventInner> actualEvents = correlatedEvent1.getActualEvents();
            assertThat(actualEvents.size()).isEqualTo(2);
            assertThat(actualEvents.get(0).getActualBusinessTimestamp().compareTo(actualEvents.get(1).getActualBusinessTimestamp())).isLessThanOrEqualTo(0);
            assertThat(correlatedEvent2.getPlannedEvent().getId()).isEqualTo(plannedEventIdOfEvent2);
            assertThat(correlatedEvent2.getActualEvents().size()).isEqualTo(1);
        } else {
            assertThat(correlatedEvent2.getPlannedEvent().getId()).isEqualTo(plannedEventIdOfEvent1);
            List<CorrelatedEventInner> actualEvents = correlatedEvent2.getActualEvents();
            assertThat(actualEvents.size()).isEqualTo(2);
            assertThat(actualEvents.get(0).getActualBusinessTimestamp().compareTo(actualEvents.get(1).getActualBusinessTimestamp())).isLessThanOrEqualTo(0);
            assertThat(correlatedEvent1.getPlannedEvent().getId()).isEqualTo(plannedEventIdOfEvent2);
            assertThat(correlatedEvent1.getActualEvents().size()).isEqualTo(1);
        }
    }

    @Test
    public void testGetCorrelatedEventsIncludeEventTypesWhenEventTypesIsNull() {
        UUIDValue tpId = UUIDValue.valueOf(UUID.randomUUID());
        assertThat(eventManagement.getCorrelatedEventsIncludeEventTypes(tpId, null)).isEqualTo(null);
    }

    @Test
    public void testGetCorrelatedEventsIncludeEventTypesWhenEventTypesIsEmpty() {
        UUIDValue tpId = UUIDValue.valueOf(UUID.randomUUID());
        assertThat(eventManagement.getCorrelatedEventsIncludeEventTypes(tpId, Collections.EMPTY_LIST)).isEqualTo(null);
    }

    @Test
    public void testGetCorrelatedEventsExcludeEventTypes() {
        UUIDValue tpId = UUIDValue.valueOf(UUID.randomUUID());
        List<String> eventTypes = Arrays.asList("event1", "event2");
        List<EventWrapper> eventWrappers = new ArrayList<>();
        Event event0 = new Event();
        event0.setModelNamespace("namespace");
        event0.setEventType("event2");
        event0.setActualBusinessTimestamp(Instant.now());
        EventWrapper eventWrapper0 = new EventWrapper(null, CorrelationType.UNPLANNED_PROCESS_CREATION_UPDATE.name(), event0);
        eventWrappers.add(eventWrapper0);

        PlannedEvent plannedEvent1 = new PlannedEvent();
        UUID plannedEventIdOfEvent1 = UUID.randomUUID();
        plannedEvent1.setId(plannedEventIdOfEvent1);
        Event event1 = new Event();
        event1.setModelNamespace("namespace");
        event1.setEventType("event3");
        event1.setActualBusinessTimestamp(Instant.now());
        EventWrapper eventWrapper1 = new EventWrapper(plannedEventIdOfEvent1, CorrelationType.REPORTED.name(), event1);
        eventWrappers.add(eventWrapper1);

        Event event2 = new Event();
        event2.setModelNamespace("namespace");
        event2.setEventType("event3");
        event2.setActualBusinessTimestamp(Instant.now());
        EventWrapper eventWrapper2 = new EventWrapper(plannedEventIdOfEvent1, CorrelationType.UNPLANNED_DELAYED.name(), event2);
        eventWrappers.add(eventWrapper2);

        PlannedEvent plannedEvent2 = new PlannedEvent();
        UUID plannedEventIdOfEvent2 = UUID.randomUUID();
        plannedEvent2.setId(plannedEventIdOfEvent2);
        Event event3 = new Event();
        event3.setModelNamespace("namespace");
        event3.setEventType("event4");
        event3.setActualBusinessTimestamp(Instant.now());
        EventWrapper eventWrapper3 = new EventWrapper(plannedEventIdOfEvent2, CorrelationType.UNPLANNED_OVERDUE.name(), event3);
        eventWrappers.add(eventWrapper3);

        given(defaultEventDao.getActualEventsForCurrentTPExcludeEventTypes(Mockito.any(), Mockito.anyList())).willReturn(eventWrappers);
        given(defaultPlannedEventDao.findOne(Mockito.any(), eq(plannedEventIdOfEvent1))).willReturn(plannedEvent1);
        given(defaultPlannedEventDao.findOne(Mockito.any(), eq(plannedEventIdOfEvent2))).willReturn(plannedEvent2);
        CorrelatedEvent correlatedEvent = eventManagement.getCorrelatedEventsExcludeEventTypes(tpId, eventTypes);
        List<CorrelatedEventInner> unplannedEvents = correlatedEvent.getUnmatched();
        assertThat(unplannedEvents.size()).isEqualTo(1);
        List<MatchedCorrelatedEvent> plannedEvents = correlatedEvent.getPlannedEvents();
        assertThat(plannedEvents.size()).isEqualTo(2);
        MatchedCorrelatedEvent correlatedEvent1 = plannedEvents.get(0);
        MatchedCorrelatedEvent correlatedEvent2 = plannedEvents.get(1);

        if (correlatedEvent1.getPlannedEvent().getId().equals(plannedEventIdOfEvent1)) {
            List<CorrelatedEventInner> actualEvents = correlatedEvent1.getActualEvents();
            assertThat(actualEvents.size()).isEqualTo(2);
            assertThat(actualEvents.get(0).getActualBusinessTimestamp().compareTo(actualEvents.get(1).getActualBusinessTimestamp())).isLessThanOrEqualTo(0);
            assertThat(correlatedEvent2.getPlannedEvent().getId()).isEqualTo(plannedEventIdOfEvent2);
            assertThat(correlatedEvent2.getActualEvents().size()).isEqualTo(1);
        } else {
            assertThat(correlatedEvent2.getPlannedEvent().getId()).isEqualTo(plannedEventIdOfEvent1);
            List<CorrelatedEventInner> actualEvents = correlatedEvent2.getActualEvents();
            assertThat(actualEvents.size()).isEqualTo(2);
            assertThat(actualEvents.get(0).getActualBusinessTimestamp().compareTo(actualEvents.get(1).getActualBusinessTimestamp())).isLessThanOrEqualTo(0);
            assertThat(correlatedEvent1.getPlannedEvent().getId()).isEqualTo(plannedEventIdOfEvent2);
            assertThat(correlatedEvent1.getActualEvents().size()).isEqualTo(1);
        }
    }

    @Test
    public void testGetLastCorrelatedEventIncludeEventTypes() {
        List<String> eventTypes = Arrays.asList("event1", "event2");
        Event coreEvent = new Event();
        coreEvent.setId(UUID.randomUUID());
        coreEvent.setModelNamespace("namespace");
        coreEvent.setEventType("event1");
        given(defaultEventDao.findLatestByTpIdAndEventTypeList(Mockito.any(UUID.class), Mockito.anyList())).willReturn(coreEvent);
        Event finalEvent = new Event();
        finalEvent.setId(coreEvent.getIdAsInternalValue());
        finalEvent.setModelNamespace("namespace");
        finalEvent.setEventType("event1");
        finalEvent.setValue("test", "test");
        given(defaultEventDao.findOne(Mockito.any(), eq(coreEvent.getIdAsInternalValue()))).willReturn(finalEvent);
        CurrentMetadataEntity metadata = new CurrentMetadataEntity();
        given(defaultMetadataManagement.findAllEntitiesRecursively(Mockito.anyString(), Mockito.anyString())).willReturn(metadata);
        Event event = eventManagement.getLastCorrelatedEventIncludeEventTypes(UUIDValue.valueOf(UUID.randomUUID()), "com.sap.tfo", eventTypes);
        assertThat(event.getEventType()).isEqualTo(coreEvent.getEventType());
        assertThat(event.getValueAsString("test")).isEqualTo("test");
        assertThat(event.getId()).isEqualTo(coreEvent.getId());
    }

    @Test
    public void testGetSingleEventById() {
        UUID id = UUID.randomUUID();
        Event event = mock(Event.class);
        given(defaultEventDao.findOneById(Mockito.any(UUID.class))).willReturn(event);
        assertThat(eventManagement.getSingleEventById(UUIDValue.valueOf(id))).isEqualTo(event);
    }

    @Test
    public void testGetById() {
        UUID id = UUID.randomUUID();
        Event coreEvent = new Event();
        coreEvent.setModelNamespace("namesapce");
        coreEvent.setEventType("eventType");
        given(defaultEventDao.findOneById(Mockito.any(UUID.class))).willReturn(coreEvent);
        CurrentMetadataEntity metadata = new CurrentMetadataEntity();
        given(defaultMetadataManagement.findAllEntitiesRecursively(Mockito.anyString(), Mockito.anyString())).willReturn(metadata);
        Event event = mock(Event.class);
        given(defaultEventDao.findOne(Mockito.any(CurrentMetadataEntity.class), Mockito.any(UUID.class))).willReturn(event);
        assertThat(eventManagement.get(UUIDValue.valueOf(id))).isEqualTo(event);
    }

    @Test
    public void testGet() {
        UUID id = UUID.randomUUID();
        Event event = mock(Event.class);
        given(defaultEventDao.findOne(Mockito.any(CurrentMetadataEntity.class), Mockito.any(UUID.class))).willReturn(event);
        assertThat(eventManagement.get(UUIDValue.valueOf(id), mock(CurrentMetadataEntity.class))).isEqualTo(event);
    }

    @Test
    public void testDelete() {
        UUID id = UUID.randomUUID();
        List<String> ids = new ArrayList<>();
        ids.add(id.toString());
        Event coreEvent = new Event();
        coreEvent.setId(id);
        coreEvent.setModelNamespace("namespace");
        coreEvent.setEventType("event1");
        given(defaultEventDao.findOneById(id)).willReturn(coreEvent);
        eventManagement.delete(ids);
    }

    @Test
    public void testDeleteWhenOneEventIsNotExisted() {
        UUID id = UUID.randomUUID();
        List<String> ids = new ArrayList<>();
        ids.add(id.toString());
        ids.add(UUID.randomUUID().toString());
        Event coreEvent = new Event();
        coreEvent.setId(id);
        coreEvent.setModelNamespace("namespace");
        coreEvent.setEventType("event1");
        given(defaultEventDao.findOneById(Mockito.any())).willReturn(coreEvent);
        given(defaultEventDao.findOneById(eq(id))).willReturn(null);
        try {
            eventManagement.delete(ids);
            Assert.assertTrue(false);
        } catch (MessageValidationException e) {
            Assert.assertTrue(true);
        }
    }

    @Test
    public void testDeleteWhenEventListIsEmptyOrNull() {
        List<String> ids = new ArrayList<>();
        eventManagement.delete(ids);
        eventManagement.delete(null);
    }
}
