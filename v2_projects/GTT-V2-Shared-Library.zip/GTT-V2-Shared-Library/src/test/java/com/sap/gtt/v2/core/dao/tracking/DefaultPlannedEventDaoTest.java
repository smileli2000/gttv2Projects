package com.sap.gtt.v2.core.dao.tracking;

import com.sap.gtt.v2.BaseTest;
import com.sap.gtt.v2.Dummy;
import com.sap.gtt.v2.core.dao.metadata.*;
import com.sap.gtt.v2.core.domain.metadata.CurrentMetadataEntity;
import com.sap.gtt.v2.core.domain.metadata.MetadataConstants;
import com.sap.gtt.v2.core.entity.trackedprocess.PlannedEvent;
import com.sap.gtt.v2.core.management.metadata.DefaultMetadataManagement;
import com.sap.gtt.v2.core.management.metadata.IMetadataManagement;
import org.apache.commons.lang3.time.StopWatch;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.IOException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import static org.assertj.core.api.Assertions.assertThat;


@RunWith(SpringRunner.class)
@SpringBootTest(classes = Dummy.class)
@ActiveProfiles("test")
public class DefaultPlannedEventDaoTest extends BaseTest {

    @Autowired
    private IPlannedEventDao plannedEventDao;

    @Autowired
    private IMetadataDao metadataDao;

    @Autowired
    private ISysTableDao sysTableDao;

    @Test
    public void test() throws IOException {
        plannedEventDao = DefaultPlannedEventDao.getInstance();
        DefaultMetadataDaoTest test = new DefaultMetadataDaoTest();
        test.setDefaultMetadataDao((DefaultMetadataDao) metadataDao);
        test.insertMetadataProject();

        DefaultSysTableDaoTest test1 = new DefaultSysTableDaoTest();
        test1.setDefaultSysTableDao((DefaultSysTableDao) sysTableDao);
        test1.createTables();

        String entityName = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        String namespace = "com.sap.gtt.app.mim";

        IMetadataManagement metadataManagement = DefaultMetadataManagement.getInstance();
        CurrentMetadataEntity metadata = metadataManagement.findAllEntitiesRecursively(namespace, entityName);

        final int LOOP_SIZE = 10;
        List<PlannedEvent> plannedEvents = new ArrayList<>(LOOP_SIZE);
        for (int i = 0; i < LOOP_SIZE; i++) {
            plannedEvents.add(createPlannedEvent(metadata));
        }

        StopWatch sw = new StopWatch();
        // more than 10 times slower
//        sw.start();
//        for (PlannedEvent plannedEvent : plannedEvents) {
//            plannedEventDao.insert(plannedEvent);
//        }
//        sw.stop();
//        System.out.println(sw.getTime(TimeUnit.MILLISECONDS));

        for (PlannedEvent plannedEvent : plannedEvents) {
            plannedEvent.setId(UUID.randomUUID());
        }
        sw.reset();
        sw.start();
        plannedEventDao.insert(plannedEvents);
        sw.stop();
        System.out.println("batchInsert: " + sw.getTime(TimeUnit.MILLISECONDS));

        sw.reset();
/*        sw.start();
        plannedEventDao.update(plannedEvents);
        sw.stop();
        System.out.println("update: " + sw.getTime(TimeUnit.MILLISECONDS));*/

        for (PlannedEvent plannedEvent : plannedEvents) {
            plannedEvent.setEventStatus("updated");
            plannedEvent.setValue("mode", "abc");
            plannedEventDao.update(plannedEvent);
            PlannedEvent findOne =plannedEventDao.findOne(plannedEvent.getMetadata(), plannedEvent.getId());
            assertThat(findOne.getId()).isEqualTo(plannedEvent.getId());
            assertThat(findOne.getEventStatus()).isEqualTo(plannedEvent.getEventStatus());
            assertThat(findOne.getValueAsString("mode")).isEqualTo(plannedEvent.getValueAsString("mode"));
            plannedEventDao.deleteByProcessId(plannedEvent.getProcessId(), plannedEvent.getMetadata().getCurrentEntity().getPhysicalName());
        }
    }

    private PlannedEvent createPlannedEvent(CurrentMetadataEntity metadata) {
        //
        PlannedEvent plannedEvent = new PlannedEvent();
        plannedEvent.setId(UUID.randomUUID());
        plannedEvent.setProcessId(UUID.randomUUID());
        plannedEvent.setEventStatus("DELAYED");
        //plannedEvent.setLocationId(UUID.randomUUID());
        plannedEvent.setPlannedBusinessTimestamp(Instant.now());
        plannedEvent.setPlannedTechnicalTimestamp(Instant.now());
        plannedEvent.setPlannedBusinessTimeZone("+8");
        plannedEvent.setEventType("PLANNED");
        plannedEvent.setPlannedBizTsEarliest(Instant.now());
        plannedEvent.setPlannedBizTsLatest(Instant.now());
        plannedEvent.setPlannedTechTsEarliest(Instant.now());
        plannedEvent.setPlannedTechTsLatest(Instant.now());
        plannedEvent.setNextOverdueDetection(Instant.now());
        plannedEvent.setOverdueDetectionCounter(1);
        plannedEvent.setPayloadSequence(1);

        CurrentMetadataEntity metadataPlannedEvent = new CurrentMetadataEntity();
        metadataPlannedEvent.setAllRelatedEntityMap(metadata.getAllRelatedEntityMap());
        metadataPlannedEvent.setCurrentEntityName(MetadataConstants.CoreModelEntity.PLANNED_EVENT.getFullName());
        plannedEvent.setMetadata(metadataPlannedEvent);
        return plannedEvent;
    }
}