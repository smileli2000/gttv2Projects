package com.sap.gtt.v2.core.entity.metadata;

import org.assertj.core.api.Assertions;
import org.junit.Test;

import java.time.Instant;

public class MetadataChangeHistoryTest {

    @Test
    public void test() {
        MetadataChangeHistory metadataChangeHistory =
                new MetadataChangeHistory("", Instant.now(), "", "", "","");

        MetadataChangeHistory another = new MetadataChangeHistory();
        another.setChangeTime(metadataChangeHistory.getChangeTime());
        another.setComment(metadataChangeHistory.getComment());
        another.setId(metadataChangeHistory.getId());
        another.setNamespace(metadataChangeHistory.getNamespace());
        another.setUserEmail(metadataChangeHistory.getUserEmail());
        another.setAction(metadataChangeHistory.getAction());

        System.out.println(metadataChangeHistory);
        System.out.println(another);

        Assertions.assertThat(metadataChangeHistory).isEqualTo(another);

    }
}