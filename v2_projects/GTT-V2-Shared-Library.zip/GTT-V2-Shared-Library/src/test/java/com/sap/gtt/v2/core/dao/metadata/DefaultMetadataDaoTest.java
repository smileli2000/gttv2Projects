package com.sap.gtt.v2.core.dao.metadata;

import com.sap.gtt.v2.BaseTest;
import com.sap.gtt.v2.Dummy;
import com.sap.gtt.v2.core.domain.metadata.MetadataConstants;
import com.sap.gtt.v2.core.domain.metadata.MetadataConstants.MetadataProjectStatus;
import com.sap.gtt.v2.core.domain.metadata.MetadataCriteria;
import com.sap.gtt.v2.core.entity.metadata.*;
import com.sap.gtt.v2.util.DBUtils;
import com.sap.gtt.v2.util.SpringContextUtils;
import org.apache.commons.io.IOUtils;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.IOException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import static com.sap.gtt.v2.core.domain.metadata.MetadataConstants.CoreModelEntity.TRACKED_PROCESS;
import static org.junit.Assert.*;


@RunWith(SpringRunner.class)
@SpringBootTest(classes = Dummy.class)
@ActiveProfiles("test")
public class DefaultMetadataDaoTest extends BaseTest {

    private static final String DERIVED_CSN_FILE = "derived_csn.json";
    private static final String ORIGINAL_CSN_FILE = "MIMService_csn.json";
    private static final String SWAGGER_FILE = "MIMWriteService_swagger.json";
    public static final String UTF_8 = "UTF-8";
    private static final String PDM_SCHEMA_FILE = "pdmSchema.json";

    private DefaultMetadataDao defaultMetadataDao;

    @Autowired
    JdbcTemplate jdbcTemplate;

    public void setDefaultMetadataDao(DefaultMetadataDao defaultMetadataDao) {
        this.defaultMetadataDao = defaultMetadataDao;
    }

    @Before
    public void setUp() {
        super.setUp();
        defaultMetadataDao = ((DefaultMetadataDao) SpringContextUtils.getBean(DefaultMetadataDao.BEAN_NAME));
    }

    @Test
    public void findAllMetadataProject() throws IOException {
        String id = "110";
        String namespace = "com.sap.gtt.app.mim";
        insertMetadata(id, namespace);
        List<MetadataProject> projects = defaultMetadataDao.findAllMetadataProject();
        assertTrue(projects.size() > 0);
    }

    @Test
    public void findMetadataProjectInfo() throws IOException {
        String id = "190";
        String namespace = "com.sap.gtt.app.mim1";
        insertMetadata(id, namespace);
        MetadataCriteria criteria = new MetadataCriteria();
        criteria.addNamespace(namespace);
        criteria.setStatus("ACTIVE");
        criteria.addTrackedProcessType("com.sap.gtt.app.mim.poitem.POItemModel.POItemProcess");
        criteria.addTrackedProcessType("com.sap.gtt.app.mim.poitem.POItemModel.POItemProcess1");
        criteria.setContainProjectFileInfo(true);
        List<MetadataProject> metadataProjectInfo = defaultMetadataDao.findMetadataProjectInfo(criteria);

        assertTrue(!metadataProjectInfo.isEmpty());
        assertNotNull(metadataProjectInfo.get(0).getMetadataProjectFile());

        criteria.setContainProjectFileInfo(false);
        metadataProjectInfo = defaultMetadataDao.findMetadataProjectInfo(criteria);
        assertTrue(!metadataProjectInfo.isEmpty());
        assertNull(metadataProjectInfo.get(0).getMetadataProjectFile());

        metadataProjectInfo = defaultMetadataDao.findMetadataProjectInfo(null);
        assertTrue(!metadataProjectInfo.isEmpty());
    }

    @Test
    public void insertMetadataProject() throws IOException {
        String id = "1";
        String namespace = "com.sap.gtt.app.mim";
        insertMetadata(id, namespace);
        assertTrue(true);
    }

    private void insertMetadata(String id, String namespace) throws IOException {
        List<MetadataProject> projects = defaultMetadataDao.findMetadataProjectInfoByNamespace(namespace);
        if (projects.size() > 0) {
            return;
        }
        MetadataProject metadataProject = new MetadataProject();
        metadataProject.setId(id);
        metadataProject.setNamespace(namespace);
        metadataProject.setUploadAt(Instant.now());
        metadataProject.setVersion("1.0.0");
        metadataProject.setStatus("ACTIVE");
        metadataProject.setDescription("test");
        metadataProject.setMode("Standard");
        metadataProject.setCoreModelVersion("1.0.0");
        metadataProject.setCompilerVersion("1.0.0");

        MetadataProjectFile metadataProjectFile = new MetadataProjectFile();
        metadataProject.setMetadataProjectFile(metadataProjectFile);
        metadataProjectFile.setId(metadataProject.getId());
        String csn = IOUtils.toString(getClass().getClassLoader()
                .getResourceAsStream(ORIGINAL_CSN_FILE), UTF_8);
        metadataProjectFile.setCsn(csn);
        String derivedCsn = IOUtils.toString(getClass().getClassLoader()
                .getResourceAsStream(DERIVED_CSN_FILE), UTF_8);
        metadataProjectFile.setDerivedCsn(derivedCsn);

        String swagger = IOUtils.toString(getClass().getClassLoader()
                .getResourceAsStream(SWAGGER_FILE), UTF_8);
        metadataProjectFile.setSwagger(swagger);
        defaultMetadataDao.insertMetadataProject(metadataProject);

        MetadataProcess metadataProcess = new MetadataProcess();
        metadataProcess.setId(id);
        metadataProcess.setMetadataProjectId(id);
        metadataProcess.setTrackedProcessType("com.sap.gtt.app.mim.poitem.POItemModel.POItemProcess");
        metadataProcess.setApplicationObjectType("OBP10_POITEM");
        metadataProcess.setDescription("purchase Order Item Process");

        String eventType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemEvent";
        MetadataEvent metadataEvent = new MetadataEvent();
        metadataEvent.setId(id);
        metadataEvent.setMetadataProcessId(metadataProcess.getId());
        metadataEvent.setEventType(eventType);
        metadataEvent.setDescription("test");

        MetadataEventText text = new MetadataEventText();
        text.setMetadataEventId(metadataEvent.getId());
        text.setLocale("zh_CN");
        text.setDescr("订单描述");
        metadataEvent.addMetadataEventText(text);

        metadataProcess.addMetadataEvent(metadataEvent);

        defaultMetadataDao.insertMetadataProcess(metadataProcess);
    }

    @Test
    public void testUpdateMetadataProject() throws IOException {
        String id = "110";
        String namespace = "com.sap.gtt.app.mim";
        insertMetadata(id, namespace);
        updateMetadata(id, namespace);
        assertTrue(true);
    }

    private void updateMetadata(String id, String namespace) throws IOException {
        List<MetadataProject> projects = defaultMetadataDao.findMetadataProjectInfoByNamespace(namespace);
        for (MetadataProject metadataProject : projects) {
            metadataProject.setDescription("updated");
            defaultMetadataDao.updateMetadataProject(metadataProject);
        }
    }

    @Test
    public void testUpdateMetadataProcess() throws IOException {
        String id = "33";
        String namespace = "com.sap.gtt.app.mim";
        insertMetadata(id, namespace);
        MetadataCriteria metadataCriteria = new MetadataCriteria();
        metadataCriteria.addNamespace(namespace);
        List<MetadataProcess> processList = defaultMetadataDao
                .findAllMetadataProcess(metadataCriteria);

        for (MetadataProcess metadataProcess : processList) {
            defaultMetadataDao.updateMetadataProcess(metadataProcess);
        }
        assertTrue(true);
    }

    @Test
    public void getMetadataSwaggerDerivedCsnInfo() throws IOException {
        String id = "2";
        String namespace = "com.sap.gtt.app.mim";
        insertMetadata(id, namespace);
        MetadataProjectFile swaggerCsnInfo = defaultMetadataDao.getMetadataSwaggerDerivedCsnInfo(namespace);
        assertNotNull(swaggerCsnInfo);
        assertNotNull(swaggerCsnInfo.getDerivedCsn());
        assertNotNull(swaggerCsnInfo.getSwagger());
    }

    @Test
    public void getMetadataDerivedCsn() throws IOException {
        String id = "3";
        String namespace = "com.sap.gtt.app.mim";
        insertMetadata(id, namespace);

        MetadataCriteria criteria = new MetadataCriteria();
        criteria.addNamespace(namespace);

        String derivedCsn = defaultMetadataDao.getMetadataDerivedCsn(criteria);
        assertNotNull(derivedCsn);
    }

    @Test
    public void getMetadataProjectFileFieldInfo() throws IOException {
        String id = "4";
        String namespace = "com.sap.gtt.app.mim";
        insertMetadata(id, namespace);

        List<String> namespaces = new ArrayList<>();
        namespaces.add(namespace);

        String fieldInfo = defaultMetadataDao.getMetadataProjectFileFieldInfo(namespaces, MetadataConstants.MetadataProjectFileField.DERIVED_CSN);
        assertNotNull(fieldInfo);
    }

    @Test
    public void testEqualsAndToString() throws IOException {
        String id = "110";
        String namespace = "com.sap.gtt.app.mim";

        MetadataProject metadataProject = new MetadataProject();
        metadataProject.setId(id);
        metadataProject.setNamespace(namespace);
        metadataProject.setUploadAt(Instant.now());
        metadataProject.setVersion("1.0.0");
        metadataProject.setStatus("1");
        metadataProject.setDescription("test");
        metadataProject.setMode("Standard");
        metadataProject.setCoreModelVersion("1.0.0");
        metadataProject.setCompilerVersion("1.0.0");

        MetadataProjectFile metadataProjectFile = new MetadataProjectFile();
        metadataProject.setMetadataProjectFile(metadataProjectFile);
        metadataProjectFile.setId(metadataProject.getId());
        String csn = IOUtils.toString(getClass().getClassLoader()
                .getResourceAsStream(ORIGINAL_CSN_FILE), UTF_8);
        metadataProjectFile.setCsn(csn);
        String derivedCsn = IOUtils.toString(getClass().getClassLoader()
                .getResourceAsStream(DERIVED_CSN_FILE), UTF_8);
        metadataProjectFile.setDerivedCsn(derivedCsn);

        String swagger = IOUtils.toString(getClass().getClassLoader()
                .getResourceAsStream(SWAGGER_FILE), UTF_8);
        metadataProjectFile.setSwagger(swagger);
        metadataProjectFile.setCds("");

        MetadataProcess metadataProcess = new MetadataProcess();
        metadataProcess.setId(id);
        metadataProcess.setMetadataProjectId(id);
        metadataProcess.setTrackedProcessType("com.sap.gtt.app.mim.poitem.POItemModel.POItemProcess");
        metadataProcess.setApplicationObjectType("OBP10_POITEM");
        metadataProcess.setDescription("Purchase Order Item Process");

        MetadataProjectFile metadataProjectFile1 = new MetadataProjectFile();
        metadataProjectFile1.setId(metadataProject.getId());
        metadataProjectFile1.setCsn("");
        metadataProjectFile1.setDerivedCsn("");
        metadataProjectFile1.setSwagger("");

        Assertions.assertThat(metadataProjectFile).isNotEqualTo(metadataProjectFile1);
        Assertions.assertThat(metadataProjectFile.toString()).contains("edmx=");

        MetadataProcess metadataProcess1 = new MetadataProcess();
        metadataProcess1.setId(id);
        metadataProcess1.setMetadataProjectId(id);
        metadataProcess1.setTrackedProcessType("com.sap.gtt.app.mim.poitem.POItemModel.POItemProcess");
        metadataProcess1.setApplicationObjectType("OBP10_POITEM-changed");
        Assertions.assertThat(metadataProcess).isNotEqualTo(metadataProcess1);
        Assertions.assertThat(metadataProcess.toString()).contains("metadataProjectId=");

        MetadataProject metadataProject1 = new MetadataProject();
        metadataProject1.setId(id);
        metadataProject1.setNamespace(namespace);
        metadataProject1.setUploadAt(Instant.now());
        metadataProject1.setVersion("1.0.0");
        metadataProject1.setStatus("1");
        metadataProject1.setDescription("test");
        metadataProject1.setMode("Standard");
        metadataProject1.setCoreModelVersion("1.0.0");
        metadataProject1.setCompilerVersion("1.0.0-changed");
        Assertions.assertThat(metadataProject).isNotEqualTo(metadataProject1);
        Assertions.assertThat(metadataProject.toString()).contains("namespace=");
    }

    @Test
    public void deleteMetadata() throws IOException {
        String id = "5";
        String namespace = "com.sap.gtt.app.mim1";
        insertMetadata(id, namespace);

        defaultMetadataDao.deleteMetadata(namespace);
        assertTrue(true);
    }

    @Test
    public void insertMetadataChangeHistory() {
        UUID uuid = UUID.randomUUID();
        MetadataChangeHistory metadataChangeHistory = new MetadataChangeHistory(uuid.toString(), new Date().toInstant(), "", "namespace", "", "Deploy");
        defaultMetadataDao.insertMetadataChangeHistory(metadataChangeHistory);
        assertTrue(true);
    }

    @Test
    public void getMetadataChangeHistory() {
        Instant time = new Date().toInstant();
        UUID uuid = UUID.randomUUID();
        MetadataChangeHistory metadataChangeHistory = new MetadataChangeHistory(uuid.toString(), time, "", "namespace2", "", "Deploy");
        defaultMetadataDao.insertMetadataChangeHistory(metadataChangeHistory);
        List<MetadataChangeHistory> res = defaultMetadataDao.findMetadataChangeHistoryByNamespace("namespace2");
        assertEquals("namespace2", res.get(0).getNamespace());
    }

    @Test
    public void testSelectAllMetadataDraftModelsInfo() {
        defaultMetadataDao.selectAllMetadataDraftModelsInfo(false);
        assertTrue(true);

        defaultMetadataDao.selectAllMetadataDraftModelsInfo(true);
        assertTrue(true);
    }

    @Test
    public void testInsertMetadataDraftModel() {
        UUID uuid = UUID.randomUUID();
        MetadataDraftModel metadataDraftModel = new MetadataDraftModel(uuid.toString(), "", "", "", "", "", "", Instant.now());
        defaultMetadataDao.insertMetadataDraftModel(metadataDraftModel);
        assertTrue(true);
    }

    @Test
    public void testUpdateAllMetadataDraftModelInfo() {
        UUID uuid = UUID.randomUUID();
        MetadataDraftModel metadataDraftModel = new MetadataDraftModel(uuid.toString(), "ns", "", "", "", "", "", Instant.now());
        defaultMetadataDao.updateMetadataDraftModelInfo(metadataDraftModel);
        assertTrue(true);
    }

    @Test
    public void testDeleteMetadataDraftModel() {
        defaultMetadataDao.deleteMetadataDraftModel("ns");
        assertTrue(true);
    }

    @Test
    public void testGetMetadataDraftModelInfoByNamespace() {
        defaultMetadataDao.getMetadataDraftModelInfoByNamespace("ns");
        assertTrue(true);
    }

    @Test
    public void testGetMetadataDraftModelByNamespace() {
        defaultMetadataDao.getMetadataDraftModelByNamespace("ns");
        assertTrue(true);
    }

    @Test
    public void findAllMetadataProcess() throws IOException {
        String id = "15";
        String namespace = "com.sap.gtt.app.mim";
        insertMetadata(id, namespace);
        MetadataCriteria metadataCriteria = new MetadataCriteria();
        metadataCriteria.addNamespace(namespace);
        metadataCriteria.addNamespace(namespace + "1");
        List<MetadataProcess> processList = defaultMetadataDao
                .findAllMetadataProcess(metadataCriteria);
        assertTrue(processList.size() == 1);

        metadataCriteria = new MetadataCriteria();
        processList = defaultMetadataDao
                .findAllMetadataProcess(metadataCriteria);
        assertTrue(processList.size() == 1);
        defaultMetadataDao.deleteMetadata(namespace);

        processList = defaultMetadataDao
                .findAllMetadataProcess(metadataCriteria);
        assertTrue(processList.isEmpty());

    }


    @Test
    public void testUpdateMetadataProjectStatus() {
        String namespace = "com.sap.gtt.app.mim";
        MetadataProject metadataProject = new MetadataProject();
        metadataProject.setNamespace(namespace);
        metadataProject.setStatus(MetadataProjectStatus.ACTIVE.name());
        defaultMetadataDao.updateMetadataProjectStatus(metadataProject);
        assertTrue(true);
    }

    @Test
    public void testCountTrackedProcessByType() throws IOException {
        String trackedProcessType = "com.sap.gtt.app.mim.poitem.POItemModel.POItemProcess";
        insertTrackedProcessData("1", trackedProcessType);
        insertTrackedProcessData("2", trackedProcessType);
        long count = defaultMetadataDao.countTrackedProcessByType(trackedProcessType);
        deleteTrackedProcessData("1");
        deleteTrackedProcessData("2");
        assertEquals(2, count);
    }

    private void insertTrackedProcessData(String tpId, String tpType) {
        String sql = new StringBuilder()
                .append("INSERT INTO ").append(DBUtils.toTableName(TRACKED_PROCESS.getFullName()))
                .append("(ID, TRACKEDPROCESSTYPE) VALUES(?,?)").toString();
        jdbcTemplate.update(sql, tpId, tpType);
    }

    private void deleteTrackedProcessData(String tpId) {
        String sql = new StringBuilder()
                .append("DELETE FROM ").append(DBUtils.toTableName(TRACKED_PROCESS.getFullName()))
                .append(" WHERE ID=?").toString();
        jdbcTemplate.update(sql, tpId);
    }
}