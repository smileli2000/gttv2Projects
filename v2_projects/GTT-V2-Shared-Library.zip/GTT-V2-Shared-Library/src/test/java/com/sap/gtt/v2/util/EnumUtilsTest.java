package com.sap.gtt.v2.util;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

public class EnumUtilsTest {

    private enum TestEnum {
        T1("t1"), T2("t2");

        private String value;

        TestEnum(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }
    }

    private enum TestEnum2 {
        T1, T2;
    }

    @Test
    public void getEnumTypeWithInvalidInput() {
        EnumUtils enumType = EnumUtils.getEnumType(EnumUtils.class, "T1");
        assertNull(enumType);

        TestEnum enumType1 = EnumUtils.getEnumType(TestEnum.class, "T3");
        assertNull(enumType1);
    }

    @Test
    public void getEnumType() {
        TestEnum enumType = EnumUtils.getEnumType(TestEnum.class, "T1");
        assertEquals(TestEnum.T1, enumType);
    }

    @Test
    public void getEnumTypeByValueWithInvalidInput() {
        EnumUtils enumType = EnumUtils.getEnumTypeByValue(EnumUtils.class, null);
        assertNull(enumType);

        TestEnum t2 = EnumUtils.getEnumTypeByValue(TestEnum.class, "t4");
        assertNull(t2);

        TestEnum2 t3 = EnumUtils.getEnumTypeByValue(TestEnum2.class, "t1");
        assertNull(t3);
    }

    @Test
    public void getEnumTypeByValue() {
        TestEnum t2 = EnumUtils.getEnumTypeByValue(TestEnum.class, "t2");
        assertEquals(TestEnum.T2, t2);
    }
}