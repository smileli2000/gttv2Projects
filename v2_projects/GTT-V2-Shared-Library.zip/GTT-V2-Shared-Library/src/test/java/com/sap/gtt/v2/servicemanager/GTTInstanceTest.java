package com.sap.gtt.v2.servicemanager;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.sap.gtt.v2.BaseTest;
import com.sap.gtt.v2.Dummy;
import com.sap.gtt.v2.configuration.local.LocalMockedCurrentAccessContext;
import com.sap.gtt.v2.servicemanager.GTTInstance.HanaStorageConnectionInfoForSharedPlan;
import com.sap.gtt.v2.servicemanager.GTTInstance.ManagedHanaStorageConnectionInfo;
import com.sap.gtt.v2.servicemanager.GTTInstance.StorageTypeNotSupportException;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = Dummy.class)
@ActiveProfiles("test")
public class GTTInstanceTest extends BaseTest{

	private static final String DATABASE_INSTANCE_NAME_SHARED_PLAN = "lbn-gtt-core-storage-h2";
	private static final String DATABASE_PHYSICAL_ID = "8495da7f-88a1-4fc7-afbd-9544d0fb26c9";
	
	
	private GTTInstance gttInstanceStandaloneForApp;
	private GTTInstance gttInstanceStandaloneForCloneInstance;
	
    private GTTInstance gttInstanceShared;
    
    @Override
    public void setUp(){
    	super.setUp();

    	gttInstanceShared = new GTTInstance();
    	gttInstanceShared.setInstanceName(LocalMockedCurrentAccessContext.CLONE_SERVICE_INSTANCE_NAME_SHARED_PLAN);
    	gttInstanceShared.setStorageType(GTTInstance.STORAGE_TYPE_HANA);
    	gttInstanceShared.fillStorageConnectionInfoForSharedPlan(DATABASE_INSTANCE_NAME_SHARED_PLAN);
    
    	gttInstanceStandaloneForApp = new GTTInstance();
    	gttInstanceStandaloneForApp.setInstanceName(LocalMockedCurrentAccessContext.TENANT_SUBDOMAIN);
    	gttInstanceStandaloneForApp.setStorageType(GTTInstance.STORAGE_TYPE_MANAGED_HANA);
    	gttInstanceStandaloneForApp.fillStorageConnectionInfoForStandalonePlan(LocalMockedCurrentAccessContext.TENANT_SUBACCOUNT_ID,
    			LocalMockedCurrentAccessContext.TENANT_SUBDOMAIN, null, DATABASE_PHYSICAL_ID);
    
    	gttInstanceStandaloneForCloneInstance = new GTTInstance();
    	gttInstanceStandaloneForCloneInstance.setInstanceName(LocalMockedCurrentAccessContext.TENANT_SUBDOMAIN);
    	gttInstanceStandaloneForCloneInstance.setStorageType(GTTInstance.STORAGE_TYPE_MANAGED_HANA);
    	gttInstanceStandaloneForCloneInstance.fillStorageConnectionInfoForStandalonePlan(LocalMockedCurrentAccessContext.TENANT_SUBACCOUNT_ID,
    			LocalMockedCurrentAccessContext.TENANT_SUBDOMAIN, LocalMockedCurrentAccessContext.CLONE_SERVICE_INSTANCE_ID_STANDALONE_PLAN, DATABASE_PHYSICAL_ID);
    
    }

   @Test
   public void testFillStorageConnectionInfoForSharedPlanOK(){
	   gttInstanceShared.fillStorageConnectionInfoForSharedPlan(DATABASE_INSTANCE_NAME_SHARED_PLAN);
	   assertEquals("{\"databaseServiceInstanceName\":\"lbn-gtt-core-storage-h2\",\"plan\":\"shared\"}",gttInstanceShared.getStorageConnectionInfo());
   }
   
   @Test(expected = StorageTypeNotSupportException.class)
   public void testFillStorageConnectionInfoForSharedPlanFailed1(){
	   gttInstanceShared.setStorageType(GTTInstance.STORAGE_TYPE_MANAGED_HANA);
	   gttInstanceShared.fillStorageConnectionInfoForSharedPlan(DATABASE_INSTANCE_NAME_SHARED_PLAN);
   }
   
   @Test
   public void testFillStorageConnectionInfoForStandalonePlanOK1(){
	   gttInstanceStandaloneForApp.fillStorageConnectionInfoForStandalonePlan(LocalMockedCurrentAccessContext.TENANT_SUBACCOUNT_ID,
   			LocalMockedCurrentAccessContext.TENANT_SUBDOMAIN, null, DATABASE_PHYSICAL_ID);
	   assertEquals("{\"databaseId\":\"8495da7f-88a1-4fc7-afbd-9544d0fb26c9\",\"subaccountId\":\"ba77fcf8-6aae-48d5-a787-32e768e303e8\",\"subdomain\":\"lbn-platform\",\"databaseServiceInstanceName\":\"lbn-platform$ba77fcf8-6aae-48d5-a787-32e768e303e8\",\"plan\":\"standalone\"}",gttInstanceStandaloneForApp.getStorageConnectionInfo());
   }
   
   @Test
   public void testFillStorageConnectionInfoForStandalonePlanOK2(){
	   gttInstanceStandaloneForCloneInstance.fillStorageConnectionInfoForStandalonePlan(LocalMockedCurrentAccessContext.TENANT_SUBACCOUNT_ID,
   			LocalMockedCurrentAccessContext.TENANT_SUBDOMAIN, LocalMockedCurrentAccessContext.CLONE_SERVICE_INSTANCE_ID_STANDALONE_PLAN, DATABASE_PHYSICAL_ID);
	   assertEquals("{\"databaseId\":\"8495da7f-88a1-4fc7-afbd-9544d0fb26c9\",\"subaccountId\":\"ba77fcf8-6aae-48d5-a787-32e768e303e8\",\"subdomain\":\"lbn-platform\",\"cloneInstanceId\":\"bc2510b5-b246-43b9-90a2-a6d380de5e32\",\"databaseServiceInstanceName\":\"lbn-platform@bc2510b5-b246-43b9-90a2-a6d380de5e32\",\"plan\":\"standalone\"}",gttInstanceStandaloneForCloneInstance.getStorageConnectionInfo());
   }
   
   @Test
   public void testFillStorageConnectionInfoForStandalonePlanOK3(){
	   gttInstanceStandaloneForCloneInstance.setStorageType(GTTInstance.STORAGE_TYPE_HANA);
	   gttInstanceStandaloneForCloneInstance.fillStorageConnectionInfoForStandalonePlan(LocalMockedCurrentAccessContext.TENANT_SUBACCOUNT_ID,
   			LocalMockedCurrentAccessContext.TENANT_SUBDOMAIN, LocalMockedCurrentAccessContext.CLONE_SERVICE_INSTANCE_ID_STANDALONE_PLAN, DATABASE_PHYSICAL_ID);
	   assertEquals("{\"databaseId\":\"8495da7f-88a1-4fc7-afbd-9544d0fb26c9\",\"subaccountId\":\"ba77fcf8-6aae-48d5-a787-32e768e303e8\",\"subdomain\":\"lbn-platform\",\"cloneInstanceId\":\"bc2510b5-b246-43b9-90a2-a6d380de5e32\",\"databaseServiceInstanceName\":\"lbn-platform@bc2510b5-b246-43b9-90a2-a6d380de5e32\",\"plan\":\"standalone\"}",gttInstanceStandaloneForCloneInstance.getStorageConnectionInfo());
   }
   
   @Test(expected = StorageTypeNotSupportException.class)
   public void testFillStorageConnectionInfoForStandalonePlanFailed1(){
	   gttInstanceStandaloneForCloneInstance.setStorageType("NOT_EXISTS");
	   gttInstanceStandaloneForCloneInstance.fillStorageConnectionInfoForStandalonePlan(LocalMockedCurrentAccessContext.TENANT_SUBACCOUNT_ID,
	   			LocalMockedCurrentAccessContext.TENANT_SUBDOMAIN, LocalMockedCurrentAccessContext.CLONE_SERVICE_INSTANCE_ID_STANDALONE_PLAN, DATABASE_PHYSICAL_ID);
		  
   }
   
   @Test 
   public void testParseStorageConnectionInfoSharedPlanOK(){
	   HanaStorageConnectionInfoForSharedPlan storageInfo = (HanaStorageConnectionInfoForSharedPlan)gttInstanceShared.parseStorageConnectionInfo();
	   assertEquals(GTTInstanceMapping.PLAN_SHARED, storageInfo.getPlan());
	   assertEquals(DATABASE_INSTANCE_NAME_SHARED_PLAN, storageInfo.getDatabaseServiceInstanceName());
	   assertEquals(DATABASE_INSTANCE_NAME_SHARED_PLAN, storageInfo.getStorage().getInstanceName());
	   
   }
   
   @Test 
   public void testParseStorageConnectionInfoStandaloneOK(){
	   ManagedHanaStorageConnectionInfo storageInfo = (ManagedHanaStorageConnectionInfo)gttInstanceStandaloneForApp.parseStorageConnectionInfo();
	   assertEquals(GTTInstanceMapping.PLAN_STANDALONE, storageInfo.getPlan());
	   assertEquals(LocalMockedCurrentAccessContext.TENANT_SUBDOMAIN + "$" +LocalMockedCurrentAccessContext.TENANT_SUBACCOUNT_ID, storageInfo.getDatabaseServiceInstanceName());
   }
}
