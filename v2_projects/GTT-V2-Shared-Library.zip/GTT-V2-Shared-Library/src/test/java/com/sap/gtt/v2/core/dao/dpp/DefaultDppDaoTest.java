package com.sap.gtt.v2.core.dao.dpp;

import com.sap.gtt.v2.BaseTest;
import com.sap.gtt.v2.Dummy;
import com.sap.gtt.v2.core.domain.dpp.DppEntity;
import com.sap.gtt.v2.core.domain.dpp.DppProperty;
import com.sap.gtt.v2.util.SpringContextUtils;
import org.apache.commons.io.IOUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;


@RunWith(SpringRunner.class)
@SpringBootTest(classes = Dummy.class)
@ActiveProfiles("test")
public class DefaultDppDaoTest extends BaseTest {
    private static final String PDM_SCHEMA_FILE = "pdmSchema.json";
    private DefaultDppDao defaultDppDao;
    public void setDefaultDppDao(DefaultDppDao defaultDppDao) {
        this.defaultDppDao = defaultDppDao;
    }

    @Before
    public void setUp() {
        super.setUp();
        defaultDppDao = ((DefaultDppDao) SpringContextUtils.getBean(DefaultDppDao.BEAN_NAME));
    }

    @Test
    public void testGetPdmSchema() {
        defaultDppDao.getPdmSchema();
        assertTrue(true);
    }

    @Test
    public void testInsertPdmSchema() {
        InputStream inputStream = getClass().getClassLoader().getResourceAsStream(PDM_SCHEMA_FILE);
        try {
            String pdmStr = IOUtils.toString(inputStream, Charset.defaultCharset());
            defaultDppDao.insertPdmSchema(pdmStr);
            String pdmSchema = defaultDppDao.getPdmSchema();
            assertNotNull(pdmSchema);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void testUpdatePdmSchema() {
        InputStream inputStream = getClass().getClassLoader().getResourceAsStream(PDM_SCHEMA_FILE);
        try {
            String pdmStr = IOUtils.toString(inputStream, Charset.defaultCharset());
            defaultDppDao.updatePdmSchema(pdmStr);
            assertTrue(true);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void testIsDataSubjectIdExistsInDB() {
        String dataSubjectIdValue = "TEST@SAP.COM";
        List<DppEntity> dppEntities = new ArrayList();
        DppEntity dppEntity = new DppEntity();
        dppEntity.setPhsicalName("FREIGHTORDERPROCESS");
        dppEntities.add(dppEntity);
        DppProperty dataSubjectProperty = new DppProperty();
        dataSubjectProperty.setPhysicalName("EMAIL");
        dppEntity.setDataSubjectIdProperty(dataSubjectProperty);

        DppEntity dppEntity2 = new DppEntity();
        dppEntity2.setPhsicalName("FREIGHTORDEREVENT");
        dppEntities.add(dppEntity2);
        DppProperty dataSubjectProperty2 = new DppProperty();
        dataSubjectProperty2.setPhysicalName("EMAIL");
        dppEntity2.setDataSubjectIdProperty(dataSubjectProperty2);

        defaultDppDao.isDataSubjectIdExistsInDB(dataSubjectIdValue, dppEntities);
        assertTrue(true);
    }

    @Test
    public void testGetPdmDataInfo() {
        String dataSubjectIdValue = "TEST@SAP.COM";
        DppEntity dppEntity = new DppEntity();
        dppEntity.setPhsicalName("FREIGHTORDERPROCESS");
        dppEntity.setEvent(false);
        //dataSubjectId:
        DppProperty dataSubjectProperty = new DppProperty();
        dataSubjectProperty.setName("EMAIL");
        dataSubjectProperty.setPhysicalName("EMAIL");
        dppEntity.setDataSubjectIdProperty(dataSubjectProperty);
        //key:
        List<DppProperty> keyProperties = new ArrayList();
        DppProperty keyProperty = new DppProperty();
        keyProperty.setName("ID");
        keyProperty.setPhysicalName("ID");
        keyProperties.add(keyProperty);
        dppEntity.setKeyProperties(keyProperties);
        //spi:
        List<DppProperty> spiProperties = new ArrayList();
        DppProperty spiProperty = new DppProperty();
        spiProperty.setName("CITY");
        spiProperty.setPhysicalName("CITY");
        spiProperties.add(spiProperty);
        dppEntity.setSpiProperties(spiProperties);

        DppProperty spiProperty2 = new DppProperty();
        spiProperty2.setName("CREATEDBYUSER");
        spiProperty2.setPhysicalName("CREATEDBYUSER");
        spiProperties.add(spiProperty2);
        dppEntity.setSpiProperties(spiProperties);

        DppProperty spiProperty3 = new DppProperty();
        spiProperty3.setName("UPDATEDDATE");
        spiProperty3.setPhysicalName("UPDATEDDATE");
        spiProperties.add(spiProperty3);
        dppEntity.setSpiProperties(spiProperties);

        DppProperty spiProperty4 = new DppProperty();
        spiProperty4.setName("UPDATEDDATETIME");
        spiProperty4.setPhysicalName("UPDATEDDATETIME");
        spiProperties.add(spiProperty4);
        dppEntity.setSpiProperties(spiProperties);
        //pii
        List<DppProperty> piiProperties = new ArrayList();
        DppProperty piiProperty = new DppProperty();
        piiProperty.setName("LOCATION");
        piiProperty.setPhysicalName("LOCATION");
        piiProperties.add(piiProperty);

        DppProperty piiProperty2 = new DppProperty();
        piiProperty2.setName("EMAIL");
        piiProperty2.setPhysicalName("EMAIL");
        piiProperties.add(piiProperty2);
        dppEntity.setPiiProperties(piiProperties);
        List<Map<String, Object>> pdmDataInfos = defaultDppDao.getPdmDataInfo(dataSubjectIdValue, dppEntity);
        assertTrue(pdmDataInfos.size() == 2);
    }
    
    @Test
    public void testGetPdmDataInfoOfEvent() {
        String dataSubjectIdValue = "TEST@SAP.COM";
        DppEntity dppEntity = new DppEntity();
        dppEntity.setName("FREIGHTORDEREVENT");
        dppEntity.setPhsicalName("FREIGHTORDEREVENT");
        dppEntity.setEvent(true);
        //key:
        List<DppProperty> keyProperties = new ArrayList();
        DppProperty keyProperty = new DppProperty();
        keyProperty.setName("ID");
        keyProperty.setPhysicalName("ID");
        keyProperties.add(keyProperty);
        dppEntity.setKeyProperties(keyProperties);
        //spi:
        List<DppProperty> specialProperties = new ArrayList();

        DppProperty spiProperty1 = new DppProperty();
        spiProperty1.setName("CREATEDBYUSER");
        spiProperty1.setPhysicalName("CREATEDBYUSER");
        specialProperties.add(spiProperty1);
        dppEntity.setSpecialdataSubjectIdProperties(specialProperties);

        DppProperty spiProperty2 = new DppProperty();
        spiProperty2.setName("UPDATEDBY");
        spiProperty2.setPhysicalName("UPDATEDBY");
        specialProperties.add(spiProperty2);
        dppEntity.setSpecialdataSubjectIdProperties(specialProperties);

        List<Map<String, Object>> pdmDataInfos = defaultDppDao.getPdmDataInfo(dataSubjectIdValue, dppEntity);
        assertTrue(pdmDataInfos.size() == 0);
    }
    
    @Test
    public void testGetPdmDataInfoOfCoreEvent() {
        String dataSubjectIdValue = "TEST@SAP.COM";
        DppEntity dppEntity = new DppEntity();
        dppEntity.setName("com.sap.gtt.core.CoreModel.Event");
        dppEntity.setPhsicalName("com_sap_gtt_core_CoreModel_Event");
        dppEntity.setEvent(true);
        //key:
        List<DppProperty> keyProperties = new ArrayList();
        DppProperty keyProperty = new DppProperty();
        keyProperty.setName("ID");
        keyProperty.setPhysicalName("ID");
        keyProperties.add(keyProperty);
        dppEntity.setKeyProperties(keyProperties);
        //spi:
        List<DppProperty> specialProperties = new ArrayList();

        DppProperty spiProperty1 = new DppProperty();
        spiProperty1.setName("CREATEDBYUSER");
        spiProperty1.setPhysicalName("CREATEDBYUSER");
        specialProperties.add(spiProperty1);
        dppEntity.setSpecialdataSubjectIdProperties(specialProperties);

        DppProperty spiProperty2 = new DppProperty();
        spiProperty2.setName("UPDATEDBY");
        spiProperty2.setPhysicalName("UPDATEDBY");
        specialProperties.add(spiProperty2);
        dppEntity.setSpecialdataSubjectIdProperties(specialProperties);

        List<Map<String, Object>> pdmDataInfos = defaultDppDao.getPdmDataInfo(dataSubjectIdValue, dppEntity);
        assertTrue(pdmDataInfos.size() == 0);
    }
}