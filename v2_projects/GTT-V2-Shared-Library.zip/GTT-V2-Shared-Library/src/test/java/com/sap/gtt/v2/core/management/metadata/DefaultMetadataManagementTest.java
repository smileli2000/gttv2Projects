package com.sap.gtt.v2.core.management.metadata;

import com.sap.gtt.v2.core.dao.dpp.DefaultDppDao;
import com.sap.gtt.v2.core.dao.metadata.DefaultMetadataDao;
import com.sap.gtt.v2.core.dao.metadata.DefaultSysTableDao;
import com.sap.gtt.v2.core.domain.metadata.*;
import com.sap.gtt.v2.core.domain.metadata.MetadataConstants.MetadataProjectFileField;
import com.sap.gtt.v2.core.domain.metadata.MetadataConstants.MetadataProjectStatus;
import com.sap.gtt.v2.core.entity.metadata.MetadataChangeHistory;
import com.sap.gtt.v2.core.entity.metadata.MetadataDraftModel;
import com.sap.gtt.v2.core.entity.metadata.MetadataProject;
import com.sap.gtt.v2.core.entity.metadata.MetadataProjectFile;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.test.context.ActiveProfiles;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@RunWith(PowerMockRunner.class)
@PrepareForTest({DefaultMetadataDao.class, DefaultSysTableDao.class, DefaultDppDao.class})
@ActiveProfiles("test")
public class DefaultMetadataManagementTest {

    private static final String DERIVED_CSN_FILE = "derived_csn.json";
    private static final String DERIVED_CSN_FILE_FOR_DPP = "mim_dpp_derived_csn.json";
    //private static final String DERIVED_CSN_FILE_FOR_DPP = "tstdpp.json";
    private static final String SWAGGER_FILE = "MIMWriteService_swagger.json";
    private static final String EDMX_FILE = "MIMService_edmx.xml";
    private static final String PDM_SCHEMA_FILE = "pdmSchema.json";

    @InjectMocks
    DefaultMetadataManagement defaultMetadataManagement = new DefaultMetadataManagement();
    @Mock
    DefaultMetadataDao defaultMetadataDao;
    @Mock
    DefaultDppDao defaultDppDao;
    @Mock
    DefaultSysTableDao defaultSysTableDao;

    List<MetadataDraftModel> metadataDraftModelsList;
    MetadataDraftModel metadataDraftModel;

    @Before
    public void setUp() {
        String namespace = "com.sap.gtt.app.mim";
        //String namespace = "com.sap.gtt.app.tstdpp";
        MetadataCriteria criteria = new MetadataCriteria();
        criteria.addNamespace(namespace);
        criteria.setStatus(MetadataProjectStatus.ACTIVE.name());

        PowerMockito.mockStatic(DefaultMetadataDao.class, DefaultSysTableDao.class, DefaultDppDao.class);
        PowerMockito.when(DefaultMetadataDao.getInstance()).thenReturn(defaultMetadataDao);
        PowerMockito.when(DefaultSysTableDao.getInstance()).thenReturn(defaultSysTableDao);
        PowerMockito.when(DefaultDppDao.getInstance()).thenReturn(defaultDppDao);
        try {
            given(defaultMetadataDao.getMetadataDerivedCsn(criteria)).willReturn(loadFile(DERIVED_CSN_FILE));
        } catch (IOException e) {
            e.printStackTrace();
        }

        namespace = "com.sap.gtt.app.mimivan";
        //namespace = "com.sap.gtt.app.tstdpp";
        criteria = new MetadataCriteria();
        criteria.addNamespace(namespace);
        criteria.setStatus(MetadataProjectStatus.ACTIVE.name());

        try {
            given(defaultMetadataDao.getMetadataDerivedCsn(criteria)).willReturn(loadFile(DERIVED_CSN_FILE_FOR_DPP));
        } catch (IOException e) {
            e.printStackTrace();
        }

        metadataDraftModelsList = new ArrayList<>();
        metadataDraftModel = new MetadataDraftModel("", "", "", "", "", "", "", Instant.now());
        metadataDraftModel.setId("id");
        metadataDraftModel.setNamespace("ns");
        metadataDraftModel.setVersion("1.0.0");
        metadataDraftModel.setDescription("des");
        metadataDraftModel.setStatus("active");
        metadataDraftModel.setJsonModel("{}");


    }

    private String loadFile(String fileName) throws IOException {
        InputStream inputStream = getClass().getClassLoader().getResourceAsStream(fileName);
        return IOUtils.toString(inputStream, Charset.defaultCharset());
    }

    @Test
    public void getMetadataSwaggerInfo() {
        String namespace = "com.sap.gtt.app.mim.MIMWriteService";
        String namespace1 = "com.sap.gtt.app.mim";
        String entityName = "InboundDeliveryItemEvent";
        //given
        MetadataProjectFile projectFile = new MetadataProjectFile();
        try {
            projectFile.setDerivedCsn(loadFile(DERIVED_CSN_FILE));
            projectFile.setSwagger(loadFile(SWAGGER_FILE));
        } catch (IOException e) {
            e.printStackTrace();
        }
        given(defaultMetadataDao.getMetadataSwaggerDerivedCsnInfo(namespace1)).willReturn(projectFile);

        MetadataSwaggerInfo swaggerInfo = defaultMetadataManagement.getMetadataSwaggerInfo(namespace, entityName);
        assertNotNull(swaggerInfo.getSwaggerObj());
        assertNotNull(swaggerInfo.getApplicationObjectType());
        assertTrue(swaggerInfo.isTrackedProcess());

        entityName = "InbDelGoodsReceiptEvent";

        swaggerInfo = defaultMetadataManagement.getMetadataSwaggerInfo(namespace, entityName);
        assertNotNull(swaggerInfo.getApplicationObjectType());
    }

    @Test
    public void findAllFieldsOfEntity() {
        String namespace = "com.sap.gtt.app.mim";
        String entityName = "com.sap.gtt.core.CoreModel.Event";
        Map<String, MetadataEntityElement> fields = defaultMetadataManagement.findAllFieldsOfEntity(namespace, entityName);
        assertTrue(!fields.isEmpty());

        entityName = "com.sap.gtt.app.mim.MIMService.ProcessEventDirectory";
        fields = defaultMetadataManagement.findAllFieldsOfEntity(namespace, entityName);
        assertTrue(!fields.isEmpty());

    }

    @Test
    public void getODataEdmx() throws IOException {
        String odataModel = "com.sap.gtt.app.mim.MIMService";
        String modelNamespace = "com.sap.gtt.app.mim";

        List<String> queryNamespaces = new ArrayList<>();
        queryNamespaces.add(odataModel);
        queryNamespaces.add(modelNamespace);
        //given
        String edmx = loadFile(EDMX_FILE);
        List<MetadataProject> metadataProjectList = new ArrayList<>();
        MetadataProject metadataProject = new MetadataProject();
        metadataProject.setStatus("ACTIVE");
        metadataProjectList.add(metadataProject);
        given(defaultMetadataDao.findMetadataProjectInfo(any(MetadataCriteria.class))).willReturn(metadataProjectList);
        given(defaultMetadataDao.getMetadataProjectFileFieldInfo(queryNamespaces, MetadataConstants.MetadataProjectFileField.EDMX)).willReturn(edmx);
        String oDataEdmx = defaultMetadataManagement.getODataEdmx(odataModel);
        assertNotNull(oDataEdmx);
    }

    @Test
    public void findODataNavigationEntitiesByPath() {
        String odataService = "com.sap.gtt.app.mim.MIMService.InboundDeliveryItemProcess";
        String path = "plannedEvents/process/id";
        List<MetadataEntity> entities = defaultMetadataManagement.findODataNavigationEntitiesByPath(odataService, path);
        assertTrue(entities.size() > 0);

        odataService = "com.sap.gtt.app.mim.MIMService.InboundDeliveryItemProcess";
        path = "plannedEvents/process";
        entities = defaultMetadataManagement.findODataNavigationEntitiesByPath(odataService, path);
        assertTrue(entities.size() > 0);

        odataService = "com.sap.gtt.app.mim.MIMService.ProcessEventDirectory";
        path = "event";
        entities = defaultMetadataManagement.findODataNavigationEntitiesByPath(odataService, path);
        assertTrue(entities.size() == 2);
    }

    @Test
    public void findReversedNavigationEntities() {
        String namespace = "com.sap.gtt.app.mim";
        String entityAbbrName = "Action";
        List<List<MetadataEntity>> entities = defaultMetadataManagement.findReversedNavigationEntities(namespace, entityAbbrName);
        assertEquals(17, entities.size());
        entityAbbrName = "Event";
        entities = defaultMetadataManagement.findReversedNavigationEntities(namespace, entityAbbrName);
        assertEquals(22, entities.size());
    }

    @Test
    public void checkIfEventIsUnplanned() {
        String trackedProcessType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        String eventType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.PODelayedEvent";
        boolean isUnplanned = defaultMetadataManagement.checkIfEventIsUnplanned(trackedProcessType, eventType);
        assertTrue(isUnplanned);
    }

   /* @Test
    public void checkIfEventIsProcessEvent() {
        String eventType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemEvent";
        boolean isProcessEvent = defaultMetadataManagement.checkIfEventIsProcessEvent(eventType);
        assertTrue(isProcessEvent);
    }*/

    @Test
    public void getTrackedProcessEntityEventType() {
        String namespace = "com.sap.gtt.app.mim";
        String eventType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemEvent";
        MetadataEntity entity = defaultMetadataManagement.getTrackedProcessEntityByEventType(namespace, eventType);
        assertNotNull(entity);
    }

    @Test
    public void getPhysicalNameOfEntity() {
        String namespace = "com.sap.gtt.app.mim";
        String entityName = "GTTOverdueEvent";
        PhysicalName tableName = defaultMetadataManagement.getPhysicalNameOfEntity(namespace, entityName);
        assertNotNull(tableName);
    }

    @Test
    public void getMetadataProjectFileFieldInfo() throws IOException {
        String namespace = "com.sap.gtt.app.mim";
        MetadataProjectFileField field = MetadataProjectFileField.DERIVED_CSN;
        String expected = loadFile(DERIVED_CSN_FILE);

        List<String> namespaces = new ArrayList<>();
        namespaces.add(namespace);

        given(defaultMetadataDao.getMetadataProjectFileFieldInfo(namespaces, field)).willReturn(expected);
        String actual = defaultMetadataManagement.getMetadataProjectFileFieldInfo(namespace, field);
        assertEquals(expected, actual);
    }

    @Test
    public void getEntityEvent() {
        String entityName = "com.sap.gtt.app.mim.InboundDeliveryItemModel.InboundDeliveryItemProcess";
        String eventType = "com.sap.gtt.app.mim.InboundDeliveryItemModel.InbDelPackingEvent";
        MetadataEntityEvent entityEvent = defaultMetadataManagement.getEntityEvent(entityName, eventType);
        assertEquals(eventType, entityEvent.getEventType());
        Assertions.assertThat(entityEvent).isNotEqualTo(new MetadataEntityEvent());
        Assertions.assertThat(entityEvent.toString()).contains("matchLocation=");

        eventType = "test.null";
        entityEvent = defaultMetadataManagement.getEntityEvent(entityName, eventType);
        assertNull(entityEvent);

    }

    /*@Test
    public void findAllPrimaryKeysOfEntity() {
        String namespace = "com.sap.gtt.app.mim";
        String entityName = "com.sap.gtt.core.CoreModel.PlannedEvent";
        Map<String, MetadataEntityElement> keys = defaultMetadataManagement.findAllPrimaryKeysOfEntity(namespace, entityName);
        assertTrue(keys.size() > 0);
    }*/

    @Test
    public void findAllEntitiesRecursively() {
        String namespace = "com.sap.gtt.app.mim";
        String entityName = "com.sap.gtt.app.mim.InboundDeliveryItemModel.InboundDeliveryItemProcess";
        CurrentMetadataEntity currentMetadataEntity = defaultMetadataManagement.findAllEntitiesRecursively(namespace, entityName);
        assertNotNull(currentMetadataEntity);
    }

    @Test
    public void testGetMetadataChangeHistory() {
        List<MetadataChangeHistory> res = new ArrayList<>();
        given(defaultMetadataDao.findMetadataChangeHistoryByNamespace(Mockito.anyString())).willReturn(res);
        defaultMetadataManagement.findMetadataChangeHistoryByNamespace("");
        assertTrue(true);
    }

    @Test
    public void testInsertMetadataChangeHistory() {
        MetadataChangeHistory metadataChangeHistory = new MetadataChangeHistory();
        defaultMetadataManagement.insertMetadataChangeHistory(metadataChangeHistory);
        assertTrue(true);
    }

    @Test
    public void testGetAllMetadataDraftModels() {
        given(defaultMetadataDao.selectAllMetadataDraftModelsInfo(false)).willReturn(metadataDraftModelsList);
        defaultMetadataManagement.getAllMetadataDraftModelsInfo(false);
        assertTrue(true);
    }

    @Test
    public void testCreateMetadataDraftModels() {
        metadataDraftModel.hashCode();
        assertTrue(metadataDraftModel.equals(metadataDraftModel));
        assertFalse(metadataDraftModel.equals(null));
        assertFalse(metadataDraftModel.equals(new MetadataDraftModel("", "", "", "", "", "", "", Instant.now())));
        defaultMetadataManagement.createMetadataDraftModel(metadataDraftModel);
        assertTrue(true);
    }

    @Test
    public void testUpdateMetadataDraftModels() {
        defaultMetadataManagement.updateMetadataDraftModelInfo(metadataDraftModel);
        assertTrue(true);
    }

    @Test
    public void testDeleteMetadataDraftModels() {
        defaultMetadataManagement.deleteMetadataDraftModel("metadataDraftModel");
        assertTrue(true);
    }

    @Test
    public void testGetMetadataDraftModelInfoByNamespace() {
        defaultMetadataManagement.getMetadataDraftModelInfoByNamespace("");
        assertTrue(true);
    }

    @Test
    public void findDppFieldList() {
        String namespace = "com.sap.gtt.app.mimivan";
        String entityName = "com.sap.gtt.app.mimivan.ProcurementOrderItemModel.ProcurementOrderItemEvent";
        List<String> dppFieldList = defaultMetadataManagement.findDppFieldList(namespace, entityName, MetadataConstants.DppType.DPP_DATA_SUBJECTID);
        assertTrue(dppFieldList.size() > 0);

        dppFieldList = defaultMetadataManagement.findDppFieldList(namespace, entityName, MetadataConstants.DppType.DPP_PII);
        assertTrue(dppFieldList.size() > 0);

        dppFieldList = defaultMetadataManagement.findDppFieldList(namespace, entityName, MetadataConstants.DppType.DPP_SPI);
        assertTrue(dppFieldList.size() > 0);
    }


    @Test
    public void findAllEventEntitiesByNamespace() {
        String namespace = "com.sap.gtt.app.mim";
        List<MetadataEntity> eventEntities = defaultMetadataManagement.findAllEventEntitiesByNamespace(namespace, false);
        assertTrue(!eventEntities.isEmpty());
    }

    @Test
    public void findAllTrackedProcessAndEventEntitiesByNamespace() {
        String namespace = "com.sap.gtt.app.mim";
        List<MetadataEntity> eventEntities = defaultMetadataManagement.findAllTrackedProcessAndEventEntitiesByNamespace(namespace, true);
        assertTrue(!eventEntities.isEmpty());
    }

    @Test
    public void getPdmSchema() {
        given(defaultDppDao.getPdmSchema()).willReturn(null);
        String pdmSchema = defaultMetadataManagement.getPdmSchema();
        verify(defaultDppDao, times(1)).getPdmSchema();
    }

    @Test
    public void insertPdmSchema() {
        String namespace = "com.sap.gtt.app.mimivan";
        //String namespace = "com.sap.gtt.app.tstdpp";
        given(defaultDppDao.getPdmSchema()).willReturn(null);
        defaultMetadataManagement.upsertPdmSchema(namespace);
        verify(defaultDppDao, times(1)).insertPdmSchema(Mockito.any());

    }

    @Test
    public void updatePdmSchema() {
        try {
            given(defaultDppDao.getPdmSchema()).willReturn(loadFile(PDM_SCHEMA_FILE));
        } catch (IOException e) {
            e.printStackTrace();
        }
        String namespace = "com.sap.gtt.app.mimivan";
        //String namespace = "com.sap.gtt.app.tstdpp";
        defaultMetadataManagement.upsertPdmSchema(namespace);
        verify(defaultDppDao, times(1)).updatePdmSchema(Mockito.any());
    }

    @Test
    public void deletePdmSchema() {
        String namespace = "com.sap.gtt.app.mimivan";
        //String namespace = "com.sap.gtt.app.tstdpp";
        try {
            given(defaultDppDao.getPdmSchema()).willReturn(loadFile(PDM_SCHEMA_FILE));
        } catch (IOException e) {
            e.printStackTrace();
        }
        defaultMetadataManagement.deletePdmSchema(namespace);
        verify(defaultDppDao, times(1)).updatePdmSchema(Mockito.any());
    }

    @Test
    public void testGetDataSubjectIdentitiesWithData() {
        String dataSubjectIdValue = "TEST@SAP.COM";
        try {
            given(defaultDppDao.getPdmSchema()).willReturn(loadFile(PDM_SCHEMA_FILE));
        } catch (IOException e) {
            e.printStackTrace();
        }
        given(defaultDppDao.isDataSubjectIdExistsInDB(Mockito.anyString(), Mockito.any())).willReturn(true);
        String namespace = "com.sap.gtt.app.mimivan";
        //String namespace = "com.sap.gtt.app.tstdpp";
        MetadataCriteria criteria = new MetadataCriteria();
        criteria.addNamespace(namespace);

        try {
            given(defaultMetadataDao.getMetadataDerivedCsn(criteria)).willReturn(loadFile(DERIVED_CSN_FILE_FOR_DPP));
        } catch (IOException e) {
            e.printStackTrace();
        }
        defaultMetadataManagement.isDataSubjectIdValueExistsInDB(dataSubjectIdValue);
        verify(defaultDppDao, times(1)).isDataSubjectIdExistsInDB(Mockito.anyString(), Mockito.any());
    }

    @Test
    public void testGetPdmDataInfo() {
        String entityName = "com.sap.gtt.app.mimivan.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        String dataSubjectIdValue = "TEST@SAP.COM";
        try {
            given(defaultMetadataDao.getMetadataDerivedCsn(Mockito.any())).willReturn(loadFile(DERIVED_CSN_FILE_FOR_DPP));
        } catch (IOException e) {
            e.printStackTrace();
        }
        List<Map<String, Object>> pdmInfoList = new ArrayList();
        given(defaultDppDao.getPdmDataInfo(Mockito.any(), Mockito.any())).willReturn(pdmInfoList);
        defaultMetadataManagement.getPdmDataInfo(entityName, dataSubjectIdValue);
        verify(defaultDppDao, times(1)).getPdmDataInfo(Mockito.anyString(), Mockito.any());
    }

    @Test
    public void testGetPdmDataInfoForCoreModelEvent() {
        String entityName = "com.sap.gtt.core.CoreModel.Event";
        String dataSubjectIdValue = "TEST@SAP.COM";
        List<Map<String, Object>> pdmInfoList = new ArrayList();
        given(defaultDppDao.getPdmDataInfo(Mockito.any(), Mockito.any())).willReturn(pdmInfoList);
        defaultMetadataManagement.getPdmDataInfo(entityName, dataSubjectIdValue);
        verify(defaultDppDao, times(1)).getPdmDataInfo(Mockito.anyString(), Mockito.any());
    }

    @Test
    public void getI18nInfo() throws IOException {
        String namespace = "com.sap.gtt.app.tfo";
        String fileName = "i18n_zh_CN.properties";
        List<String> namespaces = new ArrayList<>();
        namespaces.add(namespace);
        given(defaultMetadataDao.getMetadataProjectFileFieldInfo(namespaces, MetadataProjectFileField.I18N)).willReturn(null);
        String i18nInfo = defaultMetadataManagement.getI18nInfo(namespace, fileName);
        assertTrue(i18nInfo.isEmpty());

        given(defaultMetadataDao.getMetadataProjectFileFieldInfo(namespaces, MetadataProjectFileField.I18N))
                .willReturn(loadFile("i18n.json"));
        i18nInfo = defaultMetadataManagement.getI18nInfo(namespace, fileName);
        assertTrue(!i18nInfo.isEmpty());
    }

    @Test
    public void getUiAnnotation() throws IOException {
        String namespace = "com.sap.gtt.app.tfo";
        List<String> namespaces = new ArrayList<>();
        namespaces.add(namespace);
        given(defaultMetadataDao.getMetadataProjectFileFieldInfo(namespaces, MetadataProjectFileField.ANNOTATION))
                .willReturn(loadFile("annotation.json"));
        String annotation = defaultMetadataManagement.getUiAnnotation(namespace);
        assertTrue(!annotation.isEmpty());
    }

    @Test
    public void getUiAnnotation_2() throws IOException {
        String namespace = "com.sap.gtt.app.tfo";
        List<String> namespaces = new ArrayList<>();
        namespaces.add(namespace);
        given(defaultMetadataDao.getMetadataProjectFileFieldInfo(namespaces, MetadataProjectFileField.ANNOTATION))
                .willReturn(null);
        String annotation = defaultMetadataManagement.getUiAnnotation(namespace);
        assertNull(annotation);
    }

    @Test
    public void getServiceNamespace() throws IOException {
        String expected = "com.sap.gtt.app.mim.MIMWriteService";
        String namespace = "com.sap.gtt.app.mim";
        List<String> namespaces = new ArrayList<>();
        namespaces.add(namespace);
        given(defaultMetadataDao.getMetadataProjectFileFieldInfo(namespaces, MetadataProjectFileField.SWAGGER))
                .willReturn(loadFile("MIMWriteService_swagger.json"));
        String serviceNamespace = defaultMetadataManagement.getServiceNamespace(namespace, true);
        assertEquals(expected, serviceNamespace);

        given(defaultMetadataDao.getMetadataProjectFileFieldInfo(namespaces, MetadataProjectFileField.DERIVED_CSN))
                .willReturn(loadFile("derived_csn.json"));
        expected = "com.sap.gtt.app.mim.MIMService";
        serviceNamespace = defaultMetadataManagement.getServiceNamespace(namespace, false);
        assertEquals(expected, serviceNamespace);
    }

    @Test
    public void testUpdateMetadataProjectStatus() {
        String namespace = "com.sap.gtt.app.mim";

        MetadataProject metadataProject = new MetadataProject();
        metadataProject.setNamespace(namespace);
        metadataProject.setStatus(MetadataProjectStatus.ACTIVE.name());
        try {
            defaultMetadataManagement.updateMetadataProjectStatus(metadataProject);
        } catch (Exception e) {
        }
        assertTrue(true);
    }

    @Test
    public void testGetModelConfiguration() {
        String namespace = "com.sap.gtt.app.mim";
        ModelConfiguration modelConfiguration = defaultMetadataManagement.getModelConfiguration(namespace);
        assertTrue(modelConfiguration.isEnableInstanceBasedAuthorization());
        assertEquals(2, modelConfiguration.getEventCorrelationLevel());
    }

    @Test
    public void testFindMatchedExtensionFieldPairs() {
        String eventType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.POGoodsReceivedEvent";
        List<Pair<String, String>> pairs = defaultMetadataManagement.findMatchedExtensionFieldPairs(eventType);
        assertTrue(pairs.size() == 1);
        assertEquals("mode", pairs.get(0).getLeft());
        assertEquals("mode1", pairs.get(0).getRight());
    }
}