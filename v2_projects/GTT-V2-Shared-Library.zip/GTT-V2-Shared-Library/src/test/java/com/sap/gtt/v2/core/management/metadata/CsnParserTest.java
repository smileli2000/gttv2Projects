package com.sap.gtt.v2.core.management.metadata;

import com.sap.gtt.v2.core.domain.metadata.MetadataConstants;
import com.sap.gtt.v2.core.domain.metadata.MetadataEntity;
import com.sap.gtt.v2.core.domain.metadata.ModelConfiguration;
import com.sap.gtt.v2.exception.JsonParseException;
import org.apache.commons.io.IOUtils;
import org.junit.Test;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static com.sap.gtt.v2.core.domain.metadata.MetadataConstants.CoreModelEntity.PLANNED_EVENT;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class CsnParserTest {

    private String derivedCsnFile = "derived_csn.json";
    private String originalCsnFile = "MIMService_csn.json";
    private String derivedCsnFileWithWrongDuration = "derived_csn_with_wrong_duration.json";

    @Test
    public void parseToEntities() throws IOException {

        String derivedCsn = IOUtils.toString(getClass().getClassLoader()
                .getResourceAsStream(derivedCsnFile), Charset.defaultCharset());
        List<MetadataEntity> entities = CsnParser.parseToEntities(derivedCsn);
        Optional<MetadataEntity> plannedEvent = entities.stream().filter(e -> PLANNED_EVENT.getFullName().equalsIgnoreCase(e.getName())).findFirst();
        boolean includeCustomizedFields = plannedEvent.get().isIncludeCustomizedFields();
        assertTrue(includeCustomizedFields);
        assertTrue(entities.size() > 0);
    }

    @Test(expected = JsonParseException.class)
    public void parseToEntitiesWithWrongDurationCsnFile() throws IOException {

        String derivedCsn = IOUtils.toString(getClass().getClassLoader()
                .getResourceAsStream(derivedCsnFileWithWrongDuration), Charset.defaultCharset());
        CsnParser.parseToEntities(derivedCsn);
    }

    @Test
    public void deriveCSN() throws IOException {
        InputStream originalCSNStream = getClass().getClassLoader()
                .getResourceAsStream(originalCsnFile);
        String originalCsn = IOUtils.toString(originalCSNStream, Charset.defaultCharset());
        String expectedCsn = IOUtils.toString(getClass().getClassLoader().getResourceAsStream(derivedCsnFile), Charset.defaultCharset());
        ModelConfiguration configuration = new ModelConfiguration();
        configuration.setEnableInstanceBasedAuthorization(true);
        configuration.setEventCorrelationLevel(2);
        String derivedCsn = CsnParser.deriveCsn(originalCsn, configuration);
        //System.out.println(derivedCsn);
        assertEquals(expectedCsn, derivedCsn);
    }

    @Test
    public void getAllTheMetadataEntitiesOf() throws IOException {
        String derivedCsn = IOUtils.toString(getClass().getClassLoader()
                .getResourceAsStream(derivedCsnFile), Charset.defaultCharset());
        List<MetadataEntity> trackedProcessEntities = CsnParser.getAllTheMetadataEntitiesOf(derivedCsn, MetadataConstants.EntityBaseType.TRACKED_PROCESS);
        assertTrue(trackedProcessEntities.size() > 0);
    }

    @Test
    public void getProjectNamespace() {
        String expectedNamespace = "com.sap.gtt.app.mim";
        String entityName = "com.sap.gtt.app.mim.DeliveryModel.DeliveryProcess";
        String namespace = CsnParser.getProjectNamespace(entityName);
        assertEquals(expectedNamespace, namespace);
        entityName = "com.sap.gtt.app.mim.MIMService.Event";
        namespace = CsnParser.getProjectNamespace(entityName);
        assertEquals(expectedNamespace, namespace);
    }

    @Test
    public void isConditionName() {
        String fullEntityName = "com.sap.gtt.app.mim.delivery.DeliveryModel.DeliveryProcess";
        boolean actual = CsnParser.isConditionName(fullEntityName, Arrays.asList("DeliveryProcess"));
        assertEquals(true, actual);

        actual = CsnParser.isConditionName(fullEntityName, Arrays.asList("deliveryprocess"));
        assertEquals(true, actual);

        actual = CsnParser.isConditionName(fullEntityName, Arrays.asList("poitemrocess"));
        assertEquals(false, actual);
    }
}