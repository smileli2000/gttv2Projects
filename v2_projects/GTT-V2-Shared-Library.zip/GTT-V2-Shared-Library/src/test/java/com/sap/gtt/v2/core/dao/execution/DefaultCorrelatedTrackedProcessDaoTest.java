package com.sap.gtt.v2.core.dao.execution;

import com.sap.gtt.v2.BaseTest;
import com.sap.gtt.v2.Dummy;
import com.sap.gtt.v2.core.entity.execution.CorrelatedTrackedProcess;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = Dummy.class)
@ActiveProfiles("test")
public class DefaultCorrelatedTrackedProcessDaoTest extends BaseTest {
    private DefaultCorrelatedTrackedProcessDao correlatedTrackedProcessDao;

    @Before
    public void setUp() {
        super.setUp();
        correlatedTrackedProcessDao = DefaultCorrelatedTrackedProcessDao.getInstance();
    }

    @Test
    public void testInsert() {
        List<CorrelatedTrackedProcess> correlatedTrackedProcessList = new ArrayList<>();
        String executionId = "executionId";
        correlatedTrackedProcessList.add(new CorrelatedTrackedProcess(UUID.randomUUID().toString(), executionId, UUID.randomUUID().toString(), "a"));
        correlatedTrackedProcessList.add(new CorrelatedTrackedProcess(UUID.randomUUID().toString(), executionId, UUID.randomUUID().toString(), "b"));
        correlatedTrackedProcessDao.insert(correlatedTrackedProcessList);
        List<CorrelatedTrackedProcess> rst = correlatedTrackedProcessDao.query(executionId);
        assertThat(rst.size()).isEqualTo(correlatedTrackedProcessList.size());
    }
}
