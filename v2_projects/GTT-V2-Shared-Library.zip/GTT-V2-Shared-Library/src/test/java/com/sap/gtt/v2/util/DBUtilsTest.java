package com.sap.gtt.v2.util;

import com.sap.gtt.v2.core.domain.metadata.PhysicalName;
import com.sap.gtt.v2.core.entity.metadata.MetadataProject;
import org.junit.Test;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

import static com.sap.gtt.v2.core.domain.metadata.MetadataConstants.*;
import static org.junit.Assert.assertEquals;

public class DBUtilsTest {

    @Test
    public void buildUpdateSql() {
        StringBuilder updateSql = new StringBuilder();
        List<Object> updateParam = new ArrayList<>();
        MetadataProject updatedMetadataProject = new MetadataProject();

        String expected = "UPDATE METADATA_PROJECT SET UPLOADED_AT=?,VERSION=?,STATUS=?,DESCRIPTION=?,MODE=?,CORE_MODEL_VERSION=? WHERE NAMESPACE=? AND ID=?";

        String[] updatedColumns = {UPLOADED_AT, VERSION, STATUS, DESCRIPTION, MODE, CORE_MODEL_VERSION, COMPILER_VERSION};
        Object[] updatedVal = {Instant.now(),
                "1.0",
                "1",
                "desc",
                "standard",
                "1.0",
                null
        };
        String[] whereColumns = {NAMESPACE, ID};
        Object[] whereVals = {updatedMetadataProject.getNamespace(), updatedMetadataProject.getId()};

        DBUtils.buildUpdateSql(MetadataTable.METADATA_PROJECT.name(),
                updatedColumns,
                updatedVal,
                whereColumns,
                whereVals,
                updateSql,
                updateParam);
        assertEquals(expected, updateSql.toString());
    }

    @Test
    public void buildDeleteSql() {
        String tableName = MetadataTable.METADATA_PROJECT.name();
        String[] whereColumns = new String[]{NAMESPACE};
        Object[] whereVals = new Object[]{"com.sap.gtt.app.mim"};
        StringBuilder deleteSql = new StringBuilder();
        DBUtils.buildDeleteSql(tableName, whereColumns, whereVals, deleteSql);
        String expected = "DELETE FROM METADATA_PROJECT WHERE NAMESPACE = ?";
        assertEquals(expected, deleteSql.toString());

        whereColumns = new String[]{NAMESPACE};
        whereVals = new Object[]{"com.sap.gtt.app.mim", "com.sap.gtt.app.tfo"};
        deleteSql = new StringBuilder();
        DBUtils.buildDeleteSql(tableName, whereColumns, whereVals, deleteSql);
        expected = "DELETE FROM METADATA_PROJECT WHERE NAMESPACE = ? OR NAMESPACE = ?";
        assertEquals(expected, deleteSql.toString());

        whereColumns = new String[]{ID, NAMESPACE};
        whereVals = new Object[]{"1111", "com.sap.gtt.app.mim"};
        deleteSql = new StringBuilder();
        DBUtils.buildDeleteSql(tableName, whereColumns, whereVals, deleteSql);
        expected = "DELETE FROM METADATA_PROJECT WHERE ID = ? AND NAMESPACE = ?";
        assertEquals(expected, deleteSql.toString());
    }

    @Test
    public void buildDeleteSqlUsingSubQuery() {
        StringBuilder deleteSql = new StringBuilder();
        DBUtils.buildDeleteSqlUsingSubQuery(MetadataTable.METADATA_PROCESS.name(), METADATA_PROJECT_ID,
                new Object[]{"project1"}, MetadataTable.METADATA_PROJECT.name(), ID, NAMESPACE, deleteSql);
        String expected = "DELETE FROM METADATA_PROCESS WHERE METADATA_PROJECT_ID IN ( SELECT ID FROM METADATA_PROJECT WHERE NAMESPACE = ?)";
        assertEquals(expected, deleteSql.toString());

        Object[] whereVals = {"12345"};
        deleteSql = new StringBuilder();
        //delete metadata event text by metadataProcessId:
        //delete from metadata_event_texts where metadata_event_id in (select id from metadata_event where metadata_process_id = ?)
        DBUtils.buildDeleteSqlUsingSubQuery(MetadataTable.METADATA_EVENT_TEXTS.name(), METADATA_EVENT_ID, whereVals,
                MetadataTable.METADATA_EVENT.name(), ID, METADATA_PROCESS_ID, deleteSql
        );
        expected = "DELETE FROM METADATA_EVENT_TEXTS WHERE METADATA_EVENT_ID IN ( SELECT ID FROM METADATA_EVENT WHERE METADATA_PROCESS_ID = ?)";
        assertEquals(expected, deleteSql.toString());
    }

    @Test
    public void testGetPhysicalName() {
        PhysicalName physicalName = DBUtils.getPhysicalName(CoreModelEntity.PLANNED_EVENT.getFullName(), null,
                true, "test");
        String corePhysicalName = DBUtils.toTableName(CoreModelEntity.PLANNED_EVENT.getFullName());
        assertEquals(corePhysicalName, physicalName.getName());
        assertEquals(corePhysicalName, physicalName.getCorePhysicalName());
        assertEquals("test", physicalName.getExtendedPhysicalName());
    }
}