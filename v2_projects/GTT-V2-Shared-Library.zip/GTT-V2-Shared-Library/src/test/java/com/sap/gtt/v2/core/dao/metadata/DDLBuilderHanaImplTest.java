package com.sap.gtt.v2.core.dao.metadata;

import com.sap.gtt.v2.Dummy;
import com.sap.gtt.v2.core.domain.metadata.CurrentMetadataEntity;
import com.sap.gtt.v2.core.domain.metadata.MetadataEntityElement;
import com.sap.gtt.v2.core.management.metadata.DefaultMetadataManagement;
import com.sap.gtt.v2.core.management.metadata.IMetadataManagement;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.IOException;
import java.util.List;


@RunWith(SpringRunner.class)
@SpringBootTest(classes = Dummy.class)
@ActiveProfiles("test")
public class DDLBuilderHanaImplTest {
    @Autowired
    private IMetadataDao metadataDao;

    @Autowired
    private ISysTableDao sysTableDao;

    @Autowired
    private DDLBuilderHanaImpl ddlBuilderHana;

    @Test
    public void test() throws IOException {
        DefaultMetadataDaoTest test = new DefaultMetadataDaoTest();
        test.setDefaultMetadataDao((DefaultMetadataDao) metadataDao);
        test.insertMetadataProject();

        DefaultSysTableDaoTest test1 = new DefaultSysTableDaoTest();
        test1.setDefaultSysTableDao((DefaultSysTableDao) sysTableDao);
        test1.createTables();

        String entityName = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        String namespace = "com.sap.gtt.app.mim";

        IMetadataManagement metadataManagement = DefaultMetadataManagement.getInstance();
        CurrentMetadataEntity metadata = metadataManagement.findAllEntitiesRecursively(namespace, entityName);

        ddlBuilderHana.getSysTablesName();
        ddlBuilderHana.getCurrentSchemaCondition();
        List<MetadataEntityElement> elements = metadata.getAllRelatedEntityMap().get(metadata.getCurrentEntityName()).getElements();
        ddlBuilderHana.buildCreateTable(entityName, elements);

        ddlBuilderHana.buildAlterTableField(entityName, elements);
        ddlBuilderHana.buildDropTableField(entityName, elements);
    }
}