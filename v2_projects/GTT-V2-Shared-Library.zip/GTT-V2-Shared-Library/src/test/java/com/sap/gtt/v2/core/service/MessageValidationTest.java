package com.sap.gtt.v2.core.service;

import com.sap.gtt.v2.Dummy;
import com.sap.gtt.v2.bp.BusinessPartner;
import com.sap.gtt.v2.configuration.ISAPCloudPlatformAgent;
import com.sap.gtt.v2.core.domain.metadata.CurrentMetadataEntity;
import com.sap.gtt.v2.core.domain.metadata.MetadataCriteria;
import com.sap.gtt.v2.core.domain.metadata.MetadataEntity;
import com.sap.gtt.v2.core.domain.trackedprocess.Action;
import com.sap.gtt.v2.core.domain.trackedprocess.Constant;
import com.sap.gtt.v2.core.entity.metadata.MetadataProcess;
import com.sap.gtt.v2.core.entity.trackedprocess.Event;
import com.sap.gtt.v2.core.entity.trackedprocess.PlannedEvent;
import com.sap.gtt.v2.core.entity.trackedprocess.Reference;
import com.sap.gtt.v2.core.management.execution.IMessageLogManagement;
import com.sap.gtt.v2.core.management.metadata.CsnParser;
import com.sap.gtt.v2.core.management.metadata.IMetadataManagement;
import com.sap.gtt.v2.exception.BaseRuntimeException;
import com.sap.gtt.v2.exception.MultiExceptionContainer;
import com.sap.gtt.v2.util.GTTUtils;
import org.apache.commons.io.IOUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.IOException;
import java.nio.charset.Charset;
import java.time.Instant;
import java.util.*;

import static com.sap.gtt.v2.core.domain.metadata.MetadataConstants.CoreModelEntity.GTT_DELAYED_EVENT;
import static com.sap.gtt.v2.core.domain.metadata.MetadataConstants.CoreModelEntity.GTT_DELETION_EVENT;
import static com.sap.gtt.v2.core.domain.metadata.MetadataConstants.INITIAL_CAPACITY;
import static org.junit.Assert.assertTrue;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = Dummy.class)
@ActiveProfiles("test")
public class MessageValidationTest {

    public static final String BP_NUMBER = "666666";
    @InjectMocks
    MessageValidation messageValidation;

    private IMetadataManagement metadataManagement;
    @Mock
    private ISAPCloudPlatformAgent.ICurrentAccessContext currentAccessContext;

    @Before
    public void setUp() throws IOException {
        metadataManagement = mock(IMetadataManagement.class);
        IMessageLogManagement messageLogManagement = mock(IMessageLogManagement.class);
        GTTUtils.BusinessOperator businessOperator = mock(GTTUtils.BusinessOperator.class);
        given(businessOperator.getMetadataManagement()).willReturn(metadataManagement);
        given(businessOperator.getMessageLogManagement()).willReturn(messageLogManagement);
        given(currentAccessContext.createBusinessOperator()).willReturn(businessOperator);
        given(currentAccessContext.getSubaccountId()).willReturn(UUID.randomUUID().toString());

        Map<String, MetadataEntity> entityMap = loadAllMetadatas();
        String trackedProcessType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        String eventType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemEvent";
        String plannedEventType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.POConfirmedEvent";
        given(metadataManagement.getTrackedProcessEntityByEventType(CsnParser.getProjectNamespace(eventType), eventType))
                .willReturn(entityMap.get(trackedProcessType));
        given(metadataManagement.getTrackedProcessEntityByEventType(CsnParser.getProjectNamespace(eventType), plannedEventType))
                .willReturn(entityMap.get(trackedProcessType));

        String namespace = "com.sap.gtt.app.mim";
        String inboundDeliveryItemProcess = "com.sap.gtt.app.mim.InboundDeliveryItemModel.InboundDeliveryItemProcess";
        List<MetadataProcess> metadataProcessList = new ArrayList<>();
        MetadataProcess process1 = getMetadataProcesses(trackedProcessType, "ProcurementOrderItem");
        MetadataProcess process2 = getMetadataProcesses(inboundDeliveryItemProcess, "InboundDeliveryItem");
        metadataProcessList.add(process1);
        metadataProcessList.add(process2);
        MetadataCriteria criteria = new MetadataCriteria();
        criteria.addNamespace(namespace);
        given(metadataManagement.findAllMetadataProcess(criteria)).willReturn(metadataProcessList);

        BusinessPartner bp = new BusinessPartner();
        bp.setLbnId("666666");
        given(currentAccessContext.getBusinessPartner()).willReturn(bp);
    }

    private MetadataProcess getMetadataProcesses(String trackedProcessType, String trackingIdType) {
        MetadataProcess metadataProcess = new MetadataProcess();
        metadataProcess.setTrackingIdType(trackingIdType);
        metadataProcess.setTrackedProcessType(trackedProcessType);
        metadataProcess.setDescription("processType");
        return metadataProcess;
    }

    @Test
    public void should_return_ok() throws IOException {
        String eventType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemEvent";
        String namespace = "com.sap.gtt.app.mim";
        List<Event> events = getEvents(namespace, eventType, true, true);
        messageValidation.validate(events, "requestId", "writeServiceId");
        assertTrue(true);
    }

    @Test
    public void should_return_false() {
        String eventType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemEvent";
        String namespace = "com.sap.gtt.app.mim";
        List<Event> events = getEvents(namespace, eventType, false, true);
        events.addAll(getEvents(namespace, GTT_DELAYED_EVENT.getFullName(), false, false));
        events.addAll(getEvents(namespace, GTT_DELETION_EVENT.getFullName(), false, false));
        try {
            messageValidation.validate(events, "requestId", "writeServiceId");
        } catch (MultiExceptionContainer e) {
            List<Exception> containedExceptions = e.getContainedExceptions();
            containedExceptions.forEach(e1 -> {
                System.out.println(((BaseRuntimeException) e1).getMessageCode());
            });
            assertTrue(containedExceptions.size() > 0);
            return;
        }
    }

    private List<Event> getEvents(String namespace, String eventType, boolean normalEvent, boolean isProcessEvent) {
        List<Event> events = new ArrayList<>();
        String plannedEventType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.POConfirmedEvent";
        if (messageValidation.isGTTDeletionEvent(eventType)) {
            plannedEventType = null;
        }
        String altKey = "xri://sap.com/id:LBN#666666:Q8JCLNT774:ProcurementOrderItem:1211031264";
        if (!normalEvent) {
            altKey = "xri://sap.com/id:LBN#666688:Q8JCLNT774:ProcurementOrderItemXX:1211031264";
        }
        String locationAltKey = "xri://sap.com/id:LBN#10000002:Q8JCLNT767:Location:LogisticLocation:LBN_CUS_MI";
        if (isProcessEvent) {
            if (normalEvent) {
                events.add(getEvent(namespace, eventType, altKey, locationAltKey, plannedEventType, true, true, true, true, true));
            } else {
                locationAltKey = "hahaahah:hahadfd";
                events.add(getEvent(namespace, eventType, altKey, locationAltKey, plannedEventType, false, false, false, true, false));
                String invalidPlannedEvent = "com.sap.gtt.app.mim.ProcurementOrderItemModel.POConfirmedEvent222";
                events.add(getEvent(namespace, eventType, altKey, locationAltKey, invalidPlannedEvent, false, false, false, true, false));
            }
        } else {
            if (normalEvent) {
                events.add(getEvent(namespace, eventType, altKey, locationAltKey, plannedEventType, true, true, true, false, true));
            } else {
                events.add(getEvent(namespace, eventType, altKey, locationAltKey, plannedEventType, true, true, true, false, false));
            }

        }
        return events;
    }

    private Event getEvent(String namespace, String eventType, String altKey, String locationAltKey, String plannedEventType,
                           boolean normalPlannedEvent, boolean normalTimestamp, boolean normalReference,
                           boolean isProcessEvent, boolean normalLocationAltKey) {
        Event event = new Event();
        event.setModelNamespace(namespace);
        event.setEventType(eventType);
        CurrentMetadataEntity currentMetadataEntity = loadMetadata(eventType);
        currentMetadataEntity.setNamespace(namespace);
        event.setMetadata(currentMetadataEntity);
        event.setAltKey(altKey);
        event.setLocationAltKey(locationAltKey);

        if (plannedEventType != null) {
            if (isProcessEvent) {
                List<PlannedEvent> plannedEventForEvents = new ArrayList<>();
                int plannedEventSize = 1;
                if (!normalPlannedEvent) {
                    plannedEventSize = 2;
                }
                UUID id = GTTUtils.UUIDUtils.generateNameBasedUUID("hahage123");
                for (int i = 0; i < plannedEventSize; i++) {
                    PlannedEvent plannedEvent = getPlannedEventForEvent(id, plannedEventType, locationAltKey, normalTimestamp);
                    plannedEventForEvents.add(plannedEvent);
                }

                event.setPlannedEvents(plannedEventForEvents);

                List<Reference> references = new ArrayList<>();
                String referenceType = "TRACKING";
                if (normalReference) {
                    String altKeyNormal = "xri://sap.com/id:LBN#666666:Q8JCLNT774:ProcurementOrderItem:1211031295";
                    references.add(getReference(altKeyNormal, Action.ADD.name(), referenceType, normalTimestamp));
                } else {
                    referenceType = null;
                    references.add(getReference(altKey, Action.ADD.name(), referenceType, normalTimestamp));
                    references.add(getReference(altKey, Action.ADD.name(), referenceType, normalTimestamp));
                    referenceType = "WrongReferenceType";
                    references.add(getReference(altKey, Action.ADD.name(), referenceType, normalTimestamp));
                }
                event.setReferences(references);
            } else {
                event.setValue(Constant.REF_PLANNED_EVENT_TYPE, plannedEventType);
                if (normalLocationAltKey) {
                    event.setValue(Constant.REF_PLANNED_EVENT_LOCATION_ALEKEY, locationAltKey);
                }
            }
        }
        return event;
    }

    private PlannedEvent getPlannedEventForEvent(UUID id, String plannedEvent, String locationAltKey, boolean normalTimestamp) {
        PlannedEvent plannedEventForEvent = new PlannedEvent();
        plannedEventForEvent.setId(id);
        plannedEventForEvent.setEventType(plannedEvent);
        plannedEventForEvent.setLocationAltKey(locationAltKey);

        if (normalTimestamp) {
            plannedEventForEvent.setPlannedBusinessTimestamp(Instant.now());
            plannedEventForEvent.setPlannedTechnicalTimestamp(Instant.now().plusSeconds(10L));
            plannedEventForEvent.setPlannedBizTsEarliest(plannedEventForEvent.getPlannedBusinessTimestamp());
            plannedEventForEvent.setPlannedTechTsEarliest(plannedEventForEvent.getPlannedBizTsEarliest());
            plannedEventForEvent.setPlannedBizTsLatest(Instant.now());
            plannedEventForEvent.setPlannedTechTsLatest(Instant.now().plusSeconds(10L));
        } else {
            plannedEventForEvent.setPlannedTechnicalTimestamp(Instant.now());
        }
        return plannedEventForEvent;
    }

    private Reference getReference(String altKey, String action, String referenceType, boolean normalTimestamp) {
        Reference reference = new Reference();
        reference.setAltKey(altKey);
        reference.setAction(action);
        reference.setReferenceType(referenceType);
        reference.setValidFrom(Instant.now());
        if (normalTimestamp) {
            reference.setValidTo(Instant.now().plusSeconds(200L));
        } else {
            reference.setValidTo(Instant.now().minusSeconds(200L));
        }

        return reference;
    }

    private CurrentMetadataEntity loadMetadata(String eventType) {
        CurrentMetadataEntity currentMetadataEntity = new CurrentMetadataEntity();
        Map<String, MetadataEntity> allEntityMap;
        Map<String, MetadataEntity> allRelatedEntityMap = new HashMap<>(INITIAL_CAPACITY);
        try {
            allEntityMap = loadAllMetadatas();
            MetadataEntity mainEntity = allEntityMap.get(eventType);
            String mainEntityName = mainEntity.getName();
            currentMetadataEntity.setCurrentEntityName(mainEntityName);
            allRelatedEntityMap.put(mainEntityName, mainEntity);
            CsnParser.findRelatedEntities(allEntityMap, mainEntity, allRelatedEntityMap);
            currentMetadataEntity.setAllRelatedEntityMap(allRelatedEntityMap);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return currentMetadataEntity;
    }

    private Map<String, MetadataEntity> loadAllMetadatas() throws IOException {
        String derivedCsnFile = "derived_csn.json";
        String derivedCsn = IOUtils.toString(getClass().getClassLoader()
                .getResourceAsStream(derivedCsnFile), Charset.defaultCharset());
        return CsnParser.parseToEntityMap(derivedCsn);
    }
}