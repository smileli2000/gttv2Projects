package com.sap.gtt.v2.bp;

import com.google.gson.JsonObject;
import com.sap.gtt.v2.bp.BusinessPartner;
import com.sap.gtt.v2.bp.BusinessPartnerService;
import com.sap.gtt.v2.configuration.EnvironmentsConfiguration;
import com.sap.gtt.v2.configuration.EnvironmentsConfiguration.VcapServiceParser.BpServiceInstance;
import com.sap.gtt.v2.configuration.GTTRestTemplate;
import com.sap.gtt.v2.configuration.ServiceInstancesMapping;
import com.sap.gtt.v2.core.management.metadata.DefaultMetadataManagement;
import com.sap.gtt.v2.core.management.overdue.DefaultOverdueManagement;
import com.sap.gtt.v2.core.management.tracking.DefaultEventManagement;
import com.sap.gtt.v2.core.management.tracking.DefaultTrackedProcessManagement;
import com.sap.gtt.v2.configuration.EnvironmentsConfiguration.VcapServiceParser.SaasRegistryServiceInstance;
import com.sap.gtt.v2.core.runtime.model.ObjectValue;
import com.sap.gtt.v2.exception.InternalErrorException;
import com.sap.gtt.v2.util.JsonUtils;
import com.sap.gtt.v2.util.SpringContextUtils;
import com.sap.gtt.v2.util.UaaUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;

@RunWith(PowerMockRunner.class)
@PrepareForTest({UaaUtils.class, SpringContextUtils.class})
public class BpServiceTest {
    @Mock
    private ServiceInstancesMapping serviceInstancesMapping;
    @Mock
    private GTTRestTemplate restTemplate;
    @InjectMocks
    private BusinessPartnerService bpService = new BusinessPartnerService();

    @Test
    public void testGetBPByTenantId() {
        BpServiceInstance bpServiceInstance = mock(BpServiceInstance.class);
        String endpoint = "endpoint";
        given(bpServiceInstance.getEndpoint()).willReturn(endpoint);
        given(bpServiceInstance.getClientId()).willReturn("clientId");
        given(bpServiceInstance.getClientSecret()).willReturn("clientSecret");
        given(bpServiceInstance.getUrl()).willReturn("uaaUrl");
        given(serviceInstancesMapping.getBpServiceInstance()).willReturn(bpServiceInstance);

        //GTTUtils.BP bp = mock(GTTUtils.BP.class);
        ResponseEntity responseEntity = mock(ResponseEntity.class);
        String bpS = "{ \"d\": { \"results\": [ { \"AutoAcceptInvitation\": false, \"BpAccGuid\": \"dummy\", \"BpName\": \"Golden Nuts Inc.\", \"BpType\": \"SHIPPER\", \"CreatedBy\": \"shipper01.lbn@gmail.com\", \"CreatedOn\": \"2018-04-27T12:03:59Z\", \"Id\": \"DFFE045D-2241-4EE1-A1D8-76F454F3D721\", \"IsTestData\": true, \"LbnId\": \"10000002\", \"NetworkVisibility\": true, \"NumberRange\": \"10000002\", \"ProfileCompletionStatus\": 31, \"SubDomain\": \"lbn-shipper01\", \"TenantId\": \"d4cc9022-312f-43f6-895b-318a67b36495\", \"UpdatedBy\": \"thurston.chen@sap.com\", \"UpdatedOn\": \"2020-01-26T03:00:35.130Z\", \"ValidFrom\": \"\", \"ValidTo\": \"\", \"Website\": \"https://js.te.com\", \"HasEditScope\": true, \"BPAccountDetails\": { \"results\": [ { \"BpAccId\": \"5b2cdd9e-003d-4c88-970a-816b6d20bf90\", \"BpId\": \"AFAC09E4-E73C-48E1-90BE-7F7495B4BDB5\", \"BpType\": \"SHIPPER\", \"CreatedBy\": \"LBN_REMOTE\", \"CreatedOn\": \"2020-06-01T03:50:56.867Z\", \"GlobalAccExternalGUID\": \"iotDigitalScm\", \"Status\": \"Active\", \"SubAccExternalGUID\": \"lbn-gtt-samples\", \"SubscribedApp\": \"lbn_gtt_core_perf-app\", \"SubscribedPlan\": \"test\", \"UpdatedBy\": null, \"UpdatedOn\": null } ] } } ] } }";
        given(responseEntity.getBody()).willReturn(bpS);

        given(restTemplate.exchange(Mockito.anyString(), eq(HttpMethod.GET), Mockito.any(), eq(null), Mockito.any())).willReturn(responseEntity);

        PowerMockito.mockStatic(UaaUtils.class);
        when(UaaUtils.requestTechniqueToken(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn("token");

        BusinessPartner bp = bpService.getBPByTenantId("tenantId");
        assertEquals("LBN#10000002", bp.getLbnId());

        PowerMockito.mockStatic(SpringContextUtils.class);
        when(SpringContextUtils.getBean(ServiceInstancesMapping.class)).thenReturn(serviceInstancesMapping);
        SaasRegistryServiceInstance saasRegistryServiceInstance = mock(SaasRegistryServiceInstance.class);
        given(saasRegistryServiceInstance.getAppName()).willReturn("lbn_gtt_core_acc-app");
        given(serviceInstancesMapping.getApplicationSaasRegistryServiceInstance()).willReturn(saasRegistryServiceInstance);
        assertEquals(false, bp.isGTTStandaloneProductive());
    }

    @Test
    public void testGetBPByIntegrationUser() {
        BpServiceInstance bpServiceInstance = mock(BpServiceInstance.class);
        String endpoint = "endpoint";
        given(bpServiceInstance.getEndpoint()).willReturn(endpoint);
        given(bpServiceInstance.getClientId()).willReturn("clientId");
        given(bpServiceInstance.getClientSecret()).willReturn("clientSecret");
        given(bpServiceInstance.getUrl()).willReturn("uaaUrl");
        given(serviceInstancesMapping.getBpServiceInstance()).willReturn(bpServiceInstance);

        //GTTUtils.BP bp = mock(GTTUtils.BP.class);
        ResponseEntity responseEntity = mock(ResponseEntity.class);
        String bpS = "{\"d\":{\"results\":[{\"AutoAcceptInvitation\":false,\"BpAccGuid\":\"dummy\",\"BpName\":\"Golden Nuts Inc.\",\"BpType\":\"SHIPPER\",\"CreatedBy\":\"shipper01.lbn@gmail.com\",\"CreatedOn\":\"2018-04-27T12:03:59Z\",\"Id\":\"DFFE045D-2241-4EE1-A1D8-76F454F3D721\",\"IsTestData\":true,\"LbnId\":\"10000002\",\"NetworkVisibility\":true,\"NumberRange\":\"10000002\",\"ProfileCompletionStatus\":31,\"SubDomain\":\"lbn-shipper01\",\"TenantId\":\"d4cc9022-312f-43f6-895b-318a67b36495\",\"UpdatedBy\":\"thurston.chen@sap.com\",\"UpdatedOn\":\"2020-01-26T03:00:35.130Z\",\"ValidFrom\":\"\",\"ValidTo\":\"\",\"Website\":\"https://js.te.com\",\"HasEditScope\":true}]}}";
        given(responseEntity.getBody()).willReturn(bpS);

        given(restTemplate.exchange(Mockito.anyString(), eq(HttpMethod.GET), Mockito.any(), eq(null), Mockito.any())).willReturn(responseEntity);

        PowerMockito.mockStatic(UaaUtils.class);
        when(UaaUtils.requestTechniqueToken(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn("token");

        BusinessPartner bp = bpService.getBPByIntegrationUser("integrationUser");
        assertEquals("LBN#10000002", bp.getLbnId());
    }

    @Test
    public void testGetBPByLbnId() throws InternalErrorException {
        BpServiceInstance bpServiceInstance = mock(BpServiceInstance.class);
        String endpoint = "endpoint";
        given(bpServiceInstance.getEndpoint()).willReturn(endpoint);
        given(bpServiceInstance.getClientId()).willReturn("clientId");
        given(bpServiceInstance.getClientSecret()).willReturn("clientSecret");
        given(bpServiceInstance.getUrl()).willReturn("uaaUrl");
        given(serviceInstancesMapping.getBpServiceInstance()).willReturn(bpServiceInstance);

        ResponseEntity responseEntity = mock(ResponseEntity.class);
        String bpS = "{ \"d\": { \"results\": [ { \"__metadata\": { \"id\": \"https://lbnplatform-bprepo-perf.cfapps.sap.hana.ondemand.com:443/bpr/BusinessPartners('AFAC09E4-E73C-48E1-90BE-7F7495B4BDB5')\", \"uri\": \"https://lbnplatform-bprepo-perf.cfapps.sap.hana.ondemand.com:443/bpr/BusinessPartners('AFAC09E4-E73C-48E1-90BE-7F7495B4BDB5')\", \"type\": \"LBNBPRepo.BusinessPartner\" }, \"AutoAcceptInvitation\": false, \"BpName\": null, \"BpType\": \"OTHERS\", \"CreatedBy\": \"LBN_REMOTE\", \"CreatedOn\": \"2020-06-01T03:50:58.073Z\", \"DataCenterSubdomain\": \"sap\", \"Id\": \"AFAC09E4-E73C-48E1-90BE-7F7495B4BDB5\", \"IsTestData\": false, \"LbnId\": \"10010001003\", \"NetworkVisibility\": false, \"ProfileCompletionStatus\": 0, \"SubDomain\": \"lbn-gtt-samples\", \"TenantId\": \"6a0ea665-88e5-45de-83ec-ddc813e5ba51\", \"UpdatedBy\": null, \"UpdatedOn\": null, \"ValidFrom\": null, \"ValidTo\": null, \"Website\": null, \"HasEditScope\": true, \"AlternateIdDetails\": { \"__deferred\": { \"uri\": \"https://lbnplatform-bprepo-perf.cfapps.sap.hana.ondemand.com:443/bpr/BusinessPartners('AFAC09E4-E73C-48E1-90BE-7F7495B4BDB5')/AlternateIdDetails\" } }, \"BPAccountDetails\": { \"results\": [ { \"__metadata\": { \"id\": \"https://lbnplatform-bprepo-perf.cfapps.sap.hana.ondemand.com:443/bpr/BPAccounts('5b2cdd9e-003d-4c88-970a-816b6d20bf90')\", \"uri\": \"https://lbnplatform-bprepo-perf.cfapps.sap.hana.ondemand.com:443/bpr/BPAccounts('5b2cdd9e-003d-4c88-970a-816b6d20bf90')\", \"type\": \"LBNBPRepo.BPAccount\" }, \"BpAccId\": \"5b2cdd9e-003d-4c88-970a-816b6d20bf90\", \"BpId\": \"AFAC09E4-E73C-48E1-90BE-7F7495B4BDB5\", \"BpType\": \"OTHERS\", \"CreatedBy\": \"LBN_REMOTE\", \"CreatedOn\": \"2020-06-01T03:50:56.867Z\", \"GlobalAccExternalGUID\": \"iotDigitalScm\", \"Status\": \"Active\", \"SubAccExternalGUID\": \"lbn-gtt-samples\", \"SubscribedApp\": \"lbn_gtt_core_perf-app\", \"SubscribedPlan\": \"test\", \"UpdatedBy\": null, \"UpdatedOn\": null, \"BPNetworkRoleTextDetails\": { \"__deferred\": { \"uri\": \"https://lbnplatform-bprepo-perf.cfapps.sap.hana.ondemand.com:443/bpr/BPAccounts('5b2cdd9e-003d-4c88-970a-816b6d20bf90')/BPNetworkRoleTextDetails\" } } } ] }, \"BPGeoCoverageDetails\": { \"__deferred\": { \"uri\": \"https://lbnplatform-bprepo-perf.cfapps.sap.hana.ondemand.com:443/bpr/BusinessPartners('AFAC09E4-E73C-48E1-90BE-7F7495B4BDB5')/BPGeoCoverageDetails\" } }, \"BPIndustryDetails\": { \"__deferred\": { \"uri\": \"https://lbnplatform-bprepo-perf.cfapps.sap.hana.ondemand.com:443/bpr/BusinessPartners('AFAC09E4-E73C-48E1-90BE-7F7495B4BDB5')/BPIndustryDetails\" } }, \"BusinessDataDetails\": { \"__deferred\": { \"uri\": \"https://lbnplatform-bprepo-perf.cfapps.sap.hana.ondemand.com:443/bpr/BusinessPartners('AFAC09E4-E73C-48E1-90BE-7F7495B4BDB5')/BusinessDataDetails\" } }, \"BusinessRelationDetails\": { \"__deferred\": { \"uri\": \"https://lbnplatform-bprepo-perf.cfapps.sap.hana.ondemand.com:443/bpr/BusinessPartners('AFAC09E4-E73C-48E1-90BE-7F7495B4BDB5')/BusinessRelationDetails\" } }, \"CommunicationDataDetails\": { \"__deferred\": { \"uri\": \"https://lbnplatform-bprepo-perf.cfapps.sap.hana.ondemand.com:443/bpr/BusinessPartners('AFAC09E4-E73C-48E1-90BE-7F7495B4BDB5')/CommunicationDataDetails\" } }, \"ContactPersonDetails\": { \"__deferred\": { \"uri\": \"https://lbnplatform-bprepo-perf.cfapps.sap.hana.ondemand.com:443/bpr/BusinessPartners('AFAC09E4-E73C-48E1-90BE-7F7495B4BDB5')/ContactPersonDetails\" } }, \"GeoCoverageDetails\": { \"__deferred\": { \"uri\": \"https://lbnplatform-bprepo-perf.cfapps.sap.hana.ondemand.com:443/bpr/BusinessPartners('AFAC09E4-E73C-48E1-90BE-7F7495B4BDB5')/GeoCoverageDetails\" } }, \"IndustryDetails\": { \"__deferred\": { \"uri\": \"https://lbnplatform-bprepo-perf.cfapps.sap.hana.ondemand.com:443/bpr/BusinessPartners('AFAC09E4-E73C-48E1-90BE-7F7495B4BDB5')/IndustryDetails\" } }, \"NetworkingInterestDetails\": { \"__deferred\": { \"uri\": \"https://lbnplatform-bprepo-perf.cfapps.sap.hana.ondemand.com:443/bpr/BusinessPartners('AFAC09E4-E73C-48E1-90BE-7F7495B4BDB5')/NetworkingInterestDetails\" } }, \"ParameterDetails\": { \"__deferred\": { \"uri\": \"https://lbnplatform-bprepo-perf.cfapps.sap.hana.ondemand.com:443/bpr/BusinessPartners('AFAC09E4-E73C-48E1-90BE-7F7495B4BDB5')/ParameterDetails\" } }, \"BusinessRelationDetails1\": { \"__deferred\": { \"uri\": \"https://lbnplatform-bprepo-perf.cfapps.sap.hana.ondemand.com:443/bpr/BusinessPartners('AFAC09E4-E73C-48E1-90BE-7F7495B4BDB5')/BusinessRelationDetails1\" } } } ] }}";
        given(responseEntity.getBody()).willReturn(bpS);

        given(restTemplate.exchange(Mockito.anyString(), eq(HttpMethod.GET), Mockito.any(), eq(null), Mockito.any())).willReturn(responseEntity);

        PowerMockito.mockStatic(UaaUtils.class);
        when(UaaUtils.requestTechniqueToken(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn("token");

        BusinessPartner bp = bpService.getBPByLBNID("LBN#10010001003");
        assertEquals("LBN#10010001003", bp.getLbnId());

        ObjectValue objectValue = bp.convertToObjectValue();
        assertEquals("AFAC09E4-E73C-48E1-90BE-7F7495B4BDB5", objectValue.getValueAsString("Id"));
    }
}
