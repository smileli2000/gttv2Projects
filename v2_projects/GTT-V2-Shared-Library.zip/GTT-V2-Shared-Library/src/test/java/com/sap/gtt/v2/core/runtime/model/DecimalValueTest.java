package com.sap.gtt.v2.core.runtime.model;

import org.assertj.core.api.Assertions;
import org.junit.Test;

import java.math.BigDecimal;

public class DecimalValueTest {

    @Test
    public void test() {
        DecimalValue val = DecimalValue.valueOf(2.0);
        DecimalValue res = (DecimalValue) val.addInternal(DecimalValue.valueOf(4.0));
        Assertions.assertThat(res.getInternalValue().compareTo(new BigDecimal(6.0)))
                .isEqualTo(0);

        res = (DecimalValue) res.subInternal(DecimalValue.valueOf(2.0));
        Assertions.assertThat(res.getInternalValue().compareTo(new BigDecimal(4.0)))
                .isEqualTo(0);

        res = (DecimalValue) res.mulInternal(DecimalValue.valueOf(2.0));
        Assertions.assertThat(res.getInternalValue().compareTo(new BigDecimal(8.0)))
                .isEqualTo(0);

        res = (DecimalValue) res.divInternal(DecimalValue.valueOf(2.0));
        Assertions.assertThat(res.getInternalValue().compareTo(new BigDecimal(4.0)))
                .isEqualTo(0);

        res = (DecimalValue) res.powInternal(DecimalValue.valueOf(2.0));
        Assertions.assertThat(res.getInternalValue().compareTo(new BigDecimal(16.0)))
                .isEqualTo(0);
    }
}