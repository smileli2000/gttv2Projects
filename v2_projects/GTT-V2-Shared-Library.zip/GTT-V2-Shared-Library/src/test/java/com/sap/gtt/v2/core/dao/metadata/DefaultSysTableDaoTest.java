package com.sap.gtt.v2.core.dao.metadata;

import com.sap.gtt.v2.BaseTest;
import com.sap.gtt.v2.Dummy;
import com.sap.gtt.v2.core.domain.metadata.*;
import com.sap.gtt.v2.core.management.metadata.CsnParser;
import com.sap.gtt.v2.util.DBUtils;
import org.apache.commons.io.IOUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import static com.sap.gtt.v2.core.domain.metadata.MetadataConstants.CdsDataType.*;
import static org.junit.Assert.assertTrue;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = Dummy.class)
@ActiveProfiles("test")
public class DefaultSysTableDaoTest extends BaseTest {

    private static final String DERIVED_CSN_FILE = "derived_csn.json";
    public static final String UTF_8 = "UTF-8";

    @Autowired
    JdbcTemplate jdbcTemplate;

    @Autowired
    DefaultSysTableDao defaultSysTableDao;

    public void setDefaultSysTableDao(DefaultSysTableDao defaultSysTableDao) {
        this.defaultSysTableDao = defaultSysTableDao;
    }
    /**
     * create all the customized tables from derived CSN
     *
     * @throws IOException
     */
    public void createTables() throws IOException {
        String derivedCsn = IOUtils.toString(getClass().getClassLoader()
                .getResourceAsStream(DERIVED_CSN_FILE), UTF_8);
        List<MetadataEntity> entities = CsnParser.parseToEntities(derivedCsn);
        defaultSysTableDao.createTable(entities);
    }

    @Test
    public void createTable() {
        List<MetadataEntity> entities = buildEntities(2);
        defaultSysTableDao.createTable(entities);
        assertTrue(true);

        dropTables(entities);
    }

    @Test
    public void emptyTable() {
        List<MetadataEntity> entities = buildEntities(1);
        defaultSysTableDao.createTable(entities);
        defaultSysTableDao.emptyTable(entities.get(0).getName());
        assertTrue(true);
    }

    @Test
    public void insertCodeList() {
        CodeListValue codeListValue1 = new CodeListValue();
        codeListValue1.setName("Name1");
        codeListValue1.setCode("Code1");
        CodeListValue codeListValue2 = new CodeListValue();
        codeListValue2.setCode("Code2");
        codeListValue2.setName("Name2");
        CodeList codeList = new CodeList();
        codeList.setFullEntityName("com.sap.gtt.core.coremodel.processStatus");
        codeList.addCodeListValue(codeListValue1);
        codeList.addCodeListValue(codeListValue2);
        defaultSysTableDao.insertCodeList(codeList);
        assertTrue(true);
    }

    @Test
    public void insertCodeListTexts() {
        CodeListValue codeListValue1 = new CodeListValue();
        codeListValue1.setName("Name1");
        codeListValue1.setCode("Code1");
        CodeListText codeListText1 = new CodeListText();
        codeListText1.setName("Name1");
        codeListText1.setCode("Code1");
        codeListText1.setLanguage("zh");
        codeListValue1.addCodeListTexts(codeListText1);
        CodeListValue codeListValue2 = new CodeListValue();
        codeListValue2.setCode("Code2");
        codeListValue2.setName("Name2");
        CodeListText codeListText2 = new CodeListText();
        codeListText2.setName("Name2");
        codeListText2.setCode("Code2");
        codeListText2.setLanguage("zh");
        codeListValue2.addCodeListTexts(codeListText2);
        CodeList codeList = new CodeList();
        codeList.setFullEntityName("com.sap.gtt.core.coremodel.processStatus");
        codeList.addCodeListValue(codeListValue1);
        codeList.addCodeListValue(codeListValue2);
        defaultSysTableDao.insertCodeListTexts(codeList);
        assertTrue(true);
    }

    @Test
    public void addTableFieldForNotExistedTable() {
        List<MetadataEntity> entities = buildEntities(1);

        entities.get(0).clearElements();
        MetadataEntityElement newField = new MetadataEntityElement();
        newField.setName("Test1");
        newField.setType(CDS_STRING);
        newField.setLength(10);
        newField.setCustomizedField(true);
        entities.get(0).addElement(newField);

        newField = new MetadataEntityElement();
        newField.setName("Test2");
        newField.setType(CDS_TIMESTAMP);
        newField.setCustomizedField(true);
        entities.get(0).addElement(newField);

        defaultSysTableDao.addTableField(entities);

        dropTables(entities);
    }

    @Test
    public void addTableFieldForExistedTable() {
        List<MetadataEntity> entities = buildEntities(1);
        defaultSysTableDao.createTable(entities);

        entities.get(0).clearElements();
        MetadataEntityElement newField = new MetadataEntityElement();
        newField.setName("Test1");
        newField.setType(CDS_STRING);
        newField.setLength(10);
        newField.setCustomizedField(true);
        entities.get(0).addElement(newField);

        newField = new MetadataEntityElement();
        newField.setName("Test2");
        newField.setType(CDS_TIMESTAMP);
        newField.setCustomizedField(true);
        entities.get(0).addElement(newField);

        defaultSysTableDao.addTableField(entities);

        dropTables(entities);
    }


    @Test
    public void modifyTableField() {
        List<MetadataEntity> entities = buildEntities(1);
        defaultSysTableDao.createTable(entities);

        entities.get(0).clearElements();
        MetadataEntityElement modField = new MetadataEntityElement();

        modField.setName("Name1");
        modField.setType(CDS_STRING);
        modField.setLength(60);
        modField.setCustomizedField(true);
        entities.get(0).addElement(modField);

        modField = new MetadataEntityElement();
        modField.setName("Quantity1");
        modField.setType(CDS_DECIMAL);
        modField.setPrecision(15);
        modField.setScale(4);
        modField.setCustomizedField(true);
        entities.get(0).addElement(modField);

        defaultSysTableDao.modifyTableField(entities);

        dropTables(entities);
    }

    private void dropTables(List<MetadataEntity> entities) {
        List<String> entityNames = entities.stream().map(MetadataEntity::getName).collect(Collectors.toList());
        dropTable(entityNames);
    }

    private List<MetadataEntity> buildEntities(int size) {
        List<MetadataEntity> entities = new ArrayList<>();
        for (int i = 0; i < size; i++) {
            MetadataEntity entity = new MetadataEntity();
            entity.setName("com.sap.cttest" + i);
            entity.setBaseType(MetadataConstants.EntityBaseType.TRACKED_PROCESS.getValue());
            entity.setIncludeCustomizedFields(true);

            MetadataEntityElement e1 = new MetadataEntityElement();
            e1.setName("ID");
            e1.setType(CDS_UUID);
            e1.setKey(true);
            e1.setFromCoreModel(true);
            entity.addElement(e1);

            e1 = new MetadataEntityElement();
            e1.setName("Name1");
            e1.setType(CDS_STRING);
            e1.setLength(50);
            e1.setCustomizedField(true);
            entity.addElement(e1);

            e1 = new MetadataEntityElement();
            e1.setName("CratedAt");
            e1.setType(CDS_TIMESTAMP);
            e1.setFromCoreModel(true);
            entity.addElement(e1);

            e1 = new MetadataEntityElement();
            e1.setName("Time1");
            e1.setType(CDS_TIMESTAMP);
            e1.setCustomizedField(true);
            entity.addElement(e1);

            e1 = new MetadataEntityElement();
            e1.setName("Quantity1");
            e1.setType(CDS_DECIMAL);
            e1.setPrecision(10);
            e1.setScale(3);
            e1.setCustomizedField(true);
            entity.addElement(e1);

            entities.add(entity);
        }
        return entities;
    }

    private void dropTable(List<String> entityNames) {
        List<String> dropTableSql = new ArrayList<>();
        entityNames.forEach(e -> {
            if (!CsnParser.isCoreModelEntity(e)) {
                dropTableSql.add("DROP TABLE " + DBUtils.toTableName(e));
            }
        });
        jdbcTemplate.batchUpdate(dropTableSql.toArray(new String[0]));
    }
}