package com.sap.gtt.v2.controller;

import com.sap.gtt.v2.BaseTest;
import com.sap.gtt.v2.Dummy;
import com.sap.gtt.v2.exception.InternalErrorException;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationCredentialsNotFoundException;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.client.HttpClientErrorException;

import javax.xml.bind.ValidationException;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = Dummy.class, webEnvironment = SpringBootTest.WebEnvironment.NONE)
@ActiveProfiles("test")
public class DefaultExceptionHandlerTest extends BaseTest {

    @Before
    public void setUp() {
        super.setUp();
    }

    @Test
    public void test() {
        Exception[] exceptions = new Exception[]{
                new HttpRequestMethodNotSupportedException(""),
                new HttpMediaTypeNotSupportedException(""),
                new AuthenticationCredentialsNotFoundException(""),
                new ValidationException(""),
                new InternalErrorException(""),
                new HttpClientErrorException(HttpStatus.BAD_REQUEST)
        };
        DefaultExceptionHandler handler = new DefaultExceptionHandler();
        handler.handleExceptionAndTransformMessage(exceptions[0]);
        for (Exception e : exceptions) {
            if (e instanceof InternalErrorException) continue;
            Assertions.assertThat(
                    handler.handleExceptionAndTransformMessage(e))
                    .isNotNull();

            Assertions.assertThat(
                    handler.handleException(e))
                    .isNotNull();
        }
    }
}