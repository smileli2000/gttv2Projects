package com.sap.gtt.v2.exception;


import org.assertj.core.api.Assertions;
import org.junit.Test;

import java.util.Arrays;

public class FormattedErrorMessageTest {

    @Test
    public void test() {
        FormattedErrorMessage formattedErrorMessage = new FormattedErrorMessage(
                "TO_BE_DEFINED",
                "a message",
                500
        );

        formattedErrorMessage.getHttpResponse();
        Assertions.assertThat(formattedErrorMessage.getHttpStatus()).isEqualTo(500);
        formattedErrorMessage.toJsonString();
        Assertions.assertThat(formattedErrorMessage.getError().getCode()).isEqualTo("TO_BE_DEFINED");
        Assertions.assertThat(formattedErrorMessage.getError().getMessage())
                .isEqualTo("a message");
        FormattedErrorMessage container = new FormattedErrorMessage(Arrays.asList(formattedErrorMessage),"en", formattedErrorMessage.getHttpStatus());
        Assertions.assertThat(container.getHttpStatus()).isEqualTo(formattedErrorMessage.getHttpStatus());
        Assertions.assertThat(container.getError().getDetails().get(0).getLang()).isEqualTo("en");
    }
}