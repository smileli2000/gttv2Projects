package com.sap.gtt.v2.core.dao.execution;

import com.sap.gtt.v2.BaseTest;
import com.sap.gtt.v2.Dummy;
import com.sap.gtt.v2.core.domain.execution.ExecutionStatus;
import com.sap.gtt.v2.core.entity.execution.RequestMapping;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = Dummy.class)
@ActiveProfiles("test")
public class DefaultRequestMappingDaoTest extends BaseTest {
    private DefaultRequestMappingDao mappingDao;

    @Before
    public void setUp() {
        super.setUp();
        mappingDao = DefaultRequestMappingDao.getInstance();
    }

    @Test
    public void test() {
        String requestId = "requestId";
        RequestMapping requestMapping = new RequestMapping("id", requestId, requestId, null, ExecutionStatus.ERROR.name(), "messageCode", "detail");
        mappingDao.insert(requestMapping);
        List<RequestMapping> queryResult = mappingDao.queryRequestMappings(requestId);
        Assertions.assertThat(queryResult.size()).isEqualTo(1);
        RequestMapping mappingRst = queryResult.get(0);
        Assertions.assertThat(mappingRst.getId()).isEqualTo(requestMapping.getId());
        Assertions.assertThat(mappingRst.getMessageType()).isEqualTo(requestMapping.getMessageType());
    }
}
