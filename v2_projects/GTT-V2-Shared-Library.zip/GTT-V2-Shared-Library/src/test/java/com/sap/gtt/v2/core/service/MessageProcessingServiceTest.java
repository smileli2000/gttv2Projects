package com.sap.gtt.v2.core.service;

import com.sap.gtt.v2.Dummy;
import com.sap.gtt.v2.configuration.ISAPCloudPlatformAgent.ICurrentAccessContext;
import com.sap.gtt.v2.configuration.local.LocalMockedCurrentAccessContext;
import com.sap.gtt.v2.core.dao.tracking.IEventDao;
import com.sap.gtt.v2.core.domain.execution.ExecutionDto;
import com.sap.gtt.v2.core.domain.execution.ExecutionMessageDto;
import com.sap.gtt.v2.core.domain.execution.ExecutionStatus;
import com.sap.gtt.v2.core.domain.execution.Phase;
import com.sap.gtt.v2.core.domain.metadata.*;
import com.sap.gtt.v2.core.domain.trackedprocess.*;
import com.sap.gtt.v2.core.entity.trackedprocess.*;
import com.sap.gtt.v2.core.management.execution.IMessageLogManagement;
import com.sap.gtt.v2.core.management.metadata.CsnParser;
import com.sap.gtt.v2.core.management.metadata.IMetadataManagement;
import com.sap.gtt.v2.core.management.tracking.IEventManagement;
import com.sap.gtt.v2.core.management.tracking.ITrackedProcessManagement;
import com.sap.gtt.v2.core.rule.impl.GTTEmbededRuleScriptLauncher;
import com.sap.gtt.v2.core.runtime.model.TimestampValue;
import com.sap.gtt.v2.core.runtime.model.UUIDValue;
import com.sap.gtt.v2.exception.BaseRuntimeException;
import com.sap.gtt.v2.exception.GTTEmbededRuleScriptInternalException;
import com.sap.gtt.v2.exception.HttpStatus4xxException;
import com.sap.gtt.v2.exception.InternalErrorException;
import com.sap.gtt.v2.log.TenantAwareLogService;
import com.sap.gtt.v2.util.GTTUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.IOException;
import java.nio.charset.Charset;
import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import static com.sap.gtt.v2.core.domain.metadata.MetadataConstants.CoreModelEntity.*;
import static com.sap.gtt.v2.core.domain.trackedprocess.Constant.REF_PLANNED_EVENT_MATCH_KEY;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.*;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = Dummy.class)
@ActiveProfiles("test")
public class MessageProcessingServiceTest {
    public static final String REF_PLANNED_EVENT_TYPE = "refPlannedEventType";
    public static final String REF_PLANNED_EVENT_LOCATION_ALT_KEY = "refPlannedEventLocationAltKey";
    @Mock
    private ICurrentAccessContext currentAccessContext;
    @Mock
    private GTTEmbededRuleScriptLauncher ruleScriptLauncher;
    @InjectMocks
    private MessageProcessingAsync messageProcessingAsync = new MessageProcessingAsync();
    @InjectMocks
    private MessageProcessingServiceImpl service = new MessageProcessingServiceImpl();
    @Mock
    private TenantAwareLogService logService;
    @Mock
    private MessageValidation messageValidation;
    private IMetadataManagement metadataManagement;
    private ITrackedProcessManagement processManagement;
    private IEventManagement eventManagement;
    private IMessageLogManagement executionHistoryManagement;

    private Event processEventMessage;

    private Event eventMessage;

    private String derivedCsnFile = "derived_csn.json";

    private Map<String, MetadataEntity> entityMap;

    @Mock
    private IEventDao eventDao;

    @Before
    public void setup() throws IOException {
        service.setProcessingAsync(messageProcessingAsync);
        String derivedCsn = IOUtils.toString(getClass().getClassLoader()
                .getResourceAsStream(derivedCsnFile), Charset.defaultCharset());
        entityMap = CsnParser.parseToEntityMap(derivedCsn);
        metadataManagement = mock(IMetadataManagement.class);
        processManagement = mock(ITrackedProcessManagement.class);
        eventManagement = mock(IEventManagement.class);
        executionHistoryManagement = mock(IMessageLogManagement.class);
        GTTUtils.BusinessOperator businessOperator = mock(GTTUtils.BusinessOperator.class);
        given(businessOperator.getMetadataManagement()).willReturn(metadataManagement);
        given(businessOperator.getTrackedProcessManagement()).willReturn(processManagement);
        given(businessOperator.getEventManagement()).willReturn(eventManagement);
        given(businessOperator.getMessageLogManagement()).willReturn(executionHistoryManagement);
        given(currentAccessContext.createBusinessOperator()).willReturn(businessOperator);
        Mockito.when(metadataManagement.findAllEntitiesRecursively(Mockito.anyString(), Mockito.anyString()))
                .thenAnswer(new Answer<CurrentMetadataEntity>() {
                    public CurrentMetadataEntity answer(InvocationOnMock invocation) {
                        String entityName = invocation.getArgument(1);
                        return getMetadata(entityName);
                    }
                });
       /* String bpNumber = "666666";
        BusinessPartner businessPartner = new BusinessPartner();
        businessPartner.setId(GTTUtils.UUIDUtils.generateNameBasedUUID(bpNumber).toString());
        businessPartner.setSubaccountId(bpNumber);
        businessPartner.setBpNumber(bpNumber);*/
        given(currentAccessContext.getSubaccountId()).willReturn(LocalMockedCurrentAccessContext.TENANT_SUBACCOUNT_ID);
        given(currentAccessContext.getCloneServiceInstanceId()).willReturn(LocalMockedCurrentAccessContext.CLONE_SERVICE_INSTANCE_ID);
        //given(bpService.getFromSubaccountId(Mockito.anyString())).willReturn(businessPartner);
        //given(bpService.getFromBPNumber(Mockito.anyString())).willReturn(businessPartner);
        doNothing().when(messageValidation).validate(anyList(), Mockito.anyString(), Mockito.anyString());
    }

    private CurrentMetadataEntity getMetadata(String entityName) {
        CurrentMetadataEntity currentMetadataEntity = new CurrentMetadataEntity();
        currentMetadataEntity.setCurrentEntityName(entityName);
        currentMetadataEntity.setAllRelatedEntityMap(entityMap);
        return currentMetadataEntity;
    }

    private void prepareProcessEventMessage() {
        processEventMessage = new Event();
        processEventMessage.setId(UUID.randomUUID());
        processEventMessage.setModelNamespace("com.sap.gtt.app.mim");
        processEventMessage.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemEvent");
        processEventMessage.setAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:ProcurementOrderItem:1");
        processEventMessage.setId(GTTUtils.UUIDUtils.generateNameBasedUUID(processEventMessage.getAltKey()));
        processEventMessage.setEventReasonText("External API Event");
        processEventMessage.setLocationAltKey("location-alt-key");
        processEventMessage.setSenderPartyId(GTTUtils.UUIDUtils.generateTimeBasedUUID().toString());
        processEventMessage.setSubaccountId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        processEventMessage.setCloneInstanceId(null);
        processEventMessage.setMessageSourceType("messageSourceType");
        processEventMessage.setActualBusinessTimestamp(Instant.now());
        processEventMessage.setActualBusinessTimeZone("CET");
        processEventMessage.setValue("procurementOrderNO", "1211031264");
        processEventMessage.setValue("itemNO", "2345");
        processEventMessage.setValue("ScheduleLine", "0001");
        //SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        processEventMessage.setValue("supplierId", "supplier");
        processEventMessage.setValue("materialId", "material");
        processEventMessage.setValue("receivingLocationId", "location");
        processEventMessage.setValue("plannedDeliveryDate", Instant.parse("2018-07-09T09:00:00.213Z"));
        processEventMessage.setValue("earlistETA", Instant.parse("2018-07-09T09:00:00.213Z"));
        processEventMessage.setValue("procurementOrderItemQty", 3.0);
        processEventMessage.setValue("goodsReceivedQty", 2.0);
        processEventMessage.setValue("procurementOrderItemUOM", "M3");
        processEventMessage.setValue("goodsReceivedUOM", "KG");

        CurrentMetadataEntity referenceMetadata = getMetadata("com.sap.gtt.core.CoreModel.Reference");
        List<Reference> references = new ArrayList<>();
        Reference ref = new Reference();
        ref.setMetadata(referenceMetadata);
        ref.setAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:DEL_NO:99");
        ref.setReferenceType("TRACKING");
        ref.setValidFrom(Instant.parse("1970-01-03T00:00:00Z"));
        ref.setValidTo(Instant.parse("9999-12-31T00:00:00Z"));
        ref.setAction(Action.ADD.toString());
        references.add(ref);
        Reference ref2 = new Reference();
        ref2.setMetadata(referenceMetadata);
        ref2.setAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:DEL_NO:100");
        ref2.setReferenceType("TRACKING");
        ref2.setValidFrom(Instant.parse("1970-01-03T00:00:00Z"));
        ref2.setValidTo(Instant.parse("9999-12-31T00:00:00Z"));
        ref2.setAction(Action.ADD.toString());
        references.add(ref2);
        processEventMessage.setReferences(references);

        CurrentMetadataEntity peMetadata =
                getMetadata("com.sap.gtt.core.CoreModel.PlannedEvent");
        List<PlannedEvent> plannedEvents = new ArrayList<>();
        //SimpleDateFormat sdf3 = new SimpleDateFormat("yyyy-mm-dd HH:mm:ss.SSS");
        PlannedEvent pe = new PlannedEvent();
        pe.setMetadata(peMetadata);
        pe.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POConfirmedEvent");
        pe.setEventMatchKey("10");
        pe.setLocationAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:Location:shippingPoint:4711");
        pe.setPlannedTechnicalTimestamp(Instant.parse("2018-07-09T12:00:00.213Z"));
        pe.setPlannedBusinessTimestamp(Instant.parse("2018-07-09T09:00:00.213Z"));
        pe.setPlannedTechTsLatest(Instant.parse("2018-07-20T09:00:00.213Z"));
        plannedEvents.add(pe);
        PlannedEvent pe2 = new PlannedEvent();
        pe2.setMetadata(peMetadata);
        pe2.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POGoodsReceivedEvent");
        pe2.setEventMatchKey("20");
        pe2.setLocationAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:Location:shippingPoint:4711");
        pe2.setPlannedTechnicalTimestamp(Instant.parse("2018-07-09T12:00:00.213Z"));
        pe2.setPlannedBusinessTimestamp(Instant.parse("2018-07-09T09:00:00.213Z"));
        pe2.setPlannedTechTsLatest(Instant.parse("2018-07-20T09:00:00.213Z"));
        pe2.setPlannedBusinessTimeZone("CET");
        plannedEvents.add(pe2);
        processEventMessage.setPlannedEvents(plannedEvents);
        processEventMessage.setMetadata(getMetadata(processEventMessage.getEventType()));
    }

    private void prepareEventMessage() {
        eventMessage = new Event();
        eventMessage.setId(UUID.randomUUID());
        eventMessage.setAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:ProcurementOrderItem:1211031264");
        eventMessage.setEventReasonText("External API Event");
        eventMessage.setLocationAltKey("location-alt-key");
        eventMessage.setModelNamespace("com.sap.gtt.app.mim");
        eventMessage.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POConfirmedEvent");
        eventMessage.setEventMatchKey("10");
        eventMessage.setSenderPartyId(GTTUtils.UUIDUtils.generateTimeBasedUUID().toString());
        eventMessage.setSubaccountId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        eventMessage.setCloneInstanceId(null);
        eventMessage.setMessageSourceType("messageSourceType");
        eventMessage.setActualBusinessTimestamp(Instant.parse("2018-07-09T09:00:00.213Z"));
        eventMessage.setActualBusinessTimeZone("CET");

        CurrentMetadataEntity referenceMetadata = getMetadata("com.sap.gtt.core.CoreModel.Reference");
        List<Reference> eventReferences = new ArrayList<>();
        Reference eref = new Reference();
        eref.setMetadata(referenceMetadata);
        eref.setAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:OBP10_PO:12");
        eref.setReferenceType("TRACKING");
        eref.setAction(Action.ADD.toString());
        //first add validFrom and validTo, remove later
        eref.setValidFrom(Instant.parse("1970-01-03T00:00:00Z"));
        eref.setValidTo(Instant.parse("9999-12-31T00:00:00Z"));
        eventReferences.add(eref);
        Reference eref2 = new Reference();
        eref2.setMetadata(referenceMetadata);
        eref2.setAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:OBP10_PO:13");
        eref2.setReferenceType("TRACKING");
        eref2.setAction(Action.ADD.toString());
        eref2.setValidFrom(Instant.parse("1970-01-03T00:00:00Z"));
        eref2.setValidTo(Instant.parse("9999-12-31T00:00:00Z"));
        eventReferences.add(eref2);
        eventMessage.setReferences(eventReferences);
        eventMessage.setMetadata(getMetadata(eventMessage.getEventType()));
    }
    @Test
    public void validateAuthorizationTest(){
        Event event = new Event();
        UUID eventId = UUID.randomUUID();
        event.setId(eventId);
        event.setAltKey("altkey");
        event.setEventType("eventType");
        event.setEventMatchKey("eventMatchKey");
        event.setModelNamespace("namespace");
        event.setSenderPartyId("88888888");
        Instant now = Instant.now();
        event.setActualBusinessTimestamp(now);
        MetadataEntity metadataEntity = mock(MetadataEntity.class);
        given(metadataEntity.isProcessEvent()).willReturn(false);
        CurrentMetadataEntity metadata = mock(CurrentMetadataEntity.class);
        given(metadata.getCurrentEntity()).willReturn(metadataEntity);
        given(metadata.isEnableInstanceBasedAuthorization()).willReturn(true);
        event.setMetadata(metadata);
        given(eventManagement.get(Mockito.any())).willReturn(event);

        TrackedProcess tp = new TrackedProcess();
        String trackedProcessType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        tp.setMetadata(getMetadata(trackedProcessType));
        tp.setTrackedProcessType(trackedProcessType);
        tp.setPartyId("88888888");
        UUID tpId = GTTUtils.UUIDUtils.generateTimeBasedUUID();
        tp.setId(tpId);
        tp.setAltKey("altkey");
        tp.setProcessStatus(ProcessStatus.AS_PLANNED.name());
        List<PlannedEvent> pes = new ArrayList<>();
        PlannedEvent plannedEvent = new PlannedEvent();
        plannedEvent.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.PlannedEvent"));
        plannedEvent.setId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        plannedEvent.setEventType("eventType");
        plannedEvent.setEventMatchKey("eventMatchType");
        plannedEvent.setPlannedTechTsLatest(Instant.parse("2018-07-09T12:00:00.213Z"));
        plannedEvent.setPlannedBusinessTimestamp(Instant.parse("2018-07-09T12:00:00.213Z"));
        plannedEvent.setPlannedBizTsEarliest(Constant.MIN_TIMESTAMP);
        plannedEvent.setPlannedBizTsLatest(Constant.MAX_TIMESTAMP);
        plannedEvent.setIsFinalPlannedEvent(Boolean.FALSE);
        plannedEvent.setLastProcessEventDirectoryId(null);
        plannedEvent.setEventStatus(EventStatus.PLANNED.name());
        pes.add(plannedEvent);
        tp.setPlannedEvents(pes);
        List<QualifiedTrackingId> trackingIds = new ArrayList<>();
        QualifiedTrackingId trackingId = QualifiedTrackingId.build(tpId, tpId, null, null);
        trackingId.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.QualifiedTrackingId"));
        trackingIds.add(trackingId);
        tp.setTrackingIds(trackingIds);
        List<ProcessEventDirectory> peds = new ArrayList<>();
        ProcessEventDirectory ped = ProcessEventDirectory.build(GTTUtils.UUIDUtils.generateTimeBasedUUID(),
                tpId, null, GTTUtils.UUIDUtils.generateTimeBasedUUID(), CorrelationType.UNPLANNED_PROCESS_CREATION_UPDATE.name());
        peds.add(ped);
        tp.setPEDs(peds);
        given(processManagement.getWithOnlyValidDPPStatus(Mockito.any(UUIDValue.class))).willReturn(tp);

        MetadataEntityEvent eventConfig = new MetadataEntityEvent();
        eventConfig.setMatchLocation(false);
        given(metadataManagement.getEntityEvent(Mockito.anyString(), Mockito.anyString())).willReturn(eventConfig);
        service.reprocess(eventId.toString(), tpId.toString());

    }
    @Test
    //1
    public void createNewTP() {
        prepareProcessEventMessage();
        List<Event> processEventMessages = new ArrayList<>();
        processEventMessages.add(processEventMessage);

        MetadataEntityEvent eventConfig = new MetadataEntityEvent();
        eventConfig.setTechnicalToleranceValue(null);
        eventConfig.setBusinessToleranceValue(null);
        given(metadataManagement.getEntityEvent(Mockito.anyString(), Mockito.anyString())).willReturn(eventConfig);

        String trackedProcessType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        MetadataEntity tpEntity = entityMap.get(trackedProcessType);
        given(metadataManagement.getTrackedProcessEntityByEventType(Mockito.anyString(), eq(processEventMessage.getEventType()))).willReturn(tpEntity);

        service.processEvents(processEventMessages, "requestId", "writeServiceId");

        verify(eventManagement, times(1)).post(Mockito.anyList());
        ArgumentCaptor<TrackedProcess> argumentCaptor = ArgumentCaptor.forClass(TrackedProcess.class);
        verify(processManagement, times(1)).create(argumentCaptor.capture());
        TrackedProcess tpRst = argumentCaptor.<List<String>>getValue();
        List<PlannedEvent> plannedEvents = tpRst.getPlannedEvents();
        assertThat(plannedEvents.size()).isEqualTo(2);
        assertThat(tpRst.getTrackingIds().size()).isEqualTo(3);
    }

    @Test
    //2
    public void updateTPToUpdatePlannedEventsAndTrackingIds() {
        prepareProcessEventMessage();
        TrackedProcess existedTP = new TrackedProcess();
        String trackedProcessType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        existedTP.setMetadata(getMetadata(trackedProcessType));
        existedTP.setTrackedProcessType(trackedProcessType);
        existedTP.setAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:ProcurementOrderItem:1");
        existedTP.setId(GTTUtils.UUIDUtils.generateNameBasedUUID(processEventMessage.getAltKey()));
        existedTP.setScheme("xri://sap.com/sapdoc");
        existedTP.setPartyId("666666");
        existedTP.setLogicalSystem("Q8JCLNT774");
        existedTP.setTrackingIdType("DEL_NO");
        existedTP.setTrackingId("1211031264");
        existedTP.setSubaccountId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        existedTP.setCloneInstanceId(null);
        existedTP.setLifeCycleStatus(LifeCycleStatus.BUSINESS_ACTIVE);
        existedTP.setValue("procurementOrderNO", "1211031264");
        existedTP.setValue("itemNO", "2345");
        existedTP.setValue("scheduleLine", "0001");
        //SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        existedTP.setValue("supplierId", "supplier");
        existedTP.setValue("materialId", "material");
        existedTP.setValue("receivingLocationId", "location");
        existedTP.setValue("plannedDeliveryDate", Instant.parse("2018-07-09T09:00:00.213Z"));
        existedTP.setValue("earlistETA", Instant.parse("2018-07-09T09:00:00.213Z"));
        existedTP.setValue("procurementOrderItemQty", 3.0);
        existedTP.setValue("goodsReceivedQty", 2.0);
        existedTP.setValue("procurementOrderItemUOM", "M3");
        existedTP.setValue("goodsReceivedUOM", "KG");
        existedTP.setCreationDateTime(Instant.parse("2018-06-09T00:00:00Z"));
        existedTP.setCreatedByUser("aaa");
        existedTP.setLastChangedAtBusinessTime(Instant.now().minusSeconds(600));
        List<QualifiedTrackingId> trackingIds = new ArrayList<>();
        CurrentMetadataEntity metadataOfQualifiedTrackingId = getMetadata(MetadataConstants.CoreModelEntity.QUALIFIED_TRACKING_ID.getFullName());
        QualifiedTrackingId trackingId0 = new QualifiedTrackingId();
        trackingId0.setMetadata(metadataOfQualifiedTrackingId);
        UUID processId = existedTP.getIdAsInternalValue();
        trackingId0.setProcessId(processId);
        trackingId0.setObservedProcessId(existedTP.getIdAsInternalValue());
        trackingId0.setValidFrom(null);
        trackingId0.setValidTo(null);
        trackingIds.add(trackingId0);
        QualifiedTrackingId trackingId1 = new QualifiedTrackingId();
        trackingId1.setMetadata(metadataOfQualifiedTrackingId);
        trackingId1.setProcessId(processId);
        trackingId1.setObservedProcessId(
                GTTUtils.UUIDUtils.generateNameBasedUUID("xri://sap.com/sapdoc:666666:Q8JCLNT774:DEL_NO:99"));
        trackingId1.setValidFrom(Instant.parse("1970-01-03T00:00:00Z"));
        trackingId1.setValidTo(Instant.parse("9999-12-31T00:00:00Z"));
        trackingIds.add(trackingId1);
        QualifiedTrackingId trackingId2 = new QualifiedTrackingId();
        trackingId2.setMetadata(metadataOfQualifiedTrackingId);
        trackingId2.setProcessId(processId);
        trackingId2.setObservedProcessId(
                GTTUtils.UUIDUtils.generateNameBasedUUID("xri://sap.com/sapdoc:666666:Q8JCLNT774:DEL_NO:100"));
        trackingId2.setValidFrom(Instant.parse("1970-01-03T00:00:00Z"));
        trackingId2.setValidTo(Instant.parse("9999-12-31T00:00:00Z"));
        trackingIds.add(trackingId2);
        existedTP.setTrackingIds(trackingIds);
        List<PlannedEvent> plannedEvents = new ArrayList<>();
        CurrentMetadataEntity metadataForPlannedEvent = getMetadata(MetadataConstants.CoreModelEntity.PLANNED_EVENT.getFullName());
        PlannedEvent pe1 = new PlannedEvent();
        pe1.setMetadata(metadataForPlannedEvent);
        pe1.setId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        pe1.setProcessId(existedTP.getId());
        pe1.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POConfirmedEvent");
        pe1.setEventMatchKey("10");
        pe1.setNextOverdueDetection(Instant.now());
        pe1.setOverdueDetectionCounter(0);
        pe1.setPlannedTechnicalTimestamp(Instant.parse("2018-07-09T12:00:00.213Z"));
        pe1.setPlannedTechTsEarliest(Instant.parse("2018-07-09T12:00:00.213Z"));
        pe1.setPlannedTechTsLatest(Instant.parse("2018-07-09T12:00:00.213Z"));
        pe1.setPlannedBusinessTimestamp(Instant.parse("2018-07-09T09:00:00.213Z"));
        pe1.setPlannedBizTsEarliest(Instant.parse("2018-07-09T09:00:00.213Z"));
        pe1.setPlannedBizTsLatest(Instant.parse("2018-07-09T09:00:00.213Z"));
        pe1.setPlannedBusinessTimeZone("CET");
        pe1.setPayloadSequence(1);
        pe1.setLastProcessEventDirectoryId(null);
        pe1.setEventStatus(EventStatus.REPORTED.name());
        plannedEvents.add(pe1);
        PlannedEvent pe2 = new PlannedEvent();
        pe2.setMetadata(metadataForPlannedEvent);
        pe2.setId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        pe2.setProcessId(existedTP.getId());
        pe2.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POGoodsReceivedEvent");
        pe2.setEventMatchKey("20");
        pe2.setNextOverdueDetection(Instant.now());
        pe2.setOverdueDetectionCounter(0);
        pe2.setPlannedTechnicalTimestamp(Instant.parse("2018-07-08T12:00:00.213Z"));
        pe2.setPlannedTechTsEarliest(Instant.parse("2018-07-08T12:00:00.213Z"));
        pe2.setPlannedTechTsLatest(Instant.parse("2018-07-08T12:00:00.213Z"));
        pe2.setPlannedBusinessTimestamp(Instant.parse("2018-07-08T09:00:00.213Z"));
        pe2.setPlannedBizTsEarliest(Instant.parse("2018-07-08T09:00:00.213Z"));
        pe2.setPlannedBizTsLatest(Instant.parse("2018-07-08T09:00:00.213Z"));
        pe2.setPlannedBusinessTimeZone("CET");
        pe2.setPayloadSequence(2);
        pe2.setLastProcessEventDirectoryId(null);
        pe2.setEventStatus(EventStatus.PLANNED.name());
        plannedEvents.add(pe2);
        existedTP.setPlannedEvents(plannedEvents);
        List<ProcessEventDirectory> eventDirectories = new ArrayList<>();
        ProcessEventDirectory eventDirectory = new ProcessEventDirectory();
        eventDirectory.setMetadata(getMetadata(MetadataConstants.CoreModelEntity.PROCESS_EVENT_DIRECTORY.getFullName()));
        eventDirectory.setId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        eventDirectory.setProcessId(processId);
        eventDirectory.setPlannedEventId(pe1.getId());
        eventDirectory.setEventId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        eventDirectories.add(eventDirectory);
        existedTP.setPEDs(eventDirectories);
        MetadataEntity tpEntity = entityMap.get(trackedProcessType);
        given(metadataManagement.getTrackedProcessEntityByEventType(Mockito.anyString(), eq(processEventMessage.getEventType()))).willReturn(tpEntity);
        given(processManagement.get(any(CurrentMetadataEntity.class), Mockito.any(UUIDValue.class))).willReturn(existedTP);
        MetadataEntityEvent eventConfig1 = new MetadataEntityEvent();
        eventConfig1.setTechnicalToleranceValue(null);
        eventConfig1.setBusinessToleranceValue(null);
        eventConfig1.setMatchLocation(true);
        MetadataEntityEvent eventConfig2 = new MetadataEntityEvent();
        eventConfig2.setTechnicalToleranceValue(null);
        eventConfig2.setBusinessToleranceValue(null);
        eventConfig2.setMatchLocation(false);
        given(metadataManagement.getEntityEvent(Mockito.anyString(), Mockito.contains("POConfirmedEvent"))).willReturn(eventConfig1);
        given(metadataManagement.getEntityEvent(Mockito.anyString(), Mockito.contains("POGoodsReceivedEvent"))).willReturn(eventConfig2);
        processEventMessage.getReferences().get(0).setAction(Action.DELETE.toString());
        processEventMessage.getReferences().get(1).setAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:DEL_NO:101");
        List<Event> messages = new ArrayList<>();
        messages.add(processEventMessage);
        service.processEvents(messages, "requestId", "writeServiceId");
        verify(eventManagement, times(1)).post(Mockito.anyList());
        ArgumentCaptor<TrackedProcess> argumentCaptorForTP = ArgumentCaptor.forClass(TrackedProcess.class);
        ArgumentCaptor<ProcessEventDirectory> argumentCaptorForPED = ArgumentCaptor.forClass(ProcessEventDirectory.class);
        verify(processManagement, times(1)).update(argumentCaptorForTP.capture(), argumentCaptorForPED.capture(), eq(null));
        TrackedProcess tpRst = argumentCaptorForTP.<List<String>>getValue();

        plannedEvents = tpRst.getPlannedEvents();
        assertThat(plannedEvents.size()).isEqualTo(3);
        assertThat(tpRst.getTrackingIds().size()).isEqualTo(3);
        assertThat(argumentCaptorForPED.getValue()).isNotNull();
    }

    @Test
    //test actualTechnicalTs at the same time
    public void ignoreProcessEventWhenMisorder() {
        prepareProcessEventMessage();
        processEventMessage.setActualTechnicalTimestamp(Instant.now());
        TrackedProcess existedTP = new TrackedProcess();
        String trackedProcessType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        existedTP.setMetadata(getMetadata(trackedProcessType));
        existedTP.setTrackedProcessType(trackedProcessType);
        existedTP.setAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:ProcurementOrderItem:1");
        existedTP.setId(GTTUtils.UUIDUtils.generateNameBasedUUID(processEventMessage.getAltKey()));
        existedTP.setScheme("xri://sap.com/sapdoc");
        existedTP.setPartyId("666666");
        existedTP.setLogicalSystem("Q8JCLNT774");
        existedTP.setTrackingIdType("DEL_NO");
        existedTP.setTrackingId("1211031264");
        existedTP.setSubaccountId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        existedTP.setCloneInstanceId(null);
        existedTP.setValue("procurementOrderNO", "1211031264");
        existedTP.setValue("itemNO", "2345");
        existedTP.setValue("scheduleLine", "0001");
        //SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        existedTP.setValue("supplierId", "supplier");
        existedTP.setValue("materialId", "material");
        existedTP.setValue("receivingLocationId", "location");
        existedTP.setValue("plannedDeliveryDate", Instant.parse("2018-07-09T09:00:00.213Z"));
        existedTP.setValue("earlistETA", Instant.parse("2018-07-09T09:00:00.213Z"));
        existedTP.setValue("procurementOrderItemQty", 3.0);
        existedTP.setValue("goodsReceivedQty", 2.0);
        existedTP.setValue("procurementOrderItemUOM", "M3");
        existedTP.setValue("goodsReceivedUOM", "KG");
        existedTP.setCreationDateTime(Instant.parse("2018-06-09T00:00:00Z"));
        existedTP.setCreatedByUser("aaa");
        existedTP.setLastChangedAtBusinessTime(Instant.now().plusSeconds(60));

        List<QualifiedTrackingId> trackingIds = new ArrayList<>();
        CurrentMetadataEntity metadataOfQualifiedTrackingId = getMetadata(MetadataConstants.CoreModelEntity.QUALIFIED_TRACKING_ID.getFullName());
        QualifiedTrackingId trackingId0 = new QualifiedTrackingId();
        trackingId0.setMetadata(metadataOfQualifiedTrackingId);
        UUID processId = existedTP.getIdAsInternalValue();
        trackingId0.setProcessId(processId);
        trackingId0.setObservedProcessId(existedTP.getIdAsInternalValue());
        trackingId0.setValidFrom(null);
        trackingId0.setValidTo(null);
        trackingIds.add(trackingId0);
        QualifiedTrackingId trackingId1 = new QualifiedTrackingId();
        trackingId1.setMetadata(metadataOfQualifiedTrackingId);
        trackingId1.setProcessId(processId);
        trackingId1.setObservedProcessId(
                GTTUtils.UUIDUtils.generateNameBasedUUID("xri://sap.com/sapdoc:666666:Q8JCLNT774:DEL_NO:99"));
        trackingId1.setValidFrom(Instant.parse("1970-01-03T00:00:00Z"));
        trackingId1.setValidTo(Instant.parse("9999-12-31T00:00:00Z"));
        trackingIds.add(trackingId1);
        QualifiedTrackingId trackingId2 = new QualifiedTrackingId();
        trackingId2.setMetadata(metadataOfQualifiedTrackingId);
        trackingId2.setProcessId(processId);
        trackingId2.setObservedProcessId(
                GTTUtils.UUIDUtils.generateNameBasedUUID("xri://sap.com/sapdoc:666666:Q8JCLNT774:DEL_NO:100"));
        trackingId2.setValidFrom(Instant.parse("1970-01-03T00:00:00Z"));
        trackingId2.setValidTo(Instant.parse("9999-12-31T00:00:00Z"));
        trackingIds.add(trackingId2);
        existedTP.setTrackingIds(trackingIds);
        List<PlannedEvent> plannedEvents = new ArrayList<>();
        CurrentMetadataEntity metadataForPlannedEvent = getMetadata(MetadataConstants.CoreModelEntity.PLANNED_EVENT.getFullName());
        PlannedEvent pe1 = new PlannedEvent();
        pe1.setMetadata(metadataForPlannedEvent);
        pe1.setId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        pe1.setProcessId(existedTP.getId());
        pe1.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POConfirmedEvent");
        pe1.setEventMatchKey("10");
        pe1.setNextOverdueDetection(Instant.now());
        pe1.setOverdueDetectionCounter(0);
        pe1.setPlannedTechnicalTimestamp(Instant.parse("2018-07-09T12:00:00.213Z"));
        pe1.setPlannedTechTsEarliest(Instant.parse("2018-07-09T12:00:00.213Z"));
        pe1.setPlannedTechTsLatest(Instant.parse("2018-07-09T12:00:00.213Z"));
        pe1.setPlannedBusinessTimestamp(Instant.parse("2018-07-09T09:00:00.213Z"));
        pe1.setPlannedBizTsEarliest(Instant.parse("2018-07-09T09:00:00.213Z"));
        pe1.setPlannedBizTsLatest(Instant.parse("2018-07-09T09:00:00.213Z"));
        pe1.setPlannedBusinessTimeZone("CET");
        pe1.setPayloadSequence(1);
        pe1.setLastProcessEventDirectoryId(null);
        pe1.setEventStatus(EventStatus.REPORTED.name());
        plannedEvents.add(pe1);
        PlannedEvent pe2 = new PlannedEvent();
        pe2.setMetadata(metadataForPlannedEvent);
        pe2.setId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        pe2.setProcessId(existedTP.getId());
        pe2.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POGoodsReceivedEvent");
        pe2.setEventMatchKey("20");
        pe2.setNextOverdueDetection(Instant.now());
        pe2.setOverdueDetectionCounter(0);
        pe2.setPlannedTechnicalTimestamp(Instant.parse("2018-07-08T12:00:00.213Z"));
        pe2.setPlannedTechTsEarliest(Instant.parse("2018-07-08T12:00:00.213Z"));
        pe2.setPlannedTechTsLatest(Instant.parse("2018-07-08T12:00:00.213Z"));
        pe2.setPlannedBusinessTimestamp(Instant.parse("2018-07-08T09:00:00.213Z"));
        pe2.setPlannedBizTsEarliest(Instant.parse("2018-07-08T09:00:00.213Z"));
        pe2.setPlannedBizTsLatest(Instant.parse("2018-07-08T09:00:00.213Z"));
        pe2.setPlannedBusinessTimeZone("CET");
        pe2.setPayloadSequence(2);
        pe2.setLastProcessEventDirectoryId(null);
        pe2.setEventStatus(EventStatus.PLANNED.name());
        plannedEvents.add(pe2);
        existedTP.setPlannedEvents(plannedEvents);
        List<ProcessEventDirectory> eventDirectories = new ArrayList<>();
        ProcessEventDirectory eventDirectory = new ProcessEventDirectory();
        eventDirectory.setMetadata(getMetadata(MetadataConstants.CoreModelEntity.PROCESS_EVENT_DIRECTORY.getFullName()));
        eventDirectory.setId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        eventDirectory.setProcessId(processId);
        eventDirectory.setPlannedEventId(pe1.getId());
        eventDirectory.setEventId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        eventDirectories.add(eventDirectory);
        existedTP.setPEDs(eventDirectories);
        MetadataEntity tpEntity = entityMap.get(trackedProcessType);
        given(metadataManagement.getTrackedProcessEntityByEventType(Mockito.anyString(), eq(processEventMessage.getEventType()))).willReturn(tpEntity);
        given(processManagement.get(any(CurrentMetadataEntity.class), Mockito.any(UUIDValue.class))).willReturn(existedTP);

        MetadataEntityEvent eventConfig1 = new MetadataEntityEvent();
        eventConfig1.setTechnicalToleranceValue(null);
        eventConfig1.setBusinessToleranceValue(null);
        eventConfig1.setMatchLocation(true);
        MetadataEntityEvent eventConfig2 = new MetadataEntityEvent();
        eventConfig2.setTechnicalToleranceValue(null);
        eventConfig2.setBusinessToleranceValue(null);
        eventConfig2.setMatchLocation(false);
        given(metadataManagement.getEntityEvent(Mockito.anyString(), Mockito.contains("POConfirmedEvent"))).willReturn(eventConfig1);
        given(metadataManagement.getEntityEvent(Mockito.anyString(), Mockito.contains("POGoodsReceivedEvent"))).willReturn(eventConfig2);
        processEventMessage.getReferences().get(0).setAction(Action.DELETE.toString());
        processEventMessage.getReferences().get(1).setAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:DEL_NO:101");
        List<Event> messages = new ArrayList<>();
        messages.add(processEventMessage);

        service.processEvents(messages, "requestId", "writeServiceId");
        verify(eventManagement, times(1)).post(Mockito.anyList());
        verify(processManagement, times(0)).update(Mockito.any(), Mockito.any(), Mockito.any());

        ArgumentCaptor<ExecutionDto> argumentCaptorExecutionDto = ArgumentCaptor.forClass(ExecutionDto.class);
        verify(executionHistoryManagement).insertExecution(argumentCaptorExecutionDto.capture());
        ExecutionDto executionDto = argumentCaptorExecutionDto.getValue();
        assertThat(executionDto).isNotNull();
        assertThat(executionDto.getCorrelatedTpId()).isEqualTo(GTTUtils.UUIDUtils.generateNameBasedUUID(existedTP.getAltKey()).toString());

        ArgumentCaptor<ExecutionMessageDto> argumentCaptorExecutionMessageDto = ArgumentCaptor.forClass(ExecutionMessageDto.class);
        verify(executionHistoryManagement).insertExecutionMessage(argumentCaptorExecutionMessageDto.capture());
        ExecutionMessageDto messageDto = argumentCaptorExecutionMessageDto.getValue();
        assertThat(messageDto).isNotNull();
        assertThat(messageDto.getPhase()).isEqualTo(Phase.INIT.name());
        assertThat(messageDto.getMessageType()).isEqualTo(ExecutionStatus.ERROR.name());

    }

    @Test
    //3
    public void processEventWhenThisEventIsPlannedEventAndAffact1TP() {
        prepareEventMessage();
        TrackedProcess tp = new TrackedProcess();
        String trackedProcessType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        tp.setMetadata(getMetadata(trackedProcessType));
        tp.setTrackedProcessType(trackedProcessType);
        UUID tpId = GTTUtils.UUIDUtils.generateTimeBasedUUID();
        tp.setId(tpId);
        tp.setAltKey("altkey");
        tp.setProcessStatus(ProcessStatus.AS_PLANNED.name());
        List<PlannedEvent> pes = new ArrayList<>();
        PlannedEvent plannedEvent = new PlannedEvent();
        plannedEvent.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.PlannedEvent"));
        plannedEvent.setId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        plannedEvent.setEventType(eventMessage.getEventType());
        plannedEvent.setEventMatchKey(eventMessage.getEventMatchKey());
        plannedEvent.setPlannedTechTsLatest(Instant.parse("2018-07-09T12:00:00.213Z"));
        plannedEvent.setPlannedBusinessTimestamp(Instant.parse("2018-07-09T12:00:00.213Z"));
        plannedEvent.setPlannedBizTsEarliest(Constant.MIN_TIMESTAMP);
        plannedEvent.setPlannedBizTsLatest(Constant.MAX_TIMESTAMP);
        plannedEvent.setIsFinalPlannedEvent(Boolean.FALSE);
        plannedEvent.setLastProcessEventDirectoryId(null);
        plannedEvent.setEventStatus(EventStatus.PLANNED.name());
        pes.add(plannedEvent);
        tp.setPlannedEvents(pes);
        List<QualifiedTrackingId> trackingIds = new ArrayList<>();
        QualifiedTrackingId trackingId = QualifiedTrackingId.build(tpId, tpId, null, null);
        trackingId.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.QualifiedTrackingId"));
        trackingIds.add(trackingId);
        tp.setTrackingIds(trackingIds);
        List<ProcessEventDirectory> peds = new ArrayList<>();
        ProcessEventDirectory ped = ProcessEventDirectory.build(GTTUtils.UUIDUtils.generateTimeBasedUUID(),
                tpId, null, GTTUtils.UUIDUtils.generateTimeBasedUUID(), CorrelationType.UNPLANNED_PROCESS_CREATION_UPDATE.name());
        peds.add(ped);
        tp.setPEDs(peds);
        given(processManagement.getWithOnlyValidDPPStatus(Mockito.any(UUIDValue.class))).willReturn(tp);

        Map<UUIDValue, String> observedTrackingIdMap = new HashMap<>();
        observedTrackingIdMap.put(UUIDValue.valueOf(tpId), tp.getAltKey());
        given(processManagement.getCorrelatedProcessMap(Mockito.any(UUIDValue.class), Mockito.any(TimestampValue.class), Mockito.anyInt()))
                .willReturn(observedTrackingIdMap);
        MetadataEntityEvent eventConfig = new MetadataEntityEvent();
        eventConfig.setMatchLocation(false);
        given(metadataManagement.getEntityEvent(Mockito.anyString(), Mockito.anyString())).willReturn(eventConfig);
        List<Event> messages = new ArrayList<>();
        messages.add(eventMessage);
        service.processEvents(messages, "requestId", "writeServiceId");

        ArgumentCaptor<List<Event>> argumentCaptorEvent = ArgumentCaptor.forClass(List.class);
        verify(eventManagement).post(argumentCaptorEvent.capture());
        List<Event> capturedEvent = argumentCaptorEvent.getValue();
        assertThat(capturedEvent.size()).isEqualTo(1);

        ArgumentCaptor<TrackedProcess> argumentCaptorTrackedProcess = ArgumentCaptor.forClass(TrackedProcess.class);
        ArgumentCaptor<PlannedEvent> argumentCaptorPE = ArgumentCaptor.forClass(PlannedEvent.class);
        ArgumentCaptor<ProcessEventDirectory> argumentCaptorPED = ArgumentCaptor.forClass(ProcessEventDirectory.class);
        verify(processManagement, times(1)).update(argumentCaptorTrackedProcess.capture(), argumentCaptorPED.capture(), argumentCaptorPE.capture());
        TrackedProcess rstTP = argumentCaptorTrackedProcess.getValue();
        assertThat(rstTP.getTrackingIds().size()).isEqualTo(3);
        assertThat(rstTP.getProcessStatus()).isEqualTo(ProcessStatus.AS_PLANNED.name());
        PlannedEvent capturedPE = argumentCaptorPE.<List<String>>getValue();
        assertThat(capturedPE.getEventStatus()).isEqualTo(EventStatus.REPORTED.name());
        assertThat(capturedPE.getId()).isEqualTo(plannedEvent.getId());

        ProcessEventDirectory capturedPED = argumentCaptorPED.<List<String>>getValue();
        assertThat(capturedPED.getPlannedEventId()).isEqualTo(plannedEvent.getId());
        assertThat(capturedPED.getProcessId()).isEqualTo(tpId);
    }

    @Test
    //3
    public void processEventWhenThisEventIsPlannedEventWithExtensionField() {
        prepareEventMessage();
        eventMessage.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POGoodsReceivedEvent");
        eventMessage.setMetadata(getMetadata(eventMessage.getEventType()));
        eventMessage.setValue("mode1", "abc");
        TrackedProcess tp = new TrackedProcess();
        String trackedProcessType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        tp.setMetadata(getMetadata(trackedProcessType));
        tp.setTrackedProcessType(trackedProcessType);
        UUID tpId = GTTUtils.UUIDUtils.generateTimeBasedUUID();
        tp.setId(tpId);
        tp.setAltKey("altkey");
        tp.setProcessStatus(ProcessStatus.AS_PLANNED.name());
        List<PlannedEvent> pes = new ArrayList<>();
        PlannedEvent plannedEvent = new PlannedEvent();
        plannedEvent.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.PlannedEvent"));
        plannedEvent.setId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        plannedEvent.setEventType(eventMessage.getEventType());
        plannedEvent.setEventMatchKey(eventMessage.getEventMatchKey());
        plannedEvent.setPlannedTechTsLatest(Instant.parse("2018-07-09T12:00:00.213Z"));
        plannedEvent.setPlannedBusinessTimestamp(Instant.parse("2018-07-09T12:00:00.213Z"));
        plannedEvent.setPlannedBizTsEarliest(Constant.MIN_TIMESTAMP);
        plannedEvent.setPlannedBizTsLatest(Constant.MAX_TIMESTAMP);
        plannedEvent.setIsFinalPlannedEvent(Boolean.FALSE);
        plannedEvent.setLastProcessEventDirectoryId(null);
        plannedEvent.setEventStatus(EventStatus.PLANNED.name());
        plannedEvent.setValue("mode", "abc");
        pes.add(plannedEvent);
        tp.setPlannedEvents(pes);
        List<QualifiedTrackingId> trackingIds = new ArrayList<>();
        QualifiedTrackingId trackingId = QualifiedTrackingId.build(tpId, tpId, null, null);
        trackingId.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.QualifiedTrackingId"));
        trackingIds.add(trackingId);
        tp.setTrackingIds(trackingIds);
        List<ProcessEventDirectory> peds = new ArrayList<>();
        ProcessEventDirectory ped = ProcessEventDirectory.build(GTTUtils.UUIDUtils.generateTimeBasedUUID(),
                tpId, null, GTTUtils.UUIDUtils.generateTimeBasedUUID(), CorrelationType.UNPLANNED_PROCESS_CREATION_UPDATE.name());
        peds.add(ped);
        tp.setPEDs(peds);
        given(processManagement.getWithOnlyValidDPPStatus(Mockito.any(UUIDValue.class))).willReturn(tp);

        Map<UUIDValue, String> observedTrackingIdMap = new HashMap<>();
        observedTrackingIdMap.put(UUIDValue.valueOf(tpId), tp.getAltKey());
        given(processManagement.getCorrelatedProcessMap(Mockito.any(UUIDValue.class), Mockito.any(TimestampValue.class)
                , Mockito.anyInt()))
                .willReturn(observedTrackingIdMap);
        MetadataEntityEvent eventConfig = new MetadataEntityEvent();
        eventConfig.setMatchLocation(false);
        MatchExtensionField matchExtensionField = new MatchExtensionField();
        matchExtensionField.setOperator(Operator.EQUAL.getValue());
        matchExtensionField.setSourceObject("PlannedEvent");
        matchExtensionField.setSourceField("mode");
        matchExtensionField.setTargetObject("POConfirmedEvent");
        matchExtensionField.setTargetField("mode1");
        eventConfig.addMatchExtensionField(matchExtensionField);
        given(metadataManagement.getEntityEvent(Mockito.anyString(), Mockito.anyString())).willReturn(eventConfig);
        List<Event> messages = new ArrayList<>();
        messages.add(eventMessage);
        service.processEvents(messages, "requestId", "writeServiceId");

        ArgumentCaptor<List<Event>> argumentCaptorEvent = ArgumentCaptor.forClass(List.class);
        verify(eventManagement).post(argumentCaptorEvent.capture());
        List<Event> capturedEvent = argumentCaptorEvent.getValue();
        assertThat(capturedEvent.size()).isEqualTo(1);

        ArgumentCaptor<TrackedProcess> argumentCaptorTrackedProcess = ArgumentCaptor.forClass(TrackedProcess.class);
        ArgumentCaptor<PlannedEvent> argumentCaptorPE = ArgumentCaptor.forClass(PlannedEvent.class);
        ArgumentCaptor<ProcessEventDirectory> argumentCaptorPED = ArgumentCaptor.forClass(ProcessEventDirectory.class);
        verify(processManagement, times(1)).update(argumentCaptorTrackedProcess.capture(), argumentCaptorPED.capture(), argumentCaptorPE.capture());
        TrackedProcess rstTP = argumentCaptorTrackedProcess.getValue();
        assertThat(rstTP.getTrackingIds().size()).isEqualTo(3);
        assertThat(rstTP.getProcessStatus()).isEqualTo(ProcessStatus.AS_PLANNED.name());
        PlannedEvent capturedPE = argumentCaptorPE.<List<String>>getValue();
        assertThat(capturedPE.getEventStatus()).isEqualTo(EventStatus.REPORTED.name());
        assertThat(capturedPE.getId()).isEqualTo(plannedEvent.getId());

        ProcessEventDirectory capturedPED = argumentCaptorPED.<List<String>>getValue();
        assertThat(capturedPED.getPlannedEventId()).isEqualTo(plannedEvent.getId());
        assertThat(capturedPED.getProcessId()).isEqualTo(tpId);
    }

    @Test
    public void processEventWhenThisEventIsNotExistedInThisModel() {
        prepareEventMessage();
        TrackedProcess tp = new TrackedProcess();
        String trackedProcessType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        tp.setMetadata(getMetadata(trackedProcessType));
        tp.setTrackedProcessType(trackedProcessType);
        UUID tpId = GTTUtils.UUIDUtils.generateTimeBasedUUID();
        tp.setId(tpId);
        tp.setAltKey("altkey");
        tp.setProcessStatus(ProcessStatus.AS_PLANNED.name());
        List<PlannedEvent> pes = new ArrayList<>();
        PlannedEvent plannedEvent = new PlannedEvent();
        plannedEvent.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.PlannedEvent"));
        plannedEvent.setId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        plannedEvent.setEventType(eventMessage.getEventType());
        plannedEvent.setEventMatchKey(eventMessage.getEventMatchKey());
        plannedEvent.setPlannedTechTsLatest(Instant.parse("2018-07-09T12:00:00.213Z"));
        plannedEvent.setPlannedBusinessTimestamp(Instant.parse("2018-07-09T12:00:00.213Z"));
        plannedEvent.setPlannedBizTsEarliest(Constant.MIN_TIMESTAMP);
        plannedEvent.setPlannedBizTsLatest(Constant.MAX_TIMESTAMP);
        plannedEvent.setIsFinalPlannedEvent(Boolean.FALSE);
        plannedEvent.setLastProcessEventDirectoryId(null);
        plannedEvent.setEventStatus(EventStatus.PLANNED.name());
        pes.add(plannedEvent);
        tp.setPlannedEvents(pes);
        List<QualifiedTrackingId> trackingIds = new ArrayList<>();
        QualifiedTrackingId trackingId = QualifiedTrackingId.build(tpId, tpId, null, null);
        trackingId.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.QualifiedTrackingId"));
        trackingIds.add(trackingId);
        tp.setTrackingIds(trackingIds);
        List<ProcessEventDirectory> peds = new ArrayList<>();
        ProcessEventDirectory ped = ProcessEventDirectory.build(GTTUtils.UUIDUtils.generateTimeBasedUUID(),
                tpId, null, GTTUtils.UUIDUtils.generateTimeBasedUUID(), CorrelationType.UNPLANNED_PROCESS_CREATION_UPDATE.name());
        peds.add(ped);
        tp.setPEDs(peds);
        given(processManagement.getWithOnlyValidDPPStatus(Mockito.any(UUIDValue.class))).willReturn(tp);

        Map<UUIDValue, String> observedTrackingIdMap = new HashMap<>();
        observedTrackingIdMap.put(UUIDValue.valueOf(tpId), tp.getAltKey());
        given(processManagement.getCorrelatedProcessMap(Mockito.any(UUIDValue.class), Mockito.any(TimestampValue.class)
                , Mockito.anyInt()))
                .willReturn(observedTrackingIdMap);

        given(metadataManagement.getEntityEvent(Mockito.anyString(), Mockito.anyString())).willReturn(null);
        List<Event> messages = new ArrayList<>();
        messages.add(eventMessage);
        service.processEvents(messages, "requestId", "writeServiceId");

        ArgumentCaptor<List<Event>> argumentCaptorEvent = ArgumentCaptor.forClass(List.class);
        verify(eventManagement).post(argumentCaptorEvent.capture());
        List<Event> capturedEvent = argumentCaptorEvent.getValue();
        assertThat(capturedEvent.size()).isEqualTo(1);

        verify(processManagement, times(0)).update(Mockito.any(), Mockito.any(), Mockito.any());
    }

    @Test
    //4
    public void addTwoPOItem() {
        String processEventType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemEvent";
        CurrentMetadataEntity processEventMetadata = getMetadata(processEventType);
        Event poitem1 = new Event();
        poitem1.setMetadata(processEventMetadata);
        poitem1.setId(UUID.randomUUID());
        poitem1.setAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:ProcurementOrderItem:1");
        poitem1.setActualBusinessTimestamp(Instant.now());
        poitem1.setValue("procurementOrderNO", "0000000001");
        poitem1.setValue("itemNO", "00001");
        poitem1.setValue("supplierId", "123456");
        poitem1.setValue("materialId", "000001");
        poitem1.setValue("receivingLocationId", "123");
        poitem1.setValue("procurementOrderItemQty", 2.1);
        poitem1.setValue("procurementOrderItemUOM", "EA");
        poitem1.setModelNamespace("com.sap.gtt.app.mim");
        poitem1.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemEvent");
        poitem1.setMetadata(processEventMetadata);

        CurrentMetadataEntity peMetadata =
                getMetadata("com.sap.gtt.core.CoreModel.PlannedEvent");
        List<PlannedEvent> pes1 = new ArrayList<>();
        PlannedEvent pe11 = new PlannedEvent();
        pe11.setEventType("com.sap.gtt.app.mim.poitem.POItemModel.ConfirmedEvent");
        //pe11.setLocationId(UUID.randomUUID());
        pe11.setPlannedTechnicalTimestamp(Instant.parse("2019-04-09T09:00:00.213Z"));
        pe11.setPlannedBusinessTimestamp(Instant.parse("2019-04-09T09:00:00.213Z"));
        pe11.setPlannedTechTsLatest(Instant.parse("2019-04-09T10:00:00.213Z"));
        pe11.setPlannedTechTsEarliest(Instant.parse("2019-04-09T08:00:00.213Z"));
        pe11.setPlannedBusinessTimeZone("CET");
        pe11.setMetadata(peMetadata);
        pes1.add(pe11);
        PlannedEvent pe12 = new PlannedEvent();
        pe12.setEventType("com.sap.gtt.app.mim.poitem.POItemModel.GoodsReceivedEvent");
        //pe12.setLocationId(UUID.randomUUID());
        pe12.setPlannedTechnicalTimestamp(Instant.parse("2019-04-11T09:00:00.213Z"));
        pe12.setPlannedBusinessTimestamp(Instant.parse("2019-04-11T09:00:00.213Z"));
        pe12.setPlannedTechTsLatest(Instant.parse("2019-04-11T10:00:00.213Z"));
        pe12.setPlannedTechTsEarliest(Instant.parse("2019-04-11T08:00:00.213Z"));
        pe12.setPlannedBusinessTimeZone("CET");
        pe12.setMetadata(peMetadata);
        pes1.add(pe12);
        poitem1.setPlannedEvents(pes1);

        Event poitem2 = new Event();
        poitem2.setMetadata(processEventMetadata);
        poitem2.setId(UUID.randomUUID());
        poitem2.setAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:ProcurementOrderItem:2");
        poitem2.setActualBusinessTimestamp(Instant.now());
        poitem2.setValue("procurementOrderNO", "0000000001");
        poitem2.setValue("itemNO", "00002");
        poitem2.setValue("supplierId", "123456");
        poitem2.setValue("materialId", "000002");
        poitem2.setValue("receivingLocationId", "123");
        poitem2.setValue("procurementOrderItemQty", 2.1);
        poitem2.setValue("procurementOrderItemUOM", "EA");
        poitem2.setModelNamespace("com.sap.gtt.app.mim");
        poitem2.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemEvent");
        List<PlannedEvent> pes2 = new ArrayList<>();
        PlannedEvent pe21 = new PlannedEvent();
        pe21.setEventType("com.sap.gtt.app.mim.poitem.POItemModel.ConfirmedEvent");
        //pe21.setLocationId(UUID.randomUUID());
        pe21.setPlannedTechnicalTimestamp(Instant.parse("2019-04-09T09:00:00.213Z"));
        pe21.setPlannedBusinessTimestamp(Instant.parse("2019-04-09T09:00:00.213Z"));
        pe21.setPlannedTechTsLatest(Instant.parse("2019-04-09T10:00:00.213Z"));
        pe21.setPlannedTechTsEarliest(Instant.parse("2019-04-09T08:00:00.213Z"));
        pe21.setPlannedBusinessTimeZone("CET");
        pe21.setMetadata(peMetadata);
        pes2.add(pe21);
        PlannedEvent pe22 = new PlannedEvent();
        pe22.setEventType("com.sap.gtt.app.mim.poitem.POItemModel.GoodsReceivedEvent");
        //pe22.setLocationId(UUID.randomUUID());
        pe22.setPlannedTechnicalTimestamp(Instant.parse("2019-04-11T09:00:00.213Z"));
        pe22.setPlannedBusinessTimestamp(Instant.parse("2019-04-11T09:00:00.213Z"));
        pe22.setPlannedTechTsLatest(Instant.parse("2019-04-11T10:00:00.213Z"));
        pe22.setPlannedTechTsEarliest(Instant.parse("2019-04-11T08:00:00.213Z"));
        pe22.setPlannedBusinessTimeZone("CET");
        pe22.setMetadata(peMetadata);
        pes2.add(pe22);
        poitem2.setPlannedEvents(pes2);

        List<Event> tpMessages = new ArrayList<>();
        tpMessages.add(poitem1);
        tpMessages.add(poitem2);

        given(processManagement.get(any(), Mockito.any(UUIDValue.class))).willReturn(null);
        String trackedProcessType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        MetadataEntity tpEntity = entityMap.get(trackedProcessType);
        given(metadataManagement.getTrackedProcessEntityByEventType(Mockito.anyString(), eq(processEventType))).willReturn(tpEntity);
        MetadataEntityEvent eventConfig = new MetadataEntityEvent();
        eventConfig.setTechnicalToleranceValue(Duration.parse("PT1H"));
        eventConfig.setBusinessToleranceValue(null);
        given(metadataManagement.getEntityEvent(Mockito.anyString(), Mockito.anyString())).willReturn(eventConfig);
        service.processEvents(tpMessages, "requestId", "writeServiceId");

        verify(eventManagement, times(1)).post(Mockito.anyList());

        ArgumentCaptor<TrackedProcess> argumentCaptor = ArgumentCaptor.forClass(TrackedProcess.class);
        verify(processManagement, times(2)).create(argumentCaptor.capture());
        List<TrackedProcess> processes = argumentCaptor.getAllValues();
        assertThat(processes.size()).isEqualTo(2);
        TrackedProcess process1 = processes.get(0);
        UUID tpId = process1.getIdAsInternalValue();
        List<PlannedEvent> pes = process1.getPlannedEvents();
        assertThat(pes.size()).isEqualTo(2);
        PlannedEvent pe = pes.get(0);
        assertThat(pe.getProcessId()).isEqualTo(tpId);
        assertThat(pe.getPlannedTechTsEarliest()).isEqualTo(pe11.getPlannedTechnicalTimestamp().minus(Duration.ofHours(1)));
        assertThat(pe.getPlannedTechTsLatest()).isEqualTo(pe11.getPlannedTechnicalTimestamp().plus(Duration.ofHours(1)));
        assertThat(pe.getNextOverdueDetection()).isEqualTo(Constant.MAX_TIMESTAMP);
        List<QualifiedTrackingId> trackingIds = process1.getTrackingIds();
        assertThat(trackingIds.size()).isEqualTo(1);
        QualifiedTrackingId trackingId = trackingIds.get(0);
        assertThat(trackingId.getProcessId()).isEqualTo(tpId);
        assertThat(trackingId.getObservedProcessId()).isEqualTo(tpId);
    }

    @Test
    //5
    public void addOnePOItemAndUpdateOnePOItem() {
        String processEventType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemEvent";
        CurrentMetadataEntity processEventMetadata = getMetadata(processEventType);
        Event poitem1 = new Event();
        poitem1.setMetadata(processEventMetadata);
        poitem1.setId(UUID.randomUUID());
        poitem1.setAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:ProcurementOrderItem:3");
        poitem1.setActualBusinessTimestamp(Instant.now());
        poitem1.setValue("procurementOrderNO", "0000000002");
        poitem1.setValue("itemNO", "00001");
        poitem1.setValue("supplierId", "6666666");
        poitem1.setValue("materialId", "000001");
        poitem1.setValue("receivingLocationId", "123");
        poitem1.setValue("procurementOrderItemQty", 10.0);
        poitem1.setValue("procurementOrderItemUOM", "EA");
        poitem1.setEventType(processEventType);
        poitem1.setModelNamespace("com.sap.gtt.app.mim");

        CurrentMetadataEntity peMetadata =
                getMetadata("com.sap.gtt.core.CoreModel.PlannedEvent");
        List<PlannedEvent> pes1 = new ArrayList<>();
        PlannedEvent pe11 = new PlannedEvent();
        pe11.setMetadata(peMetadata);
        pe11.setEventType("com.sap.gtt.app.mim.poitem.POItemModel.ConfirmedEvent");
        pe11.setEventMatchKey("10");
        pe11.setPlannedTechnicalTimestamp(Instant.parse("2019-04-19T09:00:00.213Z"));
        pe11.setPlannedBusinessTimestamp(Instant.parse("2019-04-19T09:00:00.213Z"));
        pe11.setPlannedTechTsEarliest(Instant.parse("2019-04-19T08:00:00.213Z"));
        pe11.setPlannedTechTsLatest(Instant.parse("2019-04-19T10:00:00.213Z"));
        pe11.setPlannedBusinessTimeZone("CET");
        pes1.add(pe11);
        PlannedEvent pe12 = new PlannedEvent();
        pe12.setMetadata(peMetadata);
        pe12.setEventType("com.sap.gtt.app.mim.poitem.POItemModel.GoodsReceivedEvent");
        pe12.setEventMatchKey("20");
        pe12.setPlannedTechnicalTimestamp(Instant.parse("2019-04-21T09:00:00.213Z"));
        pe12.setPlannedBusinessTimestamp(Instant.parse("2019-04-21T09:00:00.213Z"));
        pe12.setPlannedTechTsEarliest(Instant.parse("2019-04-21T08:00:00.213Z"));
        pe12.setPlannedTechTsLatest(Instant.parse("2019-04-19T10:00:00.213Z"));
        pe12.setPlannedBusinessTimeZone("CET");
        pes1.add(pe12);
        poitem1.setPlannedEvents(pes1);

        Event poitem2 = new Event();
        poitem2.setMetadata(processEventMetadata);
        poitem2.setId(UUID.randomUUID());
        poitem2.setAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:ProcurementOrderItem:2");
        poitem2.setActualBusinessTimestamp(Instant.now());
        poitem2.setValue("procurementOrderNO", "0000000001");
        poitem2.setValue("itemNO", "00002");
        poitem2.setValue("supplierId", "123456");
        poitem2.setValue("materialId", "000002");
        poitem2.setValue("receivingLocationId", "123");
        poitem2.setValue("procurementOrderItemQty", 2.1);
        poitem2.setValue("procurementOrderItemUOM", "EA");
        poitem2.setEventType(processEventType);
        poitem2.setModelNamespace("com.sap.gtt.app.mim");
        List<PlannedEvent> pes2_message = new ArrayList<>();
        PlannedEvent pe22 = new PlannedEvent();
        pe22.setMetadata(peMetadata);
        pe22.setEventType("com.sap.gtt.app.mim.poitem.POItemModel.GoodsReceivedEvent");
        pe22.setEventMatchKey("20");
        pe22.setPlannedTechnicalTimestamp(Instant.parse("2019-04-11T09:00:00.213Z"));
        pe22.setPlannedBusinessTimestamp(Instant.parse("2019-04-11T09:00:00.213Z"));
        pe22.setPlannedTechTsEarliest(Instant.parse("2019-04-11T08:00:00.213Z"));
        pe22.setPlannedTechTsLatest(Instant.parse("2019-04-11T10:00:00.213Z"));
        pe22.setPlannedBusinessTimeZone("CET");
        pes2_message.add(pe22);
        poitem2.setPlannedEvents(pes2_message);

        CurrentMetadataEntity referenceMetadata =
                getMetadata("com.sap.gtt.core.CoreModel.Reference");
        List<Reference> references = new ArrayList<>();
        Reference reference = new Reference();
        reference.setAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:ProcurementOrderItem:1");
        reference.setReferenceType("TRACKING");
        reference.setValidFrom(Instant.parse("2019-04-01T00:00:00Z"));
        reference.setValidTo(Instant.parse("2019-04-01T23:59:59Z"));
        reference.setAction("ADD");
        reference.setMetadata(referenceMetadata);
        references.add(reference);
        poitem2.setReferences(references);

        List<Event> tpMessages = new ArrayList<>();
        tpMessages.add(poitem1);
        tpMessages.add(poitem2);

        String trackedProcessType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        TrackedProcess poitem2_existed = new TrackedProcess();
        poitem2_existed.setMetadata(getMetadata(trackedProcessType));
        poitem2_existed.setAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:ProcurementOrderItem:2");
        UUID poitem2_id = GTTUtils.UUIDUtils.generateNameBasedUUID(poitem2_existed.getAltKey());
        poitem2_existed.setId(poitem2_id);
        poitem2_existed.setValue("procurementOrderNO", "0000000001");
        poitem2_existed.setValue("itemNO", "00002");
        poitem2_existed.setValue("supplierId", "123456");
        poitem2_existed.setValue("materialId", "000002");
        poitem2_existed.setValue("receivingLocationId", "123");
        poitem2_existed.setValue("procurementOrderItemQty", 2.1);
        poitem2_existed.setValue("procurementOrderItemUOM", "EA");
        poitem2_existed.setScheme("xri://sap.com/sapdoc");
        poitem2_existed.setPartyId("666666");
        poitem2_existed.setLogicalSystem("Q8JCLNT774");
        poitem2_existed.setTrackingIdType("ProcurementOrderItem");
        poitem2_existed.setTrackingId("2");
        poitem2_existed.setTrackedProcessType(trackedProcessType);
        poitem2_existed.setCreationDateTime(Instant.now());
        poitem2_existed.setCreatedByUser("");
        poitem2_existed.setLastChangedAtBusinessTime(Instant.now().minusSeconds(600));
        poitem2_existed.setLifeCycleStatus(LifeCycleStatus.BUSINESS_ACTIVE);
        List<QualifiedTrackingId> trackingIds_existed = new ArrayList<>();
        QualifiedTrackingId trackingId_existed = QualifiedTrackingId.build(poitem2_id, poitem2_id, null, null);
        trackingId_existed.setMetadata(getMetadata(MetadataConstants.CoreModelEntity.QUALIFIED_TRACKING_ID.getFullName()));
        trackingIds_existed.add(trackingId_existed);
        poitem2_existed.setTrackingIds(trackingIds_existed);
        List<PlannedEvent> pes2_existed = new ArrayList<>();
        PlannedEvent pe21_existed = new PlannedEvent();
        pe21_existed.setMetadata(getMetadata(MetadataConstants.CoreModelEntity.PLANNED_EVENT.getFullName()));
        pe21_existed.setId(UUID.randomUUID());
        pe21_existed.setProcessId(poitem2_existed.getId());
        pe21_existed.setEventType("com.sap.gtt.app.mim.poitem.POItemModel.ConfirmedEvent");
        pe21_existed.setPayloadSequence(3);
        pe21_existed.setEventMatchKey("10");
        pe21_existed.setPlannedTechnicalTimestamp(Instant.parse("2019-04-09T09:00:00.213Z"));
        pe21_existed.setPlannedBusinessTimestamp(Instant.parse("2019-04-09T09:00:00.213Z"));
        pe21_existed.setPlannedBusinessTimeZone("CET");
        pe21_existed.setNextOverdueDetection(null);
        pe21_existed.setOverdueDetectionCounter(0);
        pe21_existed.setPlannedTechTsEarliest(pe21_existed.getPlannedTechnicalTimestamp());
        pe21_existed.setPlannedTechTsLatest(pe21_existed.getPlannedTechnicalTimestamp());
        pe21_existed.setPlannedBizTsEarliest(pe21_existed.getPlannedBusinessTimestamp());
        pe21_existed.setPlannedBizTsLatest(pe21_existed.getPlannedBusinessTimestamp());
        pe21_existed.setLastProcessEventDirectoryId(null);
        pe21_existed.setEventStatus(EventStatus.REPORTED.name());
        pes2_existed.add(pe21_existed);
        poitem2_existed.setPlannedEvents(pes2_existed);
        List<ProcessEventDirectory> peds2_existed = new ArrayList<>();
        ProcessEventDirectory ped21_existed = new ProcessEventDirectory();
        ped21_existed.setMetadata(getMetadata(MetadataConstants.CoreModelEntity.PROCESS_EVENT_DIRECTORY.getFullName()));
        ped21_existed.setProcessId(poitem2_id);
        ped21_existed.setPlannedEventId(pe21_existed.getId());
        ped21_existed.setEventId(UUID.randomUUID());
        ped21_existed.setId(UUID.randomUUID());
        peds2_existed.add(ped21_existed);
        poitem2_existed.setPEDs(peds2_existed);

        given(processManagement.get(any(), eq(UUIDValue.valueOf(poitem2_id)))).willReturn(poitem2_existed);
        MetadataEntityEvent eventConfig = new MetadataEntityEvent();
        eventConfig.setTechnicalToleranceValue(Duration.parse("PT1H"));
        eventConfig.setBusinessToleranceValue(null);
        given(metadataManagement.getEntityEvent(Mockito.anyString(), Mockito.anyString())).willReturn(eventConfig);

        MetadataEntity tpEntity = entityMap.get(trackedProcessType);
        given(metadataManagement.getTrackedProcessEntityByEventType(Mockito.anyString(), eq(processEventType))).willReturn(tpEntity);
        service.processEvents(tpMessages, "requestId", "writeServiceId");

        verify(eventManagement, times(1)).post(Mockito.anyList());

        ArgumentCaptor<TrackedProcess> argumentCaptor = ArgumentCaptor.forClass(TrackedProcess.class);
        verify(processManagement).create(argumentCaptor.capture());
        TrackedProcess process1 = argumentCaptor.<List<String>>getValue();
        UUID tpId = process1.getIdAsInternalValue();
        List<PlannedEvent> pes = process1.getPlannedEvents();
        assertThat(pes.size()).isEqualTo(2);
        PlannedEvent pe = pes.get(0);
        assertThat(pe.getProcessId()).isEqualTo(tpId);
        assertThat(pe.getPlannedTechTsEarliest()).isEqualTo(pe11.getPlannedTechnicalTimestamp().minus(Duration.ofHours(1)));
        assertThat(pe.getPlannedTechTsLatest()).isEqualTo(pe11.getPlannedTechnicalTimestamp().plus(Duration.ofHours(1)));
        assertThat(pe.getPayloadSequence()).isEqualTo(1);
        assertThat(pes.get(1).getPayloadSequence()).isEqualTo(2);
        List<QualifiedTrackingId> trackingIds = process1.getTrackingIds();
        assertThat(trackingIds.size()).isEqualTo(1);
        QualifiedTrackingId trackingId = trackingIds.get(0);
        assertThat(trackingId.getProcessId()).isEqualTo(tpId);
        assertThat(trackingId.getObservedProcessId()).isEqualTo(tpId);

        verify(processManagement).update(argumentCaptor.capture(), Mockito.any(ProcessEventDirectory.class), eq(null));
        TrackedProcess process2 = argumentCaptor.<List<String>>getValue();
        UUID tpId2 = process2.getIdAsInternalValue();
        List<PlannedEvent> pes2 = process2.getPlannedEvents();
        assertThat(pes2.size()).isEqualTo(2);
        pe = pes2.get(0);
        assertThat(pe.getProcessId()).isEqualTo(tpId2);
        assertThat(pe.getPlannedTechTsEarliest()).isEqualTo(pe22.getPlannedTechnicalTimestamp().minus(Duration.ofHours(1)));
        assertThat(pe.getPlannedTechTsLatest()).isEqualTo(pe22.getPlannedTechnicalTimestamp().plus(Duration.ofHours(1)));
        assertThat(pe.getPayloadSequence()).isEqualTo(4);
        PlannedEvent pe2 = pes2.get(1);
        assertThat(pe2.getEventType()).isEqualTo(pe21_existed.getEventType());
        assertThat(pe2.getEventMatchKey()).isEqualTo(pe21_existed.getEventMatchKey());
        assertThat(pe2.getEventStatus()).isEqualTo(pe21_existed.getEventStatus());
        assertThat(pe2.getPayloadSequence()).isEqualTo(3);
        trackingIds = process2.getTrackingIds();
        assertThat(trackingIds.size()).isEqualTo(2);
        trackingId = trackingIds.get(0);
        assertThat(trackingId.getProcessId()).isEqualTo(tpId2);
        assertThat(trackingId.getObservedProcessId()).isEqualTo(tpId2);
        trackingId = trackingIds.get(1);
        assertThat(trackingId.getProcessId()).isEqualTo(tpId2);
        assertThat(trackingId.getObservedProcessId()).isEqualTo(GTTUtils.UUIDUtils.generateNameBasedUUID(reference.getAltKey()));
    }

    @Test
    //6
    public void testProcessEventWhenThereIsNoMatchingEvent() {
        Event eventMessage = new Event();
        eventMessage.setId(UUID.randomUUID());
        eventMessage.setAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:ProcurementOrderItem:10");
        eventMessage.setModelNamespace("com.sap.gtt.app.mim");
        eventMessage.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POConfirmedEvent");
        eventMessage.setEventMatchKey("10");
        eventMessage.setEventReasonText("External API Confirm Event");
        eventMessage.setActualBusinessTimestamp(Instant.now());
        eventMessage.setValue("quantity", 10.0);
        eventMessage.setValue("uom", "KG");
        eventMessage.setSenderPartyId(GTTUtils.UUIDUtils.generateTimeBasedUUID().toString());
        eventMessage.setSubaccountId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        eventMessage.setCloneInstanceId(null);
        eventMessage.setMessageSourceType("messageSourceType");
        eventMessage.setActualBusinessTimeZone(null);
        eventMessage.setMetadata(getMetadata(eventMessage.getEventType()));
        List<Event> messages = new ArrayList<>();
        messages.add(eventMessage);
        Map<UUIDValue, String> trackingIdMap = new HashMap<>();
        trackingIdMap.put(UUIDValue.valueOf(GTTUtils.UUIDUtils.generateTimeBasedUUID()), "processAltkey");
        given(processManagement.getCorrelatedProcessMap(Mockito.any(UUIDValue.class), Mockito.any(TimestampValue.class)
                , Mockito.anyInt()))
                .willReturn(trackingIdMap);
        //given(metadataManagement.checkIfEventIsUnplanned(Mockito.anyString(), Mockito.anyString())).willReturn(false);
        MetadataEntityEvent eventConfig = new MetadataEntityEvent();
        eventConfig.setMatchLocation(false);
        given(metadataManagement.getEntityEvent(Mockito.anyString(), Mockito.anyString())).willReturn(eventConfig);
        String trackedProcessType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        //MetadataEntity tpEntity = entityMap.get(trackedProcessType);
        //given(metadataManagement.getTrackedProcessEntityByEventType(Mockito.anyString(), Mockito.anyString())).willReturn(tpEntity);
        TrackedProcess tp = new TrackedProcess();
        tp.setTrackedProcessType("com.sap.gtt.app.mim.POItem");
        given(processManagement.getWithOnlyValidDPPStatus(Mockito.any(UUIDValue.class))).willReturn(tp);
        service.processEvents(messages, "requestId", "writeServiceId");

        verify(eventManagement, times(1)).post(Mockito.anyList());
        verify(processManagement, times(0)).update(Mockito.any(), Mockito.any(), Mockito.any());
    }

    @Test
    //7
    public void testProcessOverdueEvent() {
        TrackedProcess tp = new TrackedProcess();
        String trackedProcessType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        tp.setMetadata(getMetadata(trackedProcessType));
        tp.setTrackedProcessType(trackedProcessType);
        UUID tpId = GTTUtils.UUIDUtils.generateTimeBasedUUID();
        tp.setId(tpId);
        tp.setProcessStatus(ProcessStatus.AS_PLANNED.name());
        List<PlannedEvent> pes = new ArrayList<>();
        PlannedEvent plannedEvent = new PlannedEvent();
        plannedEvent.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.PlannedEvent"));
        plannedEvent.setId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        plannedEvent.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POConfirmedEvent");
        plannedEvent.setPlannedTechTsLatest(Instant.parse("2019-05-22T12:00:00.213Z"));
        plannedEvent.setPlannedBusinessTimestamp(Instant.parse("2019-05-15T12:00:00.213Z"));
        plannedEvent.setPlannedBizTsEarliest(Instant.parse("2019-05-09T12:00:00.213Z"));
        plannedEvent.setPlannedBizTsLatest(Instant.parse("2019-05-22T12:00:00.213Z"));
        plannedEvent.setEventStatus(EventStatus.PLANNED.name());
        plannedEvent.setOverdueDetectionCounter(0);
        plannedEvent.setNextOverdueDetection(plannedEvent.getPlannedTechTsLatest());
        plannedEvent.setIsFinalPlannedEvent(Boolean.FALSE);
        plannedEvent.setEventMatchKey("10");
        plannedEvent.setLastProcessEventDirectoryId(null);
        plannedEvent.setEventStatus(EventStatus.PLANNED.name());
        pes.add(plannedEvent);
        tp.setPlannedEvents(pes);
        List<QualifiedTrackingId> trackingIds = new ArrayList<>();
        QualifiedTrackingId trackingId = QualifiedTrackingId.build(tpId, tpId, null, null);
        trackingId.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.QualifiedTrackingId"));
        trackingIds.add(trackingId);
        tp.setTrackingIds(trackingIds);
        List<ProcessEventDirectory> peds = new ArrayList<>();
        ProcessEventDirectory ped = ProcessEventDirectory.build(GTTUtils.UUIDUtils.generateTimeBasedUUID(),
                tpId, null, GTTUtils.UUIDUtils.generateTimeBasedUUID(), CorrelationType.UNPLANNED_PROCESS_CREATION_UPDATE.name());
        peds.add(ped);
        tp.setPEDs(peds);
        given(processManagement.get(any(), Mockito.any(UUIDValue.class))).willReturn(tp);

        OverdueEvent eventMessage = new OverdueEvent();
        eventMessage.setId(UUID.randomUUID());
        eventMessage.setRefPlannedEventUUID(plannedEvent.getId());
        eventMessage.setAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:ProcurementOrderItem:10");
        eventMessage.setEventType("com.sap.gtt.core.CoreModel.GTTOverdueEvent");
        eventMessage.setModelNamespace("com.sap.gtt.app.mim");
        eventMessage.setEventReasonText("Overdue detected");
        eventMessage.setActualBusinessTimestamp(Instant.now());
        eventMessage.setMetadata(getMetadata(eventMessage.getEventType()));
        List<Event> messages = new ArrayList<>();
        messages.add(eventMessage);
        MetadataEntityEvent eventConfig = new MetadataEntityEvent();
        eventConfig.setMatchLocation(false);
        eventConfig.setMaxOverdueDetection(3);
        eventConfig.setPeriodicOverdueDetection(Duration.parse("PT24H"));
        given(metadataManagement.getEntityEvent(Mockito.anyString(), Mockito.anyString())).willReturn(eventConfig);
        service.processEvents(messages, "requestId", "writeServiceId");

        ArgumentCaptor<List<Event>> argumentCaptorEvent = ArgumentCaptor.forClass(List.class);
        verify(eventManagement, times(1)).post(argumentCaptorEvent.capture());
        List<Event> capturedEvent = argumentCaptorEvent.getValue();
        assertThat(capturedEvent).isNotNull();

        ArgumentCaptor<TrackedProcess> argumentCaptorTrackedProcess = ArgumentCaptor.forClass(TrackedProcess.class);
        ArgumentCaptor<PlannedEvent> argumentCaptorPE = ArgumentCaptor.forClass(PlannedEvent.class);
        ArgumentCaptor<ProcessEventDirectory> argumentCaptorPED = ArgumentCaptor.forClass(ProcessEventDirectory.class);
        verify(processManagement, times(1)).update(argumentCaptorTrackedProcess.capture(), argumentCaptorPED.capture(), argumentCaptorPE.capture());
        TrackedProcess rstTP = argumentCaptorTrackedProcess.getValue();
        assertThat(rstTP.getTrackingIds().size()).isEqualTo(1);
        assertThat(rstTP.getProcessStatus()).isEqualTo(ProcessStatus.OVERDUE.name());
        PlannedEvent capturedPE = argumentCaptorPE.<List<String>>getValue();
        assertThat(capturedPE.getId()).isEqualTo(eventMessage.getRefPlannedEventUUID());
        ProcessEventDirectory capturedPED = argumentCaptorPED.<List<String>>getValue();
        assertThat(capturedPED.getCorrelationType()).isEqualTo(CorrelationType.UNPLANNED_OVERDUE.name());
    }

    @Test
    public void testProcessGTTDelayedEventWhenNoMatch() {
        TrackedProcess tp = new TrackedProcess();
        String trackedProcessType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        tp.setMetadata(getMetadata(trackedProcessType));
        tp.setTrackedProcessType(trackedProcessType);
        UUID tpId = GTTUtils.UUIDUtils.generateTimeBasedUUID();
        tp.setId(tpId);
        tp.setProcessStatus(ProcessStatus.AS_PLANNED.name());
        List<PlannedEvent> pes = new ArrayList<>();
        PlannedEvent plannedEvent = new PlannedEvent();
        plannedEvent.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.PlannedEvent"));
        plannedEvent.setId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        plannedEvent.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POConfirmedEvent");
        plannedEvent.setEventMatchKey("10");
        plannedEvent.setPlannedTechTsLatest(Instant.parse("2019-05-22T12:00:00.213Z"));
        plannedEvent.setPlannedBusinessTimestamp(Instant.parse("2019-05-15T12:00:00.213Z"));
        plannedEvent.setPlannedBizTsEarliest(Instant.parse("2019-05-09T12:00:00.213Z"));
        plannedEvent.setPlannedBizTsLatest(Instant.parse("2019-05-22T12:00:00.213Z"));
        plannedEvent.setEventStatus(EventStatus.PLANNED.name());
        plannedEvent.setOverdueDetectionCounter(0);
        plannedEvent.setNextOverdueDetection(plannedEvent.getPlannedTechTsLatest());
        plannedEvent.setIsFinalPlannedEvent(Boolean.FALSE);
        plannedEvent.setLastProcessEventDirectoryId(null);
        plannedEvent.setEventStatus(EventStatus.PLANNED.name());
        pes.add(plannedEvent);
        tp.setPlannedEvents(pes);
        List<QualifiedTrackingId> trackingIds = new ArrayList<>();
        QualifiedTrackingId trackingId = QualifiedTrackingId.build(tpId, tpId, null, null);
        trackingId.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.QualifiedTrackingId"));
        trackingIds.add(trackingId);
        tp.setTrackingIds(trackingIds);
        List<ProcessEventDirectory> peds = new ArrayList<>();
        ProcessEventDirectory ped = ProcessEventDirectory.build(GTTUtils.UUIDUtils.generateTimeBasedUUID(),
                tpId, null, GTTUtils.UUIDUtils.generateTimeBasedUUID(), CorrelationType.UNPLANNED_PROCESS_CREATION_UPDATE.name());
        peds.add(ped);
        tp.setPEDs(peds);
        given(processManagement.getWithOnlyValidDPPStatus(Mockito.any(UUIDValue.class))).willReturn(tp);

        Event eventMessage = new Event();
        eventMessage.setId(UUID.randomUUID());
        eventMessage.setAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:ProcurementOrderItem:10");
        eventMessage.setModelNamespace("com.sap.gtt.app.mim");
        eventMessage.setEventType("com.sap.gtt.core.CoreModel.GTTDelayedEvent");
        eventMessage.setEventReasonText("Delayed Event");
        eventMessage.setActualBusinessTimestamp(Instant.now());
        eventMessage.setValue(REF_PLANNED_EVENT_TYPE, plannedEvent.getEventType());
        eventMessage.setMetadata(getMetadata(eventMessage.getEventType()));
        List<Event> messages = new ArrayList<>();
        messages.add(eventMessage);
        MetadataEntityEvent eventConfig = new MetadataEntityEvent();
        eventConfig.setMatchLocation(false);
        eventConfig.setMaxOverdueDetection(3);
        eventConfig.setPeriodicOverdueDetection(Duration.parse("PT24H"));
        given(metadataManagement.getEntityEvent(Mockito.anyString(), Mockito.anyString())).willReturn(eventConfig);
        given(metadataManagement.checkIfEventIsUnplanned(Mockito.anyString(), Mockito.anyString())).willReturn(true);
        service.processEvents(messages, "requestId", "writeServiceId");

        ArgumentCaptor<List<Event>> argumentCaptorEvent = ArgumentCaptor.forClass(List.class);
        verify(eventManagement, times(1)).post(argumentCaptorEvent.capture());
        List<Event> capturedEvent = argumentCaptorEvent.getValue();
        assertThat(capturedEvent).isNotNull();

        ArgumentCaptor<TrackedProcess> argumentCaptorTrackedProcess = ArgumentCaptor.forClass(TrackedProcess.class);
        ArgumentCaptor<PlannedEvent> argumentCaptorPE = ArgumentCaptor.forClass(PlannedEvent.class);
        ArgumentCaptor<ProcessEventDirectory> argumentCaptorPED = ArgumentCaptor.forClass(ProcessEventDirectory.class);
        verify(processManagement, times(1)).update(argumentCaptorTrackedProcess.capture(), argumentCaptorPED.capture(), argumentCaptorPE.capture());
        TrackedProcess rstTP = argumentCaptorTrackedProcess.getValue();
        assertThat(rstTP.getTrackingIds().size()).isEqualTo(1);
        assertThat(rstTP.getProcessStatus()).isEqualTo(ProcessStatus.AS_PLANNED.name());
        PlannedEvent capturedPE = argumentCaptorPE.<List<String>>getValue();
        assertThat(capturedPE).isNull();
        ProcessEventDirectory capturedPED = argumentCaptorPED.<List<String>>getValue();
        assertThat(capturedPED.getCorrelationType()).isEqualTo(CorrelationType.UNPLANNED_DELAYED.name());
    }

    @Test
    public void testProcessGTTDelayedEventWhenLocationMatchedFalse() {
        TrackedProcess tp = new TrackedProcess();
        String trackedProcessType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        tp.setMetadata(getMetadata(trackedProcessType));
        tp.setTrackedProcessType(trackedProcessType);
        UUID tpId = GTTUtils.UUIDUtils.generateTimeBasedUUID();
        tp.setId(tpId);
        tp.setProcessStatus(ProcessStatus.AS_PLANNED.name());
        List<PlannedEvent> pes = new ArrayList<>();
        PlannedEvent plannedEvent = new PlannedEvent();
        plannedEvent.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.PlannedEvent"));
        plannedEvent.setId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        plannedEvent.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POConfirmedEvent");
        plannedEvent.setEventMatchKey("10");
        plannedEvent.setPlannedTechTsLatest(Instant.parse("2019-05-22T12:00:00.213Z"));
        plannedEvent.setPlannedBusinessTimestamp(Instant.parse("2019-05-15T12:00:00.213Z"));
        plannedEvent.setPlannedBizTsEarliest(Instant.parse("2019-05-09T12:00:00.213Z"));
        plannedEvent.setPlannedBizTsLatest(Instant.parse("2019-05-22T12:00:00.213Z"));
        plannedEvent.setEventStatus(EventStatus.PLANNED.name());
        plannedEvent.setOverdueDetectionCounter(0);
        plannedEvent.setNextOverdueDetection(plannedEvent.getPlannedTechTsLatest());
        plannedEvent.setIsFinalPlannedEvent(Boolean.FALSE);
        plannedEvent.setLastProcessEventDirectoryId(null);
        plannedEvent.setEventStatus(EventStatus.PLANNED.name());
        pes.add(plannedEvent);
        tp.setPlannedEvents(pes);
        List<QualifiedTrackingId> trackingIds = new ArrayList<>();
        QualifiedTrackingId trackingId = QualifiedTrackingId.build(tpId, tpId, null, null);
        trackingId.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.QualifiedTrackingId"));
        trackingIds.add(trackingId);
        tp.setTrackingIds(trackingIds);
        List<ProcessEventDirectory> peds = new ArrayList<>();
        ProcessEventDirectory ped = ProcessEventDirectory.build(GTTUtils.UUIDUtils.generateTimeBasedUUID(),
                tpId, null, GTTUtils.UUIDUtils.generateTimeBasedUUID(), CorrelationType.UNPLANNED_PROCESS_CREATION_UPDATE.name());
        peds.add(ped);
        tp.setPEDs(peds);
        given(processManagement.getWithOnlyValidDPPStatus(Mockito.any(UUIDValue.class))).willReturn(tp);

        Event eventMessage = new Event();
        eventMessage.setId(UUID.randomUUID());
        eventMessage.setAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:ProcurementOrderItem:10");
        eventMessage.setModelNamespace("com.sap.gtt.app.mim");
        eventMessage.setEventType("com.sap.gtt.core.CoreModel.GTTDelayedEvent");
        eventMessage.setEventReasonText("Delayed Event");
        eventMessage.setActualBusinessTimestamp(Instant.now());
        eventMessage.setValue(REF_PLANNED_EVENT_TYPE, plannedEvent.getEventType());
        eventMessage.setValue(REF_PLANNED_EVENT_MATCH_KEY, plannedEvent.getEventMatchKey());
        eventMessage.setMetadata(getMetadata(eventMessage.getEventType()));
        List<Event> messages = new ArrayList<>();
        messages.add(eventMessage);
        MetadataEntityEvent eventConfig = new MetadataEntityEvent();
        eventConfig.setMatchLocation(false);
        eventConfig.setMaxOverdueDetection(3);
        eventConfig.setPeriodicOverdueDetection(Duration.parse("PT24H"));
        given(metadataManagement.getEntityEvent(Mockito.anyString(), Mockito.anyString())).willReturn(eventConfig);
        service.processEvents(messages, "requestId", "writeServiceId");

        ArgumentCaptor<List<Event>> argumentCaptorEvent = ArgumentCaptor.forClass(List.class);
        verify(eventManagement, times(1)).post(argumentCaptorEvent.capture());
        List<Event> capturedEvent = argumentCaptorEvent.getValue();
        assertThat(capturedEvent).isNotNull();

        ArgumentCaptor<TrackedProcess> argumentCaptorTrackedProcess = ArgumentCaptor.forClass(TrackedProcess.class);
        ArgumentCaptor<PlannedEvent> argumentCaptorPE = ArgumentCaptor.forClass(PlannedEvent.class);
        ArgumentCaptor<ProcessEventDirectory> argumentCaptorPED = ArgumentCaptor.forClass(ProcessEventDirectory.class);
        verify(processManagement, times(1)).update(argumentCaptorTrackedProcess.capture(), argumentCaptorPED.capture(), argumentCaptorPE.capture());
        TrackedProcess rstTP = argumentCaptorTrackedProcess.getValue();
        assertThat(rstTP.getTrackingIds().size()).isEqualTo(1);
        assertThat(rstTP.getProcessStatus()).isEqualTo(ProcessStatus.DELAYED.name());
        PlannedEvent capturedPE = argumentCaptorPE.<List<String>>getValue();
        assertThat(capturedPE.getId()).isEqualTo(plannedEvent.getId());
        assertThat(capturedPE.getEventStatus()).isEqualTo(EventStatus.DELAYED.name());
        ProcessEventDirectory capturedPED = argumentCaptorPED.<List<String>>getValue();
        assertThat(capturedPED.getCorrelationType()).isEqualTo(CorrelationType.UNPLANNED_DELAYED.name());
    }

    @Test
    //9
    public void testProcessGTTDelayedEventWhenLocationMatchedTrue() {
        TrackedProcess tp = new TrackedProcess();
        String trackedProcessType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        tp.setMetadata(getMetadata(trackedProcessType));
        tp.setTrackedProcessType(trackedProcessType);
        UUID tpId = GTTUtils.UUIDUtils.generateTimeBasedUUID();
        tp.setId(tpId);
        tp.setProcessStatus(ProcessStatus.AS_PLANNED.name());
        List<PlannedEvent> pes = new ArrayList<>();
        PlannedEvent plannedEvent = new PlannedEvent();
        plannedEvent.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.PlannedEvent"));
        plannedEvent.setId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        plannedEvent.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POConfirmedEvent");
        plannedEvent.setEventMatchKey("10");
        plannedEvent.setLocationAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:Location:shippingPoint:4712");
        plannedEvent.setPlannedTechTsLatest(Instant.parse("2019-05-22T12:00:00.213Z"));
        plannedEvent.setPlannedBusinessTimestamp(Instant.parse("2019-05-15T12:00:00.213Z"));
        plannedEvent.setPlannedBizTsEarliest(Instant.parse("2019-05-09T12:00:00.213Z"));
        plannedEvent.setPlannedBizTsLatest(Instant.parse("2019-05-22T12:00:00.213Z"));
        plannedEvent.setEventStatus(EventStatus.PLANNED.name());
        plannedEvent.setOverdueDetectionCounter(0);
        plannedEvent.setNextOverdueDetection(plannedEvent.getPlannedTechTsLatest());
        plannedEvent.setIsFinalPlannedEvent(Boolean.FALSE);
        plannedEvent.setLastProcessEventDirectoryId(null);
        plannedEvent.setEventStatus(EventStatus.PLANNED.name());
        pes.add(plannedEvent);
        tp.setPlannedEvents(pes);
        List<QualifiedTrackingId> trackingIds = new ArrayList<>();
        QualifiedTrackingId trackingId = QualifiedTrackingId.build(tpId, tpId, null, null);
        trackingId.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.QualifiedTrackingId"));
        trackingIds.add(trackingId);
        tp.setTrackingIds(trackingIds);
        List<ProcessEventDirectory> peds = new ArrayList<>();
        ProcessEventDirectory ped = ProcessEventDirectory.build(GTTUtils.UUIDUtils.generateTimeBasedUUID(),
                tpId, null, GTTUtils.UUIDUtils.generateTimeBasedUUID(), CorrelationType.UNPLANNED_PROCESS_CREATION_UPDATE.name());
        peds.add(ped);
        tp.setPEDs(peds);
        given(processManagement.getWithOnlyValidDPPStatus(Mockito.any(UUIDValue.class))).willReturn(tp);

        Event eventMessage = new Event();
        eventMessage.setId(UUID.randomUUID());
        eventMessage.setAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:ProcurementOrderItem:10");
        eventMessage.setModelNamespace("com.sap.gtt.app.mim");
        eventMessage.setEventType("com.sap.gtt.core.CoreModel.GTTDelayedEvent");
        eventMessage.setEventReasonText("Delayed Event");
        eventMessage.setActualBusinessTimestamp(Instant.now());
        eventMessage.setValue(Constant.REF_PLANNED_EVENT_TYPE, plannedEvent.getEventType());
        eventMessage.setValue(REF_PLANNED_EVENT_MATCH_KEY, plannedEvent.getEventMatchKey());
        eventMessage.setValue(Constant.REF_PLANNED_EVENT_LOCATION_ALEKEY, "xri://sap.com/sapdoc:666666:Q8JCLNT774:Location:shippingPoint:4712");
        eventMessage.setMetadata(getMetadata(eventMessage.getEventType()));
        List<Event> messages = new ArrayList<>();
        messages.add(eventMessage);
        MetadataEntityEvent eventConfig = new MetadataEntityEvent();
        eventConfig.setMatchLocation(true);
        eventConfig.setMaxOverdueDetection(3);
        eventConfig.setPeriodicOverdueDetection(Duration.parse("PT24H"));
        given(metadataManagement.getEntityEvent(Mockito.anyString(), Mockito.anyString())).willReturn(eventConfig);

        service.processEvents(messages, "requestId", "writeServiceId");
        ArgumentCaptor<List<Event>> argumentCaptorEvent = ArgumentCaptor.forClass(List.class);
        verify(eventManagement, times(1)).post(argumentCaptorEvent.capture());
        List<Event> capturedEvent = argumentCaptorEvent.getValue();
        assertThat(capturedEvent).isNotNull();

        ArgumentCaptor<TrackedProcess> argumentCaptorTrackedProcess = ArgumentCaptor.forClass(TrackedProcess.class);
        ArgumentCaptor<PlannedEvent> argumentCaptorPE = ArgumentCaptor.forClass(PlannedEvent.class);
        ArgumentCaptor<ProcessEventDirectory> argumentCaptorPED = ArgumentCaptor.forClass(ProcessEventDirectory.class);
        verify(processManagement, times(1)).update(argumentCaptorTrackedProcess.capture(), argumentCaptorPED.capture(), argumentCaptorPE.capture());
        TrackedProcess rstTP = argumentCaptorTrackedProcess.getValue();
        assertThat(rstTP.getTrackingIds().size()).isEqualTo(1);
        assertThat(rstTP.getProcessStatus()).isEqualTo(ProcessStatus.DELAYED.name());
        PlannedEvent capturedPE = argumentCaptorPE.<List<String>>getValue();
        assertThat(capturedPE.getId()).isEqualTo(plannedEvent.getId());
        assertThat(capturedPE.getEventStatus()).isEqualTo(EventStatus.DELAYED.name());
        ProcessEventDirectory capturedPED = argumentCaptorPED.<List<String>>getValue();
        assertThat(capturedPED.getCorrelationType()).isEqualTo(CorrelationType.UNPLANNED_DELAYED.name());
    }

    @Test
    public void testProcessGTTDelayedEventWhenPlannedEventIsReported() {
        TrackedProcess tp = new TrackedProcess();
        String trackedProcessType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        tp.setMetadata(getMetadata(trackedProcessType));
        tp.setTrackedProcessType(trackedProcessType);
        UUID tpId = GTTUtils.UUIDUtils.generateTimeBasedUUID();
        tp.setId(tpId);
        tp.setProcessStatus(ProcessStatus.AS_PLANNED.name());
        List<PlannedEvent> pes = new ArrayList<>();
        PlannedEvent plannedEvent = new PlannedEvent();
        plannedEvent.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.PlannedEvent"));
        plannedEvent.setId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        plannedEvent.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POConfirmedEvent");
        plannedEvent.setEventMatchKey("10");
        plannedEvent.setLocationAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:Location:shippingPoint:4712");
        plannedEvent.setPlannedTechTsLatest(Instant.parse("2019-05-22T12:00:00.213Z"));
        plannedEvent.setPlannedBusinessTimestamp(Instant.parse("2019-05-15T12:00:00.213Z"));
        plannedEvent.setPlannedBizTsEarliest(Instant.parse("2019-05-09T12:00:00.213Z"));
        plannedEvent.setPlannedBizTsLatest(Instant.parse("2019-05-22T12:00:00.213Z"));
        plannedEvent.setEventStatus(EventStatus.REPORTED.name());
        plannedEvent.setOverdueDetectionCounter(0);
        plannedEvent.setNextOverdueDetection(plannedEvent.getPlannedTechTsLatest());
        plannedEvent.setIsFinalPlannedEvent(Boolean.FALSE);
        UUID pedId = UUID.randomUUID();
        plannedEvent.setLastProcessEventDirectoryId(pedId);
        pes.add(plannedEvent);
        tp.setPlannedEvents(pes);
        List<QualifiedTrackingId> trackingIds = new ArrayList<>();
        QualifiedTrackingId trackingId = QualifiedTrackingId.build(tpId, tpId, null, null);
        trackingId.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.QualifiedTrackingId"));
        trackingIds.add(trackingId);
        tp.setTrackingIds(trackingIds);
        List<ProcessEventDirectory> peds = new ArrayList<>();
        ProcessEventDirectory ped = ProcessEventDirectory.build(GTTUtils.UUIDUtils.generateTimeBasedUUID(),
                tpId, null, GTTUtils.UUIDUtils.generateTimeBasedUUID(), CorrelationType.UNPLANNED_PROCESS_CREATION_UPDATE.name());
        peds.add(ped);
        UUID reportedEventId = UUID.randomUUID();
        ProcessEventDirectory ped2 = ProcessEventDirectory.build(pedId, tpId, plannedEvent.getId(), reportedEventId, CorrelationType.REPORTED.name());
        peds.add(ped2);
        tp.setPEDs(peds);
        given(processManagement.getWithOnlyValidDPPStatus(Mockito.any(UUIDValue.class))).willReturn(tp);
        Instant now = Instant.now();
        Event reportedEvent = new Event();
        reportedEvent.setActualBusinessTimestamp(now.minusSeconds(60));
        given(eventManagement.getSingleEventById(Mockito.any(UUIDValue.class))).willReturn(reportedEvent);

        Event eventMessage = new Event();
        eventMessage.setId(UUID.randomUUID());
        eventMessage.setAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:ProcurementOrderItem:10");
        eventMessage.setModelNamespace("com.sap.gtt.app.mim");
        eventMessage.setEventType("com.sap.gtt.core.CoreModel.GTTDelayedEvent");
        eventMessage.setEventReasonText("Delayed Event");
        eventMessage.setActualBusinessTimestamp(now);
        eventMessage.setValue(Constant.REF_PLANNED_EVENT_TYPE, plannedEvent.getEventType());
        //eventMessage.setEventMatchKey(plannedEvent.getEventMatchKey());
        eventMessage.setValue(REF_PLANNED_EVENT_MATCH_KEY, plannedEvent.getEventMatchKey());
        eventMessage.setValue(Constant.REF_PLANNED_EVENT_LOCATION_ALEKEY, "xri://sap.com/sapdoc:666666:Q8JCLNT774:Location:shippingPoint:4712");
        eventMessage.setMetadata(getMetadata(eventMessage.getEventType()));
        List<Event> messages = new ArrayList<>();
        messages.add(eventMessage);
        MetadataEntityEvent eventConfig = new MetadataEntityEvent();
        eventConfig.setMatchLocation(true);
        eventConfig.setMaxOverdueDetection(3);
        eventConfig.setPeriodicOverdueDetection(Duration.parse("PT24H"));
        given(metadataManagement.getEntityEvent(Mockito.anyString(), Mockito.anyString())).willReturn(eventConfig);

        service.processEvents(messages, "requestId", "writeServiceId");
        ArgumentCaptor<List<Event>> argumentCaptorEvent = ArgumentCaptor.forClass(List.class);
        verify(eventManagement, times(1)).post(argumentCaptorEvent.capture());
        List<Event> capturedEvent = argumentCaptorEvent.getValue();
        assertThat(capturedEvent).isNotNull();

        verify(processManagement, times(0)).update(Mockito.any(), Mockito.any(), Mockito.any());
    }

    @Test
    public void testProcessGTTDelayedEventWhenPlannedEventIsReportedButDelayedEventIsEalier() {
        TrackedProcess tp = new TrackedProcess();
        String trackedProcessType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        tp.setMetadata(getMetadata(trackedProcessType));
        tp.setTrackedProcessType(trackedProcessType);
        UUID tpId = GTTUtils.UUIDUtils.generateTimeBasedUUID();
        tp.setId(tpId);
        tp.setProcessStatus(ProcessStatus.EARLY.name());
        List<PlannedEvent> pes = new ArrayList<>();
        PlannedEvent plannedEvent = new PlannedEvent();
        plannedEvent.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.PlannedEvent"));
        plannedEvent.setId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        plannedEvent.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POConfirmedEvent");
        plannedEvent.setEventMatchKey("10");
        plannedEvent.setLocationAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:Location:shippingPoint:4712");
        plannedEvent.setPlannedTechTsLatest(Instant.parse("2019-05-22T12:00:00.213Z"));
        plannedEvent.setPlannedBusinessTimestamp(Instant.parse("2019-05-15T12:00:00.213Z"));
        plannedEvent.setPlannedBizTsEarliest(Instant.parse("2019-05-09T12:00:00.213Z"));
        plannedEvent.setPlannedBizTsLatest(Instant.parse("2019-05-22T12:00:00.213Z"));
        plannedEvent.setEventStatus(EventStatus.EARLY_REPORTED.name());
        plannedEvent.setOverdueDetectionCounter(0);
        plannedEvent.setNextOverdueDetection(plannedEvent.getPlannedTechTsLatest());
        plannedEvent.setIsFinalPlannedEvent(Boolean.FALSE);
        UUID pedId = UUID.randomUUID();
        plannedEvent.setLastProcessEventDirectoryId(pedId);
        pes.add(plannedEvent);
        tp.setPlannedEvents(pes);
        List<QualifiedTrackingId> trackingIds = new ArrayList<>();
        QualifiedTrackingId trackingId = QualifiedTrackingId.build(tpId, tpId, null, null);
        trackingId.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.QualifiedTrackingId"));
        trackingIds.add(trackingId);
        tp.setTrackingIds(trackingIds);
        List<ProcessEventDirectory> peds = new ArrayList<>();
        ProcessEventDirectory ped = ProcessEventDirectory.build(GTTUtils.UUIDUtils.generateTimeBasedUUID(),
                tpId, null, GTTUtils.UUIDUtils.generateTimeBasedUUID(), CorrelationType.UNPLANNED_PROCESS_CREATION_UPDATE.name());
        peds.add(ped);
        UUID reportedEventId = UUID.randomUUID();
        ProcessEventDirectory ped2 = ProcessEventDirectory.build(pedId, tpId, plannedEvent.getId(), reportedEventId, CorrelationType.REPORTED.name());
        peds.add(ped2);
        tp.setPEDs(peds);
        given(processManagement.getWithOnlyValidDPPStatus(Mockito.any(UUIDValue.class))).willReturn(tp);
        Instant now = Instant.now();
        Event reportedEvent = new Event();
        reportedEvent.setActualBusinessTimestamp(now);
        reportedEvent.setPriority(0);
        given(eventManagement.getSingleEventById(Mockito.any(UUIDValue.class))).willReturn(reportedEvent);

        Event eventMessage = new Event();
        eventMessage.setId(UUID.randomUUID());
        eventMessage.setAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:ProcurementOrderItem:10");
        eventMessage.setModelNamespace("com.sap.gtt.app.mim");
        eventMessage.setEventType("com.sap.gtt.core.CoreModel.GTTDelayedEvent");
        eventMessage.setEventReasonText("Delayed Event");
        eventMessage.setActualBusinessTimestamp(now.minusSeconds(60));
        eventMessage.setValue(Constant.REF_PLANNED_EVENT_TYPE, plannedEvent.getEventType());
        //eventMessage.setEventMatchKey(plannedEvent.getEventMatchKey());
        eventMessage.setValue(REF_PLANNED_EVENT_MATCH_KEY, plannedEvent.getEventMatchKey());
        eventMessage.setValue(Constant.REF_PLANNED_EVENT_LOCATION_ALEKEY, "xri://sap.com/sapdoc:666666:Q8JCLNT774:Location:shippingPoint:4712");
        eventMessage.setMetadata(getMetadata(eventMessage.getEventType()));
        List<Event> messages = new ArrayList<>();
        messages.add(eventMessage);
        MetadataEntityEvent eventConfig = new MetadataEntityEvent();
        eventConfig.setMatchLocation(true);
        eventConfig.setMaxOverdueDetection(3);
        eventConfig.setPeriodicOverdueDetection(Duration.parse("PT24H"));
        given(metadataManagement.getEntityEvent(Mockito.anyString(), Mockito.anyString())).willReturn(eventConfig);

        service.processEvents(messages, "requestId", "writeServiceId");
        ArgumentCaptor<List<Event>> argumentCaptorEvent = ArgumentCaptor.forClass(List.class);
        verify(eventManagement, times(1)).post(argumentCaptorEvent.capture());
        List<Event> capturedEvent = argumentCaptorEvent.getValue();
        assertThat(capturedEvent).isNotNull();

        ArgumentCaptor<TrackedProcess> argumentCaptorTrackedProcess = ArgumentCaptor.forClass(TrackedProcess.class);
        ArgumentCaptor<PlannedEvent> argumentCaptorPE = ArgumentCaptor.forClass(PlannedEvent.class);
        ArgumentCaptor<ProcessEventDirectory> argumentCaptorPED = ArgumentCaptor.forClass(ProcessEventDirectory.class);
        verify(processManagement, times(1)).update(argumentCaptorTrackedProcess.capture(), argumentCaptorPED.capture(), argumentCaptorPE.capture());
        TrackedProcess rstTP = argumentCaptorTrackedProcess.getValue();
        assertThat(rstTP.getTrackingIds().size()).isEqualTo(1);
        assertThat(rstTP.getProcessStatus()).isEqualTo(ProcessStatus.EARLY.name());
        PlannedEvent capturedPE = argumentCaptorPE.<List<String>>getValue();
        assertThat(capturedPE.getId()).isEqualTo(plannedEvent.getId());
        assertThat(capturedPE.getEventStatus()).isEqualTo(EventStatus.EARLY_REPORTED.name());
        ProcessEventDirectory capturedPED = argumentCaptorPED.<List<String>>getValue();
        assertThat(capturedPED.getCorrelationType()).isEqualTo(CorrelationType.UNPLANNED_DELAYED.name());
    }

    @Test
    public void testProcessGTTDelayedEventWhenPlannedEventIsDelayed() {
        TrackedProcess tp = new TrackedProcess();
        String trackedProcessType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        tp.setMetadata(getMetadata(trackedProcessType));
        tp.setTrackedProcessType(trackedProcessType);
        UUID tpId = GTTUtils.UUIDUtils.generateTimeBasedUUID();
        tp.setId(tpId);
        tp.setProcessStatus(ProcessStatus.DELAYED.name());
        List<PlannedEvent> pes = new ArrayList<>();
        PlannedEvent plannedEvent = new PlannedEvent();
        plannedEvent.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.PlannedEvent"));
        plannedEvent.setId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        plannedEvent.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POConfirmedEvent");
        plannedEvent.setEventMatchKey("10");
        plannedEvent.setLocationAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:Location:shippingPoint:4712");
        plannedEvent.setPlannedTechTsLatest(Instant.parse("2019-05-22T12:00:00.213Z"));
        plannedEvent.setPlannedBusinessTimestamp(Instant.parse("2019-05-15T12:00:00.213Z"));
        plannedEvent.setPlannedBizTsEarliest(Instant.parse("2019-05-09T12:00:00.213Z"));
        plannedEvent.setPlannedBizTsLatest(Instant.parse("2019-05-22T12:00:00.213Z"));
        plannedEvent.setEventStatus(EventStatus.DELAYED.name());
        plannedEvent.setOverdueDetectionCounter(0);
        plannedEvent.setNextOverdueDetection(plannedEvent.getPlannedTechTsLatest());
        plannedEvent.setIsFinalPlannedEvent(Boolean.FALSE);
        UUID pedId = UUID.randomUUID();
        plannedEvent.setLastProcessEventDirectoryId(pedId);
        pes.add(plannedEvent);
        tp.setPlannedEvents(pes);
        List<QualifiedTrackingId> trackingIds = new ArrayList<>();
        QualifiedTrackingId trackingId = QualifiedTrackingId.build(tpId, tpId, null, null);
        trackingId.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.QualifiedTrackingId"));
        trackingIds.add(trackingId);
        tp.setTrackingIds(trackingIds);
        List<ProcessEventDirectory> peds = new ArrayList<>();
        ProcessEventDirectory ped = ProcessEventDirectory.build(GTTUtils.UUIDUtils.generateTimeBasedUUID(),
                tpId, null, GTTUtils.UUIDUtils.generateTimeBasedUUID(), CorrelationType.UNPLANNED_PROCESS_CREATION_UPDATE.name());
        peds.add(ped);
        UUID reportedEventId = UUID.randomUUID();
        ProcessEventDirectory ped2 = ProcessEventDirectory.build(pedId, tpId, plannedEvent.getId(), reportedEventId, CorrelationType.UNPLANNED_DELAYED.name());
        peds.add(ped2);
        tp.setPEDs(peds);
        given(processManagement.getWithOnlyValidDPPStatus(Mockito.any(UUIDValue.class))).willReturn(tp);
        Instant now = Instant.now();
        Event reportedEvent = new Event();
        reportedEvent.setActualBusinessTimestamp(now);
        given(eventManagement.getSingleEventById(Mockito.any(UUIDValue.class))).willReturn(reportedEvent);

        Event eventMessage = new Event();
        eventMessage.setId(UUID.randomUUID());
        eventMessage.setAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:ProcurementOrderItem:10");
        eventMessage.setModelNamespace("com.sap.gtt.app.mim");
        eventMessage.setEventType("com.sap.gtt.core.CoreModel.GTTDelayedEvent");
        eventMessage.setEventReasonText("Delayed Event");
        eventMessage.setActualBusinessTimestamp(now.minusSeconds(60));
        eventMessage.setValue(Constant.REF_PLANNED_EVENT_TYPE, plannedEvent.getEventType());
        //eventMessage.setEventMatchKey(plannedEvent.getEventMatchKey());
        eventMessage.setValue(REF_PLANNED_EVENT_MATCH_KEY, plannedEvent.getEventMatchKey());
        eventMessage.setValue(Constant.REF_PLANNED_EVENT_LOCATION_ALEKEY, "xri://sap.com/sapdoc:666666:Q8JCLNT774:Location:shippingPoint:4712");
        eventMessage.setMetadata(getMetadata(eventMessage.getEventType()));
        List<Event> messages = new ArrayList<>();
        messages.add(eventMessage);
        MetadataEntityEvent eventConfig = new MetadataEntityEvent();
        eventConfig.setMatchLocation(true);
        eventConfig.setMaxOverdueDetection(3);
        eventConfig.setPeriodicOverdueDetection(Duration.parse("PT24H"));
        given(metadataManagement.getEntityEvent(Mockito.anyString(), Mockito.anyString())).willReturn(eventConfig);

        service.processEvents(messages, "requestId", "writeServiceId");
        ArgumentCaptor<List<Event>> argumentCaptorEvent = ArgumentCaptor.forClass(List.class);
        verify(eventManagement, times(1)).post(argumentCaptorEvent.capture());
        List<Event> capturedEvent = argumentCaptorEvent.getValue();
        assertThat(capturedEvent).isNotNull();

        ArgumentCaptor<TrackedProcess> argumentCaptorTrackedProcess = ArgumentCaptor.forClass(TrackedProcess.class);
        ArgumentCaptor<PlannedEvent> argumentCaptorPE = ArgumentCaptor.forClass(PlannedEvent.class);
        ArgumentCaptor<ProcessEventDirectory> argumentCaptorPED = ArgumentCaptor.forClass(ProcessEventDirectory.class);
        verify(processManagement, times(1)).update(argumentCaptorTrackedProcess.capture(), argumentCaptorPED.capture(), argumentCaptorPE.capture());
        TrackedProcess rstTP = argumentCaptorTrackedProcess.getValue();
        assertThat(rstTP.getTrackingIds().size()).isEqualTo(1);
        assertThat(rstTP.getProcessStatus()).isEqualTo(ProcessStatus.DELAYED.name());
        PlannedEvent capturedPE = argumentCaptorPE.<List<String>>getValue();
        assertThat(capturedPE.getId()).isEqualTo(plannedEvent.getId());
        assertThat(capturedPE.getEventStatus()).isEqualTo(EventStatus.DELAYED.name());
        ProcessEventDirectory capturedPED = argumentCaptorPED.<List<String>>getValue();
        assertThat(capturedPED.getCorrelationType()).isEqualTo(CorrelationType.UNPLANNED_DELAYED.name());
    }

    @Test
    public void testProcessGTTDelayedEventWhenPlannedEventIsPlannedWithOnTimeEventAndKeepStatus() {
        TrackedProcess tp = new TrackedProcess();
        String trackedProcessType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        tp.setMetadata(getMetadata(trackedProcessType));
        tp.setTrackedProcessType(trackedProcessType);
        UUID tpId = GTTUtils.UUIDUtils.generateTimeBasedUUID();
        tp.setId(tpId);
        tp.setProcessStatus(ProcessStatus.AS_PLANNED.name());
        List<PlannedEvent> pes = new ArrayList<>();
        PlannedEvent plannedEvent = new PlannedEvent();
        plannedEvent.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.PlannedEvent"));
        plannedEvent.setId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        plannedEvent.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POConfirmedEvent");
        plannedEvent.setEventMatchKey("10");
        plannedEvent.setLocationAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:Location:shippingPoint:4712");
        plannedEvent.setPlannedTechTsLatest(Instant.parse("2019-05-22T12:00:00.213Z"));
        plannedEvent.setPlannedBusinessTimestamp(Instant.parse("2019-05-15T12:00:00.213Z"));
        plannedEvent.setPlannedBizTsEarliest(Instant.parse("2019-05-09T12:00:00.213Z"));
        plannedEvent.setPlannedBizTsLatest(Instant.parse("2019-05-22T12:00:00.213Z"));
        plannedEvent.setEventStatus(EventStatus.PLANNED.name());
        plannedEvent.setOverdueDetectionCounter(0);
        plannedEvent.setNextOverdueDetection(plannedEvent.getPlannedTechTsLatest());
        plannedEvent.setIsFinalPlannedEvent(Boolean.FALSE);
        UUID pedId = UUID.randomUUID();
        plannedEvent.setLastProcessEventDirectoryId(pedId);
        pes.add(plannedEvent);
        tp.setPlannedEvents(pes);
        List<QualifiedTrackingId> trackingIds = new ArrayList<>();
        QualifiedTrackingId trackingId = QualifiedTrackingId.build(tpId, tpId, null, null);
        trackingId.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.QualifiedTrackingId"));
        trackingIds.add(trackingId);
        tp.setTrackingIds(trackingIds);
        List<ProcessEventDirectory> peds = new ArrayList<>();
        ProcessEventDirectory ped = ProcessEventDirectory.build(GTTUtils.UUIDUtils.generateTimeBasedUUID(),
                tpId, null, GTTUtils.UUIDUtils.generateTimeBasedUUID(), CorrelationType.UNPLANNED_PROCESS_CREATION_UPDATE.name());
        peds.add(ped);
        UUID reportedEventId = UUID.randomUUID();
        ProcessEventDirectory ped2 = ProcessEventDirectory.build(pedId, tpId, plannedEvent.getId(), reportedEventId, CorrelationType.UNPLANNED_ONTIME.name());
        peds.add(ped2);
        tp.setPEDs(peds);
        given(processManagement.getWithOnlyValidDPPStatus(Mockito.any(UUIDValue.class))).willReturn(tp);
        Instant now = Instant.now();
        Event reportedEvent = new Event();
        reportedEvent.setActualBusinessTimestamp(now);
        given(eventManagement.getSingleEventById(Mockito.any(UUIDValue.class))).willReturn(reportedEvent);

        Event eventMessage = new Event();
        eventMessage.setId(UUID.randomUUID());
        eventMessage.setAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:ProcurementOrderItem:10");
        eventMessage.setModelNamespace("com.sap.gtt.app.mim");
        eventMessage.setEventType("com.sap.gtt.core.CoreModel.GTTDelayedEvent");
        eventMessage.setEventReasonText("Delayed Event");
        eventMessage.setActualBusinessTimestamp(now.minusSeconds(60));
        eventMessage.setValue(Constant.REF_PLANNED_EVENT_TYPE, plannedEvent.getEventType());
        //eventMessage.setEventMatchKey(plannedEvent.getEventMatchKey());
        eventMessage.setValue(REF_PLANNED_EVENT_MATCH_KEY, plannedEvent.getEventMatchKey());
        eventMessage.setValue(Constant.REF_PLANNED_EVENT_LOCATION_ALEKEY, "xri://sap.com/sapdoc:666666:Q8JCLNT774:Location:shippingPoint:4712");
        eventMessage.setMetadata(getMetadata(eventMessage.getEventType()));
        List<Event> messages = new ArrayList<>();
        messages.add(eventMessage);
        MetadataEntityEvent eventConfig = new MetadataEntityEvent();
        eventConfig.setMatchLocation(true);
        eventConfig.setMaxOverdueDetection(3);
        eventConfig.setPeriodicOverdueDetection(Duration.parse("PT24H"));
        given(metadataManagement.getEntityEvent(Mockito.anyString(), Mockito.anyString())).willReturn(eventConfig);

        service.processEvents(messages, "requestId", "writeServiceId");
        ArgumentCaptor<List<Event>> argumentCaptorEvent = ArgumentCaptor.forClass(List.class);
        verify(eventManagement, times(1)).post(argumentCaptorEvent.capture());
        List<Event> capturedEvent = argumentCaptorEvent.getValue();
        assertThat(capturedEvent).isNotNull();

        ArgumentCaptor<TrackedProcess> argumentCaptorTrackedProcess = ArgumentCaptor.forClass(TrackedProcess.class);
        ArgumentCaptor<PlannedEvent> argumentCaptorPE = ArgumentCaptor.forClass(PlannedEvent.class);
        ArgumentCaptor<ProcessEventDirectory> argumentCaptorPED = ArgumentCaptor.forClass(ProcessEventDirectory.class);
        verify(processManagement, times(1)).update(argumentCaptorTrackedProcess.capture(), argumentCaptorPED.capture(), argumentCaptorPE.capture());
        TrackedProcess rstTP = argumentCaptorTrackedProcess.getValue();
        assertThat(rstTP.getTrackingIds().size()).isEqualTo(1);
        assertThat(rstTP.getProcessStatus()).isEqualTo(ProcessStatus.AS_PLANNED.name());
        PlannedEvent capturedPE = argumentCaptorPE.<List<String>>getValue();
        assertThat(capturedPE.getId()).isEqualTo(plannedEvent.getId());
        assertThat(capturedPE.getEventStatus()).isEqualTo(EventStatus.PLANNED.name());
        assertThat(capturedPE.getLastProcessEventDirectoryId()).isEqualTo(plannedEvent.getLastProcessEventDirectoryId());
        ProcessEventDirectory capturedPED = argumentCaptorPED.<List<String>>getValue();
        assertThat(capturedPED.getCorrelationType()).isEqualTo(CorrelationType.UNPLANNED_DELAYED.name());
    }

    @Test
    public void testProcessGTTDelayedEventWhenPlannedEventIsPlannedWithOnTimeEventAndUpdateStatus() {
        TrackedProcess tp = new TrackedProcess();
        String trackedProcessType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        tp.setMetadata(getMetadata(trackedProcessType));
        tp.setTrackedProcessType(trackedProcessType);
        UUID tpId = GTTUtils.UUIDUtils.generateTimeBasedUUID();
        tp.setId(tpId);
        tp.setProcessStatus(ProcessStatus.AS_PLANNED.name());
        List<PlannedEvent> pes = new ArrayList<>();
        PlannedEvent plannedEvent = new PlannedEvent();
        plannedEvent.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.PlannedEvent"));
        plannedEvent.setId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        plannedEvent.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POConfirmedEvent");
        plannedEvent.setEventMatchKey("10");
        plannedEvent.setLocationAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:Location:shippingPoint:4712");
        plannedEvent.setPlannedTechTsLatest(Instant.parse("2019-05-22T12:00:00.213Z"));
        plannedEvent.setPlannedBusinessTimestamp(Instant.parse("2019-05-15T12:00:00.213Z"));
        plannedEvent.setPlannedBizTsEarliest(Instant.parse("2019-05-09T12:00:00.213Z"));
        plannedEvent.setPlannedBizTsLatest(Instant.parse("2019-05-22T12:00:00.213Z"));
        plannedEvent.setEventStatus(EventStatus.PLANNED.name());
        plannedEvent.setOverdueDetectionCounter(0);
        plannedEvent.setNextOverdueDetection(plannedEvent.getPlannedTechTsLatest());
        plannedEvent.setIsFinalPlannedEvent(Boolean.FALSE);
        UUID pedId = UUID.randomUUID();
        plannedEvent.setLastProcessEventDirectoryId(pedId);
        pes.add(plannedEvent);
        tp.setPlannedEvents(pes);
        List<QualifiedTrackingId> trackingIds = new ArrayList<>();
        QualifiedTrackingId trackingId = QualifiedTrackingId.build(tpId, tpId, null, null);
        trackingId.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.QualifiedTrackingId"));
        trackingIds.add(trackingId);
        tp.setTrackingIds(trackingIds);
        List<ProcessEventDirectory> peds = new ArrayList<>();
        ProcessEventDirectory ped = ProcessEventDirectory.build(GTTUtils.UUIDUtils.generateTimeBasedUUID(),
                tpId, null, GTTUtils.UUIDUtils.generateTimeBasedUUID(), CorrelationType.UNPLANNED_PROCESS_CREATION_UPDATE.name());
        peds.add(ped);
        UUID reportedEventId = UUID.randomUUID();
        ProcessEventDirectory ped2 = ProcessEventDirectory.build(pedId, tpId, plannedEvent.getId(), reportedEventId, CorrelationType.UNPLANNED_ONTIME.name());
        peds.add(ped2);
        tp.setPEDs(peds);
        given(processManagement.getWithOnlyValidDPPStatus(Mockito.any(UUIDValue.class))).willReturn(tp);
        Instant now = Instant.now();
        Event reportedEvent = new Event();
        reportedEvent.setActualBusinessTimestamp(now);
        given(eventManagement.getSingleEventById(Mockito.any(UUIDValue.class))).willReturn(reportedEvent);

        Event eventMessage = new Event();
        eventMessage.setId(UUID.randomUUID());
        eventMessage.setAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:ProcurementOrderItem:10");
        eventMessage.setModelNamespace("com.sap.gtt.app.mim");
        eventMessage.setEventType("com.sap.gtt.core.CoreModel.GTTDelayedEvent");
        eventMessage.setEventReasonText("Delayed Event");
        eventMessage.setActualBusinessTimestamp(now.plusSeconds(60));
        eventMessage.setValue(Constant.REF_PLANNED_EVENT_TYPE, plannedEvent.getEventType());
        //eventMessage.setEventMatchKey(plannedEvent.getEventMatchKey());
        eventMessage.setValue(REF_PLANNED_EVENT_MATCH_KEY, plannedEvent.getEventMatchKey());
        eventMessage.setValue(Constant.REF_PLANNED_EVENT_LOCATION_ALEKEY, "xri://sap.com/sapdoc:666666:Q8JCLNT774:Location:shippingPoint:4712");
        eventMessage.setMetadata(getMetadata(eventMessage.getEventType()));
        List<Event> messages = new ArrayList<>();
        messages.add(eventMessage);
        MetadataEntityEvent eventConfig = new MetadataEntityEvent();
        eventConfig.setMatchLocation(true);
        eventConfig.setMaxOverdueDetection(3);
        eventConfig.setPeriodicOverdueDetection(Duration.parse("PT24H"));
        given(metadataManagement.getEntityEvent(Mockito.anyString(), Mockito.anyString())).willReturn(eventConfig);

        service.processEvents(messages, "requestId", "writeServiceId");
        ArgumentCaptor<List<Event>> argumentCaptorEvent = ArgumentCaptor.forClass(List.class);
        verify(eventManagement, times(1)).post(argumentCaptorEvent.capture());
        List<Event> capturedEvent = argumentCaptorEvent.getValue();
        assertThat(capturedEvent).isNotNull();

        ArgumentCaptor<TrackedProcess> argumentCaptorTrackedProcess = ArgumentCaptor.forClass(TrackedProcess.class);
        ArgumentCaptor<PlannedEvent> argumentCaptorPE = ArgumentCaptor.forClass(PlannedEvent.class);
        ArgumentCaptor<ProcessEventDirectory> argumentCaptorPED = ArgumentCaptor.forClass(ProcessEventDirectory.class);
        verify(processManagement, times(1)).update(argumentCaptorTrackedProcess.capture(), argumentCaptorPED.capture(), argumentCaptorPE.capture());
        TrackedProcess rstTP = argumentCaptorTrackedProcess.getValue();
        assertThat(rstTP.getTrackingIds().size()).isEqualTo(1);
        assertThat(rstTP.getProcessStatus()).isEqualTo(ProcessStatus.DELAYED.name());
        PlannedEvent capturedPE = argumentCaptorPE.<List<String>>getValue();
        assertThat(capturedPE.getId()).isEqualTo(plannedEvent.getId());
        assertThat(capturedPE.getEventStatus()).isEqualTo(EventStatus.DELAYED.name());
        assertThat(capturedPE.getLastProcessEventDirectoryId()).isNotEqualTo(pedId);
        ProcessEventDirectory capturedPED = argumentCaptorPED.<List<String>>getValue();
        assertThat(capturedPED.getCorrelationType()).isEqualTo(CorrelationType.UNPLANNED_DELAYED.name());
    }

    @Test
    public void testProcessInheritGTTDelayedEvent() {
        TrackedProcess tp = new TrackedProcess();
        String trackedProcessType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        tp.setMetadata(getMetadata(trackedProcessType));
        tp.setTrackedProcessType(trackedProcessType);
        tp.setAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:ProcurementOrderItem:1");
        UUID tpId = GTTUtils.UUIDUtils.generateTimeBasedUUID();
        tp.setId(tpId);
        tp.setProcessStatus(ProcessStatus.AS_PLANNED.name());
        List<PlannedEvent> pes = new ArrayList<>();
        PlannedEvent plannedEvent = new PlannedEvent();
        plannedEvent.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.PlannedEvent"));
        plannedEvent.setId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        plannedEvent.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POConfirmedEvent");
        plannedEvent.setEventMatchKey("10");
        plannedEvent.setValue("mode", "a");
        plannedEvent.setLocationAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:Location:shippingPoint:4712");
        plannedEvent.setPlannedTechTsLatest(Instant.parse("2019-05-22T12:00:00.213Z"));
        plannedEvent.setPlannedBusinessTimestamp(Instant.parse("2019-05-15T12:00:00.213Z"));
        plannedEvent.setPlannedBizTsEarliest(Instant.parse("2019-05-09T12:00:00.213Z"));
        plannedEvent.setPlannedBizTsLatest(Instant.parse("2019-05-22T12:00:00.213Z"));
        plannedEvent.setEventStatus(EventStatus.PLANNED.name());
        plannedEvent.setOverdueDetectionCounter(0);
        plannedEvent.setNextOverdueDetection(plannedEvent.getPlannedTechTsLatest());
        plannedEvent.setIsFinalPlannedEvent(Boolean.FALSE);
        plannedEvent.setLastProcessEventDirectoryId(null);
        plannedEvent.setEventStatus(EventStatus.PLANNED.name());
        pes.add(plannedEvent);
        tp.setPlannedEvents(pes);
        List<QualifiedTrackingId> trackingIds = new ArrayList<>();
        QualifiedTrackingId trackingId = QualifiedTrackingId.build(tpId, tpId, null, null);
        trackingId.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.QualifiedTrackingId"));
        trackingIds.add(trackingId);
        tp.setTrackingIds(trackingIds);
        List<ProcessEventDirectory> peds = new ArrayList<>();
        ProcessEventDirectory ped = ProcessEventDirectory.build(GTTUtils.UUIDUtils.generateTimeBasedUUID(),
                tpId, null, GTTUtils.UUIDUtils.generateTimeBasedUUID(), CorrelationType.UNPLANNED_PROCESS_CREATION_UPDATE.name());
        peds.add(ped);
        tp.setPEDs(peds);
        given(processManagement.getWithOnlyValidDPPStatus(Mockito.any(UUIDValue.class))).willReturn(tp);

        Event eventMessage = new Event();
        eventMessage.setId(UUID.randomUUID());
        eventMessage.setAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:ProcurementOrderItem:10");
        eventMessage.setModelNamespace("com.sap.gtt.app.mim");
        eventMessage.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.PODelayedEvent");
        eventMessage.setEventReasonText("Delayed Event");
        eventMessage.setActualBusinessTimestamp(Instant.now());
        eventMessage.setValue(Constant.REF_PLANNED_EVENT_TYPE, plannedEvent.getEventType());
        eventMessage.setValue(REF_PLANNED_EVENT_MATCH_KEY, plannedEvent.getEventMatchKey());
        eventMessage.setValue(Constant.REF_PLANNED_EVENT_LOCATION_ALEKEY, "xri://sap.com/sapdoc:666666:Q8JCLNT774:Location:shippingPoint:4712");
        eventMessage.setValue("mode", "a");
        eventMessage.setMetadata(getMetadata(eventMessage.getEventType()));

        List<Event> messages = new ArrayList<>();
        messages.add(eventMessage);
        MetadataEntityEvent eventConfig = new MetadataEntityEvent();
        eventConfig.setMatchLocation(true);
        eventConfig.setMaxOverdueDetection(3);
        eventConfig.setPeriodicOverdueDetection(Duration.parse("PT24H"));
        MatchExtensionField matchExtensionField = new MatchExtensionField();
        matchExtensionField.setOperator(Operator.EQUAL.getValue());
        matchExtensionField.setSourceObject("PlannedEvent");
        matchExtensionField.setSourceField("mode");
        matchExtensionField.setTargetObject("POConfirmedEvent");
        matchExtensionField.setTargetField("mode1");
        eventConfig.addMatchExtensionField(matchExtensionField);
        given(metadataManagement.getEntityEvent(Mockito.anyString(), Mockito.anyString())).willReturn(eventConfig);

        Pair<String, String> pair = Pair.of("mode", "mode1");
        given(metadataManagement.findMatchedExtensionFieldPairs(Mockito.anyString())).willReturn(Arrays.asList(pair));

        Map<UUIDValue, String> observedTrackingIdMap = new HashMap<>();
        observedTrackingIdMap.put(UUIDValue.valueOf(tpId), tp.getAltKey());
        given(processManagement.getCorrelatedProcessMap(Mockito.any(UUIDValue.class), Mockito.any(TimestampValue.class)
                , Mockito.anyInt()))
                .willReturn(observedTrackingIdMap);

        service.processEvents(messages, "requestId", "writeServiceId");
        ArgumentCaptor<List<Event>> argumentCaptorEvent = ArgumentCaptor.forClass(List.class);
        verify(eventManagement, times(1)).post(argumentCaptorEvent.capture());
        List<Event> capturedEvent = argumentCaptorEvent.getValue();
        assertThat(capturedEvent).isNotNull();

        ArgumentCaptor<TrackedProcess> argumentCaptorTrackedProcess = ArgumentCaptor.forClass(TrackedProcess.class);
        ArgumentCaptor<PlannedEvent> argumentCaptorPE = ArgumentCaptor.forClass(PlannedEvent.class);
        ArgumentCaptor<ProcessEventDirectory> argumentCaptorPED = ArgumentCaptor.forClass(ProcessEventDirectory.class);
        verify(processManagement, times(1)).update(argumentCaptorTrackedProcess.capture(), argumentCaptorPED.capture(), argumentCaptorPE.capture());
        TrackedProcess rstTP = argumentCaptorTrackedProcess.getValue();
        assertThat(rstTP.getTrackingIds().size()).isEqualTo(1);
        assertThat(rstTP.getProcessStatus()).isEqualTo(ProcessStatus.DELAYED.name());
        PlannedEvent capturedPE = argumentCaptorPE.<List<String>>getValue();
        assertThat(capturedPE.getId()).isEqualTo(plannedEvent.getId());
        assertThat(capturedPE.getEventStatus()).isEqualTo(EventStatus.DELAYED.name());
        ProcessEventDirectory capturedPED = argumentCaptorPED.<List<String>>getValue();
        assertThat(capturedPED.getCorrelationType()).isEqualTo(CorrelationType.UNPLANNED_DELAYED.name());
    }

    @Test
    public void testProcessGTTOnTimeEventWhenLocationMatchedFalse() {
        TrackedProcess tp = new TrackedProcess();
        String trackedProcessType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        tp.setMetadata(getMetadata(trackedProcessType));
        tp.setTrackedProcessType(trackedProcessType);
        UUID tpId = GTTUtils.UUIDUtils.generateTimeBasedUUID();
        tp.setId(tpId);
        tp.setProcessStatus(ProcessStatus.AS_PLANNED.name());
        List<PlannedEvent> pes = new ArrayList<>();
        PlannedEvent plannedEvent = new PlannedEvent();
        plannedEvent.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.PlannedEvent"));
        plannedEvent.setId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        plannedEvent.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POConfirmedEvent");
        plannedEvent.setEventMatchKey("10");
        plannedEvent.setPlannedTechTsLatest(Instant.parse("2019-05-22T12:00:00.213Z"));
        plannedEvent.setPlannedBusinessTimestamp(Instant.parse("2019-05-15T12:00:00.213Z"));
        plannedEvent.setPlannedBizTsEarliest(Instant.parse("2019-05-09T12:00:00.213Z"));
        plannedEvent.setPlannedBizTsLatest(Instant.parse("2019-05-22T12:00:00.213Z"));
        plannedEvent.setEventStatus(EventStatus.PLANNED.name());
        plannedEvent.setOverdueDetectionCounter(0);
        plannedEvent.setNextOverdueDetection(plannedEvent.getPlannedTechTsLatest());
        plannedEvent.setIsFinalPlannedEvent(Boolean.FALSE);
        plannedEvent.setLastProcessEventDirectoryId(null);
        plannedEvent.setEventStatus(EventStatus.PLANNED.name());
        pes.add(plannedEvent);
        tp.setPlannedEvents(pes);
        List<QualifiedTrackingId> trackingIds = new ArrayList<>();
        QualifiedTrackingId trackingId = QualifiedTrackingId.build(tpId, tpId, null, null);
        trackingId.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.QualifiedTrackingId"));
        trackingIds.add(trackingId);
        tp.setTrackingIds(trackingIds);
        List<ProcessEventDirectory> peds = new ArrayList<>();
        ProcessEventDirectory ped = ProcessEventDirectory.build(GTTUtils.UUIDUtils.generateTimeBasedUUID(),
                tpId, null, GTTUtils.UUIDUtils.generateTimeBasedUUID(), CorrelationType.UNPLANNED_PROCESS_CREATION_UPDATE.name());
        peds.add(ped);
        tp.setPEDs(peds);
        given(processManagement.getWithOnlyValidDPPStatus(Mockito.any(UUIDValue.class))).willReturn(tp);

        Event eventMessage = new Event();
        eventMessage.setId(UUID.randomUUID());
        eventMessage.setAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:ProcurementOrderItem:10");
        eventMessage.setModelNamespace("com.sap.gtt.app.mim");
        eventMessage.setEventType("com.sap.gtt.core.CoreModel.GTTOnTimeEvent");
        eventMessage.setEventReasonText("OnTime Event");
        eventMessage.setActualBusinessTimestamp(Instant.now());
        eventMessage.setValue(REF_PLANNED_EVENT_TYPE, plannedEvent.getEventType());
        eventMessage.setValue(REF_PLANNED_EVENT_MATCH_KEY, plannedEvent.getEventMatchKey());
        eventMessage.setMetadata(getMetadata(eventMessage.getEventType()));
        List<Event> messages = new ArrayList<>();
        messages.add(eventMessage);
        MetadataEntityEvent eventConfig = new MetadataEntityEvent();
        eventConfig.setMatchLocation(false);
        eventConfig.setMaxOverdueDetection(3);
        eventConfig.setPeriodicOverdueDetection(Duration.parse("PT24H"));
        given(metadataManagement.getEntityEvent(Mockito.anyString(), Mockito.anyString())).willReturn(eventConfig);
        service.processEvents(messages, "requestId", "writeServiceId");

        ArgumentCaptor<List<Event>> argumentCaptorEvent = ArgumentCaptor.forClass(List.class);
        verify(eventManagement, times(1)).post(argumentCaptorEvent.capture());
        List<Event> capturedEvent = argumentCaptorEvent.getValue();
        assertThat(capturedEvent).isNotNull();

        ArgumentCaptor<TrackedProcess> argumentCaptorTrackedProcess = ArgumentCaptor.forClass(TrackedProcess.class);
        ArgumentCaptor<PlannedEvent> argumentCaptorPE = ArgumentCaptor.forClass(PlannedEvent.class);
        ArgumentCaptor<ProcessEventDirectory> argumentCaptorPED = ArgumentCaptor.forClass(ProcessEventDirectory.class);
        verify(processManagement, times(1)).update(argumentCaptorTrackedProcess.capture(), argumentCaptorPED.capture(), argumentCaptorPE.capture());
        TrackedProcess rstTP = argumentCaptorTrackedProcess.getValue();
        assertThat(rstTP.getTrackingIds().size()).isEqualTo(1);
        assertThat(rstTP.getProcessStatus()).isEqualTo(ProcessStatus.AS_PLANNED.name());
        PlannedEvent capturedPE = argumentCaptorPE.<List<String>>getValue();
        assertThat(capturedPE.getId()).isEqualTo(plannedEvent.getId());
        assertThat(capturedPE.getEventStatus()).isEqualTo(EventStatus.PLANNED.name());
        ProcessEventDirectory capturedPED = argumentCaptorPED.<List<String>>getValue();
        assertThat(capturedPED.getCorrelationType()).isEqualTo(CorrelationType.UNPLANNED_ONTIME.name());
    }

    @Test
    public void testProcessGTTOnTimeEventWhenNoMatch() {
        TrackedProcess tp = new TrackedProcess();
        String trackedProcessType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        tp.setMetadata(getMetadata(trackedProcessType));
        tp.setTrackedProcessType(trackedProcessType);
        UUID tpId = GTTUtils.UUIDUtils.generateTimeBasedUUID();
        tp.setId(tpId);
        tp.setProcessStatus(ProcessStatus.AS_PLANNED.name());
        List<PlannedEvent> pes = new ArrayList<>();
        PlannedEvent plannedEvent = new PlannedEvent();
        plannedEvent.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.PlannedEvent"));
        plannedEvent.setId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        plannedEvent.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POConfirmedEvent");
        plannedEvent.setEventMatchKey("10");
        plannedEvent.setPlannedTechTsLatest(Instant.parse("2019-05-22T12:00:00.213Z"));
        plannedEvent.setPlannedBusinessTimestamp(Instant.parse("2019-05-15T12:00:00.213Z"));
        plannedEvent.setPlannedBizTsEarliest(Instant.parse("2019-05-09T12:00:00.213Z"));
        plannedEvent.setPlannedBizTsLatest(Instant.parse("2019-05-22T12:00:00.213Z"));
        plannedEvent.setEventStatus(EventStatus.PLANNED.name());
        plannedEvent.setOverdueDetectionCounter(0);
        plannedEvent.setNextOverdueDetection(plannedEvent.getPlannedTechTsLatest());
        plannedEvent.setIsFinalPlannedEvent(Boolean.FALSE);
        plannedEvent.setLastProcessEventDirectoryId(null);
        plannedEvent.setEventStatus(EventStatus.PLANNED.name());
        pes.add(plannedEvent);
        tp.setPlannedEvents(pes);
        List<QualifiedTrackingId> trackingIds = new ArrayList<>();
        QualifiedTrackingId trackingId = QualifiedTrackingId.build(tpId, tpId, null, null);
        trackingId.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.QualifiedTrackingId"));
        trackingIds.add(trackingId);
        tp.setTrackingIds(trackingIds);
        List<ProcessEventDirectory> peds = new ArrayList<>();
        ProcessEventDirectory ped = ProcessEventDirectory.build(GTTUtils.UUIDUtils.generateTimeBasedUUID(),
                tpId, null, GTTUtils.UUIDUtils.generateTimeBasedUUID(), CorrelationType.UNPLANNED_PROCESS_CREATION_UPDATE.name());
        peds.add(ped);
        tp.setPEDs(peds);
        given(processManagement.getWithOnlyValidDPPStatus(Mockito.any(UUIDValue.class))).willReturn(tp);

        Event eventMessage = new Event();
        eventMessage.setId(UUID.randomUUID());
        eventMessage.setAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:ProcurementOrderItem:10");
        eventMessage.setModelNamespace("com.sap.gtt.app.mim");
        eventMessage.setEventType("com.sap.gtt.core.CoreModel.GTTOnTimeEvent");
        eventMessage.setEventReasonText("OnTime Event");
        eventMessage.setActualBusinessTimestamp(Instant.now());
        eventMessage.setValue(REF_PLANNED_EVENT_TYPE, plannedEvent.getEventType());
        eventMessage.setMetadata(getMetadata(eventMessage.getEventType()));
        List<Event> messages = new ArrayList<>();
        messages.add(eventMessage);
        MetadataEntityEvent eventConfig = new MetadataEntityEvent();
        eventConfig.setMatchLocation(false);
        eventConfig.setMaxOverdueDetection(3);
        eventConfig.setPeriodicOverdueDetection(Duration.parse("PT24H"));
        given(metadataManagement.getEntityEvent(Mockito.anyString(), Mockito.anyString())).willReturn(eventConfig);
        given(metadataManagement.checkIfEventIsUnplanned(Mockito.anyString(), Mockito.anyString())).willReturn(true);
        service.processEvents(messages, "requestId", "writeServiceId");

        ArgumentCaptor<List<Event>> argumentCaptorEvent = ArgumentCaptor.forClass(List.class);
        verify(eventManagement, times(1)).post(argumentCaptorEvent.capture());
        List<Event> capturedEvent = argumentCaptorEvent.getValue();
        assertThat(capturedEvent).isNotNull();

        ArgumentCaptor<TrackedProcess> argumentCaptorTrackedProcess = ArgumentCaptor.forClass(TrackedProcess.class);
        ArgumentCaptor<PlannedEvent> argumentCaptorPE = ArgumentCaptor.forClass(PlannedEvent.class);
        ArgumentCaptor<ProcessEventDirectory> argumentCaptorPED = ArgumentCaptor.forClass(ProcessEventDirectory.class);
        verify(processManagement, times(1)).update(argumentCaptorTrackedProcess.capture(), argumentCaptorPED.capture(), argumentCaptorPE.capture());
        TrackedProcess rstTP = argumentCaptorTrackedProcess.getValue();
        assertThat(rstTP.getTrackingIds().size()).isEqualTo(1);
        assertThat(rstTP.getProcessStatus()).isEqualTo(ProcessStatus.AS_PLANNED.name());
        PlannedEvent capturedPE = argumentCaptorPE.<List<String>>getValue();
        assertThat(capturedPE).isNull();
        ProcessEventDirectory capturedPED = argumentCaptorPED.<List<String>>getValue();
        assertThat(capturedPED.getCorrelationType()).isEqualTo(CorrelationType.UNPLANNED_ONTIME.name());
    }

    @Test
    public void testProcessGTTOnTimeEventWhenPlannedEventIsReported() {
        TrackedProcess tp = new TrackedProcess();
        String trackedProcessType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        tp.setMetadata(getMetadata(trackedProcessType));
        tp.setTrackedProcessType(trackedProcessType);
        UUID tpId = GTTUtils.UUIDUtils.generateTimeBasedUUID();
        tp.setId(tpId);
        tp.setProcessStatus(ProcessStatus.AS_PLANNED.name());
        List<PlannedEvent> pes = new ArrayList<>();
        PlannedEvent plannedEvent = new PlannedEvent();
        plannedEvent.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.PlannedEvent"));
        plannedEvent.setId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        plannedEvent.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POConfirmedEvent");
        plannedEvent.setEventMatchKey("10");
        plannedEvent.setLocationAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:Location:shippingPoint:4712");
        plannedEvent.setPlannedTechTsLatest(Instant.parse("2019-05-22T12:00:00.213Z"));
        plannedEvent.setPlannedBusinessTimestamp(Instant.parse("2019-05-15T12:00:00.213Z"));
        plannedEvent.setPlannedBizTsEarliest(Instant.parse("2019-05-09T12:00:00.213Z"));
        plannedEvent.setPlannedBizTsLatest(Instant.parse("2019-05-22T12:00:00.213Z"));
        plannedEvent.setEventStatus(EventStatus.REPORTED.name());
        plannedEvent.setOverdueDetectionCounter(0);
        plannedEvent.setNextOverdueDetection(plannedEvent.getPlannedTechTsLatest());
        plannedEvent.setIsFinalPlannedEvent(Boolean.FALSE);
        UUID pedId = UUID.randomUUID();
        plannedEvent.setLastProcessEventDirectoryId(pedId);
        pes.add(plannedEvent);
        tp.setPlannedEvents(pes);
        List<QualifiedTrackingId> trackingIds = new ArrayList<>();
        QualifiedTrackingId trackingId = QualifiedTrackingId.build(tpId, tpId, null, null);
        trackingId.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.QualifiedTrackingId"));
        trackingIds.add(trackingId);
        tp.setTrackingIds(trackingIds);
        List<ProcessEventDirectory> peds = new ArrayList<>();
        ProcessEventDirectory ped = ProcessEventDirectory.build(GTTUtils.UUIDUtils.generateTimeBasedUUID(),
                tpId, null, GTTUtils.UUIDUtils.generateTimeBasedUUID(), CorrelationType.UNPLANNED_PROCESS_CREATION_UPDATE.name());
        peds.add(ped);
        UUID reportedEventId = UUID.randomUUID();
        ProcessEventDirectory ped2 = ProcessEventDirectory.build(pedId, tpId, plannedEvent.getId(), reportedEventId, CorrelationType.REPORTED.name());
        peds.add(ped2);
        tp.setPEDs(peds);
        given(processManagement.getWithOnlyValidDPPStatus(Mockito.any(UUIDValue.class))).willReturn(tp);
        Instant now = Instant.now();
        Event reportedEvent = new Event();
        reportedEvent.setActualBusinessTimestamp(now.minusSeconds(60));
        given(eventManagement.getSingleEventById(Mockito.any(UUIDValue.class))).willReturn(reportedEvent);

        Event eventMessage = new Event();
        eventMessage.setId(UUID.randomUUID());
        eventMessage.setAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:ProcurementOrderItem:10");
        eventMessage.setModelNamespace("com.sap.gtt.app.mim");
        eventMessage.setEventType("com.sap.gtt.core.CoreModel.GTTOnTimeEvent");
        eventMessage.setEventReasonText("OnTime Event");
        eventMessage.setActualBusinessTimestamp(now);
        eventMessage.setValue(Constant.REF_PLANNED_EVENT_TYPE, plannedEvent.getEventType());
        eventMessage.setValue(REF_PLANNED_EVENT_MATCH_KEY, plannedEvent.getEventMatchKey());
        eventMessage.setValue(Constant.REF_PLANNED_EVENT_LOCATION_ALEKEY, "xri://sap.com/sapdoc:666666:Q8JCLNT774:Location:shippingPoint:4712");
        eventMessage.setMetadata(getMetadata(eventMessage.getEventType()));
        List<Event> messages = new ArrayList<>();
        messages.add(eventMessage);
        MetadataEntityEvent eventConfig = new MetadataEntityEvent();
        eventConfig.setMatchLocation(true);
        eventConfig.setMaxOverdueDetection(3);
        eventConfig.setPeriodicOverdueDetection(Duration.parse("PT24H"));
        given(metadataManagement.getEntityEvent(Mockito.anyString(), Mockito.anyString())).willReturn(eventConfig);

        service.processEvents(messages, "requestId", "writeServiceId");
        ArgumentCaptor<List<Event>> argumentCaptorEvent = ArgumentCaptor.forClass(List.class);
        verify(eventManagement, times(1)).post(argumentCaptorEvent.capture());
        List<Event> capturedEvent = argumentCaptorEvent.getValue();
        assertThat(capturedEvent).isNotNull();

        verify(processManagement, times(0)).update(Mockito.any(), Mockito.any(), Mockito.any());
    }

    @Test
    public void testProcessGTTOnTimeEventWhenPlannedEventIsReportedButOnTimeEventIsEalier() {
        TrackedProcess tp = new TrackedProcess();
        String trackedProcessType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        tp.setMetadata(getMetadata(trackedProcessType));
        tp.setTrackedProcessType(trackedProcessType);
        UUID tpId = GTTUtils.UUIDUtils.generateTimeBasedUUID();
        tp.setId(tpId);
        tp.setProcessStatus(ProcessStatus.EARLY.name());
        List<PlannedEvent> pes = new ArrayList<>();
        PlannedEvent plannedEvent = new PlannedEvent();
        plannedEvent.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.PlannedEvent"));
        plannedEvent.setId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        plannedEvent.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POConfirmedEvent");
        plannedEvent.setEventMatchKey("10");
        plannedEvent.setLocationAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:Location:shippingPoint:4712");
        plannedEvent.setPlannedTechTsLatest(Instant.parse("2019-05-22T12:00:00.213Z"));
        plannedEvent.setPlannedBusinessTimestamp(Instant.parse("2019-05-15T12:00:00.213Z"));
        plannedEvent.setPlannedBizTsEarliest(Instant.parse("2019-05-09T12:00:00.213Z"));
        plannedEvent.setPlannedBizTsLatest(Instant.parse("2019-05-22T12:00:00.213Z"));
        plannedEvent.setEventStatus(EventStatus.EARLY_REPORTED.name());
        plannedEvent.setOverdueDetectionCounter(0);
        plannedEvent.setNextOverdueDetection(plannedEvent.getPlannedTechTsLatest());
        plannedEvent.setIsFinalPlannedEvent(Boolean.FALSE);
        UUID pedId = UUID.randomUUID();
        plannedEvent.setLastProcessEventDirectoryId(pedId);
        pes.add(plannedEvent);
        tp.setPlannedEvents(pes);
        List<QualifiedTrackingId> trackingIds = new ArrayList<>();
        QualifiedTrackingId trackingId = QualifiedTrackingId.build(tpId, tpId, null, null);
        trackingId.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.QualifiedTrackingId"));
        trackingIds.add(trackingId);
        tp.setTrackingIds(trackingIds);
        List<ProcessEventDirectory> peds = new ArrayList<>();
        ProcessEventDirectory ped = ProcessEventDirectory.build(GTTUtils.UUIDUtils.generateTimeBasedUUID(),
                tpId, null, GTTUtils.UUIDUtils.generateTimeBasedUUID(), CorrelationType.UNPLANNED_PROCESS_CREATION_UPDATE.name());
        peds.add(ped);
        UUID reportedEventId = UUID.randomUUID();
        ProcessEventDirectory ped2 = ProcessEventDirectory.build(pedId, tpId, plannedEvent.getId(), reportedEventId, CorrelationType.REPORTED.name());
        peds.add(ped2);
        tp.setPEDs(peds);
        given(processManagement.getWithOnlyValidDPPStatus(Mockito.any(UUIDValue.class))).willReturn(tp);
        Instant now = Instant.now();
        Event reportedEvent = new Event();
        reportedEvent.setActualBusinessTimestamp(now);
        reportedEvent.setPriority(0);
        given(eventManagement.getSingleEventById(Mockito.any(UUIDValue.class))).willReturn(reportedEvent);

        Event eventMessage = new Event();
        eventMessage.setId(UUID.randomUUID());
        eventMessage.setAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:ProcurementOrderItem:10");
        eventMessage.setModelNamespace("com.sap.gtt.app.mim");
        eventMessage.setEventType("com.sap.gtt.core.CoreModel.GTTOnTimeEvent");
        eventMessage.setEventReasonText("OnTime Event");
        eventMessage.setActualBusinessTimestamp(now.minusSeconds(60));
        eventMessage.setValue(Constant.REF_PLANNED_EVENT_TYPE, plannedEvent.getEventType());
        //eventMessage.setEventMatchKey(plannedEvent.getEventMatchKey());
        eventMessage.setValue(REF_PLANNED_EVENT_MATCH_KEY, plannedEvent.getEventMatchKey());
        eventMessage.setValue(Constant.REF_PLANNED_EVENT_LOCATION_ALEKEY, "xri://sap.com/sapdoc:666666:Q8JCLNT774:Location:shippingPoint:4712");
        eventMessage.setMetadata(getMetadata(eventMessage.getEventType()));
        List<Event> messages = new ArrayList<>();
        messages.add(eventMessage);
        MetadataEntityEvent eventConfig = new MetadataEntityEvent();
        eventConfig.setMatchLocation(true);
        eventConfig.setMaxOverdueDetection(3);
        eventConfig.setPeriodicOverdueDetection(Duration.parse("PT24H"));
        given(metadataManagement.getEntityEvent(Mockito.anyString(), Mockito.anyString())).willReturn(eventConfig);

        service.processEvents(messages, "requestId", "writeServiceId");
        ArgumentCaptor<List<Event>> argumentCaptorEvent = ArgumentCaptor.forClass(List.class);
        verify(eventManagement, times(1)).post(argumentCaptorEvent.capture());
        List<Event> capturedEvent = argumentCaptorEvent.getValue();
        assertThat(capturedEvent).isNotNull();

        ArgumentCaptor<TrackedProcess> argumentCaptorTrackedProcess = ArgumentCaptor.forClass(TrackedProcess.class);
        ArgumentCaptor<PlannedEvent> argumentCaptorPE = ArgumentCaptor.forClass(PlannedEvent.class);
        ArgumentCaptor<ProcessEventDirectory> argumentCaptorPED = ArgumentCaptor.forClass(ProcessEventDirectory.class);
        verify(processManagement, times(1)).update(argumentCaptorTrackedProcess.capture(), argumentCaptorPED.capture(), argumentCaptorPE.capture());
        TrackedProcess rstTP = argumentCaptorTrackedProcess.getValue();
        assertThat(rstTP.getTrackingIds().size()).isEqualTo(1);
        assertThat(rstTP.getProcessStatus()).isEqualTo(ProcessStatus.EARLY.name());
        PlannedEvent capturedPE = argumentCaptorPE.<List<String>>getValue();
        assertThat(capturedPE.getId()).isEqualTo(plannedEvent.getId());
        assertThat(capturedPE.getEventStatus()).isEqualTo(EventStatus.EARLY_REPORTED.name());
        ProcessEventDirectory capturedPED = argumentCaptorPED.<List<String>>getValue();
        assertThat(capturedPED.getCorrelationType()).isEqualTo(CorrelationType.UNPLANNED_ONTIME.name());
    }

    @Test
    public void testProcessGTTOnTimeEventWhenPlannedEventIsPlannedWithOnTimeEvent() {
        TrackedProcess tp = new TrackedProcess();
        String trackedProcessType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        tp.setMetadata(getMetadata(trackedProcessType));
        tp.setTrackedProcessType(trackedProcessType);
        UUID tpId = GTTUtils.UUIDUtils.generateTimeBasedUUID();
        tp.setId(tpId);
        tp.setProcessStatus(ProcessStatus.DELAYED.name());
        List<PlannedEvent> pes = new ArrayList<>();
        PlannedEvent plannedEvent = new PlannedEvent();
        plannedEvent.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.PlannedEvent"));
        plannedEvent.setId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        plannedEvent.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POConfirmedEvent");
        plannedEvent.setEventMatchKey("10");
        plannedEvent.setLocationAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:Location:shippingPoint:4712");
        plannedEvent.setPlannedTechTsLatest(Instant.parse("2019-05-22T12:00:00.213Z"));
        plannedEvent.setPlannedBusinessTimestamp(Instant.parse("2019-05-15T12:00:00.213Z"));
        plannedEvent.setPlannedBizTsEarliest(Instant.parse("2019-05-09T12:00:00.213Z"));
        plannedEvent.setPlannedBizTsLatest(Instant.parse("2019-05-22T12:00:00.213Z"));
        plannedEvent.setEventStatus(EventStatus.PLANNED.name());
        plannedEvent.setOverdueDetectionCounter(0);
        plannedEvent.setNextOverdueDetection(plannedEvent.getPlannedTechTsLatest());
        plannedEvent.setIsFinalPlannedEvent(Boolean.FALSE);
        UUID pedId = UUID.randomUUID();
        plannedEvent.setLastProcessEventDirectoryId(pedId);
        pes.add(plannedEvent);
        tp.setPlannedEvents(pes);
        List<QualifiedTrackingId> trackingIds = new ArrayList<>();
        QualifiedTrackingId trackingId = QualifiedTrackingId.build(tpId, tpId, null, null);
        trackingId.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.QualifiedTrackingId"));
        trackingIds.add(trackingId);
        tp.setTrackingIds(trackingIds);
        List<ProcessEventDirectory> peds = new ArrayList<>();
        ProcessEventDirectory ped = ProcessEventDirectory.build(GTTUtils.UUIDUtils.generateTimeBasedUUID(),
                tpId, null, GTTUtils.UUIDUtils.generateTimeBasedUUID(), CorrelationType.UNPLANNED_PROCESS_CREATION_UPDATE.name());
        peds.add(ped);
        UUID reportedEventId = UUID.randomUUID();
        ProcessEventDirectory ped2 = ProcessEventDirectory.build(pedId, tpId, plannedEvent.getId(), reportedEventId, CorrelationType.UNPLANNED_ONTIME.name());
        peds.add(ped2);
        tp.setPEDs(peds);
        given(processManagement.getWithOnlyValidDPPStatus(Mockito.any(UUIDValue.class))).willReturn(tp);
        Instant now = Instant.now();
        Event reportedEvent = new Event();
        reportedEvent.setActualBusinessTimestamp(now);
        given(eventManagement.getSingleEventById(Mockito.any(UUIDValue.class))).willReturn(reportedEvent);

        Event eventMessage = new Event();
        eventMessage.setId(UUID.randomUUID());
        eventMessage.setAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:ProcurementOrderItem:10");
        eventMessage.setModelNamespace("com.sap.gtt.app.mim");
        eventMessage.setEventType("com.sap.gtt.core.CoreModel.GTTOnTimeEvent");
        eventMessage.setEventReasonText("OnTime Event");
        eventMessage.setActualBusinessTimestamp(now.minusSeconds(60));
        eventMessage.setValue(Constant.REF_PLANNED_EVENT_TYPE, plannedEvent.getEventType());
        eventMessage.setValue(REF_PLANNED_EVENT_MATCH_KEY, plannedEvent.getEventMatchKey());
        eventMessage.setValue(Constant.REF_PLANNED_EVENT_LOCATION_ALEKEY, "xri://sap.com/sapdoc:666666:Q8JCLNT774:Location:shippingPoint:4712");
        eventMessage.setMetadata(getMetadata(eventMessage.getEventType()));
        List<Event> messages = new ArrayList<>();
        messages.add(eventMessage);
        MetadataEntityEvent eventConfig = new MetadataEntityEvent();
        eventConfig.setMatchLocation(true);
        eventConfig.setMaxOverdueDetection(3);
        eventConfig.setPeriodicOverdueDetection(Duration.parse("PT24H"));
        given(metadataManagement.getEntityEvent(Mockito.anyString(), Mockito.anyString())).willReturn(eventConfig);

        service.processEvents(messages, "requestId", "writeServiceId");
        ArgumentCaptor<List<Event>> argumentCaptorEvent = ArgumentCaptor.forClass(List.class);
        verify(eventManagement, times(1)).post(argumentCaptorEvent.capture());
        List<Event> capturedEvent = argumentCaptorEvent.getValue();
        assertThat(capturedEvent).isNotNull();

        ArgumentCaptor<TrackedProcess> argumentCaptorTrackedProcess = ArgumentCaptor.forClass(TrackedProcess.class);
        ArgumentCaptor<PlannedEvent> argumentCaptorPE = ArgumentCaptor.forClass(PlannedEvent.class);
        ArgumentCaptor<ProcessEventDirectory> argumentCaptorPED = ArgumentCaptor.forClass(ProcessEventDirectory.class);
        verify(processManagement, times(1)).update(argumentCaptorTrackedProcess.capture(), argumentCaptorPED.capture(), argumentCaptorPE.capture());
        TrackedProcess rstTP = argumentCaptorTrackedProcess.getValue();
        assertThat(rstTP.getTrackingIds().size()).isEqualTo(1);
        assertThat(rstTP.getProcessStatus()).isEqualTo(ProcessStatus.AS_PLANNED.name());
        PlannedEvent capturedPE = argumentCaptorPE.<List<String>>getValue();
        assertThat(capturedPE.getId()).isEqualTo(plannedEvent.getId());
        assertThat(capturedPE.getLastProcessEventDirectoryId()).isEqualTo(pedId);
        assertThat(capturedPE.getEventStatus()).isEqualTo(EventStatus.PLANNED.name());
        ProcessEventDirectory capturedPED = argumentCaptorPED.<List<String>>getValue();
        assertThat(capturedPED.getCorrelationType()).isEqualTo(CorrelationType.UNPLANNED_ONTIME.name());
    }

    @Test
    public void testProcessGTTOnTimeEventWhenPlannedEventIsPlannedWithDelayedEventAndKeepStatus() {
        TrackedProcess tp = new TrackedProcess();
        String trackedProcessType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        tp.setMetadata(getMetadata(trackedProcessType));
        tp.setTrackedProcessType(trackedProcessType);
        UUID tpId = GTTUtils.UUIDUtils.generateTimeBasedUUID();
        tp.setId(tpId);
        tp.setProcessStatus(ProcessStatus.DELAYED.name());
        List<PlannedEvent> pes = new ArrayList<>();
        PlannedEvent plannedEvent = new PlannedEvent();
        plannedEvent.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.PlannedEvent"));
        plannedEvent.setId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        plannedEvent.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POConfirmedEvent");
        plannedEvent.setEventMatchKey("10");
        plannedEvent.setLocationAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:Location:shippingPoint:4712");
        plannedEvent.setPlannedTechTsLatest(Instant.parse("2019-05-22T12:00:00.213Z"));
        plannedEvent.setPlannedBusinessTimestamp(Instant.parse("2019-05-15T12:00:00.213Z"));
        plannedEvent.setPlannedBizTsEarliest(Instant.parse("2019-05-09T12:00:00.213Z"));
        plannedEvent.setPlannedBizTsLatest(Instant.parse("2019-05-22T12:00:00.213Z"));
        plannedEvent.setEventStatus(EventStatus.DELAYED.name());
        plannedEvent.setOverdueDetectionCounter(0);
        plannedEvent.setNextOverdueDetection(plannedEvent.getPlannedTechTsLatest());
        plannedEvent.setIsFinalPlannedEvent(Boolean.FALSE);
        UUID pedId = UUID.randomUUID();
        plannedEvent.setLastProcessEventDirectoryId(pedId);
        pes.add(plannedEvent);
        tp.setPlannedEvents(pes);
        List<QualifiedTrackingId> trackingIds = new ArrayList<>();
        QualifiedTrackingId trackingId = QualifiedTrackingId.build(tpId, tpId, null, null);
        trackingId.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.QualifiedTrackingId"));
        trackingIds.add(trackingId);
        tp.setTrackingIds(trackingIds);
        List<ProcessEventDirectory> peds = new ArrayList<>();
        ProcessEventDirectory ped = ProcessEventDirectory.build(GTTUtils.UUIDUtils.generateTimeBasedUUID(),
                tpId, null, GTTUtils.UUIDUtils.generateTimeBasedUUID(), CorrelationType.UNPLANNED_PROCESS_CREATION_UPDATE.name());
        peds.add(ped);
        UUID reportedEventId = UUID.randomUUID();
        ProcessEventDirectory ped2 = ProcessEventDirectory.build(pedId, tpId, plannedEvent.getId(), reportedEventId, CorrelationType.UNPLANNED_DELAYED.name());
        peds.add(ped2);
        tp.setPEDs(peds);
        given(processManagement.getWithOnlyValidDPPStatus(Mockito.any(UUIDValue.class))).willReturn(tp);
        Instant now = Instant.now();
        Event reportedEvent = new Event();
        reportedEvent.setActualBusinessTimestamp(now);
        given(eventManagement.getSingleEventById(Mockito.any(UUIDValue.class))).willReturn(reportedEvent);

        Event eventMessage = new Event();
        eventMessage.setId(UUID.randomUUID());
        eventMessage.setAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:ProcurementOrderItem:10");
        eventMessage.setModelNamespace("com.sap.gtt.app.mim");
        eventMessage.setEventType("com.sap.gtt.core.CoreModel.GTTOnTimeEvent");
        eventMessage.setEventReasonText("OnTime Event");
        eventMessage.setActualBusinessTimestamp(now.minusSeconds(60));
        eventMessage.setValue(Constant.REF_PLANNED_EVENT_TYPE, plannedEvent.getEventType());
        eventMessage.setValue(REF_PLANNED_EVENT_MATCH_KEY, plannedEvent.getEventMatchKey());
        eventMessage.setValue(Constant.REF_PLANNED_EVENT_LOCATION_ALEKEY, "xri://sap.com/sapdoc:666666:Q8JCLNT774:Location:shippingPoint:4712");
        eventMessage.setMetadata(getMetadata(eventMessage.getEventType()));
        List<Event> messages = new ArrayList<>();
        messages.add(eventMessage);
        MetadataEntityEvent eventConfig = new MetadataEntityEvent();
        eventConfig.setMatchLocation(true);
        eventConfig.setMaxOverdueDetection(3);
        eventConfig.setPeriodicOverdueDetection(Duration.parse("PT24H"));
        given(metadataManagement.getEntityEvent(Mockito.anyString(), Mockito.anyString())).willReturn(eventConfig);

        service.processEvents(messages, "requestId", "writeServiceId");
        ArgumentCaptor<List<Event>> argumentCaptorEvent = ArgumentCaptor.forClass(List.class);
        verify(eventManagement, times(1)).post(argumentCaptorEvent.capture());
        List<Event> capturedEvent = argumentCaptorEvent.getValue();
        assertThat(capturedEvent).isNotNull();

        ArgumentCaptor<TrackedProcess> argumentCaptorTrackedProcess = ArgumentCaptor.forClass(TrackedProcess.class);
        ArgumentCaptor<PlannedEvent> argumentCaptorPE = ArgumentCaptor.forClass(PlannedEvent.class);
        ArgumentCaptor<ProcessEventDirectory> argumentCaptorPED = ArgumentCaptor.forClass(ProcessEventDirectory.class);
        verify(processManagement, times(1)).update(argumentCaptorTrackedProcess.capture(), argumentCaptorPED.capture(), argumentCaptorPE.capture());
        TrackedProcess rstTP = argumentCaptorTrackedProcess.getValue();
        assertThat(rstTP.getTrackingIds().size()).isEqualTo(1);
        assertThat(rstTP.getProcessStatus()).isEqualTo(ProcessStatus.DELAYED.name());
        PlannedEvent capturedPE = argumentCaptorPE.<List<String>>getValue();
        assertThat(capturedPE.getId()).isEqualTo(plannedEvent.getId());
        assertThat(capturedPE.getEventStatus()).isEqualTo(EventStatus.DELAYED.name());
        assertThat(capturedPE.getLastProcessEventDirectoryId()).isEqualTo(plannedEvent.getLastProcessEventDirectoryId());
        ProcessEventDirectory capturedPED = argumentCaptorPED.<List<String>>getValue();
        assertThat(capturedPED.getCorrelationType()).isEqualTo(CorrelationType.UNPLANNED_ONTIME.name());
    }

    @Test
    public void testProcessGTTOnTimeEventWhenPlannedEventIsPlannedWithDelayedEventAndUpdateStatus() {
        TrackedProcess tp = new TrackedProcess();
        String trackedProcessType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        tp.setMetadata(getMetadata(trackedProcessType));
        tp.setTrackedProcessType(trackedProcessType);
        UUID tpId = GTTUtils.UUIDUtils.generateTimeBasedUUID();
        tp.setId(tpId);
        tp.setProcessStatus(ProcessStatus.DELAYED.name());
        List<PlannedEvent> pes = new ArrayList<>();
        PlannedEvent plannedEvent = new PlannedEvent();
        plannedEvent.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.PlannedEvent"));
        plannedEvent.setId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        plannedEvent.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POConfirmedEvent");
        plannedEvent.setEventMatchKey("10");
        plannedEvent.setLocationAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:Location:shippingPoint:4712");
        plannedEvent.setPlannedTechTsLatest(Instant.parse("2019-05-22T12:00:00.213Z"));
        plannedEvent.setPlannedBusinessTimestamp(Instant.parse("2019-05-15T12:00:00.213Z"));
        plannedEvent.setPlannedBizTsEarliest(Instant.parse("2019-05-09T12:00:00.213Z"));
        plannedEvent.setPlannedBizTsLatest(Instant.parse("2019-05-22T12:00:00.213Z"));
        plannedEvent.setEventStatus(EventStatus.DELAYED.name());
        plannedEvent.setOverdueDetectionCounter(0);
        plannedEvent.setNextOverdueDetection(plannedEvent.getPlannedTechTsLatest());
        plannedEvent.setIsFinalPlannedEvent(Boolean.FALSE);
        UUID pedId = UUID.randomUUID();
        plannedEvent.setLastProcessEventDirectoryId(pedId);
        pes.add(plannedEvent);
        tp.setPlannedEvents(pes);
        List<QualifiedTrackingId> trackingIds = new ArrayList<>();
        QualifiedTrackingId trackingId = QualifiedTrackingId.build(tpId, tpId, null, null);
        trackingId.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.QualifiedTrackingId"));
        trackingIds.add(trackingId);
        tp.setTrackingIds(trackingIds);
        List<ProcessEventDirectory> peds = new ArrayList<>();
        ProcessEventDirectory ped = ProcessEventDirectory.build(GTTUtils.UUIDUtils.generateTimeBasedUUID(),
                tpId, null, GTTUtils.UUIDUtils.generateTimeBasedUUID(), CorrelationType.UNPLANNED_PROCESS_CREATION_UPDATE.name());
        peds.add(ped);
        UUID reportedEventId = UUID.randomUUID();
        ProcessEventDirectory ped2 = ProcessEventDirectory.build(pedId, tpId, plannedEvent.getId(), reportedEventId, CorrelationType.UNPLANNED_DELAYED.name());
        peds.add(ped2);
        tp.setPEDs(peds);
        given(processManagement.getWithOnlyValidDPPStatus(Mockito.any(UUIDValue.class))).willReturn(tp);
        Instant now = Instant.now();
        Event reportedEvent = new Event();
        reportedEvent.setActualBusinessTimestamp(now);
        given(eventManagement.getSingleEventById(Mockito.any(UUIDValue.class))).willReturn(reportedEvent);

        Event eventMessage = new Event();
        eventMessage.setId(UUID.randomUUID());
        eventMessage.setAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:ProcurementOrderItem:10");
        eventMessage.setModelNamespace("com.sap.gtt.app.mim");
        eventMessage.setEventType("com.sap.gtt.core.CoreModel.GTTOnTimeEvent");
        eventMessage.setEventReasonText("OnTime Event");
        eventMessage.setActualBusinessTimestamp(now.plusSeconds(60));
        eventMessage.setValue(Constant.REF_PLANNED_EVENT_TYPE, plannedEvent.getEventType());
        eventMessage.setValue(REF_PLANNED_EVENT_MATCH_KEY, plannedEvent.getEventMatchKey());
        eventMessage.setValue(Constant.REF_PLANNED_EVENT_LOCATION_ALEKEY, "xri://sap.com/sapdoc:666666:Q8JCLNT774:Location:shippingPoint:4712");
        eventMessage.setMetadata(getMetadata(eventMessage.getEventType()));
        List<Event> messages = new ArrayList<>();
        messages.add(eventMessage);
        MetadataEntityEvent eventConfig = new MetadataEntityEvent();
        eventConfig.setMatchLocation(true);
        eventConfig.setMaxOverdueDetection(3);
        eventConfig.setPeriodicOverdueDetection(Duration.parse("PT24H"));
        given(metadataManagement.getEntityEvent(Mockito.anyString(), Mockito.anyString())).willReturn(eventConfig);

        service.processEvents(messages, "requestId", "writeServiceId");
        ArgumentCaptor<List<Event>> argumentCaptorEvent = ArgumentCaptor.forClass(List.class);
        verify(eventManagement, times(1)).post(argumentCaptorEvent.capture());
        List<Event> capturedEvent = argumentCaptorEvent.getValue();
        assertThat(capturedEvent).isNotNull();

        ArgumentCaptor<TrackedProcess> argumentCaptorTrackedProcess = ArgumentCaptor.forClass(TrackedProcess.class);
        ArgumentCaptor<PlannedEvent> argumentCaptorPE = ArgumentCaptor.forClass(PlannedEvent.class);
        ArgumentCaptor<ProcessEventDirectory> argumentCaptorPED = ArgumentCaptor.forClass(ProcessEventDirectory.class);
        verify(processManagement, times(1)).update(argumentCaptorTrackedProcess.capture(), argumentCaptorPED.capture(), argumentCaptorPE.capture());
        TrackedProcess rstTP = argumentCaptorTrackedProcess.getValue();
        assertThat(rstTP.getTrackingIds().size()).isEqualTo(1);
        assertThat(rstTP.getProcessStatus()).isEqualTo(ProcessStatus.AS_PLANNED.name());
        PlannedEvent capturedPE = argumentCaptorPE.<List<String>>getValue();
        assertThat(capturedPE.getId()).isEqualTo(plannedEvent.getId());
        assertThat(capturedPE.getEventStatus()).isEqualTo(EventStatus.PLANNED.name());
        assertThat(capturedPE.getLastProcessEventDirectoryId()).isNotEqualTo(pedId);
        ProcessEventDirectory capturedPED = argumentCaptorPED.<List<String>>getValue();
        assertThat(capturedPED.getCorrelationType()).isEqualTo(CorrelationType.UNPLANNED_ONTIME.name());
    }

    @Test
    public void testProcessStatusNeedUpdate() {
        prepareEventMessage();

        TrackedProcess tp = new TrackedProcess();
        String trackedProcessType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        tp.setMetadata(getMetadata(trackedProcessType));
        tp.setTrackedProcessType(trackedProcessType);
        UUID tpId = GTTUtils.UUIDUtils.generateTimeBasedUUID();
        tp.setId(tpId);
        tp.setAltKey("altkey");
        tp.setProcessStatus(ProcessStatus.AS_PLANNED.name());
        List<PlannedEvent> pes = new ArrayList<>();
        //planned event1:
        PlannedEvent pe1 = new PlannedEvent();
        pe1.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.PlannedEvent"));
        pe1.setId(UUID.fromString("c5d8ab0d-f549-4d56-93c7-cdb1733333f2"));
        pe1.setEventMatchKey("10");
        pe1.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POGoodsReceivedEvent");
        pe1.setPlannedTechTsLatest(Instant.parse("2018-07-09T09:00:00.213Z"));
        pe1.setPlannedBusinessTimestamp(Instant.parse("2018-07-09T09:00:00.213Z"));
        pe1.setPlannedBizTsEarliest(Constant.MIN_TIMESTAMP);
        pe1.setPlannedBizTsLatest(Constant.MAX_TIMESTAMP);
        pe1.setPayloadSequence(1);
        pe1.setEventStatus(EventStatus.PLANNED.name());
        pe1.setIsFinalPlannedEvent(Boolean.FALSE);
        pe1.setLastProcessEventDirectoryId(null);
        pe1.setEventStatus(EventStatus.PLANNED.name());
        pes.add(pe1);

        //planned event2:
        PlannedEvent pe2 = new PlannedEvent();
        pe2.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.PlannedEvent"));
        pe2.setId(UUID.fromString("c5d8ab0d-f549-4d56-93c7-cdb1733333f3"));
        pe2.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POGoodsIssueEvent");
        pe2.setEventMatchKey("20");
        pe2.setPlannedTechTsLatest(Instant.parse("2018-07-08T09:00:00.213Z"));
        pe2.setPlannedBusinessTimestamp(Instant.parse("2018-07-08T09:00:00.213Z"));
        pe2.setPlannedBizTsEarliest(Constant.MIN_TIMESTAMP);
        pe2.setPlannedBizTsLatest(Constant.MAX_TIMESTAMP);
        pe2.setPayloadSequence(2);
        pe2.setEventStatus(EventStatus.PLANNED.name());
        pe2.setIsFinalPlannedEvent(Boolean.FALSE);
        pe2.setLastProcessEventDirectoryId(null);
        pe2.setEventStatus(EventStatus.PLANNED.name());
        pes.add(pe2);

        //planned event3:
        PlannedEvent pe3 = new PlannedEvent();
        pe3.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.PlannedEvent"));
        pe3.setId(UUID.fromString("c5d8ab0d-f549-4d56-93c7-cdb1733333f4"));
        pe3.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POConfirmedEvent");
        pe3.setEventMatchKey("10");
        pe3.setPlannedTechTsLatest(Instant.parse("2018-07-06T10:00:00.213Z"));
        pe3.setPlannedBusinessTimestamp(Instant.parse("2018-07-08T10:00:00.213Z"));
        pe3.setPlannedBizTsEarliest(Constant.MIN_TIMESTAMP);
        pe3.setPlannedBizTsLatest(Constant.MIN_TIMESTAMP);
        pe3.setPayloadSequence(3);
        pe3.setEventStatus(EventStatus.LATE_REPORTED.name());
        pe3.setIsFinalPlannedEvent(Boolean.FALSE);
        pe3.setLastProcessEventDirectoryId(null);
        pe3.setEventStatus(EventStatus.PLANNED.name());
        //pe3.setLocationId(GTTUtils.UUIDUtils.generateNameBasedUUID("location-alt-key"));
        pes.add(pe3);
        tp.setPlannedEvents(pes);

        List<QualifiedTrackingId> trackingIds = new ArrayList<>();
        QualifiedTrackingId trackingId = QualifiedTrackingId.build(tpId, tpId, null, null);
        trackingId.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.QualifiedTrackingId"));
        trackingIds.add(trackingId);
        tp.setTrackingIds(trackingIds);
        List<ProcessEventDirectory> peds = new ArrayList<>();
        ProcessEventDirectory ped = ProcessEventDirectory.build(GTTUtils.UUIDUtils.generateTimeBasedUUID(),
                tpId, null, GTTUtils.UUIDUtils.generateTimeBasedUUID(), CorrelationType.UNPLANNED_PROCESS_CREATION_UPDATE.name());
        peds.add(ped);
        tp.setPEDs(peds);
        given(processManagement.getWithOnlyValidDPPStatus(Mockito.any(UUIDValue.class))).willReturn(tp);

        Map<UUIDValue, String> observedTrackingIdMap = new HashMap<>();
        observedTrackingIdMap.put(UUIDValue.valueOf(tpId), tp.getAltKey());
        given(processManagement.getCorrelatedProcessMap(Mockito.any(UUIDValue.class), Mockito.any(TimestampValue.class)
                , Mockito.anyInt()))
                .willReturn(observedTrackingIdMap);
        MetadataEntityEvent eventConfig = new MetadataEntityEvent();
        eventConfig.setMatchLocation(false);
        given(metadataManagement.getEntityEvent(Mockito.anyString(), Mockito.anyString())).willReturn(eventConfig);
        MetadataEntity tpEntity = entityMap.get(trackedProcessType);
        //given(metadataManagement.getTrackedProcessEntityByEventType(Mockito.anyString(), Mockito.anyString())).willReturn(tpEntity);
        List<Event> messages = new ArrayList<>();
        messages.add(eventMessage);
        service.processEvents(messages, "requestId", "writeServiceId");

        ArgumentCaptor<TrackedProcess> argumentCaptorTrackedProcess = ArgumentCaptor.forClass(TrackedProcess.class);
        verify(processManagement, times(1)).update(argumentCaptorTrackedProcess.capture(), Mockito.any(ProcessEventDirectory.class), Mockito.any(PlannedEvent.class));
        TrackedProcess rstTP = argumentCaptorTrackedProcess.getValue();
        assertThat(rstTP.getProcessStatus()).isEqualTo(ProcessStatus.LATE.name());
    }

    @Test
    public void testPriority() {
        prepareEventMessage();
        eventMessage.setPriority(1);

        TrackedProcess tp = new TrackedProcess();
        String trackedProcessType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        tp.setMetadata(getMetadata(trackedProcessType));
        tp.setTrackedProcessType(trackedProcessType);
        UUID tpId = GTTUtils.UUIDUtils.generateTimeBasedUUID();
        tp.setId(tpId);
        tp.setAltKey("altkey");
        tp.setProcessStatus(ProcessStatus.AS_PLANNED.name());
        List<PlannedEvent> pes = new ArrayList<>();

        List<QualifiedTrackingId> trackingIds = new ArrayList<>();
        QualifiedTrackingId trackingId = QualifiedTrackingId.build(tpId, tpId, null, null);
        trackingId.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.QualifiedTrackingId"));
        trackingIds.add(trackingId);
        tp.setTrackingIds(trackingIds);
        List<ProcessEventDirectory> peds = new ArrayList<>();
        ProcessEventDirectory ped = ProcessEventDirectory.build(GTTUtils.UUIDUtils.generateTimeBasedUUID(),
                tpId, null, GTTUtils.UUIDUtils.generateTimeBasedUUID(), CorrelationType.UNPLANNED_PROCESS_CREATION_UPDATE.name());
        peds.add(ped);
        Event reportedEvent = new Event();
        reportedEvent.setPriority(0);
        reportedEvent.setActualBusinessTimestamp(Instant.parse("2018-07-29T09:00:00.213Z"));
        reportedEvent.setId(UUID.randomUUID());

        //planned event1:
        PlannedEvent pe1 = new PlannedEvent();
        pe1.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.PlannedEvent"));
        pe1.setId(UUID.randomUUID());
        pe1.setEventMatchKey("10");
        pe1.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POConfirmedEvent");
        pe1.setPlannedTechTsLatest(Instant.parse("2018-07-09T09:00:00.213Z"));
        pe1.setPlannedBusinessTimestamp(Instant.parse("2018-07-09T09:00:00.213Z"));
        pe1.setPlannedBizTsEarliest(Instant.parse("2018-07-09T10:00:00.213Z"));
        pe1.setPlannedBizTsLatest(Instant.parse("2018-07-19T09:00:00.213Z"));
        pe1.setPayloadSequence(1);
        pe1.setEventStatus(EventStatus.LATE_REPORTED.name());
        pe1.setIsFinalPlannedEvent(Boolean.FALSE);

        ProcessEventDirectory ped1 = ProcessEventDirectory.build(GTTUtils.UUIDUtils.generateTimeBasedUUID(),
                tpId, pe1.getId(), reportedEvent.getIdAsInternalValue(), CorrelationType.LATE_REPORTED.name());
        peds.add(ped1);
        tp.setPEDs(peds);

        pe1.setLastProcessEventDirectoryId(ped1.getId());
        pes.add(pe1);
        tp.setPlannedEvents(pes);
        given(processManagement.getWithOnlyValidDPPStatus(Mockito.any(UUIDValue.class))).willReturn(tp);

        Map<UUIDValue, String> observedTrackingIdMap = new HashMap<>();
        observedTrackingIdMap.put(UUIDValue.valueOf(tpId), tp.getAltKey());
        given(processManagement.getCorrelatedProcessMap(Mockito.any(UUIDValue.class), Mockito.any(TimestampValue.class)
                , Mockito.anyInt()))
                .willReturn(observedTrackingIdMap);
        MetadataEntityEvent eventConfig = new MetadataEntityEvent();
        eventConfig.setMatchLocation(false);
        given(metadataManagement.getEntityEvent(Mockito.anyString(), Mockito.anyString())).willReturn(eventConfig);

        given(eventManagement.getSingleEventById(Mockito.any(UUIDValue.class))).willReturn(reportedEvent);

        service.processEvents(Arrays.asList(eventMessage), "requestId", "writeServiceId");

        ArgumentCaptor<TrackedProcess> argumentCaptorTrackedProcess = ArgumentCaptor.forClass(TrackedProcess.class);
        verify(processManagement, times(1)).update(argumentCaptorTrackedProcess.capture(), Mockito.any(ProcessEventDirectory.class), Mockito.any(PlannedEvent.class));
        TrackedProcess rstTP = argumentCaptorTrackedProcess.getValue();
        assertThat(rstTP.getProcessStatus()).isEqualTo(ProcessStatus.EARLY.name());
    }

    @Test
    //12
    public void processCommonEventCrossSubModel() {
        Event eventMessage = new Event();
        eventMessage.setId(UUID.randomUUID());
        eventMessage.setAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:InboundDeliveryItem:1211031264");
        eventMessage.setEventReasonText("External API Event");
        eventMessage.setLocationAltKey("location-alt-key");
        eventMessage.setModelNamespace("com.sap.gtt.app.mim");
        eventMessage.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POConfirmedEvent");
        eventMessage.setEventMatchKey("10");
        eventMessage.setSenderPartyId(GTTUtils.UUIDUtils.generateTimeBasedUUID().toString());
        eventMessage.setSubaccountId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        eventMessage.setCloneInstanceId(null);
        eventMessage.setMessageSourceType("messageSourceType");
        eventMessage.setActualBusinessTimestamp(Instant.parse("2018-07-09T09:00:00.213Z"));
        eventMessage.setActualBusinessTimeZone("CET");

        CurrentMetadataEntity referenceMetadata = getMetadata("com.sap.gtt.core.CoreModel.Reference");
        List<Reference> eventReferences = new ArrayList<>();
        Reference eref = new Reference();
        eref.setMetadata(referenceMetadata);
        eref.setAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:InboundDeliveryItem:12");
        eref.setReferenceType("TRACKING");
        eref.setAction(Action.ADD.toString());
        //first add validFrom and validTo, remove later
        eref.setValidFrom(Instant.parse("1970-01-03T00:00:00Z"));
        eref.setValidTo(Instant.parse("9999-12-31T00:00:00Z"));
        eventReferences.add(eref);
        Reference eref2 = new Reference();
        eref2.setMetadata(referenceMetadata);
        eref2.setAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:InboundDeliveryItem:13");
        eref2.setReferenceType("TRACKING");
        eref2.setAction(Action.ADD.toString());
        eref2.setValidFrom(Instant.parse("1970-01-03T00:00:00Z"));
        eref2.setValidTo(Instant.parse("9999-12-31T00:00:00Z"));
        eventReferences.add(eref2);
        eventMessage.setReferences(eventReferences);
        eventMessage.setMetadata(getMetadata(eventMessage.getEventType()));

        TrackedProcess tp = new TrackedProcess();
        String trackedProcessType = "com.sap.gtt.app.mim.InboundDeliveryItemModel.InboundDeliveryItemProcess";
        tp.setMetadata(getMetadata(trackedProcessType));
        tp.setTrackedProcessType(trackedProcessType);
        tp.setAltKey("altkey");
        UUID tpId = GTTUtils.UUIDUtils.generateTimeBasedUUID();
        tp.setId(tpId);
        tp.setProcessStatus(ProcessStatus.AS_PLANNED.name());
        List<PlannedEvent> pes = new ArrayList<>();
        PlannedEvent plannedEvent = new PlannedEvent();
        plannedEvent.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.PlannedEvent"));
        plannedEvent.setId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        plannedEvent.setEventType(eventMessage.getEventType());
        plannedEvent.setEventMatchKey(eventMessage.getEventMatchKey());
        plannedEvent.setPlannedTechTsLatest(Instant.parse("2018-07-09T12:00:00.213Z"));
        plannedEvent.setPlannedBusinessTimestamp(Instant.parse("2018-07-09T12:00:00.213Z"));
        plannedEvent.setPlannedBizTsEarliest(Constant.MIN_TIMESTAMP);
        plannedEvent.setPlannedBizTsLatest(Constant.MAX_TIMESTAMP);
        plannedEvent.setIsFinalPlannedEvent(Boolean.TRUE);
        plannedEvent.setLastProcessEventDirectoryId(null);
        plannedEvent.setEventStatus(EventStatus.PLANNED.name());
        pes.add(plannedEvent);
        tp.setPlannedEvents(pes);
        List<QualifiedTrackingId> trackingIds = new ArrayList<>();
        QualifiedTrackingId trackingId = QualifiedTrackingId.build(tpId, tpId, null, null);
        trackingId.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.QualifiedTrackingId"));
        trackingIds.add(trackingId);
        tp.setTrackingIds(trackingIds);
        List<ProcessEventDirectory> peds = new ArrayList<>();
        ProcessEventDirectory ped = ProcessEventDirectory.build(GTTUtils.UUIDUtils.generateTimeBasedUUID(),
                tpId, null, GTTUtils.UUIDUtils.generateTimeBasedUUID(), CorrelationType.UNPLANNED_PROCESS_CREATION_UPDATE.name());
        peds.add(ped);
        tp.setPEDs(peds);
        given(processManagement.getWithOnlyValidDPPStatus(Mockito.any(UUIDValue.class))).willReturn(tp);

        Map<UUIDValue, String> observedTrackingIdMap = new HashMap<>();
        observedTrackingIdMap.put(UUIDValue.valueOf(tpId), tp.getAltKey());
        given(processManagement.getCorrelatedProcessMap(Mockito.any(UUIDValue.class), Mockito.any(TimestampValue.class)
                , Mockito.anyInt()))
                .willReturn(observedTrackingIdMap);
        MetadataEntityEvent eventConfig = new MetadataEntityEvent();
        eventConfig.setMatchLocation(false);
        given(metadataManagement.getEntityEvent(Mockito.anyString(), Mockito.anyString())).willReturn(eventConfig);
        //MetadataEntity tpEntity = entityMap.get(trackedProcessType);
        //given(metadataManagement.getTrackedProcessEntityByEventType(Mockito.anyString(), Mockito.anyString())).willReturn(tpEntity);
        List<Event> messages = new ArrayList<>();
        messages.add(eventMessage);
        service.processEvents(messages, "requestId", "writeServiceId");

        ArgumentCaptor<List<Event>> argumentCaptorEvent = ArgumentCaptor.forClass(List.class);
        verify(eventManagement).post(argumentCaptorEvent.capture());
        List<Event> capturedEvent = argumentCaptorEvent.getValue();
        assertThat(capturedEvent.size()).isEqualTo(1);

        ArgumentCaptor<TrackedProcess> argumentCaptorTrackedProcess = ArgumentCaptor.forClass(TrackedProcess.class);
        ArgumentCaptor<PlannedEvent> argumentCaptorPE = ArgumentCaptor.forClass(PlannedEvent.class);
        ArgumentCaptor<ProcessEventDirectory> argumentCaptorPED = ArgumentCaptor.forClass(ProcessEventDirectory.class);
        verify(processManagement, times(1)).update(argumentCaptorTrackedProcess.capture(), argumentCaptorPED.capture(), argumentCaptorPE.capture());

        TrackedProcess rstTP = argumentCaptorTrackedProcess.getValue();
        assertThat(rstTP.getTrackingIds().size()).isEqualTo(3);
        assertThat(rstTP.getProcessStatus()).isEqualTo(ProcessStatus.AS_PLANNED.name());
        assertThat(rstTP.getLifeCycleStatus()).isEqualTo(LifeCycleStatus.END_OF_BUSINESS);

        PlannedEvent capturedPE = argumentCaptorPE.<List<String>>getValue();
        assertThat(capturedPE.getEventStatus()).isEqualTo(EventStatus.REPORTED.name());
        assertThat(capturedPE.getId()).isEqualTo(plannedEvent.getId());

        ProcessEventDirectory capturedPED = argumentCaptorPED.<List<String>>getValue();
        assertThat(capturedPED.getPlannedEventId()).isEqualTo(plannedEvent.getId());
        assertThat(capturedPED.getProcessId()).isEqualTo(tpId);
    }

    @Test
    //12
    public void processGTTDeletionEvent() {
        Event eventMessage = new Event();
        eventMessage.setId(UUID.randomUUID());
        eventMessage.setAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:InboundDeliveryItem:1211031264");
        eventMessage.setEventReasonText("External API Event");
        eventMessage.setLocationAltKey("location-alt-key");
        eventMessage.setModelNamespace("com.sap.gtt.app.mim");
        eventMessage.setEventType(GTT_DELETION_EVENT.getFullName());
        eventMessage.setActualBusinessTimestamp(Instant.parse("2018-07-09T09:00:00.213Z"));
        eventMessage.setActualBusinessTimeZone("CET");
        eventMessage.setMetadata(getMetadata(eventMessage.getEventType()));

        TrackedProcess tp = new TrackedProcess();
        String trackedProcessType = "com.sap.gtt.app.mim.InboundDeliveryItemModel.InboundDeliveryItemProcess";
        tp.setMetadata(getMetadata(trackedProcessType));
        tp.setTrackedProcessType(trackedProcessType);
        UUID tpId = GTTUtils.UUIDUtils.generateTimeBasedUUID();
        tp.setId(tpId);
        tp.setProcessStatus(ProcessStatus.AS_PLANNED.name());
        List<PlannedEvent> pes = new ArrayList<>();
        PlannedEvent plannedEvent = new PlannedEvent();
        plannedEvent.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.PlannedEvent"));
        plannedEvent.setId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        plannedEvent.setEventType(eventMessage.getEventType());
        plannedEvent.setPlannedTechTsLatest(Instant.parse("2018-07-09T12:00:00.213Z"));
        plannedEvent.setPlannedBusinessTimestamp(Instant.parse("2018-07-09T12:00:00.213Z"));
        plannedEvent.setPlannedBizTsEarliest(Constant.MIN_TIMESTAMP);
        plannedEvent.setPlannedBizTsLatest(Constant.MAX_TIMESTAMP);
        plannedEvent.setLastProcessEventDirectoryId(null);
        plannedEvent.setEventStatus(EventStatus.PLANNED.name());
        pes.add(plannedEvent);
        tp.setPlannedEvents(pes);
        List<QualifiedTrackingId> trackingIds = new ArrayList<>();
        QualifiedTrackingId trackingId = QualifiedTrackingId.build(tpId, tpId, null, null);
        trackingId.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.QualifiedTrackingId"));
        trackingIds.add(trackingId);
        tp.setTrackingIds(trackingIds);
        List<ProcessEventDirectory> peds = new ArrayList<>();
        ProcessEventDirectory ped = ProcessEventDirectory.build(GTTUtils.UUIDUtils.generateTimeBasedUUID(),
                tpId, null, GTTUtils.UUIDUtils.generateTimeBasedUUID(), CorrelationType.UNPLANNED_PROCESS_CREATION_UPDATE.name());
        peds.add(ped);
        tp.setPEDs(peds);
        given(processManagement.getWithOnlyValidDPPStatus(Mockito.any(UUIDValue.class))).willReturn(tp);

        List<Event> messages = new ArrayList<>();
        messages.add(eventMessage);
        service.processEvents(messages, "requestId", "writeServiceId");

        ArgumentCaptor<List<Event>> argumentCaptorEvent = ArgumentCaptor.forClass(List.class);
        verify(eventManagement).post(argumentCaptorEvent.capture());
        List<Event> capturedEvent = argumentCaptorEvent.getValue();
        assertThat(capturedEvent.size()).isEqualTo(1);

        verify(processManagement, times(1)).delete(Mockito.any());
    }

    @Test
    public void processGTTDPPDeletionEvent() {
        Event eventMessage = new Event();
        eventMessage.setId(UUID.randomUUID());
        eventMessage.setAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:InboundDeliveryItem:1211031264");
        eventMessage.setEventReasonText("External API Event");
        eventMessage.setLocationAltKey("location-alt-key");
        eventMessage.setModelNamespace("com.sap.gtt.app.mim");
        eventMessage.setEventType(GTT_DPP_DELETION_EVENT.getFullName());
        eventMessage.setActualBusinessTimestamp(Instant.parse("2018-07-09T09:00:00.213Z"));
        eventMessage.setActualBusinessTimeZone("CET");
        eventMessage.setMetadata(getMetadata(eventMessage.getEventType()));

        TrackedProcess tp = new TrackedProcess();
        String trackedProcessType = "com.sap.gtt.app.mim.InboundDeliveryItemModel.InboundDeliveryItemProcess";
        tp.setMetadata(getMetadata(trackedProcessType));
        tp.setTrackedProcessType(trackedProcessType);
        UUID tpId = GTTUtils.UUIDUtils.generateTimeBasedUUID();
        tp.setId(tpId);
        tp.setProcessStatus(ProcessStatus.AS_PLANNED.name());
        List<PlannedEvent> pes = new ArrayList<>();
        PlannedEvent plannedEvent = new PlannedEvent();
        plannedEvent.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.PlannedEvent"));
        plannedEvent.setId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        plannedEvent.setEventType(eventMessage.getEventType());
        plannedEvent.setPlannedTechTsLatest(Instant.parse("2018-07-09T12:00:00.213Z"));
        plannedEvent.setPlannedBusinessTimestamp(Instant.parse("2018-07-09T12:00:00.213Z"));
        plannedEvent.setPlannedBizTsEarliest(Constant.MIN_TIMESTAMP);
        plannedEvent.setPlannedBizTsLatest(Constant.MAX_TIMESTAMP);
        pes.add(plannedEvent);
        tp.setPlannedEvents(pes);
        List<QualifiedTrackingId> trackingIds = new ArrayList<>();
        QualifiedTrackingId trackingId = QualifiedTrackingId.build(tpId, tpId, null, null);
        trackingId.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.QualifiedTrackingId"));
        trackingIds.add(trackingId);
        tp.setTrackingIds(trackingIds);
        List<ProcessEventDirectory> peds = new ArrayList<>();
        ProcessEventDirectory ped = ProcessEventDirectory.build(GTTUtils.UUIDUtils.generateTimeBasedUUID(),
                tpId, null, GTTUtils.UUIDUtils.generateTimeBasedUUID(), CorrelationType.UNPLANNED_PROCESS_CREATION_UPDATE.name());
        peds.add(ped);
        tp.setPEDs(peds);
        given(processManagement.get(Mockito.any(UUIDValue.class))).willReturn(tp);

        List<Event> messages = new ArrayList<>();
        messages.add(eventMessage);
        service.processEvents(messages, "requestId", "writeServiceId");

        assertThat(tp.getLifeCycleStatus()).isEqualTo(LifeCycleStatus.END_OF_RETENTION);
        ArgumentCaptor<List<Event>> argumentCaptorEvent = ArgumentCaptor.forClass(List.class);
        verify(eventManagement).post(argumentCaptorEvent.capture());
        List<Event> capturedEvent = argumentCaptorEvent.getValue();
        assertThat(capturedEvent.size()).isEqualTo(1);

        verify(processManagement, times(1)).delete(Mockito.any());
    }

    @Test
    public void processGTTDPPBlockingEvent() {
        Event eventMessage = new Event();
        eventMessage.setId(UUID.randomUUID());
        eventMessage.setAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:InboundDeliveryItem:1211031264");
        eventMessage.setEventReasonText("External API Event");
        eventMessage.setLocationAltKey("location-alt-key");
        eventMessage.setModelNamespace("com.sap.gtt.app.mim");
        eventMessage.setEventType(GTT_DPP_BLOCKING_EVENT.getFullName());
        eventMessage.setActualBusinessTimestamp(Instant.parse("2018-07-09T09:00:00.213Z"));
        eventMessage.setActualBusinessTimeZone("CET");
        eventMessage.setMetadata(getMetadata(eventMessage.getEventType()));

        TrackedProcess tp = new TrackedProcess();
        String trackedProcessType = "com.sap.gtt.app.mim.InboundDeliveryItemModel.InboundDeliveryItemProcess";
        tp.setMetadata(getMetadata(trackedProcessType));
        tp.setTrackedProcessType(trackedProcessType);
        UUID tpId = GTTUtils.UUIDUtils.generateTimeBasedUUID();
        tp.setId(tpId);
        tp.setProcessStatus(ProcessStatus.AS_PLANNED.name());
        List<PlannedEvent> pes = new ArrayList<>();
        PlannedEvent plannedEvent = new PlannedEvent();
        plannedEvent.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.PlannedEvent"));
        plannedEvent.setId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        plannedEvent.setEventType(eventMessage.getEventType());
        plannedEvent.setPlannedTechTsLatest(Instant.parse("2018-07-09T12:00:00.213Z"));
        plannedEvent.setPlannedBusinessTimestamp(Instant.parse("2018-07-09T12:00:00.213Z"));
        plannedEvent.setPlannedBizTsEarliest(Constant.MIN_TIMESTAMP);
        plannedEvent.setPlannedBizTsLatest(Constant.MAX_TIMESTAMP);
        pes.add(plannedEvent);
        tp.setPlannedEvents(pes);
        List<QualifiedTrackingId> trackingIds = new ArrayList<>();
        QualifiedTrackingId trackingId = QualifiedTrackingId.build(tpId, tpId, null, null);
        trackingId.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.QualifiedTrackingId"));
        trackingIds.add(trackingId);
        tp.setTrackingIds(trackingIds);
        List<ProcessEventDirectory> peds = new ArrayList<>();
        ProcessEventDirectory ped = ProcessEventDirectory.build(GTTUtils.UUIDUtils.generateTimeBasedUUID(),
                tpId, null, GTTUtils.UUIDUtils.generateTimeBasedUUID(), CorrelationType.UNPLANNED_PROCESS_CREATION_UPDATE.name());
        peds.add(ped);
        tp.setPEDs(peds);
        given(processManagement.getWithOnlyValidDPPStatus(Mockito.any(UUIDValue.class))).willReturn(tp);

        List<Event> messages = new ArrayList<>();
        messages.add(eventMessage);
        service.processEvents(messages, "requestId", "writeServiceId");

        assertThat(tp.getLifeCycleStatus()).isEqualTo(LifeCycleStatus.END_OF_PURPOSE);
        ArgumentCaptor<List<Event>> argumentCaptorEvent = ArgumentCaptor.forClass(List.class);
        verify(eventManagement).post(argumentCaptorEvent.capture());
        List<Event> capturedEvent = argumentCaptorEvent.getValue();
        assertThat(capturedEvent.size()).isEqualTo(1);
    }

    //MPE related test cases
    @Test
    public void processCommonEventWhenThereIsNoCorrelation() {
        prepareEventMessage();
        List<Event> messages = new ArrayList<>();
        messages.add(eventMessage);
        Map<UUIDValue, String> observedTrackingIdMap = new HashMap<>();
        given(processManagement.getCorrelatedProcessMap(Mockito.any(UUIDValue.class), Mockito.any(TimestampValue.class)
                , Mockito.anyInt()))
                .willReturn(observedTrackingIdMap);
        service.processEvents(messages, "requestId", "writeServiceId");

        ArgumentCaptor<ExecutionDto> argumentCaptorExecutionDto = ArgumentCaptor.forClass(ExecutionDto.class);
        verify(executionHistoryManagement).insertExecution(argumentCaptorExecutionDto.capture());
        ExecutionDto executionDto = argumentCaptorExecutionDto.getValue();
        assertThat(executionDto).isNotNull();
        assertThat(executionDto.getCorrelatedTpId()).isNull();

        ArgumentCaptor<ExecutionMessageDto> argumentCaptorExecutionMessageDto = ArgumentCaptor.forClass(ExecutionMessageDto.class);
        verify(executionHistoryManagement).insertExecutionMessage(argumentCaptorExecutionMessageDto.capture());
        ExecutionMessageDto messageDto = argumentCaptorExecutionMessageDto.getValue();
        assertThat(messageDto).isNotNull();
        assertThat(messageDto.getPhase()).isEqualTo(Phase.CORRELATION.name());
        assertThat(messageDto.getMessageType()).isEqualTo(ExecutionStatus.ERROR.name());
    }

    @Test
    public void processCommonEventWhenTPIsNotExisted() {
        prepareEventMessage();
        UUID tpId = UUID.randomUUID();
        Map<UUIDValue, String> observedTrackingIdMap = new HashMap<>();
        observedTrackingIdMap.put(UUIDValue.valueOf(tpId), "processAltkey");
        given(processManagement.getCorrelatedProcessMap(Mockito.any(UUIDValue.class), Mockito.any(TimestampValue.class)
                , Mockito.anyInt()))
                .willReturn(observedTrackingIdMap);
        given(processManagement.getWithOnlyValidDPPStatus(Mockito.any(UUIDValue.class))).willReturn(null);
        List<Event> messages = new ArrayList<>();
        messages.add(eventMessage);
        service.processEvents(messages, "requestId", "writeServiceId");

        ArgumentCaptor<ExecutionDto> argumentCaptorExecutionDto = ArgumentCaptor.forClass(ExecutionDto.class);
        verify(executionHistoryManagement, times(2)).insertExecution(argumentCaptorExecutionDto.capture());
        List<ExecutionDto> executionDtos = argumentCaptorExecutionDto.getAllValues();
        ExecutionDto firstDto = executionDtos.get(0);
        assertThat(firstDto.getCorrelatedTpId()).isNull();
        ExecutionDto secondDto = executionDtos.get(1);
        assertThat(secondDto.getCorrelatedTpId()).isEqualTo(tpId.toString());

        ArgumentCaptor<ExecutionMessageDto> argumentCaptorExecutionMessageDto = ArgumentCaptor.forClass(ExecutionMessageDto.class);
        verify(executionHistoryManagement).insertExecutionMessage(argumentCaptorExecutionMessageDto.capture());
        ExecutionMessageDto messageDto = argumentCaptorExecutionMessageDto.getValue();
        assertThat(messageDto).isNotNull();
        assertThat(messageDto.getPhase()).isEqualTo(Phase.VALIDATION.name());
        assertThat(messageDto.getMessageType()).isEqualTo(ExecutionStatus.ERROR.name());
    }

    @Test
    public void processCommonEventWhenEventIsInvalid() {
        prepareEventMessage();

        TrackedProcess tp = new TrackedProcess();
        String trackedProcessType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        tp.setMetadata(getMetadata(trackedProcessType));
        tp.setTrackedProcessType(trackedProcessType);
        UUID tpId = GTTUtils.UUIDUtils.generateTimeBasedUUID();
        tp.setId(tpId);
        tp.setAltKey("altkey");
        tp.setProcessStatus(ProcessStatus.AS_PLANNED.name());
        List<PlannedEvent> pes = new ArrayList<>();
        //planned event1:
        PlannedEvent pe1 = new PlannedEvent();
        pe1.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.PlannedEvent"));
        pe1.setId(UUID.fromString("c5d8ab0d-f549-4d56-93c7-cdb1733333f2"));
        pe1.setEventMatchKey("10");
        pe1.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POGoodsReceivedEvent");
        pe1.setPlannedTechTsLatest(Instant.parse("2018-07-09T09:00:00.213Z"));
        pe1.setPlannedBusinessTimestamp(Instant.parse("2018-07-09T09:00:00.213Z"));
        pe1.setPlannedBizTsEarliest(Constant.MIN_TIMESTAMP);
        pe1.setPlannedBizTsLatest(Constant.MAX_TIMESTAMP);
        pe1.setPayloadSequence(1);
        pe1.setEventStatus(EventStatus.PLANNED.name());
        pe1.setIsFinalPlannedEvent(Boolean.FALSE);
        pe1.setLastProcessEventDirectoryId(null);
        pe1.setEventStatus(EventStatus.PLANNED.name());
        pes.add(pe1);

        //planned event2:
        PlannedEvent pe2 = new PlannedEvent();
        pe2.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.PlannedEvent"));
        pe2.setId(UUID.fromString("c5d8ab0d-f549-4d56-93c7-cdb1733333f3"));
        pe2.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POGoodsIssueEvent");
        pe2.setEventMatchKey("20");
        pe2.setPlannedTechTsLatest(Instant.parse("2018-07-08T09:00:00.213Z"));
        pe2.setPlannedBusinessTimestamp(Instant.parse("2018-07-08T09:00:00.213Z"));
        pe2.setPlannedBizTsEarliest(Constant.MIN_TIMESTAMP);
        pe2.setPlannedBizTsLatest(Constant.MAX_TIMESTAMP);
        pe2.setPayloadSequence(2);
        pe2.setEventStatus(EventStatus.PLANNED.name());
        pe2.setIsFinalPlannedEvent(Boolean.FALSE);
        pe2.setLastProcessEventDirectoryId(null);
        pe2.setEventStatus(EventStatus.PLANNED.name());
        pes.add(pe2);
        tp.setPlannedEvents(pes);

        List<QualifiedTrackingId> trackingIds = new ArrayList<>();
        QualifiedTrackingId trackingId = QualifiedTrackingId.build(tpId, tpId, null, null);
        trackingId.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.QualifiedTrackingId"));
        trackingIds.add(trackingId);
        tp.setTrackingIds(trackingIds);
        List<ProcessEventDirectory> peds = new ArrayList<>();
        ProcessEventDirectory ped = ProcessEventDirectory.build(GTTUtils.UUIDUtils.generateTimeBasedUUID(),
                tpId, null, GTTUtils.UUIDUtils.generateTimeBasedUUID(), CorrelationType.UNPLANNED_PROCESS_CREATION_UPDATE.name());
        peds.add(ped);
        tp.setPEDs(peds);
        given(processManagement.getWithOnlyValidDPPStatus(Mockito.any(UUIDValue.class))).willReturn(tp);

        Map<UUIDValue, String> observedTrackingIdMap = new HashMap<>();
        observedTrackingIdMap.put(UUIDValue.valueOf(tpId), tp.getAltKey());
        given(processManagement.getCorrelatedProcessMap(Mockito.any(UUIDValue.class), Mockito.any(TimestampValue.class)
                , Mockito.anyInt()))
                .willReturn(observedTrackingIdMap);
        MetadataEntityEvent eventConfig = new MetadataEntityEvent();
        eventConfig.setMatchLocation(false);
        given(metadataManagement.getEntityEvent(Mockito.anyString(), Mockito.anyString())).willReturn(eventConfig);
        List<Event> messages = new ArrayList<>();
        messages.add(eventMessage);
        service.processEvents(messages, "requestId", "writeServiceId");

        ArgumentCaptor<ExecutionDto> argumentCaptorExecutionDto = ArgumentCaptor.forClass(ExecutionDto.class);
        verify(executionHistoryManagement, times(2)).insertExecution(argumentCaptorExecutionDto.capture());
        List<ExecutionDto> executionDtos = argumentCaptorExecutionDto.getAllValues();
        ExecutionDto firstDto = executionDtos.get(0);
        assertThat(firstDto.getCorrelatedTpId()).isNull();
        ExecutionDto secondDto = executionDtos.get(1);
        assertThat(secondDto.getCorrelatedTpId()).isEqualTo(tpId.toString());

        ArgumentCaptor<ExecutionMessageDto> argumentCaptorExecutionMessageDto = ArgumentCaptor.forClass(ExecutionMessageDto.class);
        verify(executionHistoryManagement).insertExecutionMessage(argumentCaptorExecutionMessageDto.capture());
        ExecutionMessageDto messageDto = argumentCaptorExecutionMessageDto.getValue();
        assertThat(messageDto).isNotNull();
        assertThat(messageDto.getPhase()).isEqualTo(Phase.VALIDATION.name());
        assertThat(messageDto.getMessageType()).isEqualTo(ExecutionStatus.ERROR.name());
    }

    @Test
    public void processCommonEventWhenTwoEventsAndEachEventIsInvalid() {
        prepareEventMessage();
        Event eventMessage2 = new Event();
        eventMessage2.setId(UUID.randomUUID());
        eventMessage2.setAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:ProcurementOrderItem:1211031264");
        eventMessage2.setEventReasonText("External API Event");
        eventMessage2.setLocationAltKey("location-alt-key");
        eventMessage2.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POConfirmedEvent");
        eventMessage2.setEventMatchKey("10");
        eventMessage2.setSenderPartyId(GTTUtils.UUIDUtils.generateTimeBasedUUID().toString());
        eventMessage2.setSubaccountId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        eventMessage2.setCloneInstanceId(null);
        eventMessage2.setMessageSourceType("messageSourceType");
        eventMessage2.setActualBusinessTimestamp(Instant.parse("2018-07-09T09:00:00.213Z"));
        eventMessage2.setActualBusinessTimeZone("CET");

        CurrentMetadataEntity referenceMetadata = getMetadata("com.sap.gtt.core.CoreModel.Reference");
        List<Reference> eventReferences = new ArrayList<>();
        Reference eref = new Reference();
        eref.setMetadata(referenceMetadata);
        eref.setAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:OBP10_PO:12");
        eref.setReferenceType("TRACKING");
        eref.setAction(Action.ADD.toString());
        //first add validFrom and validTo, remove later
        eref.setValidFrom(Instant.parse("1970-01-03T00:00:00Z"));
        eref.setValidTo(Instant.parse("9999-12-31T00:00:00Z"));
        eventReferences.add(eref);
        Reference eref2 = new Reference();
        eref2.setMetadata(referenceMetadata);
        eref2.setAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:OBP10_PO:13");
        eref2.setReferenceType("TRACKING");
        eref2.setAction(Action.ADD.toString());
        eref2.setValidFrom(Instant.parse("1970-01-03T00:00:00Z"));
        eref2.setValidTo(Instant.parse("9999-12-31T00:00:00Z"));
        eventReferences.add(eref2);
        eventMessage2.setReferences(eventReferences);
        eventMessage2.setMetadata(getMetadata(eventMessage2.getEventType()));

        TrackedProcess tp = new TrackedProcess();
        String trackedProcessType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        tp.setMetadata(getMetadata(trackedProcessType));
        tp.setTrackedProcessType(trackedProcessType);
        UUID tpId = GTTUtils.UUIDUtils.generateTimeBasedUUID();
        tp.setId(tpId);
        tp.setAltKey("altkey");
        tp.setProcessStatus(ProcessStatus.AS_PLANNED.name());
        List<PlannedEvent> pes = new ArrayList<>();
        //planned event1:
        PlannedEvent pe1 = new PlannedEvent();
        pe1.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.PlannedEvent"));
        pe1.setId(UUID.fromString("c5d8ab0d-f549-4d56-93c7-cdb1733333f2"));
        pe1.setEventMatchKey("10");
        pe1.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POGoodsReceivedEvent");
        pe1.setPlannedTechTsLatest(Instant.parse("2018-07-09T09:00:00.213Z"));
        pe1.setPlannedBusinessTimestamp(Instant.parse("2018-07-09T09:00:00.213Z"));
        pe1.setPlannedBizTsEarliest(Constant.MIN_TIMESTAMP);
        pe1.setPlannedBizTsLatest(Constant.MAX_TIMESTAMP);
        pe1.setPayloadSequence(1);
        pe1.setEventStatus(EventStatus.PLANNED.name());
        pe1.setIsFinalPlannedEvent(Boolean.FALSE);
        pe1.setLastProcessEventDirectoryId(null);
        pe1.setEventStatus(EventStatus.PLANNED.name());
        pes.add(pe1);

        //planned event2:
        PlannedEvent pe2 = new PlannedEvent();
        pe2.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.PlannedEvent"));
        pe2.setId(UUID.fromString("c5d8ab0d-f549-4d56-93c7-cdb1733333f3"));
        pe2.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POGoodsIssueEvent");
        pe2.setEventMatchKey("20");
        pe2.setPlannedTechTsLatest(Instant.parse("2018-07-08T09:00:00.213Z"));
        pe2.setPlannedBusinessTimestamp(Instant.parse("2018-07-08T09:00:00.213Z"));
        pe2.setPlannedBizTsEarliest(Constant.MIN_TIMESTAMP);
        pe2.setPlannedBizTsLatest(Constant.MAX_TIMESTAMP);
        pe2.setPayloadSequence(2);
        pe2.setEventStatus(EventStatus.PLANNED.name());
        pe2.setIsFinalPlannedEvent(Boolean.FALSE);
        pe2.setLastProcessEventDirectoryId(null);
        pe2.setEventStatus(EventStatus.PLANNED.name());
        pes.add(pe2);
        tp.setPlannedEvents(pes);

        List<QualifiedTrackingId> trackingIds = new ArrayList<>();
        QualifiedTrackingId trackingId = QualifiedTrackingId.build(tpId, tpId, null, null);
        trackingId.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.QualifiedTrackingId"));
        trackingIds.add(trackingId);
        tp.setTrackingIds(trackingIds);
        List<ProcessEventDirectory> peds = new ArrayList<>();
        ProcessEventDirectory ped = ProcessEventDirectory.build(GTTUtils.UUIDUtils.generateTimeBasedUUID(),
                tpId, null, GTTUtils.UUIDUtils.generateTimeBasedUUID(), CorrelationType.UNPLANNED_PROCESS_CREATION_UPDATE.name());
        peds.add(ped);
        tp.setPEDs(peds);
        given(processManagement.getWithOnlyValidDPPStatus(Mockito.any(UUIDValue.class))).willReturn(tp);

        Map<UUIDValue, String> observedTrackingIdMap = new HashMap<>();
        observedTrackingIdMap.put(UUIDValue.valueOf(tpId), tp.getAltKey());
        given(processManagement.getCorrelatedProcessMap(Mockito.any(UUIDValue.class), Mockito.any(TimestampValue.class)
                , Mockito.anyInt()))
                .willReturn(observedTrackingIdMap);
        MetadataEntityEvent eventConfig = new MetadataEntityEvent();
        eventConfig.setMatchLocation(false);
        given(metadataManagement.getEntityEvent(Mockito.anyString(), Mockito.anyString())).willReturn(eventConfig);
        List<Event> messages = new ArrayList<>();
        messages.add(eventMessage);
        messages.add(eventMessage2);
        service.processEvents(messages, "requestId", "writeServiceId");

        ArgumentCaptor<ExecutionDto> argumentCaptorExecutionDto = ArgumentCaptor.forClass(ExecutionDto.class);
        verify(executionHistoryManagement, times(4)).insertExecution(argumentCaptorExecutionDto.capture());
        List<ExecutionDto> executionDtos = argumentCaptorExecutionDto.getAllValues();
        ExecutionDto firstDto = executionDtos.get(0);
        assertThat(firstDto.getCorrelatedTpId()).isNull();
        ExecutionDto secondDto = executionDtos.get(1);
        assertThat(secondDto.getCorrelatedTpId()).isEqualTo(tpId.toString());
        ExecutionDto thirdtDto = executionDtos.get(2);
        assertThat(thirdtDto.getCorrelatedTpId()).isNull();
        ExecutionDto forthDto = executionDtos.get(3);
        assertThat(forthDto.getCorrelatedTpId()).isEqualTo(tpId.toString());

        ArgumentCaptor<ExecutionMessageDto> argumentCaptorExecutionMessageDto = ArgumentCaptor.forClass(ExecutionMessageDto.class);
        verify(executionHistoryManagement, times(2)).insertExecutionMessage(argumentCaptorExecutionMessageDto.capture());
        List<ExecutionMessageDto> messageDtos = argumentCaptorExecutionMessageDto.getAllValues();
        ExecutionMessageDto messageDto = messageDtos.get(0);
        assertThat(messageDto).isNotNull();
        assertThat(messageDto.getPhase()).isEqualTo(Phase.VALIDATION.name());
        assertThat(messageDto.getMessageType()).isEqualTo(ExecutionStatus.ERROR.name());
        ExecutionMessageDto messageDto2 = messageDtos.get(0);
        assertThat(messageDto2).isNotNull();
        assertThat(messageDto2.getPhase()).isEqualTo(Phase.VALIDATION.name());
        assertThat(messageDto2.getMessageType()).isEqualTo(ExecutionStatus.ERROR.name());
    }

    @Test
    public void processCommonEventWhenEventHasTwoCorrelationTPAndEachIsInvalid() {
        prepareEventMessage();

        TrackedProcess tp = new TrackedProcess();
        String trackedProcessType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        tp.setMetadata(getMetadata(trackedProcessType));
        tp.setTrackedProcessType(trackedProcessType);
        UUID tpId = GTTUtils.UUIDUtils.generateTimeBasedUUID();
        tp.setId(tpId);
        tp.setAltKey("altkey");
        tp.setProcessStatus(ProcessStatus.AS_PLANNED.name());
        List<PlannedEvent> pes = new ArrayList<>();
        //planned event1:
        PlannedEvent pe1 = new PlannedEvent();
        pe1.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.PlannedEvent"));
        pe1.setId(UUID.fromString("c5d8ab0d-f549-4d56-93c7-cdb1733333f2"));
        pe1.setEventMatchKey("10");
        pe1.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POGoodsReceivedEvent");
        pe1.setPlannedTechTsLatest(Instant.parse("2018-07-09T09:00:00.213Z"));
        pe1.setPlannedBusinessTimestamp(Instant.parse("2018-07-09T09:00:00.213Z"));
        pe1.setPlannedBizTsEarliest(Constant.MIN_TIMESTAMP);
        pe1.setPlannedBizTsLatest(Constant.MAX_TIMESTAMP);
        pe1.setPayloadSequence(1);
        pe1.setEventStatus(EventStatus.PLANNED.name());
        pe1.setIsFinalPlannedEvent(Boolean.FALSE);
        pe1.setLastProcessEventDirectoryId(null);
        pe1.setEventStatus(EventStatus.PLANNED.name());
        pes.add(pe1);

        //planned event2:
        PlannedEvent pe2 = new PlannedEvent();
        pe2.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.PlannedEvent"));
        pe2.setId(UUID.fromString("c5d8ab0d-f549-4d56-93c7-cdb1733333f3"));
        pe2.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POGoodsIssueEvent");
        pe2.setEventMatchKey("20");
        pe2.setPlannedTechTsLatest(Instant.parse("2018-07-08T09:00:00.213Z"));
        pe2.setPlannedBusinessTimestamp(Instant.parse("2018-07-08T09:00:00.213Z"));
        pe2.setPlannedBizTsEarliest(Constant.MIN_TIMESTAMP);
        pe2.setPlannedBizTsLatest(Constant.MAX_TIMESTAMP);
        pe2.setPayloadSequence(2);
        pe2.setEventStatus(EventStatus.PLANNED.name());
        pe2.setIsFinalPlannedEvent(Boolean.FALSE);
        pe2.setLastProcessEventDirectoryId(null);
        pe2.setEventStatus(EventStatus.PLANNED.name());
        pes.add(pe2);
        tp.setPlannedEvents(pes);

        List<QualifiedTrackingId> trackingIds = new ArrayList<>();
        QualifiedTrackingId trackingId = QualifiedTrackingId.build(tpId, tpId, null, null);
        trackingId.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.QualifiedTrackingId"));
        trackingIds.add(trackingId);
        tp.setTrackingIds(trackingIds);
        List<ProcessEventDirectory> peds = new ArrayList<>();
        ProcessEventDirectory ped = ProcessEventDirectory.build(GTTUtils.UUIDUtils.generateTimeBasedUUID(),
                tpId, null, GTTUtils.UUIDUtils.generateTimeBasedUUID(), CorrelationType.UNPLANNED_PROCESS_CREATION_UPDATE.name());
        peds.add(ped);
        tp.setPEDs(peds);
        given(processManagement.getWithOnlyValidDPPStatus(Mockito.any(UUIDValue.class))).willReturn(tp);

        Map<UUIDValue, String> observedTrackingIdMap = new HashMap<>();
        observedTrackingIdMap.put(UUIDValue.valueOf(tpId), tp.getAltKey());
        UUID tpId2 = GTTUtils.UUIDUtils.generateTimeBasedUUID();
        observedTrackingIdMap.put(UUIDValue.valueOf(tpId2), "tpAltkey");
        given(processManagement.getCorrelatedProcessMap(Mockito.any(UUIDValue.class), Mockito.any(TimestampValue.class)
                , Mockito.anyInt()))
                .willReturn(observedTrackingIdMap);
        MetadataEntityEvent eventConfig = new MetadataEntityEvent();
        eventConfig.setMatchLocation(false);
        given(metadataManagement.getEntityEvent(Mockito.anyString(), Mockito.anyString())).willReturn(eventConfig);
        List<Event> messages = new ArrayList<>();
        messages.add(eventMessage);
        service.processEvents(messages, "requestId", "writeServiceId");

        ArgumentCaptor<ExecutionDto> argumentCaptorExecutionDto = ArgumentCaptor.forClass(ExecutionDto.class);
        verify(executionHistoryManagement, times(3)).insertExecution(argumentCaptorExecutionDto.capture());
        List<ExecutionDto> executionDtos = argumentCaptorExecutionDto.getAllValues();
        ExecutionDto firstDto = executionDtos.get(0);
        assertThat(firstDto.getCorrelatedTpId()).isNull();
        ExecutionDto secondDto = executionDtos.get(1);
        assertThat(secondDto.getCorrelatedTpId()).isNotNull();
        ExecutionDto thirdDto = executionDtos.get(2);
        assertThat(thirdDto.getCorrelatedTpId()).isNotNull();

        ArgumentCaptor<ExecutionMessageDto> argumentCaptorExecutionMessageDto = ArgumentCaptor.forClass(ExecutionMessageDto.class);
        verify(executionHistoryManagement, times(2)).insertExecutionMessage(argumentCaptorExecutionMessageDto.capture());
        List<ExecutionMessageDto> messageDtos = argumentCaptorExecutionMessageDto.getAllValues();
        ExecutionMessageDto messageDto = messageDtos.get(0);
        assertThat(messageDto).isNotNull();
        assertThat(messageDto.getPhase()).isEqualTo(Phase.VALIDATION.name());
        assertThat(messageDto.getMessageType()).isEqualTo(ExecutionStatus.ERROR.name());
        ExecutionMessageDto messageDto2 = messageDtos.get(0);
        assertThat(messageDto2).isNotNull();
        assertThat(messageDto2.getPhase()).isEqualTo(Phase.VALIDATION.name());
        assertThat(messageDto2.getMessageType()).isEqualTo(ExecutionStatus.ERROR.name());
    }

    /*@Test
    public void processCommonEventWhenProcessError() {
        prepareEventMessage();
        TrackedProcess tp = new TrackedProcess();
        String trackedProcessType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        tp.setMetadata(getMetadata(trackedProcessType));
        tp.setTrackedProcessType(trackedProcessType);
        UUID tpId = GTTUtils.UUIDUtils.generateTimeBasedUUID();
        tp.setId(tpId);
        tp.setAltKey("altkey");
        tp.setProcessStatus(ProcessStatus.AS_PLANNED.name());
        List<PlannedEvent> pes = new ArrayList<>();
        PlannedEvent plannedEvent = new PlannedEvent();
        plannedEvent.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.PlannedEvent"));
        plannedEvent.setId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        plannedEvent.setEventType(eventMessage.getEventType());
        plannedEvent.setEventMatchKey(eventMessage.getEventMatchKey());
        plannedEvent.setPlannedTechTsLatest(Instant.parse("2018-07-09T12:00:00.213Z"));
        plannedEvent.setPlannedBusinessTimestamp(Instant.parse("2018-07-09T12:00:00.213Z"));
        plannedEvent.setPlannedBizTsEarliest(Constant.MIN_TIMESTAMP);
        plannedEvent.setPlannedBizTsLatest(Constant.MAX_TIMESTAMP);
        plannedEvent.setIsFinalPlannedEvent(Boolean.FALSE);
        plannedEvent.setLastProcessEventDirectoryId(null);
        plannedEvent.setEventStatus(EventStatus.REPORTED.name());
        UUID lastPEDId = UUID.randomUUID();
        plannedEvent.setLastProcessEventDirectoryId(lastPEDId);
        pes.add(plannedEvent);
        tp.setPlannedEvents(pes);
        List<QualifiedTrackingId> trackingIds = new ArrayList<>();
        QualifiedTrackingId trackingId = QualifiedTrackingId.build(tpId, tpId, null, null);
        trackingId.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.QualifiedTrackingId"));
        trackingIds.add(trackingId);
        tp.setTrackingIds(trackingIds);
        List<ProcessEventDirectory> peds = new ArrayList<>();
        ProcessEventDirectory ped1 = ProcessEventDirectory.build(GTTUtils.UUIDUtils.generateTimeBasedUUID(),
                tpId, null, GTTUtils.UUIDUtils.generateTimeBasedUUID(), CorrelationType.UNPLANNED_PROCESS_CREATION_UPDATE.name());
        peds.add(ped1);
        ProcessEventDirectory ped2 = ProcessEventDirectory.build(lastPEDId, tpId, plannedEvent.getId(),
                GTTUtils.UUIDUtils.generateTimeBasedUUID(), CorrelationType.REPORTED.name());
        peds.add(ped2);
        tp.setPEDs(peds);
        given(processManagement.getWithOnlyValidDPPStatus(Mockito.any(UUIDValue.class))).willReturn(tp);

        Map<UUIDValue, String> observedTrackingIdMap = new HashMap<>();
        observedTrackingIdMap.put(UUIDValue.valueOf(tpId), tp.getAltKey());
        given(processManagement.getCorrelatedProcessMap(Mockito.any(UUIDValue.class), Mockito.any(TimestampValue.class)))
                .willReturn(observedTrackingIdMap);
        MetadataEntityEvent eventConfig = new MetadataEntityEvent();
        eventConfig.setMatchLocation(false);
        given(metadataManagement.getEntityEvent(Mockito.anyString(), Mockito.anyString())).willReturn(eventConfig);
        BaseRuntimeException baseRuntimeException = new InternalErrorException("process error");
        given(eventManagement.getSingleEventById(Mockito.any())).willThrow(baseRuntimeException);
        List<Event> messages = new ArrayList<>();
        messages.add(eventMessage);
        try {
            service.processEvents(messages, "requestId", "writeServiceId");
            fail();
        } catch (BaseRuntimeException e) {
            assertTrue(true);
        }

        ArgumentCaptor<ExecutionDto> argumentCaptorExecutionDto = ArgumentCaptor.forClass(ExecutionDto.class);
        verify(executionHistoryManagement, times(2)).insertExecution(argumentCaptorExecutionDto.capture());
        List<ExecutionDto> executionDtos = argumentCaptorExecutionDto.getAllValues();
        ExecutionDto firstDto = executionDtos.get(0);
        assertThat(firstDto.getCorrelatedTpId()).isNull();
        ExecutionDto secondDto = executionDtos.get(1);
        assertThat(secondDto.getCorrelatedTpId()).isEqualTo(tpId.toString());

        ArgumentCaptor<ExecutionMessageDto> argumentCaptorExecutionMessageDto = ArgumentCaptor.forClass(ExecutionMessageDto.class);
        verify(executionHistoryManagement).insertExecutionMessage(argumentCaptorExecutionMessageDto.capture());
        ExecutionMessageDto messageDto = argumentCaptorExecutionMessageDto.getValue();
        assertThat(messageDto).isNotNull();
        assertThat(messageDto.getPhase()).isEqualTo(Phase.PROCESS.name());
        assertThat(messageDto.getMessageType()).isEqualTo(ExecutionStatus.ERROR.name());
    }*/

    @Test
    public void updateTPWhenTPIsInBlockStatus() {
        prepareProcessEventMessage();
        List<Event> messages = new ArrayList<>();
        messages.add(processEventMessage);

        TrackedProcess existedTP = new TrackedProcess();
        existedTP.setId(UUID.randomUUID());
        existedTP.setLifeCycleStatus(LifeCycleStatus.END_OF_RETENTION);
        existedTP.setLastChangedAtBusinessTime(Instant.now().minusSeconds(600));
        String trackedProcessType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        MetadataEntity tpEntity = entityMap.get(trackedProcessType);
        given(metadataManagement.getTrackedProcessEntityByEventType(Mockito.anyString(), eq(processEventMessage.getEventType()))).willReturn(tpEntity);
        MetadataEntityEvent eventConfig = new MetadataEntityEvent();
        eventConfig.setTechnicalToleranceValue(null);
        eventConfig.setBusinessToleranceValue(null);
        eventConfig.setMatchLocation(true);
        given(metadataManagement.getEntityEvent(Mockito.anyString(), Mockito.anyString())).willReturn(eventConfig);
        given(processManagement.get(any(CurrentMetadataEntity.class), Mockito.any(UUIDValue.class))).willReturn(existedTP);
        try {
            service.processEvents(messages, "requestId", "writeServiceId");
            fail();
        } catch (BaseRuntimeException e) {
            assertTrue(true);
        }

        verify(eventManagement, times(1)).post(Mockito.anyList());
        ArgumentCaptor<ExecutionDto> argumentCaptorExecutionDto = ArgumentCaptor.forClass(ExecutionDto.class);
        verify(executionHistoryManagement).insertExecution(argumentCaptorExecutionDto.capture());
        ExecutionDto executionDto = argumentCaptorExecutionDto.getValue();
        assertThat(executionDto).isNotNull();
        assertThat(executionDto.getCorrelatedTpId()).isNotNull();

        ArgumentCaptor<ExecutionMessageDto> argumentCaptorExecutionMessageDto = ArgumentCaptor.forClass(ExecutionMessageDto.class);
        verify(executionHistoryManagement).insertExecutionMessage(argumentCaptorExecutionMessageDto.capture());
        ExecutionMessageDto messageDto = argumentCaptorExecutionMessageDto.getValue();
        assertThat(messageDto).isNotNull();
        assertThat(messageDto.getPhase()).isEqualTo(Phase.INIT.name());
        assertThat(messageDto.getMessageType()).isEqualTo(ExecutionStatus.ERROR.name());
    }

    @Test
    public void createNewTPWhenEvent2ActionRunIntoError() throws InterruptedException, ExecutionException, TimeoutException {
        prepareProcessEventMessage();
        List<Event> processEventMessages = new ArrayList<>();
        processEventMessages.add(processEventMessage);

        MetadataEntityEvent eventConfig = new MetadataEntityEvent();
        eventConfig.setTechnicalToleranceValue(null);
        eventConfig.setBusinessToleranceValue(null);
        given(metadataManagement.getEntityEvent(Mockito.anyString(), Mockito.anyString())).willReturn(eventConfig);

        String trackedProcessType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        MetadataEntity tpEntity = entityMap.get(trackedProcessType);
        given(metadataManagement.getTrackedProcessEntityByEventType(Mockito.anyString(), eq(processEventMessage.getEventType()))).willReturn(tpEntity);
        given(metadataManagement.getMetadataProjectFileFieldInfo(Mockito.anyString(), Mockito.any(MetadataConstants.MetadataProjectFileField.class))).willReturn("script");
        Future<String> futureTask = mock(Future.class);
        given(ruleScriptLauncher.execute(Mockito.anyString(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).willReturn(futureTask);
        GTTEmbededRuleScriptInternalException scriptException = new GTTEmbededRuleScriptInternalException(1, 1, "", new Exception(""));
        given(futureTask.get(Mockito.anyLong(), eq(TimeUnit.MILLISECONDS))).willThrow(scriptException);
        try {
            service.processEvents(processEventMessages, "requestId", "writeServiceId");
            fail();
        } catch (BaseRuntimeException e) {
            assertTrue(true);
        }

        verify(eventManagement, times(1)).post(Mockito.anyList());
        ArgumentCaptor<TrackedProcess> argumentCaptor = ArgumentCaptor.forClass(TrackedProcess.class);
        verify(processManagement, times(1)).create(argumentCaptor.capture());
        TrackedProcess tpRst = argumentCaptor.<List<String>>getValue();
        List<PlannedEvent> plannedEvents = tpRst.getPlannedEvents();
        assertThat(plannedEvents.size()).isEqualTo(2);
        assertThat(tpRst.getTrackingIds().size()).isEqualTo(3);

        ArgumentCaptor<ExecutionDto> argumentCaptorExecutionDto = ArgumentCaptor.forClass(ExecutionDto.class);
        verify(executionHistoryManagement).insertExecution(argumentCaptorExecutionDto.capture());
        ExecutionDto executionDto = argumentCaptorExecutionDto.getValue();
        assertThat(executionDto).isNotNull();
        assertThat(executionDto.getCorrelatedTpId()).isNotNull();

        ArgumentCaptor<ExecutionMessageDto> argumentCaptorExecutionMessageDto = ArgumentCaptor.forClass(ExecutionMessageDto.class);
        verify(executionHistoryManagement).insertExecutionMessage(argumentCaptorExecutionMessageDto.capture());
        ExecutionMessageDto messageDto = argumentCaptorExecutionMessageDto.getValue();
        assertThat(messageDto).isNotNull();
        assertThat(messageDto.getPhase()).isEqualTo(Phase.EVENT2ACTION.name());
        assertThat(messageDto.getMessageType()).isEqualTo(ExecutionStatus.ERROR.name());
    }

    @Test
    public void updateTPWhenMergePhaseError() {
        prepareProcessEventMessage();
        List<Event> messages = new ArrayList<>();
        messages.add(processEventMessage);

        TrackedProcess existedTP = new TrackedProcess();
        String trackedProcessType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        existedTP.setMetadata(getMetadata(trackedProcessType));
        existedTP.setTrackedProcessType(trackedProcessType);
        existedTP.setAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:ProcurementOrderItem:1");
        existedTP.setId(GTTUtils.UUIDUtils.generateNameBasedUUID(processEventMessage.getAltKey()));
        existedTP.setScheme("xri://sap.com/sapdoc");
        existedTP.setPartyId("666666");
        existedTP.setLogicalSystem("Q8JCLNT774");
        existedTP.setTrackingIdType("DEL_NO");
        existedTP.setTrackingId("1211031264");
        existedTP.setSubaccountId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        existedTP.setCloneInstanceId(null);
        existedTP.setLifeCycleStatus(LifeCycleStatus.BUSINESS_ACTIVE);
        existedTP.setValue("procurementOrderNO", "1211031264");
        existedTP.setValue("itemNO", "2345");
        existedTP.setValue("scheduleLine", "0001");
        //SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        existedTP.setValue("supplierId", "supplier");
        existedTP.setValue("materialId", "material");
        existedTP.setValue("receivingLocationId", "location");
        existedTP.setValue("plannedDeliveryDate", Instant.parse("2018-07-09T09:00:00.213Z"));
        existedTP.setValue("earlistETA", Instant.parse("2018-07-09T09:00:00.213Z"));
        existedTP.setValue("procurementOrderItemQty", 3.0);
        existedTP.setValue("goodsReceivedQty", 2.0);
        existedTP.setValue("procurementOrderItemUOM", "M3");
        existedTP.setValue("goodsReceivedUOM", "KG");
        existedTP.setCreationDateTime(Instant.parse("2018-06-09T00:00:00Z"));
        existedTP.setCreatedByUser("aaa");
        existedTP.setLastChangedAtBusinessTime(Instant.now().minusSeconds(600));
        List<QualifiedTrackingId> trackingIds = new ArrayList<>();
        CurrentMetadataEntity metadataOfQualifiedTrackingId = getMetadata(MetadataConstants.CoreModelEntity.QUALIFIED_TRACKING_ID.getFullName());
        QualifiedTrackingId trackingId0 = new QualifiedTrackingId();
        trackingId0.setMetadata(metadataOfQualifiedTrackingId);
        UUID processId = existedTP.getIdAsInternalValue();
        trackingId0.setProcessId(processId);
        trackingId0.setObservedProcessId(existedTP.getIdAsInternalValue());
        trackingId0.setValidFrom(null);
        trackingId0.setValidTo(null);
        trackingIds.add(trackingId0);
        existedTP.setTrackingIds(trackingIds);
        List<PlannedEvent> plannedEvents = new ArrayList<>();
        CurrentMetadataEntity metadataForPlannedEvent = getMetadata(MetadataConstants.CoreModelEntity.PLANNED_EVENT.getFullName());
        PlannedEvent pe1 = new PlannedEvent();
        pe1.setMetadata(metadataForPlannedEvent);
        pe1.setId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        pe1.setProcessId(existedTP.getId());
        pe1.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POConfirmedEvent");
        pe1.setEventMatchKey("10");
        pe1.setNextOverdueDetection(Instant.now());
        pe1.setOverdueDetectionCounter(0);
        pe1.setPlannedTechnicalTimestamp(Instant.parse("2018-07-09T12:00:00.213Z"));
        pe1.setPlannedTechTsEarliest(Instant.parse("2018-07-09T12:00:00.213Z"));
        pe1.setPlannedTechTsLatest(Instant.parse("2018-07-09T12:00:00.213Z"));
        pe1.setPlannedBusinessTimestamp(Instant.parse("2018-07-09T09:00:00.213Z"));
        pe1.setPlannedBizTsEarliest(Instant.parse("2018-07-09T09:00:00.213Z"));
        pe1.setPlannedBizTsLatest(Instant.parse("2018-07-09T09:00:00.213Z"));
        pe1.setPlannedBusinessTimeZone("CET");
        pe1.setPayloadSequence(1);
        pe1.setLastProcessEventDirectoryId(null);
        pe1.setEventStatus(EventStatus.REPORTED.name());
        plannedEvents.add(pe1);
        existedTP.setPlannedEvents(plannedEvents);
        List<ProcessEventDirectory> eventDirectories = new ArrayList<>();
        ProcessEventDirectory eventDirectory = new ProcessEventDirectory();
        eventDirectory.setMetadata(getMetadata(MetadataConstants.CoreModelEntity.PROCESS_EVENT_DIRECTORY.getFullName()));
        eventDirectory.setId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        eventDirectory.setProcessId(processId);
        eventDirectory.setPlannedEventId(pe1.getId());
        eventDirectory.setEventId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        eventDirectories.add(eventDirectory);
        existedTP.setPEDs(eventDirectories);

        MetadataEntity tpEntity = entityMap.get(trackedProcessType);
        given(metadataManagement.getTrackedProcessEntityByEventType(Mockito.anyString(), eq(processEventMessage.getEventType()))).willReturn(tpEntity);
        MetadataEntityEvent eventConfig = new MetadataEntityEvent();
        eventConfig.setTechnicalToleranceValue(null);
        eventConfig.setBusinessToleranceValue(null);
        eventConfig.setMatchLocation(true);
        given(metadataManagement.getEntityEvent(Mockito.anyString(), Mockito.anyString())).willReturn(eventConfig);
        given(processManagement.get(any(CurrentMetadataEntity.class), Mockito.any(UUIDValue.class))).willReturn(existedTP);
        BaseRuntimeException baseRuntimeException = new InternalErrorException("build QualifiedTrackingId error");
        given(metadataManagement.findAllEntitiesRecursively(Mockito.anyString(), Mockito.contains("QualifiedTrackingId"))).willThrow(baseRuntimeException);
        try {
            service.processEvents(messages, "requestId", "writeServiceId");
            fail();
        } catch (BaseRuntimeException e) {
            assertTrue(true);
        }

        verify(eventManagement, times(1)).post(Mockito.anyList());
        ArgumentCaptor<ExecutionDto> argumentCaptorExecutionDto = ArgumentCaptor.forClass(ExecutionDto.class);
        verify(executionHistoryManagement).insertExecution(argumentCaptorExecutionDto.capture());
        ExecutionDto executionDto = argumentCaptorExecutionDto.getValue();
        assertThat(executionDto).isNotNull();
        assertThat(executionDto.getCorrelatedTpId()).isNotNull();

        ArgumentCaptor<ExecutionMessageDto> argumentCaptorExecutionMessageDto = ArgumentCaptor.forClass(ExecutionMessageDto.class);
        verify(executionHistoryManagement).insertExecutionMessage(argumentCaptorExecutionMessageDto.capture());
        ExecutionMessageDto messageDto = argumentCaptorExecutionMessageDto.getValue();
        assertThat(messageDto).isNotNull();
        assertThat(messageDto.getPhase()).isEqualTo(Phase.MERGE.name());
        assertThat(messageDto.getMessageType()).isEqualTo(ExecutionStatus.ERROR.name());
    }

    @Test
    public void updateTPWhenUpdateDBError() {
        prepareProcessEventMessage();
        List<Event> messages = new ArrayList<>();
        messages.add(processEventMessage);

        TrackedProcess existedTP = new TrackedProcess();
        String trackedProcessType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        existedTP.setMetadata(getMetadata(trackedProcessType));
        existedTP.setTrackedProcessType(trackedProcessType);
        existedTP.setAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:ProcurementOrderItem:1");
        existedTP.setId(GTTUtils.UUIDUtils.generateNameBasedUUID(processEventMessage.getAltKey()));
        existedTP.setScheme("xri://sap.com/sapdoc");
        existedTP.setPartyId("666666");
        existedTP.setLogicalSystem("Q8JCLNT774");
        existedTP.setTrackingIdType("DEL_NO");
        existedTP.setTrackingId("1211031264");
        existedTP.setSubaccountId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        existedTP.setCloneInstanceId(null);
        existedTP.setLifeCycleStatus(LifeCycleStatus.BUSINESS_ACTIVE);
        existedTP.setValue("procurementOrderNO", "1211031264");
        existedTP.setValue("itemNO", "2345");
        existedTP.setValue("scheduleLine", "0001");
        //SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        existedTP.setValue("supplierId", "supplier");
        existedTP.setValue("materialId", "material");
        existedTP.setValue("receivingLocationId", "location");
        existedTP.setValue("plannedDeliveryDate", Instant.parse("2018-07-09T09:00:00.213Z"));
        existedTP.setValue("earlistETA", Instant.parse("2018-07-09T09:00:00.213Z"));
        existedTP.setValue("procurementOrderItemQty", 3.0);
        existedTP.setValue("goodsReceivedQty", 2.0);
        existedTP.setValue("procurementOrderItemUOM", "M3");
        existedTP.setValue("goodsReceivedUOM", "KG");
        existedTP.setCreationDateTime(Instant.parse("2018-06-09T00:00:00Z"));
        existedTP.setCreatedByUser("aaa");
        existedTP.setLastChangedAtBusinessTime(Instant.now().minusSeconds(600));
        List<QualifiedTrackingId> trackingIds = new ArrayList<>();
        CurrentMetadataEntity metadataOfQualifiedTrackingId = getMetadata(MetadataConstants.CoreModelEntity.QUALIFIED_TRACKING_ID.getFullName());
        QualifiedTrackingId trackingId0 = new QualifiedTrackingId();
        trackingId0.setMetadata(metadataOfQualifiedTrackingId);
        UUID processId = existedTP.getIdAsInternalValue();
        trackingId0.setProcessId(processId);
        trackingId0.setObservedProcessId(existedTP.getIdAsInternalValue());
        trackingId0.setValidFrom(null);
        trackingId0.setValidTo(null);
        trackingIds.add(trackingId0);
        existedTP.setTrackingIds(trackingIds);
        List<PlannedEvent> plannedEvents = new ArrayList<>();
        CurrentMetadataEntity metadataForPlannedEvent = getMetadata(MetadataConstants.CoreModelEntity.PLANNED_EVENT.getFullName());
        PlannedEvent pe1 = new PlannedEvent();
        pe1.setMetadata(metadataForPlannedEvent);
        pe1.setId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        pe1.setProcessId(existedTP.getId());
        pe1.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POConfirmedEvent");
        pe1.setEventMatchKey("10");
        pe1.setNextOverdueDetection(Instant.now());
        pe1.setOverdueDetectionCounter(0);
        pe1.setPlannedTechnicalTimestamp(Instant.parse("2018-07-09T12:00:00.213Z"));
        pe1.setPlannedTechTsEarliest(Instant.parse("2018-07-09T12:00:00.213Z"));
        pe1.setPlannedTechTsLatest(Instant.parse("2018-07-09T12:00:00.213Z"));
        pe1.setPlannedBusinessTimestamp(Instant.parse("2018-07-09T09:00:00.213Z"));
        pe1.setPlannedBizTsEarliest(Instant.parse("2018-07-09T09:00:00.213Z"));
        pe1.setPlannedBizTsLatest(Instant.parse("2018-07-09T09:00:00.213Z"));
        pe1.setPlannedBusinessTimeZone("CET");
        pe1.setPayloadSequence(1);
        pe1.setLastProcessEventDirectoryId(null);
        pe1.setEventStatus(EventStatus.REPORTED.name());
        plannedEvents.add(pe1);
        existedTP.setPlannedEvents(plannedEvents);
        List<ProcessEventDirectory> eventDirectories = new ArrayList<>();
        ProcessEventDirectory eventDirectory = new ProcessEventDirectory();
        eventDirectory.setMetadata(getMetadata(MetadataConstants.CoreModelEntity.PROCESS_EVENT_DIRECTORY.getFullName()));
        eventDirectory.setId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        eventDirectory.setProcessId(processId);
        eventDirectory.setPlannedEventId(pe1.getId());
        eventDirectory.setEventId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        eventDirectories.add(eventDirectory);
        existedTP.setPEDs(eventDirectories);

        MetadataEntity tpEntity = entityMap.get(trackedProcessType);
        given(metadataManagement.getTrackedProcessEntityByEventType(Mockito.anyString(), eq(processEventMessage.getEventType()))).willReturn(tpEntity);
        MetadataEntityEvent eventConfig = new MetadataEntityEvent();
        eventConfig.setTechnicalToleranceValue(null);
        eventConfig.setBusinessToleranceValue(null);
        eventConfig.setMatchLocation(true);
        given(metadataManagement.getEntityEvent(Mockito.anyString(), Mockito.anyString())).willReturn(eventConfig);
        given(processManagement.get(any(CurrentMetadataEntity.class), Mockito.any(UUIDValue.class))).willReturn(existedTP);
        BaseRuntimeException baseRuntimeException = new InternalErrorException("update tp error");
        doThrow(baseRuntimeException).when(processManagement).update(Mockito.any(), Mockito.any(), Mockito.any());
        try {
            service.processEvents(messages, "requestId", "writeServiceId");
            fail();
        } catch (BaseRuntimeException e) {
            assertTrue(true);
        }

        verify(eventManagement, times(1)).post(Mockito.anyList());
        ArgumentCaptor<ExecutionDto> argumentCaptorExecutionDto = ArgumentCaptor.forClass(ExecutionDto.class);
        verify(executionHistoryManagement).insertExecution(argumentCaptorExecutionDto.capture());
        ExecutionDto executionDto = argumentCaptorExecutionDto.getValue();
        assertThat(executionDto).isNotNull();
        assertThat(executionDto.getCorrelatedTpId()).isNotNull();

        ArgumentCaptor<ExecutionMessageDto> argumentCaptorExecutionMessageDto = ArgumentCaptor.forClass(ExecutionMessageDto.class);
        verify(executionHistoryManagement).insertExecutionMessage(argumentCaptorExecutionMessageDto.capture());
        ExecutionMessageDto messageDto = argumentCaptorExecutionMessageDto.getValue();
        assertThat(messageDto).isNotNull();
        assertThat(messageDto.getPhase()).isEqualTo(Phase.DB.name());
        assertThat(messageDto.getMessageType()).isEqualTo(ExecutionStatus.ERROR.name());
    }

    @Test
    public void testReprocessProcessEvent() {
        Event event = new Event();
        UUID eventId = UUID.randomUUID();
        event.setId(eventId);
        event.setAltKey("altkey");
        event.setEventType("eventType");
        event.setModelNamespace("namespace");
        Instant now = Instant.now();
        event.setActualBusinessTimestamp(now);
        MetadataEntity metadataEntity = mock(MetadataEntity.class);
        given(metadataEntity.isProcessEvent()).willReturn(true);
        CurrentMetadataEntity metadata = mock(CurrentMetadataEntity.class);
        given(metadata.getCurrentEntity()).willReturn(metadataEntity);
        event.setMetadata(metadata);
        given(eventManagement.get(Mockito.any())).willReturn(event);

        UUID tpId = UUID.randomUUID();
        TrackedProcess existedTP = new TrackedProcess();
        String trackedProcessType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        existedTP.setMetadata(getMetadata(trackedProcessType));
        existedTP.setTrackedProcessType(trackedProcessType);
        existedTP.setAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:ProcurementOrderItem:1");
        existedTP.setId(tpId);
        existedTP.setScheme("xri://sap.com/sapdoc");
        existedTP.setPartyId("666666");
        existedTP.setLogicalSystem("Q8JCLNT774");
        existedTP.setTrackingIdType("DEL_NO");
        existedTP.setTrackingId("1211031264");
        existedTP.setSubaccountId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        existedTP.setCloneInstanceId(null);
        existedTP.setLifeCycleStatus(LifeCycleStatus.BUSINESS_ACTIVE);
        existedTP.setCreationDateTime(Instant.parse("2018-06-09T00:00:00Z"));
        existedTP.setCreatedByUser("aaa");
        existedTP.setLastChangedAtBusinessTime(now.minusSeconds(600));
        List<QualifiedTrackingId> trackingIds = new ArrayList<>();
        CurrentMetadataEntity metadataOfQualifiedTrackingId = getMetadata(MetadataConstants.CoreModelEntity.QUALIFIED_TRACKING_ID.getFullName());
        QualifiedTrackingId trackingId0 = new QualifiedTrackingId();
        trackingId0.setMetadata(metadataOfQualifiedTrackingId);
        UUID processId = existedTP.getIdAsInternalValue();
        trackingId0.setProcessId(processId);
        trackingId0.setObservedProcessId(existedTP.getIdAsInternalValue());
        trackingId0.setValidFrom(null);
        trackingId0.setValidTo(null);
        trackingIds.add(trackingId0);
        QualifiedTrackingId trackingId1 = new QualifiedTrackingId();
        trackingId1.setMetadata(metadataOfQualifiedTrackingId);
        trackingId1.setProcessId(processId);
        trackingId1.setObservedProcessId(
                GTTUtils.UUIDUtils.generateNameBasedUUID("xri://sap.com/sapdoc:666666:Q8JCLNT774:DEL_NO:99"));
        trackingId1.setValidFrom(Instant.parse("1970-01-03T00:00:00Z"));
        trackingId1.setValidTo(Instant.parse("9999-12-31T00:00:00Z"));
        trackingIds.add(trackingId1);
        QualifiedTrackingId trackingId2 = new QualifiedTrackingId();
        trackingId2.setMetadata(metadataOfQualifiedTrackingId);
        trackingId2.setProcessId(processId);
        trackingId2.setObservedProcessId(
                GTTUtils.UUIDUtils.generateNameBasedUUID("xri://sap.com/sapdoc:666666:Q8JCLNT774:DEL_NO:100"));
        trackingId2.setValidFrom(Instant.parse("1970-01-03T00:00:00Z"));
        trackingId2.setValidTo(Instant.parse("9999-12-31T00:00:00Z"));
        trackingIds.add(trackingId2);
        existedTP.setTrackingIds(trackingIds);
        List<PlannedEvent> plannedEvents = new ArrayList<>();
        CurrentMetadataEntity metadataForPlannedEvent = getMetadata(MetadataConstants.CoreModelEntity.PLANNED_EVENT.getFullName());
        PlannedEvent pe1 = new PlannedEvent();
        pe1.setMetadata(metadataForPlannedEvent);
        pe1.setId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        pe1.setProcessId(existedTP.getId());
        pe1.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POConfirmedEvent");
        pe1.setEventMatchKey("10");
        pe1.setNextOverdueDetection(Instant.now());
        pe1.setOverdueDetectionCounter(0);
        pe1.setPlannedTechnicalTimestamp(Instant.parse("2018-07-09T12:00:00.213Z"));
        pe1.setPlannedTechTsEarliest(Instant.parse("2018-07-09T12:00:00.213Z"));
        pe1.setPlannedTechTsLatest(Instant.parse("2018-07-09T12:00:00.213Z"));
        pe1.setPlannedBusinessTimestamp(Instant.parse("2018-07-09T09:00:00.213Z"));
        pe1.setPlannedBizTsEarliest(Instant.parse("2018-07-09T09:00:00.213Z"));
        pe1.setPlannedBizTsLatest(Instant.parse("2018-07-09T09:00:00.213Z"));
        pe1.setPlannedBusinessTimeZone("CET");
        pe1.setPayloadSequence(1);
        pe1.setLastProcessEventDirectoryId(null);
        pe1.setEventStatus(EventStatus.REPORTED.name());
        plannedEvents.add(pe1);
        PlannedEvent pe2 = new PlannedEvent();
        pe2.setMetadata(metadataForPlannedEvent);
        pe2.setId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        pe2.setProcessId(existedTP.getId());
        pe2.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POGoodsReceivedEvent");
        pe2.setEventMatchKey("20");
        pe2.setNextOverdueDetection(Instant.now());
        pe2.setOverdueDetectionCounter(0);
        pe2.setPlannedTechnicalTimestamp(Instant.parse("2018-07-08T12:00:00.213Z"));
        pe2.setPlannedTechTsEarliest(Instant.parse("2018-07-08T12:00:00.213Z"));
        pe2.setPlannedTechTsLatest(Instant.parse("2018-07-08T12:00:00.213Z"));
        pe2.setPlannedBusinessTimestamp(Instant.parse("2018-07-08T09:00:00.213Z"));
        pe2.setPlannedBizTsEarliest(Instant.parse("2018-07-08T09:00:00.213Z"));
        pe2.setPlannedBizTsLatest(Instant.parse("2018-07-08T09:00:00.213Z"));
        pe2.setPlannedBusinessTimeZone("CET");
        pe2.setPayloadSequence(2);
        pe2.setLastProcessEventDirectoryId(null);
        pe2.setEventStatus(EventStatus.PLANNED.name());
        plannedEvents.add(pe2);
        existedTP.setPlannedEvents(plannedEvents);
        List<ProcessEventDirectory> eventDirectories = new ArrayList<>();
        ProcessEventDirectory eventDirectory = new ProcessEventDirectory();
        eventDirectory.setMetadata(getMetadata(MetadataConstants.CoreModelEntity.PROCESS_EVENT_DIRECTORY.getFullName()));
        eventDirectory.setId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        eventDirectory.setProcessId(processId);
        eventDirectory.setPlannedEventId(pe1.getId());
        eventDirectory.setEventId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        eventDirectories.add(eventDirectory);
        existedTP.setPEDs(eventDirectories);
        MetadataEntity tpEntity = entityMap.get(trackedProcessType);
        given(metadataManagement.getTrackedProcessEntityByEventType(Mockito.anyString(), Mockito.anyString())).willReturn(tpEntity);
        given(processManagement.get(any(CurrentMetadataEntity.class), Mockito.any(UUIDValue.class))).willReturn(existedTP);
        given(processManagement.get(Mockito.any(UUIDValue.class))).willReturn(existedTP);
        MetadataEntityEvent eventConfig1 = new MetadataEntityEvent();
        eventConfig1.setTechnicalToleranceValue(null);
        eventConfig1.setBusinessToleranceValue(null);
        eventConfig1.setMatchLocation(true);
        MetadataEntityEvent eventConfig2 = new MetadataEntityEvent();
        eventConfig2.setTechnicalToleranceValue(null);
        eventConfig2.setBusinessToleranceValue(null);
        eventConfig2.setMatchLocation(false);
        given(metadataManagement.getEntityEvent(Mockito.anyString(), Mockito.contains("POConfirmedEvent"))).willReturn(eventConfig1);
        given(metadataManagement.getEntityEvent(Mockito.anyString(), Mockito.contains("POGoodsReceivedEvent"))).willReturn(eventConfig2);
        service.reprocess(eventId.toString(), tpId.toString());
    }

    @Test
    public void testReprocessProcessEventWhenEventIsOld() {
        Event event = new Event();
        UUID eventId = UUID.randomUUID();
        event.setId(eventId);
        event.setAltKey("altkey");
        event.setEventType("eventType");
        event.setModelNamespace("namespace");
        Instant now = Instant.now();
        event.setActualBusinessTimestamp(now);
        MetadataEntity metadataEntity = mock(MetadataEntity.class);
        given(metadataEntity.isProcessEvent()).willReturn(true);
        CurrentMetadataEntity metadata = mock(CurrentMetadataEntity.class);
        given(metadata.getCurrentEntity()).willReturn(metadataEntity);
        event.setMetadata(metadata);
        given(eventManagement.get(Mockito.any())).willReturn(event);

        UUID tpId = UUID.randomUUID();
        TrackedProcess existedTP = new TrackedProcess();
        existedTP.setLastChangedAtBusinessTime(now.plusSeconds(600));
        given(processManagement.get(Mockito.any(UUIDValue.class))).willReturn(existedTP);
        try {
            service.reprocess(eventId.toString(), tpId.toString());
            fail();
        } catch (HttpStatus4xxException e) {
            assertTrue(true);
        }
    }

    @Test
    public void testReprocessCommonEventWithCorrelation() {
        Event event = new Event();
        UUID eventId = UUID.randomUUID();
        event.setId(eventId);
        event.setAltKey("altkey");
        event.setEventType("eventType");
        event.setEventMatchKey("eventMatchKey");
        event.setModelNamespace("namespace");
        Instant now = Instant.now();
        event.setActualBusinessTimestamp(now);
        MetadataEntity metadataEntity = mock(MetadataEntity.class);
        given(metadataEntity.isProcessEvent()).willReturn(false);
        CurrentMetadataEntity metadata = mock(CurrentMetadataEntity.class);
        given(metadata.getCurrentEntity()).willReturn(metadataEntity);
        event.setMetadata(metadata);
        given(eventManagement.get(Mockito.any())).willReturn(event);

        TrackedProcess tp = new TrackedProcess();
        String trackedProcessType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        tp.setMetadata(getMetadata(trackedProcessType));
        tp.setTrackedProcessType(trackedProcessType);
        UUID tpId = GTTUtils.UUIDUtils.generateTimeBasedUUID();
        tp.setId(tpId);
        tp.setAltKey("altkey");
        tp.setProcessStatus(ProcessStatus.AS_PLANNED.name());
        List<PlannedEvent> pes = new ArrayList<>();
        PlannedEvent plannedEvent = new PlannedEvent();
        plannedEvent.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.PlannedEvent"));
        plannedEvent.setId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        plannedEvent.setEventType("eventType");
        plannedEvent.setEventMatchKey("eventMatchType");
        plannedEvent.setPlannedTechTsLatest(Instant.parse("2018-07-09T12:00:00.213Z"));
        plannedEvent.setPlannedBusinessTimestamp(Instant.parse("2018-07-09T12:00:00.213Z"));
        plannedEvent.setPlannedBizTsEarliest(Constant.MIN_TIMESTAMP);
        plannedEvent.setPlannedBizTsLatest(Constant.MAX_TIMESTAMP);
        plannedEvent.setIsFinalPlannedEvent(Boolean.FALSE);
        plannedEvent.setLastProcessEventDirectoryId(null);
        plannedEvent.setEventStatus(EventStatus.PLANNED.name());
        pes.add(plannedEvent);
        tp.setPlannedEvents(pes);
        List<QualifiedTrackingId> trackingIds = new ArrayList<>();
        QualifiedTrackingId trackingId = QualifiedTrackingId.build(tpId, tpId, null, null);
        trackingId.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.QualifiedTrackingId"));
        trackingIds.add(trackingId);
        tp.setTrackingIds(trackingIds);
        List<ProcessEventDirectory> peds = new ArrayList<>();
        ProcessEventDirectory ped = ProcessEventDirectory.build(GTTUtils.UUIDUtils.generateTimeBasedUUID(),
                tpId, null, GTTUtils.UUIDUtils.generateTimeBasedUUID(), CorrelationType.UNPLANNED_PROCESS_CREATION_UPDATE.name());
        peds.add(ped);
        tp.setPEDs(peds);
        given(processManagement.getWithOnlyValidDPPStatus(Mockito.any(UUIDValue.class))).willReturn(tp);

        Map<UUIDValue, String> observedTrackingIdMap = new HashMap<>();
        observedTrackingIdMap.put(UUIDValue.valueOf(tpId), tp.getAltKey());
        given(processManagement.getCorrelatedProcessMap(Mockito.any(UUIDValue.class), Mockito.any(TimestampValue.class)
                , Mockito.anyInt()))
                .willReturn(observedTrackingIdMap);
        MetadataEntityEvent eventConfig = new MetadataEntityEvent();
        eventConfig.setMatchLocation(false);
        given(metadataManagement.getEntityEvent(Mockito.anyString(), Mockito.anyString())).willReturn(eventConfig);
        service.reprocess(eventId.toString(), null);
    }

    @Test
    public void testReprocessCommonEventWithoutCorrelation() {
        Event event = new Event();
        UUID eventId = UUID.randomUUID();
        event.setId(eventId);
        event.setAltKey("altkey");
        event.setEventType("eventType");
        event.setEventMatchKey("eventMatchKey");
        event.setModelNamespace("namespace");
        Instant now = Instant.now();
        event.setActualBusinessTimestamp(now);
        MetadataEntity metadataEntity = mock(MetadataEntity.class);
        given(metadataEntity.isProcessEvent()).willReturn(false);
        CurrentMetadataEntity metadata = mock(CurrentMetadataEntity.class);
        given(metadata.getCurrentEntity()).willReturn(metadataEntity);
        event.setMetadata(metadata);
        given(eventManagement.get(Mockito.any())).willReturn(event);

        TrackedProcess tp = new TrackedProcess();
        String trackedProcessType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        tp.setMetadata(getMetadata(trackedProcessType));
        tp.setTrackedProcessType(trackedProcessType);
        UUID tpId = GTTUtils.UUIDUtils.generateTimeBasedUUID();
        tp.setId(tpId);
        tp.setAltKey("altkey");
        tp.setProcessStatus(ProcessStatus.AS_PLANNED.name());
        List<PlannedEvent> pes = new ArrayList<>();
        PlannedEvent plannedEvent = new PlannedEvent();
        plannedEvent.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.PlannedEvent"));
        plannedEvent.setId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        plannedEvent.setEventType("eventType");
        plannedEvent.setEventMatchKey("eventMatchType");
        plannedEvent.setPlannedTechTsLatest(Instant.parse("2018-07-09T12:00:00.213Z"));
        plannedEvent.setPlannedBusinessTimestamp(Instant.parse("2018-07-09T12:00:00.213Z"));
        plannedEvent.setPlannedBizTsEarliest(Constant.MIN_TIMESTAMP);
        plannedEvent.setPlannedBizTsLatest(Constant.MAX_TIMESTAMP);
        plannedEvent.setIsFinalPlannedEvent(Boolean.FALSE);
        plannedEvent.setLastProcessEventDirectoryId(null);
        plannedEvent.setEventStatus(EventStatus.PLANNED.name());
        pes.add(plannedEvent);
        tp.setPlannedEvents(pes);
        List<QualifiedTrackingId> trackingIds = new ArrayList<>();
        QualifiedTrackingId trackingId = QualifiedTrackingId.build(tpId, tpId, null, null);
        trackingId.setMetadata(getMetadata("com.sap.gtt.core.CoreModel.QualifiedTrackingId"));
        trackingIds.add(trackingId);
        tp.setTrackingIds(trackingIds);
        List<ProcessEventDirectory> peds = new ArrayList<>();
        ProcessEventDirectory ped = ProcessEventDirectory.build(GTTUtils.UUIDUtils.generateTimeBasedUUID(),
                tpId, null, GTTUtils.UUIDUtils.generateTimeBasedUUID(), CorrelationType.UNPLANNED_PROCESS_CREATION_UPDATE.name());
        peds.add(ped);
        tp.setPEDs(peds);
        given(processManagement.getWithOnlyValidDPPStatus(Mockito.any(UUIDValue.class))).willReturn(tp);

        MetadataEntityEvent eventConfig = new MetadataEntityEvent();
        eventConfig.setMatchLocation(false);
        given(metadataManagement.getEntityEvent(Mockito.anyString(), Mockito.anyString())).willReturn(eventConfig);
        service.reprocess(eventId.toString(), tpId.toString());
    }

    @Test
    public void testGTTUpdatePlanEventWithUpdateReportedPlannedEventsAndAddNewAndUpdateThisNewAgain() {
        Event gttUpdatePlanEvent = new Event();
        gttUpdatePlanEvent.setId(UUID.randomUUID());
        gttUpdatePlanEvent.setModelNamespace("com.sap.gtt.app.mim");
        gttUpdatePlanEvent.setEventType(GTT_UPDATE_PLAN_EVENT.getFullName());
        gttUpdatePlanEvent.setAltKey("xri://sap.com/id:LBN#10000170:Q8JCLNT774:ProcurementOrderItem:1");
        gttUpdatePlanEvent.setId(UUID.randomUUID());
        gttUpdatePlanEvent.setEventReasonText("GTT Update Plan Event");
        gttUpdatePlanEvent.setLocationAltKey("location-alt-key");
        gttUpdatePlanEvent.setSenderPartyId(GTTUtils.UUIDUtils.generateTimeBasedUUID().toString());
        gttUpdatePlanEvent.setSubaccountId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        gttUpdatePlanEvent.setCloneInstanceId(null);
        gttUpdatePlanEvent.setMessageSourceType("messageSourceType");
        gttUpdatePlanEvent.setActualBusinessTimestamp(Instant.now());
        gttUpdatePlanEvent.setActualBusinessTimeZone("CET");

        CurrentMetadataEntity referenceMetadata = getMetadata("com.sap.gtt.core.CoreModel.Reference");
        List<Reference> references = new ArrayList<>();
        Reference ref = new Reference();
        ref.setMetadata(referenceMetadata);
        ref.setAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:DEL_NO:99");
        ref.setReferenceType("TRACKING");
        ref.setValidFrom(Instant.parse("1970-01-03T00:00:00Z"));
        ref.setValidTo(Instant.parse("9999-12-31T00:00:00Z"));
        ref.setAction(Action.ADD.toString());
        references.add(ref);
        Reference ref2 = new Reference();
        ref2.setMetadata(referenceMetadata);
        ref2.setAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:DEL_NO:100");
        ref2.setReferenceType("TRACKING");
        ref2.setValidFrom(Instant.parse("1970-01-03T00:00:00Z"));
        ref2.setValidTo(Instant.parse("9999-12-31T00:00:00Z"));
        ref2.setAction(Action.ADD.toString());
        references.add(ref2);
        gttUpdatePlanEvent.setReferences(references);

        CurrentMetadataEntity peMetadata =
                getMetadata(PLANNED_EVENT_FOR_UPDATE_PLAN_EVENT.getFullName());
        List<PlannedEvent> plannedEvents1 = new ArrayList<>();
        //SimpleDateFormat sdf3 = new SimpleDateFormat("yyyy-mm-dd HH:mm:ss.SSS");
        PlannedEvent pe11 = new PlannedEvent();
        pe11.setMetadata(peMetadata);
        pe11.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POConfirmedEvent");
        pe11.setEventMatchKey("10");
        pe11.setLocationAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:Location:shippingPoint:4711");
        pe11.setPlannedTechTsEarliest(Instant.parse("2018-07-08T12:00:00.213Z"));
        pe11.setPlannedTechnicalTimestamp(Instant.parse("2018-07-09T12:00:00.213Z"));
        pe11.setPlannedTechTsLatest(Instant.parse("2018-07-10T12:00:00.213Z"));
        pe11.setPlannedBusinessTimestamp(Instant.parse("2018-07-09T09:00:00.213Z"));
        pe11.setPlannedBizTsEarliest(Instant.parse("2018-07-08T12:00:00.213Z"));
        pe11.setPlannedBizTsLatest(Instant.parse("2018-07-10T12:00:00.213Z"));
        pe11.setValue("mode", "a");
        pe11.setValue(PlannedEvent.ACTION, Action.ADD.name());
        plannedEvents1.add(pe11);
        PlannedEvent pe12 = new PlannedEvent();
        pe12.setMetadata(peMetadata);
        pe12.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POGoodsReceivedEvent");
        pe12.setEventMatchKey("20");
        pe12.setValue("mode", "b");
        pe12.setLocationAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:Location:shippingPoint:4711");
        pe12.setPlannedTechnicalTimestamp(Instant.parse("2018-07-09T12:00:00.213Z"));
        pe12.setPlannedBusinessTimestamp(Instant.parse("2018-07-09T09:00:00.213Z"));
        pe12.setPlannedTechTsLatest(Instant.parse("2018-07-20T09:00:00.213Z"));
        pe12.setPlannedBusinessTimeZone("CET");
        pe12.setValue(PlannedEvent.ACTION, Action.ADD.name());
        plannedEvents1.add(pe12);
        PlannedEvent pe13 = new PlannedEvent();
        pe13.setMetadata(peMetadata);
        pe13.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POGoodsReceivedEvent");
        pe13.setEventMatchKey("20");
        pe13.setValue("mode", "b");
        pe13.setLocationAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:Location:shippingPoint:4711");
        pe13.setPlannedTechnicalTimestamp(Instant.parse("2018-07-09T12:00:00.213Z"));
        pe13.setPlannedBusinessTimestamp(Instant.parse("2018-07-09T09:00:00.213Z"));
        pe13.setPlannedTechTsLatest(Instant.parse("2018-07-20T09:00:00.213Z"));
        pe13.setPlannedBusinessTimeZone("CET");
        pe13.setValue(PlannedEvent.ACTION, Action.ADD.name());
        plannedEvents1.add(pe13);
        gttUpdatePlanEvent.setPlannedEvents(plannedEvents1);
        gttUpdatePlanEvent.setMetadata(getMetadata(gttUpdatePlanEvent.getEventType()));

        TrackedProcess existedTP = new TrackedProcess();
        String trackedProcessType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        existedTP.setMetadata(getMetadata(trackedProcessType));
        existedTP.setTrackedProcessType(trackedProcessType);
        existedTP.setAltKey(gttUpdatePlanEvent.getAltKey());
        existedTP.setId(GTTUtils.UUIDUtils.generateNameBasedUUID(gttUpdatePlanEvent.getAltKey()));
        existedTP.setScheme(" xri://sap.com/id");
        existedTP.setPartyId("LBN#10000170");
        existedTP.setLogicalSystem("Q8JCLNT774");
        existedTP.setTrackingIdType("ProcurementOrderItem");
        existedTP.setTrackingId("1");
        existedTP.setSubaccountId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        existedTP.setCloneInstanceId(null);
        existedTP.setLifeCycleStatus(LifeCycleStatus.BUSINESS_ACTIVE);
        existedTP.setCreationDateTime(Instant.parse("2018-06-09T00:00:00Z"));
        existedTP.setCreatedByUser("aaa");
        existedTP.setLastChangedAtBusinessTime(Instant.now().minusSeconds(600));
        List<QualifiedTrackingId> trackingIds = new ArrayList<>();
        CurrentMetadataEntity metadataOfQualifiedTrackingId = getMetadata(MetadataConstants.CoreModelEntity.QUALIFIED_TRACKING_ID.getFullName());
        QualifiedTrackingId trackingId0 = new QualifiedTrackingId();
        trackingId0.setMetadata(metadataOfQualifiedTrackingId);
        UUID processId = existedTP.getIdAsInternalValue();
        trackingId0.setProcessId(processId);
        trackingId0.setObservedProcessId(existedTP.getIdAsInternalValue());
        trackingId0.setValidFrom(null);
        trackingId0.setValidTo(null);
        trackingIds.add(trackingId0);
        QualifiedTrackingId trackingId1 = new QualifiedTrackingId();
        trackingId1.setMetadata(metadataOfQualifiedTrackingId);
        trackingId1.setProcessId(processId);
        trackingId1.setObservedProcessId(
                GTTUtils.UUIDUtils.generateNameBasedUUID("xri://sap.com/sapdoc:666666:Q8JCLNT774:DEL_NO:99"));
        trackingId1.setValidFrom(Instant.parse("1970-01-03T00:00:00Z"));
        trackingId1.setValidTo(Instant.parse("9999-12-31T00:00:00Z"));
        trackingIds.add(trackingId1);
        QualifiedTrackingId trackingId2 = new QualifiedTrackingId();
        trackingId2.setMetadata(metadataOfQualifiedTrackingId);
        trackingId2.setProcessId(processId);
        trackingId2.setObservedProcessId(
                GTTUtils.UUIDUtils.generateNameBasedUUID("xri://sap.com/sapdoc:666666:Q8JCLNT774:DEL_NO:100"));
        trackingId2.setValidFrom(Instant.parse("1970-01-03T00:00:00Z"));
        trackingId2.setValidTo(Instant.parse("9999-12-31T00:00:00Z"));
        trackingIds.add(trackingId2);
        existedTP.setTrackingIds(trackingIds);
        List<PlannedEvent> plannedEvents2 = new ArrayList<>();
        CurrentMetadataEntity metadataForPlannedEvent = getMetadata(MetadataConstants.CoreModelEntity.PLANNED_EVENT.getFullName());
        PlannedEvent pe21 = new PlannedEvent();
        pe21.setMetadata(metadataForPlannedEvent);
        pe21.setId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        pe21.setProcessId(existedTP.getId());
        pe21.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POConfirmedEvent");
        pe21.setLocationAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:Location:shippingPoint:4711");
        pe21.setEventMatchKey("10");
        pe21.setValue("mode", "a");
        pe21.setNextOverdueDetection(Instant.now());
        pe21.setOverdueDetectionCounter(0);
        pe21.setPlannedTechnicalTimestamp(Instant.parse("2018-07-09T12:00:00.213Z"));
        pe21.setPlannedTechTsEarliest(Instant.parse("2018-07-09T12:00:00.213Z"));
        pe21.setPlannedTechTsLatest(Instant.parse("2018-07-09T12:00:00.213Z"));
        pe21.setPlannedBusinessTimestamp(Instant.parse("2018-07-09T09:00:00.213Z"));
        pe21.setPlannedBizTsEarliest(Instant.parse("2018-07-09T09:00:00.213Z"));
        pe21.setPlannedBizTsLatest(Instant.parse("2018-07-09T09:00:00.213Z"));
        pe21.setPlannedBusinessTimeZone("CET");
        pe21.setPayloadSequence(1);
        pe21.setLastProcessEventDirectoryId(null);
        pe21.setEventStatus(EventStatus.REPORTED.name());
        plannedEvents2.add(pe21);
        /*PlannedEvent pe2 = new PlannedEvent();
        pe2.setMetadata(metadataForPlannedEvent);
        pe2.setId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        pe2.setProcessId(existedTP.getId());
        pe2.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POGoodsReceivedEvent");
        pe2.setEventMatchKey("20");
        pe2.setNextOverdueDetection(Instant.now());
        pe2.setOverdueDetectionCounter(0);
        pe2.setPlannedTechnicalTimestamp(Instant.parse("2018-07-08T12:00:00.213Z"));
        pe2.setPlannedTechTsEarliest(Instant.parse("2018-07-08T12:00:00.213Z"));
        pe2.setPlannedTechTsLatest(Instant.parse("2018-07-08T12:00:00.213Z"));
        pe2.setPlannedBusinessTimestamp(Instant.parse("2018-07-08T09:00:00.213Z"));
        pe2.setPlannedBizTsEarliest(Instant.parse("2018-07-08T09:00:00.213Z"));
        pe2.setPlannedBizTsLatest(Instant.parse("2018-07-08T09:00:00.213Z"));
        pe2.setPlannedBusinessTimeZone("CET");
        pe2.setPayloadSequence(2);
        pe2.setLastProcessEventDirectoryId(null);
        pe2.setEventStatus(EventStatus.PLANNED.name());
        plannedEvents.add(pe2);*/
        existedTP.setPlannedEvents(plannedEvents2);
        List<ProcessEventDirectory> eventDirectories = new ArrayList<>();
        ProcessEventDirectory eventDirectory = new ProcessEventDirectory();
        eventDirectory.setMetadata(getMetadata(MetadataConstants.CoreModelEntity.PROCESS_EVENT_DIRECTORY.getFullName()));
        eventDirectory.setId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        eventDirectory.setProcessId(processId);
        eventDirectory.setPlannedEventId(pe21.getId());
        UUID eventId = GTTUtils.UUIDUtils.generateTimeBasedUUID();
        eventDirectory.setEventId(eventId);
        eventDirectory.setCorrelationType(CorrelationType.REPORTED.name());
        eventDirectories.add(eventDirectory);
        existedTP.setPEDs(eventDirectories);
        given(processManagement.getWithOnlyValidDPPStatus(Mockito.any(UUIDValue.class))).willReturn(existedTP);
        Event reportedEvent = new Event();
        reportedEvent.setActualBusinessTimestamp(Instant.parse("2018-07-09T09:00:00.213Z"));
        reportedEvent.setEventType(pe21.getEventType());
        given(eventManagement.getSingleEventById(Mockito.any())).willReturn(reportedEvent);
        MetadataEntityEvent eventConfig1 = new MetadataEntityEvent();
        eventConfig1.setTechnicalToleranceValue(null);
        eventConfig1.setBusinessToleranceValue(null);
        eventConfig1.setMatchLocation(true);
        MetadataEntityEvent eventConfig2 = new MetadataEntityEvent();
        eventConfig2.setTechnicalToleranceValue(null);
        eventConfig2.setBusinessToleranceValue(null);
        eventConfig2.setMatchLocation(false);
        MatchExtensionField matchExtensionField = new MatchExtensionField();
        matchExtensionField.setOperator(Operator.EQUAL.getValue());
        matchExtensionField.setSourceObject("PlannedEvent");
        matchExtensionField.setSourceField("mode");
        matchExtensionField.setTargetObject("POGoodsReceivedEvent");
        matchExtensionField.setTargetField("mode1");
        eventConfig2.addMatchExtensionField(matchExtensionField);

        given(metadataManagement.getEntityEvent(Mockito.anyString(), Mockito.contains("POConfirmedEvent"))).willReturn(eventConfig1);
        given(metadataManagement.getEntityEvent(Mockito.anyString(), Mockito.contains("POGoodsReceivedEvent"))).willReturn(eventConfig2);
        List<Event> messages = new ArrayList<>();
        messages.add(gttUpdatePlanEvent);
        service.processEvents(messages, "requestId", "writeServiceId");
        verify(eventManagement, times(1)).post(Mockito.anyList());
        ArgumentCaptor<TrackedProcess> argumentCaptorForTP = ArgumentCaptor.forClass(TrackedProcess.class);
        verify(processManagement, times(1)).update(argumentCaptorForTP.capture());
        TrackedProcess tpRst = argumentCaptorForTP.<List<String>>getValue();

        List<PlannedEvent> plannedEvents = tpRst.getPlannedEvents();
        assertThat(plannedEvents.size()).isEqualTo(2);
        assertThat(tpRst.getTrackingIds().size()).isEqualTo(3);
    }

    @Test
    public void testGTTUpdatePlanEventWithResetAndUpdateNonReportedPlannedEvents() {
        Event gttUpdatePlanEvent = new Event();
        gttUpdatePlanEvent.setId(UUID.randomUUID());
        gttUpdatePlanEvent.setModelNamespace("com.sap.gtt.app.mim");
        gttUpdatePlanEvent.setEventType(GTT_UPDATE_PLAN_EVENT.getFullName());
        gttUpdatePlanEvent.setAltKey("xri://sap.com/id:LBN#10000170:Q8JCLNT774:ProcurementOrderItem:1");
        gttUpdatePlanEvent.setId(UUID.randomUUID());
        gttUpdatePlanEvent.setEventReasonText("GTT Update Plan Event");
        gttUpdatePlanEvent.setLocationAltKey("location-alt-key");
        gttUpdatePlanEvent.setSenderPartyId(GTTUtils.UUIDUtils.generateTimeBasedUUID().toString());
        gttUpdatePlanEvent.setSubaccountId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        gttUpdatePlanEvent.setCloneInstanceId(null);
        gttUpdatePlanEvent.setMessageSourceType("messageSourceType");
        gttUpdatePlanEvent.setActualBusinessTimestamp(Instant.now());
        gttUpdatePlanEvent.setActualBusinessTimeZone("CET");

        CurrentMetadataEntity referenceMetadata = getMetadata("com.sap.gtt.core.CoreModel.Reference");
        List<Reference> references = new ArrayList<>();
        Reference ref = new Reference();
        ref.setMetadata(referenceMetadata);
        ref.setAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:DEL_NO:99");
        ref.setReferenceType("TRACKING");
        ref.setValidFrom(Instant.parse("1970-01-03T00:00:00Z"));
        ref.setValidTo(Instant.parse("9999-12-31T00:00:00Z"));
        ref.setAction(Action.ADD.toString());
        references.add(ref);
        Reference ref2 = new Reference();
        ref2.setMetadata(referenceMetadata);
        ref2.setAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:DEL_NO:100");
        ref2.setReferenceType("TRACKING");
        ref2.setValidFrom(Instant.parse("1970-01-03T00:00:00Z"));
        ref2.setValidTo(Instant.parse("9999-12-31T00:00:00Z"));
        ref2.setAction(Action.ADD.toString());
        references.add(ref2);
        gttUpdatePlanEvent.setReferences(references);

        CurrentMetadataEntity peMetadata =
                getMetadata(PLANNED_EVENT_FOR_UPDATE_PLAN_EVENT.getFullName());
        List<PlannedEvent> plannedEvents1 = new ArrayList<>();
        //SimpleDateFormat sdf3 = new SimpleDateFormat("yyyy-mm-dd HH:mm:ss.SSS");
        PlannedEvent pe11 = new PlannedEvent();
        pe11.setMetadata(peMetadata);
        pe11.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POConfirmedEvent");
        pe11.setEventMatchKey("10");
        pe11.setLocationAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:Location:shippingPoint:4711");
        pe11.setPlannedTechTsEarliest(Instant.parse("2018-07-08T12:00:00.213Z"));
        pe11.setPlannedTechnicalTimestamp(Instant.parse("2018-07-09T12:00:00.213Z"));
        pe11.setPlannedTechTsLatest(Instant.parse("2018-07-10T12:00:00.213Z"));
        pe11.setPlannedBusinessTimestamp(Instant.parse("2018-07-09T09:00:00.213Z"));
        pe11.setPlannedBizTsEarliest(Instant.parse("2018-07-08T12:00:00.213Z"));
        pe11.setPlannedBizTsLatest(Instant.parse("2018-07-10T12:00:00.213Z"));
        pe11.setValue("mode", "a");
        pe11.setValue(PlannedEvent.ACTION, Action.RESET.name());
        plannedEvents1.add(pe11);
        PlannedEvent pe12 = new PlannedEvent();
        pe12.setMetadata(peMetadata);
        pe12.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POGoodsReceivedEvent");
        pe12.setEventMatchKey("20");
        pe12.setValue("mode", "b");
        pe12.setLocationAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:Location:shippingPoint:4711");
        pe12.setPlannedTechnicalTimestamp(Instant.parse("2018-07-09T12:00:00.213Z"));
        pe12.setPlannedBusinessTimestamp(Instant.parse("2018-07-09T09:00:00.213Z"));
        pe12.setPlannedTechTsLatest(Instant.parse("2018-07-20T09:00:00.213Z"));
        pe12.setPlannedBusinessTimeZone("CET");
        pe12.setValue(PlannedEvent.ACTION, Action.ADD.name());
        plannedEvents1.add(pe12);
        gttUpdatePlanEvent.setPlannedEvents(plannedEvents1);
        gttUpdatePlanEvent.setMetadata(getMetadata(gttUpdatePlanEvent.getEventType()));

        TrackedProcess existedTP = new TrackedProcess();
        String trackedProcessType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        existedTP.setMetadata(getMetadata(trackedProcessType));
        existedTP.setTrackedProcessType(trackedProcessType);
        existedTP.setAltKey(gttUpdatePlanEvent.getAltKey());
        existedTP.setId(GTTUtils.UUIDUtils.generateNameBasedUUID(gttUpdatePlanEvent.getAltKey()));
        existedTP.setScheme(" xri://sap.com/id");
        existedTP.setPartyId("LBN#10000170");
        existedTP.setLogicalSystem("Q8JCLNT774");
        existedTP.setTrackingIdType("ProcurementOrderItem");
        existedTP.setTrackingId("1");
        existedTP.setSubaccountId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        existedTP.setCloneInstanceId(null);
        existedTP.setLifeCycleStatus(LifeCycleStatus.BUSINESS_ACTIVE);
        existedTP.setCreationDateTime(Instant.parse("2018-06-09T00:00:00Z"));
        existedTP.setCreatedByUser("aaa");
        existedTP.setLastChangedAtBusinessTime(Instant.now().minusSeconds(600));
        List<QualifiedTrackingId> trackingIds = new ArrayList<>();
        CurrentMetadataEntity metadataOfQualifiedTrackingId = getMetadata(MetadataConstants.CoreModelEntity.QUALIFIED_TRACKING_ID.getFullName());
        QualifiedTrackingId trackingId0 = new QualifiedTrackingId();
        trackingId0.setMetadata(metadataOfQualifiedTrackingId);
        UUID processId = existedTP.getIdAsInternalValue();
        trackingId0.setProcessId(processId);
        trackingId0.setObservedProcessId(existedTP.getIdAsInternalValue());
        trackingId0.setValidFrom(null);
        trackingId0.setValidTo(null);
        trackingIds.add(trackingId0);
        QualifiedTrackingId trackingId1 = new QualifiedTrackingId();
        trackingId1.setMetadata(metadataOfQualifiedTrackingId);
        trackingId1.setProcessId(processId);
        trackingId1.setObservedProcessId(
                GTTUtils.UUIDUtils.generateNameBasedUUID("xri://sap.com/sapdoc:666666:Q8JCLNT774:DEL_NO:99"));
        trackingId1.setValidFrom(Instant.parse("1970-01-03T00:00:00Z"));
        trackingId1.setValidTo(Instant.parse("9999-12-31T00:00:00Z"));
        trackingIds.add(trackingId1);
        QualifiedTrackingId trackingId2 = new QualifiedTrackingId();
        trackingId2.setMetadata(metadataOfQualifiedTrackingId);
        trackingId2.setProcessId(processId);
        trackingId2.setObservedProcessId(
                GTTUtils.UUIDUtils.generateNameBasedUUID("xri://sap.com/sapdoc:666666:Q8JCLNT774:DEL_NO:100"));
        trackingId2.setValidFrom(Instant.parse("1970-01-03T00:00:00Z"));
        trackingId2.setValidTo(Instant.parse("9999-12-31T00:00:00Z"));
        trackingIds.add(trackingId2);
        existedTP.setTrackingIds(trackingIds);
        List<PlannedEvent> plannedEvents2 = new ArrayList<>();
        CurrentMetadataEntity metadataForPlannedEvent = getMetadata(MetadataConstants.CoreModelEntity.PLANNED_EVENT.getFullName());
        PlannedEvent pe21 = new PlannedEvent();
        pe21.setMetadata(metadataForPlannedEvent);
        pe21.setId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        pe21.setProcessId(existedTP.getId());
        pe21.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POConfirmedEvent");
        pe21.setLocationAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:Location:shippingPoint:4711");
        pe21.setEventMatchKey("10");
        pe21.setValue("mode", "a");
        pe21.setNextOverdueDetection(Instant.now());
        pe21.setOverdueDetectionCounter(0);
        pe21.setPlannedTechnicalTimestamp(Instant.parse("2018-07-09T12:00:00.213Z"));
        pe21.setPlannedTechTsEarliest(Instant.parse("2018-07-09T12:00:00.213Z"));
        pe21.setPlannedTechTsLatest(Instant.parse("2018-07-09T12:00:00.213Z"));
        pe21.setPlannedBusinessTimestamp(Instant.parse("2018-07-09T09:00:00.213Z"));
        pe21.setPlannedBizTsEarliest(Instant.parse("2018-07-09T09:00:00.213Z"));
        pe21.setPlannedBizTsLatest(Instant.parse("2018-07-09T09:00:00.213Z"));
        pe21.setPlannedBusinessTimeZone("CET");
        pe21.setPayloadSequence(1);
        pe21.setLastProcessEventDirectoryId(null);
        pe21.setEventStatus(EventStatus.REPORTED.name());
        plannedEvents2.add(pe21);
        PlannedEvent pe22 = new PlannedEvent();
        pe22.setMetadata(metadataForPlannedEvent);
        pe22.setId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        pe22.setProcessId(existedTP.getId());
        pe22.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POGoodsReceivedEvent");
        pe22.setEventMatchKey("20");
        pe22.setValue("mode", "b");
        pe22.setNextOverdueDetection(Instant.now());
        pe22.setOverdueDetectionCounter(0);
        pe22.setPlannedTechnicalTimestamp(Instant.parse("2018-07-08T12:00:00.213Z"));
        pe22.setPlannedTechTsEarliest(Instant.parse("2018-07-08T12:00:00.213Z"));
        pe22.setPlannedTechTsLatest(Instant.parse("2018-07-08T12:00:00.213Z"));
        pe22.setPlannedBusinessTimestamp(Instant.parse("2018-07-08T09:00:00.213Z"));
        pe22.setPlannedBizTsEarliest(Instant.parse("2018-07-08T09:00:00.213Z"));
        pe22.setPlannedBizTsLatest(Instant.parse("2018-07-08T09:00:00.213Z"));
        pe22.setPlannedBusinessTimeZone("CET");
        pe22.setPayloadSequence(2);
        pe22.setLastProcessEventDirectoryId(null);
        pe22.setEventStatus(EventStatus.PLANNED.name());
        plannedEvents2.add(pe22);
        existedTP.setPlannedEvents(plannedEvents2);
        List<ProcessEventDirectory> eventDirectories = new ArrayList<>();
        ProcessEventDirectory eventDirectory = new ProcessEventDirectory();
        eventDirectory.setMetadata(getMetadata(MetadataConstants.CoreModelEntity.PROCESS_EVENT_DIRECTORY.getFullName()));
        eventDirectory.setId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        eventDirectory.setProcessId(processId);
        eventDirectory.setPlannedEventId(pe21.getId());
        UUID eventId = GTTUtils.UUIDUtils.generateTimeBasedUUID();
        eventDirectory.setEventId(eventId);
        eventDirectory.setCorrelationType(CorrelationType.REPORTED.name());
        eventDirectories.add(eventDirectory);
        existedTP.setPEDs(eventDirectories);
        given(processManagement.getWithOnlyValidDPPStatus(Mockito.any(UUIDValue.class))).willReturn(existedTP);
        /*Event reportedEvent = new Event();
        reportedEvent.setActualBusinessTimestamp(Instant.parse("2018-07-09T09:00:00.213Z"));
        reportedEvent.setEventType(pe21.getEventType());
        given(eventManagement.getSingleEventById(Mockito.any())).willReturn(reportedEvent);*/
        MetadataEntityEvent eventConfig1 = new MetadataEntityEvent();
        eventConfig1.setTechnicalToleranceValue(null);
        eventConfig1.setBusinessToleranceValue(null);
        eventConfig1.setMatchLocation(true);
        MetadataEntityEvent eventConfig2 = new MetadataEntityEvent();
        eventConfig2.setTechnicalToleranceValue(null);
        eventConfig2.setBusinessToleranceValue(null);
        eventConfig2.setMatchLocation(false);
        given(metadataManagement.getEntityEvent(Mockito.anyString(), Mockito.contains("POConfirmedEvent"))).willReturn(eventConfig1);
        given(metadataManagement.getEntityEvent(Mockito.anyString(), Mockito.contains("POGoodsReceivedEvent"))).willReturn(eventConfig2);
        List<Event> messages = new ArrayList<>();
        messages.add(gttUpdatePlanEvent);
        service.processEvents(messages, "requestId", "writeServiceId");
        verify(eventManagement, times(1)).post(Mockito.anyList());
        ArgumentCaptor<TrackedProcess> argumentCaptorForTP = ArgumentCaptor.forClass(TrackedProcess.class);
        verify(processManagement, times(1)).update(argumentCaptorForTP.capture());
        TrackedProcess tpRst = argumentCaptorForTP.<List<String>>getValue();

        List<PlannedEvent> plannedEvents = tpRst.getPlannedEvents();
        assertThat(plannedEvents.size()).isEqualTo(2);
        assertThat(tpRst.getTrackingIds().size()).isEqualTo(3);
    }

    @Test
    public void testGTTUpdatePlanEventWithDeletePlannedEvents() {
        Event gttUpdatePlanEvent = new Event();
        gttUpdatePlanEvent.setId(UUID.randomUUID());
        gttUpdatePlanEvent.setModelNamespace("com.sap.gtt.app.mim");
        gttUpdatePlanEvent.setEventType(GTT_UPDATE_PLAN_EVENT.getFullName());
        gttUpdatePlanEvent.setAltKey("xri://sap.com/id:LBN#10000170:Q8JCLNT774:ProcurementOrderItem:1");
        gttUpdatePlanEvent.setId(UUID.randomUUID());
        gttUpdatePlanEvent.setEventReasonText("GTT Update Plan Event");
        gttUpdatePlanEvent.setLocationAltKey("location-alt-key");
        gttUpdatePlanEvent.setSenderPartyId(GTTUtils.UUIDUtils.generateTimeBasedUUID().toString());
        gttUpdatePlanEvent.setSubaccountId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        gttUpdatePlanEvent.setCloneInstanceId(null);
        gttUpdatePlanEvent.setMessageSourceType("messageSourceType");
        gttUpdatePlanEvent.setActualBusinessTimestamp(Instant.now());
        gttUpdatePlanEvent.setActualBusinessTimeZone("CET");

        CurrentMetadataEntity referenceMetadata = getMetadata("com.sap.gtt.core.CoreModel.Reference");
        List<Reference> references = new ArrayList<>();
        Reference ref = new Reference();
        ref.setMetadata(referenceMetadata);
        ref.setAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:DEL_NO:99");
        ref.setReferenceType("TRACKING");
        ref.setValidFrom(Instant.parse("1970-01-03T00:00:00Z"));
        ref.setValidTo(Instant.parse("9999-12-31T00:00:00Z"));
        ref.setAction(Action.ADD.toString());
        references.add(ref);
        Reference ref2 = new Reference();
        ref2.setMetadata(referenceMetadata);
        ref2.setAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:DEL_NO:100");
        ref2.setReferenceType("TRACKING");
        ref2.setValidFrom(Instant.parse("1970-01-03T00:00:00Z"));
        ref2.setValidTo(Instant.parse("9999-12-31T00:00:00Z"));
        ref2.setAction(Action.ADD.toString());
        references.add(ref2);
        gttUpdatePlanEvent.setReferences(references);

        CurrentMetadataEntity peMetadata =
                getMetadata(PLANNED_EVENT_FOR_UPDATE_PLAN_EVENT.getFullName());
        List<PlannedEvent> plannedEvents1 = new ArrayList<>();
        //SimpleDateFormat sdf3 = new SimpleDateFormat("yyyy-mm-dd HH:mm:ss.SSS");
        PlannedEvent pe11 = new PlannedEvent();
        pe11.setMetadata(peMetadata);
        pe11.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POConfirmedEvent");
        pe11.setEventMatchKey("10");
        pe11.setLocationAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:Location:shippingPoint:4711");
        pe11.setPlannedTechTsEarliest(Instant.parse("2018-07-08T12:00:00.213Z"));
        pe11.setPlannedTechnicalTimestamp(Instant.parse("2018-07-09T12:00:00.213Z"));
        pe11.setPlannedTechTsLatest(Instant.parse("2018-07-10T12:00:00.213Z"));
        pe11.setPlannedBusinessTimestamp(Instant.parse("2018-07-09T09:00:00.213Z"));
        pe11.setPlannedBizTsEarliest(Instant.parse("2018-07-08T12:00:00.213Z"));
        pe11.setPlannedBizTsLatest(Instant.parse("2018-07-10T12:00:00.213Z"));
        pe11.setValue("mode", "a");
        pe11.setValue(PlannedEvent.ACTION, Action.DELETE.name());
        plannedEvents1.add(pe11);
        gttUpdatePlanEvent.setPlannedEvents(plannedEvents1);
        gttUpdatePlanEvent.setMetadata(getMetadata(gttUpdatePlanEvent.getEventType()));

        TrackedProcess existedTP = new TrackedProcess();
        String trackedProcessType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        existedTP.setMetadata(getMetadata(trackedProcessType));
        existedTP.setTrackedProcessType(trackedProcessType);
        existedTP.setAltKey(gttUpdatePlanEvent.getAltKey());
        existedTP.setId(GTTUtils.UUIDUtils.generateNameBasedUUID(gttUpdatePlanEvent.getAltKey()));
        existedTP.setScheme(" xri://sap.com/id");
        existedTP.setPartyId("LBN#10000170");
        existedTP.setLogicalSystem("Q8JCLNT774");
        existedTP.setTrackingIdType("ProcurementOrderItem");
        existedTP.setTrackingId("1");
        existedTP.setSubaccountId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        existedTP.setCloneInstanceId(null);
        existedTP.setLifeCycleStatus(LifeCycleStatus.BUSINESS_ACTIVE);
        existedTP.setCreationDateTime(Instant.parse("2018-06-09T00:00:00Z"));
        existedTP.setCreatedByUser("aaa");
        existedTP.setLastChangedAtBusinessTime(Instant.now().minusSeconds(600));
        List<QualifiedTrackingId> trackingIds = new ArrayList<>();
        CurrentMetadataEntity metadataOfQualifiedTrackingId = getMetadata(MetadataConstants.CoreModelEntity.QUALIFIED_TRACKING_ID.getFullName());
        QualifiedTrackingId trackingId0 = new QualifiedTrackingId();
        trackingId0.setMetadata(metadataOfQualifiedTrackingId);
        UUID processId = existedTP.getIdAsInternalValue();
        trackingId0.setProcessId(processId);
        trackingId0.setObservedProcessId(existedTP.getIdAsInternalValue());
        trackingId0.setValidFrom(null);
        trackingId0.setValidTo(null);
        trackingIds.add(trackingId0);
        QualifiedTrackingId trackingId1 = new QualifiedTrackingId();
        trackingId1.setMetadata(metadataOfQualifiedTrackingId);
        trackingId1.setProcessId(processId);
        trackingId1.setObservedProcessId(
                GTTUtils.UUIDUtils.generateNameBasedUUID("xri://sap.com/sapdoc:666666:Q8JCLNT774:DEL_NO:99"));
        trackingId1.setValidFrom(Instant.parse("1970-01-03T00:00:00Z"));
        trackingId1.setValidTo(Instant.parse("9999-12-31T00:00:00Z"));
        trackingIds.add(trackingId1);
        QualifiedTrackingId trackingId2 = new QualifiedTrackingId();
        trackingId2.setMetadata(metadataOfQualifiedTrackingId);
        trackingId2.setProcessId(processId);
        trackingId2.setObservedProcessId(
                GTTUtils.UUIDUtils.generateNameBasedUUID("xri://sap.com/sapdoc:666666:Q8JCLNT774:DEL_NO:100"));
        trackingId2.setValidFrom(Instant.parse("1970-01-03T00:00:00Z"));
        trackingId2.setValidTo(Instant.parse("9999-12-31T00:00:00Z"));
        trackingIds.add(trackingId2);
        existedTP.setTrackingIds(trackingIds);
        List<PlannedEvent> plannedEvents2 = new ArrayList<>();
        CurrentMetadataEntity metadataForPlannedEvent = getMetadata(MetadataConstants.CoreModelEntity.PLANNED_EVENT.getFullName());
        PlannedEvent pe21 = new PlannedEvent();
        pe21.setMetadata(metadataForPlannedEvent);
        pe21.setId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        pe21.setProcessId(existedTP.getId());
        pe21.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POConfirmedEvent");
        pe21.setLocationAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:Location:shippingPoint:4711");
        pe21.setEventMatchKey("10");
        pe21.setValue("mode", "a");
        pe21.setNextOverdueDetection(Instant.now());
        pe21.setOverdueDetectionCounter(0);
        pe21.setPlannedTechnicalTimestamp(Instant.parse("2018-07-09T12:00:00.213Z"));
        pe21.setPlannedTechTsEarliest(Instant.parse("2018-07-09T12:00:00.213Z"));
        pe21.setPlannedTechTsLatest(Instant.parse("2018-07-09T12:00:00.213Z"));
        pe21.setPlannedBusinessTimestamp(Instant.parse("2018-07-09T09:00:00.213Z"));
        pe21.setPlannedBizTsEarliest(Instant.parse("2018-07-09T09:00:00.213Z"));
        pe21.setPlannedBizTsLatest(Instant.parse("2018-07-09T09:00:00.213Z"));
        pe21.setPlannedBusinessTimeZone("CET");
        pe21.setPayloadSequence(1);
        pe21.setLastProcessEventDirectoryId(null);
        pe21.setEventStatus(EventStatus.REPORTED.name());
        plannedEvents2.add(pe21);
        PlannedEvent pe22 = new PlannedEvent();
        pe22.setMetadata(metadataForPlannedEvent);
        pe22.setId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        pe22.setProcessId(existedTP.getId());
        pe22.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POGoodsReceivedEvent");
        pe22.setEventMatchKey("20");
        pe22.setValue("mode", "b");
        pe22.setNextOverdueDetection(Instant.now());
        pe22.setOverdueDetectionCounter(0);
        pe22.setPlannedTechnicalTimestamp(Instant.parse("2018-07-08T12:00:00.213Z"));
        pe22.setPlannedTechTsEarliest(Instant.parse("2018-07-08T12:00:00.213Z"));
        pe22.setPlannedTechTsLatest(Instant.parse("2018-07-08T12:00:00.213Z"));
        pe22.setPlannedBusinessTimestamp(Instant.parse("2018-07-08T09:00:00.213Z"));
        pe22.setPlannedBizTsEarliest(Instant.parse("2018-07-08T09:00:00.213Z"));
        pe22.setPlannedBizTsLatest(Instant.parse("2018-07-08T09:00:00.213Z"));
        pe22.setPlannedBusinessTimeZone("CET");
        pe22.setPayloadSequence(2);
        pe22.setLastProcessEventDirectoryId(null);
        pe22.setEventStatus(EventStatus.PLANNED.name());
        plannedEvents2.add(pe22);
        existedTP.setPlannedEvents(plannedEvents2);
        List<ProcessEventDirectory> eventDirectories = new ArrayList<>();
        ProcessEventDirectory eventDirectory = new ProcessEventDirectory();
        eventDirectory.setMetadata(getMetadata(MetadataConstants.CoreModelEntity.PROCESS_EVENT_DIRECTORY.getFullName()));
        eventDirectory.setId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        eventDirectory.setProcessId(processId);
        eventDirectory.setPlannedEventId(pe21.getId());
        UUID eventId = GTTUtils.UUIDUtils.generateTimeBasedUUID();
        eventDirectory.setEventId(eventId);
        eventDirectory.setCorrelationType(CorrelationType.REPORTED.name());
        eventDirectories.add(eventDirectory);
        existedTP.setPEDs(eventDirectories);
        given(processManagement.getWithOnlyValidDPPStatus(Mockito.any(UUIDValue.class))).willReturn(existedTP);
        /*Event reportedEvent = new Event();
        reportedEvent.setActualBusinessTimestamp(Instant.parse("2018-07-09T09:00:00.213Z"));
        reportedEvent.setEventType(pe21.getEventType());
        given(eventManagement.getSingleEventById(Mockito.any())).willReturn(reportedEvent);*/
        MetadataEntityEvent eventConfig1 = new MetadataEntityEvent();
        eventConfig1.setTechnicalToleranceValue(null);
        eventConfig1.setBusinessToleranceValue(null);
        eventConfig1.setMatchLocation(true);
        MetadataEntityEvent eventConfig2 = new MetadataEntityEvent();
        eventConfig2.setTechnicalToleranceValue(null);
        eventConfig2.setBusinessToleranceValue(null);
        eventConfig2.setMatchLocation(false);
        given(metadataManagement.getEntityEvent(Mockito.anyString(), Mockito.contains("POConfirmedEvent"))).willReturn(eventConfig1);
        given(metadataManagement.getEntityEvent(Mockito.anyString(), Mockito.contains("POGoodsReceivedEvent"))).willReturn(eventConfig2);
        List<Event> messages = new ArrayList<>();
        messages.add(gttUpdatePlanEvent);
        service.processEvents(messages, "requestId", "writeServiceId");
        verify(eventManagement, times(1)).post(Mockito.anyList());
        ArgumentCaptor<TrackedProcess> argumentCaptorForTP = ArgumentCaptor.forClass(TrackedProcess.class);
        verify(processManagement, times(1)).update(argumentCaptorForTP.capture());
        TrackedProcess tpRst = argumentCaptorForTP.<List<String>>getValue();

        List<PlannedEvent> plannedEvents = tpRst.getPlannedEvents();
        assertThat(plannedEvents.size()).isEqualTo(1);
        assertThat(tpRst.getTrackingIds().size()).isEqualTo(3);
    }
}
