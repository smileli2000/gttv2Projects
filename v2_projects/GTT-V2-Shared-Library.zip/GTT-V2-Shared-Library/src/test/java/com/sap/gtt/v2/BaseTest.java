package com.sap.gtt.v2;

import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.sap.gtt.v2.configuration.GTTRestTemplate;
import com.sap.gtt.v2.log.TenantAwareLogService;
import com.sap.gtt.v2.tenant.GTTTenantSetting;
import com.sap.gtt.v2.tenant.TenantService;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = Dummy.class)
@ActiveProfiles("test")
public abstract class BaseTest {
	public static final String TEST_URL_REQUEST_TOKEN = "lbn-platform.authentication.sap.hana.ondemand.com/oauth/token";
	@MockBean
	private GTTRestTemplate restTemplate;
	@Value("${TEST_DATA_DUMMY_TOKEN}")
	private String dummyToken;
	
	@Mock
	protected TenantService tenantSettingService ;
	@InjectMocks
	@Autowired
	protected TenantAwareLogService logService;
	
	@Before
    public void setUp() {
    	MockitoAnnotations.initMocks(this);
    	
    	/*AccessContext accessContext = new AccessContext(LocalMockedServletRequestListener.TENANT_SUBACCOUNT_ID,
    			LocalMockedServletRequestListener.LOGON_NAME,
    			LocalMockedServletRequestListener.TENANT_SUBDOMAIN,
    			LocalMockedServletRequestListener.CLONE_SERVICE_INSTANCE_ID,
				LocaleContextHolder.getLocale(),
				null
				);
		AccessContextHolder.set(accessContext);*/
		
    	GTTTenantSetting tenantSetting1 = new GTTTenantSetting();
    	tenantSetting1.setEventToActionMaxTime(30);
    	tenantSetting1.setLogLevel(GTTTenantSetting.SETTING_PARAM_LOGGER_LOGLEVEL_INFO);
    	
    	when(tenantSettingService.get(ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(tenantSetting1);
		
    	ResponseEntity<Object> tokenResponse = new ResponseEntity<>(dummyToken,HttpStatus.OK);
    	when(restTemplate.exchange(ArgumentMatchers.contains(TEST_URL_REQUEST_TOKEN), ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(tokenResponse);
    	
    	
    }
	
}
