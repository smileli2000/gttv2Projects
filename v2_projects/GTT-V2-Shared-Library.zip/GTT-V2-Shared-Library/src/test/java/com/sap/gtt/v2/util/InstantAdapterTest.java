package com.sap.gtt.v2.util;

import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import org.assertj.core.api.Assertions;
import org.junit.Test;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.time.Instant;

public class InstantAdapterTest {

    @Test
    public void test() throws IOException {
        Instant now = Instant.now();
        InstantAdapter instantAdapter = new InstantAdapter();
        StringWriter sw = new StringWriter();
        JsonWriter out = new JsonWriter(sw);
        instantAdapter.write(out, now);

        String json = sw.toString();
        System.out.println(json);

        Instant instant = instantAdapter.read(new JsonReader(new StringReader(json)));

        Assertions.assertThat(instant).isEqualTo(now);
    }

}