package com.sap.gtt.v2.core.dao.tracking;

import com.sap.gtt.v2.Dummy;
import com.sap.gtt.v2.core.dao.metadata.*;
import com.sap.gtt.v2.core.domain.metadata.CurrentMetadataEntity;
import com.sap.gtt.v2.core.domain.trackedprocess.LifeCycleStatus;
import com.sap.gtt.v2.core.entity.trackedprocess.Event;
import com.sap.gtt.v2.core.entity.trackedprocess.PlannedEvent;
import com.sap.gtt.v2.core.entity.trackedprocess.Reference;
import com.sap.gtt.v2.core.entity.trackedprocess.TrackedProcess;
import com.sap.gtt.v2.core.management.metadata.DefaultMetadataManagement;
import com.sap.gtt.v2.core.management.metadata.IMetadataManagement;
import com.sap.gtt.v2.core.runtime.model.ListValue;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.IOException;
import java.time.Instant;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import static com.sap.gtt.v2.core.entity.trackedprocess.TrackedProcess.TRACKING_IDS;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = Dummy.class)
@ActiveProfiles("test")
public class DefaultCoreModelDataProcessDaoTest {

    @Autowired
    private DefaultCoreModelDataProcessDao coreModelDataProcessDao;

    @Autowired
    private IMetadataDao metadataDao;

    @Autowired
    private ISysTableDao sysTableDao;

    @Autowired
    private DefaultEventDao defaultEventDao;

    @Autowired
    private DefaultTrackedProcessDao trackedProcessDao;

    private void insertEvent(Event event) throws IOException {

        DefaultMetadataDaoTest test = new DefaultMetadataDaoTest();
        test.setDefaultMetadataDao((DefaultMetadataDao) metadataDao);
        test.insertMetadataProject();

        DefaultSysTableDaoTest test1 = new DefaultSysTableDaoTest();
        test1.setDefaultSysTableDao((DefaultSysTableDao)sysTableDao);
        test1.createTables();

        String entityName = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        String namespace = "com.sap.gtt.app.mim";

        IMetadataManagement metadataManagement = DefaultMetadataManagement.getInstance();
        CurrentMetadataEntity metadata = metadataManagement.findAllEntitiesRecursively(namespace, entityName);

        event.setId(UUID.randomUUID());
        event.setActualBusinessTimestamp(Instant.now());
        event.setActualBusinessTimeZone("");
        event.setAltKey("alt-key");
        event.setCloneInstanceId(UUID.randomUUID());
        event.setCreatedByUser("");
        event.setCreationDateTime(Instant.now());
        event.setActualTechnicalTimestamp(Instant.now());
        event.setEventReasonText("reason");
        event.setEventType("arrived");
        event.setLastChangedByUser("");
        event.setLastChangedDateTime(Instant.now());
        event.setLocationAltKey("location-alt-key");
        event.setLogicalSystem("001");
        event.setMessageSourceType("message-source-type");
        event.setScheme("scheme");
        event.setSenderPartyId(UUID.randomUUID().toString());
        event.setTrackingId("tracking-id");
        event.setSubaccountId(UUID.randomUUID());
        event.setTrackingIdType("tracking-id-type");
        event.setModelNamespace(namespace);
        event.setMetadata(metadata);

        PlannedEvent plannedEventForEvent = new PlannedEvent();
        plannedEventForEvent.setValue(PlannedEvent.EVENTID, UUID.randomUUID());
        plannedEventForEvent.setEventType("plannedEventForEvent");
        plannedEventForEvent.setLocationAltKey("location-alt-key");
        plannedEventForEvent.setPlannedBizTsEarliest(Instant.now());
        plannedEventForEvent.setPlannedBizTsLatest(Instant.now());
        plannedEventForEvent.setPlannedBusinessTimestamp(Instant.now());
        plannedEventForEvent.setPlannedBusinessTimeZone("");
        plannedEventForEvent.setPlannedTechnicalTimestamp(Instant.now());
        plannedEventForEvent.setPlannedTechTsEarliest(Instant.now());
        plannedEventForEvent.setPlannedTechTsLatest(Instant.now());

        event.setPlannedEvents(Arrays.asList(plannedEventForEvent));

        Reference reference = new Reference();
        CurrentMetadataEntity metadata2 = new CurrentMetadataEntity();
        reference.setAction("ADD");
        reference.setAltKey("alt-key");
        reference.setEventId(event.getIdAsInternalValue());
        reference.setReferenceType("ref-type");
        reference.setValidFrom(Instant.now());
        reference.setValidTo(Instant.now());

        defaultEventDao.insert(event);

        event.setId(UUID.randomUUID());
        event.setAltKey("xri://sap.com/id:LBN#10000034:Q8JCLNT774:FreightOrder:0001");
        defaultEventDao.insert(Arrays.asList(event));
        defaultEventDao.update(event);
    }

    private void insertTP(TrackedProcess tp) throws IOException {
        DefaultMetadataDaoTest test = new DefaultMetadataDaoTest();
        test.setDefaultMetadataDao((DefaultMetadataDao) metadataDao);
        test.insertMetadataProject();

        DefaultSysTableDaoTest test1 = new DefaultSysTableDaoTest();
        test1.setDefaultSysTableDao((DefaultSysTableDao)sysTableDao);
        test1.createTables();

        String entityType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        String entityName = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        String namespace = "com.sap.gtt.app.mim";

        IMetadataManagement metadataManagement = DefaultMetadataManagement.getInstance();
        CurrentMetadataEntity metadata = metadataManagement.findAllEntitiesRecursively(namespace, entityName);

        tp.setId(UUID.randomUUID());
        tp.setTrackedProcessType(entityType);
        tp.setTrackingId("my-tracking-id");
        tp.setPartyId("666666");
        tp.setScheme("my-scheme");
        tp.setAltKey("my-alt-key");
        tp.setLifeCycleStatus(LifeCycleStatus.END_OF_BUSINESS);
        tp.setTrackingIdType("my-tracking-id-type");
        tp.setLogicalSystem("a-system");

        tp.setValue("procurementOrderNO", "12345");
        tp.setValue("procurementOrderItemQty", 88.8);
        tp.setMetadata(metadata);
        tp.setVersion(0);
        tp.setLifeCycleStatus(LifeCycleStatus.BUSINESS_ACTIVE);
        System.out.println(LifeCycleStatus.BUSINESS_ACTIVE.toString());
        ListValue nullList = null;
        tp.setValue(TRACKING_IDS, nullList);
        trackedProcessDao.insert(tp);
    }

    @Test
    public void testDeleteCoreModeData() throws IOException {
        String namespace = "com.sap.gtt.app.mim";
        Event event = new Event();
        TrackedProcess tp = new TrackedProcess();
        //insertEvent(event);
        insertTP(tp);
        //add event assert after model namespace added
        List<TrackedProcess> retrievedList = trackedProcessDao.findAllByNamespace(namespace);
       // Assertions.assertThat(retrievedList).size().isEqualTo(1);
        coreModelDataProcessDao.deleteAllCoreModelData(namespace);
        List<TrackedProcess> retrievedList1 = trackedProcessDao.findAllByNamespace(namespace);
        Assertions.assertThat(retrievedList1).size().isEqualTo(0);
    }

}
