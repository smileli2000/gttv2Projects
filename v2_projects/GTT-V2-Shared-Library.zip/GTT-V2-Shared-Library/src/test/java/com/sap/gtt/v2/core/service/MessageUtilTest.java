package com.sap.gtt.v2.core.service;

import com.sap.gtt.v2.core.domain.metadata.CurrentMetadataEntity;
import com.sap.gtt.v2.core.domain.metadata.MetadataEntity;
import com.sap.gtt.v2.core.domain.trackedprocess.EventStatus;
import com.sap.gtt.v2.core.domain.trackedprocess.Operator;
import com.sap.gtt.v2.core.entity.trackedprocess.PlannedEvent;
import com.sap.gtt.v2.core.entity.trackedprocess.TrackedProcess;
import com.sap.gtt.v2.core.management.metadata.CsnParser;
import com.sap.gtt.v2.util.GTTUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.tuple.Triple;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import java.io.IOException;
import java.nio.charset.Charset;
import java.time.Instant;
import java.util.*;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(MockitoJUnitRunner.class)
public class MessageUtilTest {
    private String derivedCsnFile = "derived_csn.json";

    @Test
    public void testMatchPlannedEvent() {
        List<PlannedEvent> plannedEvents = new ArrayList<>();
        PlannedEvent pe1 = new PlannedEvent();
        pe1.setEventType("eventtype.a");
        pe1.setEventMatchKey("1");
        pe1.setLocationAltKey("location.a");
        pe1.setValue("cnt", 1);
        plannedEvents.add(pe1);
        PlannedEvent pe2 = new PlannedEvent();
        pe2.setEventType("eventtype.b");
        pe2.setEventMatchKey("1");
        pe2.setLocationAltKey("location.a");
        pe2.setValue("cnt", 2);
        plannedEvents.add(pe2);
        List<Triple<Object, String, String>> list = new ArrayList<>();
        Triple<Object, String, String> triple1 = Triple.of("eventtype.a", Operator.EQUAL.getValue(), "eventType");
        list.add(triple1);
        Triple<Object, String, String> triple2 = Triple.of("1", Operator.EQUAL.getValue(), "eventMatchKey");
        list.add(triple2);
        Triple<Object, String, String> triple3 = Triple.of("location.a", Operator.EQUAL.getValue(), "locationAltKey");
        list.add(triple3);
        Triple<Object, String, String> triple4 = Triple.of(1, Operator.EQUAL.getValue(), "cnt");
        list.add(triple4);
        PlannedEvent matchedPE = MessageUtil.matchPlannedEvent(plannedEvents, list);
        assertThat(matchedPE).isNotNull();

        Triple<Object, String, String> triple = Triple.of(2, Operator.EQUAL.getValue(), "cnt");
        list.add(triple);
        list.remove(3);
        list.add(triple);
        matchedPE = MessageUtil.matchPlannedEvent(plannedEvents, list);
        assertThat(matchedPE).isNull();
    }

/*    @Test
    public void testMatchPlannedEventWhenLocationMatchedFalse() {
        List<PlannedEvent> plannedEvents = new ArrayList<>();
        PlannedEvent pe1 = new PlannedEvent();
        pe1.setEventType("eventtype.a");
        pe1.setEventMatchKey("1");
        pe1.setLocationAltKey("location.a");
        plannedEvents.add(pe1);
        PlannedEvent pe2 = new PlannedEvent();
        pe2.setEventType("eventtype.b");
        pe2.setEventMatchKey("1");
        pe2.setLocationAltKey("location.a");
        plannedEvents.add(pe2);
        PlannedEvent matchedPE = MessageUtil.matchPlannedEvent(plannedEvents, "eventtype.a", "1", "location.a", false);
        assertThat(matchedPE).isNotNull();

        matchedPE = MessageUtil.matchPlannedEvent(plannedEvents, "eventtype.a", "1", "location.b", false);
        assertThat(matchedPE).isNotNull();

        matchedPE = MessageUtil.matchPlannedEvent(plannedEvents, "eventtype.a", "2", "location.b", false);
        assertThat(matchedPE).isNull();
    }*/

    @Test
    public void testMatchPlannedEventWhenPlannedEventsNull() {
        List<Triple<Object, String, String>> list = new ArrayList<>();
        Triple<Object, String, String> triple1 = Triple.of("eventtype.a", Operator.EQUAL.getValue(), "eventType");
        list.add(triple1);
        PlannedEvent matchedPE = MessageUtil.matchPlannedEvent(null, list);
        assertThat(matchedPE).isNull();
    }

    @Test
    public void testMatchPlannedEventByPlannedEventId() {
        List<PlannedEvent> plannedEvents = new ArrayList<>();
        PlannedEvent pe1 = new PlannedEvent();
        pe1.setId(UUID.randomUUID());
        pe1.setEventType("eventtype.a");
        pe1.setEventMatchKey("1");
        pe1.setLocationAltKey("location.a");
        plannedEvents.add(pe1);
        PlannedEvent pe2 = new PlannedEvent();
        pe2.setId(UUID.randomUUID());
        pe2.setEventType("eventtype.b");
        pe2.setEventMatchKey("1");
        pe2.setLocationAltKey("location.a");
        plannedEvents.add(pe2);
        PlannedEvent matchedPE = MessageUtil.matchPlannedEvent(plannedEvents, pe1.getId());
        assertThat(matchedPE).isNotNull();
        assertThat(matchedPE.getId()).isEqualTo(pe1.getId());
    }

    @Test
    public void testFillMetadata() throws IOException {
        String derivedCsn = IOUtils.toString(getClass().getClassLoader()
                .getResourceAsStream(derivedCsnFile), Charset.defaultCharset());
        Map<String, MetadataEntity> entityMap = CsnParser.parseToEntityMap(derivedCsn);
        CurrentMetadataEntity currentMetadataEntity = new CurrentMetadataEntity();
        currentMetadataEntity.setCurrentEntityName("com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess");
        currentMetadataEntity.setAllRelatedEntityMap(entityMap);

        TrackedProcess tp = new TrackedProcess();
        String trackedProcessType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        tp.setMetadata(currentMetadataEntity);
        tp.setTrackedProcessType(trackedProcessType);
        tp.setAltKey("xri://sap.com/sapdoc:666666:Q8JCLNT774:ProcurementOrderItem:1");
        tp.setId(GTTUtils.UUIDUtils.generateNameBasedUUID(tp.getAltKey()));
        tp.setScheme("xri://sap.com/sapdoc");
        tp.setPartyId("666666");
        tp.setLogicalSystem("Q8JCLNT774");
        tp.setTrackingIdType("DEL_NO");
        tp.setTrackingId("1211031264");
        tp.setSubaccountId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        tp.setCloneInstanceId(null);
        tp.setValue("procurementOrderNO", "1211031264");
        tp.setValue("itemNO", "2345");
        tp.setValue("scheduleLine", "0001");
        //SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        tp.setValue("supplierId", "supplier");
        tp.setValue("materialId", "material");
        tp.setValue("receivingLocationId", "location");
        tp.setValue("plannedDeliveryDate", Instant.parse("2018-07-09T09:00:00.213Z"));
        tp.setValue("earlistETA", Instant.parse("2018-07-09T09:00:00.213Z"));
        tp.setValue("procurementOrderItemQty", 3.0);
        tp.setValue("goodsReceivedQty", 2.0);
        tp.setValue("procurementOrderItemUOM", "M3");
        tp.setValue("goodsReceivedUOM", "KG");
        tp.setCreationDateTime(Instant.parse("2018-06-09T00:00:00Z"));
        tp.setCreatedByUser("aaa");
        
        List<PlannedEvent> plannedEvents = new ArrayList<>();
        PlannedEvent pe1 = new PlannedEvent();
        pe1.setId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        pe1.setProcessId(tp.getId());
        pe1.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POConfirmedEvent");
        pe1.setEventMatchKey("10");
        pe1.setNextOverdueDetection(Instant.now());
        pe1.setOverdueDetectionCounter(0);
        pe1.setPlannedTechnicalTimestamp(Instant.parse("2018-07-09T12:00:00.213Z"));
        pe1.setPlannedTechTsEarliest(Instant.parse("2018-07-09T12:00:00.213Z"));
        pe1.setPlannedTechTsLatest(Instant.parse("2018-07-09T12:00:00.213Z"));
        pe1.setPlannedBusinessTimestamp(Instant.parse("2018-07-09T09:00:00.213Z"));
        pe1.setPlannedBizTsEarliest(Instant.parse("2018-07-09T09:00:00.213Z"));
        pe1.setPlannedBizTsLatest(Instant.parse("2018-07-09T09:00:00.213Z"));
        pe1.setPlannedBusinessTimeZone("CET");
        pe1.setPayloadSequence(1);
        pe1.setLastProcessEventDirectoryId(null);
        pe1.setEventStatus(EventStatus.REPORTED.name());
        plannedEvents.add(pe1);
        tp.setPlannedEvents(plannedEvents);

        MessageUtil.fillMetadata(tp);
        assertThat(pe1.getMetadata()).isNotNull();
        
    }

}
