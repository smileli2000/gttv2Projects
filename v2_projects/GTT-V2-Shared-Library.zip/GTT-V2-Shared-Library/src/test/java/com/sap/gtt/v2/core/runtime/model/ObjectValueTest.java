package com.sap.gtt.v2.core.runtime.model;

import com.sap.gtt.v2.core.domain.metadata.*;
import com.sap.gtt.v2.core.entity.trackedprocess.Event;
import com.sap.gtt.v2.core.entity.trackedprocess.TrackedProcess;
import com.sap.gtt.v2.exception.PropertyValidationException;
import org.assertj.core.api.Assertions;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.time.Instant;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import static junit.framework.TestCase.assertNull;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;


public class ObjectValueTest {

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void testMetadataValidation() {
        CurrentMetadataEntity currentMetadataEntity = new CurrentMetadataEntity();
        currentMetadataEntity.setCurrentEntityName("order");

        MetadataEntity metadataEntity = new MetadataEntity();
        MetadataEntityElement elementComposition = new MetadataEntityElement();
        elementComposition.setType(MetadataConstants.CdsDataType.CDS_COMPOSITION);
        elementComposition.setName("items");
        FieldContent fieldContent = new FieldContent();
        fieldContent.setMinItems(0);
        fieldContent.setMaxItems(100);
        elementComposition.setFieldContent(fieldContent);
        metadataEntity.addElement(elementComposition);

        MetadataEntityElement elementInteger = new MetadataEntityElement();
        elementInteger.setType(MetadataConstants.CdsDataType.CDS_INTEGER);
        elementInteger.setName("quantity");
        fieldContent = new FieldContent();
        fieldContent.setMaximum("100");
        fieldContent.setMinimum("1");
        fieldContent.setMultipleOf("2");
        elementInteger.setFieldContent(fieldContent);
        metadataEntity.addElement(elementInteger);

        MetadataEntityElement elementDecimal = new MetadataEntityElement();
        elementDecimal.setType(MetadataConstants.CdsDataType.CDS_INTEGER);
        elementDecimal.setName("price");
        fieldContent = new FieldContent();
        fieldContent.setMaximum("100");
        fieldContent.setMinimum("1");
        fieldContent.setMultipleOf("2");
        elementDecimal.setFieldContent(fieldContent);
        metadataEntity.addElement(elementDecimal);

        MetadataEntityElement elementString = new MetadataEntityElement();
        elementString.setType(MetadataConstants.CdsDataType.CDS_STRING);
        elementString.setName("description");
        fieldContent = new FieldContent();
        fieldContent.setMinLength(1);
        fieldContent.setPattern("[a-z]*");
        elementString.setFieldContent(fieldContent);
        elementString.setLength(100);
        metadataEntity.addElement(elementString);

        MetadataEntityElement elementTimestamp = new MetadataEntityElement();
        elementTimestamp.setType(MetadataConstants.CdsDataType.CDS_TIMESTAMP);
        elementTimestamp.setName("createdTime");
        metadataEntity.addElement(elementTimestamp);

        MetadataEntityElement elementDate = new MetadataEntityElement();
        elementDate.setType(MetadataConstants.CdsDataType.CDS_DATE);
        elementDate.setName("createdDate");
        metadataEntity.addElement(elementDate);

        Map<String, MetadataEntity> map = new HashMap<>();
        map.put("order", metadataEntity);
        currentMetadataEntity.setAllRelatedEntityMap(map);

        ObjectValue obj = ObjectValue.valueOfEmpty();
        obj.setMetadata(currentMetadataEntity);
        obj.setValue("description", (Object)null);
        obj.setValue("quantity", (Object)null);
        obj.setValue("price", (Object)null);
        obj.setValue("items", (Object)null);
        obj.setValue("createdTime", (Object)null);
        obj.setValue("createdDate", (Object)null);
        Assertions.assertThat(obj.getValueAsInteger("quantity"))
                .isNull();
        Assertions.assertThat(obj.getValueAsDecimal("price"))
                .isNull();
        Assertions.assertThat(obj.getValueAsString("description"))
                .isNull();
        Assertions.assertThat(obj.getValueAsList("items")).isNull();
        Assertions.assertThat(obj.getValueAsTimeStamp("createdTime"))
                .isNull();
        Assertions.assertThat(obj.getValueAsDate("createdDate")).isNull();
//        Assertions.assertThat(obj.getValueAsBoolean("no-such-property")).isNull();
//        Assertions.assertThat(obj.getValueAsUUID("no-such-property")).isNull();
//        Assertions.assertThat(obj.getValueAsObject("no-such-property")).isNull();

        obj.setValue("description", "abcd");
        obj.setValue("quantity", 90);
        obj.setValue("price", 88);
        obj.setValue("items", Arrays.asList());
        obj.setValue("createdTime", Instant.now());
        obj.setValue("createdDate", LocalDate.now());

        Assertions.assertThatThrownBy(
                () -> obj.setValue("description", 1)
        ).isInstanceOf(PropertyValidationException.class);

        Assertions.assertThatThrownBy(
                () -> obj.setValue("quantity", "1")
        ).isInstanceOf(PropertyValidationException.class);

        Assertions.assertThatThrownBy(
                () -> obj.setValue("price", 1)
        ).isInstanceOf(PropertyValidationException.class);

        Assertions.assertThatThrownBy(
                () -> obj.setValue("items", 1)
        ).isInstanceOf(PropertyValidationException.class);

        Assertions.assertThatThrownBy(
                () -> obj.setValue("createdTime", 1)
        ).isInstanceOf(PropertyValidationException.class);

        Assertions.assertThatThrownBy(
                () -> obj.setValue("createdDate", 1)
        ).isInstanceOf(PropertyValidationException.class);

        Assertions.assertThat(obj.isCsnPrimitive()).isFalse();
        Assertions.assertThat(obj.isCollection()).isFalse();
        Assertions.assertThat(BooleanValue.TRUE.isCsnPrimitive()).isTrue();
        Assertions.assertThat(BooleanValue.TRUE.isCollection()).isFalse();
        Assertions.assertThat(IntegerValue.valueOf(1).isCsnPrimitive()).isTrue();
        Assertions.assertThat(IntegerValue.valueOf(1).isCollection()).isFalse();
        Assertions.assertThat(DecimalValue.valueOf(1).isCsnPrimitive()).isTrue();
        Assertions.assertThat(DecimalValue.valueOf(1).isCollection()).isFalse();
        Assertions.assertThat(StringValue.valueOf("").isCsnPrimitive()).isTrue();
        Assertions.assertThat(StringValue.valueOf("").isCollection()).isFalse();

    }

    @Test
    public void testSetValueBasics() {
        ObjectValue tp = new TrackedProcess();
        tp.setValue("my_first_property", "good");
        try {
            IPropertyValue ret = tp.getValue("not-exist");
            System.out.println(ret);
        } catch(Exception e) {
            assertTrue(e instanceof PropertyValidationException);
        }

        Object obj = null;
        tp.setValue("aaa", obj);
        IPropertyValue ret = tp.getValue("aaa");
        System.out.println(ret instanceof NullValue);

        assertEquals("good", tp.getValueAsString("my_first_property"));

        ObjectValue event = new Event();
        event.setValue("my_first_property", "good");
        assertEquals("good", event.getValueAsString("my_first_property"));

        tp.setValue("eventIds[0]", 0);
        tp.setValue("eventIds[1]", 1);
       // tp.setValue("eventIds[2]", 1.8f);
        tp.setValue("eventIds[3]", 2.8d);
        tp.setValue("eventIds[4]", "good");
        tp.setValue("eventIds[5]", UUID.randomUUID());

        try {
            Integer i = null;
            tp.setValue("aaa", i);
            Integer j = tp.getValueAsInteger("aaa");
            assertNull(j);
        }catch(Exception e) {
            assertTrue(e instanceof NullPointerException);
        }
    }
}