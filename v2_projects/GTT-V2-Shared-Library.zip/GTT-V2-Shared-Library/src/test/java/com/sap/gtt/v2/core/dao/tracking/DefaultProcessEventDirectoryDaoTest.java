package com.sap.gtt.v2.core.dao.tracking;

import com.sap.gtt.v2.Dummy;
import com.sap.gtt.v2.core.dao.metadata.*;
import com.sap.gtt.v2.core.domain.metadata.CurrentMetadataEntity;
import com.sap.gtt.v2.core.domain.metadata.MetadataConstants;
import com.sap.gtt.v2.core.domain.trackedprocess.CorrelationType;
import com.sap.gtt.v2.core.entity.trackedprocess.ProcessEventDirectory;
import com.sap.gtt.v2.core.entity.trackedprocess.QualifiedTrackingId;
import com.sap.gtt.v2.core.management.metadata.DefaultMetadataManagement;
import com.sap.gtt.v2.core.management.metadata.IMetadataManagement;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.IOException;
import java.time.Instant;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = Dummy.class)
@ActiveProfiles("test")
public class DefaultProcessEventDirectoryDaoTest {

    @Autowired
    private IProcessEventDirectoryDao pedDao;

    @Autowired
    private IMetadataDao metadataDao;

    @Autowired
    private ISysTableDao sysTableDao;

    @Test
    public void test() throws IOException {
        pedDao = DefaultProcessEventDirectoryDao.getInstance();

        DefaultMetadataDaoTest test = new DefaultMetadataDaoTest();
        test.setDefaultMetadataDao((DefaultMetadataDao) metadataDao);
        test.insertMetadataProject();

        DefaultSysTableDaoTest test1 = new DefaultSysTableDaoTest();
        test1.setDefaultSysTableDao((DefaultSysTableDao) sysTableDao);
        test1.createTables();

        String entityName = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemEventForWrite";
        String namespace = "com.sap.gtt.app.mim";

        IMetadataManagement metadataManagement = DefaultMetadataManagement.getInstance();
        CurrentMetadataEntity metadata = metadataManagement.findAllEntitiesRecursively(namespace, entityName);
        metadata.setCurrentEntityName(MetadataConstants.CoreModelEntity.PROCESS_EVENT_DIRECTORY.getFullName());

        ProcessEventDirectory ped = new ProcessEventDirectory();
        ped.setMetadata(metadata);
        UUID pedId = UUID.randomUUID();
        ped.setId(pedId);
        UUID processId = UUID.randomUUID();
        ped.setProcessId(processId);
        ped.setEventId(UUID.randomUUID());
        ped.setPlannedEventId(null);
        ped.setCorrelationType(CorrelationType.UNPLANNED.name());

        pedDao.insert(Arrays.asList(ped));
        ProcessEventDirectory pedRst = pedDao.findOne(metadata, pedId);
        assertThat(pedRst).isNotNull();

        ped.setCorrelationType(CorrelationType.UNPLANNED_PROCESS_CREATION_UPDATE.name());
        pedDao.update(ped);

        pedDao.deleteByProcessId(processId);

        ProcessEventDirectory ped2 = new ProcessEventDirectory();
        ped2.setMetadata(metadata);
        ped2.setId(UUID.randomUUID());
        ped2.setProcessId(UUID.randomUUID());
        ped2.setEventId(UUID.randomUUID());
        UUID plannedEventId = UUID.randomUUID();
        ped2.setPlannedEventId(plannedEventId);
        ped2.setCorrelationType(CorrelationType.REPORTED.name());

        pedDao.insert(ped2);
        pedDao.deleteByPlannedEventId(plannedEventId);
    }
}