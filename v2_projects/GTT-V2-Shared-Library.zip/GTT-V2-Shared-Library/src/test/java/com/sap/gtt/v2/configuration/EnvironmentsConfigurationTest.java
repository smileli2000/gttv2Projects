/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.gtt.v2.configuration;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Test;

import com.sap.gtt.v2.configuration.EnvironmentsConfiguration.VcapServiceParser.SaasRegistryServiceInstance.Dependency;
import com.sap.gtt.v2.configuration.EnvironmentsConfiguration.VcapServiceParser.SaasRegistryServiceInstance.ReturnOfGetSubscriptions;
import com.sap.gtt.v2.configuration.EnvironmentsConfiguration.VcapServiceParser.SaasRegistryServiceInstance.Subscription;

/**
 *
 * @author I326335
 */
public class EnvironmentsConfigurationTest {
    
    public EnvironmentsConfigurationTest() {
    }

    @Test
    public void testSubscrition() {
        String subscriptionStr = "{\"subscriptions\":[{\"appName\":\"fef399af-a490-41fc-bc7b-d69fcc79c441\",\"consumerTenantId\":\"86cbb49a-0deb-4c74-9c85-9a85908569f1\",\"state\":\"SUBSCRIBED\",\"serviceInstanceId\":\"e2a716c2-d622-4811-a603-d09ed283d1f7\",\"dependencies\":[{\"xsappname\":\"clone602d3bcebaed4c758f2509919b775c48!b5700|destination-xsappname!b433\",\"appName\":\"destination\",\"dependencies\":[]}]},{\"appName\":\"fef399af-a490-41fc-bc7b-d69fcc79c441\",\"consumerTenantId\":\"86cbb49a-0deb-4c74-9c85-9a85908569f1\",\"state\":\"SUBSCRIBE_FAILED\",\"error\":\"subscribe failed. Parameters: rootSubscription: RootSubscription : { xsuaaAppId: lbn-gtt-core_sandbox!b5700, consumerTenant: 86cbb49a-0deb-4c74-9c85-9a85908569f1, subdomain: lbn-gtt }. Error description: Timestamp: Fri Oct 11 10:19:40 UTC 2019, correlationId: b0b36420-2980-47d8-51a8-e2a5b013fd93, Details: Error build subscription tree : Error parse get dependencies of application with appName: fef399af-a490-41fc-bc7b-d69fcc79c441. Error: Failed to call callback url GET: https://gtt-core-service-manager-sandbox.cfapps.sap.hana.ondemand.com/callback/v1.0/dependencies?tenantId=86cbb49a-0deb-4c74-9c85-9a85908569f1, for appName: fef399af-a490-41fc-bc7b-d69fcc79c441 and consumer tenant: 86cbb49a-0deb-4c74-9c85-9a85908569f1. Reason: Insufficient scope for this resourc\",\"serviceInstanceId\":\"b7da4101-240b-438c-8528-855bf0a1f151\",\"dependencies\":[]}]}";
        ReturnOfGetSubscriptions subscriptions = ReturnOfGetSubscriptions.fromJson(subscriptionStr);
        assertNotNull(subscriptions);
        Subscription subscription = subscriptions.getSubscriptions().get(0);
        assertEquals("fef399af-a490-41fc-bc7b-d69fcc79c441", subscription.getAppName());
        assertEquals("86cbb49a-0deb-4c74-9c85-9a85908569f1", subscription.getConsumerTenantId());
        assertEquals("SUBSCRIBED", subscription.getState());
        assertEquals("e2a716c2-d622-4811-a603-d09ed283d1f7", subscription.getServiceInstanceId());
        assertNotNull(subscription.getDependencies());
        Dependency dependency = subscription.getDependencies().get(0);
        assertEquals("clone602d3bcebaed4c758f2509919b775c48!b5700|destination-xsappname!b433", dependency.getXsappname());
        assertEquals("destination", dependency.getAppName());
        assertNotNull(dependency.getDependencies());
        
    }
    
}
