package com.sap.gtt.v2.core.dao.execution;

import com.sap.gtt.v2.BaseTest;
import com.sap.gtt.v2.Dummy;
import com.sap.gtt.v2.core.entity.execution.RequestTrackingId;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = Dummy.class)
@ActiveProfiles("test")
public class DefaultRequestTrackingIdDaoTest extends BaseTest {
    private DefaultRequestTrackingIdDao trackingIdDao;

    @Before
    public void setUp() {
        super.setUp();
        trackingIdDao = DefaultRequestTrackingIdDao.getInstance();
    }

    @Test
    public void testInsert() {
        List<RequestTrackingId> trackingIds = new ArrayList<>();
        String requestId = "requestId";
        trackingIds.add(new RequestTrackingId(UUID.randomUUID().toString(), requestId, "a"));
        trackingIds.add(new RequestTrackingId(UUID.randomUUID().toString(), requestId, "b"));
        trackingIdDao.insertRequestTrackingIds(trackingIds);
        List<RequestTrackingId> trackingIdsRst = trackingIdDao.queryRequestTrackingIds(requestId);
        assertThat(trackingIdsRst.size()).isEqualTo(trackingIds.size());
    }
}
