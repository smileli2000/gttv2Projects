package com.sap.gtt.v2.core.dao.execution;

import com.sap.gtt.v2.BaseTest;
import com.sap.gtt.v2.Dummy;
import com.sap.gtt.v2.core.entity.execution.ExecutionPhase;
import com.sap.gtt.v2.core.domain.execution.ExecutionStatus;
import com.sap.gtt.v2.core.domain.execution.Phase;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = Dummy.class)
@ActiveProfiles("test")
public class DefaultExecutionPhaseDaoTest extends BaseTest {
    private DefaultExecutionPhaseDao executionPhaseDao;

    @Before
    public void setUp() {
        super.setUp();
        executionPhaseDao = DefaultExecutionPhaseDao.getInstance();
    }

    @Test
    public void testQueryExecutionPhaseById() {
        String id = "phaseId";
        String executionId = "executionId";
        ExecutionPhase executionPhase = executionPhaseDao.queryExecutionPhase(id);
        if (executionPhase == null) {
            insertExecutionPhase(id, UUID.randomUUID().toString());
            executionPhase = executionPhaseDao.queryExecutionPhase(id);
        }
        assertThat(executionPhase.getId()).isEqualTo(id);
        executionPhaseDao.updateExecutionPhaseStatus(id, ExecutionStatus.PENDING.name());
        executionPhase = executionPhaseDao.queryExecutionPhase(id);
        assertThat(executionPhase.getStatus()).isEqualTo(ExecutionStatus.PENDING.name());
    }

    @Test
    public void testQueryExecutionPhaseByExecutionIdAndPhaseName() {
        String id = "phaseId";
        String executionId = "executionId";
        ExecutionPhase executionPhase = executionPhaseDao.queryExecutionPhase(executionId, Phase.EVENT2ACTION.name());
        if (executionPhase == null) {
            insertExecutionPhase(id, executionId);
            executionPhase = executionPhaseDao.queryExecutionPhase(executionId, Phase.EVENT2ACTION.name());
        }
        assertThat(executionPhase.getId()).isEqualTo(id);
    }

    @Test
    public void testQueryExecutionPhases() {
        String id = "phaseId";
        String executionId = "executionId";
        List<ExecutionPhase> phases = executionPhaseDao.queryExecutionPhases(executionId);
        if (phases.isEmpty()) {
            insertExecutionPhase(id, executionId);
            phases = executionPhaseDao.queryExecutionPhases(executionId);
        }
        assertThat(phases.size()).isEqualTo(1);
    }

    private void insertExecutionPhase(String id, String executionId) {
        String phase = Phase.EVENT2ACTION.name();
        String status = ExecutionStatus.ERROR.name();
        ExecutionPhase executionPhase = new ExecutionPhase(id, executionId, phase, status);
        executionPhaseDao.insertExecutionPhase(executionPhase);
    }
}
