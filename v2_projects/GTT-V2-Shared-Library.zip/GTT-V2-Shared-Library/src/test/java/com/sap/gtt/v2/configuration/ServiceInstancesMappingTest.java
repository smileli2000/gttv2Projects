/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 
package com.sap.gtt.v2.configuration;

import com.sap.gtt.v2.configuration.EnvironmentsConfiguration.VcapServiceParser.SaasRegistryServiceInstance;
import com.sap.gtt.v2.configuration.EnvironmentsConfiguration.VcapServiceParser.SaasSubscriptionServiceInstance;
import com.sap.gtt.v2.tenant.TenantService;
import java.util.HashMap;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;
import org.mockito.junit.MockitoJUnitRunner;

*//**
 *
 * @author I326335
 *//*
@RunWith(MockitoJUnitRunner.class)
public class ServiceInstancesMappingTest {
    @InjectMocks
    private ServiceInstancesMapping serviceInstancesMapping=spy(new ServiceInstancesMapping());
    @Mock
	private EnvironmentsConfiguration.VcapServiceParser vcapServiceParser;
    @Mock
	private TenantService tenantService;
    
    public ServiceInstancesMappingTest() {
    }

    *//**
     * Test of getSaasRegistryServiceInstance method, of class ServiceInstancesMapping.
     *//*
    @Test
    public void testGetSaasRegistryServiceInstance() throws Exception {
        System.out.println("getSaasRegistryServiceInstance");
        SaasRegistryServiceInstance expResult = mock(SaasRegistryServiceInstance.class);
        when(serviceInstancesMapping.getSaasRegistryServiceInstanceMap()).thenReturn(new HashMap<String, SaasRegistryServiceInstance>(){{put("aa", expResult);}});
        SaasRegistryServiceInstance result = serviceInstancesMapping.getServiceSaasRegistryServiceInstance();
        assertEquals(expResult, result);
    }
    
    @Test(expected = InternalError.class)
    public void testGetSaasRegistryServiceInstanceWithoutInstances() throws Exception {
        System.out.println("getSaasRegistryServiceInstance");
        when(serviceInstancesMapping.getSaasRegistryServiceInstanceMap()).thenReturn(new HashMap<String, SaasRegistryServiceInstance>(){{}});
        serviceInstancesMapping.getServiceSaasRegistryServiceInstance();
    }
    
    @Test(expected = InternalError.class)
    public void testGetSaasRegistryServiceInstanceWithMultiInstances() throws Exception {
        System.out.println("getSaasRegistryServiceInstance");
        when(serviceInstancesMapping.getSaasRegistryServiceInstanceMap()).thenReturn(new HashMap<String, SaasRegistryServiceInstance>(){{put("aa", mock(SaasRegistryServiceInstance.class));put("aa1", mock(SaasRegistryServiceInstance.class));}});
        serviceInstancesMapping.getServiceSaasRegistryServiceInstance();
    }

    *//**
     * Test of getSaasSubscriptionServiceInstance method, of class ServiceInstancesMapping.
     *//*
    @Test
    public void testGetSaasSubscriptionServiceInstance() throws Exception {
        System.out.println("getSaasSubscriptionServiceInstance");
        SaasSubscriptionServiceInstance expResult = mock(SaasSubscriptionServiceInstance.class);
        when(serviceInstancesMapping.getSaasSubscriptionServiceInstanceMap()).thenReturn(new HashMap<String, SaasSubscriptionServiceInstance>(){{put("aa", expResult);}});
        SaasSubscriptionServiceInstance result = serviceInstancesMapping.getSaasSubscriptionServiceInstance();
        assertEquals(expResult, result);
    }
    
    @Test(expected = InternalError.class)
    public void testGetSaasSubscriptionServiceInstanceWithoutMultiInstances() throws Exception {
        System.out.println("getSaasSubscriptionServiceInstance");
        SaasSubscriptionServiceInstance expResult = mock(SaasSubscriptionServiceInstance.class);
        when(serviceInstancesMapping.getSaasSubscriptionServiceInstanceMap()).thenReturn(new HashMap<String, SaasSubscriptionServiceInstance>(){{}});
        SaasSubscriptionServiceInstance result = serviceInstancesMapping.getSaasSubscriptionServiceInstance();
        assertEquals(expResult, result);
    }
    
    @Test(expected = InternalError.class)
    public void testGetSaasSubscriptionServiceInstanceWithMultiInstances() throws Exception {
        System.out.println("getSaasSubscriptionServiceInstance");
        SaasSubscriptionServiceInstance expResult = mock(SaasSubscriptionServiceInstance.class);
        when(serviceInstancesMapping.getSaasSubscriptionServiceInstanceMap()).thenReturn(new HashMap<String, SaasSubscriptionServiceInstance>(){{put("aa", expResult);put("aa1", expResult);}});
        SaasSubscriptionServiceInstance result = serviceInstancesMapping.getSaasSubscriptionServiceInstance();
        assertEquals(expResult, result);
    }
}
*/