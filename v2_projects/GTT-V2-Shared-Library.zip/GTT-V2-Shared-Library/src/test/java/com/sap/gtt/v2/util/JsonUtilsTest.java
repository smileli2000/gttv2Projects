package com.sap.gtt.v2.util;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.sap.gtt.v2.core.domain.trackedprocess.CorrelationType;
import com.sap.gtt.v2.core.domain.trackedprocess.EventStatus;
import com.sap.gtt.v2.core.domain.trackedprocess.ProcessStatus;
import com.sap.gtt.v2.core.entity.trackedprocess.PlannedEvent;
import com.sap.gtt.v2.core.entity.trackedprocess.ProcessEventDirectory;
import com.sap.gtt.v2.core.entity.trackedprocess.QualifiedTrackingId;
import com.sap.gtt.v2.core.entity.trackedprocess.TrackedProcess;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(MockitoJUnitRunner.class)
public class JsonUtilsTest {

    @Test
    public void testFromIPropertyValue() {
        TrackedProcess tp = new TrackedProcess();
        String trackedProcessType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        tp.setTrackedProcessType(trackedProcessType);
        UUID tpId = GTTUtils.UUIDUtils.generateTimeBasedUUID();
        tp.setId(tpId);
        tp.setProcessStatus(ProcessStatus.AS_PLANNED.name());
        List<PlannedEvent> pes = new ArrayList<>();
        PlannedEvent plannedEvent = new PlannedEvent();
        plannedEvent.setId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        plannedEvent.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POConfirmedEvent");
        plannedEvent.setPlannedTechTsLatest(Instant.parse("2019-05-22T12:00:00.213Z"));
        plannedEvent.setPlannedBusinessTimestamp(Instant.parse("2019-05-15T12:00:00.213Z"));
        plannedEvent.setPlannedBizTsEarliest(Instant.parse("2019-05-09T12:00:00.213Z"));
        plannedEvent.setPlannedBizTsLatest(Instant.parse("2019-05-22T12:00:00.213Z"));
        plannedEvent.setEventStatus(EventStatus.PLANNED.name());
        plannedEvent.setOverdueDetectionCounter(0);
        plannedEvent.setNextOverdueDetection(plannedEvent.getPlannedTechTsLatest());
        plannedEvent.setIsFinalPlannedEvent(Boolean.FALSE);
        plannedEvent.setEventMatchKey("10");
        plannedEvent.setLastProcessEventDirectoryId(null);
        plannedEvent.setEventStatus(EventStatus.PLANNED.name());
        pes.add(plannedEvent);
        tp.setPlannedEvents(pes);
        List<QualifiedTrackingId> trackingIds = new ArrayList<>();
        QualifiedTrackingId trackingId = QualifiedTrackingId.build(tpId, tpId, null, null);
        trackingIds.add(trackingId);
        tp.setTrackingIds(trackingIds);
        List<ProcessEventDirectory> peds = new ArrayList<>();
        ProcessEventDirectory ped = ProcessEventDirectory.build(GTTUtils.UUIDUtils.generateTimeBasedUUID(),
                tpId, null, GTTUtils.UUIDUtils.generateTimeBasedUUID(), CorrelationType.UNPLANNED_PROCESS_CREATION_UPDATE.name());
        peds.add(ped);
        tp.setPEDs(peds);
        JsonElement ele = JsonUtils.fromIPropertyValue(tp);
        assertThat(ele.isJsonObject()).isTrue();

        JsonArray jsonArray = JsonUtils.generateJsonArrayFromList(Arrays.asList("aaa", "bbb"));
        Assertions.assertThat(jsonArray).isNotNull();
        boolean found = JsonUtils.containsKey("aaa", ele);
        Assertions.assertThat(found).isFalse();
    }
}
