package com.sap.gtt.v2.core.management.metering;

import com.sap.gtt.v2.core.dao.metering.DefaultMeteringDao;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import java.time.Instant;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;

@RunWith(PowerMockRunner.class)
@PrepareForTest({DefaultMeteringDao.class})
public class DefaultMeteringManagementTest {

    @Mock
    private DefaultMeteringDao meteringDao;

    private DefaultMeteringManagement meteringManagement;

    @Before
    public void setup() {
        PowerMockito.mockStatic(DefaultMeteringDao.class);
        PowerMockito.when(DefaultMeteringDao.getInstance()).thenReturn(meteringDao);
        meteringManagement = new DefaultMeteringManagement();
    }

    @Test
    public void test() {
        Instant instant = Instant.now();
        given(meteringDao.getPreviousMeteringTime(Mockito.anyString())).willReturn(instant);
        assertThat(meteringManagement.getPreviousMeteringTime("jobName")).isEqualTo(instant);

        given(meteringDao.countEvent(Mockito.any(Instant.class), Mockito.any(Instant.class))).willReturn(1);
        assertThat(meteringManagement.countEvent(Instant.EPOCH, Instant.now())).isEqualTo(1);

        given(meteringDao.countTP(Mockito.any(Instant.class), Mockito.any(Instant.class))).willReturn(1);
        assertThat(meteringManagement.countTP(Instant.EPOCH, Instant.now())).isEqualTo(1);

        meteringManagement.updateMeteringJobInfo("jobName", Instant.now());
    }
}
