/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.gtt.v2.core.auditlog;

import com.sap.gtt.v2.configuration.ISAPCloudPlatformAgent;
import com.sap.gtt.v2.core.domain.auditlog.AuditDataAccessData;
import com.sap.gtt.v2.core.domain.auditlog.AuditDataModificationData;
import com.sap.gtt.v2.exception.AuditLogServiceException;
import com.sap.gtt.v2.log.TenantAwareLogService;
import java.util.ArrayList;
import java.util.List;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.when;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.test.context.ActiveProfiles;

/**
 *
 * @author I326335
 */
@RunWith(PowerMockRunner.class)
@ActiveProfiles("test")
public class AuditLogServiceImplTest {

    @InjectMocks
    private AuditLogServiceImpl auditLogService;
    @Mock
    private ISAPCloudPlatformAgent.ICurrentAccessContext currentAccessContext;
    @Mock
    private TenantAwareLogService tenantAwareLogService;

    public AuditLogServiceImplTest() {
    }

    @Before
    public void setup() {
        when(currentAccessContext.getLogonName()).thenReturn("Name1");
        when(currentAccessContext.getSubaccountId()).thenReturn("Id1");
    }

    @Test(expected = AuditLogServiceException.class)
    public void testAuditDataAccess() {
        List<AuditDataAccessData> attributes = new ArrayList<AuditDataAccessData>() {
            {
                add(new AuditDataAccessData("receiver", true));
            }
        };
        auditLogService.auditDataAccess("dataSubjectId", "TrackedProcess", "", "", attributes);
    }

    @Test(expected = AuditLogServiceException.class)
    public void testAuditDataModification() {
        List<AuditDataModificationData> attributes = new ArrayList<AuditDataModificationData>() {
            {
                add(new AuditDataModificationData("receiver", "receiver1", "receiver2"));
            }
        };
        auditLogService.auditDataModification("dataSubjectId", "TrackedProcess", "", "", attributes);
    }

    @Test(expected = AuditLogServiceException.class)
    public void testAuditSecurityEvent() {
        auditLogService.auditSecurityEvent("10.1.1.1", "Unauthorized!");
    }

}
