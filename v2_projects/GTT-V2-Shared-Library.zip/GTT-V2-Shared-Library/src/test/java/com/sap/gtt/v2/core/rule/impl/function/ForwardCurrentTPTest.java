package com.sap.gtt.v2.core.rule.impl.function;

import com.sap.gtt.v2.BaseTest;
import com.sap.gtt.v2.Dummy;
import com.sap.gtt.v2.configuration.ISAPCloudPlatformAgent.ICurrentAccessContext;
import com.sap.gtt.v2.core.domain.metadata.CurrentMetadataEntity;
import com.sap.gtt.v2.core.domain.metadata.MetadataEntity;
import com.sap.gtt.v2.core.management.execution.IMessageLogManagement;
import com.sap.gtt.v2.core.management.metadata.IMetadataManagement;
import com.sap.gtt.v2.core.management.tracking.IEventManagement;
import com.sap.gtt.v2.core.management.tracking.ITrackedProcessManagement;
import com.sap.gtt.v2.core.rule.impl.MemoryBlock;
import com.sap.gtt.v2.core.rule.impl.MemoryBlockException;
import com.sap.gtt.v2.core.runtime.model.BooleanValue;
import com.sap.gtt.v2.core.runtime.model.StringValue;
import com.sap.gtt.v2.core.service.MessageValidation;
import com.sap.gtt.v2.util.GTTUtils;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;

import java.util.Arrays;
import java.util.Map;


@RunWith(SpringRunner.class)
@SpringBootTest(classes = Dummy.class)
@ActiveProfiles("test")
public class ForwardCurrentTPTest extends BaseTest {
	
	@Mock
    private MessageValidation messageValidation;
    private IMetadataManagement metadataManagement;
    private ITrackedProcessManagement processManagement;
    private IEventManagement eventManagement;
    private IMessageLogManagement executionHistoryManagement;
    
    private Map<String, MetadataEntity> entityMap;
    
    @Mock
    private ICurrentAccessContext currentAccessContext;
    
    private CurrentMetadataEntity getMetadata(String entityName) {
        CurrentMetadataEntity currentMetadataEntity = new CurrentMetadataEntity();
        currentMetadataEntity.setCurrentEntityName(entityName);
        currentMetadataEntity.setAllRelatedEntityMap(entityMap);
        return currentMetadataEntity;
    }
    
    @Before
    public void setup() {
    	metadataManagement = mock(IMetadataManagement.class);
        processManagement = mock(ITrackedProcessManagement.class);
        eventManagement = mock(IEventManagement.class);
        executionHistoryManagement = mock(IMessageLogManagement.class);
        GTTUtils.BusinessOperator businessOperator = mock(GTTUtils.BusinessOperator.class);
        given(businessOperator.getMetadataManagement()).willReturn(metadataManagement);
        given(businessOperator.getTrackedProcessManagement()).willReturn(processManagement);
        given(businessOperator.getEventManagement()).willReturn(eventManagement);
        given(businessOperator.getMessageLogManagement()).willReturn(executionHistoryManagement);
        given(currentAccessContext.createBusinessOperator()).willReturn(businessOperator);
        Mockito.when(metadataManagement.findAllEntitiesRecursively(Mockito.anyString(), Mockito.anyString()))
                .thenAnswer(new Answer<CurrentMetadataEntity>() {
                    public CurrentMetadataEntity answer(InvocationOnMock invocation) {
                        String entityName = invocation.getArgument(1);
                        return getMetadata(entityName);
                    }
                });
    }

    /*
    for sonar coverage
     */
    @Test
    public void test() throws MemoryBlockException {
        try {
            ForwardCurrentTP forwardCurrentTP = new ForwardCurrentTP();
            forwardCurrentTP.execute(MemoryBlock.createInstance(),
                    Arrays.asList(StringValue.valueOf("dummy"),
                            BooleanValue.valueOf(true),
                            BooleanValue.valueOf(true),
                            BooleanValue.valueOf(false)));
        } catch (Throwable e) {
            System.out.println(e.getMessage());
        }
    }

    @Test
    public void testAsync() throws MemoryBlockException {
        try {
            ForwardCurrentTP forwardCurrentTP = new ForwardCurrentTP();
            forwardCurrentTP.execute(MemoryBlock.createInstance(),
                    Arrays.asList(StringValue.valueOf("dummy"),
                            BooleanValue.valueOf(true),
                            BooleanValue.valueOf(true),
                            BooleanValue.valueOf(true)));
        } catch (Throwable e) {
            System.out.println(e.getMessage());
        }
    }
}