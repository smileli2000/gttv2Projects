package com.sap.gtt.v2.core.dao.execution;

import com.sap.gtt.v2.BaseTest;
import com.sap.gtt.v2.Dummy;
import com.sap.gtt.v2.core.domain.execution.ExecutionStatus;
import com.sap.gtt.v2.core.domain.execution.MessageSource;
import com.sap.gtt.v2.core.entity.execution.RequestPayload;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.time.Instant;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = Dummy.class)
@ActiveProfiles("test")
public class DefaultRequestPayloadDaoTest extends BaseTest {
    private DefaultRequestPayloadDao payloadDao;

    @Before
    public void setUp() {
        super.setUp();
        payloadDao = DefaultRequestPayloadDao.getInstance();
    }

    @Test
    public void test() {
        String requestId = "requestId";
        RequestPayload requestPayload = new RequestPayload(requestId, null, "messageNumber", "sourceId",
                MessageSource.OTHER.name(), Instant.now(), "path", "payload", ExecutionStatus.ERROR.name(),
                "cloneInstanceId", "subaccountId");
        payloadDao.insertRequestPayload(requestPayload);
        RequestPayload queryResult = payloadDao.query(requestId);
        Assertions.assertThat(queryResult).isNotNull();
        Assertions.assertThat(queryResult.getId()).isEqualTo(requestPayload.getId());
        Assertions.assertThat(queryResult.getStatus()).isEqualTo(requestPayload.getStatus());

        payloadDao.updateStatus(requestId, ExecutionStatus.SUCCESS.name());
        queryResult = payloadDao.query(requestId);
        Assertions.assertThat(queryResult).isNotNull();
        Assertions.assertThat(queryResult.getId()).isEqualTo(requestId);
        Assertions.assertThat(queryResult.getStatus()).isEqualTo(ExecutionStatus.SUCCESS.name());
    }
}
