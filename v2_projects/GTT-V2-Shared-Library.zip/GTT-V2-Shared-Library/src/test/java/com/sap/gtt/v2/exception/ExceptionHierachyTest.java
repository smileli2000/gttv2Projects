package com.sap.gtt.v2.exception;

import org.assertj.core.api.Assertions;
import org.junit.Test;

import static com.sap.gtt.v2.exception.MetadataException.MESSAGE_CODE_PROPERTY_NOT_FOUND;
import static org.apache.http.HttpStatus.SC_BAD_REQUEST;

public class ExceptionHierachyTest {
    @Test
    public void testDBException() {
        Assertions.assertThat(new DBException("db error"))
                .hasMessage("db error");
        Exception innerException = new Exception("inner exception");
        Assertions.assertThat(new DBException(innerException))
                .hasCause(innerException);

        Assertions.assertThat(new DBException("db error", innerException))
                .hasMessage("db error").hasCause(innerException);
    }

    @Test
    public void testHttpStatus4xxException() {
        Assertions.assertThat(new HttpStatus4xxException("Not Found.", null, 404))
                .hasMessage("Not Found.").hasNoCause();
    }

    @Test
    public void testMetadataException() {
        Assertions.assertThat(new MetadataException(
                MESSAGE_CODE_PROPERTY_NOT_FOUND, new Object[]{}
        )).hasNoCause();

        Assertions.assertThat(new MetadataException(
                MESSAGE_CODE_PROPERTY_NOT_FOUND, new Object[]{}, 404
        )).hasNoCause();

        Assertions.assertThat(new MetadataException(
                "internal message", null, MESSAGE_CODE_PROPERTY_NOT_FOUND,
                new Object[]{}
        )).hasNoCause();
    }

    @Test
    public void testOperationNotAllowed() {
        Assertions.assertThat(new OperationNotAllowed("401"))
                .hasMessage("401");
    }

    @Test
    public void testTenantSettingException() {
        Assertions.assertThat(new TenantServiceException((Throwable) null))
                .hasNoCause();

        Assertions.assertThat(new TenantServiceException("no-tenant-found"))
                .hasMessage("no-tenant-found");
    }

    @Test
    public void testTypeMismatchException() {
        Assertions.assertThat(new TypeMismatchException((Throwable)null))
                .hasNoCause();

        Assertions.assertThat(new TypeMismatchException("type-mismatch"))
                .hasMessage("type-mismatch");

    }

    @Test
    public void testValueParseException() {
        Assertions.assertThat(new ValueParseException("value-parse-error", null))
                .hasNoCause().hasMessage("value-parse-error");
    }

    @Test
    public void testMultiExceptionContainer() {
        MultiExceptionContainer multiExceptionContainer = new MultiExceptionContainer(500);
        MultiExceptionContainer multiExceptionContainer1 = new MultiExceptionContainer(500);
        multiExceptionContainer1.addException(new ValueParseException("value-parse-error", null));
        multiExceptionContainer.addException(multiExceptionContainer1);
        Assertions.assertThat(multiExceptionContainer.getHttpStatus())
                .isEqualTo(SC_BAD_REQUEST);
        Assertions.assertThat(multiExceptionContainer.getMessage())
                .isNotNull();
        Assertions.assertThat(multiExceptionContainer.getLocalizedMessage())
                .isNotNull();
        FormattedErrorMessage message = multiExceptionContainer.getFormattedErrorMessage();
        Assertions.assertThat(message).isNotNull();
    }

}
