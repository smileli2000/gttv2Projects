package com.sap.gtt.v2.util;

import com.sap.gtt.v2.configuration.GTTRestTemplate;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;

@RunWith(PowerMockRunner.class)
@PrepareForTest({SpringContextUtils.class})
public class UaaUtilsTest {

    @Mock
    private GTTRestTemplate restTemplate;


    @Before
    public void setUp() {
        PowerMockito.mockStatic(SpringContextUtils.class);
        when(SpringContextUtils.getBean(GTTRestTemplate.class)).thenReturn(restTemplate);

        String accessTokenUrl = "https://lbn-gtt.authentication.sap.hana.ondemand.com/oauth/token?grant_type=client_credentials";
        String accessTokenStr = "{\"access_token\": \"access_token\",\"token_type\": \"bearer\",\"expires_in\": 3599,\"scope\": \"lbn_gtt_core_acceptance!b5700.model.cp\",\"jti\": \"d9a3e44d1cd643138a8ff3e62409e35a\"}";

        String body = "{\"uaadomain\":\"aa\",\"tenantmode\":\"aa\",\"sburl\":\"aa\",\"clientid\":\"aa\",\"verificationkey\":\"aa\",\"apiurl\":\"aa\",\"xsappname\":\"aa\",\"identityzone\":\"aa\",\"identityzoneid\":\"aa\",\"clientsecret\":\"aa\",\"tenantid\":\"aa\",\"url\":\"aa\"}";

        ResponseEntity<String> response = mock(ResponseEntity.class);
        when(restTemplate.exchange(eq(accessTokenUrl), any(HttpMethod.class), any(HttpHeaders.class), any(), eq(String.class))).thenReturn(response);
        when(response.getBody()).thenReturn(accessTokenStr);
    }

    @Test
    public void requestTechniqueToken() {
        String uri = "https://lbn-gtt.authentication.sap.hana.ondemand.com";
        String clientId = "111";
        String secret = "pwd";

        String token = UaaUtils.requestTechniqueToken(uri, clientId, secret);
        assertEquals("access_token", token);
    }

    @Test
    public void requestTechniqueTokenWithSubdomainValue() {
        String uri = "https://lbn-gtt.authentication.sap.hana.ondemand.com";
        String clientId = "111";
        String secret = "pwd";
        String subdomain = "lbn-gtt";
        String token = UaaUtils.requestTechniqueToken(uri, subdomain, clientId, secret);
        assertEquals("access_token", token);
    }

    @Test
    public void getCloneInstanceDetail() {
        String cloneInstanceId = "aaa";
        String uri = "https://lbn-gtt.authentication.sap.hana.ondemand.com";
        String clientId = "111";
        String secret = "pwd";
        String cloneInstanceUrl = "https://lbn-gtt.authentication.sap.hana.ondemand.com/sap/rest/broker/clones/aaa/binding";
        String body = "{\"uaadomain\":\"aa\",\"tenantmode\":\"aa\",\"sburl\":\"aa\",\"clientid\":\"aa\",\"verificationkey\":\"aa\",\"apiurl\":\"aa\",\"xsappname\":\"aa\",\"identityzone\":\"aa\",\"identityzoneid\":\"aa\",\"clientsecret\":\"aa\",\"tenantid\":\"aa\",\"url\":\"aa\"}";
        ResponseEntity<String> response = mock(ResponseEntity.class);
        when(restTemplate.exchange(eq(cloneInstanceUrl), any(HttpMethod.class), any(HttpHeaders.class), any(), eq(String.class))).thenReturn(response);
        when(response.getBody()).thenReturn(body);
        UaaUtils.CloneInstanceDetail detail = UaaUtils.getCloneInstanceDetail(cloneInstanceId, uri, clientId, secret);
        String expected = "aa";
        assertNotNull(detail);
        assertEquals(expected, detail.getClientid());
        assertEquals(expected, detail.getIdentityzone());
        assertEquals(expected, detail.getApiurl());
        assertEquals(expected, detail.getClientsecret());
        assertEquals(expected, detail.getIdentityzoneid());
        assertEquals(expected, detail.getSburl());
        assertEquals(expected, detail.getTenantid());
        assertEquals(expected, detail.getTenantmode());
        assertEquals(expected, detail.getUaadomain());
        assertEquals(expected, detail.getUrl());
        assertEquals(expected, detail.getVerificationkey());
        assertEquals(expected, detail.getXsappname());
    }
    
    @Test
    public void getCloneInstanceDetailError() {
        String cloneInstanceId = "aaa";
        String uri = "https://lbn-gtt.authentication.sap.hana.ondemand.com";
        String clientId = "111";
        String secret = "pwd";
        String cloneInstanceUrl = "https://lbn-gtt.authentication.sap.hana.ondemand.com/sap/rest/broker/clones/aaa/binding";
        String body = "{\"error\":\"App lbn_gtt_core_pdm_service_dev_int!b6660|personal-data-manager!b3245 is no clone instance of master app lbn_gtt_core_pdm_service_dev_int!b6660|personal-data-manager!b3245\"}";
        ResponseEntity<String> response = mock(ResponseEntity.class);
        when(restTemplate.exchange(eq(cloneInstanceUrl), any(HttpMethod.class), any(HttpHeaders.class), any(), eq(String.class))).thenReturn(response);
        when(response.getBody()).thenReturn(body);
        UaaUtils.CloneInstanceDetail detail = UaaUtils.getCloneInstanceDetail(cloneInstanceId, uri, clientId, secret);
        assertNotNull(detail);
        assertNotNull(detail.getError());
    }
}