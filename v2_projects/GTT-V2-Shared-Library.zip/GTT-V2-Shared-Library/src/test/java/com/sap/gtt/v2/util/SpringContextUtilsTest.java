package com.sap.gtt.v2.util;

import com.sap.gtt.v2.Dummy;
import com.sap.gtt.v2.core.entity.trackedprocess.TrackedProcess;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = Dummy.class)
@ActiveProfiles("test")
public class SpringContextUtilsTest {

    @Test
    public void testCreateSingletonBean() {
        TrackedProcess tp = SpringContextUtils.createSingletonBean(
                TrackedProcess.class, "tp", new Object[]{});
        Assertions.assertThat(tp).isNotNull();
    }

}