package com.sap.gtt.v2.core.dao.execution;

import com.sap.gtt.v2.BaseTest;
import com.sap.gtt.v2.Dummy;
import com.sap.gtt.v2.core.domain.execution.ExecutionStatus;
import com.sap.gtt.v2.core.entity.execution.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = Dummy.class)
@ActiveProfiles("test")
public class DefaultExecutionMessageDaoTest extends BaseTest {
    private DefaultExecutionMessageDao executionMessageDao;

    @Before
    public void setUp() {
        super.setUp();
        executionMessageDao = DefaultExecutionMessageDao.getInstance();
    }

    @Test
    public void testQueryExecution() {
        String id = "executionId";
        ExecutionMessage executionMessage = executionMessageDao.queryExecutionMessage(id);
        if (executionMessage == null) {
            insertExecutionMessage(id, "phaseId");
            executionMessage = executionMessageDao.queryExecutionMessage(id);
        }
        assertThat(executionMessage.getId()).isEqualTo(id);
    }

    @Test
    public void testQueryExecutions() {
        String phaseId = "phaseId";
        List<ExecutionMessage> messages = executionMessageDao.queryExecutionMessages(phaseId);
        if (messages.isEmpty()) {
            insertExecutionMessage("id", phaseId);
            messages = executionMessageDao.queryExecutionMessages(phaseId);
        }
        assertThat(messages.size()).isEqualTo(1);
    }

    private void insertExecutionMessage(String id, String phaseId) {
        String message = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" +
                "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb" +
                "ccccccccccccccccccccccccccccccccccccccccccccccccccdddddddddd";
        ExecutionMessage executionMessage = new ExecutionMessage(id, phaseId, ExecutionStatus.ERROR.name(), message, "detail", Instant.now(), null);
        executionMessageDao.insertExecutionMessage(executionMessage);
    }
}
