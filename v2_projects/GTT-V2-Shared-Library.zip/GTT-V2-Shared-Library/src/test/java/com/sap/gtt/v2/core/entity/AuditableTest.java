package com.sap.gtt.v2.core.entity;

import com.sap.gtt.v2.core.entity.trackedprocess.Event;
import org.assertj.core.api.Assertions;
import org.junit.Test;

import java.time.Instant;

public class AuditableTest {

    @Test
    public void test() {
        Auditable event = new Event();
        Instant now = Instant.now();
        event.setCreationDateTime(now);
        event.setLastChangedDateTime(now);
        event.setCreatedByUser("a-user");

        Assertions.assertThat(event.getCreationDateTime()).isEqualTo(now);
        Assertions.assertThat(event.getLastChangedDateTime()).isEqualTo(now);
        Assertions.assertThat(event.getCreatedByUser()).isEqualTo("a-user");
    }

}