package com.sap.gtt.v2.core.management.execution;

import com.sap.gtt.v2.core.dao.execution.*;
import com.sap.gtt.v2.core.domain.execution.*;
import com.sap.gtt.v2.core.entity.execution.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import java.time.Instant;
import java.util.*;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@RunWith(PowerMockRunner.class)
@PrepareForTest({DefaultExecutionUnitDao.class, DefaultExecutionHistoryDao.class, DefaultExecutionPhaseDao.class,
        DefaultExecutionMessageDao.class, DefaultRequestPayloadDao.class, DefaultRequestTrackingIdDao.class,
        DefaultRequestMappingDao.class, DefaultCorrelatedTrackedProcessDao.class})
public class DefaultMessageLogManagementTest {

    @Mock
    private DefaultExecutionUnitDao executionUnitDao;
    @Mock
    private DefaultExecutionHistoryDao executionHistoryDao;
    @Mock
    private DefaultExecutionPhaseDao executionPhaseDao;
    @Mock
    private DefaultExecutionMessageDao executionMessageDao;
    @Mock
    private DefaultRequestPayloadDao requestPayloadDao;
    @Mock
    private DefaultRequestTrackingIdDao requestTrackingIdDao;
    @Mock
    private DefaultRequestMappingDao requestMappingDao;
    @Mock
    private DefaultCorrelatedTrackedProcessDao correlatedTrackedProcessDao;

    private DefaultMessageLogManagement messageLogManagement;

    @Before
    public void setup() {
        PowerMockito.mockStatic(DefaultExecutionUnitDao.class, DefaultExecutionHistoryDao.class,
                DefaultExecutionPhaseDao.class, DefaultExecutionMessageDao.class,
                DefaultRequestPayloadDao.class, DefaultRequestTrackingIdDao.class,
                DefaultRequestMappingDao.class, DefaultCorrelatedTrackedProcessDao.class);
        PowerMockito.when(DefaultExecutionUnitDao.getInstance()).thenReturn(executionUnitDao);
        PowerMockito.when(DefaultExecutionHistoryDao.getInstance()).thenReturn(executionHistoryDao);
        PowerMockito.when(DefaultExecutionPhaseDao.getInstance()).thenReturn(executionPhaseDao);
        PowerMockito.when(DefaultExecutionMessageDao.getInstance()).thenReturn(executionMessageDao);
        PowerMockito.when(DefaultRequestPayloadDao.getInstance()).thenReturn(requestPayloadDao);
        PowerMockito.when(DefaultRequestTrackingIdDao.getInstance()).thenReturn(requestTrackingIdDao);
        PowerMockito.when(DefaultRequestMappingDao.getInstance()).thenReturn(requestMappingDao);
        PowerMockito.when(DefaultCorrelatedTrackedProcessDao.getInstance()).thenReturn(correlatedTrackedProcessDao);
        messageLogManagement = new DefaultMessageLogManagement();
    }

    @Test
    public void testInsertExecutionWhenUnitIsNew() {
        ExecutionDto executionDto = new ExecutionDto();
        String eventId = "eventId";
        String correlatedTpId = "tpId";
        executionDto.setEventId(eventId);
        executionDto.setCorrelatedTpId(correlatedTpId);
        String executionHistoryId = UUID.randomUUID().toString();
        executionDto.setExecutionHistoryId(executionHistoryId);
        executionDto.setLastPhase(Phase.EVENT2ACTION.name());
        given(executionUnitDao.queryExecutionUnit(Mockito.anyString(), Mockito.anyString())).willReturn(null);
        messageLogManagement.insertExecution(executionDto);
        verify(executionUnitDao, times(1)).insertExecutionUnit(Mockito.any(ExecutionUnit.class));
        verify(executionHistoryDao, times(1)).insertExecution(Mockito.any(ExecutionHistory.class));
    }

    @Test
    public void testInsertExecutionWhenUnitIsExisted() {
        ExecutionDto executionDto = new ExecutionDto();
        String eventId = "eventId";
        String correlatedTpId = "tpId";
        executionDto.setEventId(eventId);
        executionDto.setCorrelatedTpId(correlatedTpId);
        String executionHistoryId = UUID.randomUUID().toString();
        executionDto.setExecutionHistoryId(executionHistoryId);
        executionDto.setLastPhase(Phase.EVENT2ACTION.name());
        String unitId = UUID.randomUUID().toString();
        int count = 1;
        ExecutionUnit executionUnit = new ExecutionUnit(unitId, "requestId", eventId, "eventType", "altkey", "locationAltkey",
                correlatedTpId, "correlatedTpAltkey", count, executionHistoryId, false);
        given(executionUnitDao.queryExecutionUnit(Mockito.anyString(), Mockito.anyString())).willReturn(executionUnit);
        messageLogManagement.insertExecution(executionDto);
        verify(executionUnitDao, times(1)).updateExecutionUnit(eq(unitId), eq(count + 1), eq(executionHistoryId));
        verify(executionHistoryDao, times(1)).insertExecution(Mockito.any(ExecutionHistory.class));
    }

    @Test
    public void testInsertErrorExecutionMessageAndAffectExecutionAndPayloadStatus() {
        ExecutionMessageDto executionMessageDto = new ExecutionMessageDto();
        String executionHistoryId = UUID.randomUUID().toString();
        executionMessageDto.setExecutionHistoryId(executionHistoryId);
        String phaseName = Phase.PROCESS.name();
        executionMessageDto.setPhase(phaseName);
        String status = ExecutionStatus.ERROR.name();
        executionMessageDto.setMessageType(status);
        executionMessageDto.setErrorAt(Instant.now());
        executionMessageDto.setMessage("message");
        executionMessageDto.setDetail("detail");

/*        ExecutionPhase phase = new ExecutionPhase("phaseId", "executionId", );
        given(executionPhaseDao.queryExecutionPhase(Mockito.anyString(), Mockito.anyString())).willReturn(phase);*/

        String unitId = "unitId";
        ExecutionHistory executionHistory = new ExecutionHistory(executionHistoryId, unitId, Instant.now(),
                Phase.EVENT2ACTION.name(), ExecutionStatus.SUCCESS.name());
        given(executionHistoryDao.queryExecution(Mockito.anyString())).willReturn(executionHistory);

        ExecutionUnit executionUnit = new ExecutionUnit();
        executionUnit.setId(unitId);
        String requestId = "requestId";
        executionUnit.setRequestId(requestId);
        given(executionUnitDao.queryExecutionUnit(Mockito.anyString())).willReturn(executionUnit);

        RequestPayload payload = new RequestPayload();
        payload.setId(executionUnit.getRequestId());
        payload.setStatus(ExecutionStatus.SUCCESS.name());
        given(requestPayloadDao.query(Mockito.anyString())).willReturn(payload);

        messageLogManagement.insertExecutionMessage(executionMessageDto);
        verify(executionPhaseDao, times(1)).insertExecutionPhase(Mockito.any(ExecutionPhase.class));
        verify(executionMessageDao, times(1)).insertExecutionMessage(Mockito.any(ExecutionMessage.class));
        verify(executionHistoryDao, times(1)).updateExecutionStatus(eq(executionHistoryId), eq(phaseName), eq(status));
        verify(requestPayloadDao, times(1)).updateStatus(eq(requestId), eq(ExecutionStatus.ERROR.name()));
    }

    @Test
    public void testInsertSuccessExecutionMessageWhenPhaseIsPendingAndAffectExecutionAndPayloadStatus() {
        ExecutionMessageDto executionMessageDto = new ExecutionMessageDto();
        String executionHistoryId = UUID.randomUUID().toString();
        executionMessageDto.setExecutionHistoryId(executionHistoryId);
        String phaseName = Phase.EVENT2ACTION.name();
        executionMessageDto.setPhase(phaseName);
        String status = ExecutionStatus.SUCCESS.name();
        executionMessageDto.setMessageType(status);
        executionMessageDto.setErrorAt(Instant.now());
        executionMessageDto.setMessage("message");
        executionMessageDto.setDetail("detail");
        String tag = "tag";
        executionMessageDto.setTag(tag);

        String phaseId = "phaseId";
        ExecutionPhase phase = new ExecutionPhase(phaseId, "executionId", Phase.EVENT2ACTION.name(), ExecutionStatus.PENDING.name());
        given(executionPhaseDao.queryExecutionPhase(Mockito.anyString(), Mockito.anyString())).willReturn(phase);

        List<ExecutionPhase> phases = new ArrayList<>();
        phases.add(phase);
        given(executionPhaseDao.queryExecutionPhases(Mockito.anyString())).willReturn(phases);

        List<ExecutionMessage> messages = new ArrayList<>();
        messages.add(new ExecutionMessage(UUID.randomUUID().toString(), phaseId, ExecutionStatus.PENDING.name(),
                "pending", "detail", Instant.now(), tag));
        messages.add(new ExecutionMessage(UUID.randomUUID().toString(), phaseId, ExecutionStatus.SUCCESS.name(),
                executionMessageDto.getMessage(), executionMessageDto.getDetail(), executionMessageDto.getErrorAt(), tag));
        given(executionMessageDao.queryExecutionMessages(Mockito.anyString())).willReturn(messages);

        String unitId = "unitId";
        ExecutionHistory executionHistory = new ExecutionHistory(executionHistoryId, unitId, Instant.now(),
                Phase.EVENT2ACTION.name(), ExecutionStatus.PENDING.name());
        given(executionHistoryDao.queryExecution(Mockito.anyString())).willReturn(executionHistory);

        ExecutionUnit executionUnit = new ExecutionUnit();
        executionUnit.setId(unitId);
        String requestId = "requestId";
        executionUnit.setRequestId(requestId);
        given(executionUnitDao.queryExecutionUnit(Mockito.anyString())).willReturn(executionUnit);

        RequestPayload payload = new RequestPayload();
        payload.setId(executionUnit.getRequestId());
        payload.setStatus(ExecutionStatus.PENDING.name());
        given(requestPayloadDao.query(Mockito.anyString())).willReturn(payload);

        RequestMapping requestMapping = new RequestMapping("id", requestId, "requestId", null,
                ExecutionStatus.SUCCESS.name(), "", "");
        List<RequestMapping> mappingList = new ArrayList<>();
        mappingList.add(requestMapping);
        given(requestMappingDao.queryRequestMappings(requestId)).willReturn(mappingList);
        List<String> statusList = new ArrayList<>();
        statusList.add(ExecutionStatus.SUCCESS.name());
        given(executionHistoryDao.queryStatus(requestId)).willReturn(statusList);

        messageLogManagement.insertExecutionMessage(executionMessageDto);
        verify(executionPhaseDao, times(1)).updateExecutionPhaseStatus(Mockito.anyString(), eq(ExecutionStatus.SUCCESS.name()));
        verify(executionMessageDao, times(1)).insertExecutionMessage(Mockito.any(ExecutionMessage.class));
        verify(executionHistoryDao, times(1)).updateExecutionStatus(eq(executionHistoryId), eq(phaseName), eq(status));
        verify(requestPayloadDao, times(1)).updateStatus(eq(requestId), eq(ExecutionStatus.SUCCESS.name()));
    }

    @Test
    public void testInsertMappingMessageSuccess() {
        MappingMessageDto messageDto = new MappingMessageDto();
        messageDto.setRootRequestId("rootRequestId");
        messageDto.setObjectId("objectId");
        messageDto.setTargetId(null);
        messageDto.setStatus(ExecutionStatus.SUCCESS);
        RequestPayload payload = new RequestPayload();
        payload.setId(messageDto.getRootRequestId());
        payload.setStatus(ExecutionStatus.ERROR.name());
        given(requestPayloadDao.query(Mockito.anyString())).willReturn(payload);
        messageLogManagement.insertMappingMessage(messageDto);
        verify(requestMappingDao, times(1)).insert(Mockito.any(RequestMapping.class));
        verify(requestPayloadDao, times(0)).updateStatus(Mockito.anyString(), Mockito.anyString());
    }

    @Test
    public void testInsertMappingMessageError() {
        MappingMessageDto messageDto = new MappingMessageDto();
        messageDto.setRootRequestId("rootRequestId");
        messageDto.setObjectId("objectId");
        messageDto.setTargetId(null);
        messageDto.setStatus(ExecutionStatus.ERROR);
        messageDto.setMessage("messageCode");
        messageDto.setDetail("detail");
        RequestPayload payload = new RequestPayload();
        payload.setId(messageDto.getRootRequestId());
        payload.setStatus(ExecutionStatus.SUCCESS.name());
        given(requestPayloadDao.query(Mockito.anyString())).willReturn(payload);
        messageLogManagement.insertMappingMessage(messageDto);
        verify(requestMappingDao, times(1)).insert(Mockito.any(RequestMapping.class));
        verify(requestPayloadDao, times(1)).updateStatus(Mockito.anyString(), Mockito.matches(ExecutionStatus.ERROR.name()));
    }

    @Test
    public void testRecalculatePayloadStatusWhenRequestMappingError() {
        String requestId = "requestId";
        RequestMapping requestMapping = new RequestMapping("id", requestId, "requestId", null,
                ExecutionStatus.ERROR.name(), "messageCode", "detail");
        List<RequestMapping> mappingList = new ArrayList<>();
        mappingList.add(requestMapping);
        given(requestMappingDao.queryRequestMappings(requestId)).willReturn(mappingList);
        List<String> statusList = new ArrayList<>();
        statusList.add(ExecutionStatus.SUCCESS.name());
        given(executionHistoryDao.queryStatus(requestId)).willReturn(statusList);
        assertThat(messageLogManagement.recalculatePayloadStatus(requestId)).isEqualTo(ExecutionStatus.ERROR);
    }

    @Test
    public void testRecalculatePayloadStatushenExecutionError() {
        String requestId = "requestId";
        RequestMapping requestMapping = new RequestMapping("id", requestId, "requestId", null,
                ExecutionStatus.SUCCESS.name(), null, null);
        List<RequestMapping> mappingList = new ArrayList<>();
        mappingList.add(requestMapping);
        given(requestMappingDao.queryRequestMappings(requestId)).willReturn(mappingList);
        List<String> statusList = new ArrayList<>();
        statusList.add(ExecutionStatus.ERROR.name());
        given(executionHistoryDao.queryStatus(requestId)).willReturn(statusList);
        assertThat(messageLogManagement.recalculatePayloadStatus(requestId)).isEqualTo(ExecutionStatus.ERROR);
    }

    @Test
    public void testRecalculatePayloadStatusSuccess() {
        String requestId = "requestId";
        RequestMapping requestMapping = new RequestMapping("id", requestId, "requestId", null,
                ExecutionStatus.SUCCESS.name(), null, null);
        List<RequestMapping> mappingList = new ArrayList<>();
        mappingList.add(requestMapping);
        given(requestMappingDao.queryRequestMappings(requestId)).willReturn(mappingList);
        List<String> statusList = new ArrayList<>();
        statusList.add(ExecutionStatus.SUCCESS.name());
        given(executionHistoryDao.queryStatus(requestId)).willReturn(statusList);
        assertThat(messageLogManagement.recalculatePayloadStatus(requestId)).isEqualTo(ExecutionStatus.SUCCESS);
    }

    @Test
    public void testInsertPayload() {
        RequestPayloadDto payloadDto = new RequestPayloadDto();
        payloadDto.setId("id");
        payloadDto.setParentId(null);
        payloadDto.setMessageNumber(null);
        payloadDto.setSourceId("sourceId");
        payloadDto.setWriteServicePath("path");
        payloadDto.setPayload("payload");
        payloadDto.setSource(MessageSource.OTHER.name());
        payloadDto.setRequestDataTime(Instant.now());
        payloadDto.setCloneInstanceId(null);
        payloadDto.setSubaccountId("subaccountId");
        messageLogManagement.insertPayload(payloadDto);
        verify(requestPayloadDao, times(1)).insertRequestPayload(Mockito.any(RequestPayload.class));
    }

    @Test
    public void testInsertTrackingIds() {
        RequestTrackingIdDto trackingIdDto = new RequestTrackingIdDto();
        trackingIdDto.setRequestId("requestId");
        trackingIdDto.setTrackingIds(Arrays.asList("a", "b"));
        messageLogManagement.insertTrackingIds(trackingIdDto);
        ArgumentCaptor<List<RequestTrackingId>> argumentCaptor = ArgumentCaptor.forClass(List.class);
        verify(requestTrackingIdDao, times(1)).insertRequestTrackingIds(argumentCaptor.capture());
        List<RequestTrackingId> trackingIds = argumentCaptor.getValue();
        assertThat(trackingIds.size()).isEqualTo(2);
    }

    @Test
    public void testInsertCorrelatedTrackedProcess() {
        CorrelatedTrackedProcessDto correlatedTrackedProcessDto = new CorrelatedTrackedProcessDto();
        correlatedTrackedProcessDto.setExecutionId("requestId");
        Map<String, String> tpMap = new HashMap<>();
        tpMap.put("key1", "value1");
        tpMap.put("key2", "value2");
        correlatedTrackedProcessDto.setTpMap(tpMap);
        messageLogManagement.insertCorrelatedTrackedProcess(correlatedTrackedProcessDto);
        ArgumentCaptor<List<CorrelatedTrackedProcess>> argumentCaptor = ArgumentCaptor.forClass(List.class);
        verify(correlatedTrackedProcessDao, times(1)).insert(argumentCaptor.capture());
        List<CorrelatedTrackedProcess> correlatedTrackedProcesses = argumentCaptor.getValue();
        assertThat(correlatedTrackedProcesses.size()).isEqualTo(2);
    }
}
