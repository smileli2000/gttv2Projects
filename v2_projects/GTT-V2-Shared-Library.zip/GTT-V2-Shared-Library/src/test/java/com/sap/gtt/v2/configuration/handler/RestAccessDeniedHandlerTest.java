/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.gtt.v2.configuration.handler;

import com.sap.gtt.v2.configuration.EnvironmentsConfiguration;
import com.sap.gtt.v2.configuration.ServiceInstancesMapping;
import com.sap.gtt.v2.core.auditlog.AuditLogService;
import com.sap.gtt.v2.log.TenantAwareLogService;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.BDDMockito;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.test.context.ActiveProfiles;

/**
 *
 * @author I326335
 */
@RunWith(PowerMockRunner.class)
@ActiveProfiles("test")
public class RestAccessDeniedHandlerTest {
    @InjectMocks
    private RestAccessDeniedHandler accessDeniedHandler;
    @Mock
    private HttpServletRequest request;
    @Mock
    private HttpServletResponse response;
    @Mock
    private AccessDeniedException exception;
    @Mock
    private AuditLogService auditLogService;
    @Mock
    private TenantAwareLogService logService;
    @Mock
    private ServiceInstancesMapping serviceInstancesMapping;
    
    public RestAccessDeniedHandlerTest() {
    }

    @Test
    public void testHandler() throws IOException, ServletException {
        BDDMockito.given(serviceInstancesMapping.getUaaServiceInstance()).willReturn(Mockito.mock(EnvironmentsConfiguration.VcapServiceParser.UaaServiceInstance.class));
        Mockito.when(response.getWriter()).thenReturn(new PrintWriter(new BufferedWriter(new StringWriter())));
        accessDeniedHandler.handle(request, response, exception);
    }
    
}
