package com.sap.gtt.v2.core.runtime.model;

import org.assertj.core.api.Assertions;
import org.junit.Test;

import java.math.BigDecimal;

public class IntegerValueTest {
    @Test
    public void test() {
        IntegerValue integerVal = IntegerValue.valueOf(2);
        IntegerValue res = (IntegerValue) integerVal.addInternal(IntegerValue.valueOf(4));
        Assertions.assertThat(res.getInternalValue().compareTo(6))
                .isEqualTo(0);

        res = (IntegerValue) res.subInternal(IntegerValue.valueOf(2));
        Assertions.assertThat(res.getInternalValue().compareTo(4))
                .isEqualTo(0);

        res = (IntegerValue) res.mulInternal(IntegerValue.valueOf(2));
        Assertions.assertThat(res.getInternalValue().compareTo(8))
                .isEqualTo(0);

        res = (IntegerValue) res.divInternal(IntegerValue.valueOf(2));
        Assertions.assertThat(res.getInternalValue().compareTo(4))
                .isEqualTo(0);

        DecimalValue decimalRes = (DecimalValue) res.powInternal(IntegerValue.valueOf(2));
        Assertions.assertThat(decimalRes.getInternalValue().compareTo(new BigDecimal(16.0)))
                .isEqualTo(0);

        integerVal = IntegerValue.valueOf(2);
        decimalRes = (DecimalValue) integerVal.addInternal(DecimalValue.valueOf(4.0));
        Assertions.assertThat(decimalRes.getInternalValue().compareTo(new BigDecimal(6.0)))
                .isEqualTo(0);

        decimalRes = (DecimalValue) integerVal.subInternal(DecimalValue.valueOf(2));
        Assertions.assertThat(decimalRes.getInternalValue().compareTo(new BigDecimal(0)))
                .isEqualTo(0);

        decimalRes = (DecimalValue) integerVal.mulInternal(DecimalValue.valueOf(2));
        Assertions.assertThat(decimalRes.getInternalValue().compareTo(new BigDecimal(4)))
                .isEqualTo(0);

        decimalRes = (DecimalValue) integerVal.divInternal(DecimalValue.valueOf(2));
        Assertions.assertThat(decimalRes.getInternalValue().compareTo(new BigDecimal(1)))
                .isEqualTo(0);

        decimalRes = (DecimalValue) integerVal.powInternal(IntegerValue.valueOf(2));
        Assertions.assertThat(decimalRes.getInternalValue().compareTo(new BigDecimal(4.0)))
                .isEqualTo(0);
    }
}