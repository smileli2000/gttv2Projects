package com.sap.gtt.v2;

public class Dummy extends GTTBaseSpringApplication {
	public static void main(String[] args) {
		GTTSpringApplicationLauncher.run(new Dummy(), args);
	}
}
