package com.sap.gtt.v2.core.dao.tracking;


import com.sap.gtt.v2.BaseTest;
import com.sap.gtt.v2.Dummy;
import com.sap.gtt.v2.core.dao.metadata.*;
import com.sap.gtt.v2.core.domain.metadata.CurrentMetadataEntity;
import com.sap.gtt.v2.core.domain.metadata.MetadataConstants;
import com.sap.gtt.v2.core.domain.metadata.MetadataEntity;
import com.sap.gtt.v2.core.domain.metadata.MetadataEntityEvent;
import com.sap.gtt.v2.core.domain.trackedprocess.LifeCycleStatus;
import com.sap.gtt.v2.core.entity.trackedprocess.PlannedEvent;
import com.sap.gtt.v2.core.entity.trackedprocess.TrackedProcess;
import com.sap.gtt.v2.core.management.metadata.DefaultMetadataManagement;
import com.sap.gtt.v2.core.management.metadata.IMetadataManagement;
import com.sap.gtt.v2.util.DBUtils;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.IOException;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.Arrays;
import java.util.UUID;

import static com.sap.gtt.v2.core.entity.trackedprocess.TrackedProcess.ID;
import static org.mockito.BDDMockito.given;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = Dummy.class)
@ActiveProfiles("test")
public class DaoHelperTest extends BaseTest {

    @Autowired
    private ITrackedProcessDao trackedProcessDao;

    @Autowired
    private IQualifiedTrackingIdDao qualifiedTrackingIdDao;

    @Autowired
    private IProcessEventDirectoryDao processEventDirectoryDao;

    @Autowired
    private IPlannedEventDao plannedEventDao;

    @Autowired
    private IEventDao eventDao;

    @Autowired
    private IMetadataDao metadataDao;

    @Autowired
    private ISysTableDao sysTableDao;

    @Autowired
    private DaoHelper daoHelper;

    @Spy
    private MetadataEntity metadataEntity;

    @Test
    public void testBasicCRUD() throws IOException {
        DefaultMetadataDaoTest test = new DefaultMetadataDaoTest();
        test.setDefaultMetadataDao((DefaultMetadataDao) metadataDao);
        test.insertMetadataProject();

        DefaultSysTableDaoTest test1 = new DefaultSysTableDaoTest();
        test1.setDefaultSysTableDao((DefaultSysTableDao)sysTableDao);
        test1.createTables();

        String entityType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        String entityName = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        String namespace = "com.sap.gtt.app.mim";

        IMetadataManagement metadataManagement = DefaultMetadataManagement.getInstance();
        CurrentMetadataEntity metadata = metadataManagement.findAllEntitiesRecursively(namespace, entityName);
        metadata.setCurrentEntityName(MetadataConstants.CoreModelEntity.TRACKED_PROCESS.getFullName());

        TrackedProcess tp = new TrackedProcess();
        tp.setId(UUID.randomUUID());
        tp.setTrackedProcessType(entityType);
        tp.setTrackingId("my-tracking-id");
        tp.setPartyId("666666");
        tp.setScheme("my-scheme");
        tp.setAltKey("my-alt-key");
        tp.setLifeCycleStatus(LifeCycleStatus.END_OF_BUSINESS);
        tp.setTrackingIdType("my-tracking-id-type");
        tp.setLogicalSystem("a-system");

        tp.setValue("procurementOrderNO", "12345");
        tp.setValue("procurementOrderItemQty", 88.8);
        tp.setMetadata(metadata);
        tp.setVersion(0);

        daoHelper.insert(tp);
        daoHelper.update(tp);
        TrackedProcess tp1 = daoHelper.findOneByPrimaryKey(TrackedProcess.class, metadata, tp.getId().getInternalValue());
        daoHelper.updateFields(metadata, tp, ID);
        daoHelper.updateSingleField(metadata, tp, ID);
        daoHelper.save(Arrays.asList(tp));
        daoHelper.count(metadata, " 1=1 ");
        daoHelper.count(metadata, " 1<>1 ");
        daoHelper.exists(metadata, tp.getId().getInternalValue());
        daoHelper.findAll(TrackedProcess.class, metadata);
        daoHelper.findAll(TrackedProcess.class, metadata, 0, 1);
        daoHelper.findAll(TrackedProcess.class, metadata, 0, 1, " 1=1 ");
        daoHelper.findAll(TrackedProcess.class, metadata, 0, 1, " 1=1 ", (MapSqlParameterSource) null);
        daoHelper.findAllWithOrderBy(TrackedProcess.class, metadata, " id desc ");
        daoHelper.findAllWithOrderBy(TrackedProcess.class, metadata, " id desc ", " 1=1 ");
        daoHelper.findAllWithOrderBy(TrackedProcess.class, metadata, " id desc ", 0, 1, " 1=1 ");
        daoHelper.findAllWithOrderBy(TrackedProcess.class, metadata, " id desc ", 0, 1, " 1=1 ", (MapSqlParameterSource) null);
        daoHelper.versionExists(tp, 1);
        daoHelper.getAssociations(metadata);
        daoHelper.deleteAll(metadata, " 1=1 ");
        daoHelper.deleteAll(DBUtils.toTableName(
                MetadataConstants.CoreModelEntity.TRACKED_PROCESS.getFullName()),
                "", null);


        Assertions.assertThat(tp).isEqualTo(tp1);

        PlannedEvent plannedEvent = new PlannedEvent();
        plannedEvent.setId(UUID.randomUUID());
        plannedEvent.setProcessId(tp.getId());
        plannedEvent.setEventStatus("DELAYED");
        //plannedEvent.setLocationId(UUID.randomUUID());
        plannedEvent.setPlannedBusinessTimestamp(Instant.now());
        plannedEvent.setPlannedTechnicalTimestamp(Instant.now());
        plannedEvent.setPlannedBusinessTimeZone("+8");
        plannedEvent.setEventType("PLANNED");
        plannedEvent.setPlannedBizTsEarliest(Instant.now());
        plannedEvent.setPlannedBizTsLatest(Instant.now());
        plannedEvent.setPlannedTechTsEarliest(Instant.now());
        plannedEvent.setPlannedTechTsLatest(Instant.now());
        plannedEvent.setNextOverdueDetection(Instant.now());
        plannedEvent.setOverdueDetectionCounter(1);
        plannedEvent.setPayloadSequence(1);
        plannedEvent.setLocationAltKey("");
        plannedEvent.setLongitude(new BigDecimal(18d));
        plannedEvent.setLatitude(new BigDecimal(18d));
        plannedEvent.setIsFinalPlannedEvent(Boolean.FALSE);

        CurrentMetadataEntity metadata3 = new CurrentMetadataEntity();
        metadata3.setAllRelatedEntityMap(metadata.getAllRelatedEntityMap());
        metadata3.setCurrentEntityName(MetadataConstants.CoreModelEntity.PLANNED_EVENT.getFullName());
        plannedEvent.setMetadata(metadata3);

        Assertions.assertThat(plannedEvent.toString()).isNotBlank();
        plannedEvent.copy(plannedEvent);

    }

    @Test
    public void testExTable() throws IOException {
        DefaultMetadataDaoTest test = new DefaultMetadataDaoTest();
        test.setDefaultMetadataDao((DefaultMetadataDao) metadataDao);
        test.insertMetadataProject();

        DefaultSysTableDaoTest test1 = new DefaultSysTableDaoTest();
        test1.setDefaultSysTableDao((DefaultSysTableDao)sysTableDao);
        test1.createTables();

        String entityType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        String entityName = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        String namespace = "com.sap.gtt.app.mim";

        IMetadataManagement metadataManagement = DefaultMetadataManagement.getInstance();
        CurrentMetadataEntity metadata = metadataManagement.findAllEntitiesRecursively(namespace, entityName);
        metadata.setCurrentEntityName(MetadataConstants.CoreModelEntity.TRACKED_PROCESS.getFullName());

        MetadataEntity existing = metadata.getAllRelatedEntityMap().get(MetadataConstants.CoreModelEntity.TRACKED_PROCESS.getFullName());
        metadataEntity.setProcessEvent(true);
        metadataEntity.addPlannedEvent(new MetadataEntityEvent());
        metadataEntity.addUnplannedEvent(new MetadataEntityEvent());
        metadataEntity.setPlannedEventsStr("");
        metadataEntity.setUnplannedEventsStr("");
        metadataEntity.containsProperty("");
        metadataEntity.setApplicationObjectType("");
        Assertions.assertThat(existing.getPrimarykeys()).size().isGreaterThan(0);
        Assertions.assertThat(existing.toString()).isNotNull();
        Assertions.assertThat(existing).isNotEqualTo(metadataEntity);

        given(metadataEntity.getPhysicalName()).willReturn(existing.getPhysicalName());
//        metadata.getAllRelatedEntityMap().put(MetadataConstants.CoreModelEntity.TRACKED_PROCESS.getFullName(), metadataEntity);
        existing.getElements().get(0).setDefaultVal("");
        existing.getElements().get(0).setEnumVal("");
        existing.getElements().get(0).setTarget("");
        existing.getElements().get(0).setCardinality("");
        existing.getElements().get(0).getCardinality();
        existing.getElements().get(0).setKey(true);

        TrackedProcess tp = new TrackedProcess();
        tp.setId(UUID.randomUUID());
        tp.setTrackedProcessType(entityType);
        tp.setTrackingId("my-tracking-id");
        tp.setPartyId("666666");
        tp.setScheme("my-scheme");
        tp.setAltKey("my-alt-key");
        tp.setLifeCycleStatus(LifeCycleStatus.END_OF_BUSINESS);
        tp.setTrackingIdType("my-tracking-id-type");
        tp.setLogicalSystem("a-system");

        tp.setValue("procurementOrderNO", "12345");
        tp.setValue("procurementOrderItemQty", 88.8);
        tp.setMetadata(metadata);
        tp.setVersion(0);

        daoHelper.insert(tp);
    }
}