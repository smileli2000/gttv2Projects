package com.sap.gtt.v2.core.dao.overdue;

import com.sap.gtt.v2.BaseTest;
import com.sap.gtt.v2.Dummy;
import com.sap.gtt.v2.core.management.overdue.IOverdueManagement;
import com.sap.gtt.v2.util.SpringContextUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.reflect.Whitebox;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.time.Instant;
import java.util.*;


@RunWith(SpringRunner.class)
@SpringBootTest(classes = Dummy.class)
@ActiveProfiles("test")
public class DefaultOverdueDaoTest extends BaseTest {

    private DefaultOverdueDao defaultOverdueDao;
    String jobName = "lbn-gtt-core-storage-hana";

    @Before
    public void setUp() {
        super.setUp();
        defaultOverdueDao = ((DefaultOverdueDao) SpringContextUtils.getBean(DefaultOverdueDao.BEAN_NAME));
    }

    @Test
    public void testGetPreviousDetectionTimeWithRecord(){
        //insert one record into jobinfo table and then do the get test:
        Instant jobDetectionTime = Instant.ofEpochMilli(1596960000000l);
        defaultOverdueDao.updateOverdueInfo(jobName,jobDetectionTime);
        Instant actualPreviousDetectionTime = defaultOverdueDao.getPreviousDetectionTime(jobName);
        Assert.assertEquals(jobDetectionTime,actualPreviousDetectionTime);
    }

    @Test
    public void testCountOverduePlannedEventWithNoOverduePlannedEvent(){
        Instant from = Instant.from(Instant.EPOCH);
        Instant to = Instant.ofEpochMilli(1596960000000l);
        int actualCountNum = defaultOverdueDao.countOverduePlannedEvent(from,to);
        Assert.assertEquals(0,actualCountNum);
    }

    @Test
    public void testGetOverduePlannedEventsInfo(){
        Instant from = Instant.ofEpochMilli(1596960000000l);
        Instant to = Instant.ofEpochMilli(1596960000000l);
        int skip = 1;
        int top = 2;
        List<IOverdueManagement.PlannedEventIdentifier> plannedEventIdentifiers = defaultOverdueDao.getOverduePlannedEventsInfo(from,to,skip,top);
        Assert.assertEquals(0, plannedEventIdentifiers.size());

    }

    @Test
    public void testGetOverduePlannedEventsInfoWithReturnResult(){
        defaultOverdueDao = new DefaultOverdueDao();
        Instant from = Instant.ofEpochMilli(1596960000000l);
        Instant to = Instant.ofEpochMilli(1596960000000l);
        int skip = 0;
        int top = 1;

        List<Map<String, Object>> mapList = new ArrayList<>();
        Map<String,Object> returnMap = new HashMap<>();
        returnMap.put("SUBACCOUNTID","32dff0ce-84a4-5475-9c37-fa44f50bf5cb");
        returnMap.put("CLONEINSTANCEID","88fbeae3-3610-5e3f-b16a-7f5313cbb66a");
        returnMap.put("PLANNEDEVENTUUID","bd801991-4af6-11e9-9180-89b66dc892c1");
        returnMap.put("ALTKEY","sapem:10000000:Q8JCLNT767:DEL_NO:RH19052003");
        returnMap.put("TRACKEDPROCESSTYPE","com.sap.gtt.app.deliverysample.DeliveryModel.DeliveryProcess");
        mapList.add(returnMap);

        JdbcTemplate mockJdbcTemplate = Mockito.mock(JdbcTemplate.class);
        Whitebox.setInternalState(defaultOverdueDao,"jdbcTemplate",mockJdbcTemplate);
        Mockito.when(mockJdbcTemplate.queryForList(Mockito.anyString(),Mockito.any(Instant.class),Mockito.any(Instant.class),Mockito.anyInt(),Mockito.anyInt())).thenReturn(mapList);
        List<IOverdueManagement.PlannedEventIdentifier> plannedEventIdentifiers = defaultOverdueDao.
                getOverduePlannedEventsInfo(from,to,skip,top);
        System.out.println("plannedEventIdentifiers is " + plannedEventIdentifiers);
        Assert.assertEquals(1,plannedEventIdentifiers.size());
    }


    @Test
    public void testUpdateOverdueInfo(){
        Instant jobRunTime = Instant.ofEpochMilli(1596960000001l);
        //insert one record into the jobInfo table
        defaultOverdueDao.updateOverdueInfo(jobName,jobRunTime);
        Instant jobRunTimeUpdate = Instant.ofEpochMilli(1596960000002l);
        //update the jobInfo table to the new time:
        defaultOverdueDao.updateOverdueInfo(jobName,jobRunTimeUpdate);
        Instant actualPreviousDetectionTime = defaultOverdueDao.getPreviousDetectionTime(jobName);
        Assert.assertEquals(jobRunTimeUpdate,actualPreviousDetectionTime);
    }

}
