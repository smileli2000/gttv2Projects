package com.sap.gtt.v2.core.rule.impl;


import com.sap.gtt.v2.exception.GTTEmbededRuleScriptException;
import org.assertj.core.api.Assertions;
import org.junit.Test;

public class GTTEmbededRuleScriptExceptionTest {
    @Test
    public void test() {
        GTTEmbededRuleScriptException e = new GTTEmbededRuleScriptException(
                0,
                0,
                "a-reason",
                new NullPointerException()
        );

        Assertions.assertThat(e.getCharPositionInLine()).isEqualTo(0);
        Assertions.assertThat(e.getErrorReason()).isEqualTo("a-reason");
        Assertions.assertThat(e.getLine()).isEqualTo(0);
        Assertions.assertThat(e.getMessage()).isNotBlank();
    }
}