package com.sap.gtt.v2.core.dao.metering;

import com.sap.gtt.v2.BaseTest;
import com.sap.gtt.v2.Dummy;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.time.Clock;
import java.time.Instant;
import java.time.temporal.ChronoUnit;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = Dummy.class)
@ActiveProfiles("test")
public class DefaultMeteringDaoTest extends BaseTest {
    private DefaultMeteringDao meteringDao;

    @Before
    public void setUp() {
        super.setUp();
        meteringDao = DefaultMeteringDao.getInstance();
    }

    @Test
    public void test() {
        String jobName = "JobTest11";
        Instant now = Instant.now(Clock.systemUTC());
        Instant halfInstant = now.truncatedTo(ChronoUnit.HALF_DAYS);
        meteringDao.updateMeteringJobInfo(jobName, halfInstant);
        Instant rst = meteringDao.getPreviousMeteringTime(jobName);
        assertThat(rst).isEqualTo(halfInstant);
        assertThat(rst).isNotNull();
        meteringDao.updateMeteringJobInfo(jobName, halfInstant);
        meteringDao.countTP(halfInstant, now);
        meteringDao.countEvent(halfInstant, now);
    }
}
