package com.sap.gtt.v2.core.dao.tracking;

import com.sap.gtt.v2.Dummy;
import com.sap.gtt.v2.core.dao.metadata.*;
import com.sap.gtt.v2.core.domain.metadata.CurrentMetadataEntity;
import com.sap.gtt.v2.core.domain.metadata.MetadataConstants;
import com.sap.gtt.v2.core.entity.trackedprocess.Reference;
import com.sap.gtt.v2.core.management.metadata.DefaultMetadataManagement;
import com.sap.gtt.v2.core.management.metadata.IMetadataManagement;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.IOException;
import java.time.Instant;
import java.util.Arrays;
import java.util.UUID;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = Dummy.class)
@ActiveProfiles("test")
public class DefaultReferenceDaoTest {
    private IReferenceDao referenceDao;

    @Autowired
    private IMetadataDao metadataDao;

    @Autowired
    private ISysTableDao sysTableDao;

    @Test
    public void test() throws IOException {
        referenceDao = DefaultReferenceDao.getInstance();
        DefaultMetadataDaoTest test = new DefaultMetadataDaoTest();
        test.setDefaultMetadataDao((DefaultMetadataDao) metadataDao);
        test.insertMetadataProject();

        DefaultSysTableDaoTest test1 = new DefaultSysTableDaoTest();
        test1.setDefaultSysTableDao((DefaultSysTableDao) sysTableDao);
        test1.createTables();

        String entityName = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemEventForWrite";
        String namespace = "com.sap.gtt.app.mim";

        IMetadataManagement metadataManagement = DefaultMetadataManagement.getInstance();
        CurrentMetadataEntity metadata = metadataManagement.findAllEntitiesRecursively(namespace, entityName);
        metadata.setCurrentEntityName(MetadataConstants.CoreModelEntity.REFERENCE.getFullName());

        Reference reference = new Reference();
        reference.setMetadata(metadata);
        reference.setValidTo(Instant.now());
        reference.setValidFrom(Instant.now());
        reference.setReferenceType("");
        reference.setEventId(UUID.randomUUID());
        reference.setAltKey("");
        reference.setAction("ADD");
        reference.setId(UUID.randomUUID());
        referenceDao.insert(reference);

        reference.setId(UUID.randomUUID());
        referenceDao.insert(Arrays.asList(reference));

        referenceDao.update(reference);
        referenceDao.delete(reference.getMetadata(), reference.getId());
    }
}