package com.sap.gtt.v2.core.domain.trackedprocess;

import org.assertj.core.api.Assertions;
import org.junit.Test;

import static com.sap.gtt.v2.core.domain.trackedprocess.ObserveType.*;

public class ObserveTypeTest {

    @Test
    public void test() {
        ObserveType[] observeTypes = new ObserveType[] {
                PARENTSTART,  PARENTEND, CHILDSTART, CHILDEND, OBSERVE
        };

        for (ObserveType observeType:observeTypes) {
            Assertions.assertThat(ObserveType.fromValue(observeType.toString()))
                    .isEqualTo(observeType);

            Assertions.assertThat(ObserveType.revise(observeType)).isNotNull();
        }

        ObserveType observeType = ObserveType.fromActionReference(
                Action.ADD, ObjectReference.PARENT);
        Assertions.assertThat(observeType).isEqualTo(PARENTSTART);

        observeType = ObserveType.fromActionReference(
                Action.ADD, ObjectReference.CHILD);
        Assertions.assertThat(observeType).isEqualTo(CHILDSTART);

        observeType = ObserveType.fromActionReference(
                Action.DELETE, ObjectReference.PARENT);
        Assertions.assertThat(observeType).isEqualTo(PARENTEND);

        observeType = ObserveType.fromActionReference(
                Action.DELETE, ObjectReference.CHILD);
        Assertions.assertThat(observeType).isEqualTo(CHILDEND);

    }
}