package com.sap.gtt.v2.core.domain.trackedprocess;

import org.junit.Test;

import java.time.Instant;
import java.util.UUID;

public class CorrelatedEventInnerTest {

    @Test
    public void test() {
        CorrelatedEventInner inner = new CorrelatedEventInner();
        inner.setCorrelationType(CorrelationType.REPORTED.toString());
        inner.setActualBusinessTimestamp(Instant.now());
        inner.setActualBusinessTimeZone("UTC-8");
        inner.setActualTechnicalTimestamp(Instant.now());
        inner.setAltKey("");
        inner.setCloneInstanceId(UUID.randomUUID());
        inner.setEventMatchKey("");
        inner.setEventReasonText("");
        inner.setEventType("");
        inner.setId(UUID.randomUUID());
        inner.setLocationAltKey("");
        inner.setLogicalSystem("001");
        inner.setMessageSourceType("");
        inner.setPartyId("001");
        inner.setScheme("");
        inner.setSenderPartyId("001");
        inner.setSubaccountId(UUID.randomUUID());
        inner.setTrackingId("tracking-id");
        inner.setTrackingIdType("");

        inner.getCorrelationType();
        inner.getActualBusinessTimestamp();
        inner.getActualBusinessTimeZone();
        inner.getActualTechnicalTimestamp();
        inner.getAltKey();
        inner.getCloneInstanceId();
        inner.getEventMatchKey();
        inner.getEventReasonText();
        inner.getEventType();
        inner.getId();
        inner.getLocationAltKey();
        inner.getLogicalSystem();
        inner.getMessageSourceType();
        inner.getPartyId();
        inner.getScheme();
        inner.getSenderPartyId();
        inner.getSubaccountId();
        inner.getTrackingId();
        inner.getTrackingIdType();
    }
}