package com.sap.gtt.v2.core.management.overdue;

import com.sap.gtt.v2.Dummy;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.time.Instant;
import java.time.temporal.ChronoUnit;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = Dummy.class)
@ActiveProfiles("test")
public class DefaultOverdueManagementTest {

    @Autowired
    private DefaultOverdueManagement defaultOverdueManagement;
    @Test
    public void test() {
        defaultOverdueManagement.getOverdueDao();
        Instant to = Instant.now();
        Instant from = Instant.now().minus(3600, ChronoUnit.SECONDS);

        defaultOverdueManagement.countOverduePlannedEvent(from, to);
        defaultOverdueManagement.getOverduePlannedEventsInfo(from , to, 1, 1);
        defaultOverdueManagement.getPreviousDetectionTime("dummy");
        defaultOverdueManagement.updateOverdueInfo("dummy", from);
    }
}