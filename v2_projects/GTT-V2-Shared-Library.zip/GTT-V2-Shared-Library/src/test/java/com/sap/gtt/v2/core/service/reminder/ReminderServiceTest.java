package com.sap.gtt.v2.core.service.reminder;

import static org.powermock.api.mockito.PowerMockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.sap.gtt.v2.core.management.metadata.DefaultMetadataManagement;
import com.sap.gtt.v2.core.management.overdue.DefaultOverdueManagement;
import com.sap.gtt.v2.core.management.tracking.DefaultEventManagement;
import com.sap.gtt.v2.core.management.tracking.DefaultTrackedProcessManagement;
import com.sap.gtt.v2.log.TenantAwareLogService;
import com.sap.gtt.v2.util.SpringContextUtils;
import com.sap.gtt.v2.util.UaaUtils;

@RunWith(PowerMockRunner.class)
@PrepareForTest({SpringContextUtils.class, UaaUtils.class, DefaultTrackedProcessManagement.class, DefaultEventManagement.class, DefaultMetadataManagement.class, DefaultOverdueManagement.class})
public class ReminderServiceTest {
	@InjectMocks
	private ReminderServiceImpl service = new ReminderServiceImpl();
	@Mock
    private TenantAwareLogService log;
	
	@Before
	public void setUp() {
		PowerMockito.mockStatic(SpringContextUtils.class, UaaUtils.class, DefaultTrackedProcessManagement.class, DefaultEventManagement.class, DefaultMetadataManagement.class, DefaultOverdueManagement.class);
		when(SpringContextUtils.getBean(TenantAwareLogService.class)).thenReturn(log);
	}
	
	@Test
	public void testGenerateDirectMail() {
		service.generateDirectMail();
	}
	
	@Test
	public void testGenerateDirectMailTemplate() {
		service.generateDirectMailTemplate();
	}
}
