package com.sap.gtt.v2.core.management.tracking;

import com.sap.gtt.v2.core.dao.tracking.*;
import com.sap.gtt.v2.core.domain.metadata.CurrentMetadataEntity;
import com.sap.gtt.v2.core.domain.metadata.MetadataEntity;
import com.sap.gtt.v2.core.domain.metadata.PhysicalName;
import com.sap.gtt.v2.core.domain.trackedprocess.CorrelationType;
import com.sap.gtt.v2.core.entity.trackedprocess.PlannedEvent;
import com.sap.gtt.v2.core.entity.trackedprocess.ProcessEventDirectory;
import com.sap.gtt.v2.core.entity.trackedprocess.QualifiedTrackingId;
import com.sap.gtt.v2.core.entity.trackedprocess.TrackedProcess;
import com.sap.gtt.v2.core.management.metadata.CsnParser;
import com.sap.gtt.v2.core.management.metadata.DefaultMetadataManagement;
import com.sap.gtt.v2.core.runtime.model.IPropertyValue;
import com.sap.gtt.v2.core.runtime.model.ObjectValue;
import com.sap.gtt.v2.core.runtime.model.TimestampValue;
import com.sap.gtt.v2.core.runtime.model.UUIDValue;
import com.sap.gtt.v2.core.service.MessageUtil;
import com.sap.gtt.v2.exception.LockException;
import org.apache.commons.io.IOUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.dao.CannotAcquireLockException;

import java.io.IOException;
import java.nio.charset.Charset;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.*;

@RunWith(PowerMockRunner.class)
@PrepareForTest({DefaultTrackedProcessDao.class, DefaultPlannedEventDao.class, DefaultQualifiedTrackingIdDao.class,
        DefaultEventDao.class, DefaultProcessEventDirectoryDao.class, DefaultMetadataManagement.class,
        DefaultCoreModelDataProcessDao.class, MessageUtil.class})
public class DefaultTrackedProcessManagementTest {

    @Mock
    private DefaultTrackedProcessDao defaultTrackedProcessDao;
    @Mock
    private DefaultCoreModelDataProcessDao defaultCoreModelDataProcessDao;
    @Mock
    private DefaultPlannedEventDao defaultPlannedEventDao;
    @Mock
    private DefaultQualifiedTrackingIdDao defaultQualifiedTrackingIdDao;
    @Mock
    private DefaultEventDao defaultEventDao;
    @Mock
    private DefaultProcessEventDirectoryDao defaultProcessEventDirectoryDao;
    @Mock
    private DefaultMetadataManagement defaultMetadataManagement;
    private String derivedCsnFile = "derived_csn.json";
    private Map<String, MetadataEntity> entityMap;

    private DefaultTrackedProcessManagement trackedProcessManagement;

    @Before
    public void setup() throws IOException {
        PowerMockito.mockStatic(DefaultTrackedProcessDao.class, DefaultPlannedEventDao.class,
                DefaultQualifiedTrackingIdDao.class, DefaultEventDao.class, DefaultProcessEventDirectoryDao.class,
                DefaultMetadataManagement.class, DefaultCoreModelDataProcessDao.class, MessageUtil.class);
        PowerMockito.when(DefaultTrackedProcessDao.getInstance()).thenReturn(defaultTrackedProcessDao);
        PowerMockito.when(DefaultCoreModelDataProcessDao.getInstance()).thenReturn(defaultCoreModelDataProcessDao);
        PowerMockito.when(DefaultPlannedEventDao.getInstance()).thenReturn(defaultPlannedEventDao);
        PowerMockito.when(DefaultQualifiedTrackingIdDao.getInstance()).thenReturn(defaultQualifiedTrackingIdDao);
        PowerMockito.when(DefaultEventDao.getInstance()).thenReturn(defaultEventDao);
        PowerMockito.when(DefaultProcessEventDirectoryDao.getInstance()).thenReturn(defaultProcessEventDirectoryDao);
        PowerMockito.when(DefaultMetadataManagement.getInstance()).thenReturn(defaultMetadataManagement);
        trackedProcessManagement = new DefaultTrackedProcessManagement();
        String derivedCsn = IOUtils.toString(getClass().getClassLoader()
                .getResourceAsStream(derivedCsnFile), Charset.defaultCharset());
        entityMap = CsnParser.parseToEntityMap(derivedCsn);
    }

    private CurrentMetadataEntity getMetadata(String entityName) {
        CurrentMetadataEntity currentMetadataEntity = new CurrentMetadataEntity();
        currentMetadataEntity.setCurrentEntityName(entityName);
        currentMetadataEntity.setAllRelatedEntityMap(entityMap);
        return currentMetadataEntity;
    }

    @Test
    public void testCreate() throws Exception {
        TrackedProcess trackedProcess = new TrackedProcess();
        trackedProcess.setValue(TrackedProcess.ID, "123");
        List<IPropertyValue> trackingIds = new ArrayList<>();
        QualifiedTrackingId trackingId = new QualifiedTrackingId();
        trackingIds.add(trackingId);
        trackedProcess.setValue(TrackedProcess.TRACKING_IDS, trackingIds);
        List<IPropertyValue> peds = new ArrayList<>();
        ProcessEventDirectory ped = new ProcessEventDirectory();
        peds.add(ped);
        trackedProcess.setValue(TrackedProcess.PROCESS_EVENT_DIRECTORIES, peds);

        List<IPropertyValue> plannedEvents = new ArrayList<>();
        PlannedEvent plannedEvent = new PlannedEvent();
        plannedEvents.add(plannedEvent);
        trackedProcess.setValue(TrackedProcess.PLANNED_EVENTS, plannedEvents);
        PowerMockito.doReturn(false).when(MessageUtil.class, "isNull", Mockito.any(ObjectValue.class), Mockito.anyString());
        trackedProcessManagement.create(trackedProcess);
        verify(defaultTrackedProcessDao, times(1)).insert(Mockito.any(TrackedProcess.class));
        verify(defaultQualifiedTrackingIdDao, times(1)).insert(Mockito.anyList());
        verify(defaultProcessEventDirectoryDao, times(1)).insert(Mockito.anyList());
        verify(defaultPlannedEventDao, times(1)).insert(Mockito.anyList());
    }

    @Test
    public void testCreateWithoutPlannedEvents() throws Exception {
        TrackedProcess trackedProcess = new TrackedProcess();
        trackedProcess.setValue(TrackedProcess.ID, "123");
        List<IPropertyValue> trackingIds = new ArrayList<>();
        QualifiedTrackingId trackingId = new QualifiedTrackingId();
        trackingIds.add(trackingId);
        trackedProcess.setValue(TrackedProcess.TRACKING_IDS, trackingIds);
        List<IPropertyValue> peds = new ArrayList<>();
        ProcessEventDirectory ped = new ProcessEventDirectory();
        peds.add(ped);
        trackedProcess.setValue(TrackedProcess.PROCESS_EVENT_DIRECTORIES, peds);
        PowerMockito.doReturn(true).when(MessageUtil.class, "isNull", Mockito.any(ObjectValue.class), Mockito.anyString());
        trackedProcessManagement.create(trackedProcess);
        verify(defaultTrackedProcessDao, times(1)).insert(Mockito.any(TrackedProcess.class));
        verify(defaultQualifiedTrackingIdDao, times(1)).insert(Mockito.anyList());
        verify(defaultProcessEventDirectoryDao, times(1)).insert(Mockito.anyList());
        verify(defaultPlannedEventDao, times(0)).insert(Mockito.anyList());
    }

    @Test
    public void testUpdate() {
        TrackedProcess trackedProcess = new TrackedProcess();
        trackedProcess.setId(UUID.randomUUID());
        trackedProcess.setVersion(0);
        List<IPropertyValue> trackingIds = new ArrayList<>();
        QualifiedTrackingId trackingId = new QualifiedTrackingId();
        trackingIds.add(trackingId);
        trackedProcess.setValue(TrackedProcess.TRACKING_IDS, trackingIds);
        List<IPropertyValue> peds = new ArrayList<>();
        ProcessEventDirectory ped = new ProcessEventDirectory();
        peds.add(ped);
        trackedProcess.setValue(TrackedProcess.PROCESS_EVENT_DIRECTORIES, peds);

        List<IPropertyValue> plannedEvents = new ArrayList<>();
        PlannedEvent plannedEvent = new PlannedEvent();
        plannedEvents.add(plannedEvent);
        trackedProcess.setValue(TrackedProcess.PLANNED_EVENTS, plannedEvents);

        given(defaultTrackedProcessDao.versionExists(Mockito.any(TrackedProcess.class), Mockito.anyInt())).willReturn(true);

        trackedProcessManagement.update(trackedProcess, ped, plannedEvent);
        verify(defaultTrackedProcessDao, times(1)).insert(Mockito.any(TrackedProcess.class));
        verify(defaultQualifiedTrackingIdDao, times(1)).insert(Mockito.anyList());
        verify(defaultProcessEventDirectoryDao, times(1)).insert(Mockito.any(ProcessEventDirectory.class));
        verify(defaultPlannedEventDao, times(1)).update(Mockito.any(PlannedEvent.class));
    }

    @Test
    public void testUpdateWhenPEDAndPlannedEventNull() {
        TrackedProcess trackedProcess = new TrackedProcess();
        trackedProcess.setId(UUID.randomUUID());
        trackedProcess.setVersion(0);
        List<IPropertyValue> trackingIds = new ArrayList<>();
        QualifiedTrackingId trackingId = new QualifiedTrackingId();
        trackingIds.add(trackingId);
        trackedProcess.setValue(TrackedProcess.TRACKING_IDS, trackingIds);
        List<IPropertyValue> peds = new ArrayList<>();
        ProcessEventDirectory ped = new ProcessEventDirectory();
        peds.add(ped);
        trackedProcess.setValue(TrackedProcess.PROCESS_EVENT_DIRECTORIES, peds);

        List<IPropertyValue> plannedEvents = new ArrayList<>();
        PlannedEvent plannedEvent = new PlannedEvent();
        plannedEvents.add(plannedEvent);
        trackedProcess.setValue(TrackedProcess.PLANNED_EVENTS, plannedEvents);

        given(defaultTrackedProcessDao.versionExists(Mockito.any(TrackedProcess.class), Mockito.anyInt())).willReturn(true);

        trackedProcessManagement.update(trackedProcess, null, null);
        verify(defaultTrackedProcessDao, times(1)).insert(Mockito.any(TrackedProcess.class));
        verify(defaultQualifiedTrackingIdDao, times(1)).insert(Mockito.anyList());
        verify(defaultProcessEventDirectoryDao, times(0)).insert(Mockito.any(ProcessEventDirectory.class));
        verify(defaultPlannedEventDao, times(0)).update(Mockito.any(PlannedEvent.class));
        verify(defaultPlannedEventDao, times(0)).insert(Mockito.anyList());
    }

    @Test
    public void testUpdateWhenPEDIsUnplannedEventAndPlannedEventNull() {
        TrackedProcess trackedProcess = new TrackedProcess();
        trackedProcess.setId(UUID.randomUUID());
        trackedProcess.setVersion(0);
        List<IPropertyValue> trackingIds = new ArrayList<>();
        QualifiedTrackingId trackingId = new QualifiedTrackingId();
        trackingIds.add(trackingId);
        trackedProcess.setValue(TrackedProcess.TRACKING_IDS, trackingIds);
        List<IPropertyValue> peds = new ArrayList<>();
        ProcessEventDirectory ped = new ProcessEventDirectory();
        ped.setCorrelationType(CorrelationType.UNPLANNED.name());
        peds.add(ped);
        trackedProcess.setValue(TrackedProcess.PROCESS_EVENT_DIRECTORIES, peds);

        List<IPropertyValue> plannedEvents = new ArrayList<>();
        PlannedEvent plannedEvent = new PlannedEvent();
        plannedEvents.add(plannedEvent);
        trackedProcess.setValue(TrackedProcess.PLANNED_EVENTS, plannedEvents);

        given(defaultTrackedProcessDao.versionExists(Mockito.any(TrackedProcess.class), Mockito.anyInt())).willReturn(true);

        trackedProcessManagement.update(trackedProcess, ped, null);
        verify(defaultTrackedProcessDao, times(1)).insert(Mockito.any(TrackedProcess.class));
        verify(defaultQualifiedTrackingIdDao, times(1)).insert(Mockito.anyList());
        verify(defaultProcessEventDirectoryDao, times(1)).insert(Mockito.any(ProcessEventDirectory.class));
        verify(defaultPlannedEventDao, times(0)).update(Mockito.any(PlannedEvent.class));
        verify(defaultPlannedEventDao, times(0)).insert(Mockito.anyList());
    }

    @Test
    public void testUpdateWhenPEDIsProcessEventAndPlannedEventNull() {
        TrackedProcess trackedProcess = new TrackedProcess();
        trackedProcess.setId(UUID.randomUUID());
        trackedProcess.setVersion(0);
        trackedProcess.setTrackedProcessType("com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess");
        trackedProcess.setMetadata(getMetadata(trackedProcess.getTrackedProcessType()));
        List<IPropertyValue> trackingIds = new ArrayList<>();
        QualifiedTrackingId trackingId = new QualifiedTrackingId();
        trackingIds.add(trackingId);
        trackedProcess.setValue(TrackedProcess.TRACKING_IDS, trackingIds);
        List<IPropertyValue> peds = new ArrayList<>();
        ProcessEventDirectory ped = new ProcessEventDirectory();
        ped.setCorrelationType(CorrelationType.UNPLANNED_PROCESS_CREATION_UPDATE.name());
        peds.add(ped);
        trackedProcess.setValue(TrackedProcess.PROCESS_EVENT_DIRECTORIES, peds);

        List<IPropertyValue> plannedEvents = new ArrayList<>();
        PlannedEvent plannedEvent = new PlannedEvent();
        plannedEvents.add(plannedEvent);
        trackedProcess.setValue(TrackedProcess.PLANNED_EVENTS, plannedEvents);

        given(defaultTrackedProcessDao.versionExists(Mockito.any(TrackedProcess.class), Mockito.anyInt())).willReturn(true);

        trackedProcessManagement.update(trackedProcess, ped, null);
        verify(defaultTrackedProcessDao, times(1)).insert(Mockito.any(TrackedProcess.class));
        verify(defaultQualifiedTrackingIdDao, times(1)).insert(Mockito.anyList());
        verify(defaultProcessEventDirectoryDao, times(1)).insert(Mockito.any(ProcessEventDirectory.class));
        verify(defaultPlannedEventDao, times(0)).update(Mockito.any(PlannedEvent.class));
        verify(defaultPlannedEventDao, times(1)).deleteByProcessId(Mockito.any(UUID.class), Mockito.any(PhysicalName.class));
        verify(defaultPlannedEventDao, times(1)).insert(Mockito.anyList());
    }

    @Test
    public void testUpdateForEvent2Action() throws Exception {
        TrackedProcess trackedProcess = new TrackedProcess();
        trackedProcess.setId(UUID.randomUUID());
        trackedProcess.setVersion(0);
        trackedProcess.setTrackedProcessType("com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess");
        trackedProcess.setMetadata(getMetadata(trackedProcess.getTrackedProcessType()));
        List<IPropertyValue> trackingIds = new ArrayList<>();
        QualifiedTrackingId trackingId = new QualifiedTrackingId();
        trackingIds.add(trackingId);
        trackedProcess.setValue(TrackedProcess.TRACKING_IDS, trackingIds);
        List<IPropertyValue> peds = new ArrayList<>();
        ProcessEventDirectory ped = new ProcessEventDirectory();
        peds.add(ped);
        trackedProcess.setValue(TrackedProcess.PROCESS_EVENT_DIRECTORIES, peds);

        List<IPropertyValue> plannedEvents = new ArrayList<>();
        PlannedEvent plannedEvent = new PlannedEvent();
        plannedEvents.add(plannedEvent);
        trackedProcess.setValue(TrackedProcess.PLANNED_EVENTS, plannedEvents);

        given(defaultTrackedProcessDao.versionExists(Mockito.any(TrackedProcess.class), Mockito.anyInt())).willReturn(true);
        PowerMockito.doNothing().when(MessageUtil.class, "fillMetadata", Mockito.any(ObjectValue.class));
        trackedProcessManagement.update(trackedProcess, true, true);
        verify(defaultTrackedProcessDao, times(1)).delete(Mockito.any(), Mockito.any(UUID.class));
        verify(defaultTrackedProcessDao, times(1)).insert(Mockito.any(TrackedProcess.class));
        verify(defaultQualifiedTrackingIdDao, times(1)).deleteByProcessId(Mockito.any(UUID.class));
        verify(defaultQualifiedTrackingIdDao, times(1)).insert(Mockito.anyList());
        verify(defaultPlannedEventDao, times(1)).deleteByProcessId(Mockito.any(UUID.class), Mockito.any(PhysicalName.class));
        verify(defaultPlannedEventDao, times(1)).insert(Mockito.anyList());
    }

    @Test
    public void testUpdateForEvent2ActionWhenIsUpdateTrackingIdsIsFalse() throws Exception {
        TrackedProcess trackedProcess = new TrackedProcess();
        trackedProcess.setId(UUID.randomUUID());
        trackedProcess.setVersion(0);
        trackedProcess.setTrackedProcessType("com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess");
        trackedProcess.setMetadata(getMetadata(trackedProcess.getTrackedProcessType()));
        List<IPropertyValue> trackingIds = new ArrayList<>();
        QualifiedTrackingId trackingId = new QualifiedTrackingId();
        trackingIds.add(trackingId);
        trackedProcess.setValue(TrackedProcess.TRACKING_IDS, trackingIds);
        List<IPropertyValue> peds = new ArrayList<>();
        ProcessEventDirectory ped = new ProcessEventDirectory();
        peds.add(ped);
        trackedProcess.setValue(TrackedProcess.PROCESS_EVENT_DIRECTORIES, peds);

        List<IPropertyValue> plannedEvents = new ArrayList<>();
        PlannedEvent plannedEvent = new PlannedEvent();
        plannedEvents.add(plannedEvent);
        trackedProcess.setValue(TrackedProcess.PLANNED_EVENTS, plannedEvents);

        given(defaultTrackedProcessDao.versionExists(Mockito.any(TrackedProcess.class), Mockito.anyInt())).willReturn(true);
        PowerMockito.doNothing().when(MessageUtil.class, "fillMetadata", Mockito.any(ObjectValue.class));
        trackedProcessManagement.update(trackedProcess, false, true);
        verify(defaultTrackedProcessDao, times(1)).delete(Mockito.any(), Mockito.any(UUID.class));
        verify(defaultTrackedProcessDao, times(1)).insert(Mockito.any(TrackedProcess.class));
        verify(defaultQualifiedTrackingIdDao, times(0)).deleteByProcessId(Mockito.any(UUID.class));
        verify(defaultQualifiedTrackingIdDao, times(0)).insert(Mockito.anyList());
        verify(defaultPlannedEventDao, times(1)).deleteByProcessId(Mockito.any(UUID.class), Mockito.any(PhysicalName.class));
        verify(defaultPlannedEventDao, times(1)).insert(Mockito.anyList());
    }

    @Test
    public void testUpdateForEvent2ActionWhenIsUpdatePlannedEventsIsFalse() throws Exception {
        TrackedProcess trackedProcess = new TrackedProcess();
        trackedProcess.setId(UUID.randomUUID());
        trackedProcess.setVersion(0);
        List<IPropertyValue> trackingIds = new ArrayList<>();
        QualifiedTrackingId trackingId = new QualifiedTrackingId();
        trackingIds.add(trackingId);
        trackedProcess.setValue(TrackedProcess.TRACKING_IDS, trackingIds);
        List<IPropertyValue> peds = new ArrayList<>();
        ProcessEventDirectory ped = new ProcessEventDirectory();
        peds.add(ped);
        trackedProcess.setValue(TrackedProcess.PROCESS_EVENT_DIRECTORIES, peds);

        List<IPropertyValue> plannedEvents = new ArrayList<>();
        PlannedEvent plannedEvent = new PlannedEvent();
        plannedEvents.add(plannedEvent);
        trackedProcess.setValue(TrackedProcess.PLANNED_EVENTS, plannedEvents);

        given(defaultTrackedProcessDao.versionExists(Mockito.any(TrackedProcess.class), Mockito.anyInt())).willReturn(true);
        PowerMockito.doNothing().when(MessageUtil.class, "fillMetadata", Mockito.any(ObjectValue.class));
        trackedProcessManagement.update(trackedProcess, true, false);
        verify(defaultTrackedProcessDao, times(1)).delete(Mockito.any(), Mockito.any(UUID.class));
        verify(defaultTrackedProcessDao, times(1)).insert(Mockito.any(TrackedProcess.class));
        verify(defaultQualifiedTrackingIdDao, times(1)).deleteByProcessId(Mockito.any(UUID.class));
        verify(defaultQualifiedTrackingIdDao, times(1)).insert(Mockito.anyList());
        verify(defaultPlannedEventDao, times(0)).deleteByProcessId(Mockito.any(UUID.class), Mockito.any(PhysicalName.class));
        verify(defaultPlannedEventDao, times(0)).insert(Mockito.anyList());
    }

    @Test
    public void testLockExceptionWhenVersionNotExist() {
        TrackedProcess trackedProcess = new TrackedProcess();
        trackedProcess.setId(UUID.randomUUID());
        trackedProcess.setVersion(0);
        List<IPropertyValue> trackingIds = new ArrayList<>();
        QualifiedTrackingId trackingId = new QualifiedTrackingId();
        trackingIds.add(trackingId);
        trackedProcess.setValue(TrackedProcess.TRACKING_IDS, trackingIds);
        List<IPropertyValue> peds = new ArrayList<>();
        ProcessEventDirectory ped = new ProcessEventDirectory();
        peds.add(ped);
        trackedProcess.setValue(TrackedProcess.PROCESS_EVENT_DIRECTORIES, peds);

        List<IPropertyValue> plannedEvents = new ArrayList<>();
        PlannedEvent plannedEvent = new PlannedEvent();
        plannedEvents.add(plannedEvent);
        trackedProcess.setValue(TrackedProcess.PLANNED_EVENTS, plannedEvents);

        given(defaultTrackedProcessDao.versionExists(Mockito.any(TrackedProcess.class), Mockito.anyInt())).willReturn(false);
        try {
            trackedProcessManagement.update(trackedProcess, ped, plannedEvent);
        } catch (LockException e) {
            assertThat(e.getMessageCode()).isEqualTo(LockException.MESSAGE_CODE_PROCESS_HAS_BEEN_CHANGED);
        }
    }

    @Test
    public void testLockExceptionWhenResourceBusy() {
        TrackedProcess trackedProcess = new TrackedProcess();
        trackedProcess.setId(UUID.randomUUID());
        trackedProcess.setVersion(0);
        List<IPropertyValue> trackingIds = new ArrayList<>();
        QualifiedTrackingId trackingId = new QualifiedTrackingId();
        trackingIds.add(trackingId);
        trackedProcess.setValue(TrackedProcess.TRACKING_IDS, trackingIds);
        List<IPropertyValue> peds = new ArrayList<>();
        ProcessEventDirectory ped = new ProcessEventDirectory();
        peds.add(ped);
        trackedProcess.setValue(TrackedProcess.PROCESS_EVENT_DIRECTORIES, peds);

        List<IPropertyValue> plannedEvents = new ArrayList<>();
        PlannedEvent plannedEvent = new PlannedEvent();
        plannedEvents.add(plannedEvent);
        trackedProcess.setValue(TrackedProcess.PLANNED_EVENTS, plannedEvents);

        given(defaultTrackedProcessDao.versionExists(Mockito.any(TrackedProcess.class), Mockito.anyInt()))
                .willThrow(new CannotAcquireLockException(""));
        try {
            trackedProcessManagement.update(trackedProcess, ped, plannedEvent);
        } catch (LockException e) {
            assertThat(e.getMessageCode()).isEqualTo(LockException.MESSAGE_CODE_RESOURCE_BUSY);
        }
    }

    @Test
    public void testDelete() {
        TrackedProcess trackedProcess = new TrackedProcess();
        trackedProcess.setId(UUID.randomUUID());
        trackedProcess.setVersion(0);
        trackedProcess.setAltKey("altkey");
        trackedProcess.setTrackedProcessType("com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess");
        trackedProcess.setMetadata(getMetadata(trackedProcess.getTrackedProcessType()));
        List<IPropertyValue> trackingIds = new ArrayList<>();
        QualifiedTrackingId trackingId = new QualifiedTrackingId();
        trackingIds.add(trackingId);
        trackedProcess.setValue(TrackedProcess.TRACKING_IDS, trackingIds);
        List<ProcessEventDirectory> peds = new ArrayList<>();
        ProcessEventDirectory ped = new ProcessEventDirectory();
        ped.setCorrelationType(CorrelationType.UNPLANNED_PROCESS_CREATION_UPDATE.name());
        peds.add(ped);
        trackedProcess.setPEDs(peds);

        List<PlannedEvent> plannedEvents = new ArrayList<>();
        PlannedEvent plannedEvent = new PlannedEvent();
        plannedEvents.add(plannedEvent);
        trackedProcess.setPlannedEvents(plannedEvents);
        trackedProcessManagement.delete(trackedProcess);
        verify(this.defaultPlannedEventDao, times(1)).deleteByProcessId(Mockito.any(), Mockito.any(PhysicalName.class));
        verify(this.defaultProcessEventDirectoryDao, times(1)).deleteByProcessId(Mockito.any());
        verify(this.defaultQualifiedTrackingIdDao, times(1)).deleteByProcessId(Mockito.any());
        verify(this.defaultTrackedProcessDao, times(1)).delete(Mockito.any(CurrentMetadataEntity.class), Mockito.any());
    }

    @Test
    public void testFindByUUIDOnly() {
        TrackedProcess trackedProcess = new TrackedProcess();
        trackedProcess.setTrackedProcessType("com.sap.gtt.app.tfo.FreightOrderModel.FreightOrderProcess");
        given(defaultTrackedProcessDao.findOne(Mockito.any(UUID.class))).willReturn(trackedProcess);
        CurrentMetadataEntity metadata = mock(CurrentMetadataEntity.class);
        given(defaultMetadataManagement.findAllEntitiesRecursively(Mockito.anyString(), Mockito.anyString())).willReturn(metadata);
        TrackedProcess trackedProcess1 = new TrackedProcess();
        given(defaultTrackedProcessDao.findOne(Mockito.any(CurrentMetadataEntity.class), Mockito.any(UUID.class))).willReturn(trackedProcess1);
        TrackedProcess rst = trackedProcessManagement.get(UUIDValue.valueOf(UUID.randomUUID()));
        assertThat(rst).isEqualTo(trackedProcess1);
    }

    @Test
    public void testFindByUUIDOnlyWithOnlyValidDPPStatus() {
        TrackedProcess trackedProcess = new TrackedProcess();
        trackedProcess.setTrackedProcessType("com.sap.gtt.app.tfo.FreightOrderModel.FreightOrderProcess");
        given(defaultTrackedProcessDao.findOneWithValidStatus(Mockito.any(UUID.class))).willReturn(trackedProcess);
        CurrentMetadataEntity metadata = mock(CurrentMetadataEntity.class);
        given(defaultMetadataManagement.findAllEntitiesRecursively(Mockito.anyString(), Mockito.anyString())).willReturn(metadata);
        TrackedProcess trackedProcess1 = new TrackedProcess();
        given(defaultTrackedProcessDao.findOne(Mockito.any(CurrentMetadataEntity.class), Mockito.any(UUID.class))).willReturn(trackedProcess1);
        TrackedProcess rst = trackedProcessManagement.getWithOnlyValidDPPStatus(UUIDValue.valueOf(UUID.randomUUID()));
        assertThat(rst).isEqualTo(trackedProcess1);
    }

    @Test
    public void testFindByMetadataAndUUID() {
        TrackedProcess trackedProcess = new TrackedProcess();
        trackedProcess.setTrackedProcessType("com.sap.gtt.app.tfo.FreightOrderModel.FreightOrderProcess");
        given(defaultTrackedProcessDao.findOne(Mockito.any(CurrentMetadataEntity.class), Mockito.any(UUID.class))).willReturn(trackedProcess);
        TrackedProcess rst = trackedProcessManagement.get(new CurrentMetadataEntity(), UUIDValue.valueOf(UUID.randomUUID()));
        assertThat(rst).isEqualTo(trackedProcess);
    }

    @Test
    public void testCorrelatedProcessId() {
        UUID id = UUID.randomUUID();
        List<UUID> uuids = new ArrayList<>();
        uuids.add(id);
        given(defaultQualifiedTrackingIdDao.getCorrelatedProcessId(Mockito.any(UUID.class), Mockito.any(Instant.class),
                Mockito.anyInt())).willReturn(uuids);
        List<UUIDValue> rst = trackedProcessManagement.getCorrelatedProcessId(UUIDValue.valueOf(UUID.randomUUID()),
                TimestampValue.valueOf(Instant.now()), 1);
        assertThat(rst.get(0).getInternalValue()).isEqualTo(id);
    }

    @Test
    public void testDeleteAllTheTrackedProcessByNamespace() {
        String namespace = "com.sap.gtt.app.tfo";
        trackedProcessManagement.deleteAllTheTrackedProcessByNamespace(namespace);
        verify(defaultCoreModelDataProcessDao, times(1)).deleteAllCoreModelData(eq(namespace));
    }
}
