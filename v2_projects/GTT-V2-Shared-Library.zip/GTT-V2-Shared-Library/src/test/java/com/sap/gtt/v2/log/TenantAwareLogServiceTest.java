package com.sap.gtt.v2.log;

import com.sap.gtt.v2.BaseTest;
import com.sap.gtt.v2.Dummy;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

//@Ignore
@RunWith(SpringRunner.class)
@SpringBootTest(classes = Dummy.class)
@ActiveProfiles("test")
public class TenantAwareLogServiceTest extends BaseTest {


    @Test
    public void info() {
        logService.info("first log");
        logService.info("second log with parameter: {}", "good");
    }

    @Test
    public void debug() {
        logService.debug("first log");
        logService.debug("second log with parameter: {}", "good");
    }

    @Test
    public void warn() {
        logService.warn("first log");
        logService.warn("second log with parameter: {}", "good");
    }

    @Test
    public void error() {
        logService.error("first log");
        logService.error("second log with parameter: {}", "good");
    }

    @Test
    public void testEx() {
        logService.debug("", new Exception("test debug"));
        logService.info("", new Exception("test info"));
        logService.error("", new Exception("test error"));
        logService.warn("", new Exception("test warn"));
        logService.trace("", new Exception("test trace 1"));
        logService.trace("{}", "test trace 2");
    }


}