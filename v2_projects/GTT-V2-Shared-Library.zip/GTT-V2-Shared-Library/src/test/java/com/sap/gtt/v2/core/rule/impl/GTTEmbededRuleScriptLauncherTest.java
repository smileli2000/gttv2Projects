package com.sap.gtt.v2.core.rule.impl;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeoutException;

import com.sap.gtt.v2.configuration.AccessContextHolder;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.junit.After;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.sap.gtt.v2.BaseTest;
import com.sap.gtt.v2.Dummy;
import com.sap.gtt.v2.core.entity.trackedprocess.TrackedProcess;
import com.sap.gtt.v2.util.GTTUtils;

import static org.mockito.BDDMockito.given;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = Dummy.class)
@ActiveProfiles("test")
public class GTTEmbededRuleScriptLauncherTest extends BaseTest{

	@Autowired
	private  GTTEmbededRuleScriptLauncher scriptLauncher;

	@MockBean
	private AccessContextHolder.AccessContext  accessContext;
	
	
	
	private ByteArrayOutputStream byteArrayOutputStream;
	
	@Override
	public void setUp(){
		super.setUp();
		byteArrayOutputStream = new ByteArrayOutputStream();
		given(accessContext.getLocale()).willReturn(null);
	}
	
	@After
	public void tearDown() throws IOException{
		if(byteArrayOutputStream != null){
			byteArrayOutputStream.close();
		}
	}
	
	@Test
	public void declareStatement() throws IOException, ExecutionException, InterruptedException {
		String script = IOUtils.toString(this.getClass().getResource("declareStatement.txt"), GTTUtils.DEFAULT_CHARSET_ENCODING);
		Future<String> futureTask = scriptLauncher.execute(script,new PrintStream(byteArrayOutputStream),null ,null,null ,null ,null ,accessContext);
		futureTask.get();
		System.out.println(byteArrayOutputStream.toString());
	}

	@Test
	public void ifStatement() throws IOException, ExecutionException, InterruptedException {
		String script = IOUtils.toString(this.getClass().getResource("ifStatement.txt"), GTTUtils.DEFAULT_CHARSET_ENCODING);
		Future<String> futureTask = scriptLauncher.execute(script,new PrintStream(byteArrayOutputStream),null ,null,null ,null ,null ,accessContext );
		futureTask.get();
		String output = byteArrayOutputStream.toString();
		System.out.println(output);
		Assert.assertFalse(StringUtils.contains(output, "false"));

	}

	@Test
	public void array() throws IOException, ExecutionException, InterruptedException {
		String script = IOUtils.toString(this.getClass().getResource("array.txt"), GTTUtils.DEFAULT_CHARSET_ENCODING);
		Future<String> futureTask = scriptLauncher.execute(script,new PrintStream(byteArrayOutputStream),null ,null,null ,null ,null ,accessContext );
		futureTask.get();
		String output = byteArrayOutputStream.toString();
		System.out.println(output);
		Assert.assertFalse(StringUtils.contains(output, "false"));

	}

	@Test
	public void functions() throws IOException, ExecutionException, InterruptedException, TimeoutException {
		String script = IOUtils.toString(this.getClass().getResource("functions.script"), GTTUtils.DEFAULT_CHARSET_ENCODING);
		Future<String> futureTask = scriptLauncher.execute(script,new PrintStream(byteArrayOutputStream),null,new TrackedProcess(),null,null,null,accessContext);
		futureTask.get();
		String output = byteArrayOutputStream.toString();
		System.out.println(output);
		Assert.assertTrue(StringUtils.contains(output, "00000000-0000-0000-0000-000000000000"));
		Assert.assertTrue(StringUtils.contains(output, "2010-05-04"));
		Assert.assertTrue(StringUtils.contains(output, "2013-06-25T16:22:52.966Z"));
	}

	@Test
	public void assignment() throws IOException, ExecutionException, InterruptedException {
		String script = IOUtils.toString(this.getClass().getResource("assignment.script"), GTTUtils.DEFAULT_CHARSET_ENCODING);
		Future<String> futureTask = scriptLauncher.execute(script,new PrintStream(byteArrayOutputStream),null ,null,null ,null ,null ,accessContext );
		futureTask.get();
		String output = byteArrayOutputStream.toString();
		System.out.println(output);
		Assert.assertTrue(StringUtils.contains(output, "10"));
		Assert.assertTrue(StringUtils.contains(output, "[1,{\"test\":\"aaa\"}]"));
		Assert.assertTrue(StringUtils.contains(output, "{\"y\":[{\"b\":{\"c\":10}},{\"c\":[1,{\"test\":\"aaa\"}]},{\"test\":\"aaa\"}]}"));
		Assert.assertTrue(StringUtils.contains(output, "[{\"zero\":\"zero\"},{\"one\":1}]"));

	}

	@Test
	public void expr() throws IOException, ExecutionException, InterruptedException {
		String script = IOUtils.toString(this.getClass().getResource("expr.script"), GTTUtils.DEFAULT_CHARSET_ENCODING);
		Future<String> futureTask = scriptLauncher.execute(script,new PrintStream(byteArrayOutputStream),null ,null,null ,null ,null ,accessContext);
		futureTask.get();
		String output = byteArrayOutputStream.toString();
		//System.out.println(output);
		Assert.assertTrue(StringUtils.contains(output, "4"));
		Assert.assertTrue(StringUtils.contains(output, "13"));
		Assert.assertTrue(StringUtils.contains(output, "8.0"));
        Assert.assertFalse(StringUtils.contains(output, "false"));
	}
}
