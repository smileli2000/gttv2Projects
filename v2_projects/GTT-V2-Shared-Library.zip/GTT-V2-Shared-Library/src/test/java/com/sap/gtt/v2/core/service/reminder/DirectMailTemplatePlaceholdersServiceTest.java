package com.sap.gtt.v2.core.service.reminder;

import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.BDDMockito;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;

import com.sap.gtt.v2.configuration.AccessContextHolder;
import com.sap.gtt.v2.configuration.AccessContextHolder.AccessContext;
import com.sap.gtt.v2.configuration.GTTRestTemplate;
import com.sap.gtt.v2.configuration.ServiceInstancesMapping;
import com.sap.gtt.v2.bp.BPContactInfo;
import com.sap.gtt.v2.bp.BusinessPartnerService;
import com.sap.gtt.v2.configuration.EnvironmentsConfiguration.VcapServiceParser.ReminderServiceInstance;
import com.sap.gtt.v2.configuration.ISAPCloudPlatformAgent.ICurrentAccessContext;
import com.sap.gtt.v2.configuration.local.LocalMockedCurrentAccessContext;
import com.sap.gtt.v2.core.management.metadata.DefaultMetadataManagement;
import com.sap.gtt.v2.core.management.overdue.DefaultOverdueManagement;
import com.sap.gtt.v2.core.management.tracking.DefaultEventManagement;
import com.sap.gtt.v2.core.management.tracking.DefaultTrackedProcessManagement;
import com.sap.gtt.v2.log.TenantAwareLogService;
import com.sap.gtt.v2.util.SpringContextUtils;
import com.sap.gtt.v2.util.UaaUtils;
import com.sap.xs2.security.container.SecurityContext;
import com.sap.xs2.security.container.UserInfo;

@RunWith(PowerMockRunner.class)
@PrepareForTest({AccessContextHolder.class, SpringContextUtils.class, UaaUtils.class, DefaultTrackedProcessManagement.class, DefaultEventManagement.class, DefaultMetadataManagement.class, DefaultOverdueManagement.class})
public class DirectMailTemplatePlaceholdersServiceTest {
	@InjectMocks
	DirectMailTemplatePlaceholdersService service = new DirectMailTemplatePlaceholdersService();
	@Mock
    private ServiceInstancesMapping serviceInstancesMapping;
    @Mock
    private GTTRestTemplate restTemplate;
    @Mock
    private TenantAwareLogService log;
    @Mock
    private ICurrentAccessContext currentAccessContext;
    @Mock
    private BusinessPartnerService bpService;
    
	@Before
	public void setUp() {
		PowerMockito.mockStatic(SpringContextUtils.class, UaaUtils.class, DefaultTrackedProcessManagement.class, DefaultEventManagement.class, DefaultMetadataManagement.class, DefaultOverdueManagement.class);
		when(SpringContextUtils.getBean(ServiceInstancesMapping.class)).thenReturn(serviceInstancesMapping);
		when(SpringContextUtils.getBean(GTTRestTemplate.class)).thenReturn(restTemplate);
		when(SpringContextUtils.getBean(TenantAwareLogService.class)).thenReturn(log);
		when(SpringContextUtils.getBean(ICurrentAccessContext.class)).thenReturn(currentAccessContext);
		
		Whitebox.setInternalState(service, "bpService", bpService);
		
		ReminderServiceInstance service = mock(ReminderServiceInstance.class);
		String endpoint = "endpoint";
		given(service.getEndpoint()).willReturn(endpoint);
		given(serviceInstancesMapping.getReminderServiceInstance()).willReturn(service);
		
		ResponseEntity responseEntity = mock(ResponseEntity.class);
        String bpS = "{\r\n" + 
        		"    \"APP\": [\r\n" + 
        		"        \"App_Placeholder_1\",\r\n" + 
        		"        \"SolutionOwner_Address\",\r\n" + 
        		"        \"SolutionOwner_Mobile\",\r\n" + 
        		"        \"SolutionOwner_Logo\",\r\n" + 
        		"        \"SolutionOwner_Fax\",\r\n" + 
        		"        \"SolutionOwner_Website\",\r\n" + 
        		"        \"SolutionOwner_PostalCode\",\r\n" + 
        		"        \"SolutionOwner_BusinessProfileName\",\r\n" + 
        		"        \"SolutionOwner_ContactPersonName\",\r\n" + 
        		"        \"SolutionOwner_ContactPersonPhoneNumber\",\r\n" + 
        		"        \"SolutionOwner_ContactPersonEmail\"\r\n" + 
        		"    ]\r\n" + 
        		"}";
        given(responseEntity.getBody()).willReturn(bpS);
		given(restTemplate.exchange(Mockito.anyString(), eq(HttpMethod.POST), Mockito.any(), eq(null), Mockito.any())).willReturn(responseEntity);
		given(restTemplate.exchange(Mockito.anyString(), eq(HttpMethod.GET), Mockito.any(), eq(null), Mockito.any())).willReturn(responseEntity);
		given(currentAccessContext.getSubaccountId()).willReturn(LocalMockedCurrentAccessContext.TENANT_SUBACCOUNT_ID);
		
		AccessContext ac = new AccessContext("", "", "", "", null, null, false, false, false, false);
		PowerMockito.mockStatic(AccessContextHolder.class);
		BDDMockito.given(AccessContextHolder.get()).willReturn(ac);
		
		BPContactInfo bpContact = new BPContactInfo();
		when(bpService.getBPContactDetail(Mockito.anyString())).thenReturn(bpContact);
	}
	@Test
	public void test() {
		service.getTemplatePlaceHolders("");
	}
}
