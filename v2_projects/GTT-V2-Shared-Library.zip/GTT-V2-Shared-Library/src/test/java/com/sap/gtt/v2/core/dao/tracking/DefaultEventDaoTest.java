package com.sap.gtt.v2.core.dao.tracking;

import com.sap.gtt.v2.BaseTest;
import com.sap.gtt.v2.Dummy;
import com.sap.gtt.v2.core.dao.metadata.*;
import com.sap.gtt.v2.core.domain.metadata.CurrentMetadataEntity;
import com.sap.gtt.v2.core.entity.trackedprocess.Event;
import com.sap.gtt.v2.core.entity.trackedprocess.PlannedEvent;
import com.sap.gtt.v2.core.entity.trackedprocess.Reference;
import com.sap.gtt.v2.core.management.metadata.DefaultMetadataManagement;
import com.sap.gtt.v2.core.management.metadata.IMetadataManagement;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.IOException;
import java.time.Instant;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = Dummy.class)
@ActiveProfiles("test")
public class DefaultEventDaoTest extends BaseTest {

    private DefaultEventDao defaultEventDao;

    @Autowired
    private IMetadataDao metadataDao;

    @Autowired
    private ISysTableDao sysTableDao;

    @Before
    public void setUp() {
        super.setUp();
        defaultEventDao = DefaultEventDao.getInstance();
    }

    @Test
    public void test() throws IOException {
        DefaultMetadataDaoTest test = new DefaultMetadataDaoTest();
        test.setDefaultMetadataDao((DefaultMetadataDao) metadataDao);
        test.insertMetadataProject();

        DefaultSysTableDaoTest test1 = new DefaultSysTableDaoTest();
        test1.setDefaultSysTableDao((DefaultSysTableDao) sysTableDao);
        test1.createTables();

        String entityType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        String entityName = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        String namespace = "com.sap.gtt.app.mim";

        IMetadataManagement metadataManagement = DefaultMetadataManagement.getInstance();
        CurrentMetadataEntity metadata = metadataManagement.findAllEntitiesRecursively(namespace, entityName);

        Event event = new Event();
        event.setId(UUID.randomUUID());
        event.setActualBusinessTimestamp(Instant.now());
        event.setActualBusinessTimeZone("");
        event.setAltKey("alt-key");
        event.setCloneInstanceId(UUID.randomUUID());
        event.setCreatedByUser("");
        event.setCreationDateTime(Instant.now());
        event.setActualTechnicalTimestamp(Instant.now());
        event.setEventReasonText("reason");
        event.setEventType("arrived");
        event.setLastChangedByUser("");
        event.setLastChangedDateTime(Instant.now());
        //event.setLocationId(UUID.randomUUID());
        event.setLocationAltKey("location-alt-key");
        event.setLogicalSystem("001");
        event.setMessageSourceType("message-source-type");
        //event.setPartyId(UUID.randomUUID());
        event.setScheme("scheme");
        event.setSenderPartyId(UUID.randomUUID().toString());
        event.setTrackingId("tracking-id");
        event.setSubaccountId(UUID.randomUUID());
        event.setTrackingIdType("tracking-id-type");
        event.setMetadata(metadata);

        PlannedEvent plannedEventForEvent = new PlannedEvent();
//        CurrentMetadataEntity metadata1 = new CurrentMetadataEntity();
//        metadata1.setAllRelatedEntityMap(metadata.getAllRelatedEntityMap());
//        metadata1.setCurrentEntityName(MetadataConstants.CoreModelEntity.PLANNED_EVENT_FOR_EVENT.getFullName());
//        plannedEventForEvent.setMetadata(metadata1);
        plannedEventForEvent.setValue(PlannedEvent.EVENTID, UUID.randomUUID());
        plannedEventForEvent.setEventType("plannedEventForEvent");
        plannedEventForEvent.setLocationAltKey("location-alt-key");
        plannedEventForEvent.setPlannedBizTsEarliest(Instant.now());
        //plannedEventForEvent.setLocationId(UUID.randomUUID());
        plannedEventForEvent.setPlannedBizTsLatest(Instant.now());
        plannedEventForEvent.setPlannedBusinessTimestamp(Instant.now());
        plannedEventForEvent.setPlannedBusinessTimeZone("");
        plannedEventForEvent.setPlannedTechnicalTimestamp(Instant.now());
        plannedEventForEvent.setPlannedTechTsEarliest(Instant.now());
        plannedEventForEvent.setPlannedTechTsLatest(Instant.now());

        event.setPlannedEvents(Arrays.asList(plannedEventForEvent));

        Reference reference = new Reference();
        CurrentMetadataEntity metadata2 = new CurrentMetadataEntity();
//        metadata2.setAllRelatedEntityMap(metadata.getAllRelatedEntityMap());
//        metadata2.setCurrentEntityName(MetadataConstants.CoreModelEntity.REFERENCE.getFullName());
//        reference.setMetadata(metadata2);
        reference.setAction("ADD");
        reference.setAltKey("alt-key");
        reference.setEventId(event.getIdAsInternalValue());
        reference.setReferenceType("ref-type");
        reference.setValidFrom(Instant.now());
        reference.setValidTo(Instant.now());

//        event.setReferences(Arrays.asList(reference));
        defaultEventDao.insert(event);

        event.setId(UUID.randomUUID());
        event.setAltKey("xri://sap.com/id:LBN#10000034:Q8JCLNT774:FreightOrder:0001");
        defaultEventDao.insert(Arrays.asList(event));
        defaultEventDao.update(event);

        List<Event> byAltKey = defaultEventDao.findByAltKey(event.getMetadata(), event.getAltKey());
        Assertions.assertThat(byAltKey).size().isEqualTo(1);
        Assertions.assertThat(byAltKey.get(0).getAltKey()).isEqualTo(event.getAltKey());

        List<Event> allByAltKeys = defaultEventDao.findAllByAltKeys(event.getMetadata(), Arrays.asList(event.getAltKey()));
        Assertions.assertThat(allByAltKeys).size().isEqualTo(1);
        Assertions.assertThat(allByAltKeys.get(0).getAltKey()).isEqualTo(event.getAltKey());

        allByAltKeys = defaultEventDao.findAllByAltKeys(event.getMetadata(), event.getAltKey());
        Assertions.assertThat(allByAltKeys).size().isEqualTo(1);
        Assertions.assertThat(allByAltKeys.get(0).getAltKey()).isEqualTo(event.getAltKey());

        defaultEventDao.findOne(event.getMetadata(), event.getId().getInternalValue());
    }
}