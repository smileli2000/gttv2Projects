package com.sap.gtt.v2.core.dao.execution;

import com.sap.gtt.v2.BaseTest;
import com.sap.gtt.v2.Dummy;
import com.sap.gtt.v2.core.domain.execution.ExecutionStatus;
import com.sap.gtt.v2.core.domain.execution.Phase;
import com.sap.gtt.v2.core.entity.execution.ExecutionHistory;
import com.sap.gtt.v2.core.entity.execution.ExecutionUnit;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = Dummy.class)
@ActiveProfiles("test")
public class DefaultExecutionHistoryDaoTest extends BaseTest {
    private DefaultExecutionHistoryDao executionHistoryDao;
    private DefaultExecutionUnitDao executionUnitDao;

    @Before
    public void setUp() {
        super.setUp();
        executionHistoryDao = DefaultExecutionHistoryDao.getInstance();
        executionUnitDao = DefaultExecutionUnitDao.getInstance();
    }

    @Test
    public void testQueryExecution() {
        String id = "executionId";
        ExecutionHistory executionHistory = executionHistoryDao.queryExecution(id);
        if (executionHistory == null) {
            insertExecutionHistory(id);
            executionHistory = executionHistoryDao.queryExecution(id);
        }
        assertThat(executionHistory.getId()).isEqualTo(id);
    }

    @Test
    public void testUpdateExecutionHistory() {
        String id = "executionId";
        ExecutionHistory executionHistory = executionHistoryDao.queryExecution(id);
        if (executionHistory == null) {
            insertExecutionHistory(id);
            executionHistory = executionHistoryDao.queryExecution(id);
        }
        String unitId = executionHistory.getUnitId();
        String phase = Phase.DB.name();
        String status = ExecutionStatus.ERROR.name();
        executionHistoryDao.updateExecutionStatus(id, phase, status);
        executionHistory = executionHistoryDao.queryExecution(id);
        assertThat(executionHistory.getId()).isEqualTo(id);
        assertThat(executionHistory.getUnitId()).isEqualTo(unitId);
        assertThat(executionHistory.getLastPhase()).isEqualTo(phase);
        assertThat(executionHistory.getStatus()).isEqualTo(status);
    }

    @Test
    public void testQueryStatus() {
        String requestId = "requestId";

        String executionId1 = UUID.randomUUID().toString();
        ExecutionUnit unit1 = new ExecutionUnit(UUID.randomUUID().toString(), requestId, "eventId", "eventtType",
                "altkey", "locationAltkey", "tpId", "processAltkey",
                1, executionId1, false);
        executionUnitDao.insertExecutionUnit(unit1);
        ExecutionHistory executionHistory1 = new ExecutionHistory(executionId1, unit1.getId(), Instant.now(), Phase.PROCESS.name(), ExecutionStatus.ERROR.name());
        executionHistoryDao.insertExecution(executionHistory1);

        String executionId2 = UUID.randomUUID().toString();
        ExecutionUnit unit2 = new ExecutionUnit(UUID.randomUUID().toString(), requestId, "eventId", "eventtType",
                "altkey", "locationAltkey", "tpId", "processAltkey",
                1, executionId2, false);
        executionUnitDao.insertExecutionUnit(unit2);
        ExecutionHistory executionHistory2 = new ExecutionHistory(executionId2, unit2.getId(), Instant.now(), Phase.EVENT2ACTION.name(), ExecutionStatus.PENDING.name());
        executionHistoryDao.insertExecution(executionHistory2);

        List<String> statusList = executionHistoryDao.queryStatus(requestId);
        assertThat(statusList.size()).isEqualTo(2);
        statusList.contains("ERROR");
        statusList.contains("PENDING");
    }

    private void insertExecutionHistory(String id) {
        String unitId = UUID.randomUUID().toString();
        String lastPhase = Phase.EVENT2ACTION.name();
        String status = ExecutionStatus.SUCCESS.name();
        ExecutionHistory executionHistory = new ExecutionHistory(id, unitId, Instant.now(), lastPhase, status);
        executionHistoryDao.insertExecution(executionHistory);
    }

    private void insertExecutionUnit(String eventId, String correlatedTpId) {
        String id = UUID.randomUUID().toString();
        String executionId = UUID.randomUUID().toString();
        ExecutionUnit newExecutionUnit = new ExecutionUnit(id, "requestId", eventId, "eventtType", "altkey", "locationAltkey", correlatedTpId, "processAltkey", 1, executionId, false);
        executionUnitDao.insertExecutionUnit(newExecutionUnit);
    }
}
