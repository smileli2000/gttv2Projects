package com.sap.gtt.v2.core.entity.trackedprocess;

import com.sap.gtt.v2.Dummy;
import com.sap.gtt.v2.core.domain.trackedprocess.Constant;
import com.sap.gtt.v2.core.domain.trackedprocess.CorrelationType;
import com.sap.gtt.v2.core.domain.trackedprocess.EventStatus;
import com.sap.gtt.v2.core.domain.trackedprocess.ProcessStatus;
import com.sap.gtt.v2.core.rule.impl.MemoryBlockException;
import com.sap.gtt.v2.core.runtime.model.BooleanValue;
import com.sap.gtt.v2.core.runtime.model.IPropertyValue;
import com.sap.gtt.v2.core.runtime.model.ListValue;
import com.sap.gtt.v2.core.runtime.model.StringValue;
import com.sap.gtt.v2.exception.PropertyValidationException;
import com.sap.gtt.v2.util.GTTUtils;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.util.*;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = Dummy.class)
@ActiveProfiles("test")
public class TrackedProcessTest {

    private TrackedProcess tp;
    @Before
    public void setUp() {
        tp = new TrackedProcess();
    }

    @Test
    public void test() {

    }

    @Test
    public void testSetValueBasics() {
        tp.setValue("dummy", 1);
        Integer dummy = tp.getValueAsInteger("dummy");
        assertTrue(dummy.equals(1));

        tp.setValue("dummy", 2);
        dummy = tp.getValueAsInteger("dummy");
        assertTrue(dummy.equals(2));

        tp.setValue("dummy", "two");
        String dummyStr = tp.getValueAsString("dummy");
        assertTrue(dummyStr.equals("two"));

        Instant deliveryTime = Instant.now();
        tp.setValue("DeliveryTime", deliveryTime);
        Instant dummyTimeStamp = tp.getValueAsTimeStamp("DeliveryTime");
        assertTrue(dummyTimeStamp.equals(deliveryTime));

        LocalDate  plannedDate = LocalDate.parse("2009-01-01");
        tp.setValue("PlannedDate", plannedDate);
        LocalDate dummyDate = tp.getValueAsDate("PlannedDate");
        assertTrue(dummyDate.equals(plannedDate));

        BigDecimal price = BigDecimal.valueOf(88.8);
        tp.setValue("Price", price);
        BigDecimal dummyFloat = tp.getValueAsDecimal("Price");
        assertTrue(dummyFloat.equals(price));

        tp.setValue("IsDelivered", true);
        Boolean dummyBoolean = tp.getValueAsBoolean("IsDelivered");
        assertTrue(dummyBoolean);

        UUID uuid = UUID.randomUUID();
        tp.setValue("ID", uuid);
        UUID dummyUUID = tp.getValueAsUUID("ID");
        assertTrue(dummyUUID.equals(uuid));

        try {
            String trackingId = tp.getTrackingId();
            System.out.println(trackingId);
            assertNull(trackingId);
        }catch (PropertyValidationException e) {

        }
    }

    @Test
    public void testSortPlannedEventsWhenAllHavePlannedBizTime() {
        TrackedProcess tp = new TrackedProcess();
        String trackedProcessType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        tp.setTrackedProcessType(trackedProcessType);
        UUID tpId = GTTUtils.UUIDUtils.generateTimeBasedUUID();
        tp.setId(tpId);
        tp.setProcessStatus(ProcessStatus.AS_PLANNED.name());
        List<PlannedEvent> pes = new ArrayList<>();
        //planned event1:
        PlannedEvent pe1 = new PlannedEvent();
        pe1.setId(UUID.fromString("c5d8ab0d-f549-4d56-93c7-cdb1733333f2"));
        pe1.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POGoodsIssueEvent");
        pe1.setPlannedTechTsLatest(Instant.parse("2018-07-09T09:00:00.213Z"));
        pe1.setPlannedBusinessTimestamp(Instant.parse("2018-07-09T09:00:00.213Z"));
        pe1.setPlannedBizTsEarliest(Constant.MIN_TIMESTAMP);
        pe1.setPlannedBizTsLatest(Constant.MAX_TIMESTAMP);
        pe1.setPayloadSequence(1);
        pe1.setEventStatus(EventStatus.PLANNED.name());
        pes.add(pe1);

        //planned event2:
        PlannedEvent pe2 = new PlannedEvent();
        pe2.setId(UUID.fromString("c5d8ab0d-f549-4d56-93c7-cdb1733333f3"));
        pe2.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POGoodsIssueEvent");
        pe2.setPlannedTechTsLatest(Instant.parse("2018-07-08T09:00:00.213Z"));
        pe2.setPlannedBusinessTimestamp(Instant.parse("2018-07-08T09:00:00.213Z"));
        pe2.setPlannedBizTsEarliest(Constant.MIN_TIMESTAMP);
        pe2.setPlannedBizTsLatest(Constant.MAX_TIMESTAMP);
        pe2.setPayloadSequence(2);
        pe2.setEventStatus(EventStatus.PLANNED.name());
        pes.add(pe2);

        //planned event3:
        PlannedEvent pe3 = new PlannedEvent();
        pe3.setId(UUID.fromString("c5d8ab0d-f549-4d56-93c7-cdb1733333f4"));
        pe3.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POConfirmedEvent");
        pe3.setPlannedTechTsLatest(Instant.parse("2018-07-06T10:00:00.213Z"));
        pe3.setPlannedBusinessTimestamp(Instant.parse("2018-07-08T10:00:00.213Z"));
        pe3.setPlannedBizTsEarliest(Constant.MIN_TIMESTAMP);
        pe3.setPlannedBizTsLatest(Constant.MIN_TIMESTAMP);
        pe3.setPayloadSequence(3);
        pe3.setEventStatus(EventStatus.LATE_REPORTED.name());
        pe3.setLocationAltKey("location-alt-key");
        //pe3.setLocationId(GTTUtils.UUIDUtils.generateNameBasedUUID("location-alt-key"));
        pes.add(pe3);
        tp.setPlannedEvents(pes);

        List<QualifiedTrackingId> trackingIds = new ArrayList<>();
        QualifiedTrackingId trackingId = QualifiedTrackingId.build(tpId, tpId, null, null);
        trackingIds.add(trackingId);
        tp.setTrackingIds(trackingIds);
        List<ProcessEventDirectory> peds = new ArrayList<>();
        ProcessEventDirectory ped = ProcessEventDirectory.build(GTTUtils.UUIDUtils.generateTimeBasedUUID(),
                tpId, null, GTTUtils.UUIDUtils.generateTimeBasedUUID(), CorrelationType.UNPLANNED_PROCESS_CREATION_UPDATE.name());
        peds.add(ped);
        tp.setPEDs(peds);
        List<PlannedEvent> sortedPlannedEvents = tp.getPlannedEventsSortByPlannedBusinessTime(false);
        assertThat(sortedPlannedEvents.size()).isEqualTo(3);
        PlannedEvent pe1AfterSort = sortedPlannedEvents.get(0);
        assertThat(pe1AfterSort.getId()).isEqualTo(pe2.getId());
        PlannedEvent pe2AfterSort = sortedPlannedEvents.get(1);
        assertThat(pe2AfterSort.getId()).isEqualTo(pe3.getId());
        PlannedEvent pe3AfterSort = sortedPlannedEvents.get(2);
        assertThat(pe3AfterSort.getId()).isEqualTo(pe1.getId());
    }

    @Test
    public void testSortPlannedEventsWhenOneDoesnotHavePlannedBizTime() {
        TrackedProcess tp = new TrackedProcess();
        String trackedProcessType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        tp.setTrackedProcessType(trackedProcessType);
        UUID tpId = GTTUtils.UUIDUtils.generateTimeBasedUUID();
        tp.setId(tpId);
        tp.setProcessStatus(ProcessStatus.AS_PLANNED.name());
        List<PlannedEvent> pes = new ArrayList<>();
        //planned event1:
        PlannedEvent pe1 = new PlannedEvent();
        pe1.setId(UUID.fromString("c5d8ab0d-f549-4d56-93c7-cdb1733333f2"));
        pe1.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POGoodsIssueEvent");
        pe1.setPlannedTechTsLatest(Instant.parse("2018-07-09T09:00:00.213Z"));
        //pe1.setPlannedBusinessTimestamp(Instant.parse("2018-07-09T09:00:00.213Z"));
        pe1.setPlannedBizTsEarliest(Constant.MIN_TIMESTAMP);
        pe1.setPlannedBizTsLatest(Constant.MAX_TIMESTAMP);
        pe1.setPayloadSequence(1);
        pe1.setEventStatus(EventStatus.PLANNED.name());
        pes.add(pe1);

        //planned event2:
        PlannedEvent pe2 = new PlannedEvent();
        pe2.setId(UUID.fromString("c5d8ab0d-f549-4d56-93c7-cdb1733333f3"));
        pe2.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POGoodsIssueEvent");
        pe2.setPlannedTechTsLatest(Instant.parse("2018-07-08T09:00:00.213Z"));
        pe2.setPlannedBusinessTimestamp(Instant.parse("2018-07-08T09:00:00.213Z"));
        pe2.setPlannedBizTsEarliest(Constant.MIN_TIMESTAMP);
        pe2.setPlannedBizTsLatest(Constant.MAX_TIMESTAMP);
        pe2.setPayloadSequence(2);
        pe2.setEventStatus(EventStatus.PLANNED.name());
        pes.add(pe2);

        //planned event3:
        PlannedEvent pe3 = new PlannedEvent();
        pe3.setId(UUID.fromString("c5d8ab0d-f549-4d56-93c7-cdb1733333f4"));
        pe3.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POConfirmedEvent");
        pe3.setPlannedTechTsLatest(Instant.parse("2018-07-06T10:00:00.213Z"));
        pe3.setPlannedBusinessTimestamp(Instant.parse("2018-07-08T09:00:00.213Z"));
        pe3.setPlannedBizTsEarliest(Constant.MIN_TIMESTAMP);
        pe3.setPlannedBizTsLatest(Constant.MIN_TIMESTAMP);
        pe3.setPayloadSequence(3);
        pe3.setEventStatus(EventStatus.LATE_REPORTED.name());
        pe3.setLocationAltKey("location-alt-key");
        //pe3.setLocationId(GTTUtils.UUIDUtils.generateNameBasedUUID("location-alt-key"));
        pes.add(pe3);
        tp.setPlannedEvents(pes);

        List<QualifiedTrackingId> trackingIds = new ArrayList<>();
        QualifiedTrackingId trackingId = QualifiedTrackingId.build(tpId, tpId, null, null);
        trackingIds.add(trackingId);
        tp.setTrackingIds(trackingIds);
        List<ProcessEventDirectory> peds = new ArrayList<>();
        ProcessEventDirectory ped = ProcessEventDirectory.build(GTTUtils.UUIDUtils.generateTimeBasedUUID(),
                tpId, null, GTTUtils.UUIDUtils.generateTimeBasedUUID(), CorrelationType.UNPLANNED_PROCESS_CREATION_UPDATE.name());
        peds.add(ped);
        tp.setPEDs(peds);
        List<PlannedEvent> sortedPlannedEvents = tp.getPlannedEventsSortByPlannedBusinessTime(false);
        assertThat(sortedPlannedEvents.size()).isEqualTo(2);
        PlannedEvent pe1AfterSort = sortedPlannedEvents.get(0);
        assertThat(pe1AfterSort.getId()).isEqualTo(pe2.getId());
        PlannedEvent pe2AfterSort = sortedPlannedEvents.get(1);
        assertThat(pe2AfterSort.getId()).isEqualTo(pe3.getId());
    }

    @Test
    public void testSortPlannedEventsWhenAllDonotHavePlannedBizTime() {
        TrackedProcess tp = new TrackedProcess();
        String trackedProcessType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        tp.setTrackedProcessType(trackedProcessType);
        UUID tpId = GTTUtils.UUIDUtils.generateTimeBasedUUID();
        tp.setId(tpId);
        tp.setProcessStatus(ProcessStatus.AS_PLANNED.name());
        List<PlannedEvent> pes = new ArrayList<>();
        //planned event1:
        PlannedEvent pe1 = new PlannedEvent();
        pe1.setId(UUID.fromString("c5d8ab0d-f549-4d56-93c7-cdb1733333f2"));
        pe1.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POGoodsIssueEvent");
        pe1.setPlannedTechTsLatest(Instant.parse("2018-07-09T09:00:00.213Z"));
        //pe1.setPlannedBusinessTimestamp(Instant.parse("2018-07-09T09:00:00.213Z"));
        pe1.setPlannedBizTsEarliest(Constant.MIN_TIMESTAMP);
        pe1.setPlannedBizTsLatest(Constant.MAX_TIMESTAMP);
        pe1.setPayloadSequence(1);
        pe1.setEventStatus(EventStatus.PLANNED.name());
        pes.add(pe1);

        //planned event2:
        PlannedEvent pe2 = new PlannedEvent();
        pe2.setId(UUID.fromString("c5d8ab0d-f549-4d56-93c7-cdb1733333f3"));
        pe2.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POGoodsIssueEvent");
        pe2.setPlannedTechTsLatest(Instant.parse("2018-07-08T09:00:00.213Z"));
        //pe2.setPlannedBusinessTimestamp(Instant.parse("2018-07-08T09:00:00.213Z"));
        pe2.setPlannedBizTsEarliest(Constant.MIN_TIMESTAMP);
        pe2.setPlannedBizTsLatest(Constant.MAX_TIMESTAMP);
        pe2.setPayloadSequence(2);
        pe2.setEventStatus(EventStatus.PLANNED.name());
        pes.add(pe2);

        //planned event3:
        PlannedEvent pe3 = new PlannedEvent();
        pe3.setId(UUID.fromString("c5d8ab0d-f549-4d56-93c7-cdb1733333f4"));
        pe3.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POConfirmedEvent");
        pe3.setPlannedTechTsLatest(Instant.parse("2018-07-06T10:00:00.213Z"));
        //pe3.setPlannedBusinessTimestamp(Instant.parse("2018-07-08T09:00:00.213Z"));
        pe3.setPlannedBizTsEarliest(Constant.MIN_TIMESTAMP);
        pe3.setPlannedBizTsLatest(Constant.MIN_TIMESTAMP);
        pe3.setPayloadSequence(3);
        pe3.setEventStatus(EventStatus.LATE_REPORTED.name());
        pe3.setLocationAltKey("location-alt-key");
        //pe3.setLocationId(GTTUtils.UUIDUtils.generateNameBasedUUID("location-alt-key"));
        pes.add(pe3);
        tp.setPlannedEvents(pes);

        List<QualifiedTrackingId> trackingIds = new ArrayList<>();
        QualifiedTrackingId trackingId = QualifiedTrackingId.build(tpId, tpId, null, null);
        trackingIds.add(trackingId);
        tp.setTrackingIds(trackingIds);
        List<ProcessEventDirectory> peds = new ArrayList<>();
        ProcessEventDirectory ped = ProcessEventDirectory.build(GTTUtils.UUIDUtils.generateTimeBasedUUID(),
                tpId, null, GTTUtils.UUIDUtils.generateTimeBasedUUID(), CorrelationType.UNPLANNED_PROCESS_CREATION_UPDATE.name());
        peds.add(ped);
        tp.setPEDs(peds);
        List<PlannedEvent> sortedPlannedEvents = tp.getPlannedEventsSortByPlannedBusinessTime(false);
        assertThat(sortedPlannedEvents.size()).isEqualTo(0);
    }

    @Test
    public void testSortPlannedEventsWhenTPDoesNotHavePlannedEvents() {
        TrackedProcess tp = new TrackedProcess();
        String trackedProcessType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        tp.setTrackedProcessType(trackedProcessType);
        UUID tpId = GTTUtils.UUIDUtils.generateTimeBasedUUID();
        tp.setId(tpId);
        tp.setProcessStatus(ProcessStatus.AS_PLANNED.name());

        List<QualifiedTrackingId> trackingIds = new ArrayList<>();
        QualifiedTrackingId trackingId = QualifiedTrackingId.build(tpId, tpId, null, null);
        trackingIds.add(trackingId);
        tp.setTrackingIds(trackingIds);
        List<ProcessEventDirectory> peds = new ArrayList<>();
        ProcessEventDirectory ped = ProcessEventDirectory.build(GTTUtils.UUIDUtils.generateTimeBasedUUID(),
                tpId, null, GTTUtils.UUIDUtils.generateTimeBasedUUID(), CorrelationType.UNPLANNED_PROCESS_CREATION_UPDATE.name());
        peds.add(ped);
        tp.setPEDs(peds);
        List<PlannedEvent> sortedPlannedEvents = tp.getPlannedEventsSortByPlannedBusinessTime(false);
        assertThat(sortedPlannedEvents).isNull();
    }

    @Test
    public void testFunctionDefs() throws MemoryBlockException {
        TrackedProcess tp = new TrackedProcess();
        String trackedProcessType = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemProcess";
        tp.setTrackedProcessType(trackedProcessType);
        UUID tpId = GTTUtils.UUIDUtils.generateTimeBasedUUID();
        tp.setId(tpId);
        tp.setProcessStatus(ProcessStatus.AS_PLANNED.name());
        List<PlannedEvent> pes = new ArrayList<>();
        //planned event1:
        PlannedEvent pe1 = new PlannedEvent();
        pe1.setId(UUID.fromString("c5d8ab0d-f549-4d56-93c7-cdb1733333f2"));
        pe1.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POGoodsIssueEvent");
        pe1.setPlannedTechTsLatest(Instant.parse("2018-07-09T09:00:00.213Z"));
        //pe1.setPlannedBusinessTimestamp(Instant.parse("2018-07-09T09:00:00.213Z"));
        pe1.setPlannedBizTsEarliest(Constant.MIN_TIMESTAMP);
        pe1.setPlannedBizTsLatest(Constant.MAX_TIMESTAMP);
        pe1.setPayloadSequence(1);
        pe1.setEventStatus(EventStatus.PLANNED.name());
        pes.add(pe1);

        //planned event2:
        PlannedEvent pe2 = new PlannedEvent();
        pe2.setId(UUID.fromString("c5d8ab0d-f549-4d56-93c7-cdb1733333f3"));
        pe2.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POGoodsIssueEvent");
        pe2.setPlannedTechTsLatest(Instant.parse("2018-07-08T09:00:00.213Z"));
        pe2.setPlannedBusinessTimestamp(Instant.parse("2018-07-08T09:00:00.213Z"));
        pe2.setPlannedBizTsEarliest(Constant.MIN_TIMESTAMP);
        pe2.setPlannedBizTsLatest(Constant.MAX_TIMESTAMP);
        pe2.setPayloadSequence(2);
        pe2.setEventStatus(EventStatus.PLANNED.name());
        pes.add(pe2);

        //planned event3:
        PlannedEvent pe3 = new PlannedEvent();
        pe3.setId(UUID.fromString("c5d8ab0d-f549-4d56-93c7-cdb1733333f4"));
        pe3.setEventType("com.sap.gtt.app.mim.ProcurementOrderItemModel.POConfirmedEvent");
        pe3.setPlannedTechTsLatest(Instant.parse("2018-07-06T10:00:00.213Z"));
        pe3.setPlannedBusinessTimestamp(Instant.parse("2018-07-08T09:00:00.213Z"));
        pe3.setPlannedBizTsEarliest(Constant.MIN_TIMESTAMP);
        pe3.setPlannedBizTsLatest(Constant.MIN_TIMESTAMP);
        pe3.setPayloadSequence(3);
        pe3.setEventStatus(EventStatus.LATE_REPORTED.name());
        pe3.setLocationAltKey("location-alt-key");
        //pe3.setLocationId(GTTUtils.UUIDUtils.generateNameBasedUUID("location-alt-key"));
        pes.add(pe3);
        tp.setPlannedEvents(pes);

        ProcessEventDirectory dummy = new ProcessEventDirectory(pe1.getInternalValue());
        Assertions.assertThat(dummy).isNotEqualTo(pe1);

        Map<String, IPropertyValue.FunctionInterfaceDef> functionDefs =
                new TrackedProcessDummy().getFunctionDefs();

        IPropertyValue.FunctionInterfaceDef getFinalPlalanedEvents =
            functionDefs.get("getFinalPlannedEvents");

        ListValue listValue = ListValue.valueOfEmpty();
        listValue.add(StringValue.valueOf("aaa"));
        getFinalPlalanedEvents.function.execute(tp, Arrays.asList(listValue));

        IPropertyValue.FunctionInterfaceDef getFinalPlalanedEventsDef =
                functionDefs.get("getPlannedEventsSortByPlannedBusinessTime");

        getFinalPlalanedEventsDef.function.execute(tp, Arrays.asList(BooleanValue.TRUE));

        IPropertyValue.FunctionInterfaceDef getCorrelatedEventsForCurrentTPExcludeEventTypesDef =
                functionDefs.get("getCorrelatedEventsForCurrentTPExcludeEventTypes");

        try {
            getCorrelatedEventsForCurrentTPExcludeEventTypesDef.function.execute(
                    tp, Arrays.asList(listValue)
            );
        } catch (Exception e) {
            // TODO: remove this try catch workaround
        }


        IPropertyValue.FunctionInterfaceDef getLastCorrelatedEventForCurrentTPIncludeEventTypesDef =
                functionDefs.get("getLastCorrelatedEventForCurrentTPIncludeEventTypes");

        try {
            getLastCorrelatedEventForCurrentTPIncludeEventTypesDef
                    .function.execute(tp, Arrays.asList(listValue));
        } catch (Exception e) {
            // TODO: remove this try catch workaround
        }


        IPropertyValue.FunctionInterfaceDef calculateProcessStatusDef =
                functionDefs.get("calculateProcessStatus");

        try {
            getLastCorrelatedEventForCurrentTPIncludeEventTypesDef
                    .function.execute(tp, Arrays.asList(pe1));
        } catch (Exception e) {
            // TODO: remove this try catch workaround
        }

    }

    private class TrackedProcessDummy extends TrackedProcess {
        public Map<String, FunctionInterfaceDef>  getFunctionDefs() {return functionDefs;}
    }

}