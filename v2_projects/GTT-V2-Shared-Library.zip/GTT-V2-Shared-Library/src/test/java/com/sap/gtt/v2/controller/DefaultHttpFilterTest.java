package com.sap.gtt.v2.controller;

import com.sap.gtt.v2.Dummy;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockFilterChain;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import javax.servlet.ServletException;
import java.io.IOException;


@RunWith(SpringRunner.class)
@SpringBootTest(classes = Dummy.class)
@ActiveProfiles("test")
public class DefaultHttpFilterTest {

    @Autowired
    private DefaultHttpFilter defaultHttpFilter;

    @Test
    public void test() throws IOException, ServletException {
        defaultHttpFilter.doFilter(new MockHttpServletRequest(),
                new MockHttpServletResponse(), new MockFilterChain());
    }

}