package com.sap.gtt.v2.core.dao.tracking;

import com.sap.gtt.v2.Dummy;
import com.sap.gtt.v2.core.dao.metadata.*;
import com.sap.gtt.v2.core.domain.metadata.CurrentMetadataEntity;
import com.sap.gtt.v2.core.domain.metadata.MetadataConstants;
import com.sap.gtt.v2.core.domain.trackedprocess.LifeCycleStatus;
import com.sap.gtt.v2.core.entity.trackedprocess.QualifiedTrackingId;
import com.sap.gtt.v2.core.entity.trackedprocess.TrackedProcess;
import com.sap.gtt.v2.core.management.metadata.DefaultMetadataManagement;
import com.sap.gtt.v2.core.management.metadata.IMetadataManagement;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.IOException;
import java.time.Instant;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static com.sap.gtt.v2.core.domain.trackedprocess.Constant.MAX_TIMESTAMP;
import static com.sap.gtt.v2.core.domain.trackedprocess.Constant.MIN_TIMESTAMP;
import static org.assertj.core.api.Assertions.assertThat;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = Dummy.class)
@ActiveProfiles("test")
public class DefaultQualifiedTrackingIdDaoTest {

    @Autowired
    private IQualifiedTrackingIdDao qualifiedTrackingIdDao;

    @Autowired
    private ITrackedProcessDao trackedProcessDao;

    @Autowired
    private IMetadataDao metadataDao;

    @Autowired
    private ISysTableDao sysTableDao;

    @Test
    public void test() throws IOException {
        qualifiedTrackingIdDao = DefaultQualifiedTrackingIdDao.getInstance();
        DefaultMetadataDaoTest test = new DefaultMetadataDaoTest();
        test.setDefaultMetadataDao((DefaultMetadataDao) metadataDao);
        test.insertMetadataProject();

        DefaultSysTableDaoTest test1 = new DefaultSysTableDaoTest();
        test1.setDefaultSysTableDao((DefaultSysTableDao) sysTableDao);
        test1.createTables();

        String entityName = "com.sap.gtt.app.mim.ProcurementOrderItemModel.ProcurementOrderItemEventForWrite";
        String namespace = "com.sap.gtt.app.mim";

        IMetadataManagement metadataManagement = DefaultMetadataManagement.getInstance();


        TrackedProcess tp = new TrackedProcess();
        CurrentMetadataEntity tpMetadata = metadataManagement.findAllEntitiesRecursively(namespace, entityName);
        tpMetadata.setCurrentEntityName(MetadataConstants.CoreModelEntity.TRACKED_PROCESS.getFullName());
        tp.setMetadata(tpMetadata);
        UUID processId = UUID.randomUUID();
        tp.setId(processId);
        tp.setAltKey("altKey");
        tp.setLifeCycleStatus(LifeCycleStatus.BUSINESS_ACTIVE);
        trackedProcessDao.insert(tp);

        CurrentMetadataEntity metadata = metadataManagement.findAllEntitiesRecursively(namespace, entityName);
        metadata.setCurrentEntityName(MetadataConstants.CoreModelEntity.QUALIFIED_TRACKING_ID.getFullName());
        QualifiedTrackingId qualifiedTrackingId = new QualifiedTrackingId();
        qualifiedTrackingId.setMetadata(metadata);
        qualifiedTrackingId.setProcessId(processId);
        qualifiedTrackingId.setObservedProcessId(processId);
        qualifiedTrackingId.setValidTo(MAX_TIMESTAMP);
        qualifiedTrackingId.setValidFrom(MIN_TIMESTAMP);

        qualifiedTrackingIdDao.insert(Arrays.asList(qualifiedTrackingId));
        List<QualifiedTrackingId> all = qualifiedTrackingIdDao.findAll(qualifiedTrackingId.getObservedProcessId(),
                Instant.now());
        assertThat(all.size()).isEqualTo(1);
        Map<UUID, String> map = qualifiedTrackingIdDao.getCorrelatedProcessMap(processId, Instant.now(), 2);
        assertThat(map.size()).isEqualTo(1);

        qualifiedTrackingIdDao.getCorrelatedProcessId(qualifiedTrackingId.getProcessId(),
                Instant.now(), 1);

        qualifiedTrackingIdDao.deleteByProcessId(qualifiedTrackingId.getProcessId());
        qualifiedTrackingIdDao.deleteByProcessId(qualifiedTrackingId.getMetadata(),
                qualifiedTrackingId.getObservedProcessId());

        qualifiedTrackingIdDao.delete(qualifiedTrackingId.getMetadata(),
                qualifiedTrackingId.getProcessId(),
                qualifiedTrackingId.getObservedProcessId());

        QualifiedTrackingId another = new QualifiedTrackingId(qualifiedTrackingId.getInternalValue());
        assertThat(qualifiedTrackingId).isEqualTo(another);

    }
}