package com.sap.gtt.v2.core.dao.tracking;

import com.sap.gtt.v2.BaseTest;
import com.sap.gtt.v2.Dummy;
import com.sap.gtt.v2.core.dao.metadata.DefaultMetadataDao;
import com.sap.gtt.v2.core.dao.metadata.IMetadataDao;
import com.sap.gtt.v2.core.dao.metadata.ISysTableDao;
import com.sap.gtt.v2.core.domain.metadata.CurrentMetadataEntity;
import com.sap.gtt.v2.core.domain.metadata.MetadataEntity;
import com.sap.gtt.v2.core.entity.metadata.MetadataProject;
import com.sap.gtt.v2.core.entity.metadata.MetadataProjectFile;
import com.sap.gtt.v2.core.entity.trackedprocess.Event;
import com.sap.gtt.v2.core.management.metadata.CsnParser;
import com.sap.gtt.v2.core.management.metadata.DefaultMetadataManagement;
import com.sap.gtt.v2.core.management.metadata.IMetadataManagement;
import com.sap.gtt.v2.util.SpringContextUtils;
import org.apache.commons.io.IOUtils;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.IOException;
import java.time.Instant;
import java.util.List;
import java.util.UUID;

import static org.junit.Assert.assertTrue;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = Dummy.class)
@ActiveProfiles("test")
public class DaoHelperExTest extends BaseTest {

    private static final String DERIVED_CSN_FILE = "com_sap_gtt_app_test._tfo_FreightOrderModel_derived_csn.json";
    private static final String ORIGINAL_CSN_FILE = "";
    public static final String UTF_8 = "UTF-8";


    @Autowired
    private IMetadataDao metadataDao;

    @Autowired
    private ISysTableDao sysTableDao;

    @Autowired
    private DaoHelper daoHelper;

    private DefaultMetadataDao defaultMetadataDao;

    public void setDefaultMetadataDao(DefaultMetadataDao defaultMetadataDao) {
        this.defaultMetadataDao = defaultMetadataDao;
    }

    @Before
    public void setUp() {
        super.setUp();
        defaultMetadataDao = ((DefaultMetadataDao) SpringContextUtils.getBean(DefaultMetadataDao.BEAN_NAME));
    }

    @Test
    public void test() throws IOException {
        insertMetadataProject();
        createTables();

        String namespace = "com.sap.gtt.app.test.tfo";
        String entityName = "com.sap.gtt.app.test.tfo.FreightOrderModel.DelayedEvent";
        IMetadataManagement metadataManagement = DefaultMetadataManagement.getInstance();
        CurrentMetadataEntity metadata = metadataManagement.findAllEntitiesRecursively(namespace, entityName);
        metadata.setCurrentEntityName("com.sap.gtt.app.test.tfo.FreightOrderModel.DelayedEvent");

        DelayedEvent delayedEvent = new DelayedEvent();
        delayedEvent.setId(UUID.randomUUID());
        delayedEvent.setActualBusinessTimestamp(Instant.now());
        delayedEvent.setActualBusinessTimeZone("");
        delayedEvent.setAltKey("alt-key");
        delayedEvent.setCloneInstanceId(UUID.randomUUID());
        delayedEvent.setCreatedByUser("");
        delayedEvent.setCreationDateTime(Instant.now());
        delayedEvent.setActualTechnicalTimestamp(Instant.now());
        delayedEvent.setEventReasonText("reason");
        delayedEvent.setEventType("arrived");
        delayedEvent.setLastChangedByUser("");
        delayedEvent.setLastChangedDateTime(Instant.now());
        //event.setLocationId(UUID.randomUUID());
        delayedEvent.setLocationAltKey("location-alt-key");
        delayedEvent.setLogicalSystem("001");
        delayedEvent.setMessageSourceType("message-source-type");
        //event.setPartyId(UUID.randomUUID());
        delayedEvent.setScheme("scheme");
        delayedEvent.setSenderPartyId(UUID.randomUUID().toString());
        delayedEvent.setTrackingId("tracking-id");
        delayedEvent.setSubaccountId(UUID.randomUUID());
        delayedEvent.setTrackingIdType("tracking-id-type");
        delayedEvent.setRefPlannedEventType("CarrierArrival");
        delayedEvent.setRefPlannedEventMatchKey("001");
        delayedEvent.setRefPlannedEventLocationAltKey("loc-alt-key");
        delayedEvent.setMetadata(metadata);

        DelayedEvent retrieved = daoHelper.insert(delayedEvent);
        Assertions.assertThat(retrieved.getId()).isEqualTo(delayedEvent.getId());
        Assertions.assertThat(retrieved.getRefPlannedEventType())
                .isEqualTo(delayedEvent.getRefPlannedEventType());

        delayedEvent.setScheme("scheme-modified");
        retrieved = daoHelper.update(delayedEvent);
        Assertions.assertThat(retrieved.getScheme()).isEqualTo(delayedEvent.getScheme());

        retrieved = daoHelper.findOneByPrimaryKey(DelayedEvent.class, metadata,
                delayedEvent.getId().getInternalValue());
        Assertions.assertThat(retrieved.getId()).isEqualTo(delayedEvent.getId());
        Assertions.assertThat(retrieved.getRefPlannedEventType())
                .isEqualTo(delayedEvent.getRefPlannedEventType());
        Assertions.assertThat(retrieved.getScheme()).isEqualTo(delayedEvent.getScheme());

        daoHelper.delete(delayedEvent);
        retrieved = daoHelper.findOneByPrimaryKey(DelayedEvent.class, metadata,
                delayedEvent.getId().getInternalValue());
        Assertions.assertThat(retrieved).isNull();
    }

    public void insertMetadataProject() throws IOException {
        String id = "888";
        String namespace = "com.sap.gtt.app.test.tfo";
        insertMetadata(id, namespace);
        assertTrue(true);
    }

    public void createTables() throws IOException {
        String derivedCsn = IOUtils.toString(getClass().getClassLoader()
                .getResourceAsStream(DERIVED_CSN_FILE), UTF_8);
        List<MetadataEntity> entities = CsnParser.parseToEntities(derivedCsn);
        sysTableDao.createTable(entities);
    }

    private void insertMetadata(String id, String namespace) throws IOException {
        List<MetadataProject> projects = defaultMetadataDao.findMetadataProjectInfoByNamespace(namespace);
        if (projects.size() > 0) {
            return;
        }
        MetadataProject metadataProject = new MetadataProject();
        metadataProject.setId(id);
        metadataProject.setNamespace(namespace);
        metadataProject.setUploadAt(Instant.now());
        metadataProject.setVersion("1.0.0");
        metadataProject.setStatus("ACTIVE");
        metadataProject.setDescription("test");
        metadataProject.setMode("Standard");
        metadataProject.setCoreModelVersion("1.0.0");
        metadataProject.setCompilerVersion("1.0.0");

        MetadataProjectFile metadataProjectFile = new MetadataProjectFile();
        metadataProject.setMetadataProjectFile(metadataProjectFile);
        metadataProjectFile.setId(metadataProject.getId());
        String derivedCsn = IOUtils.toString(getClass().getClassLoader()
                .getResourceAsStream(DERIVED_CSN_FILE), UTF_8);
        metadataProjectFile.setDerivedCsn(derivedCsn);

        defaultMetadataDao.insertMetadataProject(metadataProject);
    }

    private static class DelayedEvent extends Event {
        public DelayedEvent() {super();}
        public String getRefPlannedEventType() {
            return getValueAsString("refPlannedEventType");
        }

        public void setRefPlannedEventType(String value) {
            setValue("refPlannedEventType", value);
        }

        public String getRefPlannedEventMatchKey() {
            return getValueAsString("refPlannedEventMatchKey");
        }

        public void setRefPlannedEventMatchKey(String value) {
            setValue("refPlannedEventMatchKey", value);
        }

        public String getRefPlannedEventLocationAltKey() {
            return getValueAsString("refPlannedEventLocationAltKey");
        }

        public void setRefPlannedEventLocationAltKey(String value) {
            setValue("refPlannedEventLocationAltKey", value);
        }
    }

}
