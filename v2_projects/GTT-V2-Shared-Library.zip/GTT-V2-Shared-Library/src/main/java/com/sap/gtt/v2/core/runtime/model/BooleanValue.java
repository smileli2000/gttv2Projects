package com.sap.gtt.v2.core.runtime.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.sap.gtt.v2.core.rule.impl.MemoryBlockException;
import com.sap.gtt.v2.core.runtime.model.IPropertyValue.FunctionInterfaceDef;

public final class BooleanValue extends AbstractPropertyValue<Boolean> {
    
	public static final BooleanValue TRUE = new BooleanValue(true);
	public static final BooleanValue FALSE = new BooleanValue(false);
	
	
	
	// define functions
	protected static final Map<String, FunctionInterfaceDef> functionDefs = new HashMap<>();
	static{
		functionDefs.putAll(AbstractPropertyValue.functionDefs);
	}
	
	
	@Override
	protected Map<String, FunctionInterfaceDef> getFunctionDefs(){
		return functionDefs;
	}
	//
    
	private BooleanValue(boolean internalValue) {
        super(internalValue);
    }
	
    @Override
    public boolean isCsnPrimitive() {
        return true;
    }

    @Override
    public boolean isCollection() {
        return false;
    }

	

	@Override
	protected BooleanValue orInternal(IPropertyValue that) {
		return (this.getInternalValue() || ((BooleanValue)that).getInternalValue()) ? BooleanValue.TRUE : BooleanValue.FALSE;
		
	}

	@Override
	protected BooleanValue andInternal(IPropertyValue that) {
		return (this.getInternalValue() && ((BooleanValue)that).getInternalValue()) ? BooleanValue.TRUE : BooleanValue.FALSE;
		
	}

	@Override
	protected BooleanValue notInternal() {
		return (!this.getInternalValue()) ? BooleanValue.TRUE : BooleanValue.FALSE;
	}
    
	public static BooleanValue valueOf(String value){
		return valueOf(Boolean.parseBoolean(value));
	}
	
	public static BooleanValue valueOf(boolean value){
		
		return value ? BooleanValue.TRUE : BooleanValue.FALSE; 
	}

}
