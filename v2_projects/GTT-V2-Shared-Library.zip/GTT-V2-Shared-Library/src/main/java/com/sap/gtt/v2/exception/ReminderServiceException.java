package com.sap.gtt.v2.exception;

import org.apache.http.HttpStatus;

public class ReminderServiceException extends BaseRuntimeException {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3034362225797739217L;
	public static final String ERROR_CODE = "ERROR_CODE_REMINDER_SERVICE_UNPOST";
	public static final String MESSAGE_CODE_UNPOST = ReminderServiceException.class.getName() + ".Unpost";

	public ReminderServiceException(String internalMessage, Throwable cause, String messageCode,
			Object[] localizedMsgParams) {
		super(internalMessage, cause, messageCode, localizedMsgParams);
	}

	@Override
	public int getHttpStatus() {
		return HttpStatus.SC_GONE;
	}
	@Override
	public String getErrorCode() {
		return ERROR_CODE;
	}
}
