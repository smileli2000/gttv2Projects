package com.sap.gtt.v2.log;


import org.apache.commons.lang3.StringUtils;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.AuthenticationCredentialsNotFoundException;
import org.springframework.stereotype.Service;

import com.sap.gtt.v2.configuration.ISAPCloudPlatformAgent;
import com.sap.gtt.v2.exception.TenantServiceException;
import com.sap.gtt.v2.tenant.GTTTenantSetting;
import com.sap.gtt.v2.tenant.TenantService;
import com.sap.gtt.v2.util.GTTUtils;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.LoggerContext;

@Service
public class TenantAwareLogService {
	private static final org.slf4j.Logger globalLogger = LoggerFactory.getLogger(TenantAwareLogService.class);
	@Autowired
	private TenantService tenantSettingService;

	@Value("${tenantAwareLogger.enabled:#{true}}")
	private boolean enabled;
	
	@Autowired
	private ISAPCloudPlatformAgent.ICurrentAccessContext currentAccessContext;

	protected String getCloneServiceInstanceIdIfAvailable(){
		try{
			if(currentAccessContext.containsCloneServiceInstanceId()){
				return currentAccessContext.getCloneServiceInstanceId();
			}
			else return null;
		}
		catch(AuthenticationCredentialsNotFoundException e){
			globalLogger.debug(e.getMessage(),e);
			return null;
		}
		
	}
	
	protected String getSubaccountIdIfAvailable(){
		try{
			return currentAccessContext.getSubaccountId();
		}
		catch(AuthenticationCredentialsNotFoundException e){
			globalLogger.debug(e.getMessage(),e);
			return null;
		}
	}
	
	public void debug(String msg){
		Logger logger = this.getLogger(getSubaccountIdIfAvailable(), getCloneServiceInstanceIdIfAvailable());
		logger.debug(msg);
	}
	
	public void info(String msg){
		Logger logger = this.getLogger(getSubaccountIdIfAvailable(), getCloneServiceInstanceIdIfAvailable());
		logger.info(msg);
	}
	
	public void error(String msg){
		Logger logger = this.getLogger(getSubaccountIdIfAvailable(), getCloneServiceInstanceIdIfAvailable());
		logger.error(msg);
	}
	
	public void warn(String msg){
		Logger logger = this.getLogger(getSubaccountIdIfAvailable(), getCloneServiceInstanceIdIfAvailable());
		logger.warn(msg);
	}

	public void debug(String msg, Throwable cause){
		Logger logger = this.getLogger(getSubaccountIdIfAvailable(), getCloneServiceInstanceIdIfAvailable());
		logger.debug(msg,cause);
	}
	
	public void info(String msg, Throwable cause){
		Logger logger = this.getLogger(getSubaccountIdIfAvailable(), getCloneServiceInstanceIdIfAvailable());
		logger.info(msg,cause);
	}
	
	public void error(String msg, Throwable cause){
		Logger logger = this.getLogger(getSubaccountIdIfAvailable(), getCloneServiceInstanceIdIfAvailable());
		logger.error(msg,cause);
	}
	
	public void warn(String msg, Throwable cause){
		Logger logger = this.getLogger(getSubaccountIdIfAvailable(), getCloneServiceInstanceIdIfAvailable());
		logger.warn(msg,cause);
	}

	public void debug(String msg, Object... arguments) {
		Logger logger = this.getLogger(getSubaccountIdIfAvailable(), getCloneServiceInstanceIdIfAvailable());
		logger.debug(msg, arguments);
	}

	public void info(String msg, Object... arguments) {
		Logger logger = this.getLogger(getSubaccountIdIfAvailable(), getCloneServiceInstanceIdIfAvailable());
		logger.info(msg, arguments);
	}

	public void warn(String msg, Object... arguments) {
		Logger logger = this.getLogger(getSubaccountIdIfAvailable(), getCloneServiceInstanceIdIfAvailable());
		logger.warn(msg, arguments);
	}

	public void error(String msg, Object... arguments) {
		Logger logger = this.getLogger(getSubaccountIdIfAvailable(), getCloneServiceInstanceIdIfAvailable());
		logger.error(msg, arguments);
	}

	public void trace(String msg, Object... arguments) {
		Logger logger = this.getLogger(getSubaccountIdIfAvailable(), getCloneServiceInstanceIdIfAvailable());
		logger.trace(msg, arguments);
	}

	public void trace(String msg, Throwable t) {
		Logger logger = this.getLogger(getSubaccountIdIfAvailable(), getCloneServiceInstanceIdIfAvailable());
		logger.trace(msg, t);
	}
	
	protected Logger getLogger(String subaccountId,String cloneServiceInstanceId){
		LoggerContext loggerContext = (LoggerContext)LoggerFactory.getILoggerFactory();
		
		Logger logger = null;
		if(!enabled || StringUtils.isBlank(subaccountId)){
			// return default logger
			logger = loggerContext.getLogger(TenantAwareLogService.class);
		}
		else{
			
			GTTTenantSetting tenantSetting = tenantSettingService.get(subaccountId,cloneServiceInstanceId);
			//TODO remove it later
			if(tenantSetting == null) throw new TenantServiceException(
					String.format("Setting of Tenant '%s' under clone service instance id '%s' not found", subaccountId,cloneServiceInstanceId ));
			String loggerName = subaccountId + GTTUtils.GLOBAL_STRING_SPLITOR + cloneServiceInstanceId;
			logger = loggerContext.getLogger(loggerName);
			logger.setLevel(Level.toLevel(tenantSetting.getLogLevel()));
			
			
		}
		
		return logger;

	}

	/*public static TenantAwareLogService getLogService() {
		return instance;
	}
	private static TenantAwareLogService instance;
	@Override
	public void afterPropertiesSet() throws Exception {
		instance = this;
	}*/
}
