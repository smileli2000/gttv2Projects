package com.sap.gtt.v2.core.domain.trackedprocess;

import com.sap.gtt.v2.core.runtime.model.IPropertyValue;
import com.sap.gtt.v2.core.runtime.model.ObjectValue;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CorrelatedEvent extends ObjectValue {
    public static final String MATCHED = "matched";
    public static final String UNMATCHED = "unmatched";

    public void setMatched(List<MatchedCorrelatedEvent> plannedEvents) {
        List<IPropertyValue> list = new ArrayList<>();
        for(MatchedCorrelatedEvent event : plannedEvents) {
            list.add(event);
        }
        this.setValue(MATCHED, list);
    }

    public List<MatchedCorrelatedEvent> getPlannedEvents() {
        List<IPropertyValue> list = getValueAsList(MATCHED);
        if (!CollectionUtils.isEmpty(list)) {
            List<MatchedCorrelatedEvent> actualEvents = new ArrayList<>(list.size());
            for (IPropertyValue value : list) {
                MatchedCorrelatedEvent event = (MatchedCorrelatedEvent)value;
                actualEvents.add(event);
            }
            return actualEvents;
        }
        return Collections.emptyList();
    }

    public void setUnmatched(List<CorrelatedEventInner> unplannedEvents) {
        List<IPropertyValue> list = new ArrayList<>();
        for(CorrelatedEventInner event : unplannedEvents) {
            list.add(event);
        }
        this.setValue(UNMATCHED, list);
    }

    public List<CorrelatedEventInner> getUnmatched() {
        List<IPropertyValue> list = getValueAsList(UNMATCHED);
        if (!CollectionUtils.isEmpty(list)) {
            List<CorrelatedEventInner> actualEvents = new ArrayList<>(list.size());
            for (IPropertyValue value : list) {
                CorrelatedEventInner event = (CorrelatedEventInner)value;
                actualEvents.add(event);
            }
            return actualEvents;
        }
        return Collections.emptyList();
    }

}
