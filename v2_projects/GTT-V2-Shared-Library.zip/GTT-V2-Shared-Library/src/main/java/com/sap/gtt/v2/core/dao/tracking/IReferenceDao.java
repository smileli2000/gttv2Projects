package com.sap.gtt.v2.core.dao.tracking;

import com.sap.gtt.v2.core.domain.metadata.CurrentMetadataEntity;
import com.sap.gtt.v2.core.entity.trackedprocess.Reference;

import java.util.List;
import java.util.UUID;

public interface IReferenceDao {
    void insert(Reference reference);

    void insert(List<Reference> references);

    void delete(CurrentMetadataEntity metadata, UUID id);

    void update(Reference reference);
}
