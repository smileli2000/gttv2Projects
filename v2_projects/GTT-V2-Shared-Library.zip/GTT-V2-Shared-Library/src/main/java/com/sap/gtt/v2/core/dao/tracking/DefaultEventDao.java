package com.sap.gtt.v2.core.dao.tracking;

import com.sap.gtt.v2.core.domain.metadata.CurrentMetadataEntity;
import com.sap.gtt.v2.core.domain.metadata.MetadataConstants;
import com.sap.gtt.v2.core.domain.trackedprocess.EventWrapper;
import com.sap.gtt.v2.core.entity.trackedprocess.Event;
import com.sap.gtt.v2.core.entity.trackedprocess.ProcessEventDirectory;
import com.sap.gtt.v2.log.TenantAwareLogService;
import com.sap.gtt.v2.util.DBUtils;
import com.sap.gtt.v2.util.SpringContextUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.*;

/**
 * @author I053866
 */
@Repository(DefaultEventDao.BEAN_NAME)
public class DefaultEventDao implements IEventDao {
    public static final String BEAN_NAME = "com.sap.gtt.v2.core.dao.tracking.DefaultEventDao";
    private static final String WHERE = " where ";
    private static final String T_2 = " = T2.";
    private static final String FROM = " from ";
    private static final String SELECT_T_1 = "select T1.*, ";
    private static final String T_1_INNER_JOIN = " T1 inner join ";
    private static final String T_2_ON_T_1 = " T2 on T1.";
    private static final String WHERE_T_2 = " where T2.";
    private static final String EVENT_TYPES = "eventTypes";
    private static final String SQL_ID_EVENT_TYPES = "sql:{}, id:{}, eventTypes:{}";
    @Autowired
    private TenantAwareLogService logService;

    protected DefaultEventDao() {
    }

    public static DefaultEventDao getInstance() {
        return (DefaultEventDao) SpringContextUtils.getBean(BEAN_NAME);
    }

    @Autowired
    private DaoHelper daoHelper;

    @Override
    public void insert(Event event) {
        daoHelper.insert(event);
    }

    @Override
    public void insert(List<Event> events) {
        for (Event event : events) {
            insert(event);
        }
    }

    @Override
    public void delete(CurrentMetadataEntity metadata, UUID id) {
        daoHelper.delete(metadata, id);
    }

    @Override
    public void update(Event event) {
        daoHelper.update(event);
    }

    @Override
    public List<Event> findByAltKey(CurrentMetadataEntity metadata, String altKey) {
        return daoHelper.findAll(Event.class, metadata, "altKey = ?", altKey);
    }

    @Override
    public List<Event> findAllByAltKeys(CurrentMetadataEntity metadata, List<String> altKeyList) {
        return daoHelper.findAll(Event.class, metadata, "altKey in (:altKeyList)",
                new MapSqlParameterSource().addValue("altKeyList", altKeyList));
    }

    @Override
    public List<Event> findAllByAltKeys(CurrentMetadataEntity metadata, String... altKeys) {
        return daoHelper.findAll(Event.class, metadata, "altKey in (:altKeys)",
                new MapSqlParameterSource().addValue("altKeys", altKeys));
    }

    @Override
    public Event findOne(CurrentMetadataEntity metadata, UUID id) {
        return daoHelper.findOneByPrimaryKey(Event.class, metadata, id);
    }

    @Override
    public Event findOneById(UUID id) {
        if (id == null) {
            return null;
        }

        String sql = new StringBuilder("select * from ")
                .append(DBUtils.toTableName(MetadataConstants.CoreModelEntity.EVENT.getFullName()))
                .append(" T where T.")
                .append(DBUtils.toElementPhysicalName(Event.ID))
                .append(" = :id ")
                .toString();
        logService.debug("sql:{}, id:{}", sql, id);
        List<Event> events = daoHelper.getNamedParameterJdbcTemplate().query(sql,
                new MapSqlParameterSource().addValue("id", id),
                new EventRowMapper());

        if (!events.isEmpty()) {
            return events.get(0);
        } else {
            return null;
        }

    }

    @Override
    public void deleteByProcessId(UUID tpId) {
        // hana sql does not support delete with inner join, use sub query instead
        String sql = new StringBuilder("delete from ")
                .append(DBUtils.toTableName(MetadataConstants.CoreModelEntity.EVENT.getFullName()))
                .append(WHERE).append(DBUtils.toElementPhysicalName(Event.ID))
                .append(" in (select ").append(DBUtils.toElementPhysicalName(ProcessEventDirectory.EVENT_ID))
                .append(FROM)
                .append(DBUtils.toTableName(MetadataConstants.CoreModelEntity.PROCESS_EVENT_DIRECTORY.getFullName()))
                .append(WHERE).append(DBUtils.toElementPhysicalName(ProcessEventDirectory.PROCESS_ID))
                .append(" = ? )").toString();

        logService.debug("sql:{}, tpId:{}", sql, tpId);
        daoHelper.getJdbcTemplate().update(sql, tpId);
    }


    @Override
    public List<EventWrapper> getActualEventsForCurrentTPIncludeEventTypes(UUID tpId, List<String> eventTypes) {
        if (CollectionUtils.isEmpty(eventTypes)) {
            return new ArrayList<>();
        }

        String sql = new StringBuilder(SELECT_T_1)
                .append(DBUtils.toElementPhysicalName(ProcessEventDirectory.PLANNED_EVENT_ID))
                .append(" , ")
                .append(DBUtils.toElementPhysicalName(ProcessEventDirectory.CORRELATION_TYPE))
                .append(FROM)
                .append(DBUtils.toTableName(MetadataConstants.CoreModelEntity.EVENT.getFullName()))
                .append(T_1_INNER_JOIN)
                .append(DBUtils.toTableName(MetadataConstants.CoreModelEntity.PROCESS_EVENT_DIRECTORY.getFullName()))
                .append(T_2_ON_T_1).append(DBUtils.toElementPhysicalName(Event.ID))
                .append(T_2).append(DBUtils.toElementPhysicalName(ProcessEventDirectory.EVENT_ID))
                .append(WHERE_T_2).append(DBUtils.toElementPhysicalName(ProcessEventDirectory.PROCESS_ID))
                .append(" =:id and ")
                .append(DBUtils.toElementPhysicalName(Event.EVENT_TYPE))
                .append(" in (:eventTypes) ")
                .toString();

        logService.debug(SQL_ID_EVENT_TYPES, sql, tpId, eventTypes);
        return daoHelper.getNamedParameterJdbcTemplate().query(sql,
                new MapSqlParameterSource().addValue("id", tpId)
                        .addValue(EVENT_TYPES, eventTypes),
                new EventWrapperRowMapper());
    }

    @Override
    public List<EventWrapper> getActualEventsForCurrentTPExcludeEventTypes(UUID tpId, List<String> eventTypes) {
        StringBuilder sb = new StringBuilder(SELECT_T_1)
                .append(DBUtils.toElementPhysicalName(ProcessEventDirectory.PLANNED_EVENT_ID))
                .append(" , ")
                .append(DBUtils.toElementPhysicalName(ProcessEventDirectory.CORRELATION_TYPE))
                .append(FROM)
                .append(DBUtils.toTableName(MetadataConstants.CoreModelEntity.EVENT.getFullName()))
                .append(T_1_INNER_JOIN)
                .append(DBUtils.toTableName(MetadataConstants.CoreModelEntity.PROCESS_EVENT_DIRECTORY.getFullName()))
                .append(T_2_ON_T_1).append(DBUtils.toElementPhysicalName(Event.ID))
                .append(T_2).append(DBUtils.toElementPhysicalName(ProcessEventDirectory.EVENT_ID))
                .append(WHERE_T_2).append(DBUtils.toElementPhysicalName(ProcessEventDirectory.PROCESS_ID))
                .append(" =:id ");

        if (!CollectionUtils.isEmpty(eventTypes)) {
            sb.append(" and ").append(DBUtils.toElementPhysicalName(Event.EVENT_TYPE))
                    .append(" not in (:eventTypes) ");
        }

        String sql = sb.toString();
        logService.debug(SQL_ID_EVENT_TYPES, sql, tpId, eventTypes);
        MapSqlParameterSource mapSqlParameterSource = new MapSqlParameterSource()
                .addValue("id", tpId);
        if (!CollectionUtils.isEmpty(eventTypes)) {
            mapSqlParameterSource.addValue(EVENT_TYPES, eventTypes);
        }

        return daoHelper.getNamedParameterJdbcTemplate().query(sql,
                mapSqlParameterSource,
                new EventWrapperRowMapper());
    }

    private class EventWrapperRowMapper implements RowMapper<EventWrapper> {
        @Override
        public EventWrapper mapRow(ResultSet rs, int rowNum) throws SQLException {
            UUID plannedEventId = null;
            String columnValue = rs.getString(DBUtils.toElementPhysicalName(ProcessEventDirectory.PLANNED_EVENT_ID));
            if (StringUtils.isNotEmpty(columnValue)) {
                plannedEventId = UUID.fromString(columnValue);
            }

            String correlationType = rs.getString(
                    DBUtils.toElementPhysicalName(ProcessEventDirectory.CORRELATION_TYPE));


            EventRowMapper eventRowMapper = new EventRowMapper();
            Event event = eventRowMapper.mapRow(rs, rowNum);

            return new EventWrapper(plannedEventId, correlationType, event);
        }
    }

    @Override
    public Event findOneByTpIdAndEventType(CurrentMetadataEntity metadata, UUID tpId, String eventType) {
        List<EventWrapper> actualEvents = getActualEventsForCurrentTPIncludeEventTypes(tpId, Arrays.asList(eventType));

        if (actualEvents.isEmpty()) {
            return null;
        } else {
            return daoHelper.findOneByPrimaryKey(Event.class, metadata, actualEvents.get(0).getEvent().getIdAsInternalValue());
        }
    }

    @Override
    public Event findLatestByTpIdAndEventTypeList(UUID tpId, List<String> eventTypes) {
        if (CollectionUtils.isEmpty(eventTypes)) {
            return null;
        }

        String sql = new StringBuilder(SELECT_T_1)
                .append(DBUtils.toElementPhysicalName(ProcessEventDirectory.PLANNED_EVENT_ID))
                .append(" , ")
                .append(DBUtils.toElementPhysicalName(ProcessEventDirectory.CORRELATION_TYPE))
                .append(FROM)
                .append(DBUtils.toTableName(MetadataConstants.CoreModelEntity.EVENT.getFullName()))
                .append(T_1_INNER_JOIN)
                .append(DBUtils.toTableName(MetadataConstants.CoreModelEntity.PROCESS_EVENT_DIRECTORY.getFullName()))
                .append(T_2_ON_T_1).append(DBUtils.toElementPhysicalName(Event.ID))
                .append(" = T2.").append(DBUtils.toElementPhysicalName(ProcessEventDirectory.EVENT_ID))
                .append(WHERE_T_2).append(DBUtils.toElementPhysicalName(ProcessEventDirectory.PROCESS_ID))
                .append(" =:id and ")
                .append(DBUtils.toElementPhysicalName(Event.EVENT_TYPE))
                .append(" in (:eventTypes) ")
                .append(" order by ").append(DBUtils.toElementPhysicalName(Event.ACTUAL_BUSINESS_TIMESTAMP)).append(" desc, ")
                .append(DBUtils.toElementPhysicalName(Event.ACTUAL_TECHNICAL_TIMESTAMP)).append(" desc ")
                .append(" limit 1 ")
                .toString();

        logService.debug("sql:{}, id:{}, eventTypes:{}", sql, tpId, eventTypes);
        List<Event> events = daoHelper.getNamedParameterJdbcTemplate().query(sql,
                new MapSqlParameterSource().addValue("id", tpId)
                        .addValue(EVENT_TYPES, eventTypes),
                new EventRowMapper());

        if (!events.isEmpty()) {
            return events.get(0);
        } else {
            return null;
        }
    }

    private class EventRowMapper implements RowMapper<Event> {

        @Override
        public Event mapRow(ResultSet rs, int rowNum) throws SQLException {
            Event event = new Event();
            Timestamp actualTechnicalTimestamp = rs.getTimestamp(Event.ACTUAL_TECHNICAL_TIMESTAMP);
            event.setActualTechnicalTimestamp(actualTechnicalTimestamp == null ? null : actualTechnicalTimestamp.toInstant());
            event.setEventReasonText(rs.getString(Event.EVENT_REASON_TEXT));
            event.setEventType(rs.getString(Event.EVENT_TYPE));
            event.setModelNamespace(rs.getString(Event.MODEL_NAMESPACE));

            String cloneInstanceId = rs.getString(Event.CLONEINSTANCEID);
            event.setCloneInstanceId(StringUtils.isEmpty(cloneInstanceId) ? null : UUID.fromString(cloneInstanceId));

            String subAccountId = rs.getString(Event.SUBACCOUNTID);
            event.setSubaccountId(StringUtils.isEmpty(subAccountId) ? null : UUID.fromString(subAccountId));

            String id = rs.getString(Event.ID);
            event.setId(StringUtils.isEmpty(id) ? null : UUID.fromString(id));
            event.setTrackingIdType(rs.getString(Event.TRACKING_ID_TYPE));
            event.setTrackingId(rs.getString(Event.TRACKING_ID));
            event.setPriority(rs.getInt(Event.PRIORITY));
            String senderPartyId = rs.getString(Event.SENDER_PARTY_ID);
            event.setSenderPartyId(senderPartyId);
            event.setScheme(rs.getString(Event.SCHEME));
            event.setMessageSourceType(rs.getString(Event.MESSAGE_SOURCE_TYPE));
            event.setLogicalSystem(rs.getString(Event.LOGICAL_SYSTEM));
            event.setLocationAltKey(rs.getString(Event.LOCATION_ALT_KEY));
            event.setEventMatchKey(rs.getString(Event.EVENT_MATCH_KEY));

            Timestamp creationDateTime = rs.getTimestamp(Event.CREATION_DATE_TIME);
            event.setCreationDateTime(creationDateTime == null ? null : creationDateTime.toInstant());
            event.setCreatedByUser(rs.getString(Event.CREATED_BY_USER));
            event.setAltKey(rs.getString(Event.ALT_KEY));
            event.setActualBusinessTimeZone(rs.getString(Event.ACTUAL_BUSINESS_TIME_ZONE));

            Timestamp actualBusinessTimestamp = rs.getTimestamp(Event.ACTUAL_BUSINESS_TIMESTAMP);
            event.setActualBusinessTimestamp(actualBusinessTimestamp == null ? null : actualBusinessTimestamp.toInstant());
            event.setPartyId(rs.getString(Event.PARTYID));
            return event;
        }
    }


    @Override
    public List<Event> findByAltKey(String altKey) {
        String sql = new StringBuilder("select * from ")
                .append(DBUtils.toTableName(MetadataConstants.CoreModelEntity.EVENT.getFullName()))
                .append(WHERE)
                .append(DBUtils.toElementPhysicalName(Event.ALT_KEY))
                .append(" = ? ").toString();

        logService.debug("sql:{}, altKey:{}", sql, altKey);
        return daoHelper.getJdbcTemplate().query(sql, new Object[]{altKey}, new EventRowMapper());
    }

    @Override
    public List<EventTypeAndId> findEventTypeAndIdByAltKey(String altKey) {
        String sql = new StringBuilder("select ")
                .append(DBUtils.toElementPhysicalName(Event.EVENT_TYPE))
                .append(", ")
                .append(DBUtils.toElementPhysicalName(Event.ID))
                .append(FROM)
                .append(DBUtils.toTableName(MetadataConstants.CoreModelEntity.EVENT.getFullName()))
                .append(WHERE)
                .append(DBUtils.toElementPhysicalName(Event.ALT_KEY))
                .append(" = ? ").toString();

        logService.debug("sql:{}, altKey:{}", sql, altKey);
        return daoHelper.getJdbcTemplate().query(sql, new Object[]{altKey},
                (rs, rowNum) -> {
                    String eventType = rs.getString(Event.EVENT_TYPE);
                    String id = rs.getString(Event.ID);
                    return new EventTypeAndId(eventType, StringUtils.isEmpty(id) ? null : UUID.fromString(id));
                });
    }

    public static class EventTypeAndId {
        private String eventType;
        private UUID id;

        public EventTypeAndId(String eventType, UUID id) {
            this.eventType = eventType;
            this.id = id;
        }

        public String getEventType() {
            return eventType;
        }

        public void setEventType(String eventType) {
            this.eventType = eventType;
        }

        public UUID getId() {
            return id;
        }

        public void setId(UUID id) {
            this.id = id;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) {
                return true;
            }
            if (o == null || getClass() != o.getClass()) {
                return false;
            }
            EventTypeAndId that = (EventTypeAndId) o;
            return Objects.equals(getEventType(), that.getEventType()) &&
                    Objects.equals(getId(), that.getId());
        }

        @Override
        public int hashCode() {
            return Objects.hash(getEventType(), getId());
        }
    }
}
