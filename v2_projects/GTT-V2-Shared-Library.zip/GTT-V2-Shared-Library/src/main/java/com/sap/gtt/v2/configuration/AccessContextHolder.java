package com.sap.gtt.v2.configuration;

import java.io.Serializable;
import java.util.Locale;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.springframework.context.i18n.LocaleContextHolder;

import com.sap.gtt.v2.core.entity.trackedprocess.Event;
import com.sap.gtt.v2.servicemanager.GTTInstance;

/**
 * Thead-Local
 * @author I053866
 *
 */
public class AccessContextHolder {

	private AccessContextHolder() {
		throw new IllegalStateException("AccessContextHolder class");
	}

	public static class AccessContext implements Serializable{

		private static final long serialVersionUID = -5531624618219974039L;
		private String subaccountId;
		private String logonName;
		private String subdomain;
		private String cloneServiceInstanceId;
		private Locale locale;
		private GTTInstance instance; // prior to cloneServiceInstanceId + subaccountId
		private boolean userToken;
		private boolean integrationUserToken;
		private boolean productive;
		private boolean solutionOwner;
		
		public AccessContext(String subaccountId, String logonName, String subdomain, String cloneServiceInstanceId,
				Locale locale, GTTInstance instance, boolean userToken, boolean integrationUserToken,
				boolean productive,
				boolean solutionOwner) {
			super();
			this.subaccountId = subaccountId;
			this.logonName = logonName;
			this.subdomain = subdomain;
			this.cloneServiceInstanceId = cloneServiceInstanceId;
			this.locale = locale;
			this.instance = instance;
			this.userToken = userToken;
			this.integrationUserToken = integrationUserToken;
			this.productive = productive;
			this.solutionOwner = solutionOwner;
		}
		public String getSubaccountId() {
			return subaccountId;
		}
		public void setSubaccountId(String subaccountId) {
			this.subaccountId = subaccountId;
		}
		public String getLogonName() {
			return logonName;
		}
		public void setLogonName(String logonName) {
			this.logonName = logonName;
		}
		public String getSubdomain() {
			return subdomain;
		}
		public void setSubdomain(String subdomain) {
			this.subdomain = subdomain;
		}
		public String getCloneServiceInstanceId() {
			return cloneServiceInstanceId;
		}
		public void setCloneServiceInstanceId(String cloneServiceInstanceId) {
			this.cloneServiceInstanceId = cloneServiceInstanceId;
		}
		
		
		public GTTInstance getInstance() {
			return instance;
		}
		public void setInstance(GTTInstance instance) {
			this.instance = instance;
		}
		public Locale getLocale() {
			return locale;
		}
		public void setLocale(Locale locale) {
			this.locale = locale;
		}
		public boolean isUserToken() {
			return userToken;
		}
		public void setUserToken(boolean userToken) {
			this.userToken = userToken;
		}
		public boolean isIntegrationUserToken() {
			return integrationUserToken;
		}
		public void setIntegrationUserToken(boolean integrationUserToken) {
			this.integrationUserToken = integrationUserToken;
		}
		public boolean isProductive() {
			return productive;
		}
		public void setProductive(boolean productive) {
			this.productive = productive;
		}
		public boolean isSolutionOwner() {
			return solutionOwner;
		}
		public void setSolutionOwner(boolean solutionOwner) {
			this.solutionOwner = solutionOwner;
		}
		
		
	}
	
	private static final InheritableThreadLocal<AccessContext> accessContextThreadLocal = new InheritableThreadLocal<>();
	
	public static AccessContext get(){
		return accessContextThreadLocal.get();
	}
	
	public static void set(AccessContext accessContext){
		if(accessContext == null){
			clear();
			return;
		}
		accessContextThreadLocal.set(accessContext);
		// set Locale
		if(accessContext.getLocale() != null)
			LocaleContextHolder.setLocale(accessContext.getLocale(), true);
		
	}
	
	public static void clear(){
		accessContextThreadLocal.remove();
		LocaleContextHolder.resetLocaleContext();
		
	}
	
	public static void set(Event event){
		String subaccountId = event.getSubaccountId().toString();
		UUID cloneInstanceUUID = event.getCloneInstanceId();
		String cloneInstanceId = cloneInstanceUUID == null? StringUtils.EMPTY:cloneInstanceUUID.toString();
		AccessContext accessContext = new AccessContext(
				subaccountId, null , null, cloneInstanceId,
				null, null, false, false,false,false
		);
		set(accessContext);
	}
	
}
