package com.sap.gtt.v2.exception;

import org.apache.http.HttpStatus;

public class TrackedProcessCheckException extends BaseRuntimeException {
    public static final String ERROR_CODE = "ERROR_CODE_TRACKED_PROCESS_CHECK";

    public static final String MESSAGE_CODE_TP_IN_BLOCKING_STATUS = TrackedProcessCheckException.class.getName() + ".TPInBlockingStatus";
    public static final String MESSAGE_CODE_NEW_TP_IS_OLD = TrackedProcessCheckException.class.getName() + ".NewTpIsOld";
    public static final String MESSAGE_CODE_TP_NOT_EXIST= TrackedProcessCheckException.class.getName() + ".TPNotExist";

    public TrackedProcessCheckException(String messageCode,
                                      Object[] localizedMsgParams) {
        super(null, null, messageCode, localizedMsgParams);
    }

    @Override
    public int getHttpStatus() {
        return HttpStatus.SC_BAD_REQUEST;
    }

    @Override
    public String getErrorCode() {
        return ERROR_CODE;
    }
}
