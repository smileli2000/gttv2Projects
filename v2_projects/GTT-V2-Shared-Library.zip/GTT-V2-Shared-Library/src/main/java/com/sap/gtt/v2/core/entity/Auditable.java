package com.sap.gtt.v2.core.entity;

import java.time.Instant;

public interface Auditable {
    Instant getCreationDateTime();

    void setCreationDateTime(Instant creationDateTime);

    Instant getLastChangedDateTime();

    void setLastChangedDateTime(Instant lastChangedDateTime);

    String getCreatedByUser();

    void setCreatedByUser(String createdByUser);

    String getLastChangedByUser();

    void setLastChangedByUser(String lastChangedByUser);

    String CREATION_DATE_TIME = "creationDateTime";
    String LAST_CHANGED_DATE_TIME = "lastChangeDateTime";
    String CREATED_BY_USER = "createdByUser";
    String LAST_CHANGED_BY_USER = "lastChangedByUser";
}
