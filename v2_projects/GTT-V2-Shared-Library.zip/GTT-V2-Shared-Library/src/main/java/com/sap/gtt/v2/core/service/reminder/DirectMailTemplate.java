package com.sap.gtt.v2.core.service.reminder;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.util.CollectionUtils;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.sap.gtt.v2.configuration.EnvironmentsConfiguration.VcapServiceParser.ReminderServiceInstance;
import com.sap.gtt.v2.configuration.ServiceInstancesMapping;
import com.sap.gtt.v2.core.runtime.model.BooleanValue;
import com.sap.gtt.v2.core.runtime.model.IPropertyValue;
import com.sap.gtt.v2.core.runtime.model.ObjectValue;
import com.sap.gtt.v2.core.runtime.model.StringValue;
import com.sap.gtt.v2.log.TenantAwareLogService;
import com.sap.gtt.v2.util.SpringContextUtils;

public class DirectMailTemplate extends MailNotification implements IMailNotification {
    public static final String TEMPLATE_ID = "templateId";
    public static final String TEMPLATE_SOURCE = "templateSource";
    public static final String LOCALE = "locale";
    public static final String RECIPIENTS = "recipients";
    public static final String USERDEFINED_PLACEHOLDERS = "userdefinedPlaceholders";
    public static final String USERDEFINED_PLACEHOLDERS_NAME = "userdefined_placeholders";
    public static final String SYSTEMDEFINED_PLACEHOLDERS = "systemdefinedPlaceholders";
    public static final String SYSTEMDEFINED_PLACEHOLDERS_NAME = "systemdefined_placeholders";
    public static final String APPLICATIONEFINED_PLACEHOLDERS = "applicationdefinedPlaceholders";
    public static final String APPLICATIONEFINED_PLACEHOLDERS_NAME = "applicationdefined_placeholders";
    public static final String TEMPLATERECIPIENTIGNORE = "templateRecipientIgnore";
    private static final String DEFAULT_TEMPLATE_SOURCE = "USERTEMPLATE";
    private static final String DEFAULT_LOCALE = "en";

    public void setTemplateId(String id) {
        this.setValue(TEMPLATE_ID, StringValue.valueOf(id));
    }

    public String getTemplateId() {
        if (!isValueProvided(TEMPLATE_ID)) {
            return null;
        }
        return (String) this.getValue(TEMPLATE_ID).getInternalValue();
    }

    public void setTemplateSource(String source) {
        this.setValue(TEMPLATE_SOURCE, StringValue.valueOf(source));
    }

    public String getTemplateSource() {
        if (!isValueProvided(TEMPLATE_SOURCE)) {
            return DEFAULT_TEMPLATE_SOURCE;
        }
        return (String) this.getValue(TEMPLATE_SOURCE).getInternalValue();
    }

    public void setLocale(String locale) {
        this.setValue(LOCALE, StringValue.valueOf(locale));
    }

    public String getLocale() {
        if (!isValueProvided(LOCALE)) {
            return DEFAULT_LOCALE;
        }
        return (String) this.getValue(LOCALE).getInternalValue();
    }

    public void setRecipients(List<String> recipients) {
        List<IPropertyValue> list = new ArrayList<>();
        for (String s : recipients) {
            list.add(StringValue.valueOf(s));
        }
        this.setValue(RECIPIENTS, list);
    }

    public List<String> getRecipients() {
        if (!this.isValueProvided(RECIPIENTS)) {
            return new ArrayList<>();
        }
        List<IPropertyValue> list = getValueAsList(RECIPIENTS);
        if (!CollectionUtils.isEmpty(list)) {
            List<String> rs = new ArrayList<>(list.size());
            for (IPropertyValue value : list) {
                StringValue s = (StringValue) value;
                rs.add(s.getInternalValue());
            }
            return rs;
        }
        return Collections.emptyList();
    }

    public void setUserDefPlaceHolders(JsonObject placeHolders) {
        ObjectValue obj = new ObjectValue();
        Set<String> keys = placeHolders.keySet();
        Iterator<String> its = keys.iterator();
        while (its.hasNext()) {
            String key = its.next();
            String value = placeHolders.get(key).getAsString();
            obj.setValue(key, value);
        }
        this.setValue(USERDEFINED_PLACEHOLDERS, obj);
    }

    public JsonObject getUserDefPlaceHolders() {
        if (!this.isValueProvided(USERDEFINED_PLACEHOLDERS)) {
            return new JsonObject();
        }
        JsonObject ret = new JsonObject();
        ObjectValue obj = (ObjectValue) this.getValue(USERDEFINED_PLACEHOLDERS);
        for (Map.Entry<String, IPropertyValue> entry : obj.getInternalValue().entrySet()) {
            String key = entry.getKey();
            IPropertyValue value = entry.getValue();
            ret.addProperty(key, value.toString());
        }
        return ret;
    }
    
    public JsonObject getAppDefPlaceHolders() {
        DirectMailTemplatePlaceholdersService serviceMailTemplate = SpringContextUtils.getBean(DirectMailTemplatePlaceholdersService.class);
    	return serviceMailTemplate.getTemplatePlaceHolders(this.getTemplateId());//"invite_charlie");
    }

    public void setTemplateRecipientIgnore(boolean ignore) {
        this.setValue(TEMPLATERECIPIENTIGNORE, BooleanValue.valueOf(ignore));
    }

    public boolean getTemplateRecipientIgnore() {
        if (!isValueProvided(TEMPLATERECIPIENTIGNORE)) {
            return false;
        }
        BooleanValue bv = (BooleanValue) this.getValue(TEMPLATERECIPIENTIGNORE);
        return bv.getInternalValue();
    }

    @Override
    public String getMailUri() {
        ServiceInstancesMapping serviceInstancesMapping = SpringContextUtils.getBean(ServiceInstancesMapping.class);
        ReminderServiceInstance reminderServiceInstance = serviceInstancesMapping.getReminderServiceInstance();
        return reminderServiceInstance.getEndpoint() + "directmailtemplate";
    }

    @Override
    public JsonObject getRequestBody() {
    	TenantAwareLogService logService = SpringContextUtils.getBean(TenantAwareLogService.class);
    	logService.info("===> getRequestBody start");
        JsonObject requestBody = new JsonObject();
        requestBody.addProperty(TEMPLATE_ID, this.getTemplateId());
        requestBody.addProperty(TEMPLATE_SOURCE, this.getTemplateSource());
        requestBody.addProperty(LOCALE, this.getLocale());

        JsonArray recipients = new JsonArray();
        for (String r : this.getRecipients()) {
            recipients.add(r);
        }

        requestBody.add(RECIPIENTS, recipients);
        requestBody.add(USERDEFINED_PLACEHOLDERS_NAME, getUserDefPlaceHolders());
        requestBody.add(SYSTEMDEFINED_PLACEHOLDERS_NAME, new JsonArray());
        JsonObject appPlaceholders = getAppDefPlaceHolders();
        if(appPlaceholders != null)
        	requestBody.add(APPLICATIONEFINED_PLACEHOLDERS_NAME, appPlaceholders);
        requestBody.addProperty(TEMPLATERECIPIENTIGNORE, this.getTemplateRecipientIgnore());
        return requestBody;
    }
}