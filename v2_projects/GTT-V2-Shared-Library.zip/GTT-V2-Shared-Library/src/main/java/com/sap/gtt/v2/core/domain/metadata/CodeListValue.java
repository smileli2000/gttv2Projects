package com.sap.gtt.v2.core.domain.metadata;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.StringJoiner;

/**
 * @author I301346
 */
public class CodeListValue implements Serializable {
    private static final long serialVersionUID = 1L;

    private String code;

    private String name;

    private List<CodeListText> codeListTexts = new ArrayList<>();

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<CodeListText> getCodeListTexts() {
        return new ArrayList<>(codeListTexts);
    }

    public void addCodeListTexts(CodeListText codeListText) {
        codeListTexts.add(codeListText);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        CodeListValue entity = (CodeListValue) o;
        return Objects.equals(code, entity.code) &&
                Objects.equals(name, entity.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(code, name);
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", CodeListValue.class.getSimpleName() + "[", "]")
                .add("code='" + code + "'")
                .add("name='" + name + "'")
                .toString();
    }
}
