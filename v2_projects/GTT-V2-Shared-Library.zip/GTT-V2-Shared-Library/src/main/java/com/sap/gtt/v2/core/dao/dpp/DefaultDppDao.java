package com.sap.gtt.v2.core.dao.dpp;

import com.sap.gtt.v2.core.domain.dpp.DppEntity;
import com.sap.gtt.v2.core.domain.dpp.DppProperty;
import com.sap.gtt.v2.core.domain.metadata.MetadataConstants;
import com.sap.gtt.v2.util.DBUtils;
import com.sap.gtt.v2.util.SpringContextUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Repository;

import java.util.*;

import static com.sap.gtt.v2.core.domain.metadata.MetadataConstants.*;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.stream.Collectors;

@Repository(DefaultDppDao.BEAN_NAME)
public class DefaultDppDao implements IDppDao {
    public static final String BEAN_NAME = "com.sap.gtt.v2.core.dao.dpp.DefaultDppDao";
    public static final String TABLE_NAME = "TABLE_NAME";
    public static final String SELECT = "SELECT ";
    public static final String FROM = " FROM ";
    public static final String COUNT = " COUNT(*) ";
    public static final String WHERE_1_1 = " WHERE 1=1 ";
    private static final Logger logger = LoggerFactory.getLogger(DefaultDppDao.class);

    @Autowired
    private JdbcTemplate jdbcTemplate;
    public static DefaultDppDao getInstance() {
        return (DefaultDppDao) SpringContextUtils.getBean(BEAN_NAME);
    }

    @Override
    public String getPdmSchema() {
        String getSql = new StringBuilder(SELECT)
                .append(VALUE_CLOB)
                .append(FROM)
                .append(SUB_ACCOUNT_CONFIGURATION)
                .append(WHERE_1_1)
                .append(" AND ")
                .append(PDM_KEY)
                .append(" = '")
                .append(PDM_SCHEMA)
                .append("'").toString();
        List<Map<String, Object>> pdmSchemaList = jdbcTemplate.queryForList(getSql);
        if(pdmSchemaList !=null && !pdmSchemaList.isEmpty()) {
            Map<String,Object>  pdmSchemaMap = pdmSchemaList.get(0);
            return pdmSchemaMap.get(VALUE_CLOB).toString();

        }else {
            return null;
        }
    }

    @Override
    public void insertPdmSchema(String pdmSchema) {
        StringBuilder insertSql = new StringBuilder();
        String[] columns = {PDM_KEY, VALUE_CLOB};
        DBUtils.buildInsertSql(SUB_ACCOUNT_CONFIGURATION, columns, insertSql);

        Object[] insertParams = new Object[]{
                PDM_SCHEMA,
                pdmSchema
        };
        //insert the pdm schema of the tenant to the configuration table.
        logger.info("*** in insertPdmSchema,begin jdbcTemplate.update , the pdmSchema is {} ",pdmSchema);
        jdbcTemplate.update(insertSql.toString(), insertParams);
        logger.info("*** in insertPdmSchema,end jdbcTemplate.update");
    }

    @Override
    public void updatePdmSchema(String pdmSchema) {
        StringBuilder updateSql = new StringBuilder();
        String[] updatedColumns = {VALUE_CLOB};
        Object[] updatedVal = {pdmSchema};
        String[] whereColumns = {PDM_KEY};
        Object[] whereVals = {PDM_SCHEMA};
        List<Object> updateParam = new ArrayList<>();
        DBUtils.buildUpdateSql(SUB_ACCOUNT_CONFIGURATION,
                updatedColumns,
                updatedVal,
                whereColumns,
                whereVals,
                updateSql,
                updateParam);
        //update the pdm schema of the tenant to the configuration table.
        logger.info("*** in updatePdmSchema,begin jdbcTemplate.update , the pdmSchema is {} ",pdmSchema);
        jdbcTemplate.update(updateSql.toString(), updateParam.toArray());
        logger.info("*** in updatePdmSchema,end jdbcTemplate.update ");
    }

    @Override
    public boolean isDataSubjectIdExistsInDB(String dataSubjectIdValue, List<DppEntity> dppEntities) {
        List<String> sqls = new ArrayList();
        for (DppEntity dppEntity : dppEntities) {
            if (dppEntity.getDataSubjectIdProperty() == null) {
                continue;
            }
            
            String tableName = dppEntity.getPhsicalName();
            DppProperty dppProperty = dppEntity.getDataSubjectIdProperty();
            List<DppProperty> specialProperties = new ArrayList<>();
            if (dppProperty != null) {
                specialProperties.add(dppProperty);
            }
            StringBuilder sqlSbTemp = new StringBuilder()
                    .append(SELECT)
                    .append(COUNT)
                    .append(" AS NUM ")
                    .append(FROM)
                    .append(tableName)
                    .append(WHERE_1_1)
                    .append(" AND (");
            sqlSbTemp.append(specialProperties.stream().map(property -> property.getPhysicalName().concat(" = '").concat(dataSubjectIdValue).concat("'")).collect(Collectors.joining(" OR ")));
            sqlSbTemp.append(")");
            sqls.add(sqlSbTemp.toString());
        }
        addCheckForEventAndTrackedProcess(dataSubjectIdValue, sqls);
        
        String tempSql = StringUtils.join(sqls, " \n UNION ALL ");
        String sql = new StringBuilder()
                .append(" SELECT SUM(NUM) AS TOTALNUM FROM ")
                .append("( \n")
                .append(tempSql)
                .append("\n)").toString();
        SqlRowSet result = jdbcTemplate.queryForRowSet(sql);
        int totalNum = 0;
        if (result.next()) {
            totalNum = result.getInt("TOTALNUM");
        }
        if (totalNum > 0) {
            return true;
        } else {
            return false;
        }
    }

    private void addCheckForEventAndTrackedProcess(String dataSubjectIdValue, List<String> sqls) {
        StringBuilder sqlSbTemp = new StringBuilder()
            .append(SELECT)
            .append(COUNT)
            .append(" AS NUM ")
            .append(FROM)
            .append(DBUtils.toTableName(MetadataConstants.CoreModelEntity.TRACKED_PROCESS.getFullName()))
            .append(" A LEFT JOIN (SELECT B.")
            .append(TRACKED_PROCESS_TYPE)
            .append(", C.")
            .append(STATUS)
            .append(FROM)
            .append(MetadataTable.METADATA_PROCESS.name())
            .append(" B LEFT JOIN ")
            .append(MetadataTable.METADATA_PROJECT)
            .append(" C ON B.")
            .append(METADATA_PROJECT_ID)
            .append(" = C.")
            .append(ID)
            .append(") D ON D.")
            .append(TRACKED_PROCESS_TYPE)
            .append(" = A.")
            .append(TRACKEDPROCESSTYPE)
            .append(WHERE_1_1)
            .append(" AND D.")
            .append(STATUS)
            .append(" = '")
            .append(MetadataProjectStatus.ACTIVE.name())
            .append("' AND (");
        sqlSbTemp.append(CREATEDBYUSER)
            .append(" = '")
            .append(dataSubjectIdValue)
            .append("'");
        sqlSbTemp.append(")");
        sqls.add(sqlSbTemp.toString());
        sqlSbTemp = new StringBuilder()
            .append(SELECT)
            .append(COUNT)
            .append(" AS NUM ")
            .append(FROM)
            .append(DBUtils.toTableName(MetadataConstants.CoreModelEntity.EVENT.getFullName()))
            .append(" E LEFT JOIN (SELECT ")
            .append(STATUS)
            .append(",")
            .append(NAMESPACE)
            .append(FROM)
            .append(MetadataTable.METADATA_PROJECT.name())
            .append(") F ON F.")
            .append(NAMESPACE)
            .append(" = E.")
            .append(MODELNAMESPACE)
            .append(WHERE_1_1)
            .append(" AND F.")
            .append(STATUS)
            .append(" = '")
            .append(MetadataProjectStatus.ACTIVE.name())
            .append("'  AND (");
        sqlSbTemp.append(CREATEDBYUSER)
            .append(" = '")
            .append(dataSubjectIdValue)
            .append("' OR ")
            .append(REPORTEDBY)
            .append(" = '")
            .append(dataSubjectIdValue)
            .append("'");
        sqlSbTemp.append(")");
        sqls.add(sqlSbTemp.toString());
    }

    @Override
    public List<Map<String, Object>> getPdmDataInfo(String dataSubjectIdValue, DppEntity dppEntity) {
        //retrieve CoreModel.Event or CoreModel.TrackedProcess when no user defined dpp annotations
        String coreTableName = dppEntity.isEvent() ? DBUtils.toTableName(MetadataConstants.CoreModelEntity.EVENT.getFullName())
            : DBUtils.toTableName(MetadataConstants.CoreModelEntity.TRACKED_PROCESS.getFullName());
        String tableName = dppEntity.getPhsicalName();
        
        //Select data subject id and keys based on user defined data subject id or createdByUser or updatedBy
        //If there are user defined dpp annotations, select from current user defined entity table, if no, select from CoreModel.Event or CoreModel.TrackedProcess
        StringBuilder allDataSubjectSqlSb = new StringBuilder(SELECT);
        
        List<DppProperty> dataSubjectIdProperties = dppEntity.getSpecialdataSubjectIdProperties();
        if (dppEntity.getDataSubjectIdProperty() != null) {
            dataSubjectIdProperties.add(dppEntity.getDataSubjectIdProperty());
        } else {
            tableName = coreTableName;
        }
        
        Map<String, String> propertyNameMap = new HashMap<>();
        generateAllDataSbujectIdSql(allDataSubjectSqlSb, dataSubjectIdValue, dppEntity, propertyNameMap);

        StringBuilder fromSqlSb = new StringBuilder(FROM);
        fromSqlSb.append(tableName);
        
        allDataSubjectSqlSb.append(fromSqlSb.toString()).append(" A ");
        
        if (dppEntity.getDataSubjectIdProperty() != null) {
            //Select user defined dpp annotations except for data subject id
            StringBuilder selectSqlSb = new StringBuilder(SELECT);

            generatePiiAndSpiSql(selectSqlSb, dppEntity);
            StringBuilder whereSqlSb = new StringBuilder(WHERE_1_1);
            DppProperty dataSubjectIdProperty = dppEntity.getDataSubjectIdProperty();
            whereSqlSb.append(" AND ")
                .append(dataSubjectIdProperty.getPhysicalName())
                .append(" = '")
                .append(dataSubjectIdValue)
                .append("' ");
        
            //join selct user defined pii and spi information from user defined model in table B
            selectSqlSb.append(fromSqlSb.toString()).append(whereSqlSb.toString());
            allDataSubjectSqlSb.append(" LEFT JOIN (").append(selectSqlSb.toString()).append(") B ON ");
            allDataSubjectSqlSb.append(dppEntity.getKeyProperties().stream().map(property -> "A.".concat(property.getPhysicalName()).concat(" = B.").concat(property.getPhysicalName())).collect(Collectors.joining(" AND ")));
            
            //join select createByUser and updatedBy from core model Event/TrackedProcess  in table C
            allDataSubjectSqlSb.append(" LEFT JOIN ").append(coreTableName).append(" C ON ");
            allDataSubjectSqlSb.append(dppEntity.getKeyProperties().stream().map(property -> "A.".concat(property.getPhysicalName()).concat(" = C.").concat(property.getPhysicalName())).collect(Collectors.joining(" AND ")));
        }
        
        //select personal data based on user defined data subject id (in table C) or createdByUser (in table A) or updatedBy (in table A
        String dataSubjectId = (dppEntity.getDataSubjectIdProperty() != null ? dppEntity.getDataSubjectIdProperty().getName() : "");
        String whereSql = dataSubjectIdProperties.stream().map(e -> ((StringUtils.isEmpty(dataSubjectId) || dataSubjectId.equals(e.getName())) ? "A." : "C.").concat(e.getPhysicalName()).concat(" = '").concat(dataSubjectIdValue).concat("'")).collect(Collectors.joining(" OR "));
        selectStatusFromMetadataProject(dppEntity, allDataSubjectSqlSb);
        allDataSubjectSqlSb.append(WHERE_1_1).append(" AND (").append(whereSql).append(")");
        addMetdataProjectStatusCheck(dppEntity, allDataSubjectSqlSb);
        //if there are no user defined annoations, need to add EventType/TrackedProcessType as select condition, except for directly selecting from CoreModel.Event
        if (dppEntity.getDataSubjectIdProperty() == null && !MetadataConstants.CoreModelEntity.EVENT.getFullName().equals(dppEntity.getName())) {
            allDataSubjectSqlSb.append(" AND A.").append(dppEntity.isEvent() ? EVENTTYPE : TRACKEDPROCESSTYPE).append(" = '").append(dppEntity.getName()).append("'");
        }
        
        List<Map<String, Object>> pdmDataList = jdbcTemplate.queryForList(allDataSubjectSqlSb.toString());
        return processTypesConversion(pdmDataList, propertyNameMap);
    }

    private void addMetdataProjectStatusCheck(DppEntity dppEntity, StringBuilder allDataSubjectSqlSb) {
        //check model is active when retrieving event data
        if (MetadataConstants.CoreModelEntity.EVENT.getFullName().equals(dppEntity.getName())) {
            allDataSubjectSqlSb.append(" AND F.")
                .append(STATUS)
                .append(" = '")
                .append(MetadataProjectStatus.ACTIVE.name())
                .append("' ");
        }
    }

    private void selectStatusFromMetadataProject(DppEntity dppEntity, StringBuilder allDataSubjectSqlSb) {
        //check model is active when retrieving event data
        if (MetadataConstants.CoreModelEntity.EVENT.getFullName().equals(dppEntity.getName())) {
            allDataSubjectSqlSb.append(" LEFT JOIN (SELECT ")
                .append(STATUS)
                .append(",")
                .append(NAMESPACE)
                .append(FROM)
                .append(MetadataTable.METADATA_PROJECT.name())
                .append(") F ON F.")
                .append(NAMESPACE)
                .append(" = A.")
                .append(MODELNAMESPACE);
        }
    }

    private List<Map<String, Object>> processTypesConversion(List<Map<String, Object>> pdmDataList, Map<String, String> propertyNameMap) {
        //convert property name from uppercase to correct format
        List<Map<String, Object>> convertedPDMDataList = new ArrayList<>();
        pdmDataList.stream().forEach(record -> {
            Map<String, Object> convertedMap = new HashMap<>();
            record.entrySet().stream().forEach(field -> {
                Object value = field.getValue() instanceof Timestamp ? ((Timestamp)field.getValue()).toLocalDateTime().toInstant(ZoneOffset.UTC).toString() : field.getValue();
                value = value instanceof LocalDate ? ((LocalDate)value).toString() : value;
                value = value instanceof java.sql.Date ? ((java.sql.Date)value).toLocalDate().toString() : value;
                convertedMap.put(propertyNameMap.get(field.getKey().toUpperCase()), value);
            });
            convertedPDMDataList.add(convertedMap);
        });
        return convertedPDMDataList;
    }
    
    private void generateAllDataSbujectIdSql(StringBuilder allDataSubjectSqlSb, String dataSubjectIdValue, DppEntity dppEntity, Map<String, String> propertyNameMap) {
        List<DppProperty> piiAndSpiProperties = new ArrayList();
        List<DppProperty> piiProperties = dppEntity.getPiiProperties();
        List<DppProperty> spiProperties = dppEntity.getSpiProperties();
        
        piiAndSpiProperties.addAll(piiProperties);
        piiAndSpiProperties.addAll(spiProperties);
        
        propertyNameMap.put("dataSubjectId".toUpperCase(), "dataSubjectId");
        allDataSubjectSqlSb.append("'")
            .append(dataSubjectIdValue)
            .append("' AS ")
            .append("dataSubjectId");

        dppEntity.getKeyProperties().stream().filter(property -> !propertyNameMap.containsValue(property.getName())).forEach(property -> {
            propertyNameMap.put(property.getName().toUpperCase(), property.getName());
            String columnName = property.getPhysicalName();
            allDataSubjectSqlSb.append(",")
                .append("A.")
                .append(columnName)
                .append(" AS ")
                .append(property.getName());

        });
        
        piiAndSpiProperties.stream().filter(e -> !propertyNameMap.containsValue(e.getName()) && !dppEntity.getDataSubjectIdProperty().getName().equals(e.getName())).forEach(e -> {
            //Should exclude data subject id
            propertyNameMap.put(e.getName().toUpperCase(), e.getName());
            String columnName = e.getPhysicalName();
            allDataSubjectSqlSb.append(",")
                .append("B.")
                .append(columnName)
                .append(" AS ")
                .append(e.getName());

        });
        
        //display eventType
        dppEntity.getOtherProperties().stream().filter(property -> !propertyNameMap.containsValue(property.getName())).forEach(property -> {
            propertyNameMap.put(property.getName().toUpperCase(), property.getName());
            String columnName = property.getPhysicalName();
            allDataSubjectSqlSb.append(",")
                .append("A.")
                .append(columnName)
                .append(" AS ")
                .append(property.getName());

        });
    }
    
    private void generatePiiAndSpiSql(StringBuilder selectSqlSb, DppEntity dppEntity) {
        Map<String, String> propertyNameMap = new HashMap<>();
        List<DppProperty> piiAndSpiProperties = new ArrayList();
        
        piiAndSpiProperties.addAll(dppEntity.getPiiProperties());
        piiAndSpiProperties.addAll(dppEntity.getSpiProperties());
        
        dppEntity.getKeyProperties().stream().filter(property -> !propertyNameMap.containsValue(property.getName())).forEach(property -> {
            propertyNameMap.put(property.getName().toUpperCase(), property.getName());
            String columnName = property.getPhysicalName();
            selectSqlSb.append(propertyNameMap.size() == 1 ? "" : ",").append(columnName);

        });
        
        piiAndSpiProperties.stream().filter(e -> !propertyNameMap.containsValue(e.getName()) && !dppEntity.getDataSubjectIdProperty().getName().equals(e.getName())).forEach(e -> {
            //Should exclude data subject id
            propertyNameMap.put(e.getName().toUpperCase(), e.getName());
            String columnName = e.getPhysicalName();
            selectSqlSb.append(propertyNameMap.size() == 1 ? "" : ",").append(columnName);

        });
    }
}