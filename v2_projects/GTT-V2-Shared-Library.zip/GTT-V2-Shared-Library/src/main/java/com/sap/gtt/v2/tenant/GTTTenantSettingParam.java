package com.sap.gtt.v2.tenant;

public class GTTTenantSettingParam {

	public static final String SETTING_PARAM_LOGGER_LOGLEVEL = "logger.logLevel";
	public static final String SETTING_PARAM_WS_E2A_MAX_TIME = "writeService.eventToAction.maxExecutionTime"; // second
	//public static final String SETTING_PARAM_WS_E2A_MAX_MEMORY = "writeService.eventToAction.maxMemoryConsumption"; // MB
	public static final String SETTING_PARAM_RS_RATELIMIT_MAX_RESULT_COUNT = "readService.rateLimit.maxResultCount"; // COUNT
	
	public static final String SETTING_PARAM_LOGGER_LOGLEVEL_ERROR = "ERROR";
	public static final String SETTING_PARAM_LOGGER_LOGLEVEL_DEBUG = "DEBUG";
	public static final String SETTING_PARAM_LOGGER_LOGLEVEL_INFO = "INFO";
	
	private String id;
	private String instanceMappingId;
	private String paramName;
	private String paramValue;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getInstanceMappingId() {
		return instanceMappingId;
	}
	public void setInstanceMappingId(String instanceMappingId) {
		this.instanceMappingId = instanceMappingId;
	}
	public String getParamName() {
		return paramName;
	}
	public void setParamName(String paramName) {
		this.paramName = paramName;
	}
	public String getParamValue() {
		return paramValue;
	}
	public void setParamValue(String paramValue) {
		this.paramValue = paramValue;
	}
	

	
   
	
	
}
