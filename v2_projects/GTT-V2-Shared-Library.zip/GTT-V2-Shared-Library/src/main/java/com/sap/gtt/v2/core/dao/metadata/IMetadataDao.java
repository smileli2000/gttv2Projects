package com.sap.gtt.v2.core.dao.metadata;

import com.sap.gtt.v2.core.domain.metadata.MetadataCriteria;
import com.sap.gtt.v2.core.entity.metadata.*;

import java.util.List;

import static com.sap.gtt.v2.core.domain.metadata.MetadataConstants.MetadataProjectFileField;

/**
 * @author I321712
 */
public interface IMetadataDao {
    /**
     * Find all the metadata project basic information
     *
     * @return all the metedata project basic information
     */
    List<MetadataProject> findAllMetadataProject();

    /**
     * Find metadata project information by the criteria
     *
     * @param criteria criteria
     * @return all the metadata project information
     */
    List<MetadataProject> findMetadataProjectInfo(MetadataCriteria criteria);

    /**
     * Find all the metadata project information including metadata project and process metadata by namespace.
     *
     * @param namespace namespace
     * @return list of MetadataProject
     */
    List<MetadataProject> findMetadataProjectInfoByNamespace(String namespace);

    /**
     * Find all the process metadata by given criteria.
     *
     * @param criteria criteria
     * @return list of MetadataProcess
     */
    List<MetadataProcess> findAllMetadataProcess(MetadataCriteria criteria);

    /**
     * Get derived CSN data for a given event type or tracked process type which is contained in criteria object
     *
     * @param criteria criteria for CSN data fetching
     * @return CSN data
     */
    String getMetadataDerivedCsn(MetadataCriteria criteria);

    /**
     * Get metadata swagger and derived CSN information by namespace
     *
     * @param namespace metadata project namespace
     * @return metadata Swagger and derived CSN information
     */
    MetadataProjectFile getMetadataSwaggerDerivedCsnInfo(String namespace);

    /**
     * Insert metadata project information including metadata project, metadata project file
     *
     * @param newMetadataProject new metadata project object
     */
    void insertMetadataProject(MetadataProject newMetadataProject);

    /**
     * Update metadata project including metadata project file except primary key and namespace
     *
     * @param updatedMetadataProject updated metadata project object
     */
    void updateMetadataProject(MetadataProject updatedMetadataProject);

    /**
     * Insert a process metadata
     *
     * @param newMetadataProcess new process metadata
     */
    void insertMetadataProcess(MetadataProcess newMetadataProcess);

    /**
     * Update metadata project status
     * @param updatedMetadataProject 
     */
    void updateMetadataProjectStatus(MetadataProject updatedMetadataProject);
    
    /**
     * Update tracked process type/application object type of a process metadata
     *
     * @param updatedMetadataProcess updated process metadata object
     */
    void updateMetadataProcess(MetadataProcess updatedMetadataProcess);

    /**
     * Delete all the metadata information by namespace
     *
     * @param namespace namespace of a metadata project
     */
    void deleteMetadata(String namespace);

    /**
     * Get metadata project file field information by namespace and field name
     *
     * @param namespaces namespaces
     * @param fieldName  field name
     * @return metadata project file field information
     */
    String getMetadataProjectFileFieldInfo(List<String> namespaces, MetadataProjectFileField fieldName);

    /**
     * Get metadata project file field information by namespace and field name
     *
     * @param criteria search criteria info
     * @param selectFields  field name list
     * @return metadata project file field information
     */
    MetadataProjectFile getMetadataProjectFileInfo(String[] selectFields, MetadataCriteria criteria);

    /**
     * Insert metadata change history
     *
     * @param metadataChangeHistory
     */
    void insertMetadataChangeHistory(MetadataChangeHistory metadataChangeHistory);

    /**
     * Get metadata change history by namespace
     *
     * @param namespace
     * @return
     */
    List<MetadataChangeHistory> findMetadataChangeHistoryByNamespace(String namespace);

    /**
     * Get all draft models info
     *
     * @param includeJsonModel true if including jsonModel
     * @return all the draft models
     */
    List<MetadataDraftModel> selectAllMetadataDraftModelsInfo(boolean includeJsonModel);

    /**
     * Get draft model header info by namespace
     *
     * @param namespace
     * @return
     */
    MetadataDraftModel getMetadataDraftModelInfoByNamespace(String namespace);

    /**
     * Get draft model header info by namespace
     *
     * @param namespace
     * @return
     */
    MetadataDraftModel getMetadataDraftModelByNamespace(String namespace);

    /**
     * Create a draft model
     *
     * @param metadataDraftModel
     */
    void insertMetadataDraftModel(MetadataDraftModel metadataDraftModel);

    /**
     * Update a draft model header Info
     *
     * @param metadataDraftModel
     */
    void updateMetadataDraftModelInfo(MetadataDraftModel metadataDraftModel);

    /**
     * Update a draft model by namespace
     *
     * @param namespace
     * @param metadataDraftModel
     */
    void updateMetadataDraftModel(String namespace, MetadataDraftModel metadataDraftModel);

    /**
     * Delete a draft model
     *
     * @param namespace
     */
    void deleteMetadataDraftModel(String namespace);

    /**
     * Upsert metadata process text
     *
     * @param metadataProcess
     */
    void upsertMetadataProcessTexts(MetadataProcess metadataProcess);

    /**
     *  count tracked process
     * @param trackedProcessType
     * @return
     */
    long countTrackedProcessByType(String trackedProcessType);

    /**
     * Save metadata event and its description information for a given process type
     *
     * @param metadataProcess metadata process
     */
    void saveMetadataEvents(MetadataProcess metadataProcess);

}
