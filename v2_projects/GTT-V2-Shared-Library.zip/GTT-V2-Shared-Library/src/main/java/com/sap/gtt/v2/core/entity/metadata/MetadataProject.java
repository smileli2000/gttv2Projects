package com.sap.gtt.v2.core.entity.metadata;

import java.io.Serializable;
import java.time.Instant;
import java.util.*;

/**
 * Metadata Project
 * @author I321712
 */
public class MetadataProject implements Serializable {
    private static final long serialVersionUID = 6995834198657370011L;
    private String id;
    private String namespace;
    private transient Instant uploadAt;
    private String version;
    private String status;
    private String description;
    private String mode;
    private String coreModelVersion;
    private String compilerVersion;
    private boolean enableInstanceBasedAuthorization;
    private int eventCorrelationLevel = 1;
    private List<MetadataProjectText> metadataProjectTexts = new ArrayList();
    private MetadataProjectFile metadataProjectFile;

    private List<MetadataProcess> metadataProcessList = new ArrayList<>();

    public List<MetadataProjectText> getMetadataProjectTexts() {
        return metadataProjectTexts;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNamespace() {
        return namespace;
    }

    public void setNamespace(String namespace) {
        this.namespace = namespace;
    }

    public Instant getUploadAt() {
        return uploadAt;
    }

    public void setUploadAt(Instant uploadAt) {
        this.uploadAt = uploadAt;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getMode() {
        return mode;
    }

    public void setMode(String mode) {
        this.mode = mode;
    }

    public String getCoreModelVersion() {
        return coreModelVersion;
    }

    public void setCoreModelVersion(String coreModelVersion) {
        this.coreModelVersion = coreModelVersion;
    }

    public String getCompilerVersion() {
        return compilerVersion;
    }

    public void setCompilerVersion(String compilerVersion) {
        this.compilerVersion = compilerVersion;
    }

    public MetadataProjectFile getMetadataProjectFile() {
        return metadataProjectFile;
    }

    public void setMetadataProjectFile(MetadataProjectFile metadataProjectFile) {
        this.metadataProjectFile = metadataProjectFile;
    }

    public List<MetadataProcess> getMetadataProcessList() {
        return Collections.unmodifiableList(metadataProcessList);
    }

    public void addProcessMetadata(MetadataProcess metadataProcess) {
        this.metadataProcessList.add(metadataProcess);
    }

    public boolean isEnableInstanceBasedAuthorization() {
        return enableInstanceBasedAuthorization;
    }

    public void setEnableInstanceBasedAuthorization(boolean enableInstanceBasedAuthorization) {
        this.enableInstanceBasedAuthorization = enableInstanceBasedAuthorization;
    }

    public int getEventCorrelationLevel() {
        return eventCorrelationLevel;
    }

    public void setEventCorrelationLevel(int eventCorrelationLevel) {
        this.eventCorrelationLevel = eventCorrelationLevel;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        MetadataProject that = (MetadataProject) o;
        return id.equals(that.id) &&
                namespace.equals(that.namespace) &&
                uploadAt.equals(that.uploadAt) &&
                version.equals(that.version) &&
                status.equals(that.status) &&
                Objects.equals(description, that.description) &&
                Objects.equals(mode, that.mode) &&
                coreModelVersion.equals(that.coreModelVersion) &&
                compilerVersion.equals(that.compilerVersion) &&
                enableInstanceBasedAuthorization == that.enableInstanceBasedAuthorization &&
                eventCorrelationLevel == that.eventCorrelationLevel;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, namespace, uploadAt, version, status, description, mode, coreModelVersion,
                compilerVersion, enableInstanceBasedAuthorization, eventCorrelationLevel);
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", MetadataProject.class.getSimpleName() + "[", "]")
                .add("id='" + id + "'")
                .add("namespace='" + namespace + "'")
                .add("uploadAt=" + uploadAt)
                .add("version='" + version + "'")
                .add("status='" + status + "'")
                .add("description='" + description + "'")
                .add("mode='" + mode + "'")
                .add("coreModelVersion='" + coreModelVersion + "'")
                .add("compilerVersion='" + compilerVersion + "'")
                .add("enableInstanceBasedAuthorization'" + enableInstanceBasedAuthorization + "'")
                .add("eventCorrelationLevel'" + eventCorrelationLevel + "'")
                .add("metadataProjectTexts=" + metadataProjectTexts + "")
                .toString();
    }
}
