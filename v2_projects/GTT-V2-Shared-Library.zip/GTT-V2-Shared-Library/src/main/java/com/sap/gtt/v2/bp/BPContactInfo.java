package com.sap.gtt.v2.bp;

import com.google.gson.annotations.SerializedName;

public class BPContactInfo {
	@SerializedName("SolutionOwner_ContactPersonName")
	private String solutionOwnerContactPersonName;
	@SerializedName("SolutionOwner_ContactPersonEmail")
	private String solutionOwnerContactPersonEmail;
	@SerializedName("SolutionOwner_ContactPersonPhoneNumber")
	private String solutionOwnerContactPersonPhoneNumber;
	@SerializedName("SolutionOwner_BusinessProfileName")
	private String solutionOwnerBusinessProfileName;
	@SerializedName("SolutionOwner_Address")
	private String solutionOwnerAddress;
	@SerializedName("SolutionOwner_PostalCode")
	private String solutionOwnerPostalCode;
	@SerializedName("SolutionOwner_Mobile")
	private String solutionOwnerMobile;
	@SerializedName("SolutionOwner_Fax")
	private String solutionOwnerFax;
	@SerializedName("SolutionOwner_Logo")
	private String solutionOwnerLogo;
	@SerializedName("SolutionOwner_Website")
	private String solutionOwnerWebsite;
	
	public String getSolutionOwnerContactPersonName() {
		return solutionOwnerContactPersonName;
	}
	public void setSolutionOwnerContactPersonName(String solutionOwnerContactPersonName) {
		this.solutionOwnerContactPersonName = solutionOwnerContactPersonName;
	}
	public String getSolutionOwnerContactPersonEmail() {
		return solutionOwnerContactPersonEmail;
	}
	public void setSolutionOwnerContactPersonEmail(String solutionOwnerContactPersonEmail) {
		this.solutionOwnerContactPersonEmail = solutionOwnerContactPersonEmail;
	}
	public String getSolutionOwnerContactPersonPhoneNumber() {
		return solutionOwnerContactPersonPhoneNumber;
	}
	public void setSolutionOwnerContactPersonPhoneNumber(String solutionOwnerContactPersonPhoneNumber) {
		this.solutionOwnerContactPersonPhoneNumber = solutionOwnerContactPersonPhoneNumber;
	}
	public String getSolutionOwnerBusinessProfileName() {
		return solutionOwnerBusinessProfileName;
	}
	public void setSolutionOwnerBusinessProfileName(String solutionOwnerBusinessProfileName) {
		this.solutionOwnerBusinessProfileName = solutionOwnerBusinessProfileName;
	}
	public String getSolutionOwnerAddress() {
		return solutionOwnerAddress;
	}
	public void setSolutionOwnerAddress(String solutionOwnerAddress) {
		this.solutionOwnerAddress = solutionOwnerAddress;
	}
	public String getSolutionOwnerPostalCode() {
		return solutionOwnerPostalCode;
	}
	public void setSolutionOwnerPostalCode(String solutionOwnerPostalCode) {
		this.solutionOwnerPostalCode = solutionOwnerPostalCode;
	}
	public String getSolutionOwnerMobile() {
		return solutionOwnerMobile;
	}
	public void setSolutionOwnerMobile(String solutionOwnerMobile) {
		this.solutionOwnerMobile = solutionOwnerMobile;
	}
	public String getSolutionOwnerFax() {
		return solutionOwnerFax;
	}
	public void setSolutionOwnerFax(String solutionOwnerFax) {
		this.solutionOwnerFax = solutionOwnerFax;
	}
	public String getSolutionOwnerLogo() {
		return solutionOwnerLogo;
	}
	public void setSolutionOwnerLogo(String solutionOwnerLogo) {
		this.solutionOwnerLogo = solutionOwnerLogo;
	}
	public String getSolutionOwnerWebsite() {
		return solutionOwnerWebsite;
	}
	public void setSolutionOwnerWebsite(String solutionOwnerWebsite) {
		this.solutionOwnerWebsite = solutionOwnerWebsite;
	}
}
