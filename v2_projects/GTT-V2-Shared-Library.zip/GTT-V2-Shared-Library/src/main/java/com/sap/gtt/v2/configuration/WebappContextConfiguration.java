package com.sap.gtt.v2.configuration;

import java.util.EventListener;

import javax.servlet.ServletRequestListener;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.ServletListenerRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class WebappContextConfiguration {

	
    @Autowired
    private ServletRequestListener servletRequestListener;
    
    @Bean
	public ServletListenerRegistrationBean<EventListener> getServletListenerRegistrationBean(){

		ServletListenerRegistrationBean<EventListener> registrationBean
		                           = new ServletListenerRegistrationBean<>();
		
		registrationBean.setListener(servletRequestListener);

		return registrationBean;
	}
}
