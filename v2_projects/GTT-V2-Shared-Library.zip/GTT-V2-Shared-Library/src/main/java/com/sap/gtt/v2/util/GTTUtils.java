package com.sap.gtt.v2.util;

import com.fasterxml.uuid.Generators;
import com.google.gson.JsonElement;
import com.sap.gtt.v2.configuration.EnvironmentsConfiguration.VcapServiceParser.DatabaseServiceInstance.DatabaseType;
import com.sap.gtt.v2.configuration.EnvironmentsConfiguration.VcapServiceParser.DestinationServiceInstance.Destination;
import com.sap.gtt.v2.configuration.GTTRestTemplate;
import com.sap.gtt.v2.core.domain.trackedprocess.Constant;
import com.sap.gtt.v2.core.management.execution.DefaultMessageLogManagement;
import com.sap.gtt.v2.core.management.execution.IMessageLogManagement;
import com.sap.gtt.v2.core.management.metadata.DefaultMetadataManagement;
import com.sap.gtt.v2.core.management.metadata.IMetadataManagement;
import com.sap.gtt.v2.core.management.metering.DefaultMeteringManagement;
import com.sap.gtt.v2.core.management.metering.IMeteringManagement;
import com.sap.gtt.v2.core.management.overdue.DefaultOverdueManagement;
import com.sap.gtt.v2.core.management.overdue.IOverdueManagement;
import com.sap.gtt.v2.core.management.tracking.DefaultEventManagement;
import com.sap.gtt.v2.core.management.tracking.DefaultTrackedProcessManagement;
import com.sap.gtt.v2.core.management.tracking.IEventManagement;
import com.sap.gtt.v2.core.management.tracking.ITrackedProcessManagement;
import com.sap.gtt.v2.exception.GeneralNoneTranslatableException;
import com.sap.gtt.v2.exception.InternalErrorException;
import com.sap.gtt.v2.exception.MessageValidationException;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static com.sap.gtt.v2.exception.MessageValidationException.MESSAGE_CODE_ALTKEY_FORMAT_ERROR;

public class GTTUtils {

    public static final String GLOBAL_STRING_SPLITOR = "#";
    public static final String DEFAULT_CHARSET_ENCODING = "UTF-8";

    private GTTUtils() {
        throw new IllegalStateException("GTTUtils class");
    }

    public static class UUIDUtils {

        private UUIDUtils() {
            throw new IllegalStateException("UUIDUtils class");
        }

        //2d75bf0a abdc 11e6 80f5 76304dec7eb7
        //2d75bf0a-abdc-11e6-80f5-76304dec7eb7
        public static UUID from32ToUUID(String stringToConvert) {
            if (stringToConvert == null || stringToConvert.length() != 32) {
                return null;
            }
            final int EXPECTED_BUFFER_DATA = 32;
            StringBuilder uuidBuilder = new StringBuilder(EXPECTED_BUFFER_DATA);
            uuidBuilder.append(stringToConvert.substring(0, 8));
            uuidBuilder.append("-");
            uuidBuilder.append(stringToConvert.substring(8, 12));
            uuidBuilder.append("-");
            uuidBuilder.append(stringToConvert.substring(12, 16));
            uuidBuilder.append("-");
            uuidBuilder.append(stringToConvert.substring(16, 20));
            uuidBuilder.append("-");
            uuidBuilder.append(stringToConvert.substring(20, stringToConvert.length()));
            return UUID.fromString(uuidBuilder.toString());
        }

        public static String fromUUIDTo32(UUID uuidToConvert) {
            return uuidToConvert.toString().replace("-", "");
        }

        public static UUID generateNameBasedUUID(String value) {
            return Generators.nameBasedGenerator().generate(value);
        }

        public static UUID generateTimeBasedUUID() {
            return Generators.timeBasedGenerator().generate();
        }

    }

    public static class AltKey {
        private String scheme;
        private String party;
        private String logicalSystem;
        private String type;
        private String id;

        public String getScheme() {
            return scheme;
        }

        public void setScheme(String scheme) {
            this.scheme = scheme;
        }

        public String getParty() {
            return party;
        }

        public void setParty(String party) {
            this.party = party;
        }

        public String getLogicalSystem() {
            return logicalSystem;
        }

        public void setLogicalSystem(String logicalSystem) {
            this.logicalSystem = logicalSystem;
        }

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }
    }

    public static AltKey parseAltKey(String altKey) {
        AltKey altkey = new AltKey();
        String[] segments = altKey.split(Constant.ALTKEY_DELIMITER);
        int segmentLength = segments.length;
        altkey.setScheme(segments[0].concat(Constant.ALTKEY_DELIMITER).concat(segments[1]));
        altkey.setParty(segments[2]);
        altkey.setLogicalSystem(segments[3]);
        altkey.setType(segments[segmentLength - 2]);
        altkey.setId(segments[segmentLength - 1]);
        return altkey;
    }

    public static void validateAltKey(String altKey) {
        if (!Pattern.matches(Constant.PATTERN_ALTKEY, altKey)) {
            throw new MessageValidationException(MESSAGE_CODE_ALTKEY_FORMAT_ERROR, new Object[]{altKey, Constant.DESC_ALTKEY});
        }
    }

    public static String extractTrackingId(String altKey) {
        validateAltKey(altKey);
        AltKey altKeyObj = parseAltKey(altKey);
        return altKeyObj.getId();
    }

    /**
     * @param source
     * @param targetClass
     * @return
     */
    public static <T> T createAndCopyBean(Object source, Class<T> targetClass, boolean deepCopy) {

        try {
            T target = null;
            if (!deepCopy) {
                target = targetClass.newInstance();
                // no deep
                //use spring bean utils
                // target must has corresponding setter, and source must has corresponding getter
                org.springframework.beans.BeanUtils.copyProperties(source, target);
            } else {
                // deep copy
                //use Json serialize and deserialize
                // no need for getter and setter
                JsonElement jsonElement = JsonUtils.generateJsonElementFromBean(source);
                target = JsonUtils.generateBeanFromJsonElement(jsonElement, targetClass);
            }


            return target;
        } catch (InstantiationException | IllegalAccessException e) {
            throw new InternalErrorException(e);
        }

    }

    public static <E> List<E> getDuplicateElements(List<E> list) {
        return list.stream()
                .collect(Collectors.toMap(e -> e, e -> 1, Integer::sum))
                .entrySet().stream()
                .filter(entry -> entry.getValue() > 1)
                .map(Map.Entry::getKey)
                .collect(Collectors.toList());
    }

    /**
     * Convert the first character lowercase.
     *
     * @param originalStr original string
     * @return string which the first character is lowercase
     */
    public static String toLowerCaseFirstCharacter(String originalStr) {
        char[] chars = originalStr.toCharArray();
        if (Character.isUpperCase(chars[0])) {
            chars[0] += 32;
        }
        return String.valueOf(chars);
    }

    public static String convertSpecialString(String str) {
        if (StringUtils.isBlank(str)) {
            return str;
        }
        return str.replaceAll("\\\\", "").replaceAll("\\>n", ">")
                .replaceAll("^\"\"|\"\"$", "").replaceAll("^\"|\"$", "");
    }

    public static class BusinessOperator {

        private ITrackedProcessManagement trackedProcessManagement;
        private IEventManagement eventManagement;
        private IMetadataManagement metadataManagement;
        private IOverdueManagement overdueManagement;
        private IMessageLogManagement messageLogManagement;
        private IMeteringManagement meteringManagement;

        private BusinessOperator(ITrackedProcessManagement trackedProcessManagement, IEventManagement eventManagement,
                                 IMetadataManagement metadataManagement, IOverdueManagement overdueManagement,
                                 IMessageLogManagement executionHistoryManagement, IMeteringManagement meteringManagement) {
            super();
            this.trackedProcessManagement = trackedProcessManagement;
            this.eventManagement = eventManagement;
            this.metadataManagement = metadataManagement;
            this.overdueManagement = overdueManagement;
            this.messageLogManagement = executionHistoryManagement;
            this.meteringManagement = meteringManagement;
        }

        public ITrackedProcessManagement getTrackedProcessManagement() {
            return trackedProcessManagement;
        }

        public IEventManagement getEventManagement() {
            return eventManagement;
        }

        public IMetadataManagement getMetadataManagement() {
            return metadataManagement;
        }

        public IOverdueManagement getOverdueManagement() {
            return overdueManagement;
        }

        public IMeteringManagement getMeteringManagement() {
            return meteringManagement;
        }

        public IMessageLogManagement getMessageLogManagement() {
            return messageLogManagement;
        }
    }

    public static BusinessOperator createBusinessOperator(DatabaseType databaseType) {

        if (databaseType == DatabaseType.hana || databaseType == DatabaseType.h2) {
            return new BusinessOperator(DefaultTrackedProcessManagement.getInstance(), DefaultEventManagement.getInstance(),
                    DefaultMetadataManagement.getInstance(), DefaultOverdueManagement.getInstance(),
                    DefaultMessageLogManagement.getInstance(), DefaultMeteringManagement.getInstance());
        } else {
            throw new UnsupportedOperationException(String.format("Database type '%s' not supported", databaseType.name()));
        }

    }


    public static String getTZStringFromInstant(Instant instant) {
        return instant.toString();

    }

    public static Instant getInstantFromTZString(String tzString) {
        return Instant.parse(tzString);
    }

    public static <T> T sendRequest(Destination destination, HttpMethod method, Object body, Class<T> responseType) {

        GTTRestTemplate restTemplate = SpringContextUtils.getBean(GTTRestTemplate.class);
        String targetServiceUrl = destination.getUrl();
        HttpHeaders headers = new HttpHeaders();

        if (StringUtils.equals(destination.getProxyType(), Destination.ProxyType.OnPremise.toString())) {
            // OnPremise, TODO: build proxy
        }

        if (StringUtils.equals(destination.getAuthentication(), Destination.Authentication.NoAuthentication.toString())) {
            // TODO:
        } else if (StringUtils.equals(destination.getAuthentication(), Destination.Authentication.OAuth2ClientCredentials.toString())) {
            //OAuth2ClientCredentials
            String clientId = destination.getClientId();
            String clientSecret = destination.getClientSecret();
            String uaaUrl = destination.getTokenServiceURL();

            String jwt = UaaUtils.requestTechniqueToken(uaaUrl, clientId, clientSecret);
            headers.setBearerAuth(jwt);


        } else {
            throw new GeneralNoneTranslatableException(
                    String.format("Authentication '%s' of Destination '%s' not support!", destination.getAuthentication(), destination.getName())
                    , null, 500);
        }
        return restTemplate.exchange(targetServiceUrl, method, headers, body, responseType).getBody();
    }
    
}
