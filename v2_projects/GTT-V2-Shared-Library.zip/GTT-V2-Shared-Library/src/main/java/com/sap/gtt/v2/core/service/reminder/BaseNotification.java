package com.sap.gtt.v2.core.service.reminder;

public interface BaseNotification {
	void post();
}
