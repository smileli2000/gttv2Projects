package com.sap.gtt.v2.core.domain.trackedprocess;

import java.util.Locale;

/**
 * Life Cycle Status
 */
public enum LifeCycleStatus {
    /**
     * BUSINESS_ACTIVE
     */
    BUSINESS_ACTIVE("Business Active"),
    /**
     * END_OF_BUSINESS
     */
    END_OF_BUSINESS("End of Business"),
    /**
     * END_OF_PURPOSE
     */
    END_OF_PURPOSE("End of Purpose"),
    /**
     * END_OF_RETENTION
     */
    END_OF_RETENTION("End of Retention");

    private String description;

    LifeCycleStatus(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }

    public static LifeCycleStatus fromValue(String value) {
        return LifeCycleStatus.valueOf(value.toUpperCase(Locale.ENGLISH));
    }
}
