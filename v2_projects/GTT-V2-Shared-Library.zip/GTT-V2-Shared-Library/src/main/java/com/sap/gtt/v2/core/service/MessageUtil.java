package com.sap.gtt.v2.core.service;

import com.sap.gtt.v2.core.domain.metadata.*;
import com.sap.gtt.v2.core.domain.trackedprocess.EventStatus;
import com.sap.gtt.v2.core.domain.trackedprocess.Operator;
import com.sap.gtt.v2.core.domain.trackedprocess.ProcessStatus;
import com.sap.gtt.v2.core.entity.trackedprocess.PlannedEvent;
import com.sap.gtt.v2.core.entity.trackedprocess.ProcessEventDirectory;
import com.sap.gtt.v2.core.entity.trackedprocess.QualifiedTrackingId;
import com.sap.gtt.v2.core.entity.trackedprocess.TrackedProcess;
import com.sap.gtt.v2.core.runtime.model.IPropertyValue;
import com.sap.gtt.v2.core.runtime.model.NullValue;
import com.sap.gtt.v2.core.runtime.model.ObjectValue;
import org.apache.commons.lang3.tuple.Triple;

import java.math.BigDecimal;
import java.util.*;

import static com.sap.gtt.v2.core.domain.metadata.MetadataConstants.CoreModelEntity.GTT_UPDATE_PLAN_EVENT;

public class MessageUtil {

    private MessageUtil() {
    }

    //TODO: why we need to distinguish actual event type here?
    public static ProcessStatus getProcessStatus(TrackedProcess tp, PlannedEvent matchedPlannedEvent, String eventType) {
        List<PlannedEvent> sortedPlannedEvents = tp.getPlannedEventsSortByPlannedBusinessTime(false);
        if (GTT_UPDATE_PLAN_EVENT.getFullName().equals(eventType)) {
            return getProcessStatus(sortedPlannedEvents);
        }
        if (MessageUtil.isFinalEffectiveEvent(sortedPlannedEvents, matchedPlannedEvent.getId())) {
            return ProcessStatus.from(EventStatus.valueOf(matchedPlannedEvent.getEventStatus()));
        }
        return ProcessStatus.valueOf(tp.getProcessStatus());
    }

    public static ProcessStatus getProcessStatus(List<PlannedEvent> sortedPlannedEvents) {
        PlannedEvent lastNonPlannedEvent = null;
        for (PlannedEvent plannedEvent : sortedPlannedEvents) {
            if (!EventStatus.PLANNED.name().equals(plannedEvent.getEventStatus())) {
                lastNonPlannedEvent = plannedEvent;
            }
        }
        return lastNonPlannedEvent != null ?
                ProcessStatus.from(EventStatus.valueOf(lastNonPlannedEvent.getEventStatus())) :
                ProcessStatus.from(EventStatus.PLANNED);
    }

    public static void processBacklinkProperty(ObjectValue dataObject, ObjectValue parentObject) {
        MetadataEntity metadataEntity = dataObject.getMetadata().getCurrentEntity();
        Map<String, MetadataEntityElement> metadata = metadataEntity.getElementMap();
        for (Map.Entry<String, MetadataEntityElement> entry : metadata.entrySet()) {
            MetadataEntityElement fieldConfig = entry.getValue();
            MetadataConstants.CdsDataType fieldType = fieldConfig.getType();
            if (MetadataConstants.CdsDataType.CDS_ASSOCIATION.equals(fieldType) && fieldConfig.isBackLink()) {
                List<MetadataForeignKey> foreignKeyList = fieldConfig.getForeignKeyList();
                for (MetadataForeignKey fk : foreignKeyList) {
                    dataObject.setValue(fk.getGeneratedFieldName(),
                            parentObject.getValue(fk.getReferenceFieldName()));
                }
            }
        }
        for (Map.Entry<String, MetadataEntityElement> entry : metadata.entrySet()) {
            String fieldName = entry.getKey();
            MetadataEntityElement fieldConfig = entry.getValue();
            MetadataConstants.CdsDataType fieldType = fieldConfig.getType();
            if (MetadataConstants.CdsDataType.CDS_COMPOSITION.equals(fieldType)
                    && !isNull(dataObject, fieldName)) {
                List<IPropertyValue> items = dataObject.getValueAsList(fieldName);
                for (IPropertyValue item : items) {
                    processBacklinkProperty((ObjectValue) item, dataObject);
                }
            }
        }
    }

    public static void processDefaultValue(ObjectValue dataObject) {
        MetadataEntity metadataEntity = dataObject.getMetadata().getCurrentEntity();
        Map<String, MetadataEntityElement> metadata = metadataEntity.getElementMap();
        for (Map.Entry<String, MetadataEntityElement> entry : metadata.entrySet()) {
            String fieldName = entry.getKey();
            MetadataEntityElement fieldConfig = entry.getValue();
            MetadataConstants.CdsDataType fieldType = fieldConfig.getType();
            if (MetadataConstants.CdsDataType.CDS_STRING.equals(fieldType)) {
                processDefaultValueInner(dataObject, fieldName, fieldConfig);
            } else if (MetadataConstants.CdsDataType.CDS_COMPOSITION.equals(fieldType)
                    && !isNull(dataObject, fieldName)) {
                List<IPropertyValue> items = dataObject.getValueAsList(fieldName);
                for (IPropertyValue item : items) {
                    processDefaultValue((ObjectValue) item);
                }
            }
        }
    }

    private static void processDefaultValueInner(ObjectValue dataObject, String fieldName, MetadataEntityElement fieldConfig) {
        String defaultValue = fieldConfig.getDefaultVal();
        if (defaultValue != null && isNull(dataObject, fieldName)) {
            dataObject.setValue(fieldName, defaultValue);
        }
    }

    public static void copy(ObjectValue source, ObjectValue target) {
        CurrentMetadataEntity metadata = target.getMetadata();
        MetadataEntity currentEntity = metadata.getCurrentEntity();
        Map<String, MetadataEntityElement> targetMetadataElementMap = currentEntity.getElementMap();
        targetMetadataElementMap.forEach((elemName, elemEntity) -> {
            MetadataConstants.CdsDataType elemType = elemEntity.getType();
            if (MetadataConstants.CdsDataType.CDS_COMPOSITION.equals(elemType)) {
                copyItems(source, target, elemName, elemEntity);
            } else if (!MetadataConstants.CdsDataType.CDS_ASSOCIATION.equals(elemType) && source.isValueProvided(elemName)) {
                target.setValue(elemName, source.getValue(elemName));
            }
        });
    }

    private static void copyItems(ObjectValue source, ObjectValue target, String elemName, MetadataEntityElement elemEntity) {
        if (!MessageUtil.isNull(source, elemName)) {
            List<IPropertyValue> items = source.getValueAsList(elemName);
            if (items.isEmpty()) {
                target.setValue(elemName, items);
            } else {
                String targetEntityType = elemEntity.getTarget();
                CurrentMetadataEntity metadataOfItem = new CurrentMetadataEntity();
                metadataOfItem.setAllRelatedEntityMap(target.getMetadata().getAllRelatedEntityMap());
                metadataOfItem.setCurrentEntityName(targetEntityType);
                List<IPropertyValue> itemsOfTarget = new ArrayList<>();
                for (IPropertyValue itemI : items) {
                    ObjectValue item = (ObjectValue) itemI;
                    ObjectValue itemOfTarget = buildObjectValueByEntityType(targetEntityType);
                    itemOfTarget.setMetadata(metadataOfItem);
                    copy(item, itemOfTarget);
                    itemsOfTarget.add(itemOfTarget);
                }
                target.setValue(elemName, itemsOfTarget);
            }
        }
    }

    private static ObjectValue buildObjectValueByEntityType(String entityType) {
        if (MetadataConstants.CoreModelEntity.QUALIFIED_TRACKING_ID.getFullName().equals(entityType)) {
            return new QualifiedTrackingId();
        }
        if (MetadataConstants.CoreModelEntity.PLANNED_EVENT.getFullName().equals(entityType)) {
            return new PlannedEvent();
        }
        if (MetadataConstants.CoreModelEntity.PROCESS_EVENT_DIRECTORY.getFullName().equals(entityType)) {
            return new ProcessEventDirectory();
        }
        return ObjectValue.valueOfEmpty();
    }

    public static void copyMissingValue(ObjectValue source, ObjectValue target) {
        Map<String, MetadataEntityElement> elementMap = source.getMetadata().getCurrentEntity().getElementMap();
        elementMap.forEach((fieldName, fieldConfig) -> {
            MetadataConstants.CdsDataType fieldType = fieldConfig.getType();
            if (source.isValueProvided(fieldName) && !target.isValueProvided(fieldName)) {
                if (MetadataConstants.CdsDataType.CDS_COMPOSITION.equals(fieldType)) {
                    List<IPropertyValue> valueListOfSource = source.getValueAsList(fieldName);
                    List<IPropertyValue> valueListOfTarget = new ArrayList<>();
                    valueListOfSource.forEach(value -> {
                        ObjectValue objectOfSource = (ObjectValue) value;
                        Map<String, IPropertyValue> valueMapOfTarget = new HashMap<>();
                        valueMapOfTarget.putAll(objectOfSource.getInternalValue());
                        ObjectValue valueOfTarget = buildObjectValueByEntityType(fieldConfig.getTarget());
                        valueOfTarget.setInternalValue(valueMapOfTarget);
                        valueOfTarget.setMetadata(objectOfSource.getMetadata());
                        valueListOfTarget.add(valueOfTarget);
                    });
                    target.setValue(fieldName, valueListOfTarget);
                } else if (!MetadataConstants.CdsDataType.CDS_ASSOCIATION.equals(fieldType)) {
                    target.setValue(fieldName, source.getValue(fieldName));
                }
            }
        });
    }

    public static void fillMetadata(ObjectValue objectValue) {
        CurrentMetadataEntity metadataOfParent = objectValue.getMetadata();
        MetadataEntity currentEntity = metadataOfParent.getCurrentEntity();
        Map<String, MetadataEntityElement> elementMap = currentEntity.getElementMap();
        elementMap.forEach((elemName, elemEntity) -> {
            MetadataConstants.CdsDataType elemType = elemEntity.getType();
            if (MetadataConstants.CdsDataType.CDS_COMPOSITION.equals(elemType) && !MessageUtil.isNull(objectValue, elemName)) {
                List<IPropertyValue> items = objectValue.getValueAsList(elemName);
                if (!items.isEmpty()) {
                    String targetEntityType = elemEntity.getTarget();
                    CurrentMetadataEntity metadataOfItem = new CurrentMetadataEntity();
                    metadataOfItem.setAllRelatedEntityMap(metadataOfParent.getAllRelatedEntityMap());
                    metadataOfItem.setCurrentEntityName(targetEntityType);
                    for (IPropertyValue itemI : items) {
                        ObjectValue item = (ObjectValue) itemI;
                        item.setMetadata(metadataOfItem);
                        fillMetadata(item);
                    }
                }
            }
        });
    }

    public static boolean isNull(ObjectValue obj, String fieldName) {
        if (!obj.isValueProvided(fieldName)) {
            return true;
        }
        return obj.getValue(fieldName).semanticEquals(NullValue.NULL).getInternalValue();
    }

    public static boolean isFinalEffectiveEvent(List<PlannedEvent> sortedPlannedEvents, UUID matchedPlannedEventId) {
        for (int i = 0; i < sortedPlannedEvents.size(); i++) {
            if (sortedPlannedEvents.get(i).getId().equals(matchedPlannedEventId)) {
                for (int j = i + 1; j < sortedPlannedEvents.size(); j++) {
                    String eventStatus = sortedPlannedEvents.get(j).getEventStatus();
                    if (!EventStatus.PLANNED.name().equals(eventStatus)) {
                        return false;
                    }
                }
                return true;
            }
        }
        return false;
    }

    /**
     * @param plannedEvents
     * @param plannedEventKeyList : L-value, M-operator, R-fieldName
     * @return
     */
    public static PlannedEvent matchPlannedEvent(List<PlannedEvent> plannedEvents, List<Triple<Object, String, String>> plannedEventKeyList) {
        if (plannedEvents == null) {
            return null;
        }
        for (PlannedEvent pe : plannedEvents) {
            if (matchPlannedEvent(pe, plannedEventKeyList)) {
                return pe;
            }
        }
        return null;
    }

    private static boolean matchPlannedEvent(ObjectValue plannedEvent, List<Triple<Object, String, String>> plannedEventKeyList) {
        for (Triple<Object, String, String> triple : plannedEventKeyList) {
            Object fieldValue = triple.getLeft();
            String operator = triple.getMiddle();
            String sourceFieldName = triple.getRight();

            Object plannedEventValue = getPropertyValue(plannedEvent, sourceFieldName);
            if (!Operator.EQUAL.getValue().equals(operator)) {
                return false;
            }
            if (!equalObjects(fieldValue, plannedEventValue)) {
                return false;
            }
        }
        return true;
    }

    public static boolean equalObjects(Object a, Object b) {
        if (a == null) {
            return b == null;
        }
        if (b == null) {
            return a == null;
        }

        if (a.getClass() != b.getClass()) {
            return false;
        }
        if (a instanceof BigDecimal) {
            return ((BigDecimal) a).compareTo((BigDecimal) b) == 0;
        }
        return a.equals(b);
    }

    public static PlannedEvent matchPlannedEvent(List<PlannedEvent> plannedEvents, UUID plannedEventId) {
        if (plannedEvents == null) {
            return null;
        }
        for (PlannedEvent pe : plannedEvents) {
            if (pe.getId().equals(plannedEventId)) {
                return pe;
            }
        }
        return null;
    }

    public static int getMaxPayloadSequence(Collection<PlannedEvent> plannedEvents) {
        int maxPayloadSequence = 0;
        for (PlannedEvent plannedEvent : plannedEvents) {
            if (plannedEvent.getPayloadSequence() > maxPayloadSequence) {
                maxPayloadSequence = plannedEvent.getPayloadSequence();
            }
        }
        return maxPayloadSequence;
    }

    public static String getPropertyValueAsString(ObjectValue obj, String propertyName) {
        return obj.isValueProvided(propertyName) ? obj.getValueAsString(propertyName) : null;
    }

    public static Object getPropertyValue(ObjectValue obj, String propertyName) {
        return obj.isValueProvided(propertyName) ? obj.getValue(propertyName).getInternalValue() : null;
    }

    public static boolean isReported(String status) {
        return EventStatus.REPORTED.name().equals(status)
                || EventStatus.LATE_REPORTED.name().equals(status)
                || EventStatus.EARLY_REPORTED.name().equals(status);
    }

}
