package com.sap.gtt.v2.core.entity.execution;

import java.time.Instant;

/**
 * @author I302310
 */
public class ExecutionHistory {

    private String id;
    private String unitId;
    private Instant executionAt;
    private String lastPhase;
    private String status;

    public ExecutionHistory(String id, String unitId, Instant executionAt, String lastPhase, String status) {
        this.id = id;
        this.unitId = unitId;
        this.executionAt = executionAt;
        this.lastPhase = lastPhase;
        this.status = status;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUnitId() {
        return unitId;
    }

    public void setUnitId(String unitId) {
        this.unitId = unitId;
    }

    public Instant getExecutionAt() {
        return executionAt;
    }

    public void setExecutionAt(Instant executionAt) {
        this.executionAt = executionAt;
    }

    public String getLastPhase() {
        return lastPhase;
    }

    public void setLastPhase(String lastPhase) {
        this.lastPhase = lastPhase;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
