package com.sap.gtt.v2.core.service.dpp;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.springframework.stereotype.Service;

import com.sap.gtt.v2.core.entity.trackedprocess.Event;
import com.sap.gtt.v2.core.entity.trackedprocess.TrackedProcess;
import com.sap.gtt.v2.core.management.tracking.DefaultEventManagement;
import com.sap.gtt.v2.core.management.tracking.DefaultTrackedProcessManagement;
import com.sap.gtt.v2.core.runtime.model.UUIDValue;

@Service
public class DPPEventManagementWrapper {
	public TrackedProcess getTrackedProcess(UUID trackedProcessId) {
		DefaultTrackedProcessManagement tpMan = DefaultTrackedProcessManagement.getInstance();
		return tpMan.get(UUIDValue.valueOf(trackedProcessId));
	}
	public List<Event> getEvent(List<UUID> eventIds) {
		DefaultEventManagement eventMan = DefaultEventManagement.getInstance();
		List<Event> ret = new ArrayList<Event>();
		for(UUID id : eventIds) {
			Event e = eventMan.get(UUIDValue.valueOf(id));
			if(e != null)
				ret.add(e);
		}
		return ret;
	}
	public void deleteTrackedProcesses(List<UUID> tracedProcessIds) {
		DefaultTrackedProcessManagement tpMan = DefaultTrackedProcessManagement.getInstance();
		for(UUID id : tracedProcessIds) {
			TrackedProcess tp = tpMan.get(UUIDValue.valueOf(id));
			if(tp != null) {
				tpMan.delete(tp);
			}
		}
	}
	public void deleteEvents(List<UUID> eventIds) {
		List<String> ids = new ArrayList<String>();
		for(UUID id : eventIds)
			ids.add(id.toString());
		DefaultEventManagement eventMan = DefaultEventManagement.getInstance();
		eventMan.delete(ids);
	}
}
