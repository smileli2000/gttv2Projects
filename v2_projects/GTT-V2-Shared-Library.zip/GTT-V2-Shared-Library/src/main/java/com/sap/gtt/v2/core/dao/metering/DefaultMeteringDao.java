package com.sap.gtt.v2.core.dao.metering;

import com.sap.gtt.v2.core.domain.metadata.MetadataConstants;
import com.sap.gtt.v2.util.DBUtils;
import com.sap.gtt.v2.util.SpringContextUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.Calendar;
import java.util.TimeZone;

/**
 * @author I301346
 */
@Repository(DefaultMeteringDao.BEAN_NAME)
public class DefaultMeteringDao implements IMeteringDao {
    public static final String BEAN_NAME = "com.sap.gtt.v2.core.dao.metering.DefaultMeteringDao";
    private static final String JOB_NAME = "JOB_NAME";
    private static final String PREVIOUS_RUN_TIME = "PREVIOUS_RUN_TIME";
    private static final String METERING_JOB_INFO_TABLE_NAME = "METERING_JOB_INFO";
    private static final String CREATIONDATETIME = "CREATIONDATETIME";

    public static DefaultMeteringDao getInstance() {
        return (DefaultMeteringDao) SpringContextUtils.getBean(BEAN_NAME);
    }

    @Autowired
    private JdbcTemplate jdbcTemplate;

    /**
     * There is only one record in METERING_JOB_INFO which is the previous job info.
     * For the first time, if there is no record, return 1970-01-01T00:00:00Z epoch instant
     *
     * @param jobName
     * @return the last job time
     */
    @Override
    public Instant getPreviousMeteringTime(String jobName) {
        String sql = new StringBuilder()
                .append("SELECT ")
                .append(PREVIOUS_RUN_TIME)
                .append(" FROM  ")
                .append(METERING_JOB_INFO_TABLE_NAME)
                .append(" WHERE ")
                .append(JOB_NAME)
                .append(" = ? ").toString();
        SqlRowSet result = jdbcTemplate.queryForRowSet(sql, jobName);
        if (result.next()) {
            Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
            Timestamp previousTime = result.getTimestamp(PREVIOUS_RUN_TIME, cal);
            return Instant.ofEpochSecond(previousTime.toInstant().getEpochSecond());
        }
        return Instant.EPOCH;
    }

    @Override
    public int countEvent(Instant from, Instant to) {
        return count(from, to, DBUtils.toTableName(MetadataConstants.CoreModelEntity.EVENT.getFullName()));
    }

    @Override
    public int countTP(Instant from, Instant to) {
        return count(from, to, DBUtils.toTableName(MetadataConstants.CoreModelEntity.TRACKED_PROCESS.getFullName()));
    }

    /**
     * count new created tp or event by table name
     *
     * @param from
     * @param to
     * @param tableName
     * @return
     */
    private int count(Instant from, Instant to, String tableName) {
        String sql = new StringBuilder()
                .append("select count(1) as NUM from ")
                .append(tableName)
                .append(" where ? <= ")
                .append(CREATIONDATETIME)
                .append(" and ")
                .append(CREATIONDATETIME)
                .append(" < ?").toString();
        SqlRowSet result = jdbcTemplate.queryForRowSet(sql, from, to);

        if (result.next()) {
            return result.getInt("NUM");
        }
        return 0;
    }

    /**
     * Update job run time with jobRunTime;
     * If there is no record, do insert
     *
     * @param jobName
     * @param jobRunTime
     */
    @Override
    public void updateMeteringJobInfo(String jobName, Instant jobRunTime) {
        String sql = "";
        Instant previousDetectionTime = getPreviousMeteringTime(jobName);
        if (previousDetectionTime == null || previousDetectionTime.equals(Instant.EPOCH)) {
            sql = new StringBuilder("INSERT INTO ")
                    .append(METERING_JOB_INFO_TABLE_NAME)
                    .append(" (")
                    .append(PREVIOUS_RUN_TIME)
                    .append(", ")
                    .append(JOB_NAME)
                    .append(") VALUES (?,?)").toString();
        } else {
            sql = new StringBuilder("UPDATE ")
                    .append(METERING_JOB_INFO_TABLE_NAME)
                    .append(" SET ").append(PREVIOUS_RUN_TIME)
                    .append(" = ? WHERE ")
                    .append(JOB_NAME)
                    .append(" = ?").toString();
        }
        if (sql != null && !sql.isEmpty()) {
            jdbcTemplate.update(sql, new Object[]{jobRunTime, jobName});
        }
    }
}
