package com.sap.gtt.v2.core.dao.execution;

import com.sap.gtt.v2.core.entity.execution.ExecutionMessage;

import java.util.List;

public interface IExecutionMessageDao {
    ExecutionMessage queryExecutionMessage(String id);

    List<ExecutionMessage> queryExecutionMessages(String phaseId);

    void insertExecutionMessage(ExecutionMessage message);
}
