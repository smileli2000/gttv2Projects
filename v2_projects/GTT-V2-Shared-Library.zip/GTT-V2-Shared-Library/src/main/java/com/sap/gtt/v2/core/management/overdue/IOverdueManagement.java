package com.sap.gtt.v2.core.management.overdue;

import com.sap.gtt.v2.core.runtime.model.ObjectValue;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

public interface IOverdueManagement {


    class PlannedEventIdentifier {
        private UUID plannedEventId;
        private String altKey;
        private UUID subaccountId;
        private UUID cloneServiceInstanceId;
        private String trackedProcessType;
        private String namespace;
        private String partyId;

        public void setTrackedProcessType(String trackedProcessType) {
            this.trackedProcessType = trackedProcessType;
        }

        public String getTrackedProcessType() {
            return trackedProcessType;
        }

        public String getNamespace() {
            return namespace;
        }

        public void setNamespace(String namespace) {
            this.namespace = namespace;
        }

        public PlannedEventIdentifier(UUID plannedEventId, String altKey, UUID subaccountId,
                                      UUID cloneServiceInstanceId, String trackedProcessType, String namespace, String partyId) {
            super();
            this.plannedEventId = plannedEventId;
            this.altKey = altKey;
            this.subaccountId = subaccountId;
            this.cloneServiceInstanceId = cloneServiceInstanceId;
            this.trackedProcessType = trackedProcessType;
            this.namespace = namespace;
            this.partyId = partyId;
        }

        public UUID getPlannedEventId() {
            return plannedEventId;
        }

        public String getAltKey() {
            return altKey;
        }

        public UUID getSubaccountId() {
            return subaccountId;
        }

        public void setSubaccountId(UUID subaccountId) {
            this.subaccountId = subaccountId;
        }

        public UUID getCloneServiceInstanceId() {
            return cloneServiceInstanceId;
        }

        public void setCloneServiceInstanceId(UUID cloneServiceInstanceId) {
            this.cloneServiceInstanceId = cloneServiceInstanceId;
        }

        public void setPlannedEventId(UUID plannedEventId) {
            this.plannedEventId = plannedEventId;
        }

        public void setAltKey(String altKey) {
            this.altKey = altKey;
        }

        public String getPartyId() {
            return partyId;
        }

        public void setPartyId(String partyId) {
            this.partyId = partyId;
        }

        public ObjectValue valueOf(UUID plannedEventId, String altKey, String subaccountId,
                                   String cloneServiceInstanceId) {
            return null;
        }

    }

    Instant getPreviousDetectionTime(String jobName);

    int countOverduePlannedEvent(Instant from, Instant to);

    List<PlannedEventIdentifier> getOverduePlannedEventsInfo(Instant from, Instant to, int skip, int top);

    void updateOverdueInfo(String jobName, Instant jobRunTime);
}
