package com.sap.gtt.v2.core.dao.metadata;

import com.sap.gtt.v2.core.domain.metadata.MetadataEntity;
import com.sap.gtt.v2.core.domain.metadata.MetadataEntityElement;

import java.util.List;

/**
 * Interface for DDL builder
 *
 * @author I321712
 */
public interface DDLBuilder {
    enum DDLAction {
        /**
         * CREATE TABLE
         */
        CREATE_TABLE("CREATE TABLE"),
        /**
         * ALTER TABLE ADD
         */
        ADD_TABLE_COLUMN("ALTER TABLE ADD"),
        /**
         * ALTER TABLE ALTER
         */
        ALTER_TABLE_COLUMN("ALTER TABLE ALTER"),
        /**
         * ALTER TABLE DROP
         */
        DROP_TABLE_COLUMN("ALTER TABLE DROP"),
        /**
         * Drop TABLE
         */
        DROP_TABLE("DROP TABLE");

        private String value;

        DDLAction(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }
    }

    /**
     * Build table creating SQL script for given entity
     *
     * @param entityName entity name
     * @param elements   entity elements
     * @return table creating SQL script
     */
    String buildCreateTable(String entityName, List<MetadataEntityElement> elements);

    /**
     * Build add table column SQL script for a given entity
     *
     * @param entityName entity name
     * @param elements   entity elements
     * @return column adding SQL script
     */
    String buildAddTableField(String entityName, List<MetadataEntityElement> elements);

    /**
     * Build alter table column SQL
     * for HANA
     * alter table GTTDEV.COM_SAP_CTTEST0 alter (cl2 nvarchar(20))
     * alter table GTTDEV.COM_SAP_CTTEST0 alter (cl3 decimal(5,2))
     * for H2
     * alter table COM_SAP_CTTEST0 alter cl2 nvarchar(20)
     * alter table COM_SAP_CTTEST0 alter cl3 decimal(5,2)
     *
     * @param entityName entity name
     * @param elements   entity elements
     * @return alter table column SQL
     */
    List<String> buildAlterTableField(String entityName, List<MetadataEntityElement> elements);

    /**
     * Build drop table column SQL
     * alter table GTTDEV.COM_SAP_CTTEST0 drop (cl1,cl2);
     *
     * @param entityName entity name
     * @param elements   entity elements
     * @return drop column SQL
     */
    String buildDropTableField(String entityName, List<MetadataEntityElement> elements);

    /**
     * Build drop table SQL
     * drop table GTTDEV.COM_SAP_CTTEST0
     * @param entityName entity name to be dropped
     * @return drop table SQL
     */
    String buildDropTable(String entityName);

    /**
     * Build delete table SQL
     * delete table GTTDEV.COM_SAP_CTTEST0
     * @param entityName entity name to be deleted
     * @return delete table SQL
     */
    String buildDeleteTable(String entityName);

    /**
     * Build insert table for code list SQL
     * @param entityName code list entity name
     * @return insert table SQL for code list
     */
    String buildInsertTableForCodeList(String entityName);

    /**
     * Build insert table for code list Texts SQL
     * @param entityName code list entity name
     * @return insert table SQL for code list
     */
    String buildInsertTableForCodeListTexts(String entityName);

    /**
     * Build delete table for metadata process Texts SQL
     * @return delete table SQL for metadata process Texts
     */
    String buildDeleteTableForMetadataProcessTexts();

    /**
     * Build delete table for metadata project Texts SQL
     * @return delete table SQL for metadata project Texts
     */
    String buildDeleteTableForMetadataProjectTexts();

    /**
     * Build insert table for metadata process Texts SQL
     * @return insert table SQL for metadata process Texts
     */
    String buildInsertTableForMetadataProcessTexts();

    /**
     * Build column information such as ID TYPE VARCHAR(50) and then add to the existed SQL script
     *
     * @param element entity element
     * @param sqlBuf  existed SQL script
     */
    void buildColumn(MetadataEntityElement element, StringBuilder sqlBuf);

    /**
     * Build table retrieving SQL queries
     *
     * @param entities metadata entities
     * @param sqlBuf   find table SQL
     * @param params   parameters
     */
    void buildFindTableQuery(List<MetadataEntity> entities, StringBuilder sqlBuf, List<String> params);

    /**
     * Build insert table for metadata project Texts SQL
     * @return insert table SQL for metadata project Texts
     */
    String buildInsertTableForMetadataProjectTexts();
}
