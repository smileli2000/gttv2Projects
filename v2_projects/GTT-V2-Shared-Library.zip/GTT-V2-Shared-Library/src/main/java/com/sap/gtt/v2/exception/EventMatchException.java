package com.sap.gtt.v2.exception;

import org.apache.http.HttpStatus;

public class EventMatchException extends GeneralNoneTranslatableException {
    public static final String ERROR_CODE = "ERROR_CODE_EVENT_MATCH";

    public EventMatchException(String message) {
        super(message, null, HttpStatus.SC_BAD_REQUEST);
    }

    @Override
    public String getErrorCode() {
        return ERROR_CODE;
    }
}
