package com.sap.gtt.v2.core.domain.dpp;
import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ApplicationGetDto implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -4929250812822376341L;


	@JsonProperty("appGUID")
	private String appGUID;
	
	@JsonProperty("data")
	private String data;
	
	@JsonProperty("attachmentFolderId")
	private String attachmentFolderId;

	public String getAppGUID() {
		return appGUID;
	}

	public void setAppGUID(String appGUID) {
		this.appGUID = appGUID;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public String getAttachmentFolderId() {
		return attachmentFolderId;
	}

	public void setAttachmentFolderId(String attachmentFolderId) {
		this.attachmentFolderId = attachmentFolderId;
	}
	
	
}
