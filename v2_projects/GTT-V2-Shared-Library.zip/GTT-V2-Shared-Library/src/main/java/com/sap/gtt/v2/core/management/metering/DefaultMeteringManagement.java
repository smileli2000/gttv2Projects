package com.sap.gtt.v2.core.management.metering;

import com.sap.gtt.v2.core.dao.metadata.DefaultMetadataDao;
import com.sap.gtt.v2.core.dao.metering.DefaultMeteringDao;
import com.sap.gtt.v2.core.dao.metering.IMeteringDao;
import com.sap.gtt.v2.core.dao.overdue.DefaultOverdueDao;
import com.sap.gtt.v2.core.dao.overdue.IOverdueDao;
import com.sap.gtt.v2.core.management.tracking.DefaultEventManagement;
import com.sap.gtt.v2.log.TenantAwareLogService;
import com.sap.gtt.v2.util.SpringContextUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.Instant;

/**
 * @author I301346
 */
@Service(DefaultMeteringManagement.BEAN_NAME)
public class DefaultMeteringManagement implements IMeteringManagement {
    public static final String BEAN_NAME = "com.sap.gtt.v2.core.management.metering.DefaultMeteringManagement";

    protected DefaultMeteringManagement() {
    }

    public static DefaultMeteringManagement getInstance() {
        return (DefaultMeteringManagement) SpringContextUtils.getBean(BEAN_NAME);
    }

    protected IMeteringDao getMeteringDao() {
        return DefaultMeteringDao.getInstance();
    }

    @Override
    public Instant getPreviousMeteringTime(String jobName) {
        return this.getMeteringDao().getPreviousMeteringTime(jobName);
    }

    @Override
    public int countEvent(Instant from, Instant to) {
        return this.getMeteringDao().countEvent(from, to);
    }

    @Override
    public int countTP(Instant from, Instant to) {
        return this.getMeteringDao().countTP(from, to);
    }

    @Override
    public void updateMeteringJobInfo(String jobName, Instant jobRunTime) {
        this.getMeteringDao().updateMeteringJobInfo(jobName, jobRunTime);
    }
}
