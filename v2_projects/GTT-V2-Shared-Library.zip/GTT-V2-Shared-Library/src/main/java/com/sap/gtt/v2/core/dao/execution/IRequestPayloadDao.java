package com.sap.gtt.v2.core.dao.execution;

import com.sap.gtt.v2.core.entity.execution.RequestPayload;

/**
 * @author I302310
 */
public interface IRequestPayloadDao {
    void insertRequestPayload(RequestPayload requestPayload);

    void updateStatus(String requestId, String status);

    RequestPayload query(String requestId);
}
