package com.sap.gtt.v2.util;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.InvocationTargetException;
import java.util.Locale;

/**
 * Enum Utils
 *
 * @author I321712
 */
public class EnumUtils {

    private static Logger logger = LoggerFactory.getLogger(EnumUtils.class);

    private EnumUtils() {
        throw new IllegalStateException("EnumUtils class");
    }

    private static final String GET_VALUE = "getValue";

    public static <I extends Object> I getEnumType(Class<I> enumClazz, String enumName) {
        if (StringUtils.isBlank(enumName) || !enumClazz.isEnum()) {
            return null;
        }
        enumName = enumName.toUpperCase(Locale.ENGLISH);
        I[] enumConstants = enumClazz.getEnumConstants();
        for (I t : enumConstants) {
            if (t.toString().equalsIgnoreCase(enumName)) {
                return t;
            }
        }
        return null;
    }

    public static <I extends Object> I getEnumTypeByValue(Class<I> enumClazz, String enumValue) {
        if (StringUtils.isBlank(enumValue) || !enumClazz.isEnum()) {
            return null;
        }
        I[] enumConstants = enumClazz.getEnumConstants();
        for (I t : enumConstants) {
            try {
                Object val = enumClazz.getDeclaredMethod(GET_VALUE).invoke(t);
                if (val != null && enumValue.equalsIgnoreCase(val.toString())) {
                    return t;
                }
            } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException e) {
                logger.warn(e.getMessage(), e);
                return null;
            }
        }
        return null;
    }
}
