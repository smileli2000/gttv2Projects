package com.sap.gtt.v2.core.service.reminder;

import com.google.gson.JsonObject;

public interface IMailNotification {
	String getMailUri();
	JsonObject getRequestBody();
}
