package com.sap.gtt.v2.core.service.reminder;

public interface IReminderService {
	DirectMail generateDirectMail();
	DirectMailTemplate generateDirectMailTemplate();
}
