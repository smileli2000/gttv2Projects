package com.sap.gtt.v2.core.dao.tracking;

import com.sap.gtt.v2.core.domain.metadata.CurrentMetadataEntity;
import com.sap.gtt.v2.core.entity.trackedprocess.TrackedProcess;

import java.util.List;
import java.util.UUID;

/**
 * 
 * CRUD for TP header and user defined compositions
 * @author I053866
 *
 */
public interface ITrackedProcessDao {

	void insert(TrackedProcess trackedProcess);

	void insert(List<TrackedProcess> trackedProcessList);

	void update(TrackedProcess trackedProcess, Integer version);

	void delete(CurrentMetadataEntity metadata, UUID id);

	void delete(TrackedProcess trackedProcess);

	TrackedProcess findOneByAltKey(CurrentMetadataEntity metadata, String altKey);

	List<TrackedProcess> findAllByAltKeys(CurrentMetadataEntity metadata, List<String> altKeyList);

	List<TrackedProcess> findAllByAltKeys(CurrentMetadataEntity metadata, String... altKeys);

	List<TrackedProcess> findAllByNamespace(String namespace);

	TrackedProcess findOne(CurrentMetadataEntity metadata, UUID id);
	
	boolean versionExists(TrackedProcess tp, int version);

    TrackedProcess findOneWithValidStatus(UUID id);

	TrackedProcess findOne(UUID id);
}
