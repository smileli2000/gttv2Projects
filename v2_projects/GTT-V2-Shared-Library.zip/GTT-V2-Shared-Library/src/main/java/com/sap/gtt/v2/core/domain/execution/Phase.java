package com.sap.gtt.v2.core.domain.execution;

/**
 * @author I302310
 */
public enum Phase {
    CORRELATION("Correlation"),
    INIT("Initialization"),
    MERGE("Merge Process"),
    DB("Save to DB"),
    EVENT2ACTION("Event to action"),
    VALIDATION("Event validation"),
    PROCESS("Event handling");

    private String description;

    Phase(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }
}
