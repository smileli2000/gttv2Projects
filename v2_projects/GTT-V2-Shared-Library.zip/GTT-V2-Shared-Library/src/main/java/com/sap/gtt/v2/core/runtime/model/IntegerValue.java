package com.sap.gtt.v2.core.runtime.model;

import java.math.BigDecimal;

import com.sap.gtt.v2.exception.ValueParseException;

public final class IntegerValue extends NumberValue<Integer>{

	private IntegerValue(Integer internalValue) {
		super(internalValue);
	}

	@Override
	protected IPropertyValue addInternal(IPropertyValue that) {
		if(that instanceof IntegerValue){
			return new IntegerValue(this.getInternalValue() + ((IntegerValue)that).getInternalValue());
		}
		else if(that instanceof DecimalValue){
			BigDecimal resultValue = BigDecimal.valueOf(this.getInternalValue());
			return DecimalValue.valueOf(resultValue.add(((DecimalValue)that).getInternalValue()));
		}
		else{
			throw new UnsupportedOperationException(UnsupportedOperationException.class.getSimpleName());
		}
	}

	@Override
	protected IPropertyValue subInternal(IPropertyValue that) {
		if(that instanceof IntegerValue){
			return new IntegerValue(this.getInternalValue() - ((IntegerValue)that).getInternalValue());
		}
		else if(that instanceof DecimalValue){
			BigDecimal resultValue = BigDecimal.valueOf(this.getInternalValue());
			return DecimalValue.valueOf(resultValue.subtract(((DecimalValue)that).getInternalValue()));
		}
		else{
			throw new UnsupportedOperationException(UnsupportedOperationException.class.getSimpleName());
		}
	}
	
	@Override
	protected IPropertyValue mulInternal(IPropertyValue that) {
		if(that instanceof IntegerValue){
			return new IntegerValue(this.getInternalValue() * ((IntegerValue)that).getInternalValue());
		}
		else if(that instanceof DecimalValue){
			BigDecimal resultValue = BigDecimal.valueOf(this.getInternalValue());
			return DecimalValue.valueOf(resultValue.multiply(((DecimalValue)that).getInternalValue()));
		}
		else{
			throw new UnsupportedOperationException(UnsupportedOperationException.class.getSimpleName());
		}
	}

	@Override
	protected IPropertyValue divInternal(IPropertyValue that) {
		if(that instanceof IntegerValue){
			return new IntegerValue(this.getInternalValue() / ((IntegerValue)that).getInternalValue());
		}
		else if(that instanceof DecimalValue){
			BigDecimal resultValue = BigDecimal.valueOf(this.getInternalValue());
			return DecimalValue.valueOf(resultValue.divide(((DecimalValue)that).getInternalValue()));
		}
		else{
			throw new UnsupportedOperationException(UnsupportedOperationException.class.getSimpleName());
		}
	}

	@Override
	protected IPropertyValue powInternal(IPropertyValue that) {
		if(that instanceof IntegerValue){
			return DecimalValue.valueOf(BigDecimal.valueOf(Math.pow(this.getInternalValue(), ((IntegerValue)that).getInternalValue())));
		}
		else if(that instanceof DecimalValue){
			return DecimalValue.valueOf(BigDecimal.valueOf(Math.pow(this.getInternalValue().doubleValue(), ((DecimalValue)that).getInternalValue().doubleValue())));
		}
		else{
			throw new UnsupportedOperationException(UnsupportedOperationException.class.getSimpleName());
		}
	}


	@Override
	protected IPropertyValue negateInternal() {
		return new IntegerValue(0 - this.getInternalValue());
	}

	@Override
	protected int compareToInternal(IPropertyValue that) {
		int compareResult = 0;
		if(that instanceof IntegerValue){
			int thisValue = this.getInternalValue();
			int thatValue = ((IntegerValue)that).getInternalValue();
			compareResult = thisValue > thatValue ? 1 : -1;
			if(thisValue == thatValue) compareResult = 0;
		}
		else if(that instanceof DecimalValue){
			BigDecimal thisValue = BigDecimal.valueOf(this.getInternalValue());
			BigDecimal thatValue = ((DecimalValue)that).getInternalValue();
			return thisValue.compareTo(thatValue);
		}
		else{
			throw new UnsupportedOperationException(UnsupportedOperationException.class.getSimpleName());
		}
		
		return compareResult;
	}

	public static IntegerValue valueOf(int value){
		return new IntegerValue(value);
	}
	
	public static IntegerValue valueOf(String value){
		try{
			return IntegerValue.valueOf(Integer.parseInt(value));
		}
		catch(NumberFormatException e){
			throw new ValueParseException(e.getLocalizedMessage(), e);
		}
	}
	
}
