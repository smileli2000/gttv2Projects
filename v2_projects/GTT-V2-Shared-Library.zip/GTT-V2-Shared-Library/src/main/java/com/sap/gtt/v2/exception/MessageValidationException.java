package com.sap.gtt.v2.exception;

import org.apache.http.HttpStatus;

public class MessageValidationException extends BaseRuntimeException {
    public static final String ERROR_CODE = "ERROR_CODE_MESSAGE_PREDEFINED_VALIDATION";

    public static final String MESSAGE_CODE_TIME_SHOULD_EARLIER_OR_EQUAL = MessageValidationException.class.getName() + ".TimeShouldEarlierOrEqual";
    public static final String MESSAGE_CODE_PROPERTY_IS_REQUIRED = MessageValidationException.class.getName() + ".PropertyIsRequired";
    public static final String MESSAGE_CODE_DUPLICATE_ALT_KEY = MessageValidationException.class.getName() + ".DuplicateAltKey";
    public static final String MESSAGE_CODE_DUPLICATE_PLANNED_EVENT = MessageValidationException.class.getName() + ".DuplicatePlannedEvent";
    public static final String MESSAGE_CODE_DUPLICATE_PRIMARY_KEY = MessageValidationException.class.getName() + ".DuplicatePrimaryKey";
    public static final String MESSAGE_CODE_NOT_ENUM_VALUE = MessageValidationException.class.getName() + ".NotEnumValue";
    public static final String MESSAGE_CODE_CYCLE_REFERENCE_NOT_ALLOWED = MessageValidationException.class.getName() + ".CycleReferenceNotAllowed";
    public static final String MESSAGE_CODE_INVALID_PLANNED_EVENT = MessageValidationException.class.getName() + ".InvalidPlannedEvent";
    public static final String MESSAGE_CODE_INVALID_TRACKING_ID_TYPE = MessageValidationException.class.getName() + ".InvalidTrackingIdType";
    public static final String MESSAGE_CODE_EVENT_NOT_EXISTED = MessageValidationException.class.getName() + ".EventNotExisted";
    public static final String MESSAGE_CODE_SENDER_PARTY_ID_NOT_SUPPORT_IN_USER_TOKEN = MessageValidationException.class.getName() + ".SenderPartyIdNotSupportInUserToken";
    public static final String MESSAGE_CODE_BP_NOT_EXISTED = MessageValidationException.class.getName() + ".BpNotExisted";
    public static final String MESSAGE_CODE_ALTKEY_FORMAT_ERROR = MessageValidationException.class.getName() + ".AltKeyFormatError";
    public static final String MESSAGE_CODE_INVALID_PARTY_ID = MessageValidationException.class.getName() + ".InvalidPartyId";

    public MessageValidationException(String messageCode,
                                      Object[] localizedMsgParams) {
        super(null, null, messageCode, localizedMsgParams);
    }


    @Override
    public int getHttpStatus() {
        return HttpStatus.SC_BAD_REQUEST;
    }

    @Override
    public String getErrorCode() {
        return ERROR_CODE;
    }

}
