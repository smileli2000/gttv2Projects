package com.sap.gtt.v2.core.runtime.model;

import com.sap.gtt.v2.exception.OperationNotAllowed;

import java.util.List;

public interface IPropertyValue {

	public static final String ERROR_IMCOMPATIBLE_DATA_TYPE = "Operating on incompatible data type '%s' and '%s'";
	public static final String ERROR_OPERATE_ON_NULL = "Operating on null value";
	public static final String ERROR_OPERATE_NOT_SUPPORT = "Operation '%s' is not support on data type '%s'";
	public static final String ERROR_FUNCTION_NOT_FOUND = "Function '%s' is not defined on data type '%s'";
	
	public static final String ERROR_FUNCTION_ARGUMENTS_MISMATCH_SIZE = "Argument size mismatch on function '%s', expect '%s' but '%s'";
	public static final String ERROR_FUNCTION_ARGUMENTS_MISMATCH_TYPE = "Argument type mismatch on function '%s', argument '%s', expect '%s' but '%s'";
	public static final String ERROR_FUNCTION_CATEGORY_NOT_SUPPORT = "Function category '%s' not support for function '%s'";
	
	
	public static class FunctionInterfaceDef{
		public enum Category{
			SYSTEM, CUSTOMIZED
		}
		public final String name;
		public final Category category;
		public final List<Class<? extends IPropertyValue>> argumentTypes;
		public final IFunction function;
		public FunctionInterfaceDef(Category category, String name, List<Class<? extends IPropertyValue>> argumentTypes, IFunction function){
			this.category = category;
			this.name = name;
			this.argumentTypes = argumentTypes;
			this.function = function;
		}
		
	}
	
	public Object getInternalValue();
	
	public boolean isCsnPrimitive();
	
	public boolean isCollection();
	
	public default BooleanValue semanticEquals(IPropertyValue that){
		throw new OperationNotAllowed(String.format(ERROR_OPERATE_NOT_SUPPORT, "semanticEquals", this.getClass().getSimpleName()));
	}

	public default BooleanValue semanticNotEquals(IPropertyValue that){
		throw new OperationNotAllowed(String.format(ERROR_OPERATE_NOT_SUPPORT, "semanticNotEquals", this.getClass().getSimpleName()));
	}
	
	public default BooleanValue greaterEquals(IPropertyValue that) {
		throw new OperationNotAllowed(String.format(ERROR_OPERATE_NOT_SUPPORT, "greaterEquals", this.getClass().getSimpleName()));
	}
	
	public default BooleanValue greaterThan(IPropertyValue that) {
		throw new OperationNotAllowed(String.format(ERROR_OPERATE_NOT_SUPPORT, "greaterThan", this.getClass().getSimpleName()));
		
	}

	public default BooleanValue lessThan(IPropertyValue that) {
		throw new OperationNotAllowed(String.format(ERROR_OPERATE_NOT_SUPPORT, "lessThan", this.getClass().getSimpleName()));
		
	}

	public default BooleanValue lessEquals(IPropertyValue that) {
		throw new OperationNotAllowed(String.format(ERROR_OPERATE_NOT_SUPPORT, "lessEquals", this.getClass().getSimpleName()));
		
	}
	
	public default BooleanValue or(IPropertyValue that){
		throw new OperationNotAllowed(String.format(ERROR_OPERATE_NOT_SUPPORT, "or", this.getClass().getSimpleName()));	
	}
	
	public default BooleanValue and(IPropertyValue that){
		throw new OperationNotAllowed(String.format(ERROR_OPERATE_NOT_SUPPORT, "and", this.getClass().getSimpleName()));	
	}
	
	public default BooleanValue not(){
		throw new OperationNotAllowed(String.format(ERROR_OPERATE_NOT_SUPPORT, "not", this.getClass().getSimpleName()));	
	}
	
	public default IPropertyValue plus(IPropertyValue that){
		throw new OperationNotAllowed(String.format(ERROR_OPERATE_NOT_SUPPORT, "add", this.getClass().getSimpleName()));	
	}
	
	public default IPropertyValue sub(IPropertyValue that){
		throw new OperationNotAllowed(String.format(ERROR_OPERATE_NOT_SUPPORT, "sub", this.getClass().getSimpleName()));	
	}
	
	public default IPropertyValue mul(IPropertyValue that){
		throw new OperationNotAllowed(String.format(ERROR_OPERATE_NOT_SUPPORT, "mul", this.getClass().getSimpleName()));	
	}
	
	public default IPropertyValue div(IPropertyValue that){
		throw new OperationNotAllowed(String.format(ERROR_OPERATE_NOT_SUPPORT, "div", this.getClass().getSimpleName()));	
	}
	
	public default IPropertyValue pow(IPropertyValue that){
		throw new OperationNotAllowed(String.format(ERROR_OPERATE_NOT_SUPPORT, "pow", this.getClass().getSimpleName()));	
	}
	
	public default IPropertyValue negate(){
		throw new OperationNotAllowed(String.format(ERROR_OPERATE_NOT_SUPPORT, "negate", this.getClass().getSimpleName()));	
	}
	
	public default IPropertyValue callFunction(String functionName, List<IPropertyValue> args){
		throw new OperationNotAllowed(String.format(ERROR_OPERATE_NOT_SUPPORT, "callFunction", this.getClass().getSimpleName()));	
	}
	
	public default FunctionInterfaceDef getFunctionDef(String functionName){
		throw new OperationNotAllowed(String.format(ERROR_OPERATE_NOT_SUPPORT, "getFunctionDef", this.getClass().getSimpleName()));	
	}
}
	    
