package com.sap.gtt.v2.configuration;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.security.access.AccessDecisionVoter;
import org.springframework.security.access.vote.AuthenticatedVoter;
import org.springframework.security.access.vote.UnanimousBased;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configurers.ExpressionUrlAuthorizationConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.oauth2.config.annotation.web.configuration.ResourceServerConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configurers.ResourceServerSecurityConfigurer;
import org.springframework.security.oauth2.provider.expression.OAuth2WebSecurityExpressionHandler;
import org.springframework.security.oauth2.provider.token.ResourceServerTokenServices;
import org.springframework.security.web.access.expression.WebExpressionVoter;

import com.sap.gtt.v2.configuration.ISAPCloudPlatformAgent.ICurrentAccessContext;
import com.sap.gtt.v2.configuration.handler.RestAccessDeniedHandler;
import com.sap.gtt.v2.configuration.handler.RestAuthenticationEntryPoint;

/**
 * 
 * @author I053866
 *
 */

public abstract class AbstractCloudSecurityConfiguration extends ResourceServerConfigurerAdapter{
	
	@Autowired
	private ResourceServerTokenServices tokenService;    

	@Autowired
	private ServiceInstancesMapping serviceInstanceMapping;
	
	@Autowired
	private OAuth2WebSecurityExpressionHandler expressionHandler;
    
	@Autowired
	private RestAccessDeniedHandler accessDeniedHandler;
	@Autowired
	private RestAuthenticationEntryPoint authenticationEntryPoint;
    
	@Override
	public void configure(ResourceServerSecurityConfigurer resources) {
		resources.tokenServices(tokenService);
		resources.expressionHandler(expressionHandler);
        if (this.enableAuditLog()) {
            resources.authenticationEntryPoint(authenticationEntryPoint);
            resources.accessDeniedHandler(accessDeniedHandler);
        }
	}
    
    protected boolean enableAuditLog() {
        return true;
    }
    
    @Bean(name = "accessDecisionManager")
    protected UnanimousBased accessDecisionManagerBean() {
        List<AccessDecisionVoter<? extends Object>> voterList = new ArrayList<>();
        WebExpressionVoter expressionVoter = new WebExpressionVoter();
        expressionVoter.setExpressionHandler(expressionHandler);
        voterList.add(expressionVoter);
        voterList.add(new AuthenticatedVoter());
        return new UnanimousBased(voterList);
    }
    
    protected String getUaaXsAppname(){
    	return serviceInstanceMapping.getUaaServiceInstance().getXsappname();
    }
    
    protected String getScopeCheckExpress(String scope){
		return this.getScopeCheckExpress(scope, false);
	}
    
    protected String getScopeCheckExpress(String scope, boolean masterUaa){
    	String result = "#oauth2.hasScopeMatching('" + this.getUaaXsAppname() +"."+ scope + "')";
    	if(masterUaa){
    		// must to be master uaa jtw
    		result += " and " + "!@" + ICurrentAccessContext.BEAN_NAME+".containsCloneServiceInstanceId()";
    	}
    	// do NOT check if is clone instance jwt
    	/*else{
    		result += " and " + "@" + CurrentAccessContext.BEAN_NAME+".containsCloneServiceInstanceId()";
    	}*/
		return result;
	}
    
    /**
     * This is to fix a bug in the original OAuth2WebSecurityExpressionHandler
     * which no bean resolver set so that you can not use bean in the scope check SPEL
     * @param applicationContext
     * @return
     */
    @Bean
    public OAuth2WebSecurityExpressionHandler oAuth2WebSecurityExpressionHandler(ApplicationContext applicationContext) {
        OAuth2WebSecurityExpressionHandler webExpressionHandler = new OAuth2WebSecurityExpressionHandler();
		webExpressionHandler.setApplicationContext(applicationContext);
        return webExpressionHandler;
    }

	@Override
	public void configure(HttpSecurity http) throws Exception {
		ExpressionUrlAuthorizationConfigurer<HttpSecurity>.ExpressionInterceptUrlRegistry expressionInterceptUrlRegistry = http.sessionManagement()
		.sessionCreationPolicy(SessionCreationPolicy.NEVER)
		.and().authorizeRequests();
		
		expressionInterceptUrlRegistry = this.setProtectedExpressionInterceptUrlRegistry(expressionInterceptUrlRegistry);
		
		expressionInterceptUrlRegistry.anyRequest().denyAll();
	}
	
	
	public ExpressionUrlAuthorizationConfigurer<HttpSecurity>.ExpressionInterceptUrlRegistry setProtectedExpressionInterceptUrlRegistry(ExpressionUrlAuthorizationConfigurer<HttpSecurity>.ExpressionInterceptUrlRegistry  expressionInterceptUrlRegistry ){
		return expressionInterceptUrlRegistry.antMatchers("/lbnServiceHealth**").anonymous();
	}
    
}
