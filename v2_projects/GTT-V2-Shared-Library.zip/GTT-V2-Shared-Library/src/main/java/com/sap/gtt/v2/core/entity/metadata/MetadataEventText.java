package com.sap.gtt.v2.core.entity.metadata;

/**
 * @author I321712
 */
public class MetadataEventText extends ObjectText {
    private static final long serialVersionUID = 8675507634841278526L;
    private String metadataEventId;

    public String getMetadataEventId() {
        return metadataEventId;
    }

    public void setMetadataEventId(String metadataEventId) {
        this.metadataEventId = metadataEventId;
    }
}
