package com.sap.gtt.v2.core.rule.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.codec.binary.StringUtils;

import com.sap.gtt.v2.configuration.ISAPCloudPlatformAgent;
import com.sap.gtt.v2.core.entity.trackedprocess.TrackedProcess;
import com.sap.gtt.v2.core.rule.impl.function.ForwardCurrentTP;
import com.sap.gtt.v2.core.runtime.model.AbstractPropertyValue;
import com.sap.gtt.v2.core.runtime.model.BooleanValue;
import com.sap.gtt.v2.core.runtime.model.DateValue;
import com.sap.gtt.v2.core.runtime.model.IPropertyValue;
import com.sap.gtt.v2.core.runtime.model.NullValue;
import com.sap.gtt.v2.core.runtime.model.ObjectValue;
import com.sap.gtt.v2.core.runtime.model.StringValue;
import com.sap.gtt.v2.core.runtime.model.TimestampValue;
import com.sap.gtt.v2.core.runtime.model.UUIDValue;
import com.sap.gtt.v2.core.runtime.model.IPropertyValue.FunctionInterfaceDef;
import com.sap.gtt.v2.util.GTTUtils;
import com.sap.gtt.v2.util.JsonUtils;
import com.sap.gtt.v2.util.SpringContextUtils;

public class MemoryBlock extends ObjectValue{
	private static final String VARIABLE_NOT_DECLARED = "Variable '%s' is not declared";
	
	private static final String DUPLICATED_VARIABLE = "Variable '%s' is already declared";

	private static final String FUNCTION_TO_TIME_STAMP = "toTimestamp";

	private static final String FUNCTION_TO_DATE = "toDate";

	private static final String FUNCTION_TO_UUID = "toUUID";

	private static final String FUNCTION_TO_OBJECT = "toObject";

	private static final String FUNCTION_UPDATE_TP_PROPS = "updateTPProperties";
	
	private static final String FUNCTION_FORWARD_CURRENT_TP = "forwardCurrentTP";

	// define functions
		protected static final Map<String, FunctionInterfaceDef> functionDefs = new HashMap<>();
		static{
			functionDefs.putAll(ObjectValue.functionDefs);
			
			List<Class<? extends IPropertyValue>> argumentTypes = new ArrayList<>();
			argumentTypes.add(StringValue.class);

			List<Class<? extends IPropertyValue>> updateTpPropsArgumentTypes = new ArrayList<>();
			updateTpPropsArgumentTypes.add(0,TrackedProcess.class);
			updateTpPropsArgumentTypes.add(1,ObjectValue.class);


			FunctionInterfaceDef updateTPDef = new FunctionInterfaceDef(
					FunctionInterfaceDef.Category.SYSTEM, FUNCTION_UPDATE_TP_PROPS, updateTpPropsArgumentTypes,
					(callerObject, args) -> {
						TrackedProcess trackedProcess = (TrackedProcess) args.get(0);
						ObjectValue argObj = (ObjectValue) args.get(1);
						if(argObj.getInternalValue().isEmpty()) {
							return null;
						}
						boolean isUpdatePlannedEvent = false;
						boolean isUpdateTrackingIds = false;
						
						for(Map.Entry<String, IPropertyValue> entry : argObj.getInternalValue().entrySet()){
							String key = entry.getKey();
							IPropertyValue value = entry.getValue();
							trackedProcess.setValue(key, value);
							
							if(StringUtils.equals(key, TrackedProcess.TRACKING_IDS)){
								isUpdateTrackingIds = true;
							}
							else if(StringUtils.equals(key, TrackedProcess.PLANNED_EVENTS)){
								isUpdatePlannedEvent = true;
							}
						}
						
						GTTUtils.BusinessOperator businessOperator = SpringContextUtils.getBean(ISAPCloudPlatformAgent.ICurrentAccessContext.class).createBusinessOperator();
						businessOperator.getTrackedProcessManagement().update(trackedProcess, isUpdateTrackingIds, isUpdatePlannedEvent);
						return null;
					});
			functionDefs.put(updateTPDef.name, updateTPDef);

			FunctionInterfaceDef toTimeStampDef = new FunctionInterfaceDef(
					FunctionInterfaceDef.Category.SYSTEM, FUNCTION_TO_TIME_STAMP, argumentTypes,
					(callerObject, args) -> {
						StringValue input = (StringValue)args.get(0);
						return TimestampValue.valueOf(input.getInternalValue());
					});
			functionDefs.put(toTimeStampDef.name, toTimeStampDef);

			FunctionInterfaceDef toDateDef = new FunctionInterfaceDef(
					FunctionInterfaceDef.Category.SYSTEM, FUNCTION_TO_DATE, argumentTypes,
					(callerObject, args) -> {
						StringValue input = (StringValue)args.get(0);
						return DateValue.valueOf(input.getInternalValue());
					});
			functionDefs.put(toDateDef.name, toDateDef);

			FunctionInterfaceDef toUuidDef = new FunctionInterfaceDef(
					FunctionInterfaceDef.Category.SYSTEM, FUNCTION_TO_UUID, argumentTypes,
					(callerObject, args) -> {
						StringValue input = (StringValue)args.get(0);
						return UUIDValue.valueOf(input.getInternalValue());
					});
			functionDefs.put(toUuidDef.name, toUuidDef);

			FunctionInterfaceDef toObjectDef = new FunctionInterfaceDef(
					FunctionInterfaceDef.Category.SYSTEM, FUNCTION_TO_OBJECT, argumentTypes,
					(callerObject, args) -> {
						StringValue input = (StringValue)args.get(0);
						return ObjectValue.valueOf(JsonUtils.generateJsonObjectFromJsonString(input.getInternalValue()));
					});
			functionDefs.put(toObjectDef.name, toObjectDef);

			
			argumentTypes = new ArrayList<>();
			argumentTypes.add(StringValue.class); // destination Name
			argumentTypes.add(BooleanValue.class); // destinationInPaasAccount = true/false
			argumentTypes.add(BooleanValue.class); // true = forward old tp and planned event, false = not
			argumentTypes.add(BooleanValue.class); // true = async, false = sync
			
			FunctionInterfaceDef forwardCurrentTPDef = new FunctionInterfaceDef(
					FunctionInterfaceDef.Category.SYSTEM, FUNCTION_FORWARD_CURRENT_TP, argumentTypes,
					new ForwardCurrentTP()
			);
			functionDefs.put(forwardCurrentTPDef.name, forwardCurrentTPDef);

		}
		@Override
		protected Map<String, FunctionInterfaceDef> getFunctionDefs(){
			return functionDefs;
		}
		//

	private IPropertyValue returnedValue = null;
	
	
	public IPropertyValue getReturnedValue() {
		return returnedValue;
	}

	public void setReturnedValue(IPropertyValue returnedValue) {
		this.returnedValue = returnedValue;
	}

	private MemoryBlock() {
		super(new HashMap<>());
	}

	
	
	public void declareVariable(String name) throws MemoryBlockException{
		if(this.isVariableDeclared(name)){
			throw new MemoryBlockException(String.format(DUPLICATED_VARIABLE , name));
		}
		this.setValue(name, NullValue.NULL);
	}
	
	public void setVariableValue(String name, IPropertyValue value) throws MemoryBlockException {
		if(this.isVariableDeclared(name)){
			if(value == null){
				this.setValue(name, NullValue.NULL);
			} else {
				this.setValue(name, value);	
			}
		}
		else{
			throw new MemoryBlockException(String.format( VARIABLE_NOT_DECLARED, name));
		}
		
	}

	
	public boolean isVariableDeclared(String name) {
		
		return this.isValueProvided(name);
	}
	
	public IPropertyValue getVariableValue(String name) throws MemoryBlockException{
		if(this.isVariableDeclared(name)){
			return this.getValue(name);
		}
		else{
			throw new MemoryBlockException(String.format(VARIABLE_NOT_DECLARED , name));
		}
	}
	
	public static MemoryBlock createInstance(){
		return new MemoryBlock();
	}

}
