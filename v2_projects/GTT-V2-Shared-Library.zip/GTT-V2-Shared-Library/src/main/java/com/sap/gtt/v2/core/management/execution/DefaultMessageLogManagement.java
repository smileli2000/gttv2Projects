package com.sap.gtt.v2.core.management.execution;

import com.sap.gtt.v2.core.dao.execution.*;
import com.sap.gtt.v2.core.domain.execution.*;
import com.sap.gtt.v2.core.entity.execution.*;
import com.sap.gtt.v2.util.GTTUtils;
import com.sap.gtt.v2.util.SpringContextUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

/**
 * @author I302310
 */
@Service(DefaultMessageLogManagement.BEAN_NAME)
public class DefaultMessageLogManagement implements IMessageLogManagement {
    public static final String BEAN_NAME = "com.sap.gtt.v2.core.management.execution.DefaultMessageLogManagement";

    public static DefaultMessageLogManagement getInstance() {
        return (DefaultMessageLogManagement) SpringContextUtils.getBean(BEAN_NAME);
    }

    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    @Override
    public void insertExecution(ExecutionDto executionDto) {
        String eventId = executionDto.getEventId();
        String correlatedTpId = executionDto.getCorrelatedTpId();
        ExecutionUnit unit = getExecutionUnitDao().queryExecutionUnit(eventId, correlatedTpId);
        String executionHistoryId = executionDto.getExecutionHistoryId();
        String unitId = null;
        if (unit == null) {
            unitId = UUID.randomUUID().toString();
            unit = new ExecutionUnit(unitId, executionDto.getRequestId(), eventId,
                    executionDto.getEventType(), executionDto.getAltkey(), executionDto.getLocationAltkey(),
                    correlatedTpId, executionDto.getCorrelatedTpAltkey(), 1, executionHistoryId,
                    executionDto.isProcessEvent());
            getExecutionUnitDao().insertExecutionUnit(unit);
        } else {
            unitId = unit.getId();
            getExecutionUnitDao().updateExecutionUnit(unitId, unit.getExecutionCount() + 1, executionHistoryId);
        }
        ExecutionHistory executionHistory = new ExecutionHistory(executionHistoryId, unitId,
                executionDto.getExecutionAt(), executionDto.getLastPhase(), ExecutionStatus.SUCCESS.name());
        getExecutionHistoryDao().insertExecution(executionHistory);
    }

    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    @Override
    public void insertExecutionMessage(ExecutionMessageDto messageDto) {
        String executionHistoryId = messageDto.getExecutionHistoryId();
        String phaseName = messageDto.getPhase();
        IExecutionPhaseDao executionPhaseDao = getExecutionPhaseDao();
        ExecutionPhase phase = executionPhaseDao.queryExecutionPhase(executionHistoryId, phaseName);
        String messageType = messageDto.getMessageType();
        String phaseId = phase == null ? UUID.randomUUID().toString() : phase.getId();
        ExecutionMessage message = new ExecutionMessage(UUID.randomUUID().toString(), phaseId, messageType,
                messageDto.getMessage(), messageDto.getDetail(), messageDto.getErrorAt(), messageDto.getTag());
        getExecutionMessageDao().insertExecutionMessage(message);

        ExecutionStatus messageStatus = ExecutionStatus.valueOf(messageType);
        ExecutionStatus prePhaseStatus = null;
        ExecutionStatus postPhaseStatus;
        if (phase == null) {
            phase = new ExecutionPhase(phaseId, executionHistoryId, phaseName, messageType);
            executionPhaseDao.insertExecutionPhase(phase);
            postPhaseStatus = messageStatus;
        } else {
            prePhaseStatus = ExecutionStatus.valueOf(phase.getStatus());
            postPhaseStatus = prePhaseStatus;
            if (messageStatus.getPriority() > prePhaseStatus.getPriority()) {
                postPhaseStatus = messageStatus;
            } else if (messageStatus.getPriority() < prePhaseStatus.getPriority()
                    && ExecutionStatus.PENDING == prePhaseStatus
                    && ExecutionStatus.SUCCESS == messageStatus) {
                postPhaseStatus = recalculatePhaseStatus(phase.getId());
            }
        }

        if (prePhaseStatus != null && prePhaseStatus != postPhaseStatus) {
            getExecutionPhaseDao().updateExecutionPhaseStatus(phaseId, postPhaseStatus.name());
        }
        //for execution status
        ExecutionHistory executionHistory = getExecutionHistoryDao().queryExecution(executionHistoryId);
        ExecutionStatus preExecutionStatus = ExecutionStatus.valueOf(executionHistory.getStatus());
        ExecutionStatus postExecutionStatus = getExecutionStatus(executionHistoryId, prePhaseStatus, postPhaseStatus, preExecutionStatus);
        if (preExecutionStatus != postExecutionStatus) {
            getExecutionHistoryDao().updateExecutionStatus(executionHistoryId, phaseName, postExecutionStatus.name());
            ExecutionUnit unit = getExecutionUnitDao().queryExecutionUnit(executionHistoryId);
            String requestId = unit.getRequestId();
            RequestPayload payload = getRequestPayloadDao().query(requestId);
            ExecutionStatus prePayloadStatus = ExecutionStatus.valueOf(payload.getStatus());
            ExecutionStatus postPayloadStatus = getPayloadStatus(preExecutionStatus, postExecutionStatus, requestId, prePayloadStatus);
            if (prePayloadStatus != postPayloadStatus) {
                getRequestPayloadDao().updateStatus(requestId, postPayloadStatus.name());
            }
        }
    }

    private ExecutionStatus getPayloadStatus(ExecutionStatus preExecutionStatus, ExecutionStatus postExecutionStatus,
                                             String requestId, ExecutionStatus prePayloadStatus) {
        ExecutionStatus postPayloadStatus = prePayloadStatus;
        if (postExecutionStatus.getPriority() > preExecutionStatus.getPriority()) {
            if (postExecutionStatus.getPriority() > prePayloadStatus.getPriority()) {
                postPayloadStatus = postExecutionStatus;
            }
        } else if (postExecutionStatus.getPriority() < preExecutionStatus.getPriority()
                && preExecutionStatus.getPriority() == prePayloadStatus.getPriority()) {
            postPayloadStatus = recalculatePayloadStatus(requestId);
        }
        return postPayloadStatus;
    }

    private ExecutionStatus getExecutionStatus(String executionHistoryId, ExecutionStatus prePhaseStatus,
                                               ExecutionStatus postPhaseStatus, ExecutionStatus preExecutionStatus) {
        ExecutionStatus postExecutionStatus = preExecutionStatus;
        if (prePhaseStatus == null || postPhaseStatus.getPriority() > prePhaseStatus.getPriority()) {
            if (postPhaseStatus.getPriority() > preExecutionStatus.getPriority()) {
                postExecutionStatus = postPhaseStatus;
            }
        } else if (postPhaseStatus.getPriority() < prePhaseStatus.getPriority()
                && prePhaseStatus.getPriority() == preExecutionStatus.getPriority()) {
            postExecutionStatus = recalculateExecutionStatus(executionHistoryId);
        }
        return postExecutionStatus;
    }

    private ExecutionStatus recalculateExecutionStatus(String executionHistoryId) {
        List<ExecutionPhase> phases = getExecutionPhaseDao().queryExecutionPhases(executionHistoryId);
        Optional<ExecutionPhase> warningPhase = phases.stream()
                //!StringUtils.equals(p.getPhase(), phaseName) &&
                .filter(p -> ExecutionStatus.WARNING == ExecutionStatus.valueOf(p.getStatus())).findAny();
        return warningPhase.isPresent() ? ExecutionStatus.WARNING : ExecutionStatus.SUCCESS;
    }

    private ExecutionStatus recalculatePhaseStatus(String phaseId) {
        List<ExecutionMessage> messages = getExecutionMessageDao().queryExecutionMessages(phaseId);
        List<String> pendingMap = new ArrayList<>();
        List<String> successMap = new ArrayList<>();
        List<String> warningIds = new ArrayList<>();

        for (ExecutionMessage message : messages) {
            ExecutionStatus messageStatus = ExecutionStatus.valueOf(message.getMessageType());
            if (ExecutionStatus.WARNING == messageStatus) {
                warningIds.add(message.getId());
            } else if (StringUtils.isNotBlank(message.getTag())) {
                if (ExecutionStatus.PENDING == messageStatus) {
                    pendingMap.add(message.getTag());
                } else if (ExecutionStatus.SUCCESS == messageStatus) {
                    successMap.add(message.getTag());
                }
            }
        }
        boolean isPending = !successMap.containsAll(pendingMap);
        if (!isPending) {
            return warningIds.isEmpty() ? ExecutionStatus.SUCCESS : ExecutionStatus.WARNING;
        }
        return ExecutionStatus.PENDING;
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    public void insertMappingMessage(MappingMessageDto mappingMessageDto) {
        String id = UUID.randomUUID().toString();
        ExecutionStatus status = mappingMessageDto.getStatus();
        String rootRequestId = mappingMessageDto.getRootRequestId();
        RequestMapping requestMapping = new RequestMapping(id, rootRequestId, mappingMessageDto.getObjectId(),
                mappingMessageDto.getTargetId(), status.name(), mappingMessageDto.getMessage(), mappingMessageDto.getDetail());
        getRequestMappingDao().insert(requestMapping);

        IRequestPayloadDao payloadDao = getRequestPayloadDao();
        RequestPayload payload = payloadDao.query(rootRequestId);
        ExecutionStatus payloadStatus = ExecutionStatus.valueOf(payload.getStatus());
        if (status.getPriority() > payloadStatus.getPriority()) {
            payloadDao.updateStatus(rootRequestId, status.name());
        }
    }

    protected ExecutionStatus recalculatePayloadStatus(String requestId) {
        List<RequestMapping> requestMappings = getRequestMappingDao().queryRequestMappings(requestId);
        List<String> executionStatusList = getExecutionHistoryDao().queryStatus(requestId);
        Optional<RequestMapping> errorMappingFound = requestMappings.stream()
                .filter(mapping -> ExecutionStatus.ERROR.name().equals(mapping.getMessageType())).findAny();
        if (errorMappingFound.isPresent()) {
            return ExecutionStatus.ERROR;
        }
        Optional<String> executionErrorFound = executionStatusList.stream()
                .filter(s -> ExecutionStatus.ERROR.name().equals(s)).findAny();
        if (executionErrorFound.isPresent()) {
            return ExecutionStatus.ERROR;
        }
        Optional<String> executionPendingFound = executionStatusList.stream()
                .filter(s -> ExecutionStatus.PENDING.name().equals(s)).findAny();
        if (executionPendingFound.isPresent()) {
            return ExecutionStatus.PENDING;
        }
        Optional<RequestMapping> warningMappingFound = requestMappings.stream()
                .filter(mapping -> ExecutionStatus.WARNING.name().equals(mapping.getMessageType())).findAny();
        if (warningMappingFound.isPresent()) {
            return ExecutionStatus.WARNING;
        }
        Optional<String> executionWarningFound = executionStatusList.stream()
                .filter(s -> ExecutionStatus.WARNING.name().equals(s)).findAny();
        if (executionWarningFound.isPresent()) {
            return ExecutionStatus.WARNING;
        }
        return ExecutionStatus.SUCCESS;
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    public void insertPayload(RequestPayloadDto payloadDto) {
        RequestPayload requestPayload = new RequestPayload();
        requestPayload.setId(payloadDto.getId());
        requestPayload.setParentId(payloadDto.getParentId());
        requestPayload.setMessageNumber(payloadDto.getMessageNumber());
        requestPayload.setSourceId(payloadDto.getSourceId());
        requestPayload.setSource(payloadDto.getSource());
        requestPayload.setRequestDataTime(payloadDto.getRequestDataTime());
        requestPayload.setWriteServicePath(payloadDto.getWriteServicePath());
        requestPayload.setPayload(payloadDto.getPayload());
        requestPayload.setStatus(ExecutionStatus.SUCCESS.name());
        requestPayload.setCloneInstanceId(payloadDto.getCloneInstanceId());
        requestPayload.setSubaccountId(payloadDto.getSubaccountId());
        getRequestPayloadDao().insertRequestPayload(requestPayload);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    public void insertTrackingIds(RequestTrackingIdDto trackingIdDto) {
        String requestId = trackingIdDto.getRequestId();
        List<String> trackingIds = trackingIdDto.getTrackingIds();
        if (trackingIds == null || trackingIds.isEmpty()) {
            return;
        }
        List<RequestTrackingId> requestTrackingIds = new ArrayList<>();
        for (String trackingId : trackingIds) {
            String id = GTTUtils.UUIDUtils.generateTimeBasedUUID().toString();
            RequestTrackingId requestTrackingId = new RequestTrackingId();
            requestTrackingId.setId(id);
            requestTrackingId.setRequestId(requestId);
            requestTrackingId.setTrackingId(trackingId);
            requestTrackingIds.add(requestTrackingId);
        }
        getRequestTrackingIdDao().insertRequestTrackingIds(requestTrackingIds);
    }

    @Override
    public void insertCorrelatedTrackedProcess(CorrelatedTrackedProcessDto trackedProcessDto) {
        String executionId = trackedProcessDto.getExecutionId();
        Map<String, String> tpMap = trackedProcessDto.getTpMap();
        if (tpMap == null || tpMap.isEmpty()) {
            return;
        }
        List<CorrelatedTrackedProcess> trackedProcesses = new ArrayList<>();
        for (Map.Entry<String, String> entry : tpMap.entrySet()) {
            String id = GTTUtils.UUIDUtils.generateTimeBasedUUID().toString();
            CorrelatedTrackedProcess trackedProcess = new CorrelatedTrackedProcess();
            trackedProcess.setId(id);
            trackedProcess.setExecutionId(executionId);
            trackedProcess.setCorrelatedTpId(entry.getKey());
            trackedProcess.setCorrelatedTpAltkey(entry.getValue());
            trackedProcesses.add(trackedProcess);
        }
        getCorrelatedTrackedProcessDao().insert(trackedProcesses);
    }

    protected IRequestPayloadDao getRequestPayloadDao() {
        return DefaultRequestPayloadDao.getInstance();
    }

    protected IRequestTrackingIdDao getRequestTrackingIdDao() {
        return DefaultRequestTrackingIdDao.getInstance();
    }

    protected IRequestMappingDao getRequestMappingDao() {
        return DefaultRequestMappingDao.getInstance();
    }

    protected ICorrelatedTrackedProcessDao getCorrelatedTrackedProcessDao() {
        return DefaultCorrelatedTrackedProcessDao.getInstance();
    }

    protected IExecutionUnitDao getExecutionUnitDao() {
        return DefaultExecutionUnitDao.getInstance();
    }

    protected IExecutionHistoryDao getExecutionHistoryDao() {
        return DefaultExecutionHistoryDao.getInstance();
    }

    protected IExecutionPhaseDao getExecutionPhaseDao() {
        return DefaultExecutionPhaseDao.getInstance();
    }

    protected IExecutionMessageDao getExecutionMessageDao() {
        return DefaultExecutionMessageDao.getInstance();
    }
}
