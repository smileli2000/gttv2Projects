package com.sap.gtt.v2.core.domain.trackedprocess;

/**
 * @author I302310
 */

public enum CorrelationType {
    EARLY_REPORTED,
    REPORTED,
    LATE_REPORTED,
    UNPLANNED,
    UNPLANNED_PROCESS_CREATION_UPDATE,
    UNPLANNED_OVERDUE,
    UNPLANNED_DELAYED,
    UNPLANNED_ONTIME,
    UNPLANNED_BLOCKING,
    UNPLANNED_UPDATE_PLAN
}
