package com.sap.gtt.v2.core.entity.metadata;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * @author I321712
 */
public class MetadataEvent implements Serializable {
    private String id;
    private String metadataProcessId;
    private String eventType;
    private String description;
    private List<MetadataEventText> metadataEventTexts = new ArrayList<>();

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getMetadataProcessId() {
        return metadataProcessId;
    }

    public void setMetadataProcessId(String metadataProcessId) {
        this.metadataProcessId = metadataProcessId;
    }

    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<MetadataEventText> getMetadataEventTexts() {
        return new ArrayList<>(metadataEventTexts);
    }

    public void addMetadataEventText(MetadataEventText metadataEventText) {
        this.metadataEventTexts.add(metadataEventText);
    }

    public void clearMetadataEventTexts() {
        this.metadataEventTexts.clear();
    }
}
