package com.sap.gtt.v2.controller;

import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;


public interface IBaseRestController {

	@InitBinder
	public default void initBinder(WebDataBinder binder) {
		binder.setDisallowedFields(getDisallowedFields());
	}
	
	public default String[] getDisallowedFields(){
		return new String[]{};
	}
}
