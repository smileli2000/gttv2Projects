package com.sap.gtt.v2.util;

import com.sap.gtt.v2.configuration.EnvironmentsConfiguration.VcapServiceParser.DatabaseServiceInstance.DatabaseType;
import com.sap.gtt.v2.core.dao.metadata.DDLBuilder;
import com.sap.gtt.v2.core.dao.metadata.DDLBuilderH2Impl;
import com.sap.gtt.v2.core.dao.metadata.DDLBuilderHanaImpl;
import com.sap.gtt.v2.core.domain.metadata.MetadataConstants.CoreModelEntity;
import com.sap.gtt.v2.core.domain.metadata.MetadataConstants.EntityBaseType;
import com.sap.gtt.v2.core.domain.metadata.PhysicalName;
import com.sap.gtt.v2.core.management.metadata.CsnParser;
import org.apache.commons.lang3.RegExUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.List;

import static com.sap.gtt.v2.core.domain.metadata.MetadataConstants.COMMA;
import static com.sap.gtt.v2.core.domain.metadata.MetadataConstants.UNDERSCORE;

/**
 * Utilities for DB related operations
 *
 * @author I321712
 */
public class DBUtils {

    public static final String WHERE = " WHERE ";

    private DBUtils() {
        //Utility classes should not have public constructors
        throw new IllegalStateException("DBUtils class");
    }

    public static String toStringValue(Object obj) {
        return obj == null ? null : obj.toString();
    }

    public static void buildUpdateSql(String tableName, String[] updatedColumns, Object[] updatedVals,
                                      String[] whereColumns, Object[] whereVals,
                                      StringBuilder updateSql, List<Object> updateParam) {
        if (whereVals == null || whereVals.length == 0) {
            return;
        }
        updateSql.append("UPDATE ")
                .append(tableName)
                .append(" SET ");
        for (int i = 0; i < updatedVals.length; i++) {
            Object updatedVal = updatedVals[i];
            if (updatedVal != null) {
                updateSql.append(updatedColumns[i]).append("=?");
                if (i < updatedVals.length - 1) {
                    updateSql.append(COMMA);
                }
                updateParam.add(updatedVal);
            }
        }
        int len = updateSql.length();
        if (updateSql.lastIndexOf(COMMA) == len - 1) {
            updateSql.deleteCharAt(len - 1);
        }
        for (int i = 0; i < whereVals.length; i++) {
            if (i == 0) {
                updateSql.append(WHERE);
            }
            updateSql.append(whereColumns[i]).append("=?");
            if (i < whereVals.length - 1) {
                updateSql.append(" AND ");
            }
            updateParam.add(whereVals[i]);
        }
    }

    public static void buildInsertSql(String tableName, String[] columns, StringBuilder insertSql) {
        insertSql.append("INSERT INTO ")
                .append(tableName)
                .append("(")
                .append(StringUtils.join(columns, COMMA))
                .append(") VALUES( ");
        for (int i = 0; i < columns.length; i++) {
            insertSql.append("?");
            if (i < columns.length - 1) {
                insertSql.append(COMMA);
            }
        }
        insertSql.append(")");
    }

    public static void buildDeleteSql(String tableName, String[] whereColumns, Object[] whereVals, StringBuilder deleteSql) {
        if (whereColumns == null || whereColumns.length == 0 || whereVals == null || whereVals.length == 0) {
            return;
        }
        deleteSql.append("DELETE FROM ").append(tableName).append(WHERE);
        int whereLength = whereColumns.length;
        int whereValLength = whereVals.length;
        if (whereLength == 1) {
            String whereColumn = whereColumns[0];
            for (int i = 0; i < whereVals.length; i++) {
                deleteSql.append(whereColumn).append(" = ?");
                if (i < whereValLength - 1) {
                    deleteSql.append(" OR ");
                }
            }
        } else {
            for (int i = 0; i < whereLength; i++) {
                String whereColumn = whereColumns[i];
                deleteSql.append(whereColumn).append(" = ?");
                if (i < whereLength - 1) {
                    deleteSql.append(" AND ");
                }
            }
        }
    }

    public static void buildDeleteSqlUsingSubQuery(String tableName, String delWhereColumn, Object[] whereVals,
                                                   String subQueryTableName, String subQueryColumnName,
                                                   String subQueryWhere, StringBuilder deleteSql) {
        if (whereVals == null || whereVals.length == 0) {
            return;
        }
        deleteSql.append("DELETE FROM ").append(tableName).append(WHERE).append(delWhereColumn).append(" IN (");
        // delete from METADATA_PROCES" where metadata_project_id in (select ID from METADATA_PROJEC" where namespace = 'com.sap.gtt.app.tfo')
        deleteSql.append(" SELECT ").append(subQueryColumnName).append(" FROM ").append(subQueryTableName)
                .append(WHERE).append(subQueryWhere).append(" = ?");
        deleteSql.append(")");
    }

    /**
     * Generate table name from entity full name.
     *
     * @param entityFullName entity full name such as com.sap.gtt.app.mim.poitem.POItemModel.POItemProcess
     * @return table name such as com_sap_gtt_app_mim_poitem_POItemModel_POItemProcess
     */
    public static String toTableName(String entityFullName) {
        String regex = "\\.";
        return RegExUtils.replaceAll(entityFullName, regex, UNDERSCORE);
    }

    /**
     * Generate the physical name from entity element name
     *
     * @param elementName entity element name
     * @return physical name for a given entity element name
     */
    public static String toElementPhysicalName(String elementName) {
        return elementName;
    }

    public static DDLBuilder getDDLBuilder(DatabaseType databaseType) {
        if (databaseType == DatabaseType.hana) {
            return SpringContextUtils.getBean(DDLBuilderHanaImpl.class);
        } else if (databaseType == DatabaseType.h2) {
            return SpringContextUtils.getBean(DDLBuilderH2Impl.class);
        } else {
            throw new UnsupportedOperationException(String.format("Database type '%s' not supported", databaseType.name()));
        }
    }

    public static PhysicalName getPhysicalName(String fullEntityModelName, String baseType,
                                               boolean includeCustomizedFields, String... extendedEntityName) {
        PhysicalName physicalName = new PhysicalName();
        physicalName.setName(toTableName(fullEntityModelName));
        if (StringUtils.isNotBlank(baseType)) {
            EntityBaseType entityBaseType = EnumUtils.getEnumTypeByValue(EntityBaseType.class, baseType);
            if (EntityBaseType.EVENT.equals(entityBaseType) || EntityBaseType.TRACKED_PROCESS.equals(entityBaseType)) {
                CoreModelEntity coreModelEntity = EnumUtils.getEnumTypeByValue(CoreModelEntity.class, entityBaseType.getValue());
                if (coreModelEntity != null) {
                    physicalName.setCorePhysicalName(DBUtils.toTableName(coreModelEntity.getFullName()));
                }
            }
        } else {
            if (CsnParser.isCoreModelEntity(fullEntityModelName)) {
                physicalName.setCorePhysicalName(physicalName.getName());
            }
        }
        if (!includeCustomizedFields) {
            physicalName.setName(physicalName.getCorePhysicalName());
        }
        if (extendedEntityName != null && extendedEntityName.length == 1) {
            physicalName.setExtendedPhysicalName(toTableName(extendedEntityName[0]));
        }
        return physicalName;
    }

}
