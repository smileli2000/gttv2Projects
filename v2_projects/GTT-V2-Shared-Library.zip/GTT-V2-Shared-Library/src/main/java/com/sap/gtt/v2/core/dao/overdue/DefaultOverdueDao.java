package com.sap.gtt.v2.core.dao.overdue;

import com.sap.gtt.v2.core.domain.metadata.MetadataConstants;
import com.sap.gtt.v2.core.domain.metadata.MetadataConstants.CoreModelEntity;
import com.sap.gtt.v2.core.domain.metadata.MetadataConstants.MetadataTable;
import com.sap.gtt.v2.core.entity.trackedprocess.PlannedEvent;
import com.sap.gtt.v2.core.management.overdue.IOverdueManagement;
import com.sap.gtt.v2.util.DBUtils;
import com.sap.gtt.v2.util.SpringContextUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Repository(DefaultOverdueDao.BEAN_NAME)
public class DefaultOverdueDao implements IOverdueDao {
    public static final String BEAN_NAME = "com.sap.gtt.v2.core.dao.overdue.DefaultOverdueDao";

    @Autowired
    private JdbcTemplate jdbcTemplate;
    private static final String EVENT_STATUS_PLANNED = "PLANNED";
    private static final String EVENT_STATUS_OVERDUE = "OVERDUE";
    private static final String JOB_NAME = "JOB_NAME";
    private static final String PREVIOUS_DETECTION_TIME = "PREVIOUS_DETECTION_TIME";
    private static final String PLANNEDEVENTUUID = "PLANNEDEVENTUUID";
    private static final String ALTKEY = "ALTKEY";
    private static final String OVERDUE_JOB_INFO_TABLE_NAME = "OVERDUE_JOB_INFO";
    private static final String SUBACCOUNTID = "SUBACCOUNTID";
    private static final String CLONEINSTANCEID = "CLONEINSTANCEID";
    private static final String TRACKEDPROCESSTYPE = "TRACKEDPROCESSTYPE";
    private static final String PARTYID = "PARTYID";
    private static final String INNER_JOIN = "INNER JOIN ";

    public static DefaultOverdueDao getInstance() {
        return (DefaultOverdueDao) SpringContextUtils.getBean(BEAN_NAME);
    }

    @Override
    public Instant getPreviousDetectionTime(String jobName) {
        String sql = new StringBuilder()
                .append("SELECT PREVIOUS_DETECTION_TIME \n")
                .append("FROM  OVERDUE_JOB_INFO \n")
                .append("WHERE JOB_NAME = ? \n")
                .toString();
        SqlRowSet result = jdbcTemplate.queryForRowSet(sql, jobName);
        if (result.next()) {
            Timestamp previousTime = result.getTimestamp(PREVIOUS_DETECTION_TIME);
            return previousTime.toInstant();
        }
        return Instant.EPOCH;
    }

    @Override
    public int countOverduePlannedEvent(Instant from, Instant to) {
        String sql = new StringBuilder()
                .append("SELECT COUNT(1) AS NUM \n")
                .append(getOverduePlannedEventSQL())
                .toString();
        SqlRowSet result = jdbcTemplate.queryForRowSet(sql, from, to);
        if (result.next()) {
            return result.getInt("NUM");
        }
        return 0;
    }

    private String getOverduePlannedEventSQL() {
        String trackedProcessCoreTableName = DBUtils.toTableName(CoreModelEntity.TRACKED_PROCESS.getFullName());
        String plannedEventCoreTableName = DBUtils.toTableName(CoreModelEntity.PLANNED_EVENT.getFullName());
        return new StringBuilder()
                .append("FROM ").append(trackedProcessCoreTableName).append(" T1 \n")
                .append(INNER_JOIN).append(plannedEventCoreTableName).append(" T3 ON T1.").append(MetadataConstants.ID).append(" = T3.").append(MetadataConstants.PROCESS_ID).append(" \n")
                .append(INNER_JOIN).append(MetadataTable.METADATA_PROCESS).append(" T5 ON ( T5.").append(MetadataConstants.TRACKED_PROCESS_TYPE).append(" = T1.").append(MetadataConstants.TRACKEDPROCESSTYPE).append(")\n")
                .append(INNER_JOIN).append(MetadataTable.METADATA_PROJECT).append(" T6 ON (T5.").append(MetadataConstants.METADATA_PROJECT_ID).append(" = T6.").append(MetadataConstants.ID).append(")\n")
                .append("WHERE T3.").append(MetadataConstants.NEXT_OVERDUE_DETECTION).append(" >= ? \n")
                .append("AND T3.").append(MetadataConstants.NEXT_OVERDUE_DETECTION).append(" < ? \n")
                .append("AND T6.").append(MetadataConstants.STATUS).append(" = '").append(MetadataConstants.MetadataProjectStatus.ACTIVE.name()).append("' \n")
                .append("AND ((T3.").append(MetadataConstants.EVENTSTATUS_CODE).append(" = '").append(EVENT_STATUS_PLANNED)
                .append("' AND T3.").append(PlannedEvent.LAST_PROCESS_EVENT_DIRECTORY_ID).append(" is null ")
                .append(") OR T3.").append(MetadataConstants.EVENTSTATUS_CODE).append(" = '").append(EVENT_STATUS_OVERDUE)
                .append("') \n")
                .toString();
    }

    @Override
    public List<IOverdueManagement.PlannedEventIdentifier> getOverduePlannedEventsInfo(Instant from, Instant to, int skip, int top) {
        String sql = new StringBuilder()
                .append("SELECT T1.").append(MetadataConstants.SUB_ACCOUNT_ID).append(",")
                .append("T1.").append(MetadataConstants.CLONE_INSTANCE_ID).append(",")
                .append("T3.").append(MetadataConstants.ID).append(" AS PLANNEDEVENTUUID,")
                .append("T1.").append(MetadataConstants.ALT_KEY).append(",")
                .append("T1.").append(MetadataConstants.TRACKEDPROCESSTYPE).append(",")
                .append("T1.").append(MetadataConstants.PARTY_ID).append(",")
                .append("T6.").append(MetadataConstants.NAMESPACE)
                .append("\n")
                .append(getOverduePlannedEventSQL())
                .append("ORDER BY T3.ID \n") // why need sort? -> ensure the sequence each time fetch the data from db
                .append("LIMIT ? OFFSET ? \n")
                .toString();

        List<Map<String, Object>> mapList = jdbcTemplate.queryForList(sql, from, to, top, skip);
        List<IOverdueManagement.PlannedEventIdentifier> overdues = new ArrayList<>();
        mapList.forEach(obj -> {
            UUID plannedEventUUID = null;
            UUID subaccountId = null;
            UUID cloneServiceInstanceId = null;
            String plannedEventStr = DBUtils.toStringValue(obj.get(PLANNEDEVENTUUID));
            if (plannedEventStr != null && !plannedEventStr.isEmpty()) {
                plannedEventUUID = UUID.fromString(plannedEventStr);
            }
            String subAccountIdStr = DBUtils.toStringValue(obj.get(SUBACCOUNTID));
            if (subAccountIdStr != null && !subAccountIdStr.isEmpty()) {
                subaccountId = UUID.fromString(subAccountIdStr);
            }
            String cloneInstanceIdStr = DBUtils.toStringValue(obj.get(CLONEINSTANCEID));
            if (cloneInstanceIdStr != null && cloneInstanceIdStr.isEmpty()) {
                cloneServiceInstanceId = UUID.fromString(cloneInstanceIdStr);
            }
            IOverdueManagement.PlannedEventIdentifier plannedEventIdentifier =
                    new IOverdueManagement.PlannedEventIdentifier(
                            plannedEventUUID, DBUtils.toStringValue(obj.get(ALTKEY)),
                            subaccountId,
                            cloneServiceInstanceId,
                            DBUtils.toStringValue(obj.get(TRACKEDPROCESSTYPE)),
                            DBUtils.toStringValue(obj.get(MetadataConstants.NAMESPACE)),
                            DBUtils.toStringValue(obj.get(PARTYID)));
            overdues.add(plannedEventIdentifier);
        });

        return overdues;
    }


    @Override
    public void updateOverdueInfo(String jobName, Instant jobRunTime) {
        java.sql.Timestamp jobRunTimeTimestamp = java.sql.Timestamp.from(jobRunTime);
        String sql = "";
        Instant previousDetectionTime = getPreviousDetectionTime(jobName);
        if (previousDetectionTime == null || previousDetectionTime.equals(Instant.EPOCH)) {
            sql = new StringBuilder("")
                    .append("INSERT INTO OVERDUE_JOB_INFO (PREVIOUS_DETECTION_TIME,JOB_NAME) \n")
                    .append(" VALUES(?,?) \n")
                    .toString();
        } else {
            sql = new StringBuilder("")
                    .append("UPDATE ").append(OVERDUE_JOB_INFO_TABLE_NAME).append(" \n")
                    .append("SET ").append(PREVIOUS_DETECTION_TIME).append(" = ? \n")
                    .append("WHERE ").append(JOB_NAME).append(" = ? \n").toString();
        }
        if (sql != null && !sql.isEmpty()) {
            jdbcTemplate.update(sql, new PreparedStatementSetter() {
                public void setValues(PreparedStatement ps) throws SQLException {
                    ps.setTimestamp(1, jobRunTimeTimestamp);
                    ps.setString(2, jobName);
                }
            });
        }

    }
}