package com.sap.gtt.v2.core.rule.impl;

import java.io.PrintStream;
import java.util.concurrent.Future;

import com.sap.gtt.v2.configuration.AccessContextHolder;
import com.sap.gtt.v2.core.entity.trackedprocess.Event;
import com.sap.gtt.v2.core.entity.trackedprocess.PlannedEvent;
import com.sap.gtt.v2.core.entity.trackedprocess.TrackedProcess;
import org.antlr.v4.runtime.CharStream;
import org.antlr.v4.runtime.CharStreams;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.atn.PredictionMode;
import org.antlr.v4.runtime.tree.ParseTree;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Component;

import com.sap.gtt.v2.core.rule.GTTEmbededRuleScriptLexer;
import com.sap.gtt.v2.core.rule.GTTEmbededRuleScriptParser;
import com.sap.gtt.v2.core.runtime.model.NullValue;
import com.sap.gtt.v2.core.service.reminder.IReminderService;
import com.sap.gtt.v2.core.service.reminder.ReminderServiceImpl;
import com.sap.gtt.v2.log.TenantAwareLogService;
import com.sap.gtt.v2.util.SpringContextUtils;

@Component
public class GTTEmbededRuleScriptLauncher {
    public static final String EXEC_TIME_OUT = "Script execution time out";
    public static final int TIME_OUT = 30000;
    public static final String ASYNC_EXEC_RES = "Script executed";

    @Autowired
    private TenantAwareLogService logService;

    public static class ParseResult {
        private CommonTokenStream tokens;
        private ParseTree tree;

        private ParseResult(CommonTokenStream tokens, ParseTree tree) {
            super();
            this.tokens = tokens;
            this.tree = tree;
        }

        public CommonTokenStream getTokens() {
            return tokens;
        }

        public ParseTree getTree() {
            return tree;
        }

    }

    public ParseResult parse(String script) {
        CharStream input = CharStreams.fromString(script);
        GTTEmbededRuleScriptLexer lexer = new GTTEmbededRuleScriptLexer(input);

        CommonTokenStream tokens = new CommonTokenStream(lexer);
        GTTEmbededRuleScriptErrorListener errorListener = new GTTEmbededRuleScriptErrorListener();
        GTTEmbededRuleScriptParser parser = new GTTEmbededRuleScriptParser(tokens);
        parser.addErrorListener(errorListener);

        // stop guessing and throw error when lex error using PredictionMode.SLL mode
        // it is the fatest mode.
        parser.getInterpreter().setPredictionMode(PredictionMode.SLL);

        ParseTree tree = parser.script();
        // begin parsing at init rule
        logService.debug(tree.toStringTree(parser));

        if (errorListener.containsError()) {
            throw errorListener.getMultiExceptionContainer();
        }

        return new ParseResult(tokens, tree);

    }
    

    @Async(value = "Event2ActionExecutor")
    public Future<String> execute(String script, PrintStream printStream,
                                  TrackedProcess oldTrackedProcess, TrackedProcess trackedProcess, PlannedEvent oldPlannedEvent, PlannedEvent plannedEvent, Event actualEvent
                                  ,AccessContextHolder.AccessContext accessContext) {
        AccessContextHolder.set(accessContext);
        try{
            SpringContextUtils.supportAsynCorrespondingIdInLogs();
            
            ParseResult parseResult = this.parse(script);
            GTTEmbededRuleScriptVisitorImpl visitor = new GTTEmbededRuleScriptVisitorImpl(parseResult.tokens, printStream);
            visitor.setSystemVariable(GTTEmbededRuleScriptConsts.SYSTEM_VAR_TRACKED_PROCESS_BEFORE_EVENT_POST, oldTrackedProcess == null ? NullValue.NULL : oldTrackedProcess);
            visitor.setSystemVariable(GTTEmbededRuleScriptConsts.SYSTEM_VAR_PLANNED_EVENT_BEFORE_EVENT_POST, oldPlannedEvent == null ? NullValue.NULL : oldPlannedEvent);
            visitor.setSystemVariable(GTTEmbededRuleScriptConsts.SYSTEM_VAR_TRACKED_PROCESS, trackedProcess == null ? NullValue.NULL : trackedProcess);
            visitor.setSystemVariable(GTTEmbededRuleScriptConsts.SYSTEM_VAR_ACTUAL_EVENT, actualEvent == null ? NullValue.NULL : actualEvent);
            visitor.setSystemVariable(GTTEmbededRuleScriptConsts.SYSTEM_VAR_PLANNED_EVENT, plannedEvent == null ? NullValue.NULL : plannedEvent);
            
            IReminderService reminderService = (IReminderService)SpringContextUtils.getBean(IReminderService.class);
        	visitor.setSystemVariable(GTTEmbededRuleScriptConsts.SYSTEM_VAR_REMINDER_SERVICE, reminderService == null ? NullValue.NULL : (ReminderServiceImpl)reminderService);
        
            visitor.visit(parseResult.tree);
        }
        finally {
            AccessContextHolder.clear();
        }
        return new AsyncResult<>(ASYNC_EXEC_RES);
    }

}
