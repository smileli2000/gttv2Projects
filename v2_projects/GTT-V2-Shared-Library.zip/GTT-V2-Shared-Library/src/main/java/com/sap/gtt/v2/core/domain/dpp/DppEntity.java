package com.sap.gtt.v2.core.domain.dpp;

import java.util.ArrayList;
import java.util.List;

public class DppEntity {
    private String name;
    private String phsicalName;
    private DppProperty dataSubjectIdProperty;
    private Boolean event;
    //There is no SPI & PII properties
    private List<DppProperty> specialdataSubjectIdProperties;
    private List<DppProperty> spiProperties;
    private List<DppProperty> piiProperties;
    private List<DppProperty> keyProperties;
    private List<DppProperty> otherProperties;

    public void setKeyProperties(List<DppProperty> keyProperties) {
        this.keyProperties = keyProperties;
    }

    public List<DppProperty> getKeyProperties() {
        return keyProperties;
    }

    public String getName() {
        return name;
    }

    public String getPhsicalName() {
        return phsicalName;
    }

    public Boolean isEvent() {
        return event;
    }

    public DppProperty getDataSubjectIdProperty() {
        return dataSubjectIdProperty;
    }

    public List<DppProperty> getSpecialdataSubjectIdProperties() {
        if (specialdataSubjectIdProperties == null) {
            specialdataSubjectIdProperties = new ArrayList<>();
        }
        return specialdataSubjectIdProperties;
    }

    public List<DppProperty> getSpiProperties() {
        if (spiProperties == null) {
            spiProperties = new ArrayList<>();
        }
        return spiProperties;
    }

    public List<DppProperty> getPiiProperties() {
        if (piiProperties == null) {
            piiProperties = new ArrayList<>();
        }
        return piiProperties;
    }

    public List<DppProperty> getOtherProperties() {
        if (otherProperties == null) {
            otherProperties = new ArrayList<>();
        }
        return otherProperties;
    }
    
    public void setName(String name) {
        this.name = name;
    }

    public void setPhsicalName(String phsicalName) {
        this.phsicalName = phsicalName;
    }

    public void setEvent(Boolean isEvent) {
        this.event = isEvent;
    }

    public void setDataSubjectIdProperty(DppProperty dataSubjectIdProperty) {
        this.dataSubjectIdProperty = dataSubjectIdProperty;
    }

    public void setSpecialdataSubjectIdProperties(List<DppProperty> specialdataSubjectIdProperties) {
        this.specialdataSubjectIdProperties = specialdataSubjectIdProperties;
    }

    public void setSpiProperties(List<DppProperty> spiProperties) {
        this.spiProperties = spiProperties;
    }

    public void setPiiProperties(List<DppProperty> piiProperties) {
        this.piiProperties = piiProperties;
    }

    public void setOtherProperties(List<DppProperty> otherProperties) {
        this.otherProperties = otherProperties;
    }

    @Override
    public String toString() {
        return "DppEntity{" +
                "name='" + name + '\'' +
                ", phsicalName='" + phsicalName + '\'' +
                ", dataSubjectIdProperty=" + dataSubjectIdProperty +
                ", specialdataSubjectIdProperties=" + specialdataSubjectIdProperties +
                ", spiProperties=" + spiProperties +
                ", piiProperties=" + piiProperties +
                ", keyProperties=" + keyProperties +
                ", otherProperties=" + otherProperties +
                '}';
    }
}
