package com.sap.gtt.v2.core.dao.metadata;

import com.sap.gtt.v2.core.domain.metadata.MetadataEntityElement;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * DDL builder for H2 database
 *
 * @author I321712
 */
@Component
public class DDLBuilderH2Impl extends AbstractDefaultDDLBuilder {
    @Override
    public String buildCreateTable(String entityName, List<MetadataEntityElement> elements) {
        return buildCreateTableSQL(entityName, elements, false, true);
    }
}