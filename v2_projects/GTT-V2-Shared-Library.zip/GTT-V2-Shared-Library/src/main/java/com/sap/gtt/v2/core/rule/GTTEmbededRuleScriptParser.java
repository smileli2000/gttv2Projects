// Generated from GTTEmbededRuleScript.g4 by ANTLR 4.7.2
package com.sap.gtt.v2.core.rule;
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public class GTTEmbededRuleScriptParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.7.2", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		T__0=1, T__1=2, T__2=3, T__3=4, T__4=5, T__5=6, T__6=7, T__7=8, T__8=9, 
		T__9=10, T__10=11, T__11=12, T__12=13, T__13=14, T__14=15, T__15=16, T__16=17, 
		T__17=18, T__18=19, T__19=20, T__20=21, KEYWORD_IF=22, KEYWORD_ELSE=23, 
		KEYWORD_RETURN=24, KEYWORD_VAR=25, KEYWORD_WHILE=26, NULL_LITERAL=27, 
		INTEGER_LITERAL=28, DECIMAL_LITERAL=29, BOOLEAN_LITERAL=30, STRING_LITERAL=31, 
		IDENTIFIER=32, END_MARK=33, BLOCK_START=34, BLOCK_END=35, DOT=36, WS=37, 
		COMMENT=38, LINE_COMMENT=39;
	public static final int
		RULE_script = 0, RULE_operationStatement = 1, RULE_declaration = 2, RULE_printStatement = 3, 
		RULE_ifStatement = 4, RULE_elseIfStatement = 5, RULE_elseStatement = 6, 
		RULE_whileStatement = 7, RULE_returnStatement = 8, RULE_executionBlock = 9, 
		RULE_refer = 10, RULE_qualifiedName = 11, RULE_functionCall = 12, RULE_assignStatement = 13, 
		RULE_expr = 14, RULE_atom = 15;
	private static String[] makeRuleNames() {
		return new String[] {
			"script", "operationStatement", "declaration", "printStatement", "ifStatement", 
			"elseIfStatement", "elseStatement", "whileStatement", "returnStatement", 
			"executionBlock", "refer", "qualifiedName", "functionCall", "assignStatement", 
			"expr", "atom"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, "'='", "'?'", "'('", "')'", "'['", "']'", "','", "'^'", "'-'", 
			"'+'", "'*'", "'/'", "'!'", "'>'", "'>='", "'<'", "'<='", "'=='", "'!='", 
			"'&&'", "'||'", "'if'", "'else'", "'return'", "'var'", "'while'", null, 
			null, null, null, null, null, "';'", "'{'", "'}'", "'.'"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, "KEYWORD_IF", 
			"KEYWORD_ELSE", "KEYWORD_RETURN", "KEYWORD_VAR", "KEYWORD_WHILE", "NULL_LITERAL", 
			"INTEGER_LITERAL", "DECIMAL_LITERAL", "BOOLEAN_LITERAL", "STRING_LITERAL", 
			"IDENTIFIER", "END_MARK", "BLOCK_START", "BLOCK_END", "DOT", "WS", "COMMENT", 
			"LINE_COMMENT"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "GTTEmbededRuleScript.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public GTTEmbededRuleScriptParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	public static class ScriptContext extends ParserRuleContext {
		public TerminalNode EOF() { return getToken(GTTEmbededRuleScriptParser.EOF, 0); }
		public List<OperationStatementContext> operationStatement() {
			return getRuleContexts(OperationStatementContext.class);
		}
		public OperationStatementContext operationStatement(int i) {
			return getRuleContext(OperationStatementContext.class,i);
		}
		public ScriptContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_script; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).enterScript(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).exitScript(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GTTEmbededRuleScriptVisitor ) return ((GTTEmbededRuleScriptVisitor<? extends T>)visitor).visitScript(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ScriptContext script() throws RecognitionException {
		ScriptContext _localctx = new ScriptContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_script);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(33); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(32);
				operationStatement();
				}
				}
				setState(35); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( (((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__1) | (1L << KEYWORD_IF) | (1L << KEYWORD_RETURN) | (1L << KEYWORD_VAR) | (1L << KEYWORD_WHILE) | (1L << IDENTIFIER))) != 0) );
			setState(37);
			match(EOF);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class OperationStatementContext extends ParserRuleContext {
		public DeclarationContext declaration() {
			return getRuleContext(DeclarationContext.class,0);
		}
		public TerminalNode END_MARK() { return getToken(GTTEmbededRuleScriptParser.END_MARK, 0); }
		public IfStatementContext ifStatement() {
			return getRuleContext(IfStatementContext.class,0);
		}
		public WhileStatementContext whileStatement() {
			return getRuleContext(WhileStatementContext.class,0);
		}
		public PrintStatementContext printStatement() {
			return getRuleContext(PrintStatementContext.class,0);
		}
		public FunctionCallContext functionCall() {
			return getRuleContext(FunctionCallContext.class,0);
		}
		public AssignStatementContext assignStatement() {
			return getRuleContext(AssignStatementContext.class,0);
		}
		public ReturnStatementContext returnStatement() {
			return getRuleContext(ReturnStatementContext.class,0);
		}
		public OperationStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_operationStatement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).enterOperationStatement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).exitOperationStatement(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GTTEmbededRuleScriptVisitor ) return ((GTTEmbededRuleScriptVisitor<? extends T>)visitor).visitOperationStatement(this);
			else return visitor.visitChildren(this);
		}
	}

	public final OperationStatementContext operationStatement() throws RecognitionException {
		OperationStatementContext _localctx = new OperationStatementContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_operationStatement);
		int _la;
		try {
			setState(62);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,3,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(39);
				declaration();
				setState(40);
				match(END_MARK);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(42);
				ifStatement();
				setState(44);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==END_MARK) {
					{
					setState(43);
					match(END_MARK);
					}
				}

				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(46);
				whileStatement();
				setState(48);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==END_MARK) {
					{
					setState(47);
					match(END_MARK);
					}
				}

				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(50);
				printStatement();
				setState(51);
				match(END_MARK);
				}
				break;
			case 5:
				enterOuterAlt(_localctx, 5);
				{
				setState(53);
				functionCall();
				setState(54);
				match(END_MARK);
				}
				break;
			case 6:
				enterOuterAlt(_localctx, 6);
				{
				setState(56);
				assignStatement();
				setState(57);
				match(END_MARK);
				}
				break;
			case 7:
				enterOuterAlt(_localctx, 7);
				{
				setState(59);
				returnStatement();
				setState(60);
				match(END_MARK);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class DeclarationContext extends ParserRuleContext {
		public TerminalNode KEYWORD_VAR() { return getToken(GTTEmbededRuleScriptParser.KEYWORD_VAR, 0); }
		public TerminalNode IDENTIFIER() { return getToken(GTTEmbededRuleScriptParser.IDENTIFIER, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public DeclarationContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_declaration; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).enterDeclaration(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).exitDeclaration(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GTTEmbededRuleScriptVisitor ) return ((GTTEmbededRuleScriptVisitor<? extends T>)visitor).visitDeclaration(this);
			else return visitor.visitChildren(this);
		}
	}

	public final DeclarationContext declaration() throws RecognitionException {
		DeclarationContext _localctx = new DeclarationContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_declaration);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(64);
			match(KEYWORD_VAR);
			setState(65);
			match(IDENTIFIER);
			setState(68);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==T__0) {
				{
				setState(66);
				match(T__0);
				setState(67);
				expr(0);
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class PrintStatementContext extends ParserRuleContext {
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public PrintStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_printStatement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).enterPrintStatement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).exitPrintStatement(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GTTEmbededRuleScriptVisitor ) return ((GTTEmbededRuleScriptVisitor<? extends T>)visitor).visitPrintStatement(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PrintStatementContext printStatement() throws RecognitionException {
		PrintStatementContext _localctx = new PrintStatementContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_printStatement);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(70);
			match(T__1);
			setState(71);
			expr(0);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class IfStatementContext extends ParserRuleContext {
		public TerminalNode KEYWORD_IF() { return getToken(GTTEmbededRuleScriptParser.KEYWORD_IF, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public TerminalNode BLOCK_START() { return getToken(GTTEmbededRuleScriptParser.BLOCK_START, 0); }
		public ExecutionBlockContext executionBlock() {
			return getRuleContext(ExecutionBlockContext.class,0);
		}
		public TerminalNode BLOCK_END() { return getToken(GTTEmbededRuleScriptParser.BLOCK_END, 0); }
		public List<ElseIfStatementContext> elseIfStatement() {
			return getRuleContexts(ElseIfStatementContext.class);
		}
		public ElseIfStatementContext elseIfStatement(int i) {
			return getRuleContext(ElseIfStatementContext.class,i);
		}
		public ElseStatementContext elseStatement() {
			return getRuleContext(ElseStatementContext.class,0);
		}
		public IfStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_ifStatement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).enterIfStatement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).exitIfStatement(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GTTEmbededRuleScriptVisitor ) return ((GTTEmbededRuleScriptVisitor<? extends T>)visitor).visitIfStatement(this);
			else return visitor.visitChildren(this);
		}
	}

	public final IfStatementContext ifStatement() throws RecognitionException {
		IfStatementContext _localctx = new IfStatementContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_ifStatement);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(73);
			match(KEYWORD_IF);
			setState(74);
			match(T__2);
			setState(75);
			expr(0);
			setState(76);
			match(T__3);
			setState(77);
			match(BLOCK_START);
			setState(78);
			executionBlock(null);
			setState(79);
			match(BLOCK_END);
			setState(83);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,5,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(80);
					elseIfStatement();
					}
					} 
				}
				setState(85);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,5,_ctx);
			}
			setState(87);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==KEYWORD_ELSE) {
				{
				setState(86);
				elseStatement();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ElseIfStatementContext extends ParserRuleContext {
		public TerminalNode KEYWORD_ELSE() { return getToken(GTTEmbededRuleScriptParser.KEYWORD_ELSE, 0); }
		public TerminalNode KEYWORD_IF() { return getToken(GTTEmbededRuleScriptParser.KEYWORD_IF, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public TerminalNode BLOCK_START() { return getToken(GTTEmbededRuleScriptParser.BLOCK_START, 0); }
		public ExecutionBlockContext executionBlock() {
			return getRuleContext(ExecutionBlockContext.class,0);
		}
		public TerminalNode BLOCK_END() { return getToken(GTTEmbededRuleScriptParser.BLOCK_END, 0); }
		public ElseIfStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_elseIfStatement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).enterElseIfStatement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).exitElseIfStatement(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GTTEmbededRuleScriptVisitor ) return ((GTTEmbededRuleScriptVisitor<? extends T>)visitor).visitElseIfStatement(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ElseIfStatementContext elseIfStatement() throws RecognitionException {
		ElseIfStatementContext _localctx = new ElseIfStatementContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_elseIfStatement);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(89);
			match(KEYWORD_ELSE);
			setState(90);
			match(KEYWORD_IF);
			setState(91);
			match(T__2);
			setState(92);
			expr(0);
			setState(93);
			match(T__3);
			setState(94);
			match(BLOCK_START);
			setState(95);
			executionBlock(null);
			setState(96);
			match(BLOCK_END);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ElseStatementContext extends ParserRuleContext {
		public TerminalNode KEYWORD_ELSE() { return getToken(GTTEmbededRuleScriptParser.KEYWORD_ELSE, 0); }
		public TerminalNode BLOCK_START() { return getToken(GTTEmbededRuleScriptParser.BLOCK_START, 0); }
		public ExecutionBlockContext executionBlock() {
			return getRuleContext(ExecutionBlockContext.class,0);
		}
		public TerminalNode BLOCK_END() { return getToken(GTTEmbededRuleScriptParser.BLOCK_END, 0); }
		public ElseStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_elseStatement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).enterElseStatement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).exitElseStatement(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GTTEmbededRuleScriptVisitor ) return ((GTTEmbededRuleScriptVisitor<? extends T>)visitor).visitElseStatement(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ElseStatementContext elseStatement() throws RecognitionException {
		ElseStatementContext _localctx = new ElseStatementContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_elseStatement);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(98);
			match(KEYWORD_ELSE);
			setState(99);
			match(BLOCK_START);
			setState(100);
			executionBlock(null);
			setState(101);
			match(BLOCK_END);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class WhileStatementContext extends ParserRuleContext {
		public TerminalNode KEYWORD_WHILE() { return getToken(GTTEmbededRuleScriptParser.KEYWORD_WHILE, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public TerminalNode BLOCK_START() { return getToken(GTTEmbededRuleScriptParser.BLOCK_START, 0); }
		public ExecutionBlockContext executionBlock() {
			return getRuleContext(ExecutionBlockContext.class,0);
		}
		public TerminalNode BLOCK_END() { return getToken(GTTEmbededRuleScriptParser.BLOCK_END, 0); }
		public WhileStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_whileStatement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).enterWhileStatement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).exitWhileStatement(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GTTEmbededRuleScriptVisitor ) return ((GTTEmbededRuleScriptVisitor<? extends T>)visitor).visitWhileStatement(this);
			else return visitor.visitChildren(this);
		}
	}

	public final WhileStatementContext whileStatement() throws RecognitionException {
		WhileStatementContext _localctx = new WhileStatementContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_whileStatement);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(103);
			match(KEYWORD_WHILE);
			setState(104);
			match(T__2);
			setState(105);
			expr(0);
			setState(106);
			match(T__3);
			setState(107);
			match(BLOCK_START);
			setState(108);
			executionBlock(null);
			setState(109);
			match(BLOCK_END);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ReturnStatementContext extends ParserRuleContext {
		public TerminalNode KEYWORD_RETURN() { return getToken(GTTEmbededRuleScriptParser.KEYWORD_RETURN, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public ReturnStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_returnStatement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).enterReturnStatement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).exitReturnStatement(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GTTEmbededRuleScriptVisitor ) return ((GTTEmbededRuleScriptVisitor<? extends T>)visitor).visitReturnStatement(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ReturnStatementContext returnStatement() throws RecognitionException {
		ReturnStatementContext _localctx = new ReturnStatementContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_returnStatement);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(111);
			match(KEYWORD_RETURN);
			setState(113);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__2) | (1L << T__4) | (1L << T__8) | (1L << T__9) | (1L << T__12) | (1L << NULL_LITERAL) | (1L << INTEGER_LITERAL) | (1L << DECIMAL_LITERAL) | (1L << BOOLEAN_LITERAL) | (1L << STRING_LITERAL) | (1L << IDENTIFIER))) != 0)) {
				{
				setState(112);
				expr(0);
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ExecutionBlockContext extends ParserRuleContext {
		public String blockName;
		public List<OperationStatementContext> operationStatement() {
			return getRuleContexts(OperationStatementContext.class);
		}
		public OperationStatementContext operationStatement(int i) {
			return getRuleContext(OperationStatementContext.class,i);
		}
		public ReturnStatementContext returnStatement() {
			return getRuleContext(ReturnStatementContext.class,0);
		}
		public TerminalNode END_MARK() { return getToken(GTTEmbededRuleScriptParser.END_MARK, 0); }
		public ExecutionBlockContext(ParserRuleContext parent, int invokingState) { super(parent, invokingState); }
		public ExecutionBlockContext(ParserRuleContext parent, int invokingState, String blockName) {
			super(parent, invokingState);
			this.blockName = blockName;
		}
		@Override public int getRuleIndex() { return RULE_executionBlock; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).enterExecutionBlock(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).exitExecutionBlock(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GTTEmbededRuleScriptVisitor ) return ((GTTEmbededRuleScriptVisitor<? extends T>)visitor).visitExecutionBlock(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ExecutionBlockContext executionBlock(String blockName) throws RecognitionException {
		ExecutionBlockContext _localctx = new ExecutionBlockContext(_ctx, getState(), blockName);
		enterRule(_localctx, 18, RULE_executionBlock);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(118);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,8,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(115);
					operationStatement();
					}
					} 
				}
				setState(120);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,8,_ctx);
			}
			setState(124);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==KEYWORD_RETURN) {
				{
				setState(121);
				returnStatement();
				setState(122);
				match(END_MARK);
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ReferContext extends ParserRuleContext {
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public TerminalNode DOT() { return getToken(GTTEmbededRuleScriptParser.DOT, 0); }
		public TerminalNode IDENTIFIER() { return getToken(GTTEmbededRuleScriptParser.IDENTIFIER, 0); }
		public ReferContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_refer; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).enterRefer(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).exitRefer(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GTTEmbededRuleScriptVisitor ) return ((GTTEmbededRuleScriptVisitor<? extends T>)visitor).visitRefer(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ReferContext refer() throws RecognitionException {
		ReferContext _localctx = new ReferContext(_ctx, getState());
		enterRule(_localctx, 20, RULE_refer);
		try {
			setState(132);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case T__4:
				enterOuterAlt(_localctx, 1);
				{
				{
				setState(126);
				match(T__4);
				setState(127);
				expr(0);
				setState(128);
				match(T__5);
				}
				}
				break;
			case DOT:
				enterOuterAlt(_localctx, 2);
				{
				{
				setState(130);
				match(DOT);
				setState(131);
				match(IDENTIFIER);
				}
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class QualifiedNameContext extends ParserRuleContext {
		public TerminalNode IDENTIFIER() { return getToken(GTTEmbededRuleScriptParser.IDENTIFIER, 0); }
		public List<ReferContext> refer() {
			return getRuleContexts(ReferContext.class);
		}
		public ReferContext refer(int i) {
			return getRuleContext(ReferContext.class,i);
		}
		public QualifiedNameContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_qualifiedName; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).enterQualifiedName(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).exitQualifiedName(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GTTEmbededRuleScriptVisitor ) return ((GTTEmbededRuleScriptVisitor<? extends T>)visitor).visitQualifiedName(this);
			else return visitor.visitChildren(this);
		}
	}

	public final QualifiedNameContext qualifiedName() throws RecognitionException {
		QualifiedNameContext _localctx = new QualifiedNameContext(_ctx, getState());
		enterRule(_localctx, 22, RULE_qualifiedName);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(134);
			match(IDENTIFIER);
			setState(138);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,11,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(135);
					refer();
					}
					} 
				}
				setState(140);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,11,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class FunctionCallContext extends ParserRuleContext {
		public TerminalNode IDENTIFIER() { return getToken(GTTEmbededRuleScriptParser.IDENTIFIER, 0); }
		public QualifiedNameContext qualifiedName() {
			return getRuleContext(QualifiedNameContext.class,0);
		}
		public TerminalNode DOT() { return getToken(GTTEmbededRuleScriptParser.DOT, 0); }
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public FunctionCallContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_functionCall; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).enterFunctionCall(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).exitFunctionCall(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GTTEmbededRuleScriptVisitor ) return ((GTTEmbededRuleScriptVisitor<? extends T>)visitor).visitFunctionCall(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FunctionCallContext functionCall() throws RecognitionException {
		FunctionCallContext _localctx = new FunctionCallContext(_ctx, getState());
		enterRule(_localctx, 24, RULE_functionCall);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(144);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,12,_ctx) ) {
			case 1:
				{
				setState(141);
				qualifiedName();
				setState(142);
				match(DOT);
				}
				break;
			}
			setState(146);
			match(IDENTIFIER);
			setState(147);
			match(T__2);
			setState(156);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__2) | (1L << T__4) | (1L << T__8) | (1L << T__9) | (1L << T__12) | (1L << NULL_LITERAL) | (1L << INTEGER_LITERAL) | (1L << DECIMAL_LITERAL) | (1L << BOOLEAN_LITERAL) | (1L << STRING_LITERAL) | (1L << IDENTIFIER))) != 0)) {
				{
				setState(148);
				expr(0);
				setState(153);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==T__6) {
					{
					{
					setState(149);
					match(T__6);
					setState(150);
					expr(0);
					}
					}
					setState(155);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				}
			}

			setState(158);
			match(T__3);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AssignStatementContext extends ParserRuleContext {
		public AssignStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_assignStatement; }
	 
		public AssignStatementContext() { }
		public void copyFrom(AssignStatementContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class IdentifierAssignContext extends AssignStatementContext {
		public TerminalNode IDENTIFIER() { return getToken(GTTEmbededRuleScriptParser.IDENTIFIER, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public IdentifierAssignContext(AssignStatementContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).enterIdentifierAssign(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).exitIdentifierAssign(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GTTEmbededRuleScriptVisitor ) return ((GTTEmbededRuleScriptVisitor<? extends T>)visitor).visitIdentifierAssign(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class ReferAssignContext extends AssignStatementContext {
		public QualifiedNameContext qualifiedName() {
			return getRuleContext(QualifiedNameContext.class,0);
		}
		public ReferContext refer() {
			return getRuleContext(ReferContext.class,0);
		}
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public ReferAssignContext(AssignStatementContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).enterReferAssign(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).exitReferAssign(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GTTEmbededRuleScriptVisitor ) return ((GTTEmbededRuleScriptVisitor<? extends T>)visitor).visitReferAssign(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AssignStatementContext assignStatement() throws RecognitionException {
		AssignStatementContext _localctx = new AssignStatementContext(_ctx, getState());
		enterRule(_localctx, 26, RULE_assignStatement);
		try {
			setState(168);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,15,_ctx) ) {
			case 1:
				_localctx = new ReferAssignContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(160);
				qualifiedName();
				setState(161);
				refer();
				setState(162);
				match(T__0);
				setState(163);
				expr(0);
				}
				break;
			case 2:
				_localctx = new IdentifierAssignContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(165);
				match(IDENTIFIER);
				setState(166);
				match(T__0);
				setState(167);
				expr(0);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ExprContext extends ParserRuleContext {
		public ExprContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_expr; }
	 
		public ExprContext() { }
		public void copyFrom(ExprContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class ExprAtomContext extends ExprContext {
		public AtomContext atom() {
			return getRuleContext(AtomContext.class,0);
		}
		public ExprAtomContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).enterExprAtom(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).exitExprAtom(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GTTEmbededRuleScriptVisitor ) return ((GTTEmbededRuleScriptVisitor<? extends T>)visitor).visitExprAtom(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class BoolGeContext extends ExprContext {
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public BoolGeContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).enterBoolGe(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).exitBoolGe(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GTTEmbededRuleScriptVisitor ) return ((GTTEmbededRuleScriptVisitor<? extends T>)visitor).visitBoolGe(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class BoolNotEqContext extends ExprContext {
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public BoolNotEqContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).enterBoolNotEq(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).exitBoolNotEq(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GTTEmbededRuleScriptVisitor ) return ((GTTEmbededRuleScriptVisitor<? extends T>)visitor).visitBoolNotEq(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class BoolOrContext extends ExprContext {
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public BoolOrContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).enterBoolOr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).exitBoolOr(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GTTEmbededRuleScriptVisitor ) return ((GTTEmbededRuleScriptVisitor<? extends T>)visitor).visitBoolOr(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class BoolLeContext extends ExprContext {
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public BoolLeContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).enterBoolLe(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).exitBoolLe(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GTTEmbededRuleScriptVisitor ) return ((GTTEmbededRuleScriptVisitor<? extends T>)visitor).visitBoolLe(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class MathUnitaryContext extends ExprContext {
		public Token op;
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public MathUnitaryContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).enterMathUnitary(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).exitMathUnitary(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GTTEmbededRuleScriptVisitor ) return ((GTTEmbededRuleScriptVisitor<? extends T>)visitor).visitMathUnitary(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class BoolReverseContext extends ExprContext {
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public BoolReverseContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).enterBoolReverse(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).exitBoolReverse(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GTTEmbededRuleScriptVisitor ) return ((GTTEmbededRuleScriptVisitor<? extends T>)visitor).visitBoolReverse(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class MathPowContext extends ExprContext {
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public MathPowContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).enterMathPow(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).exitMathPow(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GTTEmbededRuleScriptVisitor ) return ((GTTEmbededRuleScriptVisitor<? extends T>)visitor).visitMathPow(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class ExprQulifiedNameContext extends ExprContext {
		public QualifiedNameContext qualifiedName() {
			return getRuleContext(QualifiedNameContext.class,0);
		}
		public ExprQulifiedNameContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).enterExprQulifiedName(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).exitExprQulifiedName(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GTTEmbededRuleScriptVisitor ) return ((GTTEmbededRuleScriptVisitor<? extends T>)visitor).visitExprQulifiedName(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class BoolAndContext extends ExprContext {
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public BoolAndContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).enterBoolAnd(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).exitBoolAnd(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GTTEmbededRuleScriptVisitor ) return ((GTTEmbededRuleScriptVisitor<? extends T>)visitor).visitBoolAnd(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class ExprParensContext extends ExprContext {
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public ExprParensContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).enterExprParens(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).exitExprParens(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GTTEmbededRuleScriptVisitor ) return ((GTTEmbededRuleScriptVisitor<? extends T>)visitor).visitExprParens(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class MathAddSubContext extends ExprContext {
		public Token op;
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public MathAddSubContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).enterMathAddSub(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).exitMathAddSub(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GTTEmbededRuleScriptVisitor ) return ((GTTEmbededRuleScriptVisitor<? extends T>)visitor).visitMathAddSub(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class BoolLtContext extends ExprContext {
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public BoolLtContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).enterBoolLt(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).exitBoolLt(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GTTEmbededRuleScriptVisitor ) return ((GTTEmbededRuleScriptVisitor<? extends T>)visitor).visitBoolLt(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class BoolGtContext extends ExprContext {
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public BoolGtContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).enterBoolGt(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).exitBoolGt(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GTTEmbededRuleScriptVisitor ) return ((GTTEmbededRuleScriptVisitor<? extends T>)visitor).visitBoolGt(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class BoolEqContext extends ExprContext {
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public BoolEqContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).enterBoolEq(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).exitBoolEq(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GTTEmbededRuleScriptVisitor ) return ((GTTEmbededRuleScriptVisitor<? extends T>)visitor).visitBoolEq(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class MathMulDivContext extends ExprContext {
		public Token op;
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public MathMulDivContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).enterMathMulDiv(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).exitMathMulDiv(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GTTEmbededRuleScriptVisitor ) return ((GTTEmbededRuleScriptVisitor<? extends T>)visitor).visitMathMulDiv(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class ExprFunctionCallContext extends ExprContext {
		public FunctionCallContext functionCall() {
			return getRuleContext(FunctionCallContext.class,0);
		}
		public ExprFunctionCallContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).enterExprFunctionCall(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).exitExprFunctionCall(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GTTEmbededRuleScriptVisitor ) return ((GTTEmbededRuleScriptVisitor<? extends T>)visitor).visitExprFunctionCall(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ExprContext expr() throws RecognitionException {
		return expr(0);
	}

	private ExprContext expr(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		ExprContext _localctx = new ExprContext(_ctx, _parentState);
		ExprContext _prevctx = _localctx;
		int _startState = 28;
		enterRecursionRule(_localctx, 28, RULE_expr, _p);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(182);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,16,_ctx) ) {
			case 1:
				{
				_localctx = new ExprParensContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;

				setState(171);
				match(T__2);
				setState(172);
				expr(0);
				setState(173);
				match(T__3);
				}
				break;
			case 2:
				{
				_localctx = new MathUnitaryContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(175);
				((MathUnitaryContext)_localctx).op = _input.LT(1);
				_la = _input.LA(1);
				if ( !(_la==T__8 || _la==T__9) ) {
					((MathUnitaryContext)_localctx).op = (Token)_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(176);
				expr(15);
				}
				break;
			case 3:
				{
				_localctx = new BoolReverseContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(177);
				match(T__12);
				setState(178);
				expr(12);
				}
				break;
			case 4:
				{
				_localctx = new ExprAtomContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(179);
				atom();
				}
				break;
			case 5:
				{
				_localctx = new ExprFunctionCallContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(180);
				functionCall();
				}
				break;
			case 6:
				{
				_localctx = new ExprQulifiedNameContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(181);
				qualifiedName();
				}
				break;
			}
			_ctx.stop = _input.LT(-1);
			setState(219);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,18,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					setState(217);
					_errHandler.sync(this);
					switch ( getInterpreter().adaptivePredict(_input,17,_ctx) ) {
					case 1:
						{
						_localctx = new MathPowContext(new ExprContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(184);
						if (!(precpred(_ctx, 16))) throw new FailedPredicateException(this, "precpred(_ctx, 16)");
						setState(185);
						match(T__7);
						setState(186);
						expr(16);
						}
						break;
					case 2:
						{
						_localctx = new MathMulDivContext(new ExprContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(187);
						if (!(precpred(_ctx, 14))) throw new FailedPredicateException(this, "precpred(_ctx, 14)");
						setState(188);
						((MathMulDivContext)_localctx).op = _input.LT(1);
						_la = _input.LA(1);
						if ( !(_la==T__10 || _la==T__11) ) {
							((MathMulDivContext)_localctx).op = (Token)_errHandler.recoverInline(this);
						}
						else {
							if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
							_errHandler.reportMatch(this);
							consume();
						}
						setState(189);
						expr(15);
						}
						break;
					case 3:
						{
						_localctx = new MathAddSubContext(new ExprContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(190);
						if (!(precpred(_ctx, 13))) throw new FailedPredicateException(this, "precpred(_ctx, 13)");
						setState(191);
						((MathAddSubContext)_localctx).op = _input.LT(1);
						_la = _input.LA(1);
						if ( !(_la==T__8 || _la==T__9) ) {
							((MathAddSubContext)_localctx).op = (Token)_errHandler.recoverInline(this);
						}
						else {
							if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
							_errHandler.reportMatch(this);
							consume();
						}
						setState(192);
						expr(14);
						}
						break;
					case 4:
						{
						_localctx = new BoolGtContext(new ExprContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(193);
						if (!(precpred(_ctx, 11))) throw new FailedPredicateException(this, "precpred(_ctx, 11)");
						setState(194);
						match(T__13);
						setState(195);
						expr(12);
						}
						break;
					case 5:
						{
						_localctx = new BoolGeContext(new ExprContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(196);
						if (!(precpred(_ctx, 10))) throw new FailedPredicateException(this, "precpred(_ctx, 10)");
						setState(197);
						match(T__14);
						setState(198);
						expr(11);
						}
						break;
					case 6:
						{
						_localctx = new BoolLtContext(new ExprContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(199);
						if (!(precpred(_ctx, 9))) throw new FailedPredicateException(this, "precpred(_ctx, 9)");
						setState(200);
						match(T__15);
						setState(201);
						expr(10);
						}
						break;
					case 7:
						{
						_localctx = new BoolLeContext(new ExprContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(202);
						if (!(precpred(_ctx, 8))) throw new FailedPredicateException(this, "precpred(_ctx, 8)");
						setState(203);
						match(T__16);
						setState(204);
						expr(9);
						}
						break;
					case 8:
						{
						_localctx = new BoolEqContext(new ExprContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(205);
						if (!(precpred(_ctx, 7))) throw new FailedPredicateException(this, "precpred(_ctx, 7)");
						setState(206);
						match(T__17);
						setState(207);
						expr(8);
						}
						break;
					case 9:
						{
						_localctx = new BoolNotEqContext(new ExprContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(208);
						if (!(precpred(_ctx, 6))) throw new FailedPredicateException(this, "precpred(_ctx, 6)");
						setState(209);
						match(T__18);
						setState(210);
						expr(7);
						}
						break;
					case 10:
						{
						_localctx = new BoolAndContext(new ExprContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(211);
						if (!(precpred(_ctx, 5))) throw new FailedPredicateException(this, "precpred(_ctx, 5)");
						setState(212);
						match(T__19);
						setState(213);
						expr(6);
						}
						break;
					case 11:
						{
						_localctx = new BoolOrContext(new ExprContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(214);
						if (!(precpred(_ctx, 4))) throw new FailedPredicateException(this, "precpred(_ctx, 4)");
						setState(215);
						match(T__20);
						setState(216);
						expr(5);
						}
						break;
					}
					} 
				}
				setState(221);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,18,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	public static class AtomContext extends ParserRuleContext {
		public AtomContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_atom; }
	 
		public AtomContext() { }
		public void copyFrom(AtomContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class DecimalLiteralContext extends AtomContext {
		public TerminalNode DECIMAL_LITERAL() { return getToken(GTTEmbededRuleScriptParser.DECIMAL_LITERAL, 0); }
		public DecimalLiteralContext(AtomContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).enterDecimalLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).exitDecimalLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GTTEmbededRuleScriptVisitor ) return ((GTTEmbededRuleScriptVisitor<? extends T>)visitor).visitDecimalLiteral(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class NullLiteralContext extends AtomContext {
		public TerminalNode NULL_LITERAL() { return getToken(GTTEmbededRuleScriptParser.NULL_LITERAL, 0); }
		public NullLiteralContext(AtomContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).enterNullLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).exitNullLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GTTEmbededRuleScriptVisitor ) return ((GTTEmbededRuleScriptVisitor<? extends T>)visitor).visitNullLiteral(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class StringLiteralContext extends AtomContext {
		public TerminalNode STRING_LITERAL() { return getToken(GTTEmbededRuleScriptParser.STRING_LITERAL, 0); }
		public StringLiteralContext(AtomContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).enterStringLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).exitStringLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GTTEmbededRuleScriptVisitor ) return ((GTTEmbededRuleScriptVisitor<? extends T>)visitor).visitStringLiteral(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class ArrayLiteralContext extends AtomContext {
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public ArrayLiteralContext(AtomContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).enterArrayLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).exitArrayLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GTTEmbededRuleScriptVisitor ) return ((GTTEmbededRuleScriptVisitor<? extends T>)visitor).visitArrayLiteral(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class IntegerLiteralContext extends AtomContext {
		public TerminalNode INTEGER_LITERAL() { return getToken(GTTEmbededRuleScriptParser.INTEGER_LITERAL, 0); }
		public IntegerLiteralContext(AtomContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).enterIntegerLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).exitIntegerLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GTTEmbededRuleScriptVisitor ) return ((GTTEmbededRuleScriptVisitor<? extends T>)visitor).visitIntegerLiteral(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class BoolLiteralContext extends AtomContext {
		public TerminalNode BOOLEAN_LITERAL() { return getToken(GTTEmbededRuleScriptParser.BOOLEAN_LITERAL, 0); }
		public BoolLiteralContext(AtomContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).enterBoolLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GTTEmbededRuleScriptListener ) ((GTTEmbededRuleScriptListener)listener).exitBoolLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GTTEmbededRuleScriptVisitor ) return ((GTTEmbededRuleScriptVisitor<? extends T>)visitor).visitBoolLiteral(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AtomContext atom() throws RecognitionException {
		AtomContext _localctx = new AtomContext(_ctx, getState());
		enterRule(_localctx, 30, RULE_atom);
		int _la;
		try {
			setState(239);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case INTEGER_LITERAL:
				_localctx = new IntegerLiteralContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(222);
				match(INTEGER_LITERAL);
				}
				break;
			case DECIMAL_LITERAL:
				_localctx = new DecimalLiteralContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(223);
				match(DECIMAL_LITERAL);
				}
				break;
			case BOOLEAN_LITERAL:
				_localctx = new BoolLiteralContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(224);
				match(BOOLEAN_LITERAL);
				}
				break;
			case STRING_LITERAL:
				_localctx = new StringLiteralContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(225);
				match(STRING_LITERAL);
				}
				break;
			case T__4:
				_localctx = new ArrayLiteralContext(_localctx);
				enterOuterAlt(_localctx, 5);
				{
				setState(226);
				match(T__4);
				setState(235);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__2) | (1L << T__4) | (1L << T__8) | (1L << T__9) | (1L << T__12) | (1L << NULL_LITERAL) | (1L << INTEGER_LITERAL) | (1L << DECIMAL_LITERAL) | (1L << BOOLEAN_LITERAL) | (1L << STRING_LITERAL) | (1L << IDENTIFIER))) != 0)) {
					{
					setState(227);
					expr(0);
					setState(232);
					_errHandler.sync(this);
					_la = _input.LA(1);
					while (_la==T__6) {
						{
						{
						setState(228);
						match(T__6);
						setState(229);
						expr(0);
						}
						}
						setState(234);
						_errHandler.sync(this);
						_la = _input.LA(1);
					}
					}
				}

				setState(237);
				match(T__5);
				}
				break;
			case NULL_LITERAL:
				_localctx = new NullLiteralContext(_localctx);
				enterOuterAlt(_localctx, 6);
				{
				setState(238);
				match(NULL_LITERAL);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public boolean sempred(RuleContext _localctx, int ruleIndex, int predIndex) {
		switch (ruleIndex) {
		case 14:
			return expr_sempred((ExprContext)_localctx, predIndex);
		}
		return true;
	}
	private boolean expr_sempred(ExprContext _localctx, int predIndex) {
		switch (predIndex) {
		case 0:
			return precpred(_ctx, 16);
		case 1:
			return precpred(_ctx, 14);
		case 2:
			return precpred(_ctx, 13);
		case 3:
			return precpred(_ctx, 11);
		case 4:
			return precpred(_ctx, 10);
		case 5:
			return precpred(_ctx, 9);
		case 6:
			return precpred(_ctx, 8);
		case 7:
			return precpred(_ctx, 7);
		case 8:
			return precpred(_ctx, 6);
		case 9:
			return precpred(_ctx, 5);
		case 10:
			return precpred(_ctx, 4);
		}
		return true;
	}

	public static final String _serializedATN =
		"\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\3)\u00f4\4\2\t\2\4"+
		"\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7\4\b\t\b\4\t\t\t\4\n\t\n\4\13\t"+
		"\13\4\f\t\f\4\r\t\r\4\16\t\16\4\17\t\17\4\20\t\20\4\21\t\21\3\2\6\2$\n"+
		"\2\r\2\16\2%\3\2\3\2\3\3\3\3\3\3\3\3\3\3\5\3/\n\3\3\3\3\3\5\3\63\n\3\3"+
		"\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\5\3A\n\3\3\4\3\4\3\4\3"+
		"\4\5\4G\n\4\3\5\3\5\3\5\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\7\6T\n\6\f\6\16"+
		"\6W\13\6\3\6\5\6Z\n\6\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\b\3\b\3\b"+
		"\3\b\3\b\3\t\3\t\3\t\3\t\3\t\3\t\3\t\3\t\3\n\3\n\5\nt\n\n\3\13\7\13w\n"+
		"\13\f\13\16\13z\13\13\3\13\3\13\3\13\5\13\177\n\13\3\f\3\f\3\f\3\f\3\f"+
		"\3\f\5\f\u0087\n\f\3\r\3\r\7\r\u008b\n\r\f\r\16\r\u008e\13\r\3\16\3\16"+
		"\3\16\5\16\u0093\n\16\3\16\3\16\3\16\3\16\3\16\7\16\u009a\n\16\f\16\16"+
		"\16\u009d\13\16\5\16\u009f\n\16\3\16\3\16\3\17\3\17\3\17\3\17\3\17\3\17"+
		"\3\17\3\17\5\17\u00ab\n\17\3\20\3\20\3\20\3\20\3\20\3\20\3\20\3\20\3\20"+
		"\3\20\3\20\3\20\5\20\u00b9\n\20\3\20\3\20\3\20\3\20\3\20\3\20\3\20\3\20"+
		"\3\20\3\20\3\20\3\20\3\20\3\20\3\20\3\20\3\20\3\20\3\20\3\20\3\20\3\20"+
		"\3\20\3\20\3\20\3\20\3\20\3\20\3\20\3\20\3\20\3\20\3\20\7\20\u00dc\n\20"+
		"\f\20\16\20\u00df\13\20\3\21\3\21\3\21\3\21\3\21\3\21\3\21\3\21\7\21\u00e9"+
		"\n\21\f\21\16\21\u00ec\13\21\5\21\u00ee\n\21\3\21\3\21\5\21\u00f2\n\21"+
		"\3\21\2\3\36\22\2\4\6\b\n\f\16\20\22\24\26\30\32\34\36 \2\4\3\2\13\f\3"+
		"\2\r\16\2\u010f\2#\3\2\2\2\4@\3\2\2\2\6B\3\2\2\2\bH\3\2\2\2\nK\3\2\2\2"+
		"\f[\3\2\2\2\16d\3\2\2\2\20i\3\2\2\2\22q\3\2\2\2\24x\3\2\2\2\26\u0086\3"+
		"\2\2\2\30\u0088\3\2\2\2\32\u0092\3\2\2\2\34\u00aa\3\2\2\2\36\u00b8\3\2"+
		"\2\2 \u00f1\3\2\2\2\"$\5\4\3\2#\"\3\2\2\2$%\3\2\2\2%#\3\2\2\2%&\3\2\2"+
		"\2&\'\3\2\2\2\'(\7\2\2\3(\3\3\2\2\2)*\5\6\4\2*+\7#\2\2+A\3\2\2\2,.\5\n"+
		"\6\2-/\7#\2\2.-\3\2\2\2./\3\2\2\2/A\3\2\2\2\60\62\5\20\t\2\61\63\7#\2"+
		"\2\62\61\3\2\2\2\62\63\3\2\2\2\63A\3\2\2\2\64\65\5\b\5\2\65\66\7#\2\2"+
		"\66A\3\2\2\2\678\5\32\16\289\7#\2\29A\3\2\2\2:;\5\34\17\2;<\7#\2\2<A\3"+
		"\2\2\2=>\5\22\n\2>?\7#\2\2?A\3\2\2\2@)\3\2\2\2@,\3\2\2\2@\60\3\2\2\2@"+
		"\64\3\2\2\2@\67\3\2\2\2@:\3\2\2\2@=\3\2\2\2A\5\3\2\2\2BC\7\33\2\2CF\7"+
		"\"\2\2DE\7\3\2\2EG\5\36\20\2FD\3\2\2\2FG\3\2\2\2G\7\3\2\2\2HI\7\4\2\2"+
		"IJ\5\36\20\2J\t\3\2\2\2KL\7\30\2\2LM\7\5\2\2MN\5\36\20\2NO\7\6\2\2OP\7"+
		"$\2\2PQ\5\24\13\2QU\7%\2\2RT\5\f\7\2SR\3\2\2\2TW\3\2\2\2US\3\2\2\2UV\3"+
		"\2\2\2VY\3\2\2\2WU\3\2\2\2XZ\5\16\b\2YX\3\2\2\2YZ\3\2\2\2Z\13\3\2\2\2"+
		"[\\\7\31\2\2\\]\7\30\2\2]^\7\5\2\2^_\5\36\20\2_`\7\6\2\2`a\7$\2\2ab\5"+
		"\24\13\2bc\7%\2\2c\r\3\2\2\2de\7\31\2\2ef\7$\2\2fg\5\24\13\2gh\7%\2\2"+
		"h\17\3\2\2\2ij\7\34\2\2jk\7\5\2\2kl\5\36\20\2lm\7\6\2\2mn\7$\2\2no\5\24"+
		"\13\2op\7%\2\2p\21\3\2\2\2qs\7\32\2\2rt\5\36\20\2sr\3\2\2\2st\3\2\2\2"+
		"t\23\3\2\2\2uw\5\4\3\2vu\3\2\2\2wz\3\2\2\2xv\3\2\2\2xy\3\2\2\2y~\3\2\2"+
		"\2zx\3\2\2\2{|\5\22\n\2|}\7#\2\2}\177\3\2\2\2~{\3\2\2\2~\177\3\2\2\2\177"+
		"\25\3\2\2\2\u0080\u0081\7\7\2\2\u0081\u0082\5\36\20\2\u0082\u0083\7\b"+
		"\2\2\u0083\u0087\3\2\2\2\u0084\u0085\7&\2\2\u0085\u0087\7\"\2\2\u0086"+
		"\u0080\3\2\2\2\u0086\u0084\3\2\2\2\u0087\27\3\2\2\2\u0088\u008c\7\"\2"+
		"\2\u0089\u008b\5\26\f\2\u008a\u0089\3\2\2\2\u008b\u008e\3\2\2\2\u008c"+
		"\u008a\3\2\2\2\u008c\u008d\3\2\2\2\u008d\31\3\2\2\2\u008e\u008c\3\2\2"+
		"\2\u008f\u0090\5\30\r\2\u0090\u0091\7&\2\2\u0091\u0093\3\2\2\2\u0092\u008f"+
		"\3\2\2\2\u0092\u0093\3\2\2\2\u0093\u0094\3\2\2\2\u0094\u0095\7\"\2\2\u0095"+
		"\u009e\7\5\2\2\u0096\u009b\5\36\20\2\u0097\u0098\7\t\2\2\u0098\u009a\5"+
		"\36\20\2\u0099\u0097\3\2\2\2\u009a\u009d\3\2\2\2\u009b\u0099\3\2\2\2\u009b"+
		"\u009c\3\2\2\2\u009c\u009f\3\2\2\2\u009d\u009b\3\2\2\2\u009e\u0096\3\2"+
		"\2\2\u009e\u009f\3\2\2\2\u009f\u00a0\3\2\2\2\u00a0\u00a1\7\6\2\2\u00a1"+
		"\33\3\2\2\2\u00a2\u00a3\5\30\r\2\u00a3\u00a4\5\26\f\2\u00a4\u00a5\7\3"+
		"\2\2\u00a5\u00a6\5\36\20\2\u00a6\u00ab\3\2\2\2\u00a7\u00a8\7\"\2\2\u00a8"+
		"\u00a9\7\3\2\2\u00a9\u00ab\5\36\20\2\u00aa\u00a2\3\2\2\2\u00aa\u00a7\3"+
		"\2\2\2\u00ab\35\3\2\2\2\u00ac\u00ad\b\20\1\2\u00ad\u00ae\7\5\2\2\u00ae"+
		"\u00af\5\36\20\2\u00af\u00b0\7\6\2\2\u00b0\u00b9\3\2\2\2\u00b1\u00b2\t"+
		"\2\2\2\u00b2\u00b9\5\36\20\21\u00b3\u00b4\7\17\2\2\u00b4\u00b9\5\36\20"+
		"\16\u00b5\u00b9\5 \21\2\u00b6\u00b9\5\32\16\2\u00b7\u00b9\5\30\r\2\u00b8"+
		"\u00ac\3\2\2\2\u00b8\u00b1\3\2\2\2\u00b8\u00b3\3\2\2\2\u00b8\u00b5\3\2"+
		"\2\2\u00b8\u00b6\3\2\2\2\u00b8\u00b7\3\2\2\2\u00b9\u00dd\3\2\2\2\u00ba"+
		"\u00bb\f\22\2\2\u00bb\u00bc\7\n\2\2\u00bc\u00dc\5\36\20\22\u00bd\u00be"+
		"\f\20\2\2\u00be\u00bf\t\3\2\2\u00bf\u00dc\5\36\20\21\u00c0\u00c1\f\17"+
		"\2\2\u00c1\u00c2\t\2\2\2\u00c2\u00dc\5\36\20\20\u00c3\u00c4\f\r\2\2\u00c4"+
		"\u00c5\7\20\2\2\u00c5\u00dc\5\36\20\16\u00c6\u00c7\f\f\2\2\u00c7\u00c8"+
		"\7\21\2\2\u00c8\u00dc\5\36\20\r\u00c9\u00ca\f\13\2\2\u00ca\u00cb\7\22"+
		"\2\2\u00cb\u00dc\5\36\20\f\u00cc\u00cd\f\n\2\2\u00cd\u00ce\7\23\2\2\u00ce"+
		"\u00dc\5\36\20\13\u00cf\u00d0\f\t\2\2\u00d0\u00d1\7\24\2\2\u00d1\u00dc"+
		"\5\36\20\n\u00d2\u00d3\f\b\2\2\u00d3\u00d4\7\25\2\2\u00d4\u00dc\5\36\20"+
		"\t\u00d5\u00d6\f\7\2\2\u00d6\u00d7\7\26\2\2\u00d7\u00dc\5\36\20\b\u00d8"+
		"\u00d9\f\6\2\2\u00d9\u00da\7\27\2\2\u00da\u00dc\5\36\20\7\u00db\u00ba"+
		"\3\2\2\2\u00db\u00bd\3\2\2\2\u00db\u00c0\3\2\2\2\u00db\u00c3\3\2\2\2\u00db"+
		"\u00c6\3\2\2\2\u00db\u00c9\3\2\2\2\u00db\u00cc\3\2\2\2\u00db\u00cf\3\2"+
		"\2\2\u00db\u00d2\3\2\2\2\u00db\u00d5\3\2\2\2\u00db\u00d8\3\2\2\2\u00dc"+
		"\u00df\3\2\2\2\u00dd\u00db\3\2\2\2\u00dd\u00de\3\2\2\2\u00de\37\3\2\2"+
		"\2\u00df\u00dd\3\2\2\2\u00e0\u00f2\7\36\2\2\u00e1\u00f2\7\37\2\2\u00e2"+
		"\u00f2\7 \2\2\u00e3\u00f2\7!\2\2\u00e4\u00ed\7\7\2\2\u00e5\u00ea\5\36"+
		"\20\2\u00e6\u00e7\7\t\2\2\u00e7\u00e9\5\36\20\2\u00e8\u00e6\3\2\2\2\u00e9"+
		"\u00ec\3\2\2\2\u00ea\u00e8\3\2\2\2\u00ea\u00eb\3\2\2\2\u00eb\u00ee\3\2"+
		"\2\2\u00ec\u00ea\3\2\2\2\u00ed\u00e5\3\2\2\2\u00ed\u00ee\3\2\2\2\u00ee"+
		"\u00ef\3\2\2\2\u00ef\u00f2\7\b\2\2\u00f0\u00f2\7\35\2\2\u00f1\u00e0\3"+
		"\2\2\2\u00f1\u00e1\3\2\2\2\u00f1\u00e2\3\2\2\2\u00f1\u00e3\3\2\2\2\u00f1"+
		"\u00e4\3\2\2\2\u00f1\u00f0\3\2\2\2\u00f2!\3\2\2\2\30%.\62@FUYsx~\u0086"+
		"\u008c\u0092\u009b\u009e\u00aa\u00b8\u00db\u00dd\u00ea\u00ed\u00f1";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}