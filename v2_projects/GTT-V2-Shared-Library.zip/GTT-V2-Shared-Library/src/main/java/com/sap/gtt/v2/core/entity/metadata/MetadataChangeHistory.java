package com.sap.gtt.v2.core.entity.metadata;

import java.io.Serializable;
import java.time.Instant;
import java.util.Objects;
import java.util.StringJoiner;

/**
 * Metadata Change History
 *
 * @author I321712
 */
public class MetadataChangeHistory implements Serializable {
    private String id;
    private Instant changeTime;
    private String comment;
    private String namespace;
    private String userEmail;
    private String action;

    public MetadataChangeHistory() {
    }

    public MetadataChangeHistory(String id, Instant changeTime, String comment, String namespace, String userEmail, String action) {
        this.id = id;
        this.changeTime = changeTime;
        this.comment = comment;
        this.namespace = namespace;
        this.userEmail = userEmail;
        this.action = action;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Instant getChangeTime() {
        return changeTime;
    }

    public void setChangeTime(Instant changeTime) {
        this.changeTime = changeTime;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getNamespace() {
        return namespace;
    }

    public void setNamespace(String namespace) {
        this.namespace = namespace;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        MetadataChangeHistory that = (MetadataChangeHistory) o;
        return id.equals(that.id) &&
                Objects.equals(changeTime, that.changeTime) &&
                Objects.equals(comment, that.comment) &&
                namespace.equals(that.namespace) &&
                Objects.equals(userEmail, that.userEmail) &&
                Objects.equals(action, that.action);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, changeTime, comment, namespace, userEmail);
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", MetadataChangeHistory.class.getSimpleName() + "[", "]")
                .add("id='" + id + "'")
                .add("changeTime=" + changeTime)
                .add("comment='" + comment + "'")
                .add("namespace='" + namespace + "'")
                .add("userEmail='" + userEmail + "'")
                .add("action='" + action + "'")
                .toString();
    }
}
