package com.sap.gtt.v2.core.dao.tracking;

import com.sap.gtt.v2.core.domain.metadata.CurrentMetadataEntity;
import com.sap.gtt.v2.core.domain.trackedprocess.EventWrapper;
import com.sap.gtt.v2.core.entity.trackedprocess.Event;

import java.util.List;
import java.util.UUID;

public interface IEventDao {
	public void insert(Event event);

	void insert(List<Event> events);

	void delete(CurrentMetadataEntity metadata, UUID id);

	void update(Event event);

	List<Event> findByAltKey(CurrentMetadataEntity metadata, String altKey);

	List<Event> findAllByAltKeys(CurrentMetadataEntity metadata, List<String> altKeyList);

	List<Event> findAllByAltKeys(CurrentMetadataEntity metadata, String... altKeys);

	Event findOne(CurrentMetadataEntity metadata, UUID id);

	Event findOneById(UUID id);

    void deleteByProcessId(UUID tpId);

    List<EventWrapper> getActualEventsForCurrentTPIncludeEventTypes(UUID tpId, List<String> eventTypes);

	List<EventWrapper> getActualEventsForCurrentTPExcludeEventTypes(UUID tpId, List<String> eventTypes);

    Event findOneByTpIdAndEventType(CurrentMetadataEntity metadata, UUID tpId, String eventType);

    Event findLatestByTpIdAndEventTypeList(UUID tpId, List<String> eventTypes);

	List<Event> findByAltKey(String altKey);

	List<DefaultEventDao.EventTypeAndId> findEventTypeAndIdByAltKey(String altKey);
}
