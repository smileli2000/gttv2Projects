package com.sap.gtt.v2.core.entity.execution;

/**
 * @author I302310
 */
public class ExecutionPhase {
    private String id;
    private String executionId;
    private String phase;
    private String status;

    public ExecutionPhase(String id, String executionId, String phase, String status) {
        this.id = id;
        this.executionId = executionId;
        this.phase = phase;
        this.status = status;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getExecutionId() {
        return executionId;
    }

    public void setExecutionId(String executionId) {
        this.executionId = executionId;
    }

    public String getPhase() {
        return phase;
    }

    public void setPhase(String phase) {
        this.phase = phase;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
