package com.sap.gtt.v2.exception;

import org.apache.http.HttpStatus;

/**
 * @author I321712
 */
public class MetadataException extends BaseRuntimeException {
    public static final String ERROR_CODE = "ERROR_CODE_METADATA";

    private final int httpStatus;
    public static final String MESSAGE_CODE_PROPERTY_NOT_FOUND = MetadataException.class.getName() + ".PropertyNotFound";
    public static final String MESSAGE_CODE_NOT_FOUND = MetadataException.class.getName() + ".NotFound";
    public static final String MESSAGE_CODE_INCLUDES_NOT_FOUND = MetadataException.class.getName() + ".IncludesNotFound";
    public static final String MESSAGE_CODE_INHERIT_MORE_THAN_ONE_CORE_TYPE = MetadataException.class.getName() + ".MoreThanOneCoreType";
    public static final String MESSAGE_CODE_SWAGGER_NOT_FOUND = MetadataException.class.getName() + ".SwaggerNotFound";
    public static final String MESSAGE_CODE_BAD_SERVICE = MetadataException.class.getName() + ".BadService";
    public static final String MESSAGE_CODE_MORE_THAN_ONE_FOUND = MetadataException.class.getName() + ".MoreThanOneFound";
    public static final String MESSAGE_CODE_INVALID_ENTITY_FOUND = MetadataException.class.getName() + ".InvalidEntityFound";
    public static final String MESSAGE_CODE_NOT_FOUND_TRACKED_PROCESS_ENTITY = MetadataException.class.getName() + ".NotFoundTrackedProcessEntity";
    public static final String MESSAGE_CODE_NOT_FOUND_TRACKED_PROCESS_EVENT_ENTITY = MetadataException.class.getName() + ".NotFoundTrackedProcessEventEntity";
    public static final String MESSAGE_CODE_NOT_FOUND_EVENT_ENTITY = MetadataException.class.getName() + ".NotFoundEventEntity";

    public MetadataException(String internalMessage, Throwable cause, String messageCode, Object[] localizedMsgParams) {
        super(internalMessage, cause, messageCode, localizedMsgParams);
        this.httpStatus = HttpStatus.SC_INTERNAL_SERVER_ERROR;
    }

    public MetadataException(String messageCode, Object[] localizedMsgParams) {
        super(messageCode, localizedMsgParams);
        this.httpStatus = HttpStatus.SC_INTERNAL_SERVER_ERROR;
    }

    public MetadataException(String messageCode, Object[] localizedMsgParams, int httpStatus) {
        super(messageCode, localizedMsgParams);
        this.httpStatus = httpStatus;
    }

    @Override
    public int getHttpStatus() {
        return httpStatus;
    }

    @Override
    public String getErrorCode() {
        return ERROR_CODE;
    }
}
