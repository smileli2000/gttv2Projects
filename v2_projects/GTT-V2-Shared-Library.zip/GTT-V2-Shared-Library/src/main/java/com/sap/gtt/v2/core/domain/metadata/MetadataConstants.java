package com.sap.gtt.v2.core.domain.metadata;

import org.apache.commons.lang3.StringUtils;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * Metadata Constants
 *
 * @author I321712
 */
public class MetadataConstants {

    public static final String ENTITY_BASE_TYPE = "@com.sap.gtt.core.CoreModel.BaseType";
    public static final String ENTITY_IS_PROCESS_EVENT = "@com.sap.gtt.core.CoreModel.IsProcessEvent";
    public static final String ENTITY_USAGE_TYPE = "@com.sap.gtt.core.CoreModel.UsageType";
    public static final String ENTITY_APPLICATION_OBJECT_TYPE = "@com.sap.gtt.core.CoreModel.EMIntegration.ApplicationObjectType";
    public static final String ENTITY_TRACKING_ID_TYPE = "@com.sap.gtt.core.CoreModel.TrackingIdType";
    public static final String ENTITY_ADMISSIBLE_UNPLANNED_EVENTS = "@com.sap.gtt.core.CoreModel.AdmissibleUnplannedEvents";
    public static final String ENTITY_PLANNED_EVENTS = "@com.sap.gtt.core.CoreModel.PlannedEvents";
    public static final String ENTITY_FIELD_ADMISSIBLE_UNPLANNED_EVENTS = "unplannedEventsStr";
    public static final String ENTITY_FIELD_PLANNED_EVENTS = "plannedEventsStr";
    public static final String ENTITY_KIND = "kind";
    public static final String ENTITY_INCLUDES = "includes";
    public static final String ENTITY_FIELD_BASE_TYPE = "baseType";
    public static final String ENTITY_FIELD_IS_PROCESS_EVENT = "processEvent";
    public static final String ENTITY_FIELD_APPLICATION_OBJECT_TYPE = "applicationObjectType";
    public static final String ENTITY_FIELD_TRACKING_ID_TYPE = "trackingIdType";
    public static final String ENTITY_EVENT_TYPE = "eventType";
    public static final String ENTITY_INCLUDE_CUSTOMIZED_FIELDS = "@@includeCustomizedFields";
    public static final String ENTITY_FIELD_INCLUDE_CUSTOMIZED_FIELDS = "includeCustomizedFields";
    public static final String ENTITY_INHERIT_FROM_CORE_TYPE = "@@inheritFromCore";
    public static final String ENTITY_FIELD_INHERIT_FROM_CORE_TYPE = "inheritFromCore";
    public static final String ENTITY_RESTRICT = "@restrict";
    public static final String ENTITY_RESTRICT_GRANT = "grant";
    public static final String ENTITY_RESTRICT_WHERE = "where";
    public static final String ENTITY_AUTHORIZATION = "@@Authorization";
    public static final String ENTITY_AUTHORIZATION_PERMMISIONS = "permissions";
    public static final String ENTITY_AUTHORIZATION_PRINCIPAL_TYPE = "principalType";
    public static final String ENTITY_AUTHORIZATION_ELEMENT = "element";
    public static final String ENTITY_FIELD_AUTHORIZATION = "authorizationsStr";
    public static final String ENTITY_EXTENDED_PLAN_NAME = "@@extendedPlanName";
    public static final String ENTITY_FIELD_EXTENDED_PLAN_NAME = "extendedPlanName";


    public static final String ELEMENT_KEY = "key";
    public static final String ELEMENT_TYPE = "type";
    public static final String ELEMENT_LENGTH = "length";
    public static final String ELEMENT_DEFAULT = "default";
    public static final String ELEMENT_FIELD_DEFAULT = "defaultVal";
    public static final String ELEMENT_ENUM_DEFAULT_VALUE = "@com.sap.gtt.core.CoreModel.Enum.DefaultValue";
    public static final String ELEMENT_ENUM = "enum";
    public static final String ELEMENT_FIELD_ENUM = "enumVal";
    public static final String ELEMENT_TARGET = "target";
    public static final String ELEMENT_CARDINALITY = "cardinality";
    public static final String ELEMENT_KEYS = "keys";
    public static final String ELEMENTS = "elements";
    public static final String ELEMENT_FROM_CORE_MODEL = "@@fromCoreModel";
    public static final String ELEMENT_FIELD_FROM_CORE_MODEL = "fromCoreModel";
    public static final String ELEMENT_BACK_LINK = "@@backLink";
    public static final String ELEMENT_FIELD_BACK_LINK = "backLink";
    public static final String ELEMENT_FOREIGN_KEY_FLD = "@@foreignKeyFld";
    public static final String ELEMENT_FIELD_FOREIGN_KEY_FLD = "foreignKeyFld";
    public static final String ELEMENT_KEYS_REF = "ref";
    public static final String ELEMENT_KEYS_GENERATED_FIELD_NAME = "$generatedFieldName";
    public static final String ELEMENT_PRECISION = "precision";
    public static final String ELEMENT_SCALE = "scale";
    public static final String ELEMENT_SOURCE_ALT_KEY = "@com.sap.gtt.core.CoreModel.NavigationProperty.SourceAltKey";
    public static final String ELEMENT_FIELD_SOURCE_ALT_KEY = "sourceAltKey";
    public static final String ELEMENT_ON = "on";
    public static final String ELEMENT_ON_REF = "ref";
    public static final String DEFINITIONS = "definitions";
    public static final String HASH = "#";
    public static final String EQUAL = "=";
    public static final String COMMA = ",";
    public static final String UNDERSCORE = "_";
    public static final String DOT = ".";
    public static final String CORE_MODEL_PREFIX = "com.sap.gtt.core.CoreModel";
    public static final String ORIGIN = "origin";
    public static final String VALUE = "value";
    public static final String VAL = "val";
    public static final String FOR_WRITE_SUFFIX = "ForWrite";
    public static final String ELEMENT_DPP_PII = "@DPP.PII";
    public static final String ELEMENT_FIELD_DPP_PII = "dppPii";
    public static final String ELEMENT_DPP_SPI = "@DPP.SPI";
    public static final String ELEMENT_FIELD_DPP_SPI = "dppSpi";
    public static final String ELEMENT_DPP_DATA_SUBJECTID = "@DPP.DataSubjectId";
    public static final String ELEMENT_FIELD_DPP_DATA_SUBJECTID = "dppDataSubjectId";

    public static final String FIELD_CONTENT_PREFIX = "@com.sap.gtt.core.CoreModel.FieldContent.";
    public static final String FIELD_CONTENT_INTEGER_MAXIMUM = "@com.sap.gtt.core.CoreModel.FieldContent.IntegerType.Maximum";
    public static final String FIELD_CONTENT_INTEGER_MINIMUM = "@com.sap.gtt.core.CoreModel.FieldContent.IntegerType.Minimum";
    public static final String FIELD_CONTENT_INTEGER_EXCLUSIVE_MINIMUM = "@com.sap.gtt.core.CoreModel.FieldContent.IntegerType.ExclusiveMinimum";
    public static final String FIELD_CONTENT_INTEGER_EXCLUSIVE_MAXIMUM = "@com.sap.gtt.core.CoreModel.FieldContent.IntegerType.ExclusiveMaximum";
    public static final String FIELD_CONTENT_INTEGER_MULTIPLE_OF = "@com.sap.gtt.core.CoreModel.FieldContent.IntegerType.MultipleOf";

    public static final String FIELD_CONTENT_DECIMAL_MAXIMUM = "@com.sap.gtt.core.CoreModel.FieldContent.DecimalType.Maximum";
    public static final String FIELD_CONTENT_DECIMAL_MINIMUM = "@com.sap.gtt.core.CoreModel.FieldContent.DecimalType.Minimum";
    public static final String FIELD_CONTENT_DECIMAL_EXCLUSIVE_MINIMUM = "@com.sap.gtt.core.CoreModel.FieldContent.DecimalType.ExclusiveMinimum";
    public static final String FIELD_CONTENT_DECIMAL_EXCLUSIVE_MAXIMUM = "@com.sap.gtt.core.CoreModel.FieldContent.DecimalType.ExclusiveMaximum";
    public static final String FIELD_CONTENT_DECIMAL_MULTIPLE_OF = "@com.sap.gtt.core.CoreModel.FieldContent.DecimalType.MultipleOf";

    public static final String FIELD_CONTENT_STRING_MIN_LENGTH = "@com.sap.gtt.core.CoreModel.FieldContent.StringType.MinLength";
    public static final String FIELD_CONTENT_STRING_PATTERN = "@com.sap.gtt.core.CoreModel.FieldContent.StringType.Pattern";

    public static final String FIELD_CONTENT_ARRAY_MIN_ITEMS = "@com.sap.gtt.core.CoreModel.FieldContent.ArrayType.MinItems";
    public static final String FIELD_CONTENT_ARRAY_MAX_ITEMS = "@com.sap.gtt.core.CoreModel.FieldContent.ArrayType.MaxItems";

    public static final String ENABLE_INSTANCE_BASED_AUTHORIZATION = "enableInstanceBasedAuthorization";
    public static final String EVENT_CORRELATION_LEVEL = "eventCorrelationLevel";

    public static final String ELEMENT_CORE_REPLACE_ACTUAL_EVENT_FIELD = "@com.sap.gtt.core.CoreModel.ExtendPlan.ReplaceActualEventField";
    public static final String ELEMENT_REPLACE_ACTUAL_EVENT_FIELDS = "@@replaceActualEventFields";
    public static final String ELEMENT_FIELD_REPLACE_ACTUAL_EVENT_FIELDS_STR = "replaceActualEventFieldsStr";


    public static final int INITIAL_CAPACITY = 16;

    /**
     * Column name constants definition
     */
    public static final String UPLOADED_AT = "UPLOADED_AT";
    public static final String VERSION = "VERSION";
    public static final String ID = "ID";
    public static final String CDS = "CDS";
    public static final String CSN = "CSN";
    public static final String EDMX = "EDMX";
    public static final String ANNOTATION = "ANNOTATION";
    public static final String I18N = "I18N";
    public static final String SWAGGER = "SWAGGER";
    public static final String DERIVED_CSN = "DERIVED_CSN";
    public static final String RULES = "RULES";
    public static final String NAMESPACE = "NAMESPACE";
    public static final String DRAFTSTATUS = "DRAFTSTATUS";
    public static final String STATUS = "STATUS";
    public static final String DESCRIPTION = "DESCRIPTION";
    public static final String LOCALE = "LOCALE";
    public static final String MODE = "MODE";
    public static final String CORE_MODEL_VERSION = "CORE_MODEL_VERSION";
    public static final String COMPILER_VERSION = "COMPILER_VERSION";
    public static final String TRACKED_PROCESS_TYPE = "TRACKED_PROCESS_TYPE";
    public static final String APPLICATION_OBJECT_TYPE = "APPLICATION_OBJECT_TYPE";
    public static final String TRACKING_ID_TYPE = "TRACKINGIDTYPE";
    public static final String METADATA_PROJECT_ID = "METADATA_PROJECT_ID";
    public static final String JSON_MODEL = "JSON_MODEL";
    public static final String ACTION = "ACTION";
    public static final String CHANGE_TIME = "CHANGE_TIME";
    public static final String USER_EMAIL = "USER_EMAIL";
    public static final String COMMENT = "COMMENT";
    public static final String UPDATED_AT = "UPDATED_AT";
    public static final String METADATA_EVENT_ID = "METADATA_EVENT_ID";

    public static final String PROCESS_ID = "PROCESS_ID";
    public static final String EVENTSTATUS_CODE = "EVENTSTATUS_CODE";
    public static final String NEXT_OVERDUE_DETECTION = "NEXTOVERDUEDETECTION";
    public static final String ALT_KEY = "ALTKEY";
    public static final String TRACKEDPROCESSTYPE = "TRACKEDPROCESSTYPE";
    public static final String EVENTTYPE = "EVENTTYPE";
    public static final String CLONE_INSTANCE_ID = "CLONEINSTANCEID";
    public static final String SUB_ACCOUNT_ID = "SUBACCOUNTID";
    public static final String PARTY_ID = "PARTYID";
    /**
     * processMetadata.ID
     */
    public static final String PM_ID = "PM.ID";
    /**
     * metadataProject.ID
     */
    public static final String MP_ID = "MP.ID";
    public static final String MP_NAMESPACE = "MP.NAMESPACE";
    public static final String PROCESS_METADATA_ID = "PROCESS_METADATA_ID";
    public static final String EVENT_TYPE = "EVENT_TYPE";
    public static final String MPF_ID = "MPF.ID";

    public static final String SUB_ACCOUNT_CONFIGURATION = "SUB_ACCOUNT_CONFIGURATION";
    public static final String VALUE_CLOB = "VALUE_CLOB";
    public static final String PDM_NAMESPACE = "Namespace";
    public static final String PDM_CORE_NAMESPACE = "com.sap.gtt.v2.core:coreengine";
    public static final String PDM_KEY = "KEY";
    public static final String PDM_SCHEMA = "pdm_schema";
    public static final String PDM_NAME = "Name";
    public static final String PDM_ENTITIES = "Entities";
    public static final String PDM_KEYS = "Keys";
    public static final String PDM_SEMATICS = "sap:pdm-semantics";
    public static final String PDM_DATA_SUBJECT_IDENTITY = "data-subject-identity";
    public static final String PDM_BUSINESS_DATA = "business-data";
    public static final String PDM_DATA_SUBJECT_IDENTITY_ENTITY_NAME = "data_subject_identity";
    public static final String PDM_BUSINESS_OBJECT = "sap:pdm-business-object";
    public static final String PDM_BUSINESS_NODE = "sap:pdm-business-node";
    public static final String PDM_DATA_SUBJECT_TECH_ID = "data-subject-tech-id";
    public static final String PDM_DATA_SUBJECT_ID = "data-subject-id";
    public static final String PDM_PERSONAL_DATA = "personal-data";
    public static final String PDM_SENSITIVE_PERSONAL_DATA = "sensitive-personal-data";
    public static final String PDM_LABLE = "sap:label";
    public static final String PDM_PROPERTIES = "Properties";
    public static final String PDM_TYPE = "Type";
    public static final String PDM_NULLABLE = "Nullable";
    public static final String PDM_MAXLENGTH = "MaxLength";
    public static final String PDM_SEQ_NO = "sap:pdm-display-seq-no";
    public static final String PDM_DATA_SUBJECT_ID_PROPERTY = "dataSubjectId";
    public static final String PDM_PROPERTY = "sap:pdm-property";
    public static final String PDM_UNDER_SCORE = "_";
    public static final String REPORTEDBY = "REPORTEDBY";
    public static final String CREATEDBYUSER = "CREATEDBYUSER";
    public static final String MODELNAMESPACE = "MODELNAMESPACE";
    public static final String METADATA_PROCESS_ID = "METADATA_PROCESS_ID";

    public static final List<MetadataEntityEvent> CORE_MODEL_UNPLANNED_EVENTS =
            Collections.unmodifiableList(Arrays.asList(
                    new MetadataEntityEvent(CoreModelEntity.GTT_OVERDUE_EVENT.getFullName()),
                    new MetadataEntityEvent(CoreModelEntity.GTT_DELAYED_EVENT.getFullName()),
                    new MetadataEntityEvent(CoreModelEntity.GTT_ONTIME_EVENT.getFullName()),
                    new MetadataEntityEvent(CoreModelEntity.GTT_UPDATE_PLAN_EVENT.getFullName()),
                    new MetadataEntityEvent(CoreModelEntity.GTT_DELETION_EVENT.getFullName()),
                    new MetadataEntityEvent(CoreModelEntity.GTT_DPP_BLOCKING_EVENT.getFullName()),
                    new MetadataEntityEvent(CoreModelEntity.GTT_DPP_DELETION_EVENT.getFullName())
            ));


    public enum MetadataProjectFileField {
        /**
         * CDS
         */
        CDS,
        /**
         * CSN
         */
        CSN,
        /**
         * EDMX
         */
        EDMX,
        /**
         * ANNOTATION
         */
        ANNOTATION,
        /**
         * I18N
         */
        I18N,
        /**
         * SWAGGER
         */
        SWAGGER,
        /**
         * DERIVED_CSN
         */
        DERIVED_CSN,
        /**
         * RULES
         */
        RULES,
        /**
         * JSON_MODEL
         */
        JSON_MODEL,
        /**
         * IDOC_CONFIG
         */
        IDOC_CONFIG,
        /**
         * READ_SWAGGER
         */
        READ_SWAGGER
    }

    public enum DppType {
        /**
         * DPP.DataSubjectId
         */
        DPP_DATA_SUBJECTID("DPP.DataSubjectId"),
        /**
         * DPP.SPI
         */
        DPP_SPI("DPP.SPI"),
        /**
         * DPP.PII
         */
        DPP_PII("DPP.PII");
        private String value;

        DppType(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }
    }


    public enum MetadataTable {
        /**
         * METADATA_PROJECT
         */
        METADATA_PROJECT,
        /**
         * METADATA_PROJECT_TEXTS
         */
        METADATA_PROJECT_TEXTS,

        /**
         * METADATA_PROJECT_FILE
         */
        METADATA_PROJECT_FILE,
        /**
         * METADATA_PROCESS
         */
        METADATA_PROCESS,
        /**
         * METADATA_PROCESS_TEXTS
         */
        METADATA_PROCESS_TEXTS,
        /**
         * METADATA_CHANGE_HISTORY
         */
        METADATA_CHANGE_HISTORY,
        /**
         * METADATA_EVENT
         */
        METADATA_EVENT,

        /**
         * METADATA_EVENT_TEXTS
         */
        METADATA_EVENT_TEXTS,

        /**
         * METADATA_DRAFT_MODEL
         */
        METADATA_DRAFT_MODEL
    }

    public enum MetadataProjectStatus {

        /**
         * "COVERED": Covered
         */
        COVERED("Covered"),
        /**
         * "ACTIVE": Active
         */
        ACTIVE("Active"),
        /**
         * "DEPRECATED": Deprecated
         */
        DEPRECATED("Deprecated"),
        /**
         * "DEPRECATED": Deprecated
         */
        INACTIVE("Inactive"),
        /**
         * "BEING_DELETED": Being Deleted
         */
        BEING_DELETED("Being Deleted"),
        /**
         * "DELETED": Deleted
         */
        DELETED("Deleted");
        private String value;

        MetadataProjectStatus(String value) {
            this.value = value;
        }

        public String getValue() {
            return this.value;
        }

        @Override
        public String toString() {
            return String.valueOf(value);
        }

        public static MetadataProjectStatus fromValue(String text) {
            for (MetadataProjectStatus b : MetadataProjectStatus.values()) {
                if (StringUtils.equalsIgnoreCase(String.valueOf(b.value), text)) {
                    return b;
                }
            }
            return null;
        }
    }


    public enum MetadataDraftModelStatus {
        /**
         * DRAFT: Draft
         */
        DRAFT("Draft"),

        /**
         * DEPLOYED: Deployed
         */
        DEPLOYED("Deployed");

        private String value;

        MetadataDraftModelStatus(String value) {
            this.value = value;
        }

        public String getValue() {
            return this.value;
        }

        @Override
        public String toString() {
            return String.valueOf(value);
        }

        public static MetadataDraftModelStatus fromValue(String text) {
            for (MetadataDraftModelStatus b : MetadataDraftModelStatus.values()) {
                if (StringUtils.equalsIgnoreCase(String.valueOf(b.value), text)) {
                    return b;
                }
            }
            return null;
        }
    }

    public enum MetadataChangeActions {
        DEPLOY("DEPLOY"),
        REDEPLOY("REDEPLOY"),
        ACTIVATE("ACTIVATE"),
        DEACTIVATE("DEACTIVATE");
        private String value;

        MetadataChangeActions(String value) {
            this.value = value;
        }

        public String getValue() {
            return this.value;
        }
    }

    public enum MetadataProjectMode {
        /**
         * Standard
         */
        STANDARD("Standard");
        private String value;

        MetadataProjectMode(String value) {
            this.value = value;
        }

        public String getValue() {
            return this.value;
        }
    }

    public enum EntityKind {
        /**
         * CDS entity
         */
        ENTITY("entity"),
        /**
         * CDS service
         */
        SERVICE("service");
        private String value;

        EntityKind(String value) {
            this.value = value;
        }

        public String getValue() {
            return this.value;
        }
    }

    public enum EntityBaseType {
        /**
         * TrackedProcess
         */
        TRACKED_PROCESS("TrackedProcess"),
        /**
         * Event
         */
        EVENT("Event"),
        /**
         * BusinessPartner
         */
        BUSINESS_PARTNER("BusinessPartner"),
        /**
         * Location
         */
        LOCATION("Location");

        private String value;

        EntityBaseType(String value) {
            this.value = value;
        }

        public String getValue() {
            return this.value;
        }
    }

    /**
     * Abstract for CDS build-in types which are described https://github.wdf.sap.corp/pages/cap/cds/cdl#pre-defined-types.
     * SQL types are followed by ANSI SQL types except UUID/Date,
     * here we map it to NVARCHAR(36)/Date instead of VARCHAR(36)/DATETIME.
     */
    public enum CdsDataType {
        /**
         * cds.UUID
         */
        CDS_UUID("cds.UUID", "NVARCHAR(36)"),
        /**
         * cds.Boolean
         */
        CDS_BOOLEAN("cds.Boolean", "BOOLEAN"),
        /**
         * cds.Integer
         */
        CDS_INTEGER("cds.Integer", "INTEGER"),
        /**
         * cds.String
         */
        CDS_STRING("cds.String", "NVARCHAR"),
        /**
         * cds.DateTime
         */
//        CDS_DATETIME("cds.DateTime", "DATETIME"),
        /**
         * cds.Timestamp
         */
        CDS_TIMESTAMP("cds.Timestamp", "Timestamp"),
        /**
         * cds.Date
         */
        CDS_DATE("cds.Date", "DATE"),
        /**
         * cds.Decimal
         */
        CDS_DECIMAL("cds.Decimal", "DECIMAL"),
        /**
         * cds.Association
         */
        CDS_ASSOCIATION("cds.Association", null),
        /**
         * cds.Composition
         */
        CDS_COMPOSITION("cds.Composition", null);

        private String value;
        private String sqlType;

        CdsDataType(String value, String sqlType) {
            this.value = value;
            this.sqlType = sqlType;
        }

        public String getValue() {
            return this.value;
        }

        public String getSqlType() {
            return sqlType;
        }
    }

    public enum CoreModelEntity {
        /**
         * TrackedProcess
         */
        TRACKED_PROCESS("TrackedProcess"),
        /**
         * Event
         */
        EVENT("Event"),
        /**
         * PlannedEvent
         */
        PLANNED_EVENT("PlannedEvent"),
        /**
         * ProcessEventDirectory
         */
        PROCESS_EVENT_DIRECTORY("ProcessEventDirectory"),
        /**
         * Reference
         */
        REFERENCE("Reference"),
        /**
         * ReferenceForEvent
         */
        /**
         * PlannedEventForEvent
         */
        PLANNED_EVENT_FOR_EVENT("PlannedEventForEvent"),
        /**
         * ProcessEvent
         */
        PROCESS_EVENT("ProcessEvent"),
        /**
         * GTTOverdueEvent
         */
        GTT_OVERDUE_EVENT("GTTOverdueEvent"),
        /**
         * GTTUpdatePlanEvent
         */
        GTT_UPDATE_PLAN_EVENT("GTTUpdatePlanEvent"),
        /**
         * GTTDelayedEvent
         */
        GTT_DELAYED_EVENT("GTTDelayedEvent"),
        /**
         * GTTOnTimeEvent
         */
        GTT_ONTIME_EVENT("GTTOnTimeEvent"),
        /**
         * GTTDeletionEvent
         */
        GTT_DELETION_EVENT("GTTDeletionEvent"),
        GTT_DPP_DELETION_EVENT("GTTDPPDeletionEvent"),
        GTT_DPP_BLOCKING_EVENT("GTTDPPBlockingEvent"),
        /**
         * QualifiedTrackingId
         */
        QUALIFIED_TRACKING_ID("QualifiedTrackingId"),
        /**
         * EventStatus
         */
        EVENT_STATUS("EventStatus"),
        /**
         * EventStatus_texts
         */
        EVENT_STATUS_TEXTS("EventStatus_texts"),
        /**
         * CorrelationType
         */
        CORRELATION_TYPE("CorrelationType"),
        /**
         * CorrelationType_texts
         */
        CORRELATION_TYPE_TEXTS("CorrelationType_texts"),
        /**
         * ProcessStatus
         */
        PROCESS_STATUS("ProcessStatus"),
        /**
         * ProcessStatus_texts
         */
        PROCESS_STATUS_TEXTS("ProcessStatus_texts"),
        /**
         * LifeCycleStatus
         */
        LIFECYCLE_STATUS("LifeCycleStatus"),
        /**
         * LifeCycleStatus_texts
         */
        LIFECYCLE_STATUS_TEXTS("LifeCycleStatus_texts"),
        /**
         * ReferenceType
         */
        REFERENCE_TYPE("ReferenceType"),
        /**
         * ReferenceType_texts
         */
        REFERENCE_TYPE_TEXTS("ReferenceType_texts"),
        /**
         * Action
         */
        ACTION("Action"),
        /**
         * Action_texts
         */
        ACTION_TEXTS("Action_texts"),
        /**
         * UpdatePlanAction
         */
        UPDATE_PLAN_ACTION("UpdatePlanAction"),
        /**
         * UpdatePlanAction_texts
         */
        UPDATE_PLAN_ACTION_TEXTS("UpdatePlanAction_texts"),
        /**
         * PlannedEventForUpdatePlanEvent
         */
        PLANNED_EVENT_FOR_UPDATE_PLAN_EVENT("PlannedEventForUpdatePlanEvent"),
        /**
         * BasePlan
         */
        BASE_PLAN("BasePlan");
        private String value;

        CoreModelEntity(String value) {
            this.value = value;
        }

        public String getValue() {
            return this.value;
        }

        public String getFullName() {
            return getCoreModelEntityFullName(value);
        }
    }

    public static String getCoreModelEntityFullName(String abbrName) {
        return CORE_MODEL_PREFIX + DOT + abbrName;
    }

    public enum MasterDataEntity {
        /**
         * Location
         */
        LOCATION("Location"),
        /**
         * Product
         */
        PRODUCT("Product"),
        /**
         * BusinessPartner
         */
        BUSINESS_PARTNER("BusinessPartner");

        private String value;

        MasterDataEntity(String value) {
            this.value = value;
        }

        public String getValue() {
            return this.value;
        }

        public String getFullName() {
            return CORE_MODEL_PREFIX + DOT + value;
        }
    }

    public enum PermissionEnum {
        /**
         * Read
         */
        READ("Read"),
        /**
         * Report
         */
        REPORT("Report"),
        /**
         * Observe
         */
        OBSERVE("Observe");

        private String value;

        PermissionEnum(String value) {
            this.value = value;
        }

        public String getValue() {
            return this.value;
        }
    }

    public enum PrincipalTypeEnum {
        /**
         * LBNID
         */
        LBNID("LBNID");

        private String value;

        PrincipalTypeEnum(String value) {
            this.value = value;
        }

        public String getValue() {
            return this.value;
        }
    }

    public enum BasePlanField {
        /**
         * eventType
         */
        EVENT_TYPE(ENTITY_EVENT_TYPE),
        /**
         * locationAltKey
         */
        LOCATION_ALT_KEY("locationAltKey"),
        /**
         * eventMatchKey
         */
        EVENT_MATCH_KEY("eventMatchKey"),
        /**
         * longitude
         */
        LONGITUDE("longitude"),
        /**
         * latitude
         */
        LATITUDE("latitude"),
        /**
         * isFinalPlannedEvent
         */
        IS_FINAL_PLANNED_EVENT("isFinalPlannedEvent"),
        /**
         * plannedTechnicalTimestamp
         */
        PLANNED_TECHNICAL_TIMESTAMP("plannedTechnicalTimestamp"),
        /**
         * plannedTechTsEarliest
         */
        PLANNED_TECH_TS_EARLIEST("plannedTechTsEarliest"),
        /**
         * plannedTechTsLatest
         */
        PLANNED_TECH_TS_LATEST("plannedTechTsLatest"),
        /**
         * plannedBusinessTimestamp
         */
        PLANNED_BUSINESS_TIMESTAMP("plannedBusinessTimestamp"),
        /**
         * plannedBizTsEarliest
         */
        PLANNED_BIZ_TS_EARLIEST("plannedBizTsEarliest"),
        /**
         * plannedBizTsLatest
         */
        PLANNED_BIZ_TS_LATEST("plannedBizTsLatest"),
        /**
         * plannedBusinessTimeZone
         */
        PLANNED_BUSINESS_TIME_ZONE("plannedBusinessTimeZone");

        private String value;

        BasePlanField(String value) {
            this.value = value;
        }

        public String getValue() {
            return this.value;
        }
    }

}