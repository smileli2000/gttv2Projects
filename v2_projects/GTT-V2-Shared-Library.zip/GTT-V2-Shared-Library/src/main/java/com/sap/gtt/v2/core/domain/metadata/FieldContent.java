package com.sap.gtt.v2.core.domain.metadata;

import java.io.Serializable;

/**
 * @author I321712
 */
public class FieldContent implements Serializable {
    private static final long serialVersionUID = -4291096480505464104L;
    private String minimum;
    private boolean exclusiveMinimum;
    private String maximum;
    private boolean exclusiveMaximum;
    private String multipleOf;
    private Integer minLength;
    private String pattern;
    private Integer minItems;
    private Integer maxItems;

    public String getMinimum() {
        return minimum;
    }

    public void setMinimum(String minimum) {
        this.minimum = minimum;
    }

    public boolean isExclusiveMinimum() {
        return exclusiveMinimum;
    }

    public void setExclusiveMinimum(boolean exclusiveMinimum) {
        this.exclusiveMinimum = exclusiveMinimum;
    }

    public String getMaximum() {
        return maximum;
    }

    public void setMaximum(String maximum) {
        this.maximum = maximum;
    }

    public boolean isExclusiveMaximum() {
        return exclusiveMaximum;
    }

    public void setExclusiveMaximum(boolean exclusiveMaximum) {
        this.exclusiveMaximum = exclusiveMaximum;
    }

    public String getMultipleOf() {
        return multipleOf;
    }

    public void setMultipleOf(String multipleOf) {
        this.multipleOf = multipleOf;
    }

    public Integer getMinLength() {
        return minLength;
    }

    public void setMinLength(Integer minLength) {
        this.minLength = minLength;
    }

    public String getPattern() {
        return pattern;
    }

    public void setPattern(String pattern) {
        this.pattern = pattern;
    }

    public Integer getMinItems() {
        return minItems;
    }

    public void setMinItems(Integer minItems) {
        this.minItems = minItems;
    }

    public Integer getMaxItems() {
        return maxItems;
    }

    public void setMaxItems(Integer maxItems) {
        this.maxItems = maxItems;
    }
}
