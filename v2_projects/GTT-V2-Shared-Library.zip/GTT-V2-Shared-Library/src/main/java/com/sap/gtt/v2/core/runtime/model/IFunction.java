package com.sap.gtt.v2.core.runtime.model;

import com.sap.gtt.v2.core.rule.impl.MemoryBlockException;

import java.util.List;

public interface IFunction {

	public IPropertyValue execute(IPropertyValue callerObject, List<IPropertyValue> args) throws MemoryBlockException;
}
