package com.sap.gtt.v2.core.domain.metadata;

import org.apache.commons.lang3.StringUtils;

import java.io.Serializable;
import java.util.StringJoiner;

/**
 * Physical name for a given entity
 *
 * @author I321712
 */
public class PhysicalName implements Serializable {
    private static final long serialVersionUID = 5245698743784490396L;

    private String name;
    private String corePhysicalName;
    private String extendedPhysicalName;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCorePhysicalName() {
        return corePhysicalName;
    }

    public void setCorePhysicalName(String corePhysicalName) {
        this.corePhysicalName = corePhysicalName;
    }

    public String getExtendedPhysicalName() {
        return extendedPhysicalName;
    }

    public void setExtendedPhysicalName(String extendedPhysicalName) {
        this.extendedPhysicalName = extendedPhysicalName;
    }

    public boolean isExtensionEntity() {
        String coreName = getCorePhysicalName();
        if (StringUtils.isBlank(coreName)) {
            return false;
        }
        return !StringUtils.equalsIgnoreCase(getName(), coreName);
    }

    public boolean isCoreExtensionEntity() {
        return StringUtils.equalsIgnoreCase(getName(), getCorePhysicalName())
                && StringUtils.isNotBlank(getExtendedPhysicalName());
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", PhysicalName.class.getSimpleName() + "[", "]")
                .add("name='" + name + "'")
                .add("corePhysicalName='" + corePhysicalName + "'")
                .add("extendedPhysicalName='" + extendedPhysicalName + "'")
                .toString();
    }
}