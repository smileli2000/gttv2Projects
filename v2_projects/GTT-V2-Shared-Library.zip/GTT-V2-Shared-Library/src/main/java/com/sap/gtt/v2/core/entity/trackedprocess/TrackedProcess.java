package com.sap.gtt.v2.core.entity.trackedprocess;

import com.sap.gtt.v2.configuration.ISAPCloudPlatformAgent;
import com.sap.gtt.v2.core.domain.trackedprocess.CorrelatedEvent;
import com.sap.gtt.v2.core.domain.trackedprocess.LifeCycleStatus;
import com.sap.gtt.v2.core.domain.trackedprocess.ProcessStatus;
import com.sap.gtt.v2.core.entity.Auditable;
import com.sap.gtt.v2.core.runtime.model.*;
import com.sap.gtt.v2.core.service.MessageUtil;
import com.sap.gtt.v2.util.GTTUtils;
import com.sap.gtt.v2.util.SpringContextUtils;

import org.springframework.util.CollectionUtils;

import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;


public class TrackedProcess extends ObjectValue implements Auditable {
	public static final String ID = "id";
	public static final String VERSION = "version";
	public static final String SUBACCOUNTID = "subaccountId";
	public static final String CLONEINSTANCEID = "cloneInstanceId";
	public static final String TRACKED_PROCESS_TYPE = "trackedProcessType";
	public static final String SCHEME = "scheme";
	public static final String PARTYID = "partyId";
	public static final String LOGICAL_SYSTEM = "logicalSystem";
	public static final String TRACKING_ID_TYPE = "trackingIdType";
	public static final String TRACKING_ID = "trackingId";
	public static final String ALT_KEY = "altKey";
	public static final String LIFE_CYCLE_STATUS = "lifeCycleStatus_code";
	public static final String TRACKING_IDS = "trackingIds";
	public static final String PROCESS_EVENT_DIRECTORIES = "processEvents";
	public static final String PLANNED_EVENTS = "plannedEvents";
	public static final String PROCESS_STATUS = "processStatus_code";
	public static final String LAST_CHANGED_AT_BUSINESS_TIME = "lastChangedAtBusinessTime";
	private static final String FUNCTION_GET_PLANNED_EVENTS_SORT_BY_TIME = "getPlannedEventsSortByPlannedBusinessTime";
	private static final String FUNCTION_CORRELATED_EVENT_EXCLUDE_TYPES = "getCorrelatedEventsForCurrentTPExcludeEventTypes";
	private static final String FUNCTION_CORRELATED_EVENT_INCLUDE_TYPES = "getCorrelatedEventsForCurrentTPIncludeEventTypes";
	private static final String FUNCTION_LAST_CORRELATED_EVENT_INCLUDE_TYPES = "getLastCorrelatedEventForCurrentTPIncludeEventTypes";
	private static final String FUNCTION_GET_FINAL_PLANNED_EVENTS = "getFinalPlannedEvents";
	private static final String FUNCTION_CALCULATE_PROCESS_STATUS="calculateProcessStatus";
	
    public static final String BUSINESS_ACTIVE = "BUSINESS_ACTIVE";
    public static final String END_OF_BUSINESS = "END_OF_BUSINESS";
    public static final String END_OF_PURPOSE = "END_OF_PURPOSE";
    public static final String END_OF_RETENTION = "END_OF_RETENTION";

	protected static final Map<String, FunctionInterfaceDef> functionDefs = new HashMap<>();

	static{
		functionDefs.putAll(ObjectValue.functionDefs);


		List<Class<? extends IPropertyValue>> argumentEmptyType = new ArrayList<>();
		FunctionInterfaceDef getFinalPlannedEvent = new FunctionInterfaceDef(FunctionInterfaceDef.Category.SYSTEM, FUNCTION_GET_FINAL_PLANNED_EVENTS, argumentEmptyType,
				((callerObject, args) -> {
					TrackedProcess trackedProcess = (TrackedProcess)callerObject;
					List<PlannedEvent> finalPlannedEvents = trackedProcess.getFinalPlannedEvents();
					ListValue plannedEventListValue = ListValue.valueOfEmpty();
					if(finalPlannedEvents != null){
						finalPlannedEvents.stream().forEachOrdered(plannedEvent -> plannedEventListValue.add(plannedEvent));
					}
					return plannedEventListValue;
				}));
		functionDefs.put(getFinalPlannedEvent.name,getFinalPlannedEvent);
		
		List<Class<? extends IPropertyValue>> argumentTypes = new ArrayList<>();
		argumentTypes.add(BooleanValue.class);
		FunctionInterfaceDef getLastPlannedEventDef = new FunctionInterfaceDef(
				FunctionInterfaceDef.Category.SYSTEM, FUNCTION_GET_PLANNED_EVENTS_SORT_BY_TIME, argumentTypes,
				(callerObject, args) -> {
					TrackedProcess trackedProcess = (TrackedProcess)callerObject;
					BooleanValue flag = (BooleanValue) args.get(0);
					List<PlannedEvent> plannedEventsList = trackedProcess.getPlannedEventsSortByPlannedBusinessTime(flag.getInternalValue());
					ListValue plannedEventListValue = ListValue.valueOfEmpty();
					if(plannedEventsList != null){
						plannedEventsList.stream().forEachOrdered(plannedEvent -> plannedEventListValue.add(plannedEvent));
					}
					return plannedEventListValue;
				});
		functionDefs.put(getLastPlannedEventDef.name, getLastPlannedEventDef);


		List<Class<? extends IPropertyValue>> argumentTypesForGetCorrelatedEvent = new ArrayList<>();
		argumentTypesForGetCorrelatedEvent.add(ListValue.class);
		FunctionInterfaceDef getCorrelatedEventsForCurrentTPExcludeEventTypesDef = new FunctionInterfaceDef(
				FunctionInterfaceDef.Category.SYSTEM, FUNCTION_CORRELATED_EVENT_EXCLUDE_TYPES, argumentTypesForGetCorrelatedEvent,
				(callerObject, args) -> {
					TrackedProcess trackedProcess = (TrackedProcess) callerObject;
					GTTUtils.BusinessOperator businessOperator = SpringContextUtils.getBean(ISAPCloudPlatformAgent.ICurrentAccessContext.class).createBusinessOperator();
					List<String> argument = (List<String>) args.get(0).getInternalValue();
					CorrelatedEvent correlatedEvent = businessOperator.getEventManagement().getCorrelatedEventsExcludeEventTypes(trackedProcess.getId(), argument);
					return correlatedEvent;
				});
		functionDefs.put(getCorrelatedEventsForCurrentTPExcludeEventTypesDef.name, getCorrelatedEventsForCurrentTPExcludeEventTypesDef);


		FunctionInterfaceDef getCorrelatedEventsForCurrentTPIncludeEventTypesDef = new FunctionInterfaceDef(
				FunctionInterfaceDef.Category.SYSTEM, FUNCTION_CORRELATED_EVENT_INCLUDE_TYPES, argumentTypesForGetCorrelatedEvent,
				(callerObject, args) -> {
					TrackedProcess trackedProcess = (TrackedProcess) callerObject;
					GTTUtils.BusinessOperator businessOperator = SpringContextUtils.getBean(ISAPCloudPlatformAgent.ICurrentAccessContext.class).createBusinessOperator();
					List<String> argument = (List<String>) args.get(0).getInternalValue();
					CorrelatedEvent correlatedEvent = businessOperator.getEventManagement().getCorrelatedEventsIncludeEventTypes(trackedProcess.getId(), argument);
					return correlatedEvent;
				});
		functionDefs.put(getCorrelatedEventsForCurrentTPIncludeEventTypesDef.name, getCorrelatedEventsForCurrentTPIncludeEventTypesDef);
		
		FunctionInterfaceDef getLastCorrelatedEventForCurrentTPIncludeEventTypesDef = new FunctionInterfaceDef(
				FunctionInterfaceDef.Category.SYSTEM, FUNCTION_LAST_CORRELATED_EVENT_INCLUDE_TYPES, argumentTypesForGetCorrelatedEvent,
				(callerObject, args) -> {
					TrackedProcess trackedProcess = (TrackedProcess) callerObject;
					GTTUtils.BusinessOperator businessOperator = SpringContextUtils.getBean(ISAPCloudPlatformAgent.ICurrentAccessContext.class).createBusinessOperator();
					List<String> argument = (List<String>) args.get(0).getInternalValue();
					Event actualEvent = businessOperator.getEventManagement().getLastCorrelatedEventIncludeEventTypes(trackedProcess.getId(), trackedProcess.getTrackedProcessType(), argument);
					return actualEvent;
				});
		functionDefs.put(getLastCorrelatedEventForCurrentTPIncludeEventTypesDef.name, getLastCorrelatedEventForCurrentTPIncludeEventTypesDef);
		
		List<Class<? extends IPropertyValue>> argumentTypesForCalculateProcessStatus = new ArrayList<>();
		argumentTypesForCalculateProcessStatus.add(PlannedEvent.class);
		FunctionInterfaceDef calculateProcessStatusDef = new FunctionInterfaceDef(FunctionInterfaceDef.Category.SYSTEM, FUNCTION_CALCULATE_PROCESS_STATUS, argumentTypesForCalculateProcessStatus,
				(callerObject, args) -> {
					TrackedProcess trackedProcess = (TrackedProcess)callerObject;
					PlannedEvent plannedEvent =  (PlannedEvent) args.get(0);
					ProcessStatus processStatus = MessageUtil.getProcessStatus(trackedProcess,plannedEvent,plannedEvent.getEventType());
					if(processStatus != null) {
						return StringValue.valueOf(processStatus.name());
					} else {
						return null;
					}
				});
		functionDefs.put(calculateProcessStatusDef.name, calculateProcessStatusDef);
	}

	@Override
	protected Map<String, FunctionInterfaceDef> getFunctionDefs(){
		return functionDefs;
	}

	public UUID getIdAsInternalValue() {
		return this.getId().getInternalValue();
	}

	public String getProcessStatus(){
		return this.getValueAsString(PROCESS_STATUS);
	}

	public void setProcessStatus(String processStatus){
		this.setValue(PROCESS_STATUS,processStatus);
	}

	public UUIDValue getId(){
		return (UUIDValue)this.getValue(ID);
	}
	public void setId(UUID id) {
		this.setValue(ID, id);
	}

	public int getVersion(){
		return this.getValueAsInteger(VERSION);
	}

	public void setVersion(int version){
		this.setValue(VERSION, version);
	}

	public void increaseVersion(){
		int version = this.getVersion();
		version = version == Integer.MAX_VALUE ? 0 : (version + 1);
		this.setVersion(version);
	}

	public UUID getSubaccountId() {
		return this.getValueAsUUID(SUBACCOUNTID);
	}

	public void setSubaccountId(UUID subaccountId) {
		this.setValue(SUBACCOUNTID, subaccountId);
	}

	public UUID getCloneInstanceId() {
		return this.getValueAsUUID(CLONEINSTANCEID);
	}

	public void setCloneInstanceId(UUID cloneInstanceId) {
		this.setValue(CLONEINSTANCEID, cloneInstanceId);
	}

	public String getTrackedProcessType() {
		return this.getValueAsString(TRACKED_PROCESS_TYPE);
	}

	public void setTrackedProcessType(String trackedProcessType) {
		this.setValue(TRACKED_PROCESS_TYPE, trackedProcessType);
	}

	public String getScheme() {
		return this.getValueAsString(SCHEME);
	}

	public void setScheme(String scheme) {
		this.setValue(SCHEME,StringValue.valueOf(scheme));
	}

	public String getPartyId() {
		return this.getValueAsString(PARTYID);
	}

	public void setPartyId(String partyId) {
		this.setValue(PARTYID, partyId);
	}

	public String getLogicalSystem() {
		return this.getValueAsString(LOGICAL_SYSTEM);
	}

	public void setLogicalSystem(String logicalSystem) {
		this.setValue(LOGICAL_SYSTEM, StringValue.valueOf(logicalSystem));
	}

	public String getTrackingIdType() {
		return this.getValueAsString(TRACKING_ID_TYPE);
	}

	public void setTrackingIdType(String trackingIdType) {
		this.setValue(TRACKING_ID_TYPE, StringValue.valueOf(trackingIdType));
	}

	public String getTrackingId() {
		return this.getValueAsString(TRACKING_ID);
	}

	public void setTrackingId(String trackingId) {
		this.setValue(TRACKING_ID, StringValue.valueOf(trackingId));
	}

	public String getAltKey() {
		return this.getValueAsString(ALT_KEY);
	}

	public void setAltKey(String altKey) {
		this.setValue(ALT_KEY, StringValue.valueOf(altKey));
	}

	public LifeCycleStatus getLifeCycleStatus() {
		return LifeCycleStatus.valueOf(this.getValueAsString(LIFE_CYCLE_STATUS));
	}

	public void setLifeCycleStatus(LifeCycleStatus lifeCycleStatus) {
		this.setValue(LIFE_CYCLE_STATUS, lifeCycleStatus.toString());
	}

	public Instant getLastChangedAtBusinessTime() {
		return this.getValueAsTimeStamp(LAST_CHANGED_AT_BUSINESS_TIME);
	}

	public void setLastChangedAtBusinessTime(Instant lastChangedAtBusinessTime) {
		this.setValue(LAST_CHANGED_AT_BUSINESS_TIME, lastChangedAtBusinessTime);
	}

	@Override
	public Instant getCreationDateTime() {
		return this.getValueAsTimeStamp(CREATION_DATE_TIME);
	}

	@Override
	public void setCreationDateTime(Instant creationDateTime) {
		this.setValue(CREATION_DATE_TIME, creationDateTime);
	}

	@Override
	public Instant getLastChangedDateTime() {
		return this.getValueAsTimeStamp(LAST_CHANGED_DATE_TIME);
	}

	@Override
	public void setLastChangedDateTime(Instant lastChangedDateTime) {
		this.setValue(LAST_CHANGED_DATE_TIME, lastChangedDateTime);
	}

	@Override
	public String getCreatedByUser() {
		return this.getValueAsString(CREATED_BY_USER);
	}

	@Override
	public void setCreatedByUser(String createdByUser) {
		this.setValue(CREATED_BY_USER, createdByUser);
	}

	@Override
	public String getLastChangedByUser() {
		return this.getValueAsString(LAST_CHANGED_BY_USER);
	}

	@Override
	public void setLastChangedByUser(String lastChangedByUser) {
		this.setValue(LAST_CHANGED_BY_USER, lastChangedByUser);
	}

	public List<QualifiedTrackingId> getTrackingIds() {
		List<QualifiedTrackingId> trackingIds = new ArrayList<>();
		List<IPropertyValue> list = getValueAsList(TRACKING_IDS);
		if (!CollectionUtils.isEmpty(list)) {
			trackingIds = new ArrayList<>(list.size());
			for (IPropertyValue value : list) {
				QualifiedTrackingId qualifiedTrackingId = (QualifiedTrackingId)value;
				qualifiedTrackingId.setMetadata(((ObjectValue) value).getMetadata());
				trackingIds.add(qualifiedTrackingId);
			}
		}
		return trackingIds;
	}

	public void setTrackingIds(List<QualifiedTrackingId> trackingIds) {
		List<IPropertyValue> list = new ArrayList<>();
		for(QualifiedTrackingId qualifiedTrackingId : trackingIds) {
			list.add(qualifiedTrackingId);
		}
		this.setValue(TRACKING_IDS, list);
	}

	public List<ProcessEventDirectory> getPEDs() {
		List<ProcessEventDirectory> processEventDirectories = new ArrayList<>();
		List<IPropertyValue> list = getValueAsList(PROCESS_EVENT_DIRECTORIES);
		if (!CollectionUtils.isEmpty(list)) {
			processEventDirectories = new ArrayList<>(list.size());
			for (IPropertyValue value : list) {
				ProcessEventDirectory processEventDirectory = (ProcessEventDirectory)value;
				processEventDirectory.setMetadata(((ObjectValue) value).getMetadata());
				processEventDirectories.add(processEventDirectory);
			}
		}
		return processEventDirectories;
	}

	public void setPEDs(List<ProcessEventDirectory> processEventDirectories) {
		List<IPropertyValue> list = new ArrayList<>();
		for(ProcessEventDirectory processEventDirectory : processEventDirectories) {
			list.add(processEventDirectory);
		}
		this.setValue(PROCESS_EVENT_DIRECTORIES, list);
	}

	public List<PlannedEvent> getPlannedEvents() {
		List<PlannedEvent> plannedEvents = new ArrayList<>();
		List<IPropertyValue> list = getValueAsList(PLANNED_EVENTS);
		if (!CollectionUtils.isEmpty(list)) {
			plannedEvents = new ArrayList<>(list.size());
			for (IPropertyValue value : list) {
				PlannedEvent pe = (PlannedEvent)value;
				pe.setMetadata(((ObjectValue) value).getMetadata());
				plannedEvents.add(pe);
			}
		}
		return plannedEvents;
	}

	public void setPlannedEvents(List<PlannedEvent> plannedEvents) {
		List<IPropertyValue> list = new ArrayList<>();
		for(PlannedEvent plannedEvent : plannedEvents) {
			list.add(plannedEvent);
		}
		this.setValue(PLANNED_EVENTS, list);
	}


    public List<PlannedEvent> getPlannedEventsSortByPlannedBusinessTime(Boolean withNullPlannedBusinessTimeEvents){
	    if (!isValueProvided(PLANNED_EVENTS)) {
	        return null;
        } else {
            List<PlannedEvent> plannedEvents = getPlannedEvents();
            if(plannedEvents !=null && !plannedEvents.isEmpty()){
                List<PlannedEvent> plannedEventsWithPlannedBusinessTime =  plannedEvents.stream()
                        .filter(plannedEvent-> !MessageUtil.isNull(plannedEvent, PlannedEvent.PLANNED_BUSINESS_TIMESTAMP))
						.collect(Collectors.toList());
                List<PlannedEvent> plannedEventsWithNullPlannedBusinessTime = plannedEvents.stream()
						.filter(plannedEvent-> MessageUtil.isNull(plannedEvent, PlannedEvent.PLANNED_BUSINESS_TIMESTAMP))
						.collect(Collectors.toList());
                Collections.sort(plannedEventsWithPlannedBusinessTime, (event1, event2) -> {
                    Instant event1Time = event1.getPlannedBusinessTimestamp();
                    Instant event2Time = event2.getPlannedBusinessTimestamp();
                    if (event1Time.equals(event2Time)) {
                        Integer event1Sequence = event1.getPayloadSequence();
                        Integer event2Sequence = event2.getPayloadSequence();
                        return event1Sequence.compareTo(event2Sequence);
                    } else {
                        return event1Time.compareTo(event2Time);
                    }
                });
                if(!withNullPlannedBusinessTimeEvents){
					return plannedEventsWithPlannedBusinessTime;
				}else {
                	List<PlannedEvent> sortedPlannedEvents = new ArrayList<>();
                	sortedPlannedEvents.addAll(plannedEventsWithPlannedBusinessTime);
                	sortedPlannedEvents.addAll(plannedEventsWithNullPlannedBusinessTime);
					return sortedPlannedEvents;
				}
            }
            return Collections.emptyList();
        }
    }

    public List<PlannedEvent> getFinalPlannedEvents(){
		if (!isValueProvided(PLANNED_EVENTS)) {
			return null;
		} else {
			List<PlannedEvent> plannedEvents = getPlannedEvents();
			if(plannedEvents !=null && !plannedEvents.isEmpty()){
				List<PlannedEvent> finalPlannedEventsList = plannedEvents.stream()
						.filter(plannedEvent -> plannedEvent.isValueProvided(PlannedEvent.IS_FINAL_PLANNED_EVENT) && plannedEvent.getIsFinalPlannedEvent()!= null? plannedEvent.getIsFinalPlannedEvent():false)
						.collect(Collectors.toList());
				return finalPlannedEventsList;
			}
			return Collections.emptyList();
		}
	}
    
	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if (o == null) {
			return false;
		}
		if (this.getClass() != o.getClass()) {
			return false;
		}
		TrackedProcess that = (TrackedProcess) o;
		return getId().equals(that.getId());
	}

	@Override
	public int hashCode() {
		return Objects.hash(getId());
	}
}
