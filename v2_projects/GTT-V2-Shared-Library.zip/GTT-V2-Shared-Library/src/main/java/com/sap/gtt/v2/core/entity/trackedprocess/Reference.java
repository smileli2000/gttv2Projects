package com.sap.gtt.v2.core.entity.trackedprocess;

import com.sap.gtt.v2.core.runtime.model.IPropertyValue;
import com.sap.gtt.v2.core.runtime.model.ObjectValue;

import java.time.Instant;
import java.util.Map;
import java.util.UUID;


public class Reference extends ObjectValue {
	public static final String ID = "id";
	public static final String EVENTID = "event_id";
	public static final String REFERENCE_TYPE = "referenceType_code";
	public static final String ALTKEY = "altKey";
	public static final String VALID_FROM = "validFrom";
	public static final String VALID_TO = "validTo";
	public static final String ACTION = "action_code";

	public Reference(Map<String, IPropertyValue> internalValue) {
		super(internalValue);
	}

	public Reference() {}

	public UUID getId() {
		return this.getValueAsUUID(ID);
	}

	public void setId(UUID id) {
		this.setValue(ID, id);
	}

	public UUID getEventId() {
		return this.getValueAsUUID(EVENTID);
	}

	public void setEventId(UUID eventId) {
		this.setValue(EVENTID, eventId);
	}

	public Instant getValidFrom() {
		return this.getValueAsTimeStamp(VALID_FROM);
	}

	public void setValidFrom(Instant validFrom) {
		this.setValue(VALID_FROM, validFrom);
	}

	public Instant getValidTo() {
		return this.getValueAsTimeStamp(VALID_TO);
	}

	public void setValidTo(Instant validTo) {
		this.setValue(VALID_TO, validTo);
	}

	public String getAltKey() {
		return this.getValueAsString(ALTKEY);
	}

	public void setAltKey(String altKey) {
		this.setValue(ALTKEY, altKey);
	}

	public String getReferenceType() {
		return this.getValueAsString(REFERENCE_TYPE);
	}

	public void setReferenceType(String referenceType) {
		this.setValue(REFERENCE_TYPE, referenceType);
	}

	public String getAction() {
		return this.getValueAsString(ACTION);
	}

	public void setAction(String action) {
		this.setValue(ACTION, action);
	}
}
