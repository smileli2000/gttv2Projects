package com.sap.gtt.v2.core.rule.impl;

public class MemoryBlockException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = -7781938235482598401L;

	public MemoryBlockException(String message) {
		super(message);
	}

}
