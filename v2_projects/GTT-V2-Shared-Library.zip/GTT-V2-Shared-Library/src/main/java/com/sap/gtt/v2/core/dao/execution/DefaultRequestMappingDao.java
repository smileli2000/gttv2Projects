package com.sap.gtt.v2.core.dao.execution;

import com.sap.gtt.v2.core.entity.execution.RequestMapping;
import com.sap.gtt.v2.exception.DBException;
import com.sap.gtt.v2.util.DBUtils;
import com.sap.gtt.v2.util.SpringContextUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

/**
 * @author I302310
 */
@Repository(DefaultRequestMappingDao.BEAN_NAME)
public class DefaultRequestMappingDao implements IRequestMappingDao {
    public static final String BEAN_NAME = "com.sap.gtt.v2.core.dao.execution.DefaultRequestMappingDao";
    public static final String TABLE_NAME = "REQUEST_MAPPING";
    public static final int MAX_LENGTH_MESSAGE = 255;

    public static final String ID = "ID";
    public static final String ROOT_REQUEST_ID = "ROOT_REQUEST_ID";
    public static final String REQUEST_ID = "REQUEST_ID";
    public static final String TARGET_ID = "TARGET_ID";
    public static final String MESSAGE_TYPE = "MESSAGE_TYPE";
    public static final String MESSAGE = "MESSAGE";
    public static final String MESSAGE_DETAIL = "MESSAGE_DETAIL";

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public static DefaultRequestMappingDao getInstance() {
        return (DefaultRequestMappingDao) SpringContextUtils.getBean(BEAN_NAME);
    }

    @Override
    public void insert(RequestMapping requestMapping) {
        StringBuilder sql = new StringBuilder();
        String[] columns = {ID, ROOT_REQUEST_ID, REQUEST_ID, TARGET_ID, MESSAGE_TYPE, MESSAGE, MESSAGE_DETAIL};
        DBUtils.buildInsertSql(TABLE_NAME, columns, sql);
        String message = requestMapping.getMessage();
        if (message != null && message.length() > MAX_LENGTH_MESSAGE) {
            message = message.substring(0, MAX_LENGTH_MESSAGE);
        }
        Object[] args = new Object[]{requestMapping.getId(), requestMapping.getRootRequestId(),
                requestMapping.getRequestId(), requestMapping.getTargetId(), requestMapping.getMessageType(),
                message, requestMapping.getMessageDetail()};
        int affectedRows = jdbcTemplate.update(sql.toString(), args);
        if (affectedRows <= 0) {
            throw new DBException("Insert Execution_Unit data failed. Affected rows " + affectedRows);
        }
    }

    @Override
    public List<RequestMapping> queryRequestMappings(String requestId) {
        List<String> args = new ArrayList<>();
        args.add(requestId);
        StringBuilder sql = new StringBuilder();
        sql.append("select * from ").append(TABLE_NAME)
                .append(" where ")
                .append(ROOT_REQUEST_ID).append("=?");
        return jdbcTemplate.query(sql.toString(), args.toArray(), (rs, rowNum) -> {
            String rs_id = rs.getString(ID);
            String rs_rootRequestId = rs.getString(ROOT_REQUEST_ID);
            String rs_requestId = rs.getString(REQUEST_ID);
            String rs_targetId = rs.getString(TARGET_ID);
            String rs_messageType = rs.getString(MESSAGE_TYPE);
            String rs_message = rs.getString(MESSAGE);
            String rs_detail = rs.getString(MESSAGE_DETAIL);
            return new RequestMapping(rs_id, rs_rootRequestId, rs_requestId, rs_targetId, rs_messageType, rs_message, rs_detail);
        });
    }
}
