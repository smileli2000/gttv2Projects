// Generated from GTTEmbededRuleScript.g4 by ANTLR 4.7.2
package com.sap.gtt.v2.core.rule;
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link GTTEmbededRuleScriptParser}.
 */
public interface GTTEmbededRuleScriptListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link GTTEmbededRuleScriptParser#script}.
	 * @param ctx the parse tree
	 */
	void enterScript(GTTEmbededRuleScriptParser.ScriptContext ctx);
	/**
	 * Exit a parse tree produced by {@link GTTEmbededRuleScriptParser#script}.
	 * @param ctx the parse tree
	 */
	void exitScript(GTTEmbededRuleScriptParser.ScriptContext ctx);
	/**
	 * Enter a parse tree produced by {@link GTTEmbededRuleScriptParser#operationStatement}.
	 * @param ctx the parse tree
	 */
	void enterOperationStatement(GTTEmbededRuleScriptParser.OperationStatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link GTTEmbededRuleScriptParser#operationStatement}.
	 * @param ctx the parse tree
	 */
	void exitOperationStatement(GTTEmbededRuleScriptParser.OperationStatementContext ctx);
	/**
	 * Enter a parse tree produced by {@link GTTEmbededRuleScriptParser#declaration}.
	 * @param ctx the parse tree
	 */
	void enterDeclaration(GTTEmbededRuleScriptParser.DeclarationContext ctx);
	/**
	 * Exit a parse tree produced by {@link GTTEmbededRuleScriptParser#declaration}.
	 * @param ctx the parse tree
	 */
	void exitDeclaration(GTTEmbededRuleScriptParser.DeclarationContext ctx);
	/**
	 * Enter a parse tree produced by {@link GTTEmbededRuleScriptParser#printStatement}.
	 * @param ctx the parse tree
	 */
	void enterPrintStatement(GTTEmbededRuleScriptParser.PrintStatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link GTTEmbededRuleScriptParser#printStatement}.
	 * @param ctx the parse tree
	 */
	void exitPrintStatement(GTTEmbededRuleScriptParser.PrintStatementContext ctx);
	/**
	 * Enter a parse tree produced by {@link GTTEmbededRuleScriptParser#ifStatement}.
	 * @param ctx the parse tree
	 */
	void enterIfStatement(GTTEmbededRuleScriptParser.IfStatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link GTTEmbededRuleScriptParser#ifStatement}.
	 * @param ctx the parse tree
	 */
	void exitIfStatement(GTTEmbededRuleScriptParser.IfStatementContext ctx);
	/**
	 * Enter a parse tree produced by {@link GTTEmbededRuleScriptParser#elseIfStatement}.
	 * @param ctx the parse tree
	 */
	void enterElseIfStatement(GTTEmbededRuleScriptParser.ElseIfStatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link GTTEmbededRuleScriptParser#elseIfStatement}.
	 * @param ctx the parse tree
	 */
	void exitElseIfStatement(GTTEmbededRuleScriptParser.ElseIfStatementContext ctx);
	/**
	 * Enter a parse tree produced by {@link GTTEmbededRuleScriptParser#elseStatement}.
	 * @param ctx the parse tree
	 */
	void enterElseStatement(GTTEmbededRuleScriptParser.ElseStatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link GTTEmbededRuleScriptParser#elseStatement}.
	 * @param ctx the parse tree
	 */
	void exitElseStatement(GTTEmbededRuleScriptParser.ElseStatementContext ctx);
	/**
	 * Enter a parse tree produced by {@link GTTEmbededRuleScriptParser#whileStatement}.
	 * @param ctx the parse tree
	 */
	void enterWhileStatement(GTTEmbededRuleScriptParser.WhileStatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link GTTEmbededRuleScriptParser#whileStatement}.
	 * @param ctx the parse tree
	 */
	void exitWhileStatement(GTTEmbededRuleScriptParser.WhileStatementContext ctx);
	/**
	 * Enter a parse tree produced by {@link GTTEmbededRuleScriptParser#returnStatement}.
	 * @param ctx the parse tree
	 */
	void enterReturnStatement(GTTEmbededRuleScriptParser.ReturnStatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link GTTEmbededRuleScriptParser#returnStatement}.
	 * @param ctx the parse tree
	 */
	void exitReturnStatement(GTTEmbededRuleScriptParser.ReturnStatementContext ctx);
	/**
	 * Enter a parse tree produced by {@link GTTEmbededRuleScriptParser#executionBlock}.
	 * @param ctx the parse tree
	 */
	void enterExecutionBlock(GTTEmbededRuleScriptParser.ExecutionBlockContext ctx);
	/**
	 * Exit a parse tree produced by {@link GTTEmbededRuleScriptParser#executionBlock}.
	 * @param ctx the parse tree
	 */
	void exitExecutionBlock(GTTEmbededRuleScriptParser.ExecutionBlockContext ctx);
	/**
	 * Enter a parse tree produced by {@link GTTEmbededRuleScriptParser#refer}.
	 * @param ctx the parse tree
	 */
	void enterRefer(GTTEmbededRuleScriptParser.ReferContext ctx);
	/**
	 * Exit a parse tree produced by {@link GTTEmbededRuleScriptParser#refer}.
	 * @param ctx the parse tree
	 */
	void exitRefer(GTTEmbededRuleScriptParser.ReferContext ctx);
	/**
	 * Enter a parse tree produced by {@link GTTEmbededRuleScriptParser#qualifiedName}.
	 * @param ctx the parse tree
	 */
	void enterQualifiedName(GTTEmbededRuleScriptParser.QualifiedNameContext ctx);
	/**
	 * Exit a parse tree produced by {@link GTTEmbededRuleScriptParser#qualifiedName}.
	 * @param ctx the parse tree
	 */
	void exitQualifiedName(GTTEmbededRuleScriptParser.QualifiedNameContext ctx);
	/**
	 * Enter a parse tree produced by {@link GTTEmbededRuleScriptParser#functionCall}.
	 * @param ctx the parse tree
	 */
	void enterFunctionCall(GTTEmbededRuleScriptParser.FunctionCallContext ctx);
	/**
	 * Exit a parse tree produced by {@link GTTEmbededRuleScriptParser#functionCall}.
	 * @param ctx the parse tree
	 */
	void exitFunctionCall(GTTEmbededRuleScriptParser.FunctionCallContext ctx);
	/**
	 * Enter a parse tree produced by the {@code referAssign}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#assignStatement}.
	 * @param ctx the parse tree
	 */
	void enterReferAssign(GTTEmbededRuleScriptParser.ReferAssignContext ctx);
	/**
	 * Exit a parse tree produced by the {@code referAssign}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#assignStatement}.
	 * @param ctx the parse tree
	 */
	void exitReferAssign(GTTEmbededRuleScriptParser.ReferAssignContext ctx);
	/**
	 * Enter a parse tree produced by the {@code identifierAssign}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#assignStatement}.
	 * @param ctx the parse tree
	 */
	void enterIdentifierAssign(GTTEmbededRuleScriptParser.IdentifierAssignContext ctx);
	/**
	 * Exit a parse tree produced by the {@code identifierAssign}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#assignStatement}.
	 * @param ctx the parse tree
	 */
	void exitIdentifierAssign(GTTEmbededRuleScriptParser.IdentifierAssignContext ctx);
	/**
	 * Enter a parse tree produced by the {@code exprAtom}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterExprAtom(GTTEmbededRuleScriptParser.ExprAtomContext ctx);
	/**
	 * Exit a parse tree produced by the {@code exprAtom}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitExprAtom(GTTEmbededRuleScriptParser.ExprAtomContext ctx);
	/**
	 * Enter a parse tree produced by the {@code boolGe}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterBoolGe(GTTEmbededRuleScriptParser.BoolGeContext ctx);
	/**
	 * Exit a parse tree produced by the {@code boolGe}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitBoolGe(GTTEmbededRuleScriptParser.BoolGeContext ctx);
	/**
	 * Enter a parse tree produced by the {@code boolNotEq}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterBoolNotEq(GTTEmbededRuleScriptParser.BoolNotEqContext ctx);
	/**
	 * Exit a parse tree produced by the {@code boolNotEq}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitBoolNotEq(GTTEmbededRuleScriptParser.BoolNotEqContext ctx);
	/**
	 * Enter a parse tree produced by the {@code boolOr}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterBoolOr(GTTEmbededRuleScriptParser.BoolOrContext ctx);
	/**
	 * Exit a parse tree produced by the {@code boolOr}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitBoolOr(GTTEmbededRuleScriptParser.BoolOrContext ctx);
	/**
	 * Enter a parse tree produced by the {@code boolLe}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterBoolLe(GTTEmbededRuleScriptParser.BoolLeContext ctx);
	/**
	 * Exit a parse tree produced by the {@code boolLe}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitBoolLe(GTTEmbededRuleScriptParser.BoolLeContext ctx);
	/**
	 * Enter a parse tree produced by the {@code mathUnitary}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterMathUnitary(GTTEmbededRuleScriptParser.MathUnitaryContext ctx);
	/**
	 * Exit a parse tree produced by the {@code mathUnitary}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitMathUnitary(GTTEmbededRuleScriptParser.MathUnitaryContext ctx);
	/**
	 * Enter a parse tree produced by the {@code boolReverse}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterBoolReverse(GTTEmbededRuleScriptParser.BoolReverseContext ctx);
	/**
	 * Exit a parse tree produced by the {@code boolReverse}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitBoolReverse(GTTEmbededRuleScriptParser.BoolReverseContext ctx);
	/**
	 * Enter a parse tree produced by the {@code mathPow}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterMathPow(GTTEmbededRuleScriptParser.MathPowContext ctx);
	/**
	 * Exit a parse tree produced by the {@code mathPow}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitMathPow(GTTEmbededRuleScriptParser.MathPowContext ctx);
	/**
	 * Enter a parse tree produced by the {@code exprQulifiedName}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterExprQulifiedName(GTTEmbededRuleScriptParser.ExprQulifiedNameContext ctx);
	/**
	 * Exit a parse tree produced by the {@code exprQulifiedName}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitExprQulifiedName(GTTEmbededRuleScriptParser.ExprQulifiedNameContext ctx);
	/**
	 * Enter a parse tree produced by the {@code boolAnd}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterBoolAnd(GTTEmbededRuleScriptParser.BoolAndContext ctx);
	/**
	 * Exit a parse tree produced by the {@code boolAnd}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitBoolAnd(GTTEmbededRuleScriptParser.BoolAndContext ctx);
	/**
	 * Enter a parse tree produced by the {@code exprParens}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterExprParens(GTTEmbededRuleScriptParser.ExprParensContext ctx);
	/**
	 * Exit a parse tree produced by the {@code exprParens}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitExprParens(GTTEmbededRuleScriptParser.ExprParensContext ctx);
	/**
	 * Enter a parse tree produced by the {@code mathAddSub}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterMathAddSub(GTTEmbededRuleScriptParser.MathAddSubContext ctx);
	/**
	 * Exit a parse tree produced by the {@code mathAddSub}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitMathAddSub(GTTEmbededRuleScriptParser.MathAddSubContext ctx);
	/**
	 * Enter a parse tree produced by the {@code boolLt}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterBoolLt(GTTEmbededRuleScriptParser.BoolLtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code boolLt}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitBoolLt(GTTEmbededRuleScriptParser.BoolLtContext ctx);
	/**
	 * Enter a parse tree produced by the {@code boolGt}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterBoolGt(GTTEmbededRuleScriptParser.BoolGtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code boolGt}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitBoolGt(GTTEmbededRuleScriptParser.BoolGtContext ctx);
	/**
	 * Enter a parse tree produced by the {@code boolEq}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterBoolEq(GTTEmbededRuleScriptParser.BoolEqContext ctx);
	/**
	 * Exit a parse tree produced by the {@code boolEq}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitBoolEq(GTTEmbededRuleScriptParser.BoolEqContext ctx);
	/**
	 * Enter a parse tree produced by the {@code mathMulDiv}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterMathMulDiv(GTTEmbededRuleScriptParser.MathMulDivContext ctx);
	/**
	 * Exit a parse tree produced by the {@code mathMulDiv}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitMathMulDiv(GTTEmbededRuleScriptParser.MathMulDivContext ctx);
	/**
	 * Enter a parse tree produced by the {@code exprFunctionCall}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterExprFunctionCall(GTTEmbededRuleScriptParser.ExprFunctionCallContext ctx);
	/**
	 * Exit a parse tree produced by the {@code exprFunctionCall}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitExprFunctionCall(GTTEmbededRuleScriptParser.ExprFunctionCallContext ctx);
	/**
	 * Enter a parse tree produced by the {@code integerLiteral}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#atom}.
	 * @param ctx the parse tree
	 */
	void enterIntegerLiteral(GTTEmbededRuleScriptParser.IntegerLiteralContext ctx);
	/**
	 * Exit a parse tree produced by the {@code integerLiteral}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#atom}.
	 * @param ctx the parse tree
	 */
	void exitIntegerLiteral(GTTEmbededRuleScriptParser.IntegerLiteralContext ctx);
	/**
	 * Enter a parse tree produced by the {@code decimalLiteral}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#atom}.
	 * @param ctx the parse tree
	 */
	void enterDecimalLiteral(GTTEmbededRuleScriptParser.DecimalLiteralContext ctx);
	/**
	 * Exit a parse tree produced by the {@code decimalLiteral}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#atom}.
	 * @param ctx the parse tree
	 */
	void exitDecimalLiteral(GTTEmbededRuleScriptParser.DecimalLiteralContext ctx);
	/**
	 * Enter a parse tree produced by the {@code boolLiteral}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#atom}.
	 * @param ctx the parse tree
	 */
	void enterBoolLiteral(GTTEmbededRuleScriptParser.BoolLiteralContext ctx);
	/**
	 * Exit a parse tree produced by the {@code boolLiteral}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#atom}.
	 * @param ctx the parse tree
	 */
	void exitBoolLiteral(GTTEmbededRuleScriptParser.BoolLiteralContext ctx);
	/**
	 * Enter a parse tree produced by the {@code stringLiteral}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#atom}.
	 * @param ctx the parse tree
	 */
	void enterStringLiteral(GTTEmbededRuleScriptParser.StringLiteralContext ctx);
	/**
	 * Exit a parse tree produced by the {@code stringLiteral}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#atom}.
	 * @param ctx the parse tree
	 */
	void exitStringLiteral(GTTEmbededRuleScriptParser.StringLiteralContext ctx);
	/**
	 * Enter a parse tree produced by the {@code arrayLiteral}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#atom}.
	 * @param ctx the parse tree
	 */
	void enterArrayLiteral(GTTEmbededRuleScriptParser.ArrayLiteralContext ctx);
	/**
	 * Exit a parse tree produced by the {@code arrayLiteral}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#atom}.
	 * @param ctx the parse tree
	 */
	void exitArrayLiteral(GTTEmbededRuleScriptParser.ArrayLiteralContext ctx);
	/**
	 * Enter a parse tree produced by the {@code nullLiteral}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#atom}.
	 * @param ctx the parse tree
	 */
	void enterNullLiteral(GTTEmbededRuleScriptParser.NullLiteralContext ctx);
	/**
	 * Exit a parse tree produced by the {@code nullLiteral}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#atom}.
	 * @param ctx the parse tree
	 */
	void exitNullLiteral(GTTEmbededRuleScriptParser.NullLiteralContext ctx);
}