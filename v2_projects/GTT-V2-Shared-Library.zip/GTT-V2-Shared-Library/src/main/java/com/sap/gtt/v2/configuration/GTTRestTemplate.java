package com.sap.gtt.v2.configuration;

import java.net.URI;
import java.util.Arrays;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class GTTRestTemplate {

	private static final org.slf4j.Logger globalLogger = LoggerFactory.getLogger(GTTRestTemplate.class);
	
	@Autowired
	private ISAPCloudPlatformAgent.ICurrentAccessContext currentAccessContext;
	
	@Autowired
	private RestTemplate innerRestTemplate;
	
	public <T> ResponseEntity<T> exchange(String url, HttpMethod method,
			HttpHeaders headers, Object body, Class<T> responseType){
		HttpHeaders finalHeaders = this.wrapHttpHeaders(headers);
		HttpEntity<?> requestEntity = new HttpEntity<>(body,finalHeaders);
		
		String postToLog = method + " to " + url;
		String payloadLog = "Payload: " + body;
		globalLogger.info(postToLog);
		globalLogger.info(payloadLog);
		
		ResponseEntity<T> response = this.innerRestTemplate.exchange(url, method, requestEntity, responseType);
		
		String responseLog = "response: " + response.getBody();
		globalLogger.info(responseLog);
		
		return response;
	}
	
	
	protected HttpHeaders wrapHttpHeaders(HttpHeaders hearders){
		HttpHeaders finalHeaders = hearders;
		if(hearders == null){
			finalHeaders = new HttpHeaders();
		}
		
		if(finalHeaders.getAcceptLanguage().isEmpty()){
			finalHeaders.setAcceptLanguageAsLocales(Arrays.asList(ISAPCloudPlatformAgent.ICurrentAccessContext.getLocale()));
		}
		if(!finalHeaders.containsKey(HttpHeaders.AUTHORIZATION)){
			finalHeaders.setBearerAuth(currentAccessContext.getJWT());
		}
		
		return finalHeaders;
	}

	public <T> ResponseEntity<T> exchange(URI url, HttpMethod method,
										  HttpHeaders headers, Object body, Class<T> responseType){
		HttpHeaders finalHeaders = this.wrapHttpHeaders(headers);
		HttpEntity<?> requestEntity = new HttpEntity<>(body,finalHeaders);

		String postToLog = method + " to " + url;
		String payloadLog = "Payload: " + body;
		globalLogger.info(postToLog);
		globalLogger.info(payloadLog);

		ResponseEntity<T> response = this.innerRestTemplate.exchange(url, method, requestEntity, responseType);
		
		String responseLog = "response: " + response.getBody();
		globalLogger.info(responseLog);

		return response;
	}

}
