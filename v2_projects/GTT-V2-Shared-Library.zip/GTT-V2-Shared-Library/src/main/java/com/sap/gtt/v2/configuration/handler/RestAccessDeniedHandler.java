/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.gtt.v2.configuration.handler;

import com.sap.gtt.v2.core.auditlog.AuditLogService;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.stereotype.Component;

/**
 *
 * @author I326335
 */
@Component
public class RestAccessDeniedHandler extends RestSecurityHandlerBase implements AccessDeniedHandler {

    @Autowired
    private AuditLogService auditLogService;
    
    @Override
    public void handle(HttpServletRequest request, HttpServletResponse response, AccessDeniedException exception) throws IOException, ServletException {
        auditSecurityEvent(auditLogService, exception.getMessage());
        generateResponse(request, response, FORBIDDEN, HttpServletResponse.SC_FORBIDDEN);
    }

    private static final String FORBIDDEN = "Forbidden";
    
}
