package com.sap.gtt.v2.core.entity.trackedprocess;

import com.sap.gtt.v2.core.domain.trackedprocess.EventStatus;
import com.sap.gtt.v2.core.runtime.model.IPropertyValue;
import com.sap.gtt.v2.core.runtime.model.ObjectValue;
import com.sap.gtt.v2.core.runtime.model.UUIDValue;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.Map;
import java.util.UUID;

public class PlannedEvent extends ObjectValue {
    public static final String PROCESSID = "process_id";
    public static final String EVENTTYPE = "eventType";
    public static final String EVENT_MATCH_KEY = "eventMatchKey";
    public static final String LOCATION_ALTKEY = "locationAltKey";
    public static final String ID = "id";
    public static final String EVENT_STATUS = "eventStatus_code";
    public static final String NEXT_OVERDUE_DETECTION = "nextOverdueDetection";
    public static final String OVERDUE_DETECTION_COUNTER = "overdueDetectionCounter";
    public static final String PLANNED_TECHNICAL_TIMESTAMP = "plannedTechnicalTimestamp";
    public static final String PLANNED_TECH_TS_EARLIEST = "plannedTechTsEarliest";
    public static final String PLANNED_TECH_TS_LATEST = "plannedTechTsLatest";
    public static final String PLANNED_BUSINESS_TIMESTAMP = "plannedBusinessTimestamp";
    public static final String PLANNED_BIZ_TS_EARLIEST = "plannedBizTsEarliest";
    public static final String PLANNED_BIZ_TS_LATEST = "plannedBizTsLatest";
    public static final String PLANNED_BUSINESS_TIME_ZONE = "plannedBusinessTimeZone";
    public static final String PAYLOAD_SEQUENCE = "payloadSequence";
    public static final String LONGITUDE = "longitude";
    public static final String LATITUDE = "latitude";
    public static final String IS_FINAL_PLANNED_EVENT = "isFinalPlannedEvent";
    public static final String LAST_PROCESS_EVENT_DIRECTORY_ID = "lastProcessEventDirectory_id";
    //For event, type: UUID
    public static final String EVENTID = "event_id";
    //For GTTUpdatePlanEvent, type String
    public static final String ACTION = "action_code";

    public PlannedEvent () {
        super();
    }

    public PlannedEvent(Map<String, IPropertyValue> internalValue) {
        super(internalValue);
    }

    public UUID getId() {
        return this.getValueAsUUID(ID);
    }

    public void setId(UUID id) {
        this.setValue(ID, id);
    }

    public UUID getProcessId() {
        return this.getValueAsUUID(PROCESSID);
    }

    public void setProcessId(UUID process_id) {
        this.setValue(PROCESSID, process_id);
    }

    public void setProcessId(UUIDValue process_id) {
        this.setValue(PROCESSID, process_id);
    }

    public String getEventType() {
        return this.getValueAsString(EVENTTYPE);
    }

    public void setEventType(String eventType) {
        this.setValue(EVENTTYPE, eventType);
    }

    public String getEventMatchKey() {
        return this.getValueAsString(EVENT_MATCH_KEY);
    }

    public void setEventMatchKey(String eventMatchKey) {
        this.setValue(EVENT_MATCH_KEY, eventMatchKey);
    }

    public String getEventStatus() {
        return this.getValueAsString(EVENT_STATUS);
    }

    public void setEventStatus(String eventStatus) {
        this.setValue(EVENT_STATUS, eventStatus);
    }

    public String getLocationAltKey() {
        return this.getValueAsString(LOCATION_ALTKEY);
    }

    public void setLocationAltKey(String locationAltKey) {
        this.setValue(LOCATION_ALTKEY, locationAltKey);
    }

    public Instant getNextOverdueDetection() {
        return this.getValueAsTimeStamp(NEXT_OVERDUE_DETECTION);
    }

    public void setNextOverdueDetection(Instant nextOverdueDetection) {
        this.setValue(NEXT_OVERDUE_DETECTION, nextOverdueDetection);
    }

    public Integer getOverdueDetectionCounter() {
        return this.getValueAsInteger(OVERDUE_DETECTION_COUNTER);
    }

    public void setOverdueDetectionCounter(Integer overdueDetectionCounter) {
        this.setValue(OVERDUE_DETECTION_COUNTER, overdueDetectionCounter);
    }

    public Instant getPlannedTechnicalTimestamp() {
        return this.getValueAsTimeStamp(PLANNED_TECHNICAL_TIMESTAMP);
    }

    public void setPlannedTechnicalTimestamp(Instant plannedTechnicalTimestamp) {
        this.setValue(PLANNED_TECHNICAL_TIMESTAMP, plannedTechnicalTimestamp);
    }

    public Instant getPlannedTechTsEarliest() {
        return this.getValueAsTimeStamp(PLANNED_TECH_TS_EARLIEST);
    }

    public void setPlannedTechTsEarliest(Instant plannedTechTsEarliest) {
        this.setValue(PLANNED_TECH_TS_EARLIEST, plannedTechTsEarliest);
    }

    public Instant getPlannedTechTsLatest() {
        return this.getValueAsTimeStamp(PLANNED_TECH_TS_LATEST);
    }

    public void setPlannedTechTsLatest(Instant plannedTechTsLatest) {
        this.setValue(PLANNED_TECH_TS_LATEST, plannedTechTsLatest);
    }

    public Instant getPlannedBusinessTimestamp() {
        return this.getValueAsTimeStamp(PLANNED_BUSINESS_TIMESTAMP);
    }

    public void setPlannedBusinessTimestamp(Instant plannedBusinessTimestamp) {
        this.setValue(PLANNED_BUSINESS_TIMESTAMP, plannedBusinessTimestamp);
    }

    public Instant getPlannedBizTsEarliest() {
        return this.getValueAsTimeStamp(PLANNED_BIZ_TS_EARLIEST);
    }

    public void setPlannedBizTsEarliest(Instant plannedBizTsEarliest) {
        this.setValue(PLANNED_BIZ_TS_EARLIEST, plannedBizTsEarliest);
    }

    public Instant getPlannedBizTsLatest() {
        return this.getValueAsTimeStamp(PLANNED_BIZ_TS_LATEST);
    }

    public void setPlannedBizTsLatest(Instant plannedBizTsLatest) {
        this.setValue(PLANNED_BIZ_TS_LATEST, plannedBizTsLatest);
    }

    public String getPlannedBusinessTimeZone() {
        return this.getValueAsString(PLANNED_BUSINESS_TIME_ZONE);
    }

    public void setPlannedBusinessTimeZone(String plannedBusinessTimeZone) {
        this.setValue(PLANNED_BUSINESS_TIME_ZONE, plannedBusinessTimeZone);
    }

    public Integer getPayloadSequence() {
        return this.getValueAsInteger(PAYLOAD_SEQUENCE);
    }

    public void setPayloadSequence(Integer payloadSequence) {
        this.setValue(PAYLOAD_SEQUENCE, payloadSequence);
    }

    public BigDecimal getLongitude() {
        return this.getValueAsDecimal(LONGITUDE);
    }

    public void setLongitude(BigDecimal longitude) {
        this.setValue(LONGITUDE, longitude);
    }

    public BigDecimal getLatitude() {
        return this.getValueAsDecimal(LATITUDE);
    }

    public void setLatitude(BigDecimal latitude) {
        this.setValue(LATITUDE, latitude);
    }

    public Boolean getIsFinalPlannedEvent() {
        return this.getValueAsBoolean(IS_FINAL_PLANNED_EVENT);
    }

    public void setIsFinalPlannedEvent(Boolean isFinalPlannedEvent) {
        this.setValue(IS_FINAL_PLANNED_EVENT, isFinalPlannedEvent);
    }

    public void setLastProcessEventDirectoryId(UUID lastProcessEventDirectoryId){
        this.setValue(LAST_PROCESS_EVENT_DIRECTORY_ID, lastProcessEventDirectoryId);
    }

    public UUID getLastProcessEventDirectoryId(){return this.getValueAsUUID(LAST_PROCESS_EVENT_DIRECTORY_ID);}

    public void copy(PlannedEvent pe) {
        this.getInternalValue().clear();
        this.getInternalValue().putAll(pe.getInternalValue());
    }

    public boolean isReported() {
        String status = getEventStatus();
        return EventStatus.REPORTED.name().equals(status)
                || EventStatus.LATE_REPORTED.name().equals(status)
                || EventStatus.EARLY_REPORTED.name().equals(status);
    }
}
