package com.sap.gtt.v2.core.domain.trackedprocess;

public enum Action {
    ADD,DELETE,OBSERVE,RESET;

    @Override
    public String toString() {
        switch (this) {
            case ADD:
                return "ADD";
            case DELETE:
                return "DELETE";
            case OBSERVE:
                return "OBSERVE";
            case RESET:
                return "RESET";
        }
        return "";
    }

    public static Action fromValue(String value) {
        switch (value) {
            case "ADD":
                return ADD;
            case "DELETE":
                return DELETE;
            case "OBSERVE":
                return OBSERVE;
            case "RESET":
                return RESET;
            default:
                return OBSERVE;
        }
    }

}
