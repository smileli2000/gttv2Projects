package com.sap.gtt.v2.core.entity.metadata;

import java.io.Serializable;
import java.util.Objects;
import java.util.StringJoiner;

/**
 * @author I321712
 */
public class MetadataProjectFile implements Serializable {
    private String id;
    private String cds;
    private String csn;
    private String edmx;
    private String annotation;
    private String i18n;
    private String swagger;
    private String derivedCsn;
    private String rules;
    private String jsonModel;
    private String idocConfig;
    private String readSwagger;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCds() {
        return cds;
    }

    public void setCds(String cds) {
        this.cds = cds;
    }

    public String getCsn() {
        return csn;
    }

    public void setCsn(String csn) {
        this.csn = csn;
    }

    public String getEdmx() {
        return edmx;
    }

    public void setEdmx(String edmx) {
        this.edmx = edmx;
    }

    public String getAnnotation() {
        return annotation;
    }

    public void setAnnotation(String annotation) {
        this.annotation = annotation;
    }

    public String getI18n() {
        return i18n;
    }

    public void setI18n(String i18n) {
        this.i18n = i18n;
    }

    public String getSwagger() {
        return swagger;
    }

    public void setSwagger(String swagger) {
        this.swagger = swagger;
    }

    public String getDerivedCsn() {
        return derivedCsn;
    }

    public void setDerivedCsn(String derivedCsn) {
        this.derivedCsn = derivedCsn;
    }

    public String getRules() {
        return rules;
    }

    public void setRules(String rules) {
        this.rules = rules;
    }

    public String getJsonModel() {
        return jsonModel;
    }

    public void setJsonModel(String jsonModel) {
        this.jsonModel = jsonModel;
    }

    public String getIdocConfig() {
        return idocConfig;
    }

    public void setIdocConfig(String idocConfig) {
        this.idocConfig = idocConfig;
    }

    public String getReadSwagger() {
        return readSwagger;
    }

    public void setReadSwagger(String readSwagger) {
        this.readSwagger = readSwagger;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        MetadataProjectFile that = (MetadataProjectFile) o;
        return id.equals(that.id) &&
                cds.equals(that.cds) &&
                csn.equals(that.csn) &&
                edmx.equals(that.edmx) &&
                Objects.equals(annotation, that.annotation) &&
                Objects.equals(i18n, that.i18n) &&
                Objects.equals(swagger, that.swagger) &&
                Objects.equals(derivedCsn, that.derivedCsn) &&
                Objects.equals(rules, that.rules) &&
                Objects.equals(jsonModel, that.jsonModel) &&
                Objects.equals(idocConfig, that.idocConfig) &&
                Objects.equals(readSwagger, that.readSwagger);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, cds, csn, edmx, annotation, i18n, swagger, rules, jsonModel, idocConfig, readSwagger);
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", MetadataProjectFile.class.getSimpleName() + "[", "]")
                .add("id='" + id + "'")
                .add("cds='" + cds + "'")
                .add("csn='" + csn + "'")
                .add("edmx='" + edmx + "'")
                .add("annotation='" + annotation + "'")
                .add("i18n='" + i18n + "'")
                .add("swagger='" + swagger + "'")
                .add("derivedCsn='" + derivedCsn + "'")
                .add("rules='" + rules + "'")
                .add("jsonModel='" + jsonModel + "'")
                .add("idocConfig='" + idocConfig + "'")
                .add("readSwagger='" + readSwagger + "'")
                .toString();
    }
}
