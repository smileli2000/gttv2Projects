package com.sap.gtt.v2.tenant;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.sap.gtt.v2.configuration.GTTRestTemplate;
import com.sap.gtt.v2.configuration.ServiceInstancesMapping;
import com.sap.gtt.v2.configuration.SystemConstants;
import com.sap.gtt.v2.exception.TenantServiceException;
import com.sap.gtt.v2.servicemanager.GTTInstance;
import com.sap.gtt.v2.util.GTTUtils;
import com.sap.gtt.v2.util.SpringContextUtils;


/**
 * Wrapper Service for Tenant settings
 * @author I053866
 *
 */
@Service
//@EnableScheduling
public class TenantService {
	
	private static final String GTT_INSTANCE_BY_NAME_NOT_FOUND = "GTT Instance with name '%s' not found";
	
	private static final Logger logger = LoggerFactory.getLogger(TenantService.class);
	
	public static final String CACHE_NAME_TENANT_SETTING = "tenantSetting";
	public static final String CACHE_NAME_GTT_INSTANCE = "gttInstance";
	
	@Value("${TT_SERVICE_MANAGER_URL:#{null}}")
	private String serviceManagerUrl;
	
	@Autowired
	private Environment env;
	
	@Autowired
	private ServiceInstancesMapping serviceInstancesMapping;
	
	@Cacheable(cacheNames = CACHE_NAME_TENANT_SETTING, key="#subaccountId + '" + GTTUtils.GLOBAL_STRING_SPLITOR + "' + #cloneServiceInstanceId")
	public GTTTenantSetting get(String subaccountId, String cloneInstanceId){
		subaccountId = StringUtils.trimToEmpty(subaccountId);
		cloneInstanceId = StringUtils.trimToEmpty(cloneInstanceId);
		String url = this.serviceManagerUrl + SystemConstants.SERVICE_MANAGER_ROOT_URL + "/tenantSetting?subaccountId=" + subaccountId + "&cloneInstanceId=" + cloneInstanceId;
		
		if(ArrayUtils.contains(env.getActiveProfiles(), "test")){
			return new GTTTenantSetting();
		}
		else{
			// generate GTT MASTER UAA JWT...
			String masterUAAJWT = serviceInstancesMapping.getUaaServiceInstance().requestTechniqueToken();
			HttpHeaders headers = new HttpHeaders();
			headers.setBearerAuth(masterUAAJWT);
			GTTRestTemplate restTemplate = SpringContextUtils.getBean(GTTRestTemplate.class);
			return restTemplate.exchange(url, HttpMethod.GET, headers, null, GTTTenantSetting.class).getBody();

		}
	
	}
	
	@Cacheable(cacheNames = CACHE_NAME_GTT_INSTANCE,key="#subaccountId + '" + GTTUtils.GLOBAL_STRING_SPLITOR + "' + #cloneInstanceId")
	public GTTInstance getGTTInstance(String subaccountId, String cloneInstanceId){
		subaccountId = StringUtils.trimToEmpty(subaccountId);
		cloneInstanceId = StringUtils.trimToEmpty(cloneInstanceId);
		String url = this.serviceManagerUrl + SystemConstants.SERVICE_MANAGER_ROOT_URL + "/getInstance?subaccountId=" + subaccountId + "&cloneInstanceId=" + cloneInstanceId;
		
		GTTInstance result = null;
		if(ArrayUtils.contains(env.getActiveProfiles(), "test")){
			//current is test profile
			result = new GTTInstance();
			result.setStorageConnectionInfo("{\"databaseServiceInstanceName\":\"lbn-gtt-core-storage-h2\",\"plan\":\"shared\"}");
			result.setStorageType(GTTInstance.STORAGE_TYPE_HANA);
		}
		else{
			// generate GTT MASTER UAA JWT...
			String masterUAAJWT = serviceInstancesMapping.getUaaServiceInstance().requestTechniqueToken();
			HttpHeaders headers = new HttpHeaders();
			headers.setBearerAuth(masterUAAJWT);
			GTTRestTemplate restTemplate = SpringContextUtils.getBean(GTTRestTemplate.class);
			result = restTemplate.exchange(url, HttpMethod.GET, headers, null, GTTInstance.class).getBody();
		}
		
		return result;
	}
	
	public List<GTTInstance> getGTTInstances(){
		String url = this.serviceManagerUrl + SystemConstants.SERVICE_MANAGER_ROOT_URL + "/instances";
		
		List<GTTInstance> result = new ArrayList<>();
		
		if(ArrayUtils.contains(env.getActiveProfiles(), "test")){
			result.add(this.getGTTInstance("", ""));
		}
		else{
			// generate GTT MASTER UAA JWT...
			String masterUAAJWT = serviceInstancesMapping.getUaaServiceInstance().requestTechniqueToken();
			HttpHeaders headers = new HttpHeaders();
			headers.setBearerAuth(masterUAAJWT);
			GTTRestTemplate restTemplate = SpringContextUtils.getBean(GTTRestTemplate.class);
			GTTInstance [] resultInArray = restTemplate.exchange(url, HttpMethod.GET, headers, null, GTTInstance[].class).getBody();
			return resultInArray == null ? result : Arrays.asList(resultInArray);

		}
		
		return result;
	}
	
	public GTTInstance getGTTInstanceByName(String instanceName){
		GTTInstance result = null;
		List<GTTInstance> instances = this.getGTTInstances();
		for(GTTInstance instance : instances){
			if(StringUtils.equals(instance.getInstanceName(), instanceName)){
				result = instance;
				break;
			}
		}
		if(result == null){
			throw new TenantServiceException(String.format(GTT_INSTANCE_BY_NAME_NOT_FOUND, instanceName));
		}
		return result;
	}
	@CacheEvict(value={CACHE_NAME_TENANT_SETTING,CACHE_NAME_GTT_INSTANCE}, allEntries = true)
	@Scheduled(fixedDelay = 300*1000) // 300 seconds
	public void evictAll(){
		logger.debug("Invalidating all local tenant settings and GTT Instance caches...");
	}
	
}
