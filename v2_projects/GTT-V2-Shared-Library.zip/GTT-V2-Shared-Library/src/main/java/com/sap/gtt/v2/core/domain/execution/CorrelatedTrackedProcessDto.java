package com.sap.gtt.v2.core.domain.execution;

import java.util.Map;

/**
 * @author I302310
 */
public class CorrelatedTrackedProcessDto {
    private String executionId;
    private Map<String, String> tpMap;

    public String getExecutionId() {
        return executionId;
    }

    public void setExecutionId(String executionId) {
        this.executionId = executionId;
    }

    public Map<String, String> getTpMap() {
        return tpMap;
    }

    public void setTpMap(Map<String, String> tpMap) {
        this.tpMap = tpMap;
    }
}
