package com.sap.gtt.v2.core.runtime.model;

import com.sap.gtt.v2.exception.ValueParseException;

import java.time.Instant;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public final class TimestampValue extends AbstractPropertyValue<Instant> {

    private TimestampValue(Instant internalValue) {
        super(internalValue);
    }

    @Override
    public boolean isCsnPrimitive() {
        return true;
    }

    @Override
    public boolean isCollection() {
        return false;
    }

	@Override
	protected int compareToInternal(IPropertyValue that) {
		return this.getInternalValue().compareTo(((TimestampValue)that).getInternalValue());
	}

	public static TimestampValue valueOf(String timestampStr){
        try{
        	//2019-05-16T09:00:00.213
        	//2019-05-16T09:00:00.213Z
        	//2019-05-16T09:00:00.213+01:00
        	//2019-05-16T09:00:00+01:00
            TimestampValue timestamp = valueOf(Instant.from(DateTimeFormatter.ISO_DATE_TIME.parse(timestampStr)));
            return timestamp;
        }catch (DateTimeParseException e){
            throw new ValueParseException(e.getLocalizedMessage(), e);
        }
    }
	
	public static TimestampValue valueOf(Instant value){
		return new TimestampValue(value);
	}
    
}
