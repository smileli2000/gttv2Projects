package com.sap.gtt.v2.core.dao.metadata;

import com.sap.gtt.v2.core.domain.metadata.CodeList;
import com.sap.gtt.v2.core.domain.metadata.MetadataEntity;
import com.sap.gtt.v2.core.domain.metadata.PhysicalName;

import java.util.List;

public interface ISysTableDao {
    /**
     * Create all the tables based on the metadata entity list
     * @param newEntities newly added metadata entities
     */
    void createTable(List<MetadataEntity> newEntities);

    /**
     * drop all the tables based on the metadata entity list
     * @param tobeDroppedEntities to be dropped entities
     */
    void dropTable(List<MetadataEntity> tobeDroppedEntities);

    /**
     * Add new columns to the corresponding tables of specific entities
     * @param newFieldEntities newly added metadata elements
     */
    void addTableField(List<MetadataEntity> newFieldEntities);

    /**
     * Modify columns for specific entities
     * @param modifiedFieldEntities
     */
    void modifyTableField(List<MetadataEntity> modifiedFieldEntities);

    /**
     * Delete columns
     * @param deletedFieldEntities
     */
    void deleteTableField(List<MetadataEntity> deletedFieldEntities);

    /**
     * count table rows
     * @param metadataEntity
     * @return number of rows
     */
    long countTableRows(MetadataEntity metadataEntity);

    /**
     * delete table according to the table name
     * @param tableName
     */
    void emptyTable(String tableName);

    /**
     * insert codeList into corresponding tables
     * @param codeList
     */
    void insertCodeList(CodeList codeList);

    /**
     * insert codeList into corresponding tables
     * @param codeList
     */
    void insertCodeListTexts(CodeList codeList);
}
