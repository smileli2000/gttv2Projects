package com.sap.gtt.v2.configuration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import com.sap.gtt.v2.configuration.ISAPCloudPlatformAgent.ICurrentAccessContext;

@Configuration
@EnableCaching
public class CacheConfiguration {
	
	@Component(CacheControl.BEAN_NAME)
	public static class CacheControl{
		public static final String BEAN_NAME = "cacheControl";
		
		@Value("${TT_CACHE_ENABLED:#{false}}")
		private boolean enabled;
		
		@Autowired
		private ICurrentAccessContext currentAccessContext;
		public boolean isCacheEnabled(){
			if(!enabled) return false;
			// check productive
			return currentAccessContext.isProductive();
			
		}
	}
	
	
}
