package com.sap.gtt.v2.core.management.tracking;

import com.sap.gtt.v2.core.domain.metadata.CurrentMetadataEntity;
import com.sap.gtt.v2.core.entity.trackedprocess.PlannedEvent;
import com.sap.gtt.v2.core.entity.trackedprocess.ProcessEventDirectory;
import com.sap.gtt.v2.core.entity.trackedprocess.TrackedProcess;
import com.sap.gtt.v2.core.runtime.model.TimestampValue;
import com.sap.gtt.v2.core.runtime.model.UUIDValue;

import java.util.List;
import java.util.Map;

/**
 * @author I053866
 * <p>
 * TP Update :
 * Process Event -> update whole header(including version,lastChangedBy, lastChangedAt) / customer defined items
 * -> update all planned events
 * -> update all qualified tracking ids
 * -> insert one new PED for that process event
 * <p>
 * Common Event -> insert one new PED
 * -> update one planned event
 * -> update all qualified tracking ids
 * -> update version, process status, lastChangedBy, lastChangedAt
 */
public interface ITrackedProcessManagement {

    void create(TrackedProcess trackedProcess);

    void update(TrackedProcess trackedProcess);

    void update(TrackedProcess trackedProcess, ProcessEventDirectory newProcessEventDirectory, PlannedEvent plannedEvent);

    void update(TrackedProcess trackedProcess, boolean isUpdateTrackingIds, boolean isUpdatePlannedEvents);

    void delete(TrackedProcess trackedProcess);

    void deleteAllTheTrackedProcessByNamespace(String namespace);

    TrackedProcess get(UUIDValue id);

    TrackedProcess getWithOnlyValidDPPStatus(UUIDValue id);

    TrackedProcess get(CurrentMetadataEntity metadata, UUIDValue id);

    List<UUIDValue> getCorrelatedProcessId(UUIDValue observerId, TimestampValue actualBizTs, int eventCorrelationLevel);

    Map<UUIDValue, String> getCorrelatedProcessMap(UUIDValue observedId, TimestampValue actualBizTs, int eventCorrelationLevel);
}
