package com.sap.gtt.v2.core.runtime.model;

import com.sap.gtt.v2.core.runtime.model.IPropertyValue.FunctionInterfaceDef;
import com.sap.gtt.v2.exception.ValueParseException;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.HashMap;
import java.util.Map;

public final class DateValue extends AbstractPropertyValue<LocalDate> implements Comparable<IPropertyValue>{
    
	// define functions
	protected static final Map<String, FunctionInterfaceDef> functionDefs = new HashMap<>();
	static{
		functionDefs.putAll(AbstractPropertyValue.functionDefs);
	}
	@Override
	protected Map<String, FunctionInterfaceDef> getFunctionDefs(){
		return functionDefs;
	}
	//
	
	private DateValue(LocalDate internalValue) {
        super(internalValue);
    }

    
    
    @Override
    public boolean isCsnPrimitive() {
        return true;
    }

    @Override
    public boolean isCollection() {
        return false;
    }

	@Override
	protected int compareToInternal(IPropertyValue that) {
		return this.getInternalValue().compareTo(((DateValue)that).getInternalValue());
	}

	public static DateValue valueOf(String dateStr){
		try{
			return valueOf(LocalDate.parse(dateStr));
		}
        catch(DateTimeParseException e){
        	throw new ValueParseException(e.getLocalizedMessage(), e);
        }
    }
	public static DateValue valueOf(LocalDate localDate){
		return new DateValue(localDate);
	}
    
}
