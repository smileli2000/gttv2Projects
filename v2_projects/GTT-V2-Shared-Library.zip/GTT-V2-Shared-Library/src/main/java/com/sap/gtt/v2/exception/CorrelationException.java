package com.sap.gtt.v2.exception;

import org.apache.http.HttpStatus;

public class CorrelationException extends GeneralNoneTranslatableException {
    public static final String ERROR_CODE = "ERROR_CODE_CORRELATION";

    public CorrelationException(String message) {
        super(message, null, HttpStatus.SC_BAD_REQUEST);
    }

    @Override
    public String getErrorCode() {
        return ERROR_CODE;
    }
}
