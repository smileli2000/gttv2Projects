package com.sap.gtt.v2.core.dao.execution;

import com.sap.gtt.v2.core.entity.execution.ExecutionHistory;
import com.sap.gtt.v2.exception.DBException;
import com.sap.gtt.v2.util.DBUtils;
import com.sap.gtt.v2.util.SpringContextUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author I302310
 */
@Repository(DefaultExecutionHistoryDao.BEAN_NAME)
public class DefaultExecutionHistoryDao implements IExecutionHistoryDao {
    public static final String BEAN_NAME = "com.sap.gtt.v2.core.dao.execution.DefaultExecutionHistoryDao";
    public static final String TABLE_NAME = "EXECUTION_HISTORY";

    public static final String WHERE = " where ";

    public static final String ID = "ID";
    public static final String EXECUTION_UNIT_ID = "EXECUTION_UNIT_ID";
    public static final String EXECUTION_AT = "EXECUTION_AT";
    public static final String LAST_PHASE = "LAST_PHASE";
    public static final String STATUS = "STATUS";

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public static DefaultExecutionHistoryDao getInstance() {
        return (DefaultExecutionHistoryDao) SpringContextUtils.getBean(BEAN_NAME);
    }

    @Override
    public ExecutionHistory queryExecution(String id) {
        List<String> args = new ArrayList<>();
        args.add(id);
        StringBuilder sql = new StringBuilder();
        sql.append("select * from ").append(TABLE_NAME)
                .append(WHERE)
                .append(ID).append("=?");
        List<ExecutionHistory> histories = jdbcTemplate.query(sql.toString(), args.toArray(), (rs, rowNum) -> {
            String rs_id = rs.getString(ID);
            String rs_unitId = rs.getString(EXECUTION_UNIT_ID);
            Instant rs_executionAt = rs.getTimestamp(EXECUTION_AT).toInstant();
            String rs_lastPhase = rs.getString(LAST_PHASE);
            String rs_status = rs.getString(STATUS);
            return new ExecutionHistory(rs_id, rs_unitId, rs_executionAt, rs_lastPhase, rs_status);
        });
        return histories.isEmpty() ? null : histories.get(0);
    }

    @Override
    public List<String> queryStatus(String requestId) {
        StringBuilder sql = new StringBuilder();
        sql.append("select ").append(STATUS).append(" from ")
                .append(DefaultExecutionUnitDao.TABLE_NAME).append(" T1 ")
                .append(" inner join ").append(TABLE_NAME).append(" T2 ")
                .append(" on T1.").append(DefaultExecutionUnitDao.LAST_EXECUTION_ID).append("=").append("T2.").append(ID)
                .append(WHERE)
                .append(" T1.").append(DefaultExecutionUnitDao.REQUEST_ID).append("= ?");
        List<Map<String, Object>> rst = jdbcTemplate.queryForList(sql.toString(), requestId);
        return rst.stream().map(item -> item.get(STATUS).toString()).collect(Collectors.toList());
    }


    @Override
    public void insertExecution(ExecutionHistory executionHistory) {
        StringBuilder sql = new StringBuilder();
        String[] columns = {ID, EXECUTION_UNIT_ID, EXECUTION_AT, LAST_PHASE, STATUS};
        DBUtils.buildInsertSql(TABLE_NAME, columns, sql);
        Object[] args = new Object[]{executionHistory.getId(), executionHistory.getUnitId(),
                executionHistory.getExecutionAt(), executionHistory.getLastPhase(), executionHistory.getStatus()};
        int affectedRows = jdbcTemplate.update(sql.toString(), args);
        if (affectedRows <= 0) {
            throw new DBException("Insert ExecutionHistory data failed. Affected rows " + affectedRows);
        }
    }

    @Override
    public void updateExecutionStatus(String id, String lastPhase, String status) {
        StringBuilder sql = new StringBuilder();
        String[] updatedColumns = {LAST_PHASE, STATUS};
        Object[] updateValues = new Object[]{lastPhase, status};

        String[] whereColumns = {ID};
        Object[] whereValues = new Object[]{id};

        List<Object> updateParam = new ArrayList<>();

        DBUtils.buildUpdateSql(TABLE_NAME, updatedColumns, updateValues, whereColumns, whereValues, sql, updateParam);
        Object[] args = updateParam.toArray();
        jdbcTemplate.update(sql.toString(), args);
    }

}
