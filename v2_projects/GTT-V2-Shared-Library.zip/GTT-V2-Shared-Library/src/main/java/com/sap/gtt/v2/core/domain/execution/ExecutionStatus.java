package com.sap.gtt.v2.core.domain.execution;

/**
 * @author I302310
 */
public enum ExecutionStatus {
    SUCCESS("Success", 0), WARNING("Warning", 1), PENDING("Pending", 2), ERROR("Error", 3);

    private String description;
    private int priority;

    ExecutionStatus(String description, int priority) {
        this.description = description;
        this.priority = priority;
    }

    public String getDescription() {
        return description;
    }

    public int getPriority() {
        return priority;
    }
}
