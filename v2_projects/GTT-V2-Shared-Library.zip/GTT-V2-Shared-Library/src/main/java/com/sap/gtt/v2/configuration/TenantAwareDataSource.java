package com.sap.gtt.v2.configuration;

import java.sql.Connection;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sap.gtt.v2.configuration.EnvironmentsConfiguration.VcapServiceParser.DatabaseServiceInstance;
import com.sap.gtt.v2.configuration.EnvironmentsConfiguration.VcapServiceParser.JdbcEnabledDatabaseServiceInstance;
import com.sap.gtt.v2.configuration.ISAPCloudPlatformAgent.ICurrentAccessContext;


@Component
//@Profile("cloud")
public class TenantAwareDataSource extends org.springframework.jdbc.datasource.AbstractDataSource{
	
	@Autowired
	private ICurrentAccessContext currentAccessContext;
	
	@Override
	public Connection getConnection() throws SQLException {

		DatabaseServiceInstance databaseServiceInstance = currentAccessContext.getDatabaseServiceInstance();
		if(databaseServiceInstance instanceof JdbcEnabledDatabaseServiceInstance){
			Connection conn = ((JdbcEnabledDatabaseServiceInstance)databaseServiceInstance).getDataSource().getConnection();
			return conn;
		}
		else{
			throw new UnsupportedOperationException(String.format("Database serivice instance '%s' with type '%s' is not a JDBC Enabled service, thus cannot be used by CloudTenantAwareDataSource", 
					databaseServiceInstance.getInstanceName(), databaseServiceInstance.getDatabaseType().name())); 
		}
		
		
	}

	@Override
	public Connection getConnection(String username, String password) throws SQLException {
		throw new UnsupportedOperationException("getConnection by user credential not support"); 
	}

}
