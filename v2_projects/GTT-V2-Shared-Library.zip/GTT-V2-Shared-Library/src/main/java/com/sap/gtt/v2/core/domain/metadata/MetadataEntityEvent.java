package com.sap.gtt.v2.core.domain.metadata;

import java.io.Serializable;
import java.lang.reflect.Field;
import java.time.Duration;
import java.util.*;

public class MetadataEntityEvent implements Serializable {
    private static final long serialVersionUID = -3615483584501141332L;
    private String eventType;
    private boolean matchLocation;
    private int maxOverdueDetection;
    private Duration periodicOverdueDetection;
    private Duration technicalToleranceValue;
    private Duration businessToleranceValue;
    private List<MatchExtensionField> matchExtensionFields = new ArrayList<>();
    static final Map<String, Field> METADATA_ENTITY_EVENT_FIELD_MAP = new HashMap<>();

    static {
        Field[] declaredFields = MetadataEntityEvent.class.getDeclaredFields();
        for (Field f : declaredFields) {
            METADATA_ENTITY_EVENT_FIELD_MAP.put(f.getName(), f);
        }
    }

    public MetadataEntityEvent() {
    }

    public MetadataEntityEvent(String eventType) {
        this.eventType = eventType;
    }

    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    public boolean isMatchLocation() {
        return matchLocation;
    }

    public void setMatchLocation(boolean matchLocation) {
        this.matchLocation = matchLocation;
    }

    public int getMaxOverdueDetection() {
        return maxOverdueDetection;
    }

    public void setMaxOverdueDetection(int maxOverdueDetection) {
        this.maxOverdueDetection = maxOverdueDetection;
    }

    public Duration getPeriodicOverdueDetection() {
        return periodicOverdueDetection;
    }

    public void setPeriodicOverdueDetection(Duration periodicOverdueDetection) {
        this.periodicOverdueDetection = periodicOverdueDetection;
    }

    public Duration getTechnicalToleranceValue() {
        return technicalToleranceValue;
    }

    public void setTechnicalToleranceValue(Duration technicalToleranceValue) {
        this.technicalToleranceValue = technicalToleranceValue;
    }

    public Duration getBusinessToleranceValue() {
        return businessToleranceValue;
    }

    public void setBusinessToleranceValue(Duration businessToleranceValue) {
        this.businessToleranceValue = businessToleranceValue;
    }

    public List<MatchExtensionField> getMatchExtensionFields() {
        return new ArrayList<>(matchExtensionFields);
    }

    public void addMatchExtensionField(MatchExtensionField matchExtensionField) {
        this.matchExtensionFields.add(matchExtensionField);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        MetadataEntityEvent that = (MetadataEntityEvent) o;
        return matchLocation == that.matchLocation &&
                maxOverdueDetection == that.maxOverdueDetection &&
                eventType.equals(that.eventType) &&
                Objects.equals(periodicOverdueDetection, that.periodicOverdueDetection) &&
                Objects.equals(technicalToleranceValue, that.technicalToleranceValue) &&
                Objects.equals(businessToleranceValue, that.businessToleranceValue);
    }

    @Override
    public int hashCode() {
        return Objects.hash(eventType, matchLocation, maxOverdueDetection, periodicOverdueDetection, technicalToleranceValue, businessToleranceValue);
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", MetadataEntityEvent.class.getSimpleName() + "[", "]")
                .add("eventType='" + eventType + "'")
                .add("matchLocation=" + matchLocation)
                .add("maxOverdueDetection=" + maxOverdueDetection)
                .add("periodicOverdueDetection='" + periodicOverdueDetection + "'")
                .add("technicalToleranceValue='" + technicalToleranceValue + "'")
                .add("businessToleranceValue='" + businessToleranceValue + "'")
                .toString();
    }
}
