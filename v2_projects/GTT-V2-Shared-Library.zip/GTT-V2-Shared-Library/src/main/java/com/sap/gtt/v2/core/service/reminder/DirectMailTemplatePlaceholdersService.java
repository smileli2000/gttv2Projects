package com.sap.gtt.v2.core.service.reminder;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationCredentialsNotFoundException;
import org.springframework.stereotype.Service;

import com.sap.gtt.v2.bp.BPContactInfo;
import com.sap.gtt.v2.bp.BusinessPartner;
import com.sap.gtt.v2.bp.BusinessPartnerService;
import com.sap.gtt.v2.configuration.AccessContextHolder;
import com.sap.gtt.v2.configuration.GTTRestTemplate;
import com.sap.gtt.v2.configuration.ServiceInstancesMapping;
import com.sap.gtt.v2.configuration.AccessContextHolder.AccessContext;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.sap.gtt.v2.configuration.EnvironmentsConfiguration.VcapServiceParser.ReminderServiceInstance;
import com.sap.gtt.v2.exception.InternalErrorException;
import com.sap.gtt.v2.log.TenantAwareLogService;
import com.sap.gtt.v2.util.JsonUtils;
import com.sap.gtt.v2.util.SpringContextUtils;
import com.sap.xs2.security.container.SecurityContext;
import com.sap.xs2.security.container.UserInfoException;
import com.sap.xsa.security.container.XSUserInfo;
import com.sap.xsa.security.container.XSUserInfoException;

@Service
public class DirectMailTemplatePlaceholdersService {
	protected static final String SOLUTIONOWNER_CONTACTPERSONNAME = "SolutionOwner_ContactPersonName";
	protected static final String SOLUTIONOWNER_CONTACTPERSONEMAIL = "SolutionOwner_ContactPersonEmail";
	protected static final String SOLUTIONOWNER_CONTACTPERSONPHONENUMBER = "SolutionOwner_ContactPersonPhoneNumber";
	protected static final String SOLUTIONOWNER_BUSINESSPROFILENAME = "SolutionOwner_BusinessProfileName";
	protected static final String SOLUTIONOWNER_ADDRESS = "SolutionOwner_Address";
	protected static final String SOLUTIONOWNER_POSTALCODE = "SolutionOwner_PostalCode";
	protected static final String SOLUTIONOWNER_MOBILE = "SolutionOwner_Mobile";
	protected static final String SOLUTIONOWNER_FAX = "SolutionOwner_Fax";
	protected static final String SOLUTIONOWNER_LOGO = "SolutionOwner_Logo";
	protected static final String SOLUTIONOWNER_WEBSITE = "SolutionOwner_Website";
	
	
	private class QueryInfo {
		public String method;

		public QueryInfo(String method) {
			this.method = method;
		}
	}
	private Map<String, QueryInfo> mapAppPlaceholders = new HashMap<String, QueryInfo>();
	public DirectMailTemplatePlaceholdersService() {
		mapAppPlaceholders.put(SOLUTIONOWNER_CONTACTPERSONNAME, new QueryInfo("getSolutionOwnerContactPersonName"));
		mapAppPlaceholders.put(SOLUTIONOWNER_CONTACTPERSONEMAIL, new QueryInfo("getSolutionOwnerContactPersonEmail"));
		mapAppPlaceholders.put(SOLUTIONOWNER_CONTACTPERSONPHONENUMBER, new QueryInfo("getSolutionOwnerContactPersonPhoneNumber"));
		mapAppPlaceholders.put(SOLUTIONOWNER_BUSINESSPROFILENAME, new QueryInfo("getSolutionOwnerBusinessProfileName"));
		mapAppPlaceholders.put(SOLUTIONOWNER_ADDRESS, new QueryInfo("getSolutionOwnerAddress"));
		mapAppPlaceholders.put(SOLUTIONOWNER_POSTALCODE, new QueryInfo("getSolutionOwnerPostalCode"));
		mapAppPlaceholders.put(SOLUTIONOWNER_MOBILE, new QueryInfo("getSolutionOwnerMobile"));
		mapAppPlaceholders.put(SOLUTIONOWNER_FAX, new QueryInfo("getSolutionOwnerFax"));
		mapAppPlaceholders.put(SOLUTIONOWNER_LOGO, new QueryInfo("getSolutionOwnerLogo"));
		mapAppPlaceholders.put(SOLUTIONOWNER_WEBSITE, new QueryInfo("getSolutionOwnerWebsite"));
	}
	
	@Autowired
    private BusinessPartnerService bpService;
	protected XSUserInfo getCurrentUserInfo() {
        try {
            return SecurityContext.getUserInfo();
        } catch (UserInfoException e) {
            // usually - user not authenticated
            throw new AuthenticationCredentialsNotFoundException(e.getMessage(), e);
        }
    }
    protected String getSubaccountId() {
        AccessContext accessContext = AccessContextHolder.get();
        if (accessContext != null) {
            return accessContext.getSubaccountId();
        }
        try {

            return this.getCurrentUserInfo().getSubaccountId();
        } catch (XSUserInfoException e) {
            throw new InternalErrorException(e.getMessage(), e);
        }
    }
	
	public JsonObject getTemplatePlaceHolders(String templateId) {
		JsonObject ret = new JsonObject();
		BPContactInfo bp = bpService.getBPContactDetail(getSubaccountId());
		List<String> appPlaceholders = getAppPlaceholders(templateId);
		if(appPlaceholders != null) {
			for(String ph : appPlaceholders) {
				ret.addProperty(ph, getAppPlaceholderVal(templateId, ph, bp));
			}
		}
        return ret;
	}
	
	private List<String> getAppPlaceholders(String templateId) {
		TenantAwareLogService logService = SpringContextUtils.getBean(TenantAwareLogService.class);
		
		ServiceInstancesMapping serviceInstancesMapping = SpringContextUtils.getBean(ServiceInstancesMapping.class);
        ReminderServiceInstance reminderServiceInstance = serviceInstancesMapping.getReminderServiceInstance();

        String uri = reminderServiceInstance.getEndpoint() + "templateplaceholders?templateId=" + templateId + "&locale=EN";
        logService.info("===> getAppPlaceholders: " + uri);
        
    	HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        
        headers.setBearerAuth(reminderServiceInstance.requestTechniqueTokenForSaasSubaccount());
        //headers.setBearerAuth("eyJhbGciOiJSUzI1NiIsImprdSI6Imh0dHBzOi8vbGJuLWd0dC1zYW1wbGVzLmF1dGhlbnRpY2F0aW9uLnNhcC5oYW5hLm9uZGVtYW5kLmNvbS90b2tlbl9rZXlzIiwia2lkIjoiZGVmYXVsdC1qd3Qta2V5LTExMzkyMzAxMSIsInR5cCI6IkpXVCJ9.eyJqdGkiOiIxYjgzZTg4NTM2MjE0MDZkYWQ2ZGVlODMzZjBhYjI5YyIsImV4dF9hdHRyIjp7ImVuaGFuY2VyIjoiWFNVQUEiLCJ6ZG4iOiJsYm4tZ3R0LXNhbXBsZXMiLCJzZXJ2aWNlaW5zdGFuY2VpZCI6IjM2NWE5NGE0LTcxMmQtNDhiZC1iMTM3LTE5NjU3NjA0Y2M1YyJ9LCJzdWIiOiJzYi0zNjVhOTRhNC03MTJkLTQ4YmQtYjEzNy0xOTY1NzYwNGNjNWMhYjY2NjB8bGJuLXJlbWluZGVyc2VydmljZS1zYi1kZXYhYjQ2OCIsImF1dGhvcml0aWVzIjpbImxibi1yZW1pbmRlcnNlcnZpY2Utc2ItZGV2IWI0NjguRGlyZWN0TWFpbFByb2Nlc3MiLCJsYm4tcmVtaW5kZXJzZXJ2aWNlLXNiLWRldiFiNDY4LlRlbXBsYXRlUHJvY2VzcyIsImxibi1yZW1pbmRlcnNlcnZpY2Utc2ItZGV2IWI0NjguU2VydmljZUJyb2tlclByb2Nlc3MiLCJ1YWEucmVzb3VyY2UiLCJsYm4tcmVtaW5kZXJzZXJ2aWNlLXNiLWRldiFiNDY4LkNhbGxiYWNrIiwibGJuLXJlbWluZGVyc2VydmljZS1zYi1kZXYhYjQ2OC5UZW1wbGF0ZURpc3BsYXkiXSwic2NvcGUiOlsibGJuLXJlbWluZGVyc2VydmljZS1zYi1kZXYhYjQ2OC5EaXJlY3RNYWlsUHJvY2VzcyIsImxibi1yZW1pbmRlcnNlcnZpY2Utc2ItZGV2IWI0NjguVGVtcGxhdGVQcm9jZXNzIiwibGJuLXJlbWluZGVyc2VydmljZS1zYi1kZXYhYjQ2OC5TZXJ2aWNlQnJva2VyUHJvY2VzcyIsInVhYS5yZXNvdXJjZSIsImxibi1yZW1pbmRlcnNlcnZpY2Utc2ItZGV2IWI0NjguQ2FsbGJhY2siLCJsYm4tcmVtaW5kZXJzZXJ2aWNlLXNiLWRldiFiNDY4LlRlbXBsYXRlRGlzcGxheSJdLCJjbGllbnRfaWQiOiJzYi0zNjVhOTRhNC03MTJkLTQ4YmQtYjEzNy0xOTY1NzYwNGNjNWMhYjY2NjB8bGJuLXJlbWluZGVyc2VydmljZS1zYi1kZXYhYjQ2OCIsImNpZCI6InNiLTM2NWE5NGE0LTcxMmQtNDhiZC1iMTM3LTE5NjU3NjA0Y2M1YyFiNjY2MHxsYm4tcmVtaW5kZXJzZXJ2aWNlLXNiLWRldiFiNDY4IiwiYXpwIjoic2ItMzY1YTk0YTQtNzEyZC00OGJkLWIxMzctMTk2NTc2MDRjYzVjIWI2NjYwfGxibi1yZW1pbmRlcnNlcnZpY2Utc2ItZGV2IWI0NjgiLCJncmFudF90eXBlIjoiY2xpZW50X2NyZWRlbnRpYWxzIiwicmV2X3NpZyI6ImVlM2FlZjgwIiwiaWF0IjoxNTkyMjE4NzYzLCJleHAiOjE1OTIyMjIzNjMsImlzcyI6Imh0dHBzOi8vbGJuLWd0dC1zYW1wbGVzLmF1dGhlbnRpY2F0aW9uLnNhcC5oYW5hLm9uZGVtYW5kLmNvbS9vYXV0aC90b2tlbiIsInppZCI6IjZhMGVhNjY1LTg4ZTUtNDVkZS04M2VjLWRkYzgxM2U1YmE1MSIsImF1ZCI6WyJ1YWEiLCJsYm4tcmVtaW5kZXJzZXJ2aWNlLXNiLWRldiFiNDY4Iiwic2ItMzY1YTk0YTQtNzEyZC00OGJkLWIxMzctMTk2NTc2MDRjYzVjIWI2NjYwfGxibi1yZW1pbmRlcnNlcnZpY2Utc2ItZGV2IWI0NjgiXX0.xQikrKd6FsM92KiHteVV8N_CHf0puzjixrLi2C0sx8dkSuTc3_YVsYCGkbT5o6Vo1h5Alu5ryExa73Zu3ZlhjRb0L0OrsUbAlNWVyvp4n727t-_UxHPcgLczxyDYRjvqIF_5mV5qv65czSiZKXEj9ABoHRZgMGMhfBN7k0UlmXZWFxGsdjbBBRtf5Kn3VZj5Zk6inQt664yxyhDYZPOhMAqsRle52tpN_teCOub68i-lkOLFEpAck4NcUTufqpbZjMANnZYmIGqk_F-2XIu0RkKuazOrc4BXKCh8FLZI430grwAtsaI_dU2YpfBOHxhBm9uUv470uI17ULt1Gx-_Bw");
        
        GTTRestTemplate restTemplate = SpringContextUtils.getBean(GTTRestTemplate.class);
        ResponseEntity<String> response = restTemplate.exchange(uri, HttpMethod.GET, headers, null, String.class);
        String s = response.getBody();
        JsonObject placeHolders = JsonUtils.generateJsonObjectFromJsonString(s);
        
        logService.info("===> template placeholders for " + templateId + ": " + s);
        
        JsonArray ja = placeHolders.getAsJsonArray("APP");
        if(ja == null)
        	return null;
        return JsonUtils.getElements(ja, String.class);
	}
	
	private String getAppPlaceholderVal(String templateId, String key, BPContactInfo contactInfo) {
		if(mapAppPlaceholders.containsKey(key)) {
			QueryInfo qi = mapAppPlaceholders.get(key);
			try {
				Method method = contactInfo.getClass().getDeclaredMethod(qi.method);
				String ret = (String) method.invoke(contactInfo);
				return ret;
			} catch (NoSuchMethodException e) {
				e.printStackTrace();
			} catch (SecurityException e) {
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				e.printStackTrace();
			} catch (IllegalArgumentException e) {
				e.printStackTrace();
			} catch (InvocationTargetException e) {
				e.printStackTrace();
			}
		}
		return "";
	}
}
