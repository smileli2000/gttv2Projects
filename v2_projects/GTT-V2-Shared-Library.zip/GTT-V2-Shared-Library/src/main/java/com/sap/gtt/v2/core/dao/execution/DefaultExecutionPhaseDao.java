package com.sap.gtt.v2.core.dao.execution;

import com.sap.gtt.v2.core.entity.execution.ExecutionPhase;
import com.sap.gtt.v2.exception.DBException;
import com.sap.gtt.v2.util.DBUtils;
import com.sap.gtt.v2.util.SpringContextUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

/**
 * @author I302310
 */
@Repository(DefaultExecutionPhaseDao.BEAN_NAME)
public class DefaultExecutionPhaseDao implements IExecutionPhaseDao {
    public static final String BEAN_NAME = "com.sap.gtt.v2.core.dao.execution.DefaultExecutionPhaseDao";
    public static final String TABLE_NAME = "EXECUTION_PHASE";

    public static final String SELECT_FROM = "select * from ";
    public static final String WEHRE = " where ";

    public static final String ID = "ID";
    public static final String EXECUTION_ID = "EXECUTION_ID";
    public static final String PHASE = "PHASE";
    public static final String STATUS = "STATUS";

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public static DefaultExecutionPhaseDao getInstance() {
        return (DefaultExecutionPhaseDao) SpringContextUtils.getBean(BEAN_NAME);
    }

    @Override
    public ExecutionPhase queryExecutionPhase(String id) {
        List<String> args = new ArrayList<>();
        args.add(id);
        StringBuilder sql = new StringBuilder();
        sql.append(SELECT_FROM).append(DefaultExecutionPhaseDao.TABLE_NAME)
                .append(WEHRE)
                .append(ID).append("=?");
        List<ExecutionPhase> phases = query(sql.toString(), id);
        return phases.isEmpty() ? null : phases.get(0);
    }

    @Override
    public ExecutionPhase queryExecutionPhase(String executionHistoryId, String phase) {
        StringBuilder sql = new StringBuilder();
        sql.append(SELECT_FROM).append(DefaultExecutionPhaseDao.TABLE_NAME)
                .append(WEHRE)
                .append(EXECUTION_ID).append("=?").append(" AND ")
                .append(PHASE).append("=?");
        List<ExecutionPhase> phases = query(sql.toString(), executionHistoryId, phase);
        return phases.isEmpty() ? null : phases.get(0);
    }

    @Override
    public List<ExecutionPhase> queryExecutionPhases(String executionHistoryId) {
        StringBuilder sql = new StringBuilder();
        sql.append(SELECT_FROM).append(DefaultExecutionPhaseDao.TABLE_NAME)
                .append(WEHRE)
                .append(EXECUTION_ID).append("=?");
        return query(sql.toString(), executionHistoryId);
    }

    private List<ExecutionPhase> query(String sql, Object... args) {
        return jdbcTemplate.query(sql, args, (rs, rowNum) -> {
            String rs_id = rs.getString(ID);
            String rs_executionId = rs.getString(EXECUTION_ID);
            String rs_phase = rs.getString(PHASE);
            String rs_status = rs.getString(STATUS);
            return new ExecutionPhase(rs_id, rs_executionId, rs_phase, rs_status);
        });
    }

    @Override
    public void insertExecutionPhase(ExecutionPhase phase) {
        StringBuilder sql = new StringBuilder();
        String[] columns = {ID, EXECUTION_ID, PHASE, STATUS};
        DBUtils.buildInsertSql(TABLE_NAME, columns, sql);
        Object[] args = new Object[]{phase.getId(), phase.getExecutionId(), phase.getPhase(), phase.getStatus()};
        int affectedRows = jdbcTemplate.update(sql.toString(), args);
        if (affectedRows <= 0) {
            throw new DBException("Insert Execution_Phase data failed. Affected rows " + affectedRows);
        }
    }

    @Override
    public void updateExecutionPhaseStatus(String id, String status) {
        StringBuilder sql = new StringBuilder();
        String[] updatedColumns = {STATUS};
        Object[] updateValues = new Object[]{status};

        String[] whereColumns = {ID};
        Object[] whereValues = new Object[]{id};

        List<Object> updateParam = new ArrayList<>();

        DBUtils.buildUpdateSql(TABLE_NAME, updatedColumns, updateValues, whereColumns, whereValues, sql, updateParam);
        Object[] args = updateParam.toArray();
        jdbcTemplate.update(sql.toString(), args);
    }

}
