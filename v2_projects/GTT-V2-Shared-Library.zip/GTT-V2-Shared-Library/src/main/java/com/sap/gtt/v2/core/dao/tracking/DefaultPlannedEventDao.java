package com.sap.gtt.v2.core.dao.tracking;

import com.sap.gtt.v2.core.domain.metadata.CurrentMetadataEntity;
import com.sap.gtt.v2.core.domain.metadata.MetadataConstants;
import com.sap.gtt.v2.core.domain.metadata.PhysicalName;
import com.sap.gtt.v2.core.entity.trackedprocess.PlannedEvent;
import com.sap.gtt.v2.log.TenantAwareLogService;
import com.sap.gtt.v2.util.DBUtils;
import com.sap.gtt.v2.util.SpringContextUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static com.sap.gtt.v2.core.entity.trackedprocess.PlannedEvent.PROCESSID;

@Repository(DefaultPlannedEventDao.BEAN_NAME)
public class DefaultPlannedEventDao implements IPlannedEventDao {
    public static final String BEAN_NAME = "com.sap.gtt.v2.core.dao.tracking.DefaultPlannedEventDao";

    protected DefaultPlannedEventDao() {

    }

    public static DefaultPlannedEventDao getInstance() {
        return (DefaultPlannedEventDao) SpringContextUtils.getBean(BEAN_NAME);
    }

    @Autowired
    private DaoHelper daoHelper;

    @Autowired
    private TenantAwareLogService logService;

    @Override
    public void insert(List<PlannedEvent> plannedEvents) {
        if(plannedEvents.isEmpty()) {
            return;
        }
        PlannedEvent firstPlannedEvent = plannedEvents.get(0);
        PhysicalName physicalName = firstPlannedEvent.getMetadata().getCurrentEntity().getPhysicalName();

        List<Object[]> objects = new ArrayList<>();
        String sql = "";
        for (PlannedEvent plannedEvent : plannedEvents) {
            Pair<String, Object[]> pair = daoHelper.generateSqlForBatchInsert(physicalName.getCorePhysicalName(), plannedEvent, false);

            objects.add(pair.getRight());
            if (StringUtils.isEmpty(sql)) {
                sql = pair.getLeft();
            }
        }
        daoHelper.getJdbcTemplate().batchUpdate(sql, objects);

        if (physicalName.isCoreExtensionEntity()) {
            objects = new ArrayList<>();
            sql = "";
            for (PlannedEvent plannedEvent : plannedEvents) {
                Pair<String, Object[]> pair = daoHelper.generateSqlForBatchInsert(physicalName.getExtendedPhysicalName(), plannedEvent, true);

                objects.add(pair.getRight());
                if (StringUtils.isEmpty(sql)) {
                    sql = pair.getLeft();
                }
            }
            daoHelper.getJdbcTemplate().batchUpdate(sql, objects);
        }
    }

    @Override
    public void update(PlannedEvent plannedEvent) {
        daoHelper.update(plannedEvent);
    }

    @Override
    public PlannedEvent findOne(CurrentMetadataEntity metadata, UUID id) {
        return daoHelper.findOneByPrimaryKey(PlannedEvent.class, metadata, id);
    }

    @Override
    public void deleteByProcessId(UUID processId, PhysicalName physicalName) {
        String sql = null;
        if (physicalName.isCoreExtensionEntity()) {
            sql = new StringBuilder("delete from ")
                    .append(physicalName.getExtendedPhysicalName())
                    .append(" where ").append(DBUtils.toElementPhysicalName(PlannedEvent.ID))
                    .append(" in (select ").append(DBUtils.toElementPhysicalName(PlannedEvent.ID))
                    .append(" from ")
                    .append(physicalName.getName())
                    .append(" where ").append(PROCESSID)
                    .append(" = ? )").toString();
            logService.debug("sql:{}, values:{}", sql, processId);
            daoHelper.getJdbcTemplate().update(sql, processId);
        }

        sql = new StringBuilder("delete from ")
                .append(DBUtils.toTableName(
                        MetadataConstants.CoreModelEntity.PLANNED_EVENT.getFullName()))
                .append(" where ").append(PROCESSID)
                .append(" = ?").toString();
        logService.debug("sql:{}, values:{}", sql, processId);
        daoHelper.getJdbcTemplate().update(sql, processId);
    }
}
