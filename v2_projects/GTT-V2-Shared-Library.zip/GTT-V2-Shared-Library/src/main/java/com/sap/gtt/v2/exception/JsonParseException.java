package com.sap.gtt.v2.exception;

import org.apache.http.HttpStatus;

/**
 * @author I301346
 */
public class JsonParseException extends BaseRuntimeException {
    public static final String ERROR_CODE = "ERROR_CODE_JSON_PARSE";


    public static final String MESSAGE_CODE_ERROR_DURATION_PARSE = JsonParseException.class.getName() + ".ErrorDurationParse";

    public JsonParseException(String messageCode, Object[] localizedMsgParams) {
        super(messageCode, localizedMsgParams);
    }

    public JsonParseException(Throwable cause, String messageCode, Object[] localizedMsgParams) {
        super(null, cause, messageCode, localizedMsgParams);
    }

    @Override
    public int getHttpStatus() {
        return HttpStatus.SC_BAD_REQUEST;
    }

    @Override
    public String getErrorCode() {
        return ERROR_CODE;
    }
}
