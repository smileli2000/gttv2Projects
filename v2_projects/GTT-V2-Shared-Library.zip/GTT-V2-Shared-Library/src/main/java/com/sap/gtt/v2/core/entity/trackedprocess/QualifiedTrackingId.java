package com.sap.gtt.v2.core.entity.trackedprocess;

import com.sap.gtt.v2.core.domain.trackedprocess.Constant;
import com.sap.gtt.v2.core.runtime.model.IPropertyValue;
import com.sap.gtt.v2.core.runtime.model.ObjectValue;

import java.time.Instant;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

public class QualifiedTrackingId extends ObjectValue {
    public static final String PROCESSID = "process_id";
    public static final String OBSERVEDPROCESSID = "observedProcess_id";
    public static final String VALIDFROM = "validFrom";
    public static final String VALIDTO = "validTo";

    public QualifiedTrackingId() {super();}

    public static QualifiedTrackingId build(UUID processId, UUID observedProcessId,
                                            Instant validFrom, Instant validTo) {
        QualifiedTrackingId qualifiedTrackingId = new QualifiedTrackingId();
        qualifiedTrackingId.setProcessId(processId);
        qualifiedTrackingId.setObservedProcessId(observedProcessId);
        qualifiedTrackingId.setValidFrom(validFrom == null ? Constant.MIN_TIMESTAMP : validFrom);
        qualifiedTrackingId.setValidTo(validTo == null ? Constant.MAX_TIMESTAMP : validTo);
        return qualifiedTrackingId;
    }

    public QualifiedTrackingId(Map<String, IPropertyValue> internalValue) {
        super(internalValue);
    }

    public UUID getProcessId() {
        return getValueAsUUID(PROCESSID);
    }

    public void setProcessId(UUID processId) {
        setValue(PROCESSID, processId);
    }

    public UUID getObservedProcessId() {
        return getValueAsUUID(OBSERVEDPROCESSID);
    }

    public void setObservedProcessId(UUID observedProcessId) {
        setValue(OBSERVEDPROCESSID, observedProcessId);
    }

    public Instant getValidFrom() {
        return getValueAsTimeStamp(VALIDFROM);
    }

    public void setValidFrom(Instant validFrom) {
        setValue(VALIDFROM, validFrom);
    }

    public Instant getValidTo() {
        return getValueAsTimeStamp(VALIDTO);
    }

    public void setValidTo(Instant validTo) {
        setValue(VALIDTO, validTo);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null) {
            return false;
        }
        if (this.getClass() != o.getClass()) {
            return false;
        }
        QualifiedTrackingId that = (QualifiedTrackingId) o;
        return Objects.equals(getProcessId(), that.getProcessId()) &&
                Objects.equals(getObservedProcessId(), that.getObservedProcessId()) &&
                Objects.equals(getValidFrom(), that.getValidFrom()) &&
                Objects.equals(getValidTo(), that.getValidTo());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getProcessId(), getObservedProcessId(), getValidFrom(), getValidTo());
    }

    @Override
    public String toString() {
        return "QualifiedTrackingId{" +
                "processId=" + getProcessId() +
                ", observedProcessId=" + getObservedProcessId() +
                ", validFrom=" + getValidFrom() +
                ", validTo=" + getValidTo() +
                '}';
    }
}
