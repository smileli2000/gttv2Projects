package com.sap.gtt.v2.core.rule.impl.function;

import java.time.Instant;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.http.HttpMethod;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.sap.gtt.v2.configuration.AccessContextHolder;
import com.sap.gtt.v2.configuration.AccessContextHolder.AccessContext;
import com.sap.gtt.v2.configuration.EnvironmentsConfiguration.VcapServiceParser.DestinationServiceInstance;
import com.sap.gtt.v2.configuration.EnvironmentsConfiguration.VcapServiceParser.DestinationServiceInstance.Destination;
import com.sap.gtt.v2.configuration.EnvironmentsConfiguration.VcapServiceParser.UaaServiceInstance;
import com.sap.gtt.v2.configuration.ISAPCloudPlatformAgent.ICurrentAccessContext;
import com.sap.gtt.v2.configuration.ServiceInstancesMapping;
import com.sap.gtt.v2.controller.DefaultExceptionHandler;
import com.sap.gtt.v2.core.domain.execution.ExecutionMessageDto;
import com.sap.gtt.v2.core.domain.execution.ExecutionStatus;
import com.sap.gtt.v2.core.domain.execution.Phase;
import com.sap.gtt.v2.core.management.execution.IMessageLogManagement;
import com.sap.gtt.v2.core.rule.impl.GTTEmbededRuleScriptConsts;
import com.sap.gtt.v2.core.rule.impl.MemoryBlock;
import com.sap.gtt.v2.core.rule.impl.MemoryBlockException;
import com.sap.gtt.v2.core.runtime.model.BooleanValue;
import com.sap.gtt.v2.core.runtime.model.IFunction;
import com.sap.gtt.v2.core.runtime.model.IPropertyValue;
import com.sap.gtt.v2.core.runtime.model.NullValue;
import com.sap.gtt.v2.core.runtime.model.StringValue;
import com.sap.gtt.v2.log.TenantAwareLogService;
import com.sap.gtt.v2.util.GTTUtils;
import com.sap.gtt.v2.util.JsonUtils;
import com.sap.gtt.v2.util.SpringContextUtils;


public class ForwardCurrentTP implements IFunction{

	@Override
	public IPropertyValue execute(IPropertyValue callerObject, List<IPropertyValue> args)
			throws MemoryBlockException {
		StringValue destinationName = (StringValue)args.get(0);
		BooleanValue destinationInPaasAccount = (BooleanValue)args.get(1);
		BooleanValue containsTPBeforeEventPost = (BooleanValue)args.get(2);
		BooleanValue async = (BooleanValue)args.get(3);
		if(async.getInternalValue()){
			// prepare jwt context
			// set access context in context holder
			ICurrentAccessContext currentContext = SpringContextUtils.getBean(ICurrentAccessContext.class);
			AccessContextHolder.AccessContext accessContext = currentContext.cloneContext();
			
			SpringContextUtils.getBean(AsyncForwardCurrentTP.class).asyncExecute(callerObject, destinationName, destinationInPaasAccount, containsTPBeforeEventPost, accessContext);
		}
		else{
			SpringContextUtils.getBean(SyncForwardCurrentTP.class).execute(callerObject, destinationName, destinationInPaasAccount,containsTPBeforeEventPost);
		}
		
		return NullValue.NULL;
	}
	
	@Service
	@Primary
	public static class SyncForwardCurrentTP{
		protected void execute(IPropertyValue callerObject, StringValue destinationName,BooleanValue destinationInPaasAccount,
				BooleanValue containsTPBeforeEventPost)
				throws MemoryBlockException{
			TenantAwareLogService logService = SpringContextUtils.getBean(TenantAwareLogService.class);
			
			logService.info("Executing forwardCurrentTP...");
			// read destination
			ServiceInstancesMapping serviceInstancesMapping = SpringContextUtils.getBean(ServiceInstancesMapping.class);
			ICurrentAccessContext currentAccessContext = SpringContextUtils.getBean(ICurrentAccessContext.class);
			
			Destination destination = null;
			DestinationServiceInstance destinationServiceInstance = serviceInstancesMapping.getDestinationServiceInstance();
			if(destinationInPaasAccount.getInternalValue()){
				logService.info("forwardCurrentTP for Paas...");
				UaaServiceInstance masterUaaInstance = serviceInstancesMapping.getUaaServiceInstance();
				destination = destinationServiceInstance.readFromPaasSubaccountByCloneInstanceId(masterUaaInstance, currentAccessContext.getCloneServiceInstanceId(), destinationName.getInternalValue());
			
			}
			else{
				logService.info("forwardCurrentTP for Saas...");
				String subdomain = currentAccessContext.getSubdomain();
				destination = destinationServiceInstance.readFromSaasSubaccount(subdomain, destinationName.getInternalValue());
			}
			
			// send request
			MemoryBlock caller = (MemoryBlock)callerObject;
			IPropertyValue trackedProcess = caller.getVariableValue(GTTEmbededRuleScriptConsts.SYSTEM_VAR_TRACKED_PROCESS);
			IPropertyValue actualEvent = caller.getVariableValue(GTTEmbededRuleScriptConsts.SYSTEM_VAR_ACTUAL_EVENT);
			IPropertyValue plannedEvent = caller.getVariableValue(GTTEmbededRuleScriptConsts.SYSTEM_VAR_PLANNED_EVENT);
			
			IPropertyValue oldTrackedProcess = caller.getVariableValue(GTTEmbededRuleScriptConsts.SYSTEM_VAR_TRACKED_PROCESS_BEFORE_EVENT_POST);
			IPropertyValue oldPlannedEvent = caller.getVariableValue(GTTEmbededRuleScriptConsts.SYSTEM_VAR_PLANNED_EVENT_BEFORE_EVENT_POST);
			
			//TODO: Need JSON Serilization
			JsonObject requestBody = new JsonObject();
			JsonElement actualEventJson = JsonUtils.fromIPropertyValue(actualEvent);
			JsonElement trackedProcessJson = JsonUtils.fromIPropertyValue(trackedProcess);
			JsonElement plannedEventJson = JsonUtils.fromIPropertyValue(plannedEvent);
			
			requestBody.add(GTTEmbededRuleScriptConsts.SYSTEM_VAR_TRACKED_PROCESS, trackedProcessJson);
			requestBody.add(GTTEmbededRuleScriptConsts.SYSTEM_VAR_ACTUAL_EVENT, actualEventJson);
			requestBody.add(GTTEmbededRuleScriptConsts.SYSTEM_VAR_PLANNED_EVENT, plannedEventJson);
			
			if(containsTPBeforeEventPost.getInternalValue()){
				// also contains old TP and planned event
				JsonElement oldTrackedProcessJson = JsonUtils.fromIPropertyValue(oldTrackedProcess);
				JsonElement oldPlannedEventJson = JsonUtils.fromIPropertyValue(oldPlannedEvent);
				
				requestBody.add(GTTEmbededRuleScriptConsts.SYSTEM_VAR_TRACKED_PROCESS_BEFORE_EVENT_POST, oldTrackedProcessJson);
				requestBody.add(GTTEmbededRuleScriptConsts.SYSTEM_VAR_PLANNED_EVENT_BEFORE_EVENT_POST, oldPlannedEventJson);
				
			}
			
			GTTUtils.sendRequest(destination, HttpMethod.POST, requestBody.toString(), String.class);

		}
	}
	
	@Service
	public static class AsyncForwardCurrentTP extends SyncForwardCurrentTP{
		@Autowired
	    private ICurrentAccessContext currentContext;
		private IMessageLogManagement getExecutionHistoryManagement() {
	        return currentContext.createBusinessOperator().getMessageLogManagement();
	    }
		
		private void insertExecutionMessage(String tag, String status, String error) {
	        ExecutionMessageDto executionMessageDto = new ExecutionMessageDto();
	        executionMessageDto.setPhase(Phase.PROCESS.name());
	        executionMessageDto.setMessageType(status);
	        executionMessageDto.setErrorAt(Instant.now());
	        executionMessageDto.setTag(tag);
	        if(error != null) {
	        	executionMessageDto.setMessage(error);
	        }
	        getExecutionHistoryManagement().insertExecutionMessage(executionMessageDto);
	    }
		
		@Async
		protected void asyncExecute(IPropertyValue callerObject, StringValue destinationName,
				BooleanValue destinationInPaasAccount,BooleanValue containsTPBeforeEventPost, AccessContext accessContext){
			// ineritable thread local will not work, because @Async reuse thread from pool which do not have current access at begining
			// copy only happend when new thread creation.
			String tag = GTTUtils.UUIDUtils.generateTimeBasedUUID().toString();
			insertExecutionMessage(tag, ExecutionStatus.PENDING.name(), null);
			
			AccessContextHolder.set(accessContext);
			try{
				this.execute(callerObject, destinationName, destinationInPaasAccount,containsTPBeforeEventPost);
				insertExecutionMessage(tag, ExecutionStatus.SUCCESS.name(), null);
			}
			catch(MemoryBlockException e){
				DefaultExceptionHandler exceptionHandler = SpringContextUtils.getBean(DefaultExceptionHandler.class);
				String errorMessage = exceptionHandler.handleException(e).getBody();
				TenantAwareLogService logService = SpringContextUtils.getBean(TenantAwareLogService.class);
				logService.error(errorMessage);
				
				insertExecutionMessage(tag, ExecutionStatus.ERROR.name(), e.getMessage());
			}
			finally{
				AccessContextHolder.clear();
			}
			
			
		}
		
		
	}
	
	

}
