package com.sap.gtt.v2.servicemanager;

import org.apache.http.HttpStatus;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.sap.gtt.v2.exception.GeneralNoneTranslatableException;

public class GTTPhysicalStorage {
	
	public static class PhysicalTypeNotSupportException extends GeneralNoneTranslatableException{

		/**
		 * 
		 */
		private static final long serialVersionUID = -5131875495925960575L;

		public PhysicalTypeNotSupportException(String physicalType) {
			super(String.format("Physical Type '%s' not support",  physicalType), null,HttpStatus.SC_BAD_REQUEST);
		}
		
	}
	@JsonInclude
	private String id;
	@JsonInclude
	private String physicalId;
	@JsonInclude
	private String physicalType;
	@JsonInclude
	private String globalAccountId;
	@JsonInclude
	private String globalAccountName;
	@JsonInclude
	private String orgId;
	@JsonInclude
	private String orgName;
	@JsonInclude
	private String spaceId;
	@JsonInclude
	private String spaceName;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPhysicalId() {
		return physicalId;
	}
	public void setPhysicalId(String physicalId) {
		this.physicalId = physicalId;
	}
	public String getPhysicalType() {
		return physicalType;
	}
	public void setPhysicalType(String physicalType) {
		this.physicalType = physicalType;
		
	}
	public String getGlobalAccountId() {
		return globalAccountId;
	}
	public void setGlobalAccountId(String globalAccountId) {
		this.globalAccountId = globalAccountId;
	}
	public String getGlobalAccountName() {
		return globalAccountName;
	}
	public void setGlobalAccountName(String globalAccountName) {
		this.globalAccountName = globalAccountName;
	}
	public String getOrgId() {
		return orgId;
	}
	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}
	public String getOrgName() {
		return orgName;
	}
	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}
	public String getSpaceId() {
		return spaceId;
	}
	public void setSpaceId(String spaceId) {
		this.spaceId = spaceId;
	}
	public String getSpaceName() {
		return spaceName;
	}
	public void setSpaceName(String spaceName) {
		this.spaceName = spaceName;
	}
	@Override
	public String toString() {
		return "GTTPhysicalStorage [id=" + id + ", physicalId=" + physicalId + ", physicalType=" + physicalType
				+ ", globalAccountId=" + globalAccountId + ", globalAccountName=" + globalAccountName + ", orgId="
				+ orgId + ", orgName=" + orgName + ", spaceId=" + spaceId + ", spaceName=" + spaceName + "]";
	}
	
	
}
