package com.sap.gtt.v2.exception;

import com.sap.gtt.v2.configuration.ISAPCloudPlatformAgent.ICurrentAccessContext;
import org.apache.commons.io.IOUtils;

import java.util.*;

public class MultiExceptionContainer extends BaseRuntimeException {
    private final String errorCode;
    private final int httpStatus;
    private final List<Exception> containedExceptions = new ArrayList<>();

    public MultiExceptionContainer(int httpStatus) {
        super(null, null, "", null);
        this.httpStatus = httpStatus;
        this.errorCode = "ERROR_CODE_MULTI";
    }

    public MultiExceptionContainer(int httpStatus, String errorCode) {
        super(null, null, "", null);
        this.httpStatus = httpStatus;
        this.errorCode = errorCode;
    }

    private static int getHttpStatus(Exception e) {
        return ((BaseRuntimeException) e).getHttpStatus();
    }

    public List<Exception> getContainedExceptions() {
        return Collections.unmodifiableList(containedExceptions);
    }

    @Override
    public int getHttpStatus() {
        Optional<Exception> maxHttpStatusCodeException = containedExceptions.stream()
                .filter(e -> e instanceof BaseRuntimeException)
                .max(Comparator.comparingInt(MultiExceptionContainer::getHttpStatus));
        return maxHttpStatusCodeException.map(MultiExceptionContainer::getHttpStatus)
                .orElseGet(() -> httpStatus);
    }

    public void addException(Exception exception) {
        if (exception instanceof MultiExceptionContainer) {
            this.containedExceptions.addAll(((MultiExceptionContainer) exception).getContainedExceptions());
        } else {
            this.containedExceptions.add(exception);
        }
    }

    public void addExceptions(List<Exception> exceptions) {
        this.containedExceptions.addAll(exceptions);
    }

    @Override
    public Object[] getLocalizedMsgParams() {
        // should never be invoked
        throw new UnsupportedOperationException();
    }


    @Override
    public String getMessage() {
        StringBuilder sb = new StringBuilder();
        for (Exception exception : this.getContainedExceptions()) {
            sb.append(exception.getMessage()).append(IOUtils.LINE_SEPARATOR);
        }
        return sb.toString();
    }

    @Override
    public String getLocalizedMessage() {
        StringBuilder sb = new StringBuilder();
        for (Exception exception : this.getContainedExceptions()) {
            sb.append(exception.getLocalizedMessage()).append(IOUtils.LINE_SEPARATOR);
        }
        return sb.toString();
    }

    @Override
    public FormattedErrorMessage getFormattedErrorMessage() {
        List<FormattedErrorMessage> containedFormattedErrorMessages = new ArrayList<>();
        for (Exception e : this.getContainedExceptions()) {
            if (e instanceof BaseRuntimeException) {
                containedFormattedErrorMessages.add(((BaseRuntimeException) e).getFormattedErrorMessage());
            } else {
                containedFormattedErrorMessages.add(new FormattedErrorMessage((String) null, e.getLocalizedMessage(), 0));
            }

        }

        return new FormattedErrorMessage(containedFormattedErrorMessages, ICurrentAccessContext.getLanguage(), this.getHttpStatus());
    }

    public boolean containsError() {
        return !this.getContainedExceptions().isEmpty();
    }

    @Override
    public String getErrorCode() {
        return errorCode;
    }
}
