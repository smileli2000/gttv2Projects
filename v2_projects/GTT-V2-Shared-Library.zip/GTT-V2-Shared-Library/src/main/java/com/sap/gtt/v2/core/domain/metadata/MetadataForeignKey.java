package com.sap.gtt.v2.core.domain.metadata;

import java.io.Serializable;

/**
 * To present the foreign key information from CSN.
 * For foreign keys info like {$generatedFieldName: "supplier_id", ref: "id"},
 * the "id" will be parsed as referenceFieldName, and "sender_id" will be parsed as
 * generatedFieldName.
 *
 * @author I321712
 */
public class MetadataForeignKey implements Serializable {
    private static final long serialVersionUID = 4118054122584264760L;

    private String generatedFieldName;
    private String referenceFieldName;

    public String getGeneratedFieldName() {
        return generatedFieldName;
    }

    public void setGeneratedFieldName(String generatedFieldName) {
        this.generatedFieldName = generatedFieldName;
    }

    public String getReferenceFieldName() {
        return referenceFieldName;
    }

    public void setReferenceFieldName(String referenceFieldName) {
        this.referenceFieldName = referenceFieldName;
    }
}
