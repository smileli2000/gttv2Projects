package com.sap.gtt.v2.core.dao.execution;

import com.sap.gtt.v2.core.entity.execution.RequestMapping;

import java.util.List;

public interface IRequestMappingDao {
    void insert(RequestMapping requestMapping);
    List<RequestMapping> queryRequestMappings(String requestId);
}
