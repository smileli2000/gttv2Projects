package com.sap.gtt.v2.core.dao.tracking;

import com.sap.gtt.v2.core.domain.metadata.CurrentMetadataEntity;
import com.sap.gtt.v2.core.domain.metadata.MetadataConstants;
import com.sap.gtt.v2.core.domain.trackedprocess.LifeCycleStatus;
import com.sap.gtt.v2.core.entity.trackedprocess.TrackedProcess;
import com.sap.gtt.v2.log.TenantAwareLogService;
import com.sap.gtt.v2.util.DBUtils;
import com.sap.gtt.v2.util.SpringContextUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;
import java.util.UUID;

import static com.sap.gtt.v2.core.entity.trackedprocess.TrackedProcess.*;

/**
 * Default implementation for Relational DB
 * @author I053866
 *
 */
@Repository(DefaultTrackedProcessDao.BEAN_NAME)
public class DefaultTrackedProcessDao implements ITrackedProcessDao{
	public static final String BEAN_NAME = "com.sap.gtt.v2.core.dao.tracking.DefaultTrackedProcessDao";

	protected DefaultTrackedProcessDao() {

	}

	public static DefaultTrackedProcessDao getInstance(){
		return (DefaultTrackedProcessDao)SpringContextUtils.getBean(BEAN_NAME);
	}

	@Autowired
	private DaoHelper daoHelper;
	@Autowired
	private TenantAwareLogService logService;

	@Override
	public void insert(TrackedProcess trackedProcess) {
		daoHelper.insert(trackedProcess);
	}

	@Override
	public void insert(List<TrackedProcess> trackedProcessList) {
		for(TrackedProcess tp : trackedProcessList) {
			insert(tp);
		}
	}

	@Override
	public void update(TrackedProcess trackedProcess, Integer version) {
		daoHelper.update(trackedProcess, version);
	}

	@Override
	public void delete(CurrentMetadataEntity metadata, UUID id) {
		daoHelper.delete(metadata, id);
	}

	@Override
	public void delete(TrackedProcess trackedProcess) {
		daoHelper.delete(trackedProcess);
	}

	@Override
	public TrackedProcess findOneByAltKey(CurrentMetadataEntity metadata, String altKey) {
		List<TrackedProcess> objects = daoHelper.findAll(TrackedProcess.class, metadata, "altKey = ?", altKey);
		return objects.isEmpty()?null:objects.get(0);
	}

	@Override
	public List<TrackedProcess> findAllByAltKeys(CurrentMetadataEntity metadata, List<String> altKeyList) {
		return daoHelper.findAll(TrackedProcess.class, metadata,"altKey in (:altKeyList)",
				new MapSqlParameterSource().addValue("altKeyList", altKeyList));
	}

	@Override
	public List<TrackedProcess> findAllByAltKeys(CurrentMetadataEntity metadata, String... altKeys) {
		return daoHelper.findAll(TrackedProcess.class, metadata, "altKey in (:altKeys)",
				new MapSqlParameterSource().addValue("altKeys", altKeys));
	}

	@Override
	public List<TrackedProcess> findAllByNamespace(String namespace) {
		String sql = new StringBuilder("select * from ")
				.append(DBUtils.toTableName(
						MetadataConstants.CoreModelEntity.TRACKED_PROCESS.getFullName()))
				.append(" where TRACKEDPROCESSTYPE LIKE ? ").toString();

		logService.debug("sql:{}, values:{}", sql, namespace);
		List<TrackedProcess> trackedProcessList = daoHelper.getJdbcTemplate().query(sql, new Object[]{namespace + ".%"},
				new TrackedProcessRowMapper());
		return trackedProcessList;
	}

	@Override
	public TrackedProcess findOne(CurrentMetadataEntity metadata, UUID id) {
		return daoHelper.findOneByPrimaryKey(TrackedProcess.class, metadata, id);
	}

	@Override
	public boolean versionExists(TrackedProcess tp, int version) {
		return daoHelper.versionExists(tp, version);
	}

	@Override
	public TrackedProcess findOneWithValidStatus(UUID id) {
		String sql = new StringBuilder("select * from ")
				.append(DBUtils.toTableName(
						MetadataConstants.CoreModelEntity.TRACKED_PROCESS.getFullName()))
				.append(" where ").append(TrackedProcess.ID)
				.append(" = ? and ")
				.append(LIFE_CYCLE_STATUS).append(" <> '").append(END_OF_PURPOSE).append("' and ")
				.append(LIFE_CYCLE_STATUS).append(" <> '").append(END_OF_RETENTION).append("'").toString();

		logService.debug("sql:{}, values:{}", sql, id);
		List<TrackedProcess> trackedProcessList = daoHelper.getJdbcTemplate().query(sql, new Object[]{id},
				new TrackedProcessRowMapper());

		return trackedProcessList.isEmpty()?null:trackedProcessList.get(0);
	}

	@Override
	public TrackedProcess findOne(UUID id) {
		String sql = new StringBuilder("select * from ")
				.append(DBUtils.toTableName(
						MetadataConstants.CoreModelEntity.TRACKED_PROCESS.getFullName()))
				.append(" where ").append(TrackedProcess.ID)
				.append(" = ? ").toString();

		logService.debug("sql:{}, values:{}", sql, id);
		List<TrackedProcess> trackedProcessList = daoHelper.getJdbcTemplate().query(sql, new Object[]{id},
				new TrackedProcessRowMapper());

		return trackedProcessList.isEmpty()?null:trackedProcessList.get(0);
	}

	private static class TrackedProcessRowMapper implements RowMapper<TrackedProcess> {

		@Override
		public TrackedProcess mapRow(ResultSet rs, int rowNum) throws SQLException {
			TrackedProcess tp = new TrackedProcess();
			tp.setVersion(rs.getInt(TrackedProcess.VERSION));
			tp.setTrackedProcessType(rs.getString(TrackedProcess.TRACKED_PROCESS_TYPE));
			String strValue = rs.getString(TrackedProcess.SUBACCOUNTID);
			tp.setSubaccountId(StringUtils.isEmpty(strValue)?null:UUID.fromString(strValue));

			strValue = rs.getString(TrackedProcess.CLONEINSTANCEID);
			tp.setCloneInstanceId(StringUtils.isEmpty(strValue)?null:UUID.fromString(strValue));

			Timestamp timestamp;
			timestamp = rs.getTimestamp(TrackedProcess.LAST_CHANGED_DATE_TIME);
			tp.setLastChangedDateTime(timestamp==null?null:timestamp.toInstant());

			tp.setLastChangedByUser(rs.getString(TrackedProcess.LAST_CHANGED_BY_USER));

			timestamp = rs.getTimestamp(TrackedProcess.CREATION_DATE_TIME);
			tp.setCreationDateTime(timestamp==null?null:timestamp.toInstant());

			tp.setCreatedByUser(rs.getString(TrackedProcess.CREATED_BY_USER));
			tp.setPartyId(rs.getString(TrackedProcess.PARTYID));
			tp.setProcessStatus(rs.getString(TrackedProcess.PROCESS_STATUS));
			tp.setScheme(rs.getString(TrackedProcess.SCHEME));
			tp.setAltKey(rs.getString(TrackedProcess.ALT_KEY));

			strValue = rs.getString(TrackedProcess.LIFE_CYCLE_STATUS);
			tp.setLifeCycleStatus(
					StringUtils.isEmpty(strValue)?null: LifeCycleStatus.fromValue(strValue));

			tp.setTrackingIdType(rs.getString(TrackedProcess.TRACKING_ID_TYPE));
			strValue = rs.getString(TrackedProcess.ID);
			tp.setId(StringUtils.isEmpty(strValue)?null:UUID.fromString(strValue));

			tp.setLogicalSystem(rs.getString(TrackedProcess.LOGICAL_SYSTEM));

			return tp;
		}
	}
}
