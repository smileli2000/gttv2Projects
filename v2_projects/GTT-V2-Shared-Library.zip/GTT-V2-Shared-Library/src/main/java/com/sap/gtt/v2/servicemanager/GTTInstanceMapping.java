package com.sap.gtt.v2.servicemanager;

import org.apache.http.HttpStatus;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.sap.gtt.v2.exception.GeneralNoneTranslatableException;

public class GTTInstanceMapping {

	public static final String PLAN_SHARED = "shared";
	public static final String PLAN_STANDALONE = "standalone";
	@JsonInclude
	private String id;
	@JsonInclude
	private String cloneInstanceId;
	@JsonInclude
	private String plan;
	@JsonInclude
	private String subaccountId;
	@JsonInclude
	private String subdomain;
	@JsonInclude
	private String instanceId;
	
	public static class PlanNotSupportException extends GeneralNoneTranslatableException{

		/**
		 * 
		 */
		private static final long serialVersionUID = 1722467634755323818L;

		public PlanNotSupportException(String plan) {
			super(String.format("Plan '%s' not support",  plan), null,HttpStatus.SC_BAD_REQUEST);
		}
		
	}
	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getCloneInstanceId() {
		return cloneInstanceId;
	}
	public void setCloneInstanceId(String cloneInstanceId) {
		this.cloneInstanceId = cloneInstanceId;
	}
	public String getPlan() {
		return plan;
	}
	public void setPlan(String plan) {
		this.plan = plan;
	}
	public String getSubaccountId() {
		return subaccountId;
	}
	public void setSubaccountId(String subaccountId) {
		this.subaccountId = subaccountId;
	}
	public String getInstanceId() {
		return instanceId;
	}
	public void setInstanceId(String instanceId) {
		this.instanceId = instanceId;
	}
	public String getSubdomain() {
		return subdomain;
	}
	public void setSubdomain(String subdomain) {
		this.subdomain = subdomain;
	}
	
	@Override
	public String toString() {
		return "GTTInstanceMapping [id=" + id + ", cloneInstanceId=" + cloneInstanceId + ", plan=" + plan
				+ ", subaccountId=" + subaccountId + ", subdomain=" + subdomain + ", instanceId=" + instanceId + "]";
	}
	
	
}
