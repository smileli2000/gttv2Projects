package com.sap.gtt.v2.core.dao.metadata;

import com.sap.gtt.v2.core.domain.metadata.MetadataEntityElement;
import com.sap.gtt.v2.util.DBUtils;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * DDL builder for HANA database
 *
 * @author I321712
 */
@Component
public class DDLBuilderHanaImpl extends AbstractDefaultDDLBuilder {

    public static final String CURRENT_SCHEMA_CONDITION = "SCHEMA_NAME = CURRENT_SCHEMA";
    public static final String TABLES = "TABLES";

    @Override
    public String buildCreateTable(String entityName, List<MetadataEntityElement> elements) {
        return buildCreateTableSQL(entityName, elements, true, false);
    }

    @Override
    public List<String> buildAlterTableField(String entityName, List<MetadataEntityElement> elements) {
        List<String> updateFieldSqls = new ArrayList<>();
        String tableName = DBUtils.toTableName(entityName);
        for (int i = 0; i < elements.size(); i++) {
            StringBuilder sb = new StringBuilder("ALTER TABLE ").append(tableName).append(" ALTER ");
            sb.append("(");
            MetadataEntityElement element = elements.get(i);
            buildColumn(element, sb);
            sb.append(")");
            updateFieldSqls.add(sb.toString());
        }
        return updateFieldSqls;
    }

    @Override
    protected String getSysTablesName() {
        return TABLES;
    }

    @Override
    protected String getCurrentSchemaCondition() {
        return CURRENT_SCHEMA_CONDITION;
    }
}
