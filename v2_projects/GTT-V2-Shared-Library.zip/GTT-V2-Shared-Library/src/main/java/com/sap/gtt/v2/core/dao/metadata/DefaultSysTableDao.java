package com.sap.gtt.v2.core.dao.metadata;

import com.sap.gtt.v2.configuration.ISAPCloudPlatformAgent.ICurrentAccessContext;
import com.sap.gtt.v2.core.dao.metadata.DDLBuilder.DDLAction;
import com.sap.gtt.v2.core.domain.metadata.*;
import com.sap.gtt.v2.core.management.metadata.CsnParser;
import com.sap.gtt.v2.util.DBUtils;
import com.sap.gtt.v2.util.SpringContextUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Repository;

import java.util.*;
import java.util.stream.Collectors;

import static com.sap.gtt.v2.configuration.EnvironmentsConfiguration.VcapServiceParser.DatabaseServiceInstance.DatabaseType;
import static com.sap.gtt.v2.core.dao.metadata.DDLBuilder.DDLAction.*;
import static com.sap.gtt.v2.core.domain.metadata.MetadataConstants.CdsDataType.CDS_ASSOCIATION;
import static com.sap.gtt.v2.core.domain.metadata.MetadataConstants.CdsDataType.CDS_COMPOSITION;

/**
 * @author I321712
 */
@Repository(DefaultSysTableDao.BEAN_NAME)
public class DefaultSysTableDao implements ISysTableDao {
    public static final String BEAN_NAME = "com.sap.gtt.v2.core.dao.metadata.DefaultSysTableDao";
    public static final String TABLE_NAME = "TABLE_NAME";

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private ICurrentAccessContext currentAccessContext;

    public static DefaultSysTableDao getInstance() {
        return (DefaultSysTableDao) SpringContextUtils.getBean(BEAN_NAME);
    }

    @Override
    public void createTable(List<MetadataEntity> newEntities) {
        execueUpdate(newEntities, CREATE_TABLE);
    }

    @Override
    public void dropTable(List<MetadataEntity> tobeDroppedEntities) {
        execueUpdate(tobeDroppedEntities, DROP_TABLE);
    }

    @Override
    public void addTableField(List<MetadataEntity> newFieldEntities) {
        execueUpdate(newFieldEntities, ADD_TABLE_COLUMN);
    }

    @Override
    public void modifyTableField(List<MetadataEntity> modifiedFieldEntities) {
        execueUpdate(modifiedFieldEntities, DDLAction.ALTER_TABLE_COLUMN);
    }

    @Override
    public void deleteTableField(List<MetadataEntity> deletedFieldEntities) {
        execueUpdate(deletedFieldEntities, DROP_TABLE_COLUMN);
    }

    @Override
    public long countTableRows(MetadataEntity metadataEntity) {
        String tableName = DBUtils.toTableName(metadataEntity.getName());
        StringBuilder ifExist = new StringBuilder("SELECT COUNT(1) AS I_COUNT FROM TABLES where SCHEMA_NAME = CURRENT_SCHEMA AND TABLE_NAME = '")
                .append(tableName.toUpperCase()).append("'");
        SqlRowSet exist = jdbcTemplate.queryForRowSet(ifExist.toString());
        exist.next();
        if(exist.getLong("I_COUNT") != 0){
            StringBuilder sb = new StringBuilder("SELECT COUNT(*) AS TOTAL FROM ").append(tableName);
            SqlRowSet result = jdbcTemplate.queryForRowSet(sb.toString());
            result.next();
            return result.getLong("TOTAL");
        }else {
            return -1;
        }
    }

    private void execueUpdate(List<MetadataEntity> newFieldEntities, DDLAction ddlAction) {
        cleanEntity(newFieldEntities);
        if (newFieldEntities.isEmpty()) {
            return;
        }
        DatabaseType databaseType = currentAccessContext.getDatabaseServiceInstance().getDatabaseType();
        DDLBuilder ddlBuilder = DBUtils.getDDLBuilder(databaseType);
        List<String> updateSqls = new ArrayList<>();
        if (ddlAction.equals(ADD_TABLE_COLUMN)) {
            StringBuilder tableQuerySql = new StringBuilder();
            List<String> params = new ArrayList<>();
            Map<String, MetadataEntity> entityMap = tableName2EntityMap(newFieldEntities);
            ddlBuilder.buildFindTableQuery(newFieldEntities, tableQuerySql, params);
            List<Map<String, Object>> tableMaps = jdbcTemplate.queryForList(tableQuerySql.toString(), params.toArray());
            List<MetadataEntity> tableExistedEntities = new ArrayList<>();
            if (!tableMaps.isEmpty()) {
                tableMaps.forEach(obj -> {
                    String tableName = obj.get(TABLE_NAME).toString().toUpperCase(Locale.ENGLISH);
                    tableExistedEntities.add(entityMap.get(tableName));
                    entityMap.remove(tableName);
                });
            }
            List<MetadataEntity> noTableEntities = new ArrayList<>(entityMap.values());
            if (!tableExistedEntities.isEmpty()) {
                compositeUpdateSql(tableExistedEntities, ADD_TABLE_COLUMN, ddlBuilder, updateSqls);
            }
            if (!noTableEntities.isEmpty()) {
                compositeUpdateSql(noTableEntities, CREATE_TABLE, ddlBuilder, updateSqls);
            }
        } else {
            compositeUpdateSql(newFieldEntities, ddlAction, ddlBuilder, updateSqls);
        }
        if (!updateSqls.isEmpty()) {
            jdbcTemplate.batchUpdate(updateSqls.toArray(new String[0]));
        }
    }

    private void cleanEntity(List<MetadataEntity> newFieldEntities) {
        Iterator<MetadataEntity> iterator = newFieldEntities.iterator();
        while (iterator.hasNext()) {
            MetadataEntity entity = iterator.next();
            String entityName = entity.getName();
            List<MetadataEntityElement> elements = entity.getElements().stream()
                    .filter(e -> !Arrays.asList(CDS_COMPOSITION, CDS_ASSOCIATION).contains(e.getType())
                            && (e.isKey() || e.isCustomizedField())).collect(Collectors.toList());
            boolean noNeedCreated = CsnParser.isCoreModelEntity(entityName)
                    || CsnParser.isForWriteEntity(entityName)
                    || elements.isEmpty()
                    || (elements.size() == 1 && elements.get(0).isKey());
            if (noNeedCreated) {
                iterator.remove();
            } else {
                entity.clearElements();
                elements.forEach(entity::addElement);
            }
        }
    }

    private void compositeUpdateSql(List<MetadataEntity> newFieldEntities, DDLAction ddlAction, DDLBuilder ddlBuilder, List<String> updateSqls) {
        for (MetadataEntity entity : newFieldEntities) {
            String entityName = entity.getName();
            List<MetadataEntityElement> elements = entity.getElements();
            String sql = null;
            switch (ddlAction) {
                case CREATE_TABLE:
                    sql = ddlBuilder.buildCreateTable(entityName, elements);
                    break;
                case ADD_TABLE_COLUMN:
                    removePrimarykeys(elements);
                    sql = ddlBuilder.buildAddTableField(entityName, elements);
                    break;
                case DROP_TABLE_COLUMN:
                    sql = ddlBuilder.buildDropTableField(entityName, elements);
                    break;
                case ALTER_TABLE_COLUMN:
                    List<String> alterTableFields = ddlBuilder.buildAlterTableField(entityName, elements);
                    updateSqls.addAll(alterTableFields);
                    break;
                case DROP_TABLE:
                    sql = ddlBuilder.buildDropTable(entityName);
                default:
            }
            if (StringUtils.isNotBlank(sql)) {
                updateSqls.add(sql);
            }
        }
    }

    private void removePrimarykeys(List<MetadataEntityElement> elements) {
        Iterator<MetadataEntityElement> iterator = elements.iterator();
        while (iterator.hasNext()) {
            MetadataEntityElement next = iterator.next();
            if (next.isKey()) {
                iterator.remove();
            }
        }
    }

    private Map<String, MetadataEntity> tableName2EntityMap(List<MetadataEntity> entities) {
        Map<String, MetadataEntity> ret = new HashMap<>(MetadataConstants.INITIAL_CAPACITY);
        for (MetadataEntity entity : entities) {
            PhysicalName physicalName = entity.getPhysicalName();
            if (physicalName != null) {
                String name = physicalName.getName();
                if (StringUtils.isNotBlank(name)) {
                    ret.put(physicalName.getName().toUpperCase(Locale.ENGLISH), entity);
                }
            }
        }
        return ret;
    }

    @Override
    public void emptyTable(String tableName) {
        if(StringUtils.isBlank(tableName)) {
            return;
        }
        DatabaseType databaseType = getDatabaseType();
        DDLBuilder ddlBuilder = DBUtils.getDDLBuilder(databaseType);
        String sql = ddlBuilder.buildDeleteTable(tableName);
        jdbcTemplate.execute(sql);
    }

    @Override
    public void insertCodeList(CodeList codeList) {
        String tableName = codeList.getFullEntityName();
        List<CodeListValue> codeListValues = codeList.getCodeListValues();
        List<Object[]> batchArgs= new ArrayList<>();
        //insert code and name from codeLists
        compositeBatchArgsForCodeListValues(batchArgs, codeListValues);
        DatabaseType databaseType = getDatabaseType();
        DDLBuilder ddlBuilder = DBUtils.getDDLBuilder(databaseType);
        String sql = ddlBuilder.buildInsertTableForCodeList(tableName);
        jdbcTemplate.batchUpdate(sql, batchArgs);
    }

    private void compositeBatchArgsForCodeListValues(List<Object[]> batchArgs, List<CodeListValue> codeListValues) {
        codeListValues.forEach(codeListValue -> {
            batchArgs.add(new Object[]{codeListValue.getCode(), codeListValue.getName()});
        });
    }

    @Override
    public void insertCodeListTexts(CodeList codeList) {
        String tableName = codeList.getFullEntityName() + "_TEXTS";
        List<CodeListValue> codeListValues = codeList.getCodeListValues();
        List<Object[]> batchArgs= new ArrayList<>();
        //insert code and name from codeLists
        compositeBatchArgsForCodeListValuesTexts(batchArgs, codeListValues);
        DatabaseType databaseType = getDatabaseType();
        DDLBuilder ddlBuilder = DBUtils.getDDLBuilder(databaseType);
        String sql = ddlBuilder.buildInsertTableForCodeListTexts(tableName);
        jdbcTemplate.batchUpdate(sql, batchArgs);
    }

    private void compositeBatchArgsForCodeListValuesTexts(List<Object[]> batchArgs, List<CodeListValue> codeListValues) {
        codeListValues.forEach(codeListValue -> {
            List<CodeListText> codeListTexts = codeListValue.getCodeListTexts();
            codeListTexts.forEach(codeListText -> {
                batchArgs.add(new Object[]{codeListText.getCode(), codeListText.getName(), codeListText.getLanguage()});
            });
        });
    }

    private DatabaseType getDatabaseType() {
        return currentAccessContext.getDatabaseServiceInstance().getDatabaseType();
    }
}