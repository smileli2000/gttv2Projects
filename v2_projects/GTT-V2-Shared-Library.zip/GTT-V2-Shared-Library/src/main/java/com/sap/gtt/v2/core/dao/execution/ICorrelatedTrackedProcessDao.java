package com.sap.gtt.v2.core.dao.execution;

import com.sap.gtt.v2.core.entity.execution.CorrelatedTrackedProcess;

import java.util.List;

public interface ICorrelatedTrackedProcessDao {
    void insert(List<CorrelatedTrackedProcess> trackedProcesses);

    List<CorrelatedTrackedProcess> query(String executionId);
}
