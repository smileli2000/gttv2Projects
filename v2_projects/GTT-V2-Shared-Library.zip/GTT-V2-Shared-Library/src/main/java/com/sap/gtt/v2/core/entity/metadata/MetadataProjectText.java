package com.sap.gtt.v2.core.entity.metadata;

public class MetadataProjectText extends ObjectText {
    private String metadataProjectId;
    public String getMetadataProjectId() {
        return metadataProjectId;
    }
    public void setMetadataProjectId(String metadataProjectId) {
        this.metadataProjectId = metadataProjectId;
    }

    @Override
    public String toString() {
        return super.toString() +
                "MetadataProjectText{" +
                "metadataProjectId='" + metadataProjectId + '\'' +
                '}';
    }
}
