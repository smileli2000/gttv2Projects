package com.sap.gtt.v2.core.domain.trackedprocess;

/**
 * from v1
 */
public enum ObjectReference {
    PARENT, CHILD;
    @Override
    public String toString() {
        switch (this) {
            case PARENT:
                return "Parent";
            case CHILD:
                return "Child";
            default:
                return "";
        }
    }
}
