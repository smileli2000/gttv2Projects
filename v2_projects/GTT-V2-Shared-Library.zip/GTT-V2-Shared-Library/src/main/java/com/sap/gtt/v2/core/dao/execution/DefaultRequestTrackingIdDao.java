package com.sap.gtt.v2.core.dao.execution;

import com.sap.gtt.v2.core.entity.execution.RequestTrackingId;
import com.sap.gtt.v2.util.DBUtils;
import com.sap.gtt.v2.util.SpringContextUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

/**
 * @author I302310
 */
@Repository(DefaultRequestTrackingIdDao.BEAN_NAME)
public class DefaultRequestTrackingIdDao implements IRequestTrackingIdDao {
    public static final String BEAN_NAME = "com.sap.gtt.v2.core.dao.execution.DefaultRequestTrackingIdDao";
    public static final String TABLE_NAME = "REQUEST_TRACKING_ID";

    public static final String ID = "ID";
    public static final String REQUEST_ID = "REQUEST_ID";
    public static final String TRACKING_ID = "TRACKING_ID";

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public static DefaultRequestTrackingIdDao getInstance() {
        return (DefaultRequestTrackingIdDao) SpringContextUtils.getBean(BEAN_NAME);
    }

    @Override
    public void insertRequestTrackingIds(List<RequestTrackingId> trackingIds) {
        StringBuilder sql = new StringBuilder();
        String[] columns = {ID, REQUEST_ID, TRACKING_ID};
        DBUtils.buildInsertSql(TABLE_NAME, columns, sql);
        List<Object[]> argList = new ArrayList<>();
        for (RequestTrackingId trackingId : trackingIds) {
            Object[] args = new Object[]{trackingId.getId(), trackingId.getRequestId(), trackingId.getTrackingId()};
            argList.add(args);
        }
        jdbcTemplate.batchUpdate(sql.toString(), argList);
    }

    @Override
    public List<RequestTrackingId> queryRequestTrackingIds(String requestId) {
        List<String> args = new ArrayList<>();
        args.add(requestId);
        StringBuilder sql = new StringBuilder();
        sql.append("select * from ").append(TABLE_NAME)
                .append(" where ")
                .append(REQUEST_ID).append("=?");
        return jdbcTemplate.query(sql.toString(), args.toArray(), (rs, rowNum) -> {
            String rs_id = rs.getString(ID);
            String rs_requestId = rs.getString(REQUEST_ID);
            String rs_trackingId = rs.getString(TRACKING_ID);
            return new RequestTrackingId(rs_id, rs_requestId, rs_trackingId);
        });
    }
}
