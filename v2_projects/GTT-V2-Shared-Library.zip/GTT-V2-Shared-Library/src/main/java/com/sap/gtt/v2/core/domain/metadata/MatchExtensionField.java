package com.sap.gtt.v2.core.domain.metadata;

import java.io.Serializable;
import java.util.Objects;

public class MatchExtensionField implements Serializable {

    private static final long serialVersionUID = 4116860872437032200L;
    private String sourceObject;
    private String sourceField;
    private String targetObject;
    private String targetField;
    private String operator;

    public String getSourceObject() {
        return sourceObject;
    }

    public void setSourceObject(String sourceObject) {
        this.sourceObject = sourceObject;
    }

    public String getSourceField() {
        return sourceField;
    }

    public void setSourceField(String sourceField) {
        this.sourceField = sourceField;
    }

    public String getTargetObject() {
        return targetObject;
    }

    public void setTargetObject(String targetObject) {
        this.targetObject = targetObject;
    }

    public String getTargetField() {
        return targetField;
    }

    public void setTargetField(String targetField) {
        this.targetField = targetField;
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        MatchExtensionField that = (MatchExtensionField) o;
        return Objects.equals(sourceObject, that.sourceObject) &&
                Objects.equals(sourceField, that.sourceField) &&
                Objects.equals(targetObject, that.targetObject) &&
                Objects.equals(targetField, that.targetField) &&
                Objects.equals(operator, that.operator);
    }

    @Override
    public int hashCode() {
        return Objects.hash(sourceObject, sourceField, targetObject, targetField, operator);
    }
}
