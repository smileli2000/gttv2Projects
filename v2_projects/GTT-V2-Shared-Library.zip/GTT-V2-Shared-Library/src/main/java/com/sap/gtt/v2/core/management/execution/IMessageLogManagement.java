package com.sap.gtt.v2.core.management.execution;

import com.sap.gtt.v2.core.domain.execution.*;

/**
 * @author I302310
 */
public interface IMessageLogManagement {
    /**
     * 1. query execution unit by objectId, transformId and relatedId, the last 2 fields can be null
     * 2. if unit is not existed, go to 3; else go to 4
     * 3. insert unit with execution_id and executionHistory with unit_id
     * 4. update unit with execution_id; and insert executionHistory with unit_id
     *
     * @param executionDto
     */
    void insertExecution(ExecutionDto executionDto);

    /**
     * 1. insert execution_message and execution_phase;
     * 2. update last_phase and status of execution_history
     *
     * @param messageDto
     */
    void insertExecutionMessage(ExecutionMessageDto messageDto);

    void insertMappingMessage(MappingMessageDto mappingMessageDto);

    /**
     * insert request payload directly
     * status=SUCCESS
     *
     * @param payloadDto
     */
    void insertPayload(RequestPayloadDto payloadDto);

    /**
     * insert (requestId, trackingId), one trackingId one line
     *
     * @param trackingIdDto
     */
    void insertTrackingIds(RequestTrackingIdDto trackingIdDto);

    void insertCorrelatedTrackedProcess(CorrelatedTrackedProcessDto trackedProcessDto);

    //void updateRequestStatus(String eventId, String correlatedTpId);
}
