package com.sap.gtt.v2.core.domain.trackedprocess;

import java.time.Duration;
import java.time.Instant;

public class Constant {
    public static final String FIELD_NAME_ID = "id";
    public static final Instant MIN_TIMESTAMP = Instant.parse("1970-01-01T00:00:00.000Z");
    public static final Instant MAX_TIMESTAMP = Instant.parse("9999-12-31T00:00:00.000Z");
   
    public static final long OVERDUE_JOB_INTERVAL = 300L * 1000L; // 300 Seconds, 5min
    public static final Duration BUFFER_TIME = Duration.ofMillis(OVERDUE_JOB_INTERVAL);
    
    public static final String ALTKEY_DELIMITER = ":";
    /**altkey for SAP Document "xri://sap.com/sapdoc:party:system:type:id" */
    public static final String PATTERN_ALTKEY = "xri://sap.com/id:LBN#[^:]+(:([^:]+)){3}$";
    /**altkey for Business partner "uri:sapgtt:party:system:type:id" */
    public static final String PATTERN_BUSINESS_PARTNER_ALTKEY = "uri:sapgtt(:([^:]+)){4}$";
    /**altkey for Location "uri:sapgtt:party:system:Location:subtype:id" */
    public static final String PATTERN_LOCATION_ALTKEY = "uri:sapgtt(:([^:]+)){5}$";
    /**altkey for Product "uri:sapgtt:party:system:product:id" */
    public static final String PATTERN_PRODUCT_ALTKEY = "uri:sapgtt(:([^:]+)){4}$";
    public static final String DESC_ALTKEY = "xri://sap.com/id:LBN#party:system:type:id";
    public static final String DESC_BUSINESS_PARTNER_ALTKEY = "uri:sapgtt:party:system:type:id";
    //public static final String DESC_LOCATION_ALTKEY = "uri:sapgtt:party:system:Location:subtype:id";
    public static final String DESC_PRODUCT_ALTKEY = "uri:sapgtt:party:system:product:id";

    public static final String REF_PLANNED_EVENT_TYPE = "refPlannedEventType";
    public static final String REF_PLANNED_EVENT_LOCATION_ALEKEY = "refPlannedEventLocationAltKey";
    public static final String REF_PLANNED_EVENT_MATCH_KEY = "refPlannedEventMatchKey";

    public static final int TP_START_VERSION = 0;

    private Constant() {}
}
