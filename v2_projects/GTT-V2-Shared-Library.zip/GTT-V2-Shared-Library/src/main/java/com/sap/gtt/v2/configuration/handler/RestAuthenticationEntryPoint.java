/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.gtt.v2.configuration.handler;

import com.sap.gtt.v2.core.auditlog.AuditLogService;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;

/**
 *
 * @author I326335
 */
@Component
public class RestAuthenticationEntryPoint extends RestSecurityHandlerBase implements AuthenticationEntryPoint {

    @Autowired
    private AuditLogService auditLogService;
    
    @Override
    public void commence(HttpServletRequest request, HttpServletResponse response, AuthenticationException exception) throws IOException, ServletException {
        auditSecurityEvent(auditLogService, exception.getMessage());
        generateResponse(request, response, UN_AUTHORIZED, HttpServletResponse.SC_UNAUTHORIZED);
    }

    private static final String UN_AUTHORIZED = "UnAuthorized";

}
