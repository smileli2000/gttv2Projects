package com.sap.gtt.v2.util;

import com.google.gson.JsonObject;
import com.sap.gtt.v2.configuration.GTTRestTemplate;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;

public class UaaUtils {

	public static final String CLONE_INSTANCE_ID_PLACEHOLDER = "${cloneInstanceId}";
	public static final String CLONE_BINDING_PATH = "/sap/rest/broker/clones/"+CLONE_INSTANCE_ID_PLACEHOLDER+"/binding";
	
	public static final String OAUTH_TOKEN_CLIENT_CREDENTIALS_PATH = "/oauth/token?grant_type=client_credentials";
	
	public static String requestTechniqueToken(String uaaUrl, String clientId, String secret) {
        GTTRestTemplate restTemplate = SpringContextUtils.getBean(GTTRestTemplate.class);
        String endpoint = uaaUrl + OAUTH_TOKEN_CLIENT_CREDENTIALS_PATH;
        HttpHeaders headers = new HttpHeaders();
        headers.setBasicAuth(clientId, secret);
       
        ResponseEntity<String> tokenResponse = restTemplate.exchange(endpoint, HttpMethod.GET, headers, null, String.class);
   	 	JsonObject tokenJsonObject = JsonUtils.generateJsonObjectFromJsonString(tokenResponse.getBody());
        return tokenJsonObject.get("access_token").getAsString();
       
    }
	
	public static String requestTechniqueToken(String uaaUrl, String subdomain, String clientId, String secret) {
    	String uaaUrlForSubdomain = replaceSubdomain(uaaUrl, subdomain);
        return requestTechniqueToken(uaaUrlForSubdomain, clientId, secret);
    }
	
	public static String replaceSubdomain(String uaaUrl, String subdomain){
    	return "https://" + subdomain + uaaUrl.substring(uaaUrl.indexOf("."));
    }
	
	
	public static class CloneInstanceDetail{

		private String uaadomain;

		private String tenantmode;
	
		private String sburl;
		
		private String clientid;
		
		private String verificationkey;
		
		private String apiurl;
		
		private String xsappname;
		
		private String identityzone;

		private String identityzoneid;
		
		private String clientsecret;
		
		private String tenantid;
		
		private String url;
        
		private String error;
		
		public String getUaadomain() {
			return uaadomain;
		}

		public String getTenantmode() {
			return tenantmode;
		}

		public String getSburl() {
			return sburl;
		}

		public String getClientid() {
			return clientid;
		}

		public String getVerificationkey() {
			return verificationkey;
		}

		public String getApiurl() {
			return apiurl;
		}

		public String getXsappname() {
			return xsappname;
		}

		public String getIdentityzone() {
			return identityzone;
		}

		public String getIdentityzoneid() {
			return identityzoneid;
		}

		public String getClientsecret() {
			return clientsecret;
		}

		public String getTenantid() {
			return tenantid;
		}

		public String getUrl() {
			return url;
		}
        
		public String getError() {
			return error;
		}

		public static CloneInstanceDetail fromJson(String jsonString){
			return JsonUtils.generateBeanFromJson(jsonString, CloneInstanceDetail.class);
		} 
		
		
	}
	
	public static CloneInstanceDetail getCloneInstanceDetail(String cloneInstanceId,String uaaUrl, String clientId, String secret){
		String jwt = requestTechniqueToken(uaaUrl, clientId, secret);
		// request to get binding info
		String url = uaaUrl + StringUtils.replace(CLONE_BINDING_PATH, CLONE_INSTANCE_ID_PLACEHOLDER, cloneInstanceId);
		GTTRestTemplate restTemplate = SpringContextUtils.getBean(GTTRestTemplate.class);
		
		HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(jwt);
        
        ResponseEntity<String> tokenResponse = restTemplate.exchange(url, HttpMethod.GET, headers, null, String.class);
        
        return CloneInstanceDetail.fromJson(tokenResponse.getBody());
        
	}
}
