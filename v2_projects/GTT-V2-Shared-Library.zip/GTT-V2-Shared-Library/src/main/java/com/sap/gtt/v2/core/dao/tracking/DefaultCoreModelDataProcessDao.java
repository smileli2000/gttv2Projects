package com.sap.gtt.v2.core.dao.tracking;

import com.sap.gtt.v2.core.domain.metadata.MetadataConstants;
import com.sap.gtt.v2.core.entity.trackedprocess.*;
import com.sap.gtt.v2.log.TenantAwareLogService;
import com.sap.gtt.v2.util.DBUtils;
import com.sap.gtt.v2.util.SpringContextUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.Map;

import static com.sap.gtt.v2.core.domain.metadata.MetadataConstants.CoreModelEntity.*;

/**
 * @author I301346
 */
@Repository(DefaultCoreModelDataProcessDao.BEAN_NAME)
public class DefaultCoreModelDataProcessDao implements ICoreModelDataProcessDao {
    public static final String BEAN_NAME = "com.sap.gtt.v2.core.dao.tracking.DefaultCoreModelDataProcessDao";
    private static final String WHERE = " where ";
    private static final String WHERE_T_2 = " where T2.";
    private static final String FROM = " from ";
    private static final String T_1_INNER_JOIN = " T1 inner join ";
    private static final String T_2_ON_T_1 = " T2 on T1.";
    private static final String IN_SELECT_T1 = " in (select T1.";
    private static final String EQ_T_2 = " = T2.";
    private static final String DELETE_FROM = "delete from ";

    @Autowired
    private TenantAwareLogService logService;

    @Autowired
    private DaoHelper daoHelper;

    protected DefaultCoreModelDataProcessDao() {

    }

    public static DefaultCoreModelDataProcessDao getInstance() {
        return (DefaultCoreModelDataProcessDao) SpringContextUtils.getBean(BEAN_NAME);
    }

    private void deleteEventRelatedCoreTables(Map<String, String> coreTableNameColMap, String namespace) {
        coreTableNameColMap.forEach((k, v) -> {
            String sql1 = generateDropSQLForEventRelatedCoreModelTable(k, v);
            daoHelper.getJdbcTemplate().update(sql1, namespace);
        });
    }

    private void deleteTrackedProcessRelatedCoreTables(Map<String, String> coreTableNameColMap, String namespaceLike) {
        coreTableNameColMap.forEach((k, v) -> {
            String sql1 = generateDropSQLForTrackedProcessRelatedCoreModelTable(k, v);
            daoHelper.getJdbcTemplate().update(sql1, namespaceLike);
        });
    }

    @Override
    public void deleteAllCoreModelData(String namespace) {
        Map<String, String> coreTableNameColMapForEvent = new HashMap<>(MetadataConstants.INITIAL_CAPACITY);

        //COM_SAP_GTT_CORE_COREMODEL_REFERENCE
        coreTableNameColMapForEvent.put(REFERENCE.getFullName(), Reference.EVENTID);

        //COM_SAP_GTT_CORE_COREMODEL_PLANNEDEVENTFORUPDATEPLANEVENT
        coreTableNameColMapForEvent.put(PLANNED_EVENT_FOR_UPDATE_PLAN_EVENT.getFullName(), PlannedEvent.EVENTID);

        //COM_SAP_GTT_CORE_COREMODEL_PLANNEDEVENTFOREVENT
        coreTableNameColMapForEvent.put(PLANNED_EVENT_FOR_EVENT.getFullName(), PlannedEvent.EVENTID);

        //COM_SAP_GTT_CORE_COREMODEL_GTTOVERDUEEVENT
        coreTableNameColMapForEvent.put(GTT_OVERDUE_EVENT.getFullName(), Event.ID);

        //COM_SAP_GTT_CORE_COREMODEL_GTTDELAYEDEVENT
        coreTableNameColMapForEvent.put(GTT_DELAYED_EVENT.getFullName(), Event.ID);

        //COM_SAP_GTT_CORE_COREMODEL_GTTONTIMEEVENT
        coreTableNameColMapForEvent.put(GTT_ONTIME_EVENT.getFullName(), Event.ID);

        deleteEventRelatedCoreTables(coreTableNameColMapForEvent, namespace);

        //delete COM_SAP_GTT_CORE_COREMODEL_EVENT
        String sql6 = generateDropSQLForEventTable();
        daoHelper.getJdbcTemplate().update(sql6, namespace);

        String namespaceForLike = namespace + ".%";

        Map<String, String> coreTableNameColMapForTrackedProcess = new HashMap<>(MetadataConstants.INITIAL_CAPACITY);

        //COM_SAP_GTT_CORE_COREMODEL_PLANNEDEVENT
        coreTableNameColMapForTrackedProcess.put(PLANNED_EVENT.getFullName(), PlannedEvent.PROCESSID);

        //COM_SAP_GTT_CORE_COREMODEL_PROCESSEVENTDIRECTORY
        coreTableNameColMapForTrackedProcess.put(PROCESS_EVENT_DIRECTORY.getFullName(), ProcessEventDirectory.PROCESS_ID);

        //delete COM_SAP_GTT_CORE_COREMODEL_QUALIFIEDTRACKINGID
        coreTableNameColMapForTrackedProcess.put(QUALIFIED_TRACKING_ID.getFullName(), QualifiedTrackingId.PROCESSID);

        deleteTrackedProcessRelatedCoreTables(coreTableNameColMapForTrackedProcess, namespaceForLike);

        //delete COM_SAP_GTT_CORE_COREMODEL_QUALIFIEDTRACKINGID
        String sql10 = generateDropSQLForTrackedprocessTable();
        daoHelper.getJdbcTemplate().update(sql10, namespaceForLike);
    }

    private String generateDropSQLForEventRelatedCoreModelTable(String coreModelTableName, String coreModelColumnName) {
        String sql = new StringBuilder(DELETE_FROM)
                .append(DBUtils.toTableName(coreModelTableName))
                .append(WHERE).append(DBUtils.toElementPhysicalName(coreModelColumnName))
                .append(IN_SELECT_T1).append(DBUtils.toElementPhysicalName(coreModelColumnName))
                .append(FROM).append(DBUtils.toTableName(coreModelTableName))
                .append(T_1_INNER_JOIN).append(DBUtils.toTableName(MetadataConstants.CoreModelEntity.EVENT.getFullName()))
                .append(T_2_ON_T_1).append(DBUtils.toElementPhysicalName(coreModelColumnName)).append(EQ_T_2).append(DBUtils.toElementPhysicalName(Event.ID))
                .append(WHERE_T_2).append(DBUtils.toElementPhysicalName(Event.MODEL_NAMESPACE))
                .append(" = ? )").toString();

        logService.debug("sql:{}, coreModelTableName:{}, coreModelColumnName:{}", sql, coreModelTableName, coreModelColumnName);

        return sql;
    }

    private String generateDropSQLForTrackedProcessRelatedCoreModelTable(String coreModelTableName, String coreModelColumnName) {
        String sql = new StringBuilder(DELETE_FROM)
                .append(DBUtils.toTableName(coreModelTableName))
                .append(WHERE).append(DBUtils.toElementPhysicalName(coreModelColumnName))
                .append(IN_SELECT_T1).append(DBUtils.toElementPhysicalName(coreModelColumnName))
                .append(FROM).append(DBUtils.toTableName(coreModelTableName))
                .append(T_1_INNER_JOIN).append(DBUtils.toTableName(MetadataConstants.CoreModelEntity.TRACKED_PROCESS.getFullName()))
                .append(T_2_ON_T_1).append(DBUtils.toElementPhysicalName(coreModelColumnName)).append(EQ_T_2).append(DBUtils.toElementPhysicalName(TrackedProcess.ID))
                .append(WHERE_T_2).append(DBUtils.toElementPhysicalName(TrackedProcess.TRACKED_PROCESS_TYPE))
                .append(" like ? )").toString();

        logService.debug("sql:{}, coreModelTableName:{}, coreModelColumnName:{}", sql, coreModelTableName, coreModelColumnName);

        return sql;
    }

    private String generateDropSQLForEventTable() {
        String sql = new StringBuilder(DELETE_FROM)
                .append(DBUtils.toTableName(MetadataConstants.CoreModelEntity.EVENT.getFullName()))
                .append(WHERE).append(DBUtils.toElementPhysicalName(Event.MODEL_NAMESPACE))
                .append(" = ? ").toString();

        logService.debug("generateDropSQLForEventTable:{}", sql);

        return sql;
    }

    private String generateDropSQLForTrackedprocessTable() {
        String sql = new StringBuilder(DELETE_FROM)
                .append(DBUtils.toTableName(MetadataConstants.CoreModelEntity.TRACKED_PROCESS.getFullName()))
                .append(WHERE).append(DBUtils.toElementPhysicalName(TrackedProcess.TRACKED_PROCESS_TYPE))
                .append(" like ? ").toString();

        logService.debug("generateDropSQLForTrackedprocessTable:{}", sql);

        return sql;
    }
}
