package com.sap.gtt.v2.bp;

import com.sap.gtt.v2.exception.InternalErrorException;

import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.sap.gtt.v2.configuration.EnvironmentsConfiguration.VcapServiceParser.BpServiceInstance;
import com.sap.gtt.v2.log.TenantAwareLogService;
import com.sap.gtt.v2.configuration.GTTRestTemplate;
import com.sap.gtt.v2.configuration.ServiceInstancesMapping;
import com.sap.gtt.v2.util.JsonUtils;
import com.sap.gtt.v2.util.SpringContextUtils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class BusinessPartnerService {
	private static final Logger logger = LoggerFactory.getLogger(BusinessPartnerService.class);
	
	public static final String CACHE_NAME_BUSINESS_PARTNER_BY_TENANT_ID = "businessPartnerByTenantId";
	public static final String CACHE_NAME_BUSINESS_PARTNER_BY_INTEGRATION_USER = "businessPartnerByIntegrationUser";
    public static final String CACHE_NAME_BUSINESS_PARTNER_BY_LBN_ID = "businessPartnerByLbnId";

    @Autowired
    private ServiceInstancesMapping serviceInstancesMapping;
    @Autowired
    private GTTRestTemplate restTemplate;

    @Cacheable(cacheNames = CACHE_NAME_BUSINESS_PARTNER_BY_TENANT_ID)
    public BusinessPartner getBPByTenantId(String tenantId) {
        BpServiceInstance bpServiceInstance = serviceInstancesMapping.getBpServiceInstance();
        String endpoint = bpServiceInstance.getEndpoint();
        String path = "/bpr/BusinessPartners?$format=json&$filter=TenantId eq '{0}'&$expand=BPAccountDetails".replace("{0}", tenantId);
        String uri = endpoint.concat(path);
        HttpHeaders headers = new HttpHeaders();
        String jwt = bpServiceInstance.requestTechniqueToken();
        headers.setBearerAuth(jwt);
        String response = restTemplate.exchange(uri, HttpMethod.GET, headers, null, String.class).getBody();
        return getBPFromResponseBody(response);
    }

    @Cacheable(cacheNames = CACHE_NAME_BUSINESS_PARTNER_BY_INTEGRATION_USER)
    public BusinessPartner getBPByIntegrationUser(String integrationUser) {
        BpServiceInstance bpServiceInstance = serviceInstancesMapping.getBpServiceInstance();
        String endpoint = bpServiceInstance.getEndpoint();
        String path = String.format("/bpr/BusinessPartners?$format=json&$expand=BPAccountDetails&$filter=AlternateIdDetails/IdentityType eq '%s' and AlternateIdDetails/AltId eq '%s'","LBN_OTHERS",integrationUser);
        String uri = endpoint.concat(path);
        HttpHeaders headers = new HttpHeaders();
        String jwt = bpServiceInstance.requestTechniqueToken();
        headers.setBearerAuth(jwt);
        String response = restTemplate.exchange(uri, HttpMethod.GET, headers, null, String.class).getBody();
        return getBPFromResponseBody(response);
    }

    @Cacheable(cacheNames = CACHE_NAME_BUSINESS_PARTNER_BY_LBN_ID)
    public BusinessPartner getBPByLBNID(String lbnId) throws InternalErrorException {

        String formattedLbnId = formatLbnId(lbnId);

        BpServiceInstance bpServiceInstance = serviceInstancesMapping.getBpServiceInstance();
        String endpoint = bpServiceInstance.getEndpoint();
        String path = "/bpr/BusinessPartners?$format=json&$filter=LbnId eq '{0}'&$expand=BPAccountDetails".replace("{0}", formattedLbnId);
        String uri = endpoint.concat(path);
        HttpHeaders headers = new HttpHeaders();
        String jwt = bpServiceInstance.requestTechniqueToken();
        headers.setBearerAuth(jwt);
        String response = restTemplate.exchange(uri, HttpMethod.GET, headers, null, String.class).getBody();
        return getBPFromResponseBody(response);
    }

    private String formatLbnId(String lbnId) throws InternalErrorException {
        String isNumber = "^[0-9]";
        String isLBNPrefix = "(LBN#)(.*[0-9])($)";
        if (lbnId.matches(isNumber)) {
            return lbnId;
        } else {
            Pattern pattern = Pattern.compile(isLBNPrefix);
            Matcher matcher = pattern.matcher(lbnId);
            if(matcher.find()) {
                return matcher.group(2);
            }else{
                throw new InternalErrorException("LBN Id is not standard: " + lbnId);
            }
        }
    }

    private BusinessPartner getBPFromResponseBody(String body) {
        JsonObject obj = JsonUtils.generateJsonObjectFromJsonString(body);
        JsonArray results = obj.getAsJsonObject("d").getAsJsonArray("results");
        if (results.size() == 0) {
            return null;
        }
        JsonObject bpObj = results.get(0).getAsJsonObject();
        BusinessPartner bpResult = JsonUtils.generateBeanFromJson(bpObj.toString(), BusinessPartner.class);
        if(bpObj.getAsJsonObject("BPAccountDetails") != null){
            JsonArray bpAccountResults = bpObj.getAsJsonObject("BPAccountDetails").getAsJsonArray("results");
            if(bpAccountResults != null) {
                ArrayList<BPAccountDetail> bpAccountDetails = new ArrayList<>();
                for(int i = 0; i < bpAccountResults.size(); i++) {
                    bpAccountDetails.add(JsonUtils.generateBeanFromJsonElement(bpAccountResults.get(i), BPAccountDetail.class));
                }
                bpResult.setBpAccountDetails(bpAccountDetails);
            }
        }
        if(bpObj.getAsJsonObject("CommunicationDataDetails") != null) {
        	bpObj.getAsJsonObject("CommunicationDataDetails");
        }
        return bpResult;
    }

    @CacheEvict(value={CACHE_NAME_BUSINESS_PARTNER_BY_TENANT_ID,CACHE_NAME_BUSINESS_PARTNER_BY_INTEGRATION_USER}, allEntries = true)
	@Scheduled(fixedDelay = 300*1000) // 300 seconds
	public void evictAll(){
		logger.debug("Invalidating all local business partner caches...");
	}
	

    private String getJsonString(JsonElement e) {
    	String ret = null;
    	if(e != null) {
    		ret = e.getAsString();
    	}
    	if(ret == null)
    		ret = "";
    	return ret;
    }
    private BPContactInfo getContactInfoFromResponseBody(String body) {
    	BPContactInfo ret = new BPContactInfo();
    	JsonObject obj = JsonUtils.generateJsonObjectFromJsonString(body);
    	JsonArray results = obj.getAsJsonObject("d").getAsJsonArray("results");
    	if (results.size() == 0) {
            return null;
        }
    	JsonObject bpObj = results.get(0).getAsJsonObject();
    	ret.setSolutionOwnerBusinessProfileName(getJsonString(bpObj.get("BpName")));
    	ret.setSolutionOwnerWebsite(getJsonString(bpObj.get("Website")));
    	
    	JsonObject communicationDataDetails = bpObj.getAsJsonObject("CommunicationDataDetails");
    	if(communicationDataDetails != null) {
	    	results = communicationDataDetails.getAsJsonArray("results");
	    	if (results.size() != 0) {
	    		JsonObject commObj = results.get(0).getAsJsonObject();
	    		ret.setSolutionOwnerFax(getJsonString(commObj.get("Fax")));
	    		ret.setSolutionOwnerMobile(getJsonString(commObj.get("Mobile")));
	    		ret.setSolutionOwnerPostalCode(getJsonString(commObj.get("PostalCode")));
	    		ret.setSolutionOwnerAddress(getJsonString(commObj.get("Street1")) + ", " + getJsonString(commObj.get("City")) + ", " + getJsonString(commObj.get("Country")));
	        }
    	}
    	JsonObject contactPersonDetails = bpObj.getAsJsonObject("ContactPersonDetails");
    	if(contactPersonDetails != null) {
	    	results = contactPersonDetails.getAsJsonArray("results");
	    	if (results.size() != 0) {
	    		JsonObject contObj = results.get(0).getAsJsonObject();
	    		ret.setSolutionOwnerContactPersonEmail(getJsonString(contObj.get("Email")));
	    		ret.setSolutionOwnerContactPersonPhoneNumber(getJsonString(contObj.get("Phone")));
	    		ret.setSolutionOwnerContactPersonName(getJsonString(contObj.get("FirstName")) + " " + getJsonString(contObj.get("LastName")));
	        }
    	}
    	return ret;
    }
    
    public BPContactInfo getBPContactDetail(String tenantId) {
    	TenantAwareLogService logService = SpringContextUtils.getBean(TenantAwareLogService.class);
    	
        BpServiceInstance bpServiceInstance = serviceInstancesMapping.getBpServiceInstance();
        String endpoint = bpServiceInstance.getEndpoint();
        String path = "/bpr/BusinessPartners?$format=json&$filter=TenantId eq '{0}'&$expand=CommunicationDataDetails,ContactPersonDetails".replace("{0}", tenantId);
        String uri = endpoint.concat(path);
        
        logService.info("===> getBPContactDetail: " + uri);
        //String uri = "https://lbnplatform-bprepo-int.cfapps.sap.hana.ondemand.com/bpr/BusinessPartners?$filter=LbnId eq '10000034'&$expand=CommunicationDataDetails,ContactPersonDetails";
        HttpHeaders headers = new HttpHeaders();
        String jwt = bpServiceInstance.requestTechniqueToken();
        //String jwt  ="eyJhbGciOiJSUzI1NiIsImprdSI6Imh0dHBzOi8vbGJuLXNoaXBwZXIwMS5hdXRoZW50aWNhdGlvbi5zYXAuaGFuYS5vbmRlbWFuZC5jb20vdG9rZW5fa2V5cyIsImtpZCI6ImtleS1pZC0xIiwidHlwIjoiSldUIn0.eyJqdGkiOiJlZTUwYTIxOGI2OTA0YTU0YmRhODM3NjkxNTNhNTU1YiIsImV4dF9hdHRyIjp7ImVuaGFuY2VyIjoiWFNVQUEiLCJ6ZG4iOiJsYm4tc2hpcHBlcjAxIiwic2VydmljZWluc3RhbmNlaWQiOiJjYmNlZTFiOS0xODQyLTQyZGYtYjQ3Yy1kNzZiM2IzZmQ5Y2QifSwic3ViIjoic2ItbGJucGxhdGZvcm0tYnByZXBvLXJldXNlLXNlcnZpY2UtY2xvbmUhYjQ2OHxsYm5wbGF0Zm9ybS1icHJlcG8taW50IWI2NjYwIiwiYXV0aG9yaXRpZXMiOlsibGJucGxhdGZvcm0tYnByZXBvLWludCFiNjY2MC5CUERpc2NvdmVyeVByb2Nlc3MiLCJsYm5wbGF0Zm9ybS1icHJlcG8taW50IWI2NjYwLkJQRGlzcGxheSIsImxibi1kZXYhdDQ2OC5PcHMiLCJsYm4tc2FuZGJveCF0NDY4Lk9wcyIsInVhYS5yZXNvdXJjZSIsImxibnBsYXRmb3JtLWJwcmVwby1pbnQhYjY2NjAuQlBFZGl0IiwibGJuLWRldi1oZiF0NDY4Lk9wcyIsImxibi1hY2NlcHRhbmNlIXQ0NjguT3BzIiwibGJucGxhdGZvcm0tYnByZXBvLWludCFiNjY2MC5DYWxsYmFjayIsImxibi1wZXJmb3JtYW5jZSF0NDY4Lk9wcyJdLCJzY29wZSI6WyJsYm5wbGF0Zm9ybS1icHJlcG8taW50IWI2NjYwLkJQRGlzY292ZXJ5UHJvY2VzcyIsImxibnBsYXRmb3JtLWJwcmVwby1pbnQhYjY2NjAuQlBEaXNwbGF5IiwibGJuLWRldiF0NDY4Lk9wcyIsImxibi1zYW5kYm94IXQ0NjguT3BzIiwidWFhLnJlc291cmNlIiwibGJucGxhdGZvcm0tYnByZXBvLWludCFiNjY2MC5CUEVkaXQiLCJsYm4tZGV2LWhmIXQ0NjguT3BzIiwibGJuLWFjY2VwdGFuY2UhdDQ2OC5PcHMiLCJsYm5wbGF0Zm9ybS1icHJlcG8taW50IWI2NjYwLkNhbGxiYWNrIiwibGJuLXBlcmZvcm1hbmNlIXQ0NjguT3BzIl0sImNsaWVudF9pZCI6InNiLWxibnBsYXRmb3JtLWJwcmVwby1yZXVzZS1zZXJ2aWNlLWNsb25lIWI0Njh8bGJucGxhdGZvcm0tYnByZXBvLWludCFiNjY2MCIsImNpZCI6InNiLWxibnBsYXRmb3JtLWJwcmVwby1yZXVzZS1zZXJ2aWNlLWNsb25lIWI0Njh8bGJucGxhdGZvcm0tYnByZXBvLWludCFiNjY2MCIsImF6cCI6InNiLWxibnBsYXRmb3JtLWJwcmVwby1yZXVzZS1zZXJ2aWNlLWNsb25lIWI0Njh8bGJucGxhdGZvcm0tYnByZXBvLWludCFiNjY2MCIsImdyYW50X3R5cGUiOiJjbGllbnRfY3JlZGVudGlhbHMiLCJyZXZfc2lnIjoiNmJlMmFjYWUiLCJpYXQiOjE1OTIyMTg4MDEsImV4cCI6MTU5MjI2MjAwMSwiaXNzIjoiaHR0cDovL2xibi1zaGlwcGVyMDEubG9jYWxob3N0OjgwODAvdWFhL29hdXRoL3Rva2VuIiwiemlkIjoiZDRjYzkwMjItMzEyZi00M2Y2LTg5NWItMzE4YTY3YjM2NDk1IiwiYXVkIjpbImxibi1kZXYhdDQ2OCIsImxibi1kZXYtaGYhdDQ2OCIsInVhYSIsImxibi1hY2NlcHRhbmNlIXQ0NjgiLCJsYm5wbGF0Zm9ybS1icHJlcG8taW50IWI2NjYwIiwibGJuLXBlcmZvcm1hbmNlIXQ0NjgiLCJzYi1sYm5wbGF0Zm9ybS1icHJlcG8tcmV1c2Utc2VydmljZS1jbG9uZSFiNDY4fGxibnBsYXRmb3JtLWJwcmVwby1pbnQhYjY2NjAiLCJsYm4tc2FuZGJveCF0NDY4Il19.LlO3hqRzSDC3kSDvwhDbr4-gjAI2prEmu8Ve3CKIlBkI7BdpqXUds4Aoaj6HVIRpXZ7rYI-lLDkVZ8LljC4bd_vfQECExhhFVzFPoWyQ4ONPVCNQbWbdv1e8Yp7yjFr0HN0C2UcZ3JhZE1xoYxpa6pp3Lkve_KO2OzDPYE6rUxEbjndss9Jlk_mNZ1AwQhMwxepBGzX5pmAQO3Ah8vWCPaArBe102ytmIg7qtPU-DDwTfnMeyeNXrH_AD8Z2gLs1vEqWwehkcFDqXFsG7BxqX4-UUvR0iCxyi35TbKwgmnpQuRGFPm3gAu9eGkIfrygWGVXWvVNUOWwF9iFwkA_69A";
        headers.setBearerAuth(jwt);
        String response = restTemplate.exchange(uri, HttpMethod.GET, headers, null, String.class).getBody();
        logService.info("===> getBPContactDetail result: " + response);
        return getContactInfoFromResponseBody(response);
    }
}
