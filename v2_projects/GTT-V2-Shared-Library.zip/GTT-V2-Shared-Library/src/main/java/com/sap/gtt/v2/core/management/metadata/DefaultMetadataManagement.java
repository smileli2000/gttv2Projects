package com.sap.gtt.v2.core.management.metadata;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.sap.gtt.v2.configuration.SystemConstants;
import com.sap.gtt.v2.core.dao.dpp.DefaultDppDao;
import com.sap.gtt.v2.core.dao.dpp.IDppDao;
import com.sap.gtt.v2.core.dao.metadata.DefaultMetadataDao;
import com.sap.gtt.v2.core.dao.metadata.DefaultSysTableDao;
import com.sap.gtt.v2.core.dao.metadata.IMetadataDao;
import com.sap.gtt.v2.core.dao.metadata.ISysTableDao;
import com.sap.gtt.v2.core.domain.dpp.DppEntity;
import com.sap.gtt.v2.core.domain.metadata.*;
import com.sap.gtt.v2.core.domain.metadata.MetadataConstants.*;
import com.sap.gtt.v2.core.entity.metadata.*;
import com.sap.gtt.v2.exception.InternalErrorException;
import com.sap.gtt.v2.exception.MetadataException;
import com.sap.gtt.v2.util.DBUtils;
import com.sap.gtt.v2.util.GTTUtils;
import com.sap.gtt.v2.util.JsonUtils;
import com.sap.gtt.v2.util.SpringContextUtils;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.core.io.ClassPathResource;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.stream.Collectors;

import static com.sap.gtt.v2.core.domain.metadata.MetadataConstants.*;
import static com.sap.gtt.v2.exception.MetadataException.*;

/**
 * @author I321712
 */
@Service(DefaultMetadataManagement.BEAN_NAME)
//@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
//@EnableScheduling
public class DefaultMetadataManagement implements IMetadataManagement {


    public static final String BEAN_NAME = "com.sap.gtt.v2.core.management.metadata.DefaultMetadataManagement";

    public static final String CACHE_NAME_METADATA_ENTITY = "metadataEntity";
    public static final String CACHE_NAME_METADATA_SWAGGER = "metadataSwagger";
    public static final String CACHE_NAME_METADATA_FIELDINFO = "metadataFieldInfo";
    public static final String CACHE_NAME_METADATA_EDMX = "metadataEdmx";
    public static final String CACHE_NAME_METADATA_MODEL_ACTIVE = "metadataModelActive";
    public static final String CACHE_NAME_METADATA_EVENT_TYPE = "metadataEventType";
    public static final String CACHE_NAME_METADATA_IS_EVENT_UNPLANNED = "metadataIsEventUnplanned";
    public static final String CACHE_NAME_METADATA_ALL_FIELDS_OF_ENTITY = "metadataAllFieldsOfEntity";
    public static final String CACHE_NAME_METADATA_ENTITY_EVENT = "metadataEntityEvent";
    public static final String CACHE_NAME_METADATA_ENTITY_PHYSICAL_NAME = "metadataEntityPhysicalName";
    public static final String CACHE_NAME_METADATA_CHANGE_HISTORY = "metadataChangeHistory";
    public static final String CACHE_NAME_METADATA_DRAFT_MODEL_LIST = "metadataDraftModelList";
    public static final String CACHE_NAME_METADATA_PROCESS_EVENT_ENTITY = "metadataProcessEventEntity";
    public static final String CACHE_NAME_METADATA_EVENT_ENTITY = "metadataEventEntity";
    public static final String CACHE_NAME_METADATA_MODEL_ENABLE_INSTANCE_AUTHORIZATION = "metadataModelEnableInstanceAuthorization";
    public static final String CACHE_NAME_METADATA_MODEL_MODEL_CONFIGURATION = "metadataModelModelConfiguration";
    private static final String DOT = ".";
    private static final String UNDER_LINE = "_";
    private static final String CORE_CORE_MODEL_DERIVED_CSN_JSON = "core/CoreModel_Derived_CSN.json";

    private static final Logger logger = LoggerFactory.getLogger(DefaultMetadataManagement.class);
    public static final String SLASH = "/";

    public static DefaultMetadataManagement getInstance() {
        return (DefaultMetadataManagement) SpringContextUtils.getBean(BEAN_NAME);
    }

    @Override
    public IMetadataDao getMetadataDao() {
        return DefaultMetadataDao.getInstance();
    }

    protected ISysTableDao getSysTableDao() {
        return DefaultSysTableDao.getInstance();
    }

    protected IDppDao getDppDao() {
        return DefaultDppDao.getInstance();
    }


    @Transactional(readOnly = true)
    @Override
    public List<MetadataProcess> findAllMetadataProcess(MetadataCriteria criteria) {
        return getMetadataDao().findAllMetadataProcess(criteria);
    }

    @Transactional(readOnly = true)
    @Override
    public MetadataProjectFile getMetadataProjectFileInfo(String[] selectedFields, String namespace) {
        MetadataCriteria criteria = new MetadataCriteria();
        criteria.addNamespace(namespace);
        return getMetadataDao().getMetadataProjectFileInfo(selectedFields, criteria);
    }

    @Transactional(readOnly = true)
    @Override
    public List<MetadataProject> findAllMetadataProject() {
        return getMetadataDao().findAllMetadataProject();
    }

    @Transactional(readOnly = true)
    @Override
    public List<MetadataProject> findMetadataProjectInfo(MetadataCriteria criteria) {
        return getMetadataDao().findMetadataProjectInfo(criteria);
    }

    @Transactional(readOnly = true)
    @Override
    public List<MetadataProject> findMetadataProjectInfoByNamespace(String namespace) {
        return getMetadataDao().findMetadataProjectInfoByNamespace(namespace);
    }

    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    @Override
    public void insertMetadataProject(MetadataProject newMetadataProject) {
        getMetadataDao().insertMetadataProject(newMetadataProject);
        getInstance().evictAll();
    }

    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    @Override
    public void updateMetadataProject(MetadataProject updatedMetadataProject) {
        getMetadataDao().updateMetadataProject(updatedMetadataProject);
        getInstance().evictAll();
    }

    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    @Override
    public void updateMetadataProjectStatus(MetadataProject updatedMetadataProject) {
        getMetadataDao().updateMetadataProjectStatus(updatedMetadataProject);
        getInstance().evictAll();
    }

    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    @Override
    public void insertMetadataProcess(MetadataProcess newMetadataProcess) {
        getMetadataDao().insertMetadataProcess(newMetadataProcess);
        getInstance().evictAll();
    }

    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    @Override
    public void updateMetadataProcess(MetadataProcess updatedMetadataProcess) {
        getMetadataDao().updateMetadataProcess(updatedMetadataProcess);
        getInstance().evictAll();
    }

    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    @Override
    public void upsertMetadataProcessText(MetadataProcess newMetadataProcess) {
        getMetadataDao().upsertMetadataProcessTexts(newMetadataProcess);
        getInstance().evictAll();
    }

    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    @Override
    public void deleteMetadata(String namespace) {
        getMetadataDao().deleteMetadata(namespace);
        getInstance().evictAll();
    }

    @Transactional(readOnly = true)
    @Override
    @Cacheable(cacheNames = CACHE_NAME_METADATA_FIELDINFO, key = "#namespace + '" + GTTUtils.GLOBAL_STRING_SPLITOR + "' + #fieldName"
            , condition = SystemConstants.SPRING_BEAN_SPEL_CONDITION_ON_IS_CACHE_ENABLED)
    public String getMetadataProjectFileFieldInfo(String namespace, MetadataProjectFileField fieldName) {
        List<String> queryNamespaces = new ArrayList<>();
        queryNamespaces.add(namespace);
        return getMetadataDao().getMetadataProjectFileFieldInfo(queryNamespaces, fieldName);
    }

    @Override
    public void createTable(List<MetadataEntity> newEntities) {
        getSysTableDao().createTable(newEntities);
        getInstance().evictAll();
    }

    @Override
    public void dropTable(List<MetadataEntity> tobeDroppedEntities) {
        getSysTableDao().dropTable(tobeDroppedEntities);
        getInstance().evictAll();
    }

    @Override
    public void addTableField(List<MetadataEntity> newFieldEntities) {
        getSysTableDao().addTableField(newFieldEntities);
        getInstance().evictAll();
    }

    @Override
    public void modifyTableField(List<MetadataEntity> modifiedFieldEntities) {
        getSysTableDao().modifyTableField(modifiedFieldEntities);
        getInstance().evictAll();
    }

    @Override
    public void deleteTableField(List<MetadataEntity> deletedFieldEntities) {
        getSysTableDao().deleteTableField(deletedFieldEntities);
        getInstance().evictAll();
    }

    @Transactional(readOnly = true)
    @Override
    @Cacheable(cacheNames = CACHE_NAME_METADATA_IS_EVENT_UNPLANNED, key = "#trackedProcessType + '" + GTTUtils.GLOBAL_STRING_SPLITOR + "' + #eventType"
            , condition = SystemConstants.SPRING_BEAN_SPEL_CONDITION_ON_IS_CACHE_ENABLED)
    public boolean checkIfEventIsUnplanned(String trackedProcessType, String eventType) {
        String namespace = CsnParser.getProjectNamespace(trackedProcessType);
        MetadataEntity entity = getMetadataEntity(namespace, trackedProcessType);
        List<MetadataEntityEvent> unplannedEvents = entity.getUnplannedEvents();
        return unplannedEvents.stream().anyMatch(e -> eventType.equalsIgnoreCase(e.getEventType()));
    }

    @Transactional(readOnly = true)
    @Override
    @Cacheable(cacheNames = CACHE_NAME_METADATA_ENTITY_EVENT, key = "#entityName + '" + GTTUtils.GLOBAL_STRING_SPLITOR + "' + #eventType"
            , condition = SystemConstants.SPRING_BEAN_SPEL_CONDITION_ON_IS_CACHE_ENABLED
    )
    public MetadataEntityEvent getEntityEvent(String entityName, String eventType) {
        String namespace = CsnParser.getProjectNamespace(entityName);
        MetadataEntity entity = getMetadataEntity(namespace, entityName);
        List<MetadataEntityEvent> events = new ArrayList<>();
        events.addAll(entity.getPlannedEvents());
        events.addAll(entity.getUnplannedEvents());

        Optional<MetadataEntityEvent> event = events.stream()
                .filter(e -> eventType.equalsIgnoreCase(e.getEventType()))
                .findFirst();
        return event.orElse(null);
    }

    @Transactional(readOnly = true)
    @Override
    @Cacheable(cacheNames = CACHE_NAME_METADATA_ALL_FIELDS_OF_ENTITY, key = "#namespace + '" + GTTUtils.GLOBAL_STRING_SPLITOR + "' + #entityName"
            , condition = SystemConstants.SPRING_BEAN_SPEL_CONDITION_ON_IS_CACHE_ENABLED)
    public Map<String, MetadataEntityElement> findAllFieldsOfEntity(String namespace, String entityName) {
        MetadataEntity entity = getMetadataEntity(namespace, entityName);
        return entity.getElements().stream().collect(Collectors.toMap(MetadataEntityElement::getName, v -> v));
    }

    @Transactional(readOnly = true)
    @Override
    @Cacheable(cacheNames = CACHE_NAME_METADATA_EVENT_TYPE, key = "#namespace + '" + GTTUtils.GLOBAL_STRING_SPLITOR + "' + #eventType"
            , condition = SystemConstants.SPRING_BEAN_SPEL_CONDITION_ON_IS_CACHE_ENABLED)
    public MetadataEntity getTrackedProcessEntityByEventType(String namespace, String eventType) {
        List<MetadataEntity> entities = getAllEntities(namespace);
        return getTrackedProcessEntityByEventType(entities, namespace, eventType);
    }

    private MetadataEntity getTrackedProcessEntityByEventType(List<MetadataEntity> entities, String namespace, String eventType) {
        String tpPrefix = eventType.substring(0, eventType.lastIndexOf(DOT));
        Optional<MetadataEntity> tpEntity = getTrackedProcessEntity(entities, tpPrefix);
        if (!tpEntity.isPresent()) {
            tpEntity = getTrackedProcessEntity(entities, namespace);
        }
        if (tpEntity.isPresent()) {
            return tpEntity.get();
        }
        throw new MetadataException(MESSAGE_CODE_NOT_FOUND_TRACKED_PROCESS_ENTITY, new Object[]{eventType});
    }

    private Optional<MetadataEntity> getTrackedProcessEntity(List<MetadataEntity> entities, String tpPrefix) {
        return entities.stream()
                .filter(e -> CsnParser.isTrackedProcess(e.getBaseType())
                        && e.getName().startsWith(tpPrefix + DOT))
                .findFirst();
    }

    @Transactional(readOnly = true)
    @Override
    @Cacheable(cacheNames = CACHE_NAME_METADATA_SWAGGER, key = "#namespace + '" + GTTUtils.GLOBAL_STRING_SPLITOR + "' + #eventEntityName"
            , condition = SystemConstants.SPRING_BEAN_SPEL_CONDITION_ON_IS_CACHE_ENABLED)
    public MetadataSwaggerInfo getMetadataSwaggerInfo(String namespace, String eventEntityName) {
        MetadataSwaggerInfo ret = new MetadataSwaggerInfo();
        String modelNamespace = getModelNamespace(namespace);
        ret.setNamespace(modelNamespace);
        MetadataProjectFile projectFile = getMetadataDao().getMetadataSwaggerDerivedCsnInfo(modelNamespace);
        if (projectFile == null) {
            throw new MetadataException(MESSAGE_CODE_NOT_FOUND, new Object[]{namespace}, HttpStatus.SC_BAD_REQUEST);
        }
        String swagger = projectFile.getSwagger();
        if (StringUtils.isBlank(swagger)) {
            throw new MetadataException(MESSAGE_CODE_SWAGGER_NOT_FOUND, new Object[0], HttpStatus.SC_BAD_REQUEST);
        }
        JsonObject swaggerJsonObj = JsonUtils.generateJsonObjectFromJsonString(swagger);
        JsonElement serviceElement = swaggerJsonObj.get(namespace);
        if (serviceElement == null) {
            throw new MetadataException(MESSAGE_CODE_NOT_FOUND, new Object[]{namespace}, HttpStatus.SC_BAD_REQUEST);
        }
        ret.setSwaggerObj(serviceElement.getAsJsonObject());
        String derivedCsn = projectFile.getDerivedCsn();
        if (StringUtils.isBlank(derivedCsn)) {
            throw new MetadataException(MESSAGE_CODE_NOT_FOUND, new Object[]{modelNamespace}, HttpStatus.SC_BAD_REQUEST);
        }
        List<MetadataEntity> entities = CsnParser.parseToEntities(derivedCsn);
        List<MetadataEntity> filteredEntities = entities.stream().filter(e -> isEntityExisted(e, eventEntityName)).collect(Collectors.toList());
        if (filteredEntities.isEmpty()) {
            throw new MetadataException(MESSAGE_CODE_NOT_FOUND, new Object[]{eventEntityName}, HttpStatus.SC_BAD_REQUEST);
        }
        if (filteredEntities.size() > 1) {
            throw new MetadataException(MESSAGE_CODE_MORE_THAN_ONE_FOUND, new Object[]{eventEntityName}, HttpStatus.SC_BAD_REQUEST);
        }
        MetadataEntity entity = filteredEntities.get(0);
        String fullName = entity.getName();
        String baseType = entity.getBaseType();
        ret.setEventType(fullName);
        MetadataEntity processEntity = getTrackedProcessEntityByEventType(entities, modelNamespace, fullName);
        ret.setApplicationObjectType(processEntity.getApplicationObjectType());
        ret.setTrackedProcessType(processEntity.getName());
        if (!entity.isProcessEvent() && !CsnParser.isEvent(baseType)) {
            throw new MetadataException(MESSAGE_CODE_INVALID_ENTITY_FOUND, new Object[]{eventEntityName}, HttpStatus.SC_BAD_REQUEST);
        }
        if (entity.isProcessEvent() || CoreModelEntity.GTT_UPDATE_PLAN_EVENT.getFullName().equalsIgnoreCase(fullName)) {
            ret.setTrackedProcess(entity.isProcessEvent());
            List<MetadataEntityEvent> entityEvents = processEntity.getPlannedEvents();
            ret.setPlannedEvents(entityEvents.stream().map(MetadataEntityEvent::getEventType).collect(Collectors.toList()));
        }
        return ret;
    }

    private String getModelNamespace(String serviceNamespace) {
        if (StringUtils.isBlank(serviceNamespace) || StringUtils.indexOf(serviceNamespace, DOT) == -1) {
            throw new MetadataException(MESSAGE_CODE_BAD_SERVICE, new Object[]{serviceNamespace}, HttpStatus.SC_BAD_REQUEST);
        }
        return StringUtils.substring(serviceNamespace, 0, StringUtils.lastIndexOf(serviceNamespace, DOT));
    }

    private boolean isEntityExisted(MetadataEntity entity, String searchedName) {
        String name = entity.getName();
        String entityShortName = name.substring(name.lastIndexOf(DOT) + 1);
        return searchedName.equalsIgnoreCase(name) || searchedName.equalsIgnoreCase(entityShortName);
    }

    @Transactional(readOnly = true)
    @Override
    @Cacheable(cacheNames = CACHE_NAME_METADATA_ENTITY_PHYSICAL_NAME, key = "#namespace + '" + GTTUtils.GLOBAL_STRING_SPLITOR + "' + #entityName"
            , condition = SystemConstants.SPRING_BEAN_SPEL_CONDITION_ON_IS_CACHE_ENABLED)
    public PhysicalName getPhysicalNameOfEntity(String namespace, String entityName) {
        String entityAbbrName = CsnParser.getEntityAbbrName(entityName);
        MetadataEntity entity = getMetadataEntity(namespace, entityAbbrName);
        return DBUtils.getPhysicalName(entity.getName(), entity.getBaseType(), entity.isIncludeCustomizedFields(),
                entity.getExtendedPlanName());
    }

    private List<MetadataEntity> getAllEntities(String namespace) {
        //1. fetch related CSN by namespace
        String derivedCsn = getDerivedCsn(namespace);
        //2. parse to entities
        return CsnParser.parseToEntities(derivedCsn);
    }

    private MetadataEntity getMetadataEntity(String namespace, String entityName) {
        //1. fetch related CSN by namespace
        String derivedCsn = getDerivedCsn(namespace);
        //2. parse CSN data to fetch the specified entity details
        return getMetadataEntityFromDerivedCsn(derivedCsn, entityName);
    }

    private String getDerivedCsn(String namespace) {
        MetadataCriteria criteria = new MetadataCriteria();
        criteria.addNamespace(namespace);
        criteria.setStatus(MetadataProjectStatus.ACTIVE.name());
        String derivedCsn = getMetadataDao().getMetadataDerivedCsn(criteria);
        if (StringUtils.isBlank(derivedCsn)) {
            throw new MetadataException(MESSAGE_CODE_NOT_FOUND, new Object[]{namespace}, HttpStatus.SC_NOT_FOUND);
        }
        return derivedCsn;
    }

    private MetadataEntity getCoreModelMetadataEntity(String entityName) {
        //1. fetch related CSN by namespace
        String derivedCsn = getCoreModelDerivedCsn();
        //2. parse CSN data to fetch the specified entity details
        return getMetadataEntityFromDerivedCsn(derivedCsn, entityName);
    }

    private MetadataEntity getMetadataEntityFromDerivedCsn(String derivedCsn, String entityName) {
        //parse CSN data to fetch the specified entity details
        List<MetadataEntity> entities = CsnParser.findEntities(derivedCsn, entityName);
        if (entities.isEmpty()) {
            throw new MetadataException(MESSAGE_CODE_NOT_FOUND, new Object[]{entityName}, HttpStatus.SC_NOT_FOUND);
        } else if (entities.size() > 1) {
            throw new MetadataException(MESSAGE_CODE_MORE_THAN_ONE_FOUND, new Object[]{entityName});
        }
        return entities.get(0);
    }

    private String getCoreModelDerivedCsn() {
        ClassPathResource resource = new ClassPathResource(CORE_CORE_MODEL_DERIVED_CSN_JSON);
        try (InputStream inputStream = resource.getInputStream()) {
            return IOUtils.toString(inputStream, StandardCharsets.UTF_8);
        } catch (IOException ex) {
            throw new InternalErrorException(ex.getMessage(), ex);
        }
    }

    @Transactional(readOnly = true)
    @Override
    @Cacheable(cacheNames = CACHE_NAME_METADATA_EDMX
            , condition = SystemConstants.SPRING_BEAN_SPEL_CONDITION_ON_IS_CACHE_ENABLED)
    public String getODataEdmx(String odataModel) {
        List<String> queryNamespaces = new ArrayList<>();
        queryNamespaces.add(odataModel);
        String modelNamespace = getModelNamespace(odataModel);
        queryNamespaces.add(modelNamespace);
        String edmx = getMetadataDao().getMetadataProjectFileFieldInfo(queryNamespaces, MetadataProjectFileField.EDMX);
        if (StringUtils.isBlank(edmx)) {
            throw new MetadataException(MESSAGE_CODE_NOT_FOUND, new Object[]{modelNamespace}, HttpStatus.SC_BAD_REQUEST);
        }
        JsonObject edmxObj = JsonUtils.generateJsonObjectFromJsonString(edmx);
        JsonElement element = edmxObj.get(odataModel);
        if (element == null) {
            element = edmxObj.entrySet().iterator().next().getValue();
            if (element == null) {
                throw new MetadataException(MESSAGE_CODE_NOT_FOUND, new Object[]{odataModel}, HttpStatus.SC_BAD_REQUEST);
            }
        }
        return GTTUtils.convertSpecialString(element.toString());
    }

    /**
     * model is active or not
     *
     * @param namespace
     * @return When model is active, the result is true; When model is inactive, the result is false
     */
    @Override
    @Cacheable(cacheNames = CACHE_NAME_METADATA_MODEL_ACTIVE
            , condition = SystemConstants.SPRING_BEAN_SPEL_CONDITION_ON_IS_CACHE_ENABLED)
    @Transactional(readOnly = true)
    public boolean isModelActive(String namespace) {
        List<String> queryNamespaces = new ArrayList<>();
        queryNamespaces.add(namespace);
        String modelNamespace = getModelNamespace(namespace);
        queryNamespaces.add(modelNamespace);
        MetadataCriteria criteria = new MetadataCriteria();
        queryNamespaces.forEach(criteria::addNamespace);
        List<MetadataProject> metadataProjectList = findMetadataProjectInfo(criteria);
        if (metadataProjectList.isEmpty()) {
            throw new MetadataException(MESSAGE_CODE_NOT_FOUND, new Object[]{modelNamespace}, HttpStatus.SC_BAD_REQUEST);
        }
        //one modelNamespace will get one MetadataProject
        String status = metadataProjectList.get(0).getStatus();
        return MetadataProjectStatus.ACTIVE.name().equalsIgnoreCase(status);
    }

    @Transactional(readOnly = true)
    @Override
    public List<MetadataEntity> findODataNavigationEntitiesByPath(String odataMainEntityType, String path) {
        List<MetadataEntity> ret = new ArrayList<>();
        String namespace = CsnParser.getProjectNamespace(odataMainEntityType);
        Map<String, MetadataEntity> entityMap = new HashMap<>(16);
        MetadataEntity mainEntity = findMainEntityWithAll(namespace, odataMainEntityType, entityMap);
        ret.add(mainEntity);
        findEntities(entityMap, mainEntity, path, ret);
        return ret;
    }

    @Override
    public List<List<MetadataEntity>> findReversedNavigationEntities(String namespace, String entityAbbrName) {
        /**
         * for a given entity, find all the referencedBy entities
         */
        List<List<MetadataEntity>> ret = new ArrayList<>();
        String derivedCsn = getDerivedCsn(namespace);
        Map<String, MetadataEntity> allEntitiesMap = CsnParser.parseToEntityMap(derivedCsn);
        Optional<MetadataEntity> referenceEntityOption = allEntitiesMap.values().stream()
                .filter(e -> CsnParser.getEntityAbbrName(e.getName()).equalsIgnoreCase(entityAbbrName))
                .findFirst();
        MetadataEntity referenceEntity = referenceEntityOption
                .orElseThrow(() -> new MetadataException(MESSAGE_CODE_NOT_FOUND, new Object[]{entityAbbrName}));
        List<MetadataEntity> directReferencedByEntities = new ArrayList<>();
        List<MetadataEntity> interPathEntities = new ArrayList<>();
        findAllReferencedByEntities(allEntitiesMap, referenceEntity, directReferencedByEntities, interPathEntities, ret);
        if (CollectionUtils.isEmpty(directReferencedByEntities)) {
            List<MetadataEntity> meArr = new ArrayList<>();
            meArr.add(referenceEntity);
            ret.add(meArr);
        }
        return ret;
    }

    /**
     * For each entity, find all the direct referenced entities of it, and then iterate all these entities,
     * if it is event or tp, then write the data to the response result. For other events,
     * recursively find its root event or tp type and then write to response result.
     *
     * @param allEntitiesMap             entity maps
     * @param referenceEntity            reference entity
     * @param directReferencedByEntities directly referenced by entities
     * @param interPathEntities          intermediate entities
     * @param finalResult                final result
     */
    private void findAllReferencedByEntities(Map<String, MetadataEntity> allEntitiesMap, MetadataEntity referenceEntity,
                                             List<MetadataEntity> directReferencedByEntities,
                                             List<MetadataEntity> interPathEntities,
                                             List<List<MetadataEntity>> finalResult) {
        String referenceEntityName = referenceEntity.getName();
        allEntitiesMap.remove(referenceEntityName);
        interPathEntities.add(referenceEntity);
        allEntitiesMap.forEach((k, v) ->
                findDirectReferencedByEntities(directReferencedByEntities, referenceEntityName, k, v)
        );
        if (CollectionUtils.isEmpty(directReferencedByEntities)) {
            return;
        }
        int directReferencedBySize = directReferencedByEntities.size();
        for (int i = 0; i < directReferencedBySize; i++) {
            MetadataEntity referencedByEntity = directReferencedByEntities.get(i);
            String baseType = referencedByEntity.getBaseType();
            String name = referencedByEntity.getName();
            int interSize = interPathEntities.size();
            if (interSize > 1 && i > 0) {
                MetadataEntity interEntity = interPathEntities.get(interSize - 1);
                if (interEntity.getName().equalsIgnoreCase(directReferencedByEntities.get(i - 1).getName())) {
                    interPathEntities.remove(interSize - 1);
                }
            }
            if (CsnParser.isEvent(baseType) || CsnParser.isTrackedProcess(baseType)
                    || referencedByEntity.isProcessEvent() || isCoreModelRootEntity(referencedByEntity)) {
                List<MetadataEntity> item = new ArrayList<>();
                if (CollectionUtils.isNotEmpty(interPathEntities)) {
                    item.addAll(interPathEntities);
                }
                item.add(referencedByEntity);
                finalResult.add(item);
                allEntitiesMap.remove(name);
                continue;
            }
            List<MetadataEntity> innerReferencedByEntities = new ArrayList<>();
            findAllReferencedByEntities(allEntitiesMap, referencedByEntity, innerReferencedByEntities,
                    interPathEntities, finalResult);
        }
    }

    private void findDirectReferencedByEntities(List<MetadataEntity> directReferencedByEntities, String referenceEntityName, String entityName, MetadataEntity entity) {
        if (entityName.equalsIgnoreCase(referenceEntityName) || CsnParser.isForWriteEntity(entityName)) {
            return;
        }
        List<MetadataEntityElement> elements = entity.getElements();
        elements.forEach(e -> {
            CdsDataType type = e.getType();
            String target = e.getTarget();
            if ((CdsDataType.CDS_ASSOCIATION == type || CdsDataType.CDS_COMPOSITION == type)
                    && referenceEntityName.equalsIgnoreCase(target)
            ) {
                directReferencedByEntities.add(entity);
            }
        });
    }

    private boolean isCoreModelRootEntity(MetadataEntity metadataEntity) {

        return CoreModelEntity.EVENT.getFullName().equalsIgnoreCase(metadataEntity.getName())
                || CoreModelEntity.TRACKED_PROCESS.getFullName().equalsIgnoreCase(metadataEntity.getName())
                ;
    }

    private MetadataEntity findMainEntityWithAll(String namespace, String origEntityName, Map<String, MetadataEntity> allEntityMap) {
        String abbrName = CsnParser.getEntityAbbrName(origEntityName);
        String derivedCsn = getDerivedCsn(namespace);
        allEntityMap.putAll(CsnParser.parseToEntityMap(derivedCsn));
        Optional<String> mainEntityName = allEntityMap.keySet().stream()
                .filter(k -> (k.startsWith(namespace) || k.startsWith(CORE_MODEL_PREFIX))
                        && k.endsWith(DOT + abbrName))
                .findFirst();
        if (!mainEntityName.isPresent()) {
            throw new MetadataException(MESSAGE_CODE_NOT_FOUND, new Object[]{origEntityName});
        }
        return allEntityMap.get(mainEntityName.get());
    }

    private void findEntities(Map<String, MetadataEntity> allEntityMap, MetadataEntity currentEntity, String path, List<MetadataEntity> entityList) {
        String elementName = path;
        int indx = path.indexOf('/');
        if (indx != -1) {
            elementName = path.substring(0, indx);
            path = path.substring(indx + 1);
        }
        MetadataEntityElement element = currentEntity.getElementMap().get(elementName);
        if (element == null) {
            return;
        }
        String target = element.getTarget();
        if (StringUtils.isBlank(target)) {
            return;
        }
        MetadataEntity targetEntity = allEntityMap.get(target);
        if (targetEntity != null) {
            entityList.add(targetEntity);
        }
        findEntities(allEntityMap, targetEntity, path, entityList);
    }

    @Transactional(readOnly = true)
    @Override
    @Cacheable(cacheNames = CACHE_NAME_METADATA_ENTITY, key = "#namespace + '" + GTTUtils.GLOBAL_STRING_SPLITOR + "' + #entityName"
            , condition = SystemConstants.SPRING_BEAN_SPEL_CONDITION_ON_IS_CACHE_ENABLED)
    public CurrentMetadataEntity findAllEntitiesRecursively(String namespace, String entityName) {
        CurrentMetadataEntity currentMetadataEntity = new CurrentMetadataEntity();
        currentMetadataEntity.setNamespace(namespace);
        ModelConfiguration modelConfig = getModelConfiguration(namespace);
        currentMetadataEntity.setEnableInstanceBasedAuthorization(modelConfig.isEnableInstanceBasedAuthorization());
        currentMetadataEntity.setEventCorrelationLevel(modelConfig.getEventCorrelationLevel());
        Map<String, MetadataEntity> allRelatedEntityMap = new HashMap<>(INITIAL_CAPACITY);
        Map<String, MetadataEntity> allEntityMap = new HashMap<>(INITIAL_CAPACITY);
        MetadataEntity mainEntity = findMainEntityWithAll(namespace, entityName, allEntityMap);
        String mainEntityName = mainEntity.getName();
        currentMetadataEntity.setCurrentEntityName(mainEntityName);
        allRelatedEntityMap.put(mainEntityName, mainEntity);
        CsnParser.findRelatedEntities(allEntityMap, mainEntity, allRelatedEntityMap);
        currentMetadataEntity.setAllRelatedEntityMap(allRelatedEntityMap);
        return currentMetadataEntity;
    }

    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    @Override
    @CacheEvict(value = CACHE_NAME_METADATA_CHANGE_HISTORY, allEntries = true)
    public void insertMetadataChangeHistory(MetadataChangeHistory metadataChangeHistory) {
        getMetadataDao().insertMetadataChangeHistory(metadataChangeHistory);
    }

    @Transactional(readOnly = true)
    @Override
    @Cacheable(value = CACHE_NAME_METADATA_CHANGE_HISTORY
            , condition = SystemConstants.SPRING_BEAN_SPEL_CONDITION_ON_IS_CACHE_ENABLED)
    public List<MetadataChangeHistory> findMetadataChangeHistoryByNamespace(String namespace) {
        return getMetadataDao().findMetadataChangeHistoryByNamespace(namespace);
    }

    @Override
    public List<String> findDppFieldList(String namespace, String entityType, DppType dppType) {
        MetadataEntity metadataEntity = getMetadataEntity(namespace, entityType);
        List<MetadataEntityElement> metadataEntityElements = metadataEntity.getElements().stream()
                .filter(e -> {
                    boolean ret = false;
                    switch (dppType) {
                        case DPP_DATA_SUBJECTID:
                            ret = e.isDppDataSubjectId();
                            break;
                        case DPP_PII:
                            ret = e.isDppPii();
                            break;
                        case DPP_SPI:
                            ret = e.isDppSpi();
                            break;
                    }
                    return ret;
                })
                .collect(Collectors.toList());
        List<String> resultList = new ArrayList();
        metadataEntityElements.forEach(e -> resultList.add(e.getName()));
        return resultList;
    }

    @Override
    @Transactional(readOnly = true)
    @Cacheable(value = CACHE_NAME_METADATA_DRAFT_MODEL_LIST
            , condition = SystemConstants.SPRING_BEAN_SPEL_CONDITION_ON_IS_CACHE_ENABLED)
    public List<MetadataDraftModel> getAllMetadataDraftModelsInfo(boolean includeJsonModel) {
        return getMetadataDao().selectAllMetadataDraftModelsInfo(includeJsonModel);
    }


    @Override
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    @CacheEvict(value = CACHE_NAME_METADATA_DRAFT_MODEL_LIST, allEntries = true)
    public void createMetadataDraftModel(MetadataDraftModel metadataDraftModel) {
        getMetadataDao().insertMetadataDraftModel(metadataDraftModel);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    @CacheEvict(value = CACHE_NAME_METADATA_DRAFT_MODEL_LIST, allEntries = true)
    public void updateMetadataDraftModelInfo(MetadataDraftModel metadataDraftModel) {
        getMetadataDao().updateMetadataDraftModelInfo(metadataDraftModel);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    @CacheEvict(value = CACHE_NAME_METADATA_DRAFT_MODEL_LIST, allEntries = true)
    public void updateMetadataDraftModel(String namespace, MetadataDraftModel metadataDraftModel) {
        getMetadataDao().updateMetadataDraftModel(namespace, metadataDraftModel);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    @CacheEvict(value = CACHE_NAME_METADATA_DRAFT_MODEL_LIST, allEntries = true)
    public void deleteMetadataDraftModel(String namespace) {
        getMetadataDao().deleteMetadataDraftModel(namespace);
    }

    @Override
    @Transactional(readOnly = true)
    public MetadataDraftModel getMetadataDraftModelInfoByNamespace(String namespace) {
        return getMetadataDao().getMetadataDraftModelInfoByNamespace(namespace);
    }

    @Override
    public MetadataDraftModel getMetadataDraftModelByNamespace(String namespace) {
        return getMetadataDao().getMetadataDraftModelByNamespace(namespace);
    }

    @Override
    @Transactional(readOnly = true)
    public List<MetadataEntity> findAllEventEntitiesByNamespace(String namespace, boolean excludeCoreModelEvent) {
        String derivedCsn = getDerivedCsn(namespace);
        List<MetadataEntity> entities = CsnParser.parseToEntities(derivedCsn);
        return entities.stream().filter(e -> {
            boolean ret = EntityBaseType.EVENT.getValue().equalsIgnoreCase(e.getBaseType());
            if (excludeCoreModelEvent) {
                ret = ret && !CsnParser.isCoreModelEntity(e.getName());
            }
            return ret;

        }).collect(Collectors.toList());
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<MetadataEntity> findAllTrackedProcessAndEventEntitiesByNamespace(String namespace, boolean excludeCoreModelEvent) {
        String derivedCsn = getDerivedCsn(namespace);
        List<MetadataEntity> entities = CsnParser.parseToEntities(derivedCsn);
        return CsnParser.getAllTrackedProcessAndEventEntities(entities, excludeCoreModelEvent);
    }

    @Override
    public String getPdmSchema() {
        logger.info("begin get pdmSchema...");
        String pdmSchema = getDppDao().getPdmSchema();
        if (pdmSchema != null) {
            logger.info(" *** Get pdm schema success.");
        } else {
            logger.info(" *** pdmSchema is empty!");
        }
        return pdmSchema;
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    public void upsertPdmSchema(String namespace) {
        //create or get pdmSchema:
        String pdmSchemaStrInDB = getPdmSchema();
        List<MetadataEntity> metadataEntities = getAllEntities(namespace);
        List<MetadataEntity> metadataEntitiesWithoutForWriteEntities = getEntitiesWithoutForWriteEntities(metadataEntities);
        if (metadataEntitiesWithoutForWriteEntities != null && !metadataEntitiesWithoutForWriteEntities.isEmpty()) {
            String updatedPdmSchemaStr = DppUtil.getUpsertPdmSchema(pdmSchemaStrInDB, metadataEntitiesWithoutForWriteEntities);
            if (StringUtils.isNotBlank(pdmSchemaStrInDB)) {
                getDppDao().updatePdmSchema(deleteDeletedPdmSchema(updatedPdmSchemaStr));
            } else {
                getDppDao().insertPdmSchema(updatedPdmSchemaStr);
            }
        }

    }

    private List<MetadataEntity> getEntitiesWithoutForWriteEntities(List<MetadataEntity> metadataEntities) {
        return metadataEntities.stream().filter(e -> !CsnParser.isForWriteEntity(e.getName())).collect(Collectors.toList());
    }

    @Override
    public void deletePdmSchema(String namespace) {
        String pdmSchemaStrInDBStr = getPdmSchema();
        if (StringUtils.isNotBlank(pdmSchemaStrInDBStr)) {
            //remove the entity with the namespace:
            JsonObject pdmSchema = JsonUtils.generateJsonObjectFromJsonString(pdmSchemaStrInDBStr);
            JsonArray entities = pdmSchema.get(PDM_ENTITIES).getAsJsonArray();
            DppUtil.removeDppEntity(namespace, entities);
            getDppDao().updatePdmSchema(deleteDeletedPdmSchema(JsonUtils.generateJsonStringFromBean(pdmSchema)));
        }
    }

    private String deleteDeletedPdmSchema(String pdmSchemaStr) {
        JsonObject pdmSchemaJsonObj = JsonUtils.generateJsonObjectFromJsonString(pdmSchemaStr);
        JsonArray entities = pdmSchemaJsonObj.get(PDM_ENTITIES).getAsJsonArray();
        Set<String> namesapceWithDotSet = DppUtil.getAllNamespacesOfPdmSchema(pdmSchemaJsonObj);
        List<MetadataProject> allMetaDataProject = getMetadataDao().findAllMetadataProject();
        Set<String> existedNamespace = allMetaDataProject.stream().map(MetadataProject::getNamespace).collect(Collectors.toSet());
        namesapceWithDotSet.stream().filter(namespace -> !existedNamespace.contains(namespace) && !namespace.equals(DppUtil.COMSAPGTTCORE_CORE_MODEL_NAMESPACE)).forEach(namespace -> DppUtil.removeDppEntity(namespace, entities));
        return JsonUtils.generateJsonStringFromBean(pdmSchemaJsonObj);
    }

    @Override
    public boolean isDataSubjectIdValueExistsInDB(String dataSubjectIdValue) {
        boolean isDataSubjectIdValueExistsInDB = false;
        String pdmSchemaStrInDBStr = getPdmSchema();
        if (StringUtils.isNotBlank(pdmSchemaStrInDBStr)) {
            JsonObject pdmSchemaJsonObj = JsonUtils.generateJsonObjectFromJsonString(pdmSchemaStrInDBStr);
            if (pdmSchemaJsonObj != null) {
                Set<String> namesapceWithDotSet = DppUtil.getAllNamespacesOfPdmSchema(pdmSchemaJsonObj);
                List<MetadataEntity> metadataEntitiesOfAllNamespace = new ArrayList();
                namesapceWithDotSet = namesapceWithDotSet.stream().filter(namespace -> !namespace.equals(DppUtil.COMSAPGTTCORE_CORE_MODEL_NAMESPACE)).collect(Collectors.toSet());
                for (String namesapceWithDot : namesapceWithDotSet) {
                    List<MetadataEntity> metadataEntities = getAllEntities(namesapceWithDot);
                    List<MetadataEntity> metadataEntitiesWithoutForWriteEntities = getEntitiesWithoutForWriteEntities(metadataEntities);
                    if (metadataEntitiesWithoutForWriteEntities != null && !metadataEntitiesWithoutForWriteEntities.isEmpty()) {
                        metadataEntitiesOfAllNamespace.addAll(metadataEntitiesWithoutForWriteEntities);
                    }
                }
                List<DppEntity> dppEntities = DppUtil.findDppEntitiesElements(metadataEntitiesOfAllNamespace);
                isDataSubjectIdValueExistsInDB = getDppDao().isDataSubjectIdExistsInDB(dataSubjectIdValue, dppEntities);
            }
        }
        return isDataSubjectIdValueExistsInDB;
    }

    @Override
    public List<Map<String, Object>> getPdmDataInfo(String entityName, String dataSubjectIdValue) {
        String nameSpaceOfOldEntity = CsnParser.getProjectNamespace(entityName.replace(UNDER_LINE, DOT));
        MetadataEntity metadataEntity = null;
        if (nameSpaceOfOldEntity.equals(DppUtil.COMSAPGTTCORE_CORE_MODEL_NAMESPACE)) {
            metadataEntity = getCoreModelMetadataEntity(entityName.replace(UNDER_LINE, DOT));
        } else {
            metadataEntity = getMetadataEntity(nameSpaceOfOldEntity, entityName.replace(UNDER_LINE, DOT));
        }
        List<MetadataEntity> metadataEntities = new ArrayList();
        metadataEntities.add(metadataEntity);
        List<DppEntity> dppEntities = DppUtil.findDppEntitiesElements(metadataEntities);
        return getDppDao().getPdmDataInfo(dataSubjectIdValue, dppEntities.get(0));
    }

    @Override
    public long countTableRows(MetadataEntity metadataEntity) {
        return getSysTableDao().countTableRows(metadataEntity);
    }


    @CacheEvict(value = {CACHE_NAME_METADATA_ENTITY, CACHE_NAME_METADATA_SWAGGER, CACHE_NAME_METADATA_FIELDINFO, CACHE_NAME_METADATA_EDMX, CACHE_NAME_METADATA_MODEL_ACTIVE,
            CACHE_NAME_METADATA_EVENT_TYPE, CACHE_NAME_METADATA_IS_EVENT_UNPLANNED, CACHE_NAME_METADATA_ALL_FIELDS_OF_ENTITY,
            CACHE_NAME_METADATA_ENTITY_EVENT, CACHE_NAME_METADATA_ENTITY_PHYSICAL_NAME, CACHE_NAME_METADATA_CHANGE_HISTORY, CACHE_NAME_METADATA_DRAFT_MODEL_LIST,
            CACHE_NAME_METADATA_PROCESS_EVENT_ENTITY, CACHE_NAME_METADATA_EVENT_ENTITY, CACHE_NAME_METADATA_MODEL_ENABLE_INSTANCE_AUTHORIZATION}, allEntries = true)
    @Scheduled(fixedDelay = 300 * 1000) // 300 seconds
    public void evictAll() {
        logger.debug("Invalidating all local metadata caches...");
    }

    @Override
    public String getI18nInfo(String namespace, String fileName) {
        String ret = "";
        List<String> namespaces = new ArrayList<>();
        namespaces.add(namespace);
        String fieldInfo = getMetadataDao().getMetadataProjectFileFieldInfo(namespaces, MetadataProjectFileField.I18N);
        if (StringUtils.isNotBlank(fieldInfo)) {
            JsonObject jsonObject = JsonUtils.generateJsonObjectFromJsonString(fieldInfo);
            JsonElement contentElement = jsonObject.get(fileName);
            if (contentElement != null) {
                ret = contentElement.getAsString();
            }
        }
        return ret;
    }

    @Override
    public String getUiAnnotation(String namespace) {
        String ret;
        List<String> namespaces = new ArrayList<>();
        namespaces.add(namespace);
        ret = getMetadataDao().getMetadataProjectFileFieldInfo(namespaces, MetadataProjectFileField.ANNOTATION);
        if (StringUtils.isNotBlank(ret)) {
            JsonObject jsonObject = JsonUtils.generateJsonObjectFromJsonString(ret);
            ret = jsonObject.entrySet().iterator().next().getValue().getAsString();
        }
        return GTTUtils.convertSpecialString(ret);
    }

    @Override
    public void emptyTable(String tableName) {
        getSysTableDao().emptyTable(tableName);
    }

    @Override
    public void insertCodeList(CodeList codeList) {
        getSysTableDao().insertCodeList(codeList);
    }

    @Override
    public void insertCodeListTexts(CodeList codeList) {
        getSysTableDao().insertCodeListTexts(codeList);
    }

    @Override
    public String getServiceNamespace(String modelNamespace, boolean forWriteService) {
        List<String> namespaces = new ArrayList<>();
        namespaces.add(modelNamespace);
        MetadataProjectFileField field = null;
        if (forWriteService) {
            field = MetadataProjectFileField.SWAGGER;
        } else {
            field = MetadataProjectFileField.DERIVED_CSN;
        }
        String fieldInfo = getMetadataDao().getMetadataProjectFileFieldInfo(namespaces, field);
        JsonObject jsonObject = JsonUtils.generateJsonObjectFromJsonString(fieldInfo);
        String ret = null;
        if (forWriteService) {
            ret = jsonObject.keySet().iterator().next();
        } else {
            JsonElement serviceElement = jsonObject.get(EntityKind.SERVICE.getValue());
            if (!JsonUtils.isNull(serviceElement)) {
                ret = serviceElement.getAsString();
            }
        }
        return ret;
    }

    @Override
    @Transactional(readOnly = true)
    @Cacheable(cacheNames = CACHE_NAME_METADATA_PROCESS_EVENT_ENTITY, key = "#processType"
            , condition = SystemConstants.SPRING_BEAN_SPEL_CONDITION_ON_IS_CACHE_ENABLED)
    public CurrentMetadataEntity getProcessEventEntity(String processType) {
        String namespaceWithContext = CsnParser.cutStringFromLastDot(processType);
        String namespace = CsnParser.cutStringFromLastDot(namespaceWithContext);
        List<MetadataEntity> allEntities = getAllEntities(namespace);
        List<MetadataEntity> processEventList = allEntities.stream().filter(metadataEntity ->
                metadataEntity.isProcessEvent() && metadataEntity.getName().equals(processType + "Event"))
                .collect(Collectors.toList());
        if (processEventList.isEmpty()) {
            throw new MetadataException(MESSAGE_CODE_NOT_FOUND_TRACKED_PROCESS_EVENT_ENTITY, new Object[]{processType});
        }

        String processEventName = processEventList.get(0).getName();
        return this.findAllEntitiesRecursively(namespace, processEventName);
    }

    @Override
    @Transactional(readOnly = true)
    @Cacheable(cacheNames = CACHE_NAME_METADATA_EVENT_ENTITY, key = "#eventType"
            , condition = SystemConstants.SPRING_BEAN_SPEL_CONDITION_ON_IS_CACHE_ENABLED)
    public CurrentMetadataEntity getEventEntity(String eventType) {
        String namespace = CsnParser.getProjectNamespace(eventType);
        List<MetadataEntity> allEntities = getAllEntities(namespace);
        List<MetadataEntity> eventList = allEntities.stream().filter(metadataEntity ->
                metadataEntity.getName().equals(eventType))
                .collect(Collectors.toList());
        if (eventList.isEmpty()) {
            throw new MetadataException(MESSAGE_CODE_NOT_FOUND_EVENT_ENTITY, new Object[]{eventType});
        }
        return this.findAllEntitiesRecursively(namespace, eventList.get(0).getName());
    }

    @Override
    @Cacheable(cacheNames = CACHE_NAME_METADATA_MODEL_MODEL_CONFIGURATION
            , condition = SystemConstants.SPRING_BEAN_SPEL_CONDITION_ON_IS_CACHE_ENABLED)
    public ModelConfiguration getModelConfiguration(String namespace) {
        ModelConfiguration modelConfiguration = new ModelConfiguration();
        String derivedCsn = this.getDerivedCsn(namespace);
        JsonObject jsonObject = JsonUtils.generateJsonObjectFromJsonString(derivedCsn);
        JsonElement enabled = jsonObject.get(ENABLE_INSTANCE_BASED_AUTHORIZATION);
        JsonElement level = jsonObject.get(EVENT_CORRELATION_LEVEL);
        modelConfiguration.setEventCorrelationLevel(!JsonUtils.isNull(level) ? level.getAsInt() : 1);
        modelConfiguration.setEnableInstanceBasedAuthorization(!JsonUtils.isNull(enabled) && enabled.getAsBoolean());
        return modelConfiguration;
    }

    @Override
    public List<Pair<String, String>> findMatchedExtensionFieldPairs(String eventType) {
        List<Pair<String, String>> ret = new ArrayList<>();
        String namespace = CsnParser.getProjectNamespace(eventType);
        List<MetadataEntity> allEntities = getAllEntities(namespace);
        allEntities.forEach(e -> {
            List<MetadataEntityElement> elements = e.getElements();
            elements.forEach(el -> {
                List<String> replaceActualEventFields = el.getReplaceActualEventFields();
                replaceActualEventFields.forEach(re -> {
                    if (re.indexOf(eventType) > -1) {
                        Pair<String, String> p = Pair.of(el.getName(), re.substring(re.lastIndexOf(DOT) + 1));
                        if (!ret.contains(p)) {
                            ret.add(p);
                        }
                    }
                });
            });
        });
        return ret;
    }

    @Override
    public long countTrackedProcessByType(String trackedProcessType) {
        return getMetadataDao().countTrackedProcessByType(trackedProcessType);
    }
}