package com.sap.gtt.v2.exception;

import org.apache.http.HttpStatus;

public class ValueParseException extends GeneralNoneTranslatableException {
    public static final String ERROR_CODE = "ERROR_CODE_VALUE_PARSE";

    public ValueParseException(String message, Throwable cause) {
        super(message, cause, HttpStatus.SC_BAD_REQUEST);
    }

    @Override
    public String getErrorCode() {
        return ERROR_CODE;
    }

}
