package com.sap.gtt.v2.core.service;

import com.sap.gtt.v2.bp.BusinessPartner;
import com.sap.gtt.v2.configuration.ISAPCloudPlatformAgent;
import com.sap.gtt.v2.configuration.SystemConstants;
import com.sap.gtt.v2.core.domain.execution.ExecutionStatus;
import com.sap.gtt.v2.core.domain.execution.MappingMessageDto;
import com.sap.gtt.v2.core.domain.metadata.*;
import com.sap.gtt.v2.core.domain.trackedprocess.Action;
import com.sap.gtt.v2.core.domain.trackedprocess.Constant;
import com.sap.gtt.v2.core.entity.metadata.MetadataProcess;
import com.sap.gtt.v2.core.entity.trackedprocess.Event;
import com.sap.gtt.v2.core.entity.trackedprocess.PlannedEvent;
import com.sap.gtt.v2.core.entity.trackedprocess.Reference;
import com.sap.gtt.v2.core.entity.trackedprocess.TrackedProcess;
import com.sap.gtt.v2.core.management.execution.IMessageLogManagement;
import com.sap.gtt.v2.core.management.metadata.IMetadataManagement;
import com.sap.gtt.v2.core.management.tracking.ITrackedProcessManagement;
import com.sap.gtt.v2.core.runtime.model.IPropertyValue;
import com.sap.gtt.v2.core.runtime.model.ListValue;
import com.sap.gtt.v2.core.runtime.model.ObjectValue;
import com.sap.gtt.v2.core.runtime.model.UUIDValue;
import com.sap.gtt.v2.exception.BaseRuntimeException;
import com.sap.gtt.v2.exception.MessageValidationException;
import com.sap.gtt.v2.exception.MultiExceptionContainer;
import com.sap.gtt.v2.exception.TrackedProcessCheckException;
import com.sap.gtt.v2.util.GTTUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.stream.Collectors;

import static com.sap.gtt.v2.core.domain.metadata.MetadataConstants.CoreModelEntity.*;
import static com.sap.gtt.v2.core.entity.trackedprocess.PlannedEvent.*;
import static com.sap.gtt.v2.core.entity.trackedprocess.Reference.REFERENCE_TYPE;
import static com.sap.gtt.v2.exception.MessageValidationException.*;
import static com.sap.gtt.v2.exception.TrackedProcessCheckException.MESSAGE_CODE_TP_NOT_EXIST;

/**
 * Message Validation
 *
 * @author I321712
 */
@Service
public class MessageValidation {

    public static final String OR = " OR ";
    @Autowired
    private ISAPCloudPlatformAgent.ICurrentAccessContext currentContext;

    public void validate(List<Event> events, String requestId, String writeServiceId) {
        MultiExceptionContainer exceptionContainer = new MultiExceptionContainer(HttpStatus.SC_BAD_REQUEST);
        List<MappingMessageDto> messages = new ArrayList<>();
        for (Event event : events) {
            MultiExceptionContainer exceptionContainerEvent = new MultiExceptionContainer(HttpStatus.SC_BAD_REQUEST, ERROR_CODE);
            validateOneEvent(event, exceptionContainerEvent);
            UUID eventId = GTTUtils.UUIDUtils.generateTimeBasedUUID();
            event.setId(eventId);
            if (!GTT_OVERDUE_EVENT.getFullName().equals(event.getEventType())) {
                MappingMessageDto messageDto;
                if (!exceptionContainerEvent.getContainedExceptions().isEmpty()) {
                    messageDto = buildMappingMessage(requestId, writeServiceId, null, ExecutionStatus.ERROR,
                            exceptionContainerEvent);
                    exceptionContainer.addExceptions(exceptionContainerEvent.getContainedExceptions());
                } else {
                    messageDto = buildMappingMessage(requestId, writeServiceId, eventId.toString(), ExecutionStatus.SUCCESS, null);
                }
                messages.add(messageDto);
            }
        }
        if (!exceptionContainer.getContainedExceptions().isEmpty()) {
            messages.stream().forEach(message -> message.setTargetId(null));
        }
        saveMessageLogs(messages);
        if (!exceptionContainer.getContainedExceptions().isEmpty()) {
            throw exceptionContainer;
        }
    }

    private void validateOneEvent(Event event, MultiExceptionContainer exceptionContainer) {
        boolean existedEventType = validateRequired(event, Event.EVENT_TYPE, exceptionContainer);
        validateSenderPartyId(event, exceptionContainer);
        String altKey = event.getAltKey();
        validateAltKey(altKey, exceptionContainer);
        MetadataCriteria criteria = new MetadataCriteria();
        criteria.addNamespace(event.getModelNamespace());
        List<MetadataProcess> metadataProcesses = getMetadataManagement().findAllMetadataProcess(criteria);
        List<String> trackingIdTypes = metadataProcesses.stream().map(MetadataProcess::getTrackingIdType)
                .collect(Collectors.toList());
        validateReferences(event, trackingIdTypes, exceptionContainer);
        MetadataEntity entity = event.getMetadata().getCurrentEntity();
        if (existedEventType) {
            if (entity.isProcessEvent()) {
                validateProcessEvent(event, exceptionContainer);
            } else {
                if (isGTTUpdatePlanEvent(event.getEventType())) {
                    validateGTTUpdatePlanEvent(event, exceptionContainer);
                }
                validateTrackingIdType(altKey, trackingIdTypes, exceptionContainer);
            }
        }
        validateEventEnumValue(event, exceptionContainer);
        validateDuplicateKey(event, exceptionContainer);
    }

    private MappingMessageDto buildMappingMessage(String requestId, String writeServiceId, String eventId,
                                                  ExecutionStatus status, BaseRuntimeException e) {
        MappingMessageDto messageDto = new MappingMessageDto();
        messageDto.setRootRequestId(requestId);
        messageDto.setObjectId(writeServiceId);
        messageDto.setTargetId(eventId);
        messageDto.setStatus(status);
        if (e != null) {
            messageDto.setMessage(e.getErrorCode());
            messageDto.setDetail(e.getLocalizedMessage(SystemConstants.DEFAULT_LOCALE));
        }
        return messageDto;
    }

    private void saveMessageLogs(List<MappingMessageDto> messages) {
        IMessageLogManagement messageLogManagement = getMessageLogManagement();
        messages.stream().forEach(dto -> messageLogManagement.insertMappingMessage(dto));
    }

    protected boolean isGTTDeletionEvent(String eventType) {
        return GTT_DELETION_EVENT.getFullName().equalsIgnoreCase(eventType)
                || GTT_DPP_DELETION_EVENT.getFullName().equalsIgnoreCase(eventType)
                || GTT_DPP_BLOCKING_EVENT.getFullName().equalsIgnoreCase(eventType);
    }

    private boolean isGTTUpdatePlanEvent(String eventType) {
        return GTT_UPDATE_PLAN_EVENT.getFullName().equals(eventType);
    }

    private void validateProcessEvent(Event event, MultiExceptionContainer exceptionContainer) {
        MetadataEntity trackedProcessEntity = getMetadataManagement().getTrackedProcessEntityByEventType(event.getModelNamespace(), event.getEventType());
        validatePlannedEvents(event, trackedProcessEntity, true, exceptionContainer);
        String altKeyE = event.getAltKey();
        GTTUtils.AltKey altKey = GTTUtils.parseAltKey(altKeyE);
        String type = altKey.getType();
        String trackingIdType = trackedProcessEntity.getTrackingIdType();
        if (!type.equals(trackingIdType)) {
            exceptionContainer.addException(new MessageValidationException(MESSAGE_CODE_INVALID_TRACKING_ID_TYPE,
                    new Object[]{type, altKeyE, trackingIdType}));
        }
        String partyId = altKey.getParty();
        String lbnId = null;
        try {
            lbnId = getCurrentLbnId();
        } catch (MessageValidationException e) {
            exceptionContainer.addException(e);
        }
        if (lbnId != null && !lbnId.equals(partyId)) {
            exceptionContainer.addException(new MessageValidationException(MESSAGE_CODE_INVALID_PARTY_ID,
                    new Object[]{partyId, lbnId}));
        }
    }

    private void validateGTTUpdatePlanEvent(Event event, MultiExceptionContainer exceptionContainer) {
        UUID processId = GTTUtils.UUIDUtils.generateNameBasedUUID(event.getAltKey());
        TrackedProcess trackedProcess = getProcessManagement().get(UUIDValue.valueOf(processId));
        if (trackedProcess == null) {
            exceptionContainer.addException(new TrackedProcessCheckException(MESSAGE_CODE_TP_NOT_EXIST, new Object[]{processId}));
            return;
        }
        MetadataEntity trackedProcessEntity = trackedProcess.getMetadata().getCurrentEntity();
        validatePlannedEvents(event, trackedProcessEntity, false, exceptionContainer);
    }

    private void validatePlannedEvents(Event event, MetadataEntity trackedProcessEntity, boolean checkDuplicate, MultiExceptionContainer exceptionContainer) {
        if (!MessageUtil.isNull(event, Event.PLANNED_EVENTS)) {
            List<PlannedEvent> plannedEvents = event.getPlannedEvents();
            validatePlannedEvents(trackedProcessEntity, plannedEvents, checkDuplicate, exceptionContainer);
        }
    }

    private void validateTrackingIdType(String altKey, List<String> trackingIdTypes, MultiExceptionContainer exceptionContainer) {
        GTTUtils.AltKey altKeyObj = GTTUtils.parseAltKey(altKey);
        String type = altKeyObj.getType();
        if (!trackingIdTypes.contains(type)) {
            exceptionContainer.addException(new MessageValidationException(MESSAGE_CODE_INVALID_TRACKING_ID_TYPE,
                    new Object[]{type, altKey, StringUtils.join(trackingIdTypes, OR)}));
        }
    }

    private void validatePlannedEvents(MetadataEntity trackedProcessEntity, List<PlannedEvent> plannedEvents, boolean checkDuplicate, MultiExceptionContainer exceptionContainer) {
        Map<String, MetadataEntityEvent> entityEventMap = trackedProcessEntity.getPlannedEvents().stream()
                .collect(Collectors.toMap(MetadataEntityEvent::getEventType, v -> v));
        List<Map<String, Object>> plannedEventKeyList = new ArrayList<>();
        for (PlannedEvent plannedEvent : plannedEvents) {
            String plannedEventType = plannedEvent.getEventType();
            validateRequired(plannedEvent, EVENTTYPE, exceptionContainer);
            MetadataEntityEvent eventConfig = entityEventMap.get(plannedEventType);
            if (eventConfig == null) {
                exceptionContainer.addException(
                        new MessageValidationException(MESSAGE_CODE_INVALID_PLANNED_EVENT,
                                new Object[]{plannedEventType})
                );
                continue;
            }
            Map<String, Object> plannedEventKeyMap = new HashMap<>(MetadataConstants.INITIAL_CAPACITY);
            plannedEventKeyMap.put(EVENTTYPE, plannedEventType);
            String eventMatchKey = MessageUtil.getPropertyValueAsString(plannedEvent, PlannedEvent.EVENT_MATCH_KEY);
            plannedEventKeyMap.put(PlannedEvent.EVENT_MATCH_KEY, eventMatchKey);
            boolean isMatchLocation = eventConfig.isMatchLocation();
            if (isMatchLocation) {
                plannedEventKeyMap.put(LOCATION_ALTKEY, plannedEvent.getLocationAltKey());
            }
            List<MatchExtensionField> matchExtensionFields = eventConfig.getMatchExtensionFields();
            if (matchExtensionFields != null) {
                for (MatchExtensionField field : matchExtensionFields) {
                    String sourceField = field.getSourceField();
                    plannedEventKeyMap.put(sourceField, MessageUtil.getPropertyValue(plannedEvent, sourceField));
                }
            }
            plannedEventKeyList.add(plannedEventKeyMap);

            Duration techTolerance = eventConfig.getTechnicalToleranceValue();
            Duration bizTolerance = eventConfig.getBusinessToleranceValue();
            Instant plannedTechnicalTimestamp = null;
            Instant plannedBusinessTimestamp = null;
            if (!MessageUtil.isNull(plannedEvent, PLANNED_TECHNICAL_TIMESTAMP)) {
                plannedTechnicalTimestamp = plannedEvent.getPlannedTechnicalTimestamp();
            }
            if (!MessageUtil.isNull(plannedEvent, PLANNED_BUSINESS_TIMESTAMP)) {
                plannedBusinessTimestamp = plannedEvent.getPlannedBusinessTimestamp();
            }
            setTechTimes(plannedEvent, techTolerance, bizTolerance, plannedTechnicalTimestamp, plannedBusinessTimestamp);
            validatePlannedEvent(plannedEvent, isMatchLocation, exceptionContainer);
        }
        if (checkDuplicate) {
            validateDuplicate(plannedEventKeyList, MESSAGE_CODE_DUPLICATE_PLANNED_EVENT, exceptionContainer);
        }
    }

    private void setTechTimes(PlannedEvent plannedEvent, Duration techTolerance, Duration bizTolerance, Instant plannedTechnicalTimestamp, Instant plannedBusinessTimestamp) {
        if (plannedTechnicalTimestamp == null && plannedBusinessTimestamp != null) {
            plannedTechnicalTimestamp = plannedBusinessTimestamp;
            plannedEvent.setPlannedTechnicalTimestamp(plannedTechnicalTimestamp);
        }
        if (MessageUtil.isNull(plannedEvent, PlannedEvent.PLANNED_TECH_TS_EARLIEST)) {
            plannedEvent.setPlannedTechTsEarliest(
                    getTsEarliest(plannedTechnicalTimestamp, techTolerance));
        }
        if (MessageUtil.isNull(plannedEvent, PlannedEvent.PLANNED_TECH_TS_LATEST)) {
            plannedEvent.setPlannedTechTsLatest(
                    getTsLatest(plannedTechnicalTimestamp, techTolerance));
        }
        if (MessageUtil.isNull(plannedEvent, PlannedEvent.PLANNED_BIZ_TS_EARLIEST)) {
            plannedEvent.setPlannedBizTsEarliest(
                    getTsEarliest(plannedBusinessTimestamp, bizTolerance));
        }
        if (MessageUtil.isNull(plannedEvent, PlannedEvent.PLANNED_BIZ_TS_LATEST)) {
            plannedEvent.setPlannedBizTsLatest(
                    getTsLatest(plannedBusinessTimestamp, bizTolerance));
        }
    }

    private Instant getTsEarliest(Instant ts, Duration tolerance) {
        if (ts == null) {
            return Constant.MIN_TIMESTAMP;
        }
        if (tolerance == null) {
            return ts;
        }
        return ts.minus(tolerance.getSeconds(), ChronoUnit.SECONDS);
    }

    private Instant getTsLatest(Instant ts, Duration tolerance) {
        if (ts == null) {
            return Constant.MAX_TIMESTAMP;
        }
        if (tolerance == null) {
            return ts;
        }
        return ts.plus(tolerance.getSeconds(), ChronoUnit.SECONDS);
    }

    private void validateSenderPartyId(Event event, MultiExceptionContainer exceptionContainer) {
        if (!event.isValueProvided(Event.SUBACCOUNTID)) {
            event.setSubaccountId(UUID.fromString(currentContext.getSubaccountId()));
        }

        String senderPartyId = event.isValueProvided(Event.SENDER_PARTY_ID) ? event.getSenderPartyId() : null;
        boolean isUserToken = currentContext.isUserToken();
        if (StringUtils.isNotBlank(senderPartyId)) {
            if (isUserToken) {
                exceptionContainer.addException(new MessageValidationException(MESSAGE_CODE_SENDER_PARTY_ID_NOT_SUPPORT_IN_USER_TOKEN, null));
            }
            return;
        }
        try {
            event.setSenderPartyId(getCurrentLbnId());
        } catch (MessageValidationException e) {
            exceptionContainer.addException(e);
        }
    }

    private String getCurrentLbnId() {
        BusinessPartner businessPartner = currentContext.getBusinessPartner();
        if (businessPartner == null) {
            throw new MessageValidationException(MESSAGE_CODE_BP_NOT_EXISTED, null);
        }
        return businessPartner.getLbnId();
    }

    private void validateAltKey(String altKey, MultiExceptionContainer exceptionContainer) {
        try {
            GTTUtils.validateAltKey(altKey);
        } catch (MessageValidationException e) {
            exceptionContainer.addException(e);
        }
    }

    private boolean validateRequired(ObjectValue obj, String propertyName, MultiExceptionContainer exceptionContainer) {
        if (MessageUtil.isNull(obj, propertyName)) {
            exceptionContainer.addException(new MessageValidationException(MESSAGE_CODE_PROPERTY_IS_REQUIRED,
                    new Object[]{propertyName}));
            return false;
        }
        return true;
    }

    private void validateReferences(Event event, List<String> trackingIdTypes, MultiExceptionContainer exceptionContainer) {
        if (MessageUtil.isNull(event, Event.REFERENCES)) {
            return;
        }
        String eventAltKey = event.getAltKey();
        List<Reference> references = event.getReferences();
        List<String> allRefAltKeys = new ArrayList<>();
        references.forEach(r -> {
            String altKey = r.getAltKey();
            validateRequired(r, REFERENCE_TYPE, exceptionContainer);
            boolean hasValue = validateRequired(r, Reference.ALTKEY, exceptionContainer);
            if (hasValue) {
                allRefAltKeys.add(altKey);
                if (StringUtils.equals(eventAltKey, altKey)) {
                    exceptionContainer.addException(new MessageValidationException(MESSAGE_CODE_CYCLE_REFERENCE_NOT_ALLOWED,
                            new Object[]{altKey}));
                }
            }
            validateAltKey(altKey, exceptionContainer);
            validateTrackingIdType(altKey, trackingIdTypes, exceptionContainer);
            validateRequired(r, Reference.ACTION, exceptionContainer);
            Action action = Action.fromValue(r.getAction());
            if (Action.ADD.equals(action)) {
                isTimeEarlierOrEqualTo(r, Reference.VALID_FROM, Reference.VALID_TO, exceptionContainer);
            }
        });
        validateDuplicate(allRefAltKeys, MESSAGE_CODE_DUPLICATE_ALT_KEY, exceptionContainer);
    }

    private void validateDuplicate(List<? extends Object> list, String messageCode, MultiExceptionContainer exceptionContainer) {
        if (list == null || list.isEmpty()) {
            return;
        }
        List<? extends Object> duplicateElements = GTTUtils.getDuplicateElements(list);
        if (duplicateElements != null && !duplicateElements.isEmpty()) {
            exceptionContainer.addException(new MessageValidationException(messageCode, new Object[]{StringUtils.join(duplicateElements, MetadataConstants.COMMA)}));
        }
    }

    /**
     * Validate planned event.<br>
     * The time related fields should follow below logic:
     * <pre>
     * plannedBusinessTimestamp<=plannedTechnicalTimestamp
     * plannedBizTsEarliest<=plannedTechTsEarliest
     * plannedBizTsLatest<= plannedTechTsLatest
     * plannedBusinessTimestamp and plannedTechnicalTimestamp should meet earliest <= planned <= latest
     * If(planned business is null), always true
     * </pre>
     *
     * @param plannedEvent       planned event
     * @param isMatchLocation    match location flag
     * @param exceptionContainer exception container
     */
    private void validatePlannedEvent(PlannedEvent plannedEvent, boolean isMatchLocation, MultiExceptionContainer exceptionContainer) {
        if (plannedEvent != null) {
            if (!MessageUtil.isNull(plannedEvent, PLANNED_BUSINESS_TIMESTAMP)) {
                isTimeEarlierOrEqualTo(plannedEvent,
                        PLANNED_BUSINESS_TIMESTAMP,
                        PLANNED_TECHNICAL_TIMESTAMP,
                        exceptionContainer
                );
                isTimeEarlierOrEqualTo(plannedEvent,
                        PLANNED_BIZ_TS_EARLIEST,
                        PLANNED_TECH_TS_EARLIEST,
                        exceptionContainer
                );
                isTimeEarlierOrEqualTo(plannedEvent,
                        PLANNED_BIZ_TS_LATEST,
                        PLANNED_TECH_TS_LATEST,
                        exceptionContainer
                );
                //BizTimestamp and TechTimestamp in payload should meet earlist <= planned <= latest
                isTimeEarlierOrEqualTo(plannedEvent,
                        PLANNED_BIZ_TS_EARLIEST,
                        PLANNED_BUSINESS_TIMESTAMP,
                        exceptionContainer
                );
                isTimeEarlierOrEqualTo(plannedEvent,
                        PLANNED_BUSINESS_TIMESTAMP,
                        PLANNED_BIZ_TS_LATEST,
                        exceptionContainer
                );
                isTimeEarlierOrEqualTo(plannedEvent,
                        PLANNED_TECH_TS_EARLIEST,
                        PLANNED_TECHNICAL_TIMESTAMP,
                        exceptionContainer
                );
                isTimeEarlierOrEqualTo(plannedEvent,
                        PLANNED_TECHNICAL_TIMESTAMP,
                        PLANNED_TECH_TS_LATEST,
                        exceptionContainer
                );
            }

            if (isMatchLocation) {
                validateRequired(plannedEvent, LOCATION_ALTKEY, exceptionContainer);
            }
        }
    }

    private void isTimeEarlierOrEqualTo(ObjectValue obj, String earlyProperty, String lateProperty, MultiExceptionContainer exceptionContainer) {
        Instant timeEarly = MessageUtil.isNull(obj, earlyProperty) ? null : obj.getValueAsTimeStamp(earlyProperty);
        Instant timeLate = MessageUtil.isNull(obj, lateProperty) ? null : obj.getValueAsTimeStamp(lateProperty);
        if (timeEarly != null && timeEarly.compareTo(Objects.requireNonNull(timeLate)) > 0) {
            exceptionContainer.addException(new MessageValidationException(MESSAGE_CODE_TIME_SHOULD_EARLIER_OR_EQUAL,
                    new Object[]{timeEarly, earlyProperty, timeLate, lateProperty}));
        }
    }

    private void validateDuplicateKey(ObjectValue object, MultiExceptionContainer exceptionContainer) {
        CurrentMetadataEntity metadata = object.getMetadata();
        MetadataEntity currentEntity = metadata.getCurrentEntity();
        List<MetadataEntityElement> allCompositionFields = currentEntity.getElements().stream()
                .filter(e -> MetadataConstants.CdsDataType.CDS_COMPOSITION.equals(e.getType()))
                .collect(Collectors.toList());
        if (allCompositionFields.isEmpty()) {
            return;
        }
        for (MetadataEntityElement compField : allCompositionFields) {
            String compFieldName = compField.getName();
            if (!MessageUtil.isNull(object, compFieldName)) {
                List<IPropertyValue> items = object.getValueAsList(compFieldName);
                MetadataEntity targetEntity = metadata.getAllRelatedEntityMap().get(compField.getTarget());
                List<String> keyFields = targetEntity.getElements().stream().filter(MetadataEntityElement::isKey)
                        .map(MetadataEntityElement::getName).collect(Collectors.toList());
                List<IPropertyValue> keyVals = new ArrayList<>();
                setKeyValues(items, keyFields, keyVals);
                validateDuplicate(keyVals, MESSAGE_CODE_DUPLICATE_PRIMARY_KEY, exceptionContainer);
            }
        }
    }

    private void validateEventEnumValue(ObjectValue object, MultiExceptionContainer exceptionContainer) {
        CurrentMetadataEntity metadata = object.getMetadata();
        MetadataEntity currentEntity = metadata.getCurrentEntity();
        Map<String, MetadataEntity> relatedMetadataEntity = metadata.getAllRelatedEntityMap();
        Map<String, IPropertyValue> internalValue = object.getInternalValue();
        if (internalValue.isEmpty()) {
            return;
        }
        validateEnumValue(currentEntity, relatedMetadataEntity, internalValue, exceptionContainer);
    }

    private void validateEnumValue(MetadataEntity metadataEntity, Map<String, MetadataEntity> relatedMetadataEntity, Map<String, IPropertyValue> internalValue, MultiExceptionContainer exceptionContainer) {

        List<MetadataEntityElement> allFields = metadataEntity.getElements();
        if (allFields.isEmpty()) {
            return;
        }
        internalValue.entrySet().stream().forEach(ele -> {
            if (ele.getValue() instanceof ListValue) {
                String target = allFields.stream()
                        .filter(field -> ele.getKey().equals(field.getName())).findFirst().get().getTarget();
                MetadataEntity nestedMetadataEntity = relatedMetadataEntity.get(target);
                List<ObjectValue> nestedData = (List<ObjectValue>) ele.getValue().getInternalValue();
                nestedData.forEach(data -> validateEnumValue(nestedMetadataEntity, relatedMetadataEntity, data.getInternalValue(), exceptionContainer));
            } else {
                Optional<MetadataEntityElement> enumField = allFields.stream()
                        .filter(field -> ele.getKey().equals(field.getName()) && (field.getEnumVals() != null) && (!field.getEnumVals().isEmpty())).findFirst();
                if (!enumField.isPresent()) {
                    return;
                } else {
                    Map<String, String> enumVals = enumField.get().getEnumVals();
                    boolean isEnum = enumVals.entrySet().stream()
                            .anyMatch(val -> val.getValue().equals(ele.getValue().toString()));
                    if (isEnum) {
                        return;
                    } else {
                        exceptionContainer.addException(new MessageValidationException(MESSAGE_CODE_NOT_ENUM_VALUE, new Object[]{ele.getValue().toString(), enumVals.values().toString()}));
                    }
                }
            }
        });

    }

    private void setKeyValues(List<IPropertyValue> items, List<String> keyFields, List<IPropertyValue> keyVals) {
        for (IPropertyValue val : items) {
            ObjectValue ov = null;
            boolean setVal = false;
            for (String keyField : keyFields) {
                if (!MessageUtil.isNull(((ObjectValue) val), keyField)) {
                    if (ov == null) {
                        ov = ObjectValue.valueOfEmpty();
                    }
                    ov.setValue(keyField, ((ObjectValue) val).getValue(keyField));
                    setVal = true;
                }
            }
            if (setVal) {
                keyVals.add(ov);
            }
        }
    }

    private IMetadataManagement getMetadataManagement() {
        return currentContext.createBusinessOperator().getMetadataManagement();
    }

    private IMessageLogManagement getMessageLogManagement() {
        return currentContext.createBusinessOperator().getMessageLogManagement();
    }

    private ITrackedProcessManagement getProcessManagement() {
        return currentContext.createBusinessOperator().getTrackedProcessManagement();
    }
}
