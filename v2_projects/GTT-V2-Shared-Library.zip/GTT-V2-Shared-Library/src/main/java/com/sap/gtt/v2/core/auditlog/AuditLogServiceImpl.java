/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.gtt.v2.core.auditlog;

import com.sap.gtt.v2.configuration.ISAPCloudPlatformAgent;
import com.sap.gtt.v2.core.domain.auditlog.AuditDataAccessData;
import com.sap.gtt.v2.core.domain.auditlog.AuditDataModificationData;
import com.sap.gtt.v2.exception.AuditLogServiceException;
import com.sap.gtt.v2.exception.InternalErrorException;
import com.sap.gtt.v2.log.TenantAwareLogService;
import com.sap.xs.audit.api.exception.AuditLogException;
import com.sap.xs.audit.api.exception.AuditLogNotAvailableException;
import com.sap.xs.audit.api.exception.AuditLogWriteException;
import com.sap.xs.audit.api.v2.AuditLogMessageFactory;
import com.sap.xs.audit.api.v2.AuditedDataSubject;
import com.sap.xs.audit.api.v2.AuditedObject;
import com.sap.xs.audit.api.v2.DataAccessAuditMessage;
import com.sap.xs.audit.api.v2.DataModificationAuditMessage;
import com.sap.xs.audit.api.v2.SecurityEventAuditMessage;
import com.sap.xs.audit.client.impl.v2.AuditLogMessageFactoryImpl;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationCredentialsNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

/**
 *
 * @author I326335
 */
@Service
public class AuditLogServiceImpl implements AuditLogService {

    private static final Logger LOGGER = LoggerFactory.getLogger(AuditLogServiceImpl.class);

    public static final String GLOBAL_TRACK_TRACE = "Global Track & Trace";
    public static final String CORE_ENGINE = "Core Engine";

    public static final String AUDIT_NAME_KEY = "name";
    public static final String AUDIT_MODULE_KEY = "module";
    public static final String AUDIT_DATA_SUBJECT_ID = "dataSubjectId";

    @Autowired
    private ISAPCloudPlatformAgent.ICurrentAccessContext currentAccessContext;
    @Autowired
    private TenantAwareLogService tenantAwareLogService;

    @Override
    public void auditDataModification(String dataSubjectId, String type, String role, String channel, List<AuditDataModificationData> attributes) {
        AuditLogMessageFactory auditLogMessageFactory = createAuditLogMessageFactory();
        DataModificationAuditMessage message = auditLogMessageFactory.createDataModificationAuditMessage();
        AuditedObject object = auditLogMessageFactory.createAuditedObject();
        AuditedDataSubject subject = auditLogMessageFactory.createAuditedDataSubject();

        try {
            object.setType(GLOBAL_TRACK_TRACE);
            object.addIdentifier(AUDIT_NAME_KEY, CORE_ENGINE);
            object.addIdentifier(AUDIT_MODULE_KEY, channel);

            subject.setType(type);
            subject.setRole(role);
            subject.addIdentifier(AUDIT_DATA_SUBJECT_ID, dataSubjectId);

            message.setObject(object);
            message.setDataSubject(subject);

            message.setUser(getLogonName());
            message.setTenant(currentAccessContext.getSubaccountId());
            attributes.stream().forEach(attr -> message.addAttribute(attr.getField(), attr.getOldValue(), attr.getNewValue()));

            message.logSuccess();
        } catch (AuditLogNotAvailableException | AuditLogWriteException e) {
            processException(e, true);
        }
    }

    @Override
    public void auditDataAccess(String dataSubjectId, String type, String role, String channel, List<AuditDataAccessData> attributes) {
        AuditLogMessageFactory auditLogMessageFactory = createAuditLogMessageFactory();
        DataAccessAuditMessage message = auditLogMessageFactory.createDataAccessAuditMessage();
        AuditedObject object = auditLogMessageFactory.createAuditedObject();
        AuditedDataSubject subject = auditLogMessageFactory.createAuditedDataSubject();

        try {
            object.setType(GLOBAL_TRACK_TRACE);
            object.addIdentifier(AUDIT_NAME_KEY, CORE_ENGINE);
            object.addIdentifier(AUDIT_MODULE_KEY, channel);

            subject.setType(type);
            subject.setRole(role);
            subject.addIdentifier(AUDIT_DATA_SUBJECT_ID, dataSubjectId);

            message.setObject(object);
            message.setDataSubject(subject);

            message.setUser(getLogonName());
            message.setTenant(currentAccessContext.getSubaccountId());
            message.setChannel(channel);

            attributes.stream().forEach(attr -> message.addAttribute(attr.getField(), attr.getAccessed()));

            message.log();

        } catch (AuditLogNotAvailableException | AuditLogWriteException e) {
            processException(e, true);
        }
    }

    @Override
    public void auditSecurityEvent(String ip, String description) {
        AuditLogMessageFactory auditLogMessageFactory = createAuditLogMessageFactory();
        SecurityEventAuditMessage message = auditLogMessageFactory.createSecurityEventAuditMessage();
        try {
            String user = getLogonNameWithoutException();
            String tenant = getSubaccountIdWithoutException();
            if (!StringUtils.isEmpty(tenant)) {
                message.setUser(StringUtils.isEmpty(user) ? tenant : user);
                message.setTenant(tenant);
                message.setIp(ip);
                message.setData(description);

                message.log();
            }
        } catch (AuditLogNotAvailableException | AuditLogWriteException e) {
            processException(e, false);
        }

    }

    private String getLogonName() {
        return StringUtils.isEmpty(currentAccessContext.getLogonName()) ? currentAccessContext.getSubdomain(): currentAccessContext.getLogonName();
    }
    
    private String getLogonNameWithoutException() {
        try {
            return getLogonName();
        } catch (AuthenticationCredentialsNotFoundException | InternalErrorException e) {
            LOGGER.warn("Can not get logonName. {}", e.getMessage());
        }
        return null;
    }
    
    private String getSubaccountIdWithoutException() {
        try {
            return currentAccessContext.getSubaccountId();
        } catch (AuthenticationCredentialsNotFoundException | InternalErrorException e) {
            LOGGER.warn("Can not get subaccountId. {}", e.getMessage());
        }
        return null;
    }

    private void processException(AuditLogException e, boolean authorizaed) throws AuditLogServiceException {
        if (authorizaed && e instanceof AuditLogWriteException) {
            tenantAwareLogService.error("Validation failure. {}", ((AuditLogWriteException) e).getErrors());
        } else if (e instanceof AuditLogWriteException) {
            LOGGER.error("Validation failure. {}", ((AuditLogWriteException) e).getErrors());
        }
        throw new AuditLogServiceException(e.getLocalizedMessage(), e);
    }

    private AuditLogMessageFactory createAuditLogMessageFactory() {
        // the xs audit log framework
        try {
            //currentAccessContext.initUserInfoHolder();
            return new AuditLogMessageFactoryImpl();
        } catch (AuditLogException e) {
            throw new AuditLogServiceException(e.getLocalizedMessage(), e);
        }
    }
}
