package com.sap.gtt.v2.core.domain.execution;

import java.time.Instant;

/**
 * @author I302310
 */
public class ExecutionDto {
    private String executionHistoryId;
    private String requestId;
    private String eventId;
    private String eventType;
    private String altkey;
    private String locationAltkey;
    private String correlatedTpId;
    private String correlatedTpAltkey;
    private Instant executionAt;
    private String lastPhase;
    private boolean isProcessEvent;

    public String getExecutionHistoryId() {
        return executionHistoryId;
    }

    public void setExecutionHistoryId(String executionHistoryId) {
        this.executionHistoryId = executionHistoryId;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public String getEventId() {
        return eventId;
    }

    public void setEventId(String eventId) {
        this.eventId = eventId;
    }

    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    public String getAltkey() {
        return altkey;
    }

    public void setAltkey(String altkey) {
        this.altkey = altkey;
    }

    public String getLocationAltkey() {
        return locationAltkey;
    }

    public void setLocationAltkey(String locationAltkey) {
        this.locationAltkey = locationAltkey;
    }

    public String getCorrelatedTpId() {
        return correlatedTpId;
    }

    public void setCorrelatedTpId(String correlatedTpId) {
        this.correlatedTpId = correlatedTpId;
    }

    public String getCorrelatedTpAltkey() {
        return correlatedTpAltkey;
    }

    public void setCorrelatedTpAltkey(String correlatedTpAltkey) {
        this.correlatedTpAltkey = correlatedTpAltkey;
    }

    public Instant getExecutionAt() {
        return executionAt;
    }

    public void setExecutionAt(Instant executionAt) {
        this.executionAt = executionAt;
    }

    public String getLastPhase() {
        return lastPhase;
    }

    public void setLastPhase(String lastPhase) {
        this.lastPhase = lastPhase;
    }

    public boolean isProcessEvent() {
        return isProcessEvent;
    }

    public void setProcessEvent(boolean processEvent) {
        isProcessEvent = processEvent;
    }
}
