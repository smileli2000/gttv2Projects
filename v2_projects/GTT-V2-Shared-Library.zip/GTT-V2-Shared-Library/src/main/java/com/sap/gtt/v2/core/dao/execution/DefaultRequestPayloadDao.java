package com.sap.gtt.v2.core.dao.execution;

import com.sap.gtt.v2.core.entity.execution.RequestPayload;
import com.sap.gtt.v2.exception.DBException;
import com.sap.gtt.v2.util.DBUtils;
import com.sap.gtt.v2.util.SpringContextUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

/**
 * @author I302310
 */
@Repository(DefaultRequestPayloadDao.BEAN_NAME)
public class DefaultRequestPayloadDao implements IRequestPayloadDao {
    public static final String BEAN_NAME = "com.sap.gtt.v2.core.dao.execution.DefaultRequestPayloadDao";
    public static final String TABLE_NAME = "REQUEST_PAYLOAD";

    public static final String ID = "ID";
    public static final String PARENT_ID = "PARENT_ID";
    public static final String MESSAGE_NUMBER = "MESSAGE_NUMBER";
    public static final String SOURCE_ID = "SOURCE_ID";
    public static final String SOURCE = "SOURCE";
    public static final String REQUEST_DATE_TIME = "REQUEST_DATE_TIME";
    public static final String WRITE_SERVICE_PATH = "WRITE_SERVICE_PATH";
    public static final String PAYLOAD = "PAYLOAD";
    public static final String STATUS = "STATUS";
    public static final String SUBACCOUNTID = "SUBACCOUNTID";
    public static final String CLONEINSTANCEID = "CLONEINSTANCEID";

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public static DefaultRequestPayloadDao getInstance() {
        return (DefaultRequestPayloadDao) SpringContextUtils.getBean(BEAN_NAME);
    }

    @Override
    public void insertRequestPayload(RequestPayload requestPayload) {
        StringBuilder sql = new StringBuilder();
        String[] columns = {ID, PARENT_ID, MESSAGE_NUMBER, SOURCE_ID, SOURCE, REQUEST_DATE_TIME,
                WRITE_SERVICE_PATH, PAYLOAD, STATUS, CLONEINSTANCEID, SUBACCOUNTID};
        DBUtils.buildInsertSql(TABLE_NAME, columns, sql);
        Object[] args = new Object[]{requestPayload.getId(), requestPayload.getParentId(), requestPayload.getMessageNumber(),
                requestPayload.getSourceId(), requestPayload.getSource(), requestPayload.getRequestDataTime(),
                requestPayload.getWriteServicePath(), requestPayload.getPayload(), requestPayload.getStatus(),
                requestPayload.getCloneInstanceId(), requestPayload.getSubaccountId()};
        int affectedRows = jdbcTemplate.update(sql.toString(), args);
        if (affectedRows <= 0) {
            throw new DBException("Insert RequestPayload data failed. Affected rows " + affectedRows);
        }
    }

    @Override
    public void updateStatus(String requestId, String status) {
        StringBuilder sql = new StringBuilder();
        String[] updatedColumns = {STATUS};
        Object[] updateValues = new Object[]{status};

        String[] whereColumns = {ID};
        Object[] whereValues = new Object[]{requestId};

        List<Object> updateParam = new ArrayList<>();

        DBUtils.buildUpdateSql(TABLE_NAME, updatedColumns, updateValues, whereColumns, whereValues, sql, updateParam);
        Object[] args = updateParam.toArray();
        jdbcTemplate.update(sql.toString(), args);
    }

    @Override
    public RequestPayload query(String requestId) {
        List<String> args = new ArrayList<>();
        args.add(requestId);
        StringBuilder sql = new StringBuilder();
        sql.append("select * from ").append(TABLE_NAME)
                .append(" where ")
                .append(ID).append("=?");
        List<RequestPayload> rst = jdbcTemplate.query(sql.toString(), args.toArray(), (rs, rowNum) -> {
            String rs_id = rs.getString(ID);
            String rs_parentId = rs.getString(PARENT_ID);
            String rs_messageNumber = rs.getString(MESSAGE_NUMBER);
            String rs_sourceId = rs.getString(SOURCE_ID);
            String rs_source = rs.getString(SOURCE);
            Instant rs_requestDateTime = rs.getTimestamp(REQUEST_DATE_TIME).toInstant();
            String rs_writeServicePath = rs.getString(WRITE_SERVICE_PATH);
            String rs_payload = rs.getString(PAYLOAD);
            String rs_status = rs.getString(STATUS);
            String rs_cloneInstanceId = rs.getString(CLONEINSTANCEID);
            String rs_subaccountId = rs.getString(SUBACCOUNTID);
            return new RequestPayload(rs_id, rs_parentId, rs_messageNumber, rs_sourceId, rs_source, rs_requestDateTime,
                    rs_writeServicePath, rs_payload, rs_status, rs_cloneInstanceId, rs_subaccountId);
        });
        return rst.isEmpty() ? null : rst.get(0);
    }
}
