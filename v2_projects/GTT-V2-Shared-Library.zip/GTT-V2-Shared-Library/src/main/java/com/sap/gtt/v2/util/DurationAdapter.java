package com.sap.gtt.v2.util;

import com.google.gson.TypeAdapter;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import com.sap.gtt.v2.exception.JsonParseException;
import org.apache.commons.lang3.StringUtils;

import java.io.IOException;
import java.time.Duration;
import java.time.format.DateTimeParseException;

import static com.sap.gtt.v2.exception.JsonParseException.MESSAGE_CODE_ERROR_DURATION_PARSE;

/**
 * Type adapter for String and duration conversion
 *
 * @author I301346
 */
public class DurationAdapter extends TypeAdapter<Duration> {

    @Override
    public void write(JsonWriter out, Duration value) throws IOException {
        if (value.equals(Duration.ZERO)) {
            out.nullValue();
        } else {
            out.value(value.toString());
        }
    }

    @Override
    public Duration read(JsonReader in) throws IOException {
        if (in.peek() == null) {
            return Duration.ZERO;
        }
        String s = in.nextString();
        if (StringUtils.isBlank(s)) {
            return Duration.ZERO;
        }

        try {
            return Duration.parse(s);
        } catch (DateTimeParseException e) {
            //currently path is $.xxxxxx, so do substring
            String path = in.getPath().substring(2);
            throw new JsonParseException(MESSAGE_CODE_ERROR_DURATION_PARSE, new Object[]{s, path});
        }
    }
}