package com.sap.gtt.v2.configuration;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.sql.DataSource;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.datasource.init.DataSourceInitializer;
import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;
import org.springframework.security.oauth2.provider.token.ResourceServerTokenServices;
import org.springframework.web.client.HttpClientErrorException.NotFound;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.annotations.SerializedName;
import com.sap.gtt.v2.configuration.ISAPCloudPlatformAgent.ICurrentAccessContext;
import com.sap.gtt.v2.log.TenantAwareLogService;
import com.sap.gtt.v2.util.JsonUtils;
import com.sap.gtt.v2.util.SpringContextUtils;
import com.sap.gtt.v2.util.UaaUtils;
import com.sap.gtt.v2.util.UaaUtils.CloneInstanceDetail;
import com.sap.xs2.security.commons.SAPOfflineTokenServicesCloud;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

@Configuration
public class EnvironmentsConfiguration {
	protected static final String SERVICE_MANAGER_DB_INSTANCE_NAME = "lbn-gtt-core-service-manager-db";
	private static final Logger logger = LoggerFactory.getLogger(EnvironmentsConfiguration.class);
	
    public static class VcapServiceParser {
        
        public enum ServiceCategory {
            hana("hana"), h2("h2"), destination("destination"), xsuaa("xsuaa"),
            saasregistry("saas-registry"), saassubscription("saas-subscription"), managedhana("managed-hana"), bp("lbnplatform-bprepo-servicebroker-LBN")
            ,portal("portal"), reminder("lbn-reminderservice-servicebroker-LBN"),location("lbn-location-md-sbf-LBN");

            private ServiceCategory(String categoryName) {
                this.categoryName = categoryName;
            }

            public String getCategoryName() {
                return categoryName;
            }

            private final String categoryName;
        }

        public abstract static class BaseServiceInstance implements Serializable {
            /**
             *
             */
            private static final long serialVersionUID = 5580371447805067755L;

            private String instanceName;
            private String label;
            private String planName;
            private String serviceName;
            private List<String> tags = new ArrayList<>();

            public BaseServiceInstance(JsonObject serivceInstanceJsonObject) {

                this.label = JsonUtils.getValueAsString(serivceInstanceJsonObject, "label");
                this.planName = JsonUtils.getValueAsString(serivceInstanceJsonObject, "plan");
                this.serviceName = JsonUtils.getValueAsString(serivceInstanceJsonObject, "name");

                JsonArray tasgsJsonArray = JsonUtils.getValueAsJsonArray(serivceInstanceJsonObject, "tags");
                if (tasgsJsonArray != null) {
                    tags = JsonUtils.getElements(tasgsJsonArray, String.class);
                }
                this.instanceName = JsonUtils.getValueAsString(serivceInstanceJsonObject, "instance_name");
            }

            public String getInstanceName() {
                return instanceName;
            }

            public String getLabel() {
                return label;
            }

            public String getPlanName() {
                return planName;
            }

            public String getServiceName() {
                return serviceName;
            }

            public List<String> getTags() {
                return Collections.unmodifiableList(tags);
            }

            public abstract ServiceCategory getServiceCategory();

        }


        public abstract static class ClientSecretBasedServiceInstance extends BaseServiceInstance {
            /**
             *
             */
            private static final long serialVersionUID = 5670151403950254157L;
            private String clientId;
            private String clientSecret;
            private String url;
            private String identityZone;
            private String xsappname;

            public ClientSecretBasedServiceInstance(JsonObject serivceInstanceJsonObject) {
                super(serivceInstanceJsonObject);

                this.clientId = this.getClientId(serivceInstanceJsonObject);
                this.clientSecret = this.getClientSecret(serivceInstanceJsonObject);
                this.url = this.getUrl(serivceInstanceJsonObject);
                this.identityZone = this.getIdentityZone(serivceInstanceJsonObject);
                this.xsappname = this.getXsappname(serivceInstanceJsonObject);
            }
            
            protected String getClientId(JsonObject serivceInstanceJsonObject){
            	return JsonUtils.getByPath("/credentials/clientid", serivceInstanceJsonObject).getAsString();
            }
            
            protected String getClientSecret(JsonObject serivceInstanceJsonObject){
            	return JsonUtils.getByPath("/credentials/clientsecret", serivceInstanceJsonObject).getAsString();
            }

            protected String getUrl(JsonObject serivceInstanceJsonObject){
            	return JsonUtils.getByPath("/credentials/url", serivceInstanceJsonObject).getAsString();
            }
            
            protected String getIdentityZone(JsonObject serivceInstanceJsonObject){
            	return JsonUtils.getByPath("/credentials/identityzone", serivceInstanceJsonObject).getAsString();
            }
            
            protected String getXsappname(JsonObject serivceInstanceJsonObject){
            	return JsonUtils.getByPath("/credentials/xsappname", serivceInstanceJsonObject).getAsString();
            }
            
            public String getClientId() {
                return clientId;
            }

            public String getClientSecret() {
                return clientSecret;
            }

            public String getUrl() {
                return url;
            }

            public String getIdentityZone() {
                return identityZone;
            }

            public String getXsappname() {
                return xsappname;
            }

            public String requestTechniqueToken(){
            	 return UaaUtils.requestTechniqueToken(this.getUrl(), this.getClientId(), this.getClientSecret());
            }

            public String requestTechniqueToken(String subdomain){
                return UaaUtils.requestTechniqueToken(this.getUrl(), subdomain, this.getClientId(), this.getClientSecret());
            }
        }

        public abstract static class UaaBasedClientSecretBasedServiceInstance extends ClientSecretBasedServiceInstance {

			/**
			 * 
			 */
			private static final long serialVersionUID = -5902881117836970628L;
			public UaaBasedClientSecretBasedServiceInstance(JsonObject serivceInstanceJsonObject) {
				super(serivceInstanceJsonObject);
			}

			@Override
			protected String getClientId(JsonObject serivceInstanceJsonObject){
            	return JsonUtils.getByPath("/credentials/uaa/clientid", serivceInstanceJsonObject).getAsString();
            }
			@Override
            protected String getClientSecret(JsonObject serivceInstanceJsonObject){
            	return JsonUtils.getByPath("/credentials/uaa/clientsecret", serivceInstanceJsonObject).getAsString();
            }
			@Override
            protected String getUrl(JsonObject serivceInstanceJsonObject){
            	return JsonUtils.getByPath("/credentials/uaa/url", serivceInstanceJsonObject).getAsString();
            }
			@Override
            protected String getIdentityZone(JsonObject serivceInstanceJsonObject){
            	return JsonUtils.getByPath("/credentials/uaa/identityzone", serivceInstanceJsonObject).getAsString();
            }
			@Override
            protected String getXsappname(JsonObject serivceInstanceJsonObject){
            	return JsonUtils.getByPath("/credentials/uaa/xsappname", serivceInstanceJsonObject).getAsString();
            }
        	
        }

        public abstract static class DatabaseServiceInstance extends BaseServiceInstance {
            /**
             *
             */
            private static final long serialVersionUID = -5958463721114108440L;

            public DatabaseServiceInstance(JsonObject serivceInstanceJsonObject) {
                super(serivceInstanceJsonObject);
            }

            public enum DatabaseType {
                hana, h2, cosmosdb
            }

            public abstract DatabaseType getDatabaseType();

            public abstract void init();

            public abstract void empty();

            public abstract void upgrade(String procedureName);


        }

        public static class ManagedHanaServiceInstance extends BaseServiceInstance{

        	/**
			 * 
			 */
			private static final long serialVersionUID = -5464180968002899377L;
			protected String user;
            protected String password;
            protected String postManagedInstancUrl;
            protected String deleteManagedInstanceUrl;
            protected String getManagedInstanceUrl;
            
            public static class ManagedHanaTenant{
            	@SerializedName("tenant_id")
            	private String tenantId;

				public String getTenantId() {
					return tenantId;
				}

				public void setTenantId(String tenantId) {
					this.tenantId = tenantId;
				}

				@Override
				public String toString() {
					return "ManagedHanaTenant [tenantId=" + tenantId + "]";
				}
            	
            	
            }
			public ManagedHanaServiceInstance(JsonObject serivceInstanceJsonObject) {
				super(serivceInstanceJsonObject);
				this.user = JsonUtils.getByPath("/credentials/user", serivceInstanceJsonObject).getAsString();
                this.password = JsonUtils.getByPath("/credentials/password", serivceInstanceJsonObject).getAsString();
                this.postManagedInstancUrl = JsonUtils.getByPath("/credentials/post_managed_instance_url", serivceInstanceJsonObject).getAsString();
                this.deleteManagedInstanceUrl = JsonUtils.getByPath("/credentials/delete_managed_instance_url", serivceInstanceJsonObject).getAsString();
                this.getManagedInstanceUrl = JsonUtils.getByPath("/credentials/get_managed_instance_url", serivceInstanceJsonObject).getAsString();

			}

			@Override
			public ServiceCategory getServiceCategory() {
				return ServiceCategory.managedhana;
			}
			
			protected static String parseUrl(String templateUrl, String tenantId){
				String url = StringUtils.replace(templateUrl,"{tenant_id}",tenantId);
				return url;
			}
			protected HttpHeaders createHttpHeaders(){
				HttpHeaders headers = new HttpHeaders();
				headers.setBasicAuth(this.getUser(), this.getPassword());
				return headers;
			}
			
			public HanaSchemaHDIContainerServiceInstance getDatabaseServiceInstance(String tenantId){
				GTTRestTemplate restTemplate = SpringContextUtils.getBean(GTTRestTemplate.class);
				String url = parseUrl(this.getGetManagedInstanceUrl(), tenantId);
				
				final int MAX_RETRY_COUNT = 30;
				int remainCount = MAX_RETRY_COUNT;
				String status = null;
				JsonObject managedHanaSchemaCreationJsonObject = null;
				do{
					if(remainCount != MAX_RETRY_COUNT){
						try {
							Thread.sleep(1000);
						} catch (InterruptedException e) {
							Thread.currentThread().interrupt();
							throw new InternalError(e);
						}
					}
					remainCount--;
					ResponseEntity<String> responseEntity = restTemplate.exchange(url, HttpMethod.GET, createHttpHeaders(), null, String.class);
				
					String jsonString = responseEntity.getBody();
					managedHanaSchemaCreationJsonObject = JsonUtils.generateJsonObjectFromJsonString(jsonString);
					status = JsonUtils.getValueAsString(managedHanaSchemaCreationJsonObject, "status");
					
					
				}
				while(StringUtils.equals(status, "CREATION_IN_PROGRESS")
						&&
						remainCount > 0);
				
				if(StringUtils.equals(status, "CREATION_SUCCEEDED")){
					HanaSchemaHDIContainerServiceInstance result = new HanaSchemaHDIContainerServiceInstance(managedHanaSchemaCreationJsonObject);
					result.initDataSource();
					return result;
				}
				else{
					throw new InternalError(String.format("Status '%s' for Managed Hana TenantId '%s'", status, tenantId));
				}
				
			}
			
			public void provision(String tenantId, String databaseId){
				GTTRestTemplate restTemplate = SpringContextUtils.getBean(GTTRestTemplate.class);
				String url = parseUrl(this.getPostManagedInstancUrl(), tenantId);
				JsonObject jsonObject = JsonUtils.generateJsonObjectFromJsonString("{}");
				JsonObject jsonObjectProvisionParams = JsonUtils.generateJsonObjectFromJsonString("{}");
				jsonObjectProvisionParams.addProperty("database_id", databaseId);
				jsonObject.add("provisioning_parameters", jsonObjectProvisionParams);
				
				
				String payload = JsonUtils.generateJsonStringFromJsonElement(jsonObject);
				restTemplate.exchange(url, HttpMethod.POST, createHttpHeaders(), payload, String.class);
			}

			public void deprovision(String tenantId){
				GTTRestTemplate restTemplate = SpringContextUtils.getBean(GTTRestTemplate.class);
				String url = parseUrl(this.getDeleteManagedInstanceUrl(), tenantId);
				restTemplate.exchange(url, HttpMethod.DELETE, createHttpHeaders(), null, String.class);
			}
			
			public ManagedHanaTenant getManagedHanaTenant(String tenantId){
				GTTRestTemplate restTemplate = SpringContextUtils.getBean(GTTRestTemplate.class);
				String url = parseUrl(this.getGetManagedInstanceUrl(), tenantId);
				try{
					 ResponseEntity<ManagedHanaTenant> response =  restTemplate.exchange(url, HttpMethod.GET, createHttpHeaders(), null, ManagedHanaTenant.class);
					 ManagedHanaTenant result = response.getBody();
					 return result;
				}
				catch(NotFound e){
					logger.debug(e.getMessage(), e);
					return null;
				}
			}
			
			public String getUser() {
				return user;
			}

			public String getPassword() {
				return password;
			}

			public String getPostManagedInstancUrl() {
				return postManagedInstancUrl;
			}

			public String getDeleteManagedInstanceUrl() {
				return deleteManagedInstanceUrl;
			}

			public String getGetManagedInstanceUrl() {
				return getManagedInstanceUrl;
			}
        	
        }
        
        public abstract static class JdbcEnabledDatabaseServiceInstance extends DatabaseServiceInstance {

            /**
             *
             */
            private static final long serialVersionUID = -3355678814437450442L;
            protected transient DataSource dataSource;
            protected String connectionUrl;
            protected String user;
            protected String password;
            protected String driver;

            public JdbcEnabledDatabaseServiceInstance(JsonObject serivceInstanceJsonObject) {
                super(serivceInstanceJsonObject);
            }

            public String getDriver() {
                return this.driver;
            }

            public String getConnectionUrl() {
                return this.connectionUrl;
            }

            public String getUser() {
                return this.user;
            }

            public String getPassword() {
                return this.password;
            }

            public DataSource getDataSource() {
                return dataSource;
            }

            protected HikariConfig createJdbcConfig() {
                HikariConfig jdbcConfig = new HikariConfig();
                jdbcConfig.setAutoCommit(true);
                jdbcConfig.setDriverClassName(getDriver());
                jdbcConfig.setJdbcUrl(getConnectionUrl());
                jdbcConfig.setUsername(getUser());
                jdbcConfig.setPassword(getPassword());

                jdbcConfig.setMaximumPoolSize(30);
                //jdbcConfig.setConnectionTimeout(SECONDS.toMillis(30)); // 30 seconds - default
                //jdbcConfig.setInitializationFailTimeout(SECONDS.toMillis(5)); // 5 seconds for pool start
                //jdbcConfig.setValidationTimeout(SECONDS.toMillis(5)); // 5 seconds for each new connection initialize - default

                return jdbcConfig;
            }

            protected void initDataSource() {
                this.dataSource = this.createDataSource();
            }

            protected DataSource createDataSource() {

                return new HikariDataSource(this.createJdbcConfig());

            }

            @Override
            public void init() {
            	if(StringUtils.equals(SERVICE_MANAGER_DB_INSTANCE_NAME, this.getInstanceName())){
            		this.operateOnDatabaseServiceInstance("service-manager-init");
            	}
            	else{
            		this.operateOnDatabaseServiceInstance("init");
            	}
                
            }

            @Override
            public void empty() {
                this.operateOnDatabaseServiceInstance("empty");
            }

            @Override
            public void upgrade(String procedureName) {
                this.operateOnDatabaseServiceInstance(procedureName);
            }

            protected void operateOnDatabaseServiceInstance(String command) {
                DataSource ds = getDataSource();
                String resourceName = "storage-" + command + "-" + this.getDatabaseType().name() + ".sql";
                ClassPathResource resource = new ClassPathResource(resourceName);
                DataSourceInitializer initializer = new DataSourceInitializer();
                initializer.setDataSource(ds);
                ResourceDatabasePopulator populator = new ResourceDatabasePopulator(false, true, null, resource);
                populator.setSeparator("$$");
                initializer.setDatabasePopulator(populator);
                initializer.setEnabled(true);
                initializer.afterPropertiesSet();
            }

        }

        public static class HanaSchemaHDIContainerServiceInstance extends JdbcEnabledDatabaseServiceInstance {

            /**
             *
             */
            private static final long serialVersionUID = 1361242823644251703L;

            public HanaSchemaHDIContainerServiceInstance(JsonObject serivceInstanceJsonObject) {
                super(serivceInstanceJsonObject);
                this.connectionUrl = JsonUtils.getByPath("/credentials/url", serivceInstanceJsonObject).getAsString();
                this.user = JsonUtils.getByPath("/credentials/user", serivceInstanceJsonObject).getAsString();
                this.password = JsonUtils.getByPath("/credentials/password", serivceInstanceJsonObject).getAsString();
                this.driver = JsonUtils.getByPath("/credentials/driver", serivceInstanceJsonObject).getAsString();

            }

            @Override
            public ServiceCategory getServiceCategory() {
                return ServiceCategory.hana;
            }

            @Override
            public DatabaseType getDatabaseType() {

                return DatabaseType.hana;
            }
        }

        public static class H2SchemaServiceInstance extends HanaSchemaHDIContainerServiceInstance {

            /**
             *
             */
            private static final long serialVersionUID = 5546160865001689780L;

            public H2SchemaServiceInstance(JsonObject serivceInstanceJsonObject) {
                super(serivceInstanceJsonObject);
            }

            @Override
            public ServiceCategory getServiceCategory() {
                return ServiceCategory.h2;
            }

            @Override
            public DatabaseType getDatabaseType() {

                return DatabaseType.h2;
            }
        }

        public static class UaaServiceInstance extends ClientSecretBasedServiceInstance {

            public enum Plan {
                broker
            }

            /**
             *
             */
            private static final long serialVersionUID = -8561585114262408957L;

            private String identityZoneId;

            public UaaServiceInstance(JsonObject serivceInstanceJsonObject) {
                super(serivceInstanceJsonObject);
                this.identityZoneId = JsonUtils.getByPath("/credentials/identityzoneid", serivceInstanceJsonObject).getAsString();

            }

            @Override
            public ServiceCategory getServiceCategory() {
                return ServiceCategory.xsuaa;
            }

            public String getIdentityZoneId() {
                return identityZoneId;
            }

            public CloneInstanceDetail getCloneInstanceDetail(String cloneInstanceId) {
                return UaaUtils.getCloneInstanceDetail(cloneInstanceId, this.getUrl(), this.getClientId(), this.getClientSecret());
            }

            public String requestTechniqueToken(String subdomain) {
                return UaaUtils.requestTechniqueToken(this.getUrl(), subdomain, this.getClientId(), this.getClientSecret());
            }

            @Override
            public String requestTechniqueToken() {
                return UaaUtils.requestTechniqueToken(this.getUrl(), this.getClientId(), this.getClientSecret());
            }
        }

        // Destination Service
        public static class DestinationServiceInstance extends ClientSecretBasedServiceInstance {
            public static final String DESTINATION_NOT_FOUND = "Destination not found";

            private static final String SUBACCOUNT_DEST_PATH = "/destination-configuration/v1/subaccountDestinations/";
            /**
             *
             */
            private static final long serialVersionUID = 5034673482189487825L;
            private String uri;

            public DestinationServiceInstance(JsonObject serivceInstanceJsonObject) {
                super(serivceInstanceJsonObject);
                this.uri = JsonUtils.getByPath("/credentials/uri", serivceInstanceJsonObject).getAsString();
            }

            @Override
            public ServiceCategory getServiceCategory() {
                return ServiceCategory.destination;
            }

            public String getUri() {
                return uri;
            }

            public static class Destination {

                public enum Type {
                    HTTP;
                }

                public enum Authentication {
                    NoAuthentication,
                    BasicAuthentication,
                    OAuth2ClientCredentials,
                    PrincipalPropagation;
                }

                public enum ProxyType {
                    OnPremise,
                    Internet
                }

                @SerializedName(value = "Name")
                private String name;
                @SerializedName(value = "Description")
                private String description;
                @SerializedName(value = "Type")
                private String type;
                @SerializedName(value = "URL")
                private String url;
                @SerializedName(value = "CloudConnectorLocationId")
                private String cloudConnectorLocationId;
                @SerializedName(value = "Authentication")
                private String authentication;
                @SerializedName(value = "ProxyType")
                private String proxyType;
                @SerializedName(value = "User")
                private String user;
                @SerializedName(value = "Password")
                private String password;

                private String clientId;
                private String tokenServiceUser;
                private String tokenServiceURL;
                private String clientSecret;
                private String tokenServicePassword;


                public String getName() {
                    return name;
                }

                public String getClientId() {
                    return clientId;
                }

                public String getTokenServiceUser() {
                    return tokenServiceUser;
                }

                public String getTokenServiceURL() {
                    return tokenServiceURL;
                }

                public String getClientSecret() {
                    return clientSecret;
                }

                public String getTokenServicePassword() {
                    return tokenServicePassword;
                }

                public String getDescription() {
                    return description;
                }

                public String getType() {
                    return type;
                }

                public String getUrl() {
                    return url;
                }

                public String getCloudConnectorLocationId() {
                    return cloudConnectorLocationId;
                }

                public String getAuthentication() {
                    return authentication;
                }

                public String getProxyType() {
                    return proxyType;
                }

                public String getUser() {
                    return user;
                }

                public String getPassword() {
                    return password;
                }

                public static Destination fromJson(String jsonString) {
                    return JsonUtils.generateBeanFromJson(jsonString, Destination.class);
                }

            }

            public Destination readFromSaasSubaccount(String subdomain, String destinationName) {

                TenantAwareLogService logService = SpringContextUtils.getBean(TenantAwareLogService.class);
                logService.info("Searching destination '" + destinationName + "' under subdomain: " + subdomain);

                String jwt = UaaUtils.requestTechniqueToken(this.getUrl(), subdomain, this.getClientId(), this.getClientSecret());
                // destination service uri
                String destinationServiceUri = this.getUri() + SUBACCOUNT_DEST_PATH + destinationName;
                GTTRestTemplate restTemplate = SpringContextUtils.getBean(GTTRestTemplate.class);
                HttpHeaders headers = new HttpHeaders();
                headers.setBearerAuth(jwt);
                ResponseEntity<String> response = restTemplate.exchange(destinationServiceUri, HttpMethod.GET, headers, null, String.class);
                return Destination.fromJson(response.getBody());

            }

            public Destination readFromPaasSubaccountByCloneInstanceId(UaaServiceInstance masterUaaInstance, String cloneInstanceId, String destinationName) {
                CloneInstanceDetail cloneInstanceDetail = masterUaaInstance.getCloneInstanceDetail(cloneInstanceId);
                String subdmainInPaas = cloneInstanceDetail.getIdentityzone();

                return readFromSaasSubaccount(subdmainInPaas, destinationName);

            }

        }

        // Portal Service
        public static class PortalServiceInstance extends UaaBasedClientSecretBasedServiceInstance{

			/**
			 * 
			 */
			private static final long serialVersionUID = -6080762545234159050L;

			public PortalServiceInstance(JsonObject serivceInstanceJsonObject) {
				super(serivceInstanceJsonObject);
			}

			@Override
			public ServiceCategory getServiceCategory() {
				return ServiceCategory.portal;
			}
			
        	
        }
        //BP Service
        public static class BpServiceInstance extends UaaBasedClientSecretBasedServiceInstance{
        	/**
			 * 
			 */
			private static final long serialVersionUID = -2634461111401097858L;
			private String endpoint;
        	
        	public BpServiceInstance(JsonObject serivceInstanceJsonObject) {
                super(serivceInstanceJsonObject);
                this.endpoint = JsonUtils.getByPath("/credentials/url", serivceInstanceJsonObject).getAsString();
            }
        	
        	@Override
            public ServiceCategory getServiceCategory() {
                return ServiceCategory.bp;
            }
        	
        	public String getEndpoint() {
                return endpoint;
            }
        }

        // Location Service
        public static class LocationServiceInstance extends UaaBasedClientSecretBasedServiceInstance {

            private String endpoint;

            public LocationServiceInstance(JsonObject serivceInstanceJsonObject) {
                super(serivceInstanceJsonObject);
                this.endpoint = JsonUtils.getByPath("/credentials/endpoints/LocationService",serivceInstanceJsonObject).getAsString();
            }

            @Override
            public ServiceCategory getServiceCategory() {
                return ServiceCategory.location;
            }

            public String getEndpoint() {
                return endpoint;
            }

        }
        
        // Sass Registry Service
        public static class SaasRegistryServiceInstance extends ClientSecretBasedServiceInstance {

        	public enum Plan{
        		APPLICATION("application"),SERVICE("service");
        		
        		private final String planName;
        		
        		private Plan(String planName) {
					this.planName = planName;
				}

				public String getPlanName() {
					return planName;
				}

				
        	}
            /**
			 * 
			 */
			private static final long serialVersionUID = -6648214539995543805L;

            private String saasRegistryUrl;
            private String tenantOnboardingUrl;
            private String appName;

            private SaasSubscriptionServiceInstance saasSubscriptionServiceInstance;
            
            public SaasRegistryServiceInstance(JsonObject serivceInstanceJsonObject) {
                super(serivceInstanceJsonObject);
                this.saasRegistryUrl = JsonUtils.getByPath("/credentials/saas_registry_url", serivceInstanceJsonObject).getAsString();
                this.tenantOnboardingUrl = JsonUtils.getByPath("/credentials/tenant_onboarding_url", serivceInstanceJsonObject).getAsString();
                JsonElement appNameJsonElement = JsonUtils.getByPath("/credentials/appName", serivceInstanceJsonObject);
                if(appNameJsonElement.isJsonNull()){
                	appNameJsonElement = JsonUtils.getByPath("/credentials/app_name", serivceInstanceJsonObject);
                }
                this.appName = appNameJsonElement.getAsString();
            }

            @Override
            public ServiceCategory getServiceCategory() {
                return ServiceCategory.saasregistry;
            }

            public String getSaasRegistryUrl() {
                return saasRegistryUrl;
            }

            public String getTenantOnboardingUrl() {
                return tenantOnboardingUrl;
            }

            public String getAppName() {
                return appName;
            }

           
            
            public SaasSubscriptionServiceInstance getSaasSubscriptionServiceInstance() {
				return saasSubscriptionServiceInstance;
			}

			public void setSaasSubscriptionServiceInstance(SaasSubscriptionServiceInstance saasSubscriptionServiceInstance) {
				this.saasSubscriptionServiceInstance = saasSubscriptionServiceInstance;
			}



			public static class Dependency {
                private String xsappname;
                private String appName;
                private String state;
                private String error;
                private List<Dependency> dependencies;

                public String getXsappname() {
                    return xsappname;
                }

                public String getAppName() {
                    return appName;
                }

                public String getState() {
                    return state;
                }

                public String getError() {
                    return error;
                }

                public List<Dependency> getDependencies() {
                    if (dependencies == null) {
                        return new ArrayList<>();
                    }

                    return dependencies;
                }

            }
            
            public static class ReturnOfGetSubscriptions {

                private List<Subscription> subscriptions;

                public List<Subscription> getSubscriptions() {
                    if (subscriptions == null) {
                        return new ArrayList<>();
                    }

                    return subscriptions;
                }
                
                public static ReturnOfGetSubscriptions fromJson(String jsonString){
                	return JsonUtils.generateBeanFromJson(jsonString, ReturnOfGetSubscriptions.class);

                }
            }

            public static class Subscription {

                private String appName;
                private String consumerTenantId;
                private String serviceInstanceId;
                private String state;
                private String error;
                private List<Dependency> dependencies;

                public void setConsumerTenantId(String consumerTenantId) {
					this.consumerTenantId = consumerTenantId;
				}

				public void setServiceInstanceId(String serviceInstanceId) {
					this.serviceInstanceId = serviceInstanceId;
				}

				public String getAppName() {
                    return appName;
                }

                public String getConsumerTenantId() {
                    return consumerTenantId;
                }

                public String getServiceInstanceId() {
                    return serviceInstanceId;
                }

                public String getState() {
                    return state;
                }

                public String getError() {
                    return error;
                }

                public List<Dependency> getDependencies() {
                    if (dependencies == null) {
                        return new ArrayList<>();
                    }

                    return dependencies;
                }

            }

            public abstract static class APIWrapper{
            	private SaasRegistryServiceInstance saasRegistryServiceInstance;
            	public APIWrapper (SaasRegistryServiceInstance saasRegistryServiceInstance){
            		this.saasRegistryServiceInstance = saasRegistryServiceInstance;
            	}
            	
            	public SaasRegistryServiceInstance getSaasRegistryServiceInstance() {
					return saasRegistryServiceInstance;
				}

				public ReturnOfGetSubscriptions getSubscriptions(String subaccountId){
            		
            		GTTRestTemplate restTemplate = SpringContextUtils.getBean(GTTRestTemplate.class);
                    HttpHeaders headers = new HttpHeaders();
                    headers.setBearerAuth(getSaasRegistryServiceInstance().requestTechniqueToken());
                    ResponseEntity<ReturnOfGetSubscriptions> response = restTemplate.exchange(getAPIUrlForGetSubscription(subaccountId), HttpMethod.GET, headers, null, ReturnOfGetSubscriptions.class);
                    return response.getBody();
            	}
            	
				public void updateSubscription(Subscription subscription){
					GTTRestTemplate restTemplate = SpringContextUtils.getBean(GTTRestTemplate.class);
                    HttpHeaders headers = new HttpHeaders();
                    headers.setBearerAuth(getSaasRegistryServiceInstance().requestTechniqueToken());
                    restTemplate.exchange(this.getAPIUrlForUpdateSubscription(subscription), HttpMethod.PATCH, headers, null, String.class);
                    
				}
				
				public void createSubscription(Subscription subscription) {
					GTTRestTemplate restTemplate = SpringContextUtils.getBean(GTTRestTemplate.class);
                    HttpHeaders headers = new HttpHeaders();
                    headers.setBearerAuth(getSaasRegistryServiceInstance().requestTechniqueToken());
                    headers.setContentType(MediaType.APPLICATION_JSON);
                    restTemplate.exchange(this.getAPIUrlForCreateSubscription(subscription), HttpMethod.POST, headers, "{}", String.class);
                    
				}
				
				public void deleteSubscription(Subscription subscription) {
					GTTRestTemplate restTemplate = SpringContextUtils.getBean(GTTRestTemplate.class);
                    HttpHeaders headers = new HttpHeaders();
                    headers.setBearerAuth(getSaasRegistryServiceInstance().requestTechniqueToken());
                    restTemplate.exchange(this.getAPIUrlForDeleteSubscription(subscription), HttpMethod.DELETE, headers, null, String.class);
                    
				}
				
            	protected abstract String getAPIUrlForGetSubscription(String subaccountId);
            	protected abstract String getAPIUrlForUpdateSubscription(Subscription subscription);
            	protected abstract String getAPIUrlForCreateSubscription(Subscription subscription);
            	protected abstract String getAPIUrlForDeleteSubscription(Subscription subscription);
            	
            	
            }
            
            public static class ServicePlanAPIWrapper extends APIWrapper{

				public ServicePlanAPIWrapper(SaasRegistryServiceInstance saasRegistryServiceInstance) {
					super(saasRegistryServiceInstance);
					
				}

				@Override
				protected String getAPIUrlForGetSubscription(String subaccountId) {
					String result = this.getSaasRegistryServiceInstance().getSaasRegistryUrl() + "/saas-manager/v1/service/subscriptions";
					if(!StringUtils.isBlank(subaccountId)){
						result += "?tenantId=" + subaccountId;
					}
					return result;
				}

				@Override
				protected String getAPIUrlForUpdateSubscription(Subscription subscription) {
					return this.getSaasRegistryServiceInstance().getSaasRegistryUrl() + 
							String.format("/saas-manager/v1/service/tenants/%s/service-instances/%s/subscriptions", 
									subscription.getConsumerTenantId(),
									subscription.getServiceInstanceId())
					;
				}

				@Override
				public void createSubscription(Subscription subscription) {
					// get stack service
					SaasSubscriptionServiceInstance saasSubscriptionServiceInstance = this.getSaasRegistryServiceInstance().getSaasSubscriptionServiceInstance();
					saasSubscriptionServiceInstance.subscribe(subscription.getConsumerTenantId(), subscription.getServiceInstanceId(), this.getSaasRegistryServiceInstance().getAppName());
				
				}

				@Override
				public void deleteSubscription(Subscription subscription) {
					// get stack service
					SaasSubscriptionServiceInstance saasSubscriptionServiceInstance = this.getSaasRegistryServiceInstance().getSaasSubscriptionServiceInstance();
					saasSubscriptionServiceInstance.unsubscribe(subscription.getConsumerTenantId(), subscription.getServiceInstanceId(), this.getSaasRegistryServiceInstance().getAppName());
				}

				@Override
				protected String getAPIUrlForCreateSubscription(Subscription subscription) {
					throw new UnsupportedOperationException("getAPIUrlForCreateSubscription");
				}

				@Override
				protected String getAPIUrlForDeleteSubscription(Subscription subscription) {
					return this.getAPIUrlForUpdateSubscription(subscription);
				}
            	
				
            }
            
            public static class ApplicationPlanAPIWrapper extends APIWrapper{

				public ApplicationPlanAPIWrapper(SaasRegistryServiceInstance saasRegistryServiceInstance) {
					super(saasRegistryServiceInstance);
					
				}

				@Override
				protected String getAPIUrlForGetSubscription(String subaccountId) {
					String result = this.getSaasRegistryServiceInstance().getSaasRegistryUrl() + "/saas-manager/v1/application/subscriptions";
					if(!StringUtils.isBlank(subaccountId)){
						result += "?tenantId=" + subaccountId;
					}
					return result;
				}

				@Override
				protected String getAPIUrlForUpdateSubscription(Subscription subscription) {
					return this.getSaasRegistryServiceInstance().getSaasRegistryUrl() + 
							String.format("/saas-manager/v1/application/tenants/%s/subscriptions",
									subscription.getConsumerTenantId())
					;
				}

				@Override
				protected String getAPIUrlForCreateSubscription(Subscription subscription) {
					return this.getAPIUrlForUpdateSubscription(subscription);
				}

				@Override
				protected String getAPIUrlForDeleteSubscription(Subscription subscription) {
					return this.getAPIUrlForUpdateSubscription(subscription);
				}

				
            	
            }
            
            public APIWrapper getAPIWrapper(){
            	if(StringUtils.equals(this.getPlanName(), Plan.APPLICATION.getPlanName())){
            		return new ApplicationPlanAPIWrapper(this);
            	}
            	else{
            		return new ServicePlanAPIWrapper(this);
            	}
            }
        }

        // Sass Subscription Service
        public static class SaasSubscriptionServiceInstance extends ClientSecretBasedServiceInstance {

            private static final long serialVersionUID = 3556649351973395839L;

            public SaasSubscriptionServiceInstance(JsonObject serivceInstanceJsonObject) {
                super(serivceInstanceJsonObject);
            }

            @Override
            public ServiceCategory getServiceCategory() {
                return ServiceCategory.saassubscription;
            }

            public void subscribe(String subaccountId, String cloneInstanceId, String serviceSaaSRegistryName){
            	String url = this.getSaaSSubscriptionUrl(subaccountId, cloneInstanceId, serviceSaaSRegistryName);
            	GTTRestTemplate restTemplate = SpringContextUtils.getBean(GTTRestTemplate.class);
                HttpHeaders headers = new HttpHeaders();
                headers.setBearerAuth(this.requestTechniqueToken());
                restTemplate.exchange(url, HttpMethod.POST, headers, null, String.class);
            	
            }
            
            public void unsubscribe(String subaccountId, String cloneInstanceId, String serviceSaaSRegistryName){
            	String url = this.getSaaSSubscriptionUrl(subaccountId, cloneInstanceId, serviceSaaSRegistryName);
            	GTTRestTemplate restTemplate = SpringContextUtils.getBean(GTTRestTemplate.class);
                HttpHeaders headers = new HttpHeaders();
                headers.setBearerAuth(this.requestTechniqueToken());
                restTemplate.exchange(url, HttpMethod.DELETE, headers, null, String.class);
            	
            }
            
            protected String getSaaSSubscriptionUrl(String subaccountId, String cloneInstanceId, String serviceSaaSRegistryName){
            	
            	ISAPCloudPlatformAgent platformAgent = SpringContextUtils.getBean(ISAPCloudPlatformAgent.class);
            	return platformAgent.getSaasSubscriptionAPIHost() + 
                    	String.format("/api/v2.0/subaccounts/%s/applications/%s/instances/%s/subscriptions",
                    			subaccountId,serviceSaaSRegistryName, cloneInstanceId);
            }
        }
        
        // Reminder Service
        public static class ReminderServiceInstance extends UaaBasedClientSecretBasedServiceInstance {
			private static final long serialVersionUID = 7257545535000858945L;
			private String endpoint;

			public ReminderServiceInstance(JsonObject serivceInstanceJsonObject) {
				super(serivceInstanceJsonObject);
				String s = JsonUtils.getByPath("/credentials/endpoints/ReminderService", serivceInstanceJsonObject).getAsString();
				if(s.endsWith("odata/v2/"))
					s = s.replace("odata/v2/", "api/v1/");
				else
					s += "api/v1/";
				this.endpoint = s;
			}

			@Override
			public ServiceCategory getServiceCategory() {
				return ServiceCategory.reminder;
			}
        	
			public String getEndpoint() {
                return endpoint;
            }
			
			public String requestTechniqueTokenForSaasSubaccount(){
				ICurrentAccessContext currentAccessContext = SpringContextUtils.getBean(ICurrentAccessContext.class);
				String subdomain = currentAccessContext.getSubdomain();
				
				TenantAwareLogService logService = SpringContextUtils.getBean(TenantAwareLogService.class);
                logService.info("===> requestTechniqueTokenForSaasSubaccount under subdomain: " + subdomain);
                logService.info("===> requestTechniqueTokenForSaasSubaccount url: " + this.getUrl());
                logService.info("===> requestTechniqueTokenForSaasSubaccount clientid: " + this.getClientId());
                logService.info("===> requestTechniqueTokenForSaasSubaccount clientsecret: " + this.getClientSecret());
                
				return UaaUtils.requestTechniqueToken(this.getUrl(), subdomain, this.getClientId(), this.getClientSecret());
			}
        }

        private JsonObject vcapServiceJsonObject;

        public JsonObject getVcapServiceJsonObject() {
            return vcapServiceJsonObject;
        }

        public VcapServiceParser(String vcapServiceJsonString) {
            vcapServiceJsonObject = JsonUtils.generateJsonObjectFromJsonString(vcapServiceJsonString);
        }

        protected List<JsonObject> getServiceInstanceJsonObjects(ServiceCategory serviceCategory) {
            List<JsonObject> result = new ArrayList<>();
            JsonArray jsonArray = JsonUtils.getValueAsJsonArray(this.getVcapServiceJsonObject(), serviceCategory.getCategoryName());
            if (jsonArray == null) {
                return result;
            }
            result = JsonUtils.getElements(jsonArray, JsonObject.class);
            return result;
        }

        protected List<JsonObject> getServiceInstanceJsonObjects(String serviceName) {
            List<JsonObject> result = new ArrayList<>();
            JsonArray jsonArray = JsonUtils.getValueAsJsonArray(this.getVcapServiceJsonObject(), serviceName);
            if (jsonArray == null) return result;
            result = JsonUtils.getElements(jsonArray, JsonObject.class);

            return result;
        }

        /**
         * HanaSchemaHDIContainerService with only schema plan
         *
         * @return
         */
        public List<HanaSchemaHDIContainerServiceInstance> getHanaSchemaHDIContainerSchemaPlanServiceInstances() {
            return getHanaSchemaHDIContainerServiceInstances("schema");
        }

        public List<HanaSchemaHDIContainerServiceInstance> getHanaSchemaHDIContainerSecurestorePlanServiceInstances() {
            return getHanaSchemaHDIContainerServiceInstances("securestore");

        }

        protected List<HanaSchemaHDIContainerServiceInstance> getHanaSchemaHDIContainerServiceInstances(String planName) {
            List<HanaSchemaHDIContainerServiceInstance> result = new ArrayList<>();
            List<JsonObject> serviceInstanceJsonObjects = getServiceInstanceJsonObjects(ServiceCategory.hana);
            for (JsonObject serviceInstanceJsonObject : serviceInstanceJsonObjects) {
                HanaSchemaHDIContainerServiceInstance instance = new HanaSchemaHDIContainerServiceInstance(serviceInstanceJsonObject);
                if (StringUtils.equals(instance.getPlanName(), planName)) {
                    instance.initDataSource();
                    result.add(instance);
                }

            }
            return result;
        }

        protected List<H2SchemaServiceInstance> getH2SchemaServiceInstance() {
            List<H2SchemaServiceInstance> result = new ArrayList<>();
            List<JsonObject> serviceInstanceJsonObjects = getServiceInstanceJsonObjects(ServiceCategory.h2);
            for (JsonObject serviceInstanceJsonObject : serviceInstanceJsonObjects) {
                H2SchemaServiceInstance instance = new H2SchemaServiceInstance(serviceInstanceJsonObject);
                instance.initDataSource();
                result.add(instance);
            }
            return result;
        }

        protected List<DestinationServiceInstance> getDestinationServiceInstance() {
            List<DestinationServiceInstance> result = new ArrayList<>();
            List<JsonObject> serviceInstanceJsonObjects = getServiceInstanceJsonObjects(ServiceCategory.destination);
            for (JsonObject serviceInstanceJsonObject : serviceInstanceJsonObjects) {
                DestinationServiceInstance instance = new DestinationServiceInstance(serviceInstanceJsonObject);
                result.add(instance);
            }
            return result;
        }

        protected List<BpServiceInstance> getBPServiceInstances() {
            List<BpServiceInstance> result = new ArrayList<>();
            List<JsonObject> serviceInstanceJsonObjects = getServiceInstanceJsonObjects(ServiceCategory.bp);
            for (JsonObject serviceInstanceJsonObject : serviceInstanceJsonObjects) {
                BpServiceInstance instance = new BpServiceInstance(serviceInstanceJsonObject);
                result.add(instance);
            }
            return result;
        }

        protected List<LocationServiceInstance> getLocationServiceInstances() {
            List<LocationServiceInstance> result = new ArrayList<>();
            List<JsonObject> serviceInstanceJsonObjects = getServiceInstanceJsonObjects(ServiceCategory.location);
            for (JsonObject serviceInstanceJsonObject : serviceInstanceJsonObjects) {
                LocationServiceInstance instance = new LocationServiceInstance(serviceInstanceJsonObject);
                result.add(instance);
            }
            return result;
        }

        protected List<UaaServiceInstance> getUaaServiceInstances() {
            List<UaaServiceInstance> result = new ArrayList<>();
            List<JsonObject> serviceInstanceJsonObjects = getServiceInstanceJsonObjects(ServiceCategory.xsuaa);
            for (JsonObject serviceInstanceJsonObject : serviceInstanceJsonObjects) {
                UaaServiceInstance instance = new UaaServiceInstance(serviceInstanceJsonObject);
                result.add(instance);
            }
            return result;
        }

        protected List<PortalServiceInstance> getPortalServiceInstances() {
            List<PortalServiceInstance> result = new ArrayList<>();
            List<JsonObject> serviceInstanceJsonObjects = getServiceInstanceJsonObjects(ServiceCategory.portal);
            for (JsonObject serviceInstanceJsonObject : serviceInstanceJsonObjects) {
            	PortalServiceInstance instance = new PortalServiceInstance(serviceInstanceJsonObject);
                result.add(instance);
            }
            return result;
        }
        

        protected List<SaasRegistryServiceInstance> getSaasRegistryServiceInstances() {

            List<SaasRegistryServiceInstance> result = new ArrayList<>();
            List<JsonObject> serviceInstanceJsonObjects = getServiceInstanceJsonObjects(ServiceCategory.saasregistry);
            for (JsonObject serviceInstanceJsonObject : serviceInstanceJsonObjects) {
                SaasRegistryServiceInstance instance = new SaasRegistryServiceInstance(serviceInstanceJsonObject);
                result.add(instance);
            }
            return result;
        }

        protected List<SaasSubscriptionServiceInstance> getSaasSubscriptionServiceInstances() {
            List<SaasSubscriptionServiceInstance> result = new ArrayList<>();
            List<JsonObject> serviceInstanceJsonObjects = getServiceInstanceJsonObjects(ServiceCategory.saassubscription);
            for (JsonObject serviceInstanceJsonObject : serviceInstanceJsonObjects) {
                SaasSubscriptionServiceInstance instance = new SaasSubscriptionServiceInstance(serviceInstanceJsonObject);
                result.add(instance);
            }
            return result;
        }
        
        protected List<ManagedHanaServiceInstance> getManagedHanaServiceInstance(){
            List<ManagedHanaServiceInstance> result = new ArrayList<>();
            List<JsonObject> serviceInstanceJsonObjects = getServiceInstanceJsonObjects(ServiceCategory.managedhana);
            for(JsonObject serviceInstanceJsonObject : serviceInstanceJsonObjects){
            	ManagedHanaServiceInstance instance = new ManagedHanaServiceInstance(serviceInstanceJsonObject);
                result.add(instance);
            }
            return result;
        }
        
        protected List<ReminderServiceInstance> getReminderServiceInstance() {
            List<ReminderServiceInstance> result = new ArrayList<>();
            List<JsonObject> serviceInstanceJsonObjects = getServiceInstanceJsonObjects(ServiceCategory.reminder);
            for (JsonObject serviceInstanceJsonObject : serviceInstanceJsonObjects) {
            	ReminderServiceInstance instance = new ReminderServiceInstance(serviceInstanceJsonObject);
                result.add(instance);
            }
            return result;
        }
    }

    @Autowired
    private ISAPCloudPlatformAgent platformAgent;

    @Bean
    public VcapServiceParser vcapServiceParser() {
        return new VcapServiceParser(platformAgent.getVcapServicesString());
    }

    /**
     * must be static method to ensure the bean "PropertySourcesPlaceholderConfigurer" is
     * initialized before all instance method factory
     *
     * @return
     */
    @Bean
    public static PropertySourcesPlaceholderConfigurer placeholderConfigurer() {
        // make environment variables available for Spring's @Value annotation
        PropertySourcesPlaceholderConfigurer c = new PropertySourcesPlaceholderConfigurer();
        c.setIgnoreUnresolvablePlaceholders(false);
        return c;
    }

    @Bean
    public ResourceServerTokenServices tokenService() {
        return new SAPOfflineTokenServicesCloud();
    }
}
