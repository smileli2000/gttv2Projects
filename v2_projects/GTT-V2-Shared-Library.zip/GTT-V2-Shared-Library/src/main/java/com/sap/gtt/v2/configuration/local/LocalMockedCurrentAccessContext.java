package com.sap.gtt.v2.configuration.local;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import com.sap.gtt.v2.configuration.SAPCloudPlatformAgent.CurrentAccessContext;
import com.sap.gtt.v2.configuration.ServiceInstancesMapping;
import com.sap.gtt.v2.configuration.ISAPCloudPlatformAgent.ICurrentAccessContext;

@Component(ICurrentAccessContext.BEAN_NAME)
@Profile({"shared-lib-local","test"})
public class LocalMockedCurrentAccessContext extends CurrentAccessContext{
	private static final Logger logger = LoggerFactory.getLogger(LocalMockedCurrentAccessContext.class);

	public static final String TENANT_SUBACCOUNT_ID = "ba77fcf8-6aae-48d5-a787-32e768e303e8";
	public static final String TENANT_SUBDOMAIN = "lbn-platform";
	public static final String LOGON_NAME = "gtt_v2_dev@sap.com";
	public static final String CLONE_SERVICE_INSTANCE_ID_SHARED_PLAN = "96e25690-ac73-47f9-9fcf-1e041172c9f6";
	public static final String CLONE_SERVICE_INSTANCE_ID_STANDALONE_PLAN = "bc2510b5-b246-43b9-90a2-a6d380de5e32";
	public static final String CLONE_SERVICE_INSTANCE_NAME_SHARED_PLAN = "lbn-gtt-core-shared";
	public static final String CLONE_SERVICE_INSTANCE_ID = "96e25690-ac73-47f9-9fcf-1e041172c9f6";



   /*
	public static final String TENANT_SUBACCOUNT_ID = "ba77fcf8-6aae-48d5-a787-32e768e303e9";
	public static final String TENANT_SUBDOMAIN = "lbn-platform";
	public static final String LOGON_NAME = "gtt_v2_dev@sap.com";
	public static final String CLONE_SERVICE_INSTANCE_ID_SHARED_PLAN = "96e25690-ac73-47f9-9fcf-1e041172c9f7";
	public static final String CLONE_SERVICE_INSTANCE_ID_STANDALONE_PLAN = "bc2510b5-b246-43b9-90a2-a6d380de5e33";
	public static final String CLONE_SERVICE_INSTANCE_NAME_SHARED_PLAN = "lbn-gtt-core-shared2";
	public static final String CLONE_SERVICE_INSTANCE_ID = "96e25690-ac73-47f9-9fcf-1e041172c9f7";
*/
	//public static final String CLONE_SERVICE_INSTANCE_ID = StringUtils.EMPTY; // local run for standalone
	
	@Autowired
	private ServiceInstancesMapping serviceInstanceMapping;
	@Override
	public boolean isAuthenticated() {
		return true;
	}

	@Override
	public String getSubaccountId() {
		return TENANT_SUBACCOUNT_ID;
	}

	@Override
	public String getLogonName() {
		return LOGON_NAME;
	}

	@Override
	public String getCloneServiceInstanceId() {
		return CLONE_SERVICE_INSTANCE_ID_SHARED_PLAN;
	}

	@Override
	public boolean containsCloneServiceInstanceId() {
		return !StringUtils.isBlank(getCloneServiceInstanceId());
	}


	@Value("${requestToken.enabled:#{false}}")
	private boolean requestTokenEnabled;
	
	@Override
	public String getJWT() {
		if(requestTokenEnabled){
			logger.info("Requesting token...");
			String result = serviceInstanceMapping.getUaaServiceInstance().requestTechniqueToken();
			logger.info("Token requested...");
			return result;
		}
		else{
			return "";
		}
	}

	@Override
	public String getSubdomain() {
		return TENANT_SUBDOMAIN;
	}

	@Override
	public boolean isUserToken() {
		return false;
	}

	@Override
	public boolean isIntegrationUserToken() {
		return false;
	}

	@Override
	public boolean isProductive() {
		return false;
	}

	@Override
	public boolean isSolutionOwner() {
		return false;
	}

	
}
