/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.gtt.v2.core.domain.auditlog;

/**
 *
 * @author I326335
 */
public class AuditDataAccessData {
    private String field;
    private Boolean accessed;

    public AuditDataAccessData(String field, Boolean accessed) {
        this.field = field;
        this.accessed = accessed;
    }

    public String getField() {
        return field;
    }

    public void setField(String field) {
        this.field = field;
    }

    public Boolean getAccessed() {
        return accessed;
    }

    public void setAccessed(Boolean accessed) {
        this.accessed = accessed;
    }

    @Override
    public String toString() {
        return "AuditDataAccessData{" + "field=" + field + ", accessed=" + accessed + '}';
    }
}
