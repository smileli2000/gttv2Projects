package com.sap.gtt.v2.core.domain.execution;

import java.time.Instant;

/**
 * @author I302310
 */
public class MappingMessageDto {
    private String rootRequestId;
    private String objectId;
    private String targetId;
    private ExecutionStatus status;
    private String message;
    private String detail;

    public String getRootRequestId() {
        return rootRequestId;
    }

    public void setRootRequestId(String rootRequestId) {
        this.rootRequestId = rootRequestId;
    }

    public String getObjectId() {
        return objectId;
    }

    public void setObjectId(String objectId) {
        this.objectId = objectId;
    }

    public String getTargetId() {
        return targetId;
    }

    public void setTargetId(String targetId) {
        this.targetId = targetId;
    }

    public ExecutionStatus getStatus() {
        return status;
    }

    public void setStatus(ExecutionStatus status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }
}
