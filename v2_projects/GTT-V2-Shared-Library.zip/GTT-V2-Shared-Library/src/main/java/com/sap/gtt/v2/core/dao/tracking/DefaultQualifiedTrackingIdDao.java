package com.sap.gtt.v2.core.dao.tracking;

import com.sap.gtt.v2.core.domain.metadata.CurrentMetadataEntity;
import com.sap.gtt.v2.core.domain.metadata.MetadataConstants;
import com.sap.gtt.v2.core.entity.trackedprocess.QualifiedTrackingId;
import com.sap.gtt.v2.core.entity.trackedprocess.TrackedProcess;
import com.sap.gtt.v2.log.TenantAwareLogService;
import com.sap.gtt.v2.util.DBUtils;
import com.sap.gtt.v2.util.SpringContextUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

import static com.sap.gtt.v2.core.domain.metadata.MetadataConstants.DOT;
import static com.sap.gtt.v2.core.entity.trackedprocess.QualifiedTrackingId.*;
import static com.sap.gtt.v2.core.entity.trackedprocess.TrackedProcess.*;

@Repository(DefaultQualifiedTrackingIdDao.BEAN_NAME)
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class DefaultQualifiedTrackingIdDao implements IQualifiedTrackingIdDao {
    public static final String BEAN_NAME = "com.sap.gtt.v2.core.dao.tracking.DefaultQualifiedTrackingIdDao";
    private static final String AND = " = ? and ";

    private static final String TABLE_NAME_TRACKED_PROCESS = DBUtils.toTableName(MetadataConstants.CoreModelEntity.TRACKED_PROCESS.getFullName());
    private static final String TABLE_NAME_QUALIFIED_TRACKING_ID = DBUtils.toTableName(MetadataConstants.CoreModelEntity.QUALIFIED_TRACKING_ID.getFullName());

    protected DefaultQualifiedTrackingIdDao() {

    }

    public static DefaultQualifiedTrackingIdDao getInstance() {
        return (DefaultQualifiedTrackingIdDao) SpringContextUtils.getBean(BEAN_NAME);
    }

    @Autowired
    private DaoHelper daoHelper;

    @Autowired
    private TenantAwareLogService logService;

    @Override
    public void insert(QualifiedTrackingId qualifiedTrackingId) {
        daoHelper.insert(qualifiedTrackingId);
    }

    @Override
    public void insert(List<QualifiedTrackingId> qualifiedTrackingIds) {
        for (QualifiedTrackingId qualifiedTrackingId : qualifiedTrackingIds) {
            insert(qualifiedTrackingId);
        }
    }

    @Override
    public void update(QualifiedTrackingId qualifiedTrackingId) {
        daoHelper.update(qualifiedTrackingId);
    }

    @Override
    public boolean exists(QualifiedTrackingId qualifiedTrackingId) {
        String where = new StringBuilder(PROCESSID)
                .append(AND)
                .append(OBSERVEDPROCESSID)
                .append(" = ?").toString();
        return daoHelper.count(qualifiedTrackingId.getMetadata(), where, qualifiedTrackingId.getProcessId(), qualifiedTrackingId.getObservedProcessId()) > 0;
    }

    @Override
    public void delete(CurrentMetadataEntity metadata, UUID processId, UUID observedProcessId) {
        String where = new StringBuilder(PROCESSID)
                .append(AND)
                .append(OBSERVEDPROCESSID)
                .append(" = ?").toString();
        daoHelper.deleteAll(metadata, where, processId, observedProcessId);
    }

    @Override
    public void delete(QualifiedTrackingId qualifiedTrackingId) {
        String where = new StringBuilder(PROCESSID)
                .append(AND)
                .append(OBSERVEDPROCESSID)
                .append(" = ?").toString();
        daoHelper.deleteAll(qualifiedTrackingId.getMetadata(), where, qualifiedTrackingId.getProcessId(), qualifiedTrackingId.getObservedProcessId());
    }

    @Override
    public List<QualifiedTrackingId> findAll(CurrentMetadataEntity metadata, UUID observedProcessId, Instant actualBusinessTime) {
        String where = new StringBuilder(OBSERVEDPROCESSID)
                .append(" = ? and ( ")
                .append(VALIDFROM)
                .append(" <= ? and ")
                .append(VALIDTO)
                .append(" >= ? ) ").toString();

        return daoHelper.findAll(QualifiedTrackingId.class, metadata, where, observedProcessId, actualBusinessTime, actualBusinessTime);
    }

    @Override
    public List<QualifiedTrackingId> findAll(UUID observedProcessId, Instant actualBusinessTime) {
        String sql = new StringBuilder("select T1.* from ")
                .append(DBUtils.toTableName(
                        MetadataConstants.CoreModelEntity.QUALIFIED_TRACKING_ID.getFullName()))
                .append(" T1 inner join ")
                .append(DBUtils.toTableName(
                        MetadataConstants.CoreModelEntity.TRACKED_PROCESS.getFullName()))
                .append(" T2 on T1.").append(OBSERVEDPROCESSID)
                .append(" = T2.").append(TrackedProcess.ID)
                .append(" where T2.")
                .append(LIFE_CYCLE_STATUS).append(" <> '").append(END_OF_PURPOSE).append("' and T2.")
                .append(LIFE_CYCLE_STATUS).append(" <> '").append(END_OF_RETENTION).append("' and ")
                .append(OBSERVEDPROCESSID)
                .append(" = ? and ( ")
                .append(VALIDFROM)
                .append(" <= ? and ")
                .append(VALIDTO)
                .append(" >= ? ) ").toString();
        logService.debug("sql:{}, observedProcessId:{}, actualBusinessTime:{}",
                sql, observedProcessId, actualBusinessTime);

        return daoHelper.getJdbcTemplate().query(sql,
                new Object[]{observedProcessId, actualBusinessTime, actualBusinessTime},
                new QualifiedTrackingIdRowMapper());
    }

    private class QualifiedTrackingIdRowMapper implements RowMapper<QualifiedTrackingId> {
        @Override
        public QualifiedTrackingId mapRow(ResultSet rs, int rowNum) throws SQLException {
            QualifiedTrackingId qualifiedTrackingId = new QualifiedTrackingId();
            String strValue = rs.getString(PROCESSID);
            qualifiedTrackingId.setProcessId(StringUtils.isEmpty(strValue) ? null : UUID.fromString(strValue));
            strValue = rs.getString(OBSERVEDPROCESSID);
            qualifiedTrackingId.setObservedProcessId(StringUtils.isEmpty(strValue) ? null : UUID.fromString(strValue));

            Timestamp timestamp = rs.getTimestamp(VALIDFROM);
            qualifiedTrackingId.setValidFrom(timestamp == null ? null : timestamp.toInstant());

            timestamp = rs.getTimestamp(VALIDTO);
            qualifiedTrackingId.setValidTo(timestamp == null ? null : timestamp.toInstant());

            return qualifiedTrackingId;
        }
    }

    @Override
    public void deleteByProcessId(CurrentMetadataEntity metadata, UUID processId) {
        String where = new StringBuilder(PROCESSID)
                .append(" = ? ").toString();
        daoHelper.deleteAll(metadata, where, processId);
    }

    @Override
    public void deleteByProcessId(UUID processId) {
        String sql = new StringBuilder("delete from ")
                .append(DBUtils.toTableName(
                        MetadataConstants.CoreModelEntity.QUALIFIED_TRACKING_ID.getFullName()))
                .append(" where ").append(PROCESSID)
                .append(" = ?").toString();
        logService.debug("sql:{}, values:{}", sql, processId);
        daoHelper.getJdbcTemplate().update(sql, processId);
    }

    @Override
    public List<UUID> getCorrelatedProcessId(CurrentMetadataEntity metadata, UUID internalValue, Instant actualBizTs) {
        return getCorrelatedProcessId(internalValue, actualBizTs, metadata.getEventCorrelationLevel());
    }

    @Override
    public List<UUID> getCorrelatedProcessId(UUID internalValue, Instant actualBizTs, int eventCorrelationLevel) {
        Map<UUID, String> correlatedProcessMap = getCorrelatedProcessMap(internalValue, actualBizTs, eventCorrelationLevel);
        return correlatedProcessMap.keySet().stream().collect(Collectors.toList());
    }

    @Override
    public Map<UUID, String> getCorrelatedProcessMap(UUID observedProcessId, Instant actualBizTs, int eventCorrelationLevel) {
        List<Object> params = new ArrayList<>();
        String sql = generateCorrelatedProcessQuerySql(observedProcessId, actualBizTs, params, eventCorrelationLevel);
        logService.debug("sql:{}, observedProcessId:{}, actualBusinessTime:{}", sql, observedProcessId, actualBizTs);

        List<Map<String, Object>> result = daoHelper.getJdbcTemplate().queryForList(sql,
                params.toArray());

        Map<UUID, String> finalResult = new HashMap<>();
        result.stream().forEach(item -> {
            String processIdS = item.get(PROCESSID).toString();
            UUID processId = UUID.fromString(processIdS);
            String altkey = item.get(ALT_KEY).toString();
            finalResult.put(processId, altkey);
        });
        return finalResult;
    }

    /**
     * Generate correlated process query SQL.
     * <pre>
     *     select T0.process_id,tp.altKey
     *     from (select distinct T1.process_id
     *     	     from COM_SAP_GTT_CORE_COREMODEL_QUALIFIEDTRACKINGID T1
     *     	     left join COM_SAP_GTT_CORE_COREMODEL_QUALIFIEDTRACKINGID T2 on t1.OBSERVEDPROCESS_ID=t2.process_id
     *     	     left join COM_SAP_GTT_CORE_COREMODEL_QUALIFIEDTRACKINGID T3 on t2.OBSERVEDPROCESS_ID=t3.process_id
     *     	     left join COM_SAP_GTT_CORE_COREMODEL_QUALIFIEDTRACKINGID T4 on t3.OBSERVEDPROCESS_ID=t4.process_id
     *     	     left join COM_SAP_GTT_CORE_COREMODEL_QUALIFIEDTRACKINGID T5 on t4.OBSERVEDPROCESS_ID=t5.process_id
     *     	     where T1.validFrom <=? AND T1.validTo >=? AND
     *     	        T2.validFrom <=? AND T2.validTo >=? AND
     *     	        T3.validFrom <=? AND T3.validTo >=? AND
     *     	        T4.validFrom <=? AND T4.validTo >=? AND
     *     	        T5.validFrom <=? AND T5.validTo >=? AND
     *     	        T5.OBSERVEDPROCESS_ID='278c7120-13f3-5884-8a13-4c8a05ea6555') T0
     *     left join com_sap_gtt_core_CoreModel_TrackedProcess TP on T0.process_id = TP.id
     *     where TP.lifeCycleStatus_code <> 'END_OF_PURPOSE' and TP.lifeCycleStatus_code <> 'END_OF_RETENTION'
     * </pre>
     * @param observedProcessId observed process id
     * @param actualBizTs actual business tinestamp
     * @param params parameters
     * @param eventCorrelationLevel event correlation level
     * @return query SQL
     */
    private String generateCorrelatedProcessQuerySql(UUID observedProcessId, Instant actualBizTs, List<Object> params, int eventCorrelationLevel) {
        StringBuilder sqlSb = new StringBuilder("select T0.").append(PROCESSID).append(",TP.").append(ALT_KEY)
                .append(" from ( select distinct T1.").append(PROCESSID).append(" from ")
                .append(TABLE_NAME_QUALIFIED_TRACKING_ID).append(" T1 ");
        StringBuilder innerWhereSb = new StringBuilder(" WHERE ");
        if (eventCorrelationLevel <= 1) {
            generateInnerWhereForCorrelatedTp(innerWhereSb, "T1", true);
            params.add(actualBizTs);
            params.add(actualBizTs);
            params.add(observedProcessId);
        } else {
            for (int i = 1; i < eventCorrelationLevel; i++) {
                String aliasTi = " T" + i;
                String aliasTiPlus = " T" + (i + 1);
                sqlSb.append(" LEFT JOIN ").append(TABLE_NAME_QUALIFIED_TRACKING_ID).append(aliasTiPlus)
                        .append(" ON").append(aliasTi).append(".OBSERVEDPROCESS_ID=").append(aliasTiPlus).append(".PROCESS_ID ");
                generateInnerWhereForCorrelatedTp(innerWhereSb, aliasTi, false);
                params.add(actualBizTs);
                params.add(actualBizTs);
                if (i == eventCorrelationLevel - 1) {
                    innerWhereSb.append(" AND ");
                    generateInnerWhereForCorrelatedTp(innerWhereSb, aliasTiPlus, true);
                    params.add(actualBizTs);
                    params.add(actualBizTs);
                    params.add(observedProcessId);
                }
            }
        }
        sqlSb.append(innerWhereSb.toString());
        sqlSb.append(") T0 ")
                .append("LEFT JOIN ")
                .append(TABLE_NAME_TRACKED_PROCESS).append(" TP on T0.PROCESS_ID = TP.id ")
                .append(" WHERE TP.lifeCycleStatus_code <> ? and TP.lifeCycleStatus_code <> ? ")
        ;
        params.add(END_OF_PURPOSE);
        params.add(END_OF_RETENTION);
        return sqlSb.toString();
    }

    private void generateInnerWhereForCorrelatedTp(StringBuilder innerWhereSb, String aliasTi, boolean handleObservedProcessId) {
        innerWhereSb.append(aliasTi).append(DOT).append(VALIDFROM).append("<=? AND ")
                .append(aliasTi).append(DOT).append(VALIDTO).append(">=? ");
        if (handleObservedProcessId) {
            innerWhereSb.append(" AND ").append(aliasTi).append(DOT).append("OBSERVEDPROCESS_ID=? ");
        }
    }
}
