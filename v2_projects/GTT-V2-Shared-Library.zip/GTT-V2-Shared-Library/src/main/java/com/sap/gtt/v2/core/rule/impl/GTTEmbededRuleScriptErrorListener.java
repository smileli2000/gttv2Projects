package com.sap.gtt.v2.core.rule.impl;

import com.sap.gtt.v2.exception.GTTEmbededRuleScriptException;
import org.antlr.v4.runtime.BaseErrorListener;
import org.antlr.v4.runtime.RecognitionException;
import org.antlr.v4.runtime.Recognizer;
import org.apache.http.HttpStatus;

import com.sap.gtt.v2.exception.MultiExceptionContainer;

public class GTTEmbededRuleScriptErrorListener extends BaseErrorListener{
	
	private MultiExceptionContainer multiExceptionContainer = new MultiExceptionContainer(HttpStatus.SC_BAD_REQUEST, GTTEmbededRuleScriptException.ERROR_CODE);
	
	

	public MultiExceptionContainer getMultiExceptionContainer() {
		return multiExceptionContainer;
	}

	@Override
	public void syntaxError(Recognizer<?, ?> recognizer, Object offendingSymbol, int line, int charPositionInLine, String msg, RecognitionException e){
		GTTEmbededRuleScriptException error = new GTTEmbededRuleScriptException(line,
				charPositionInLine, msg,e);
		this.getMultiExceptionContainer().addException(error);
	}
	
	public void contextError(int line, int charPositionInLine,String msg, Throwable cause){
		GTTEmbededRuleScriptException error = new GTTEmbededRuleScriptException(line,
				charPositionInLine, msg, cause);
		this.getMultiExceptionContainer().addException(error);
	}
	
	public boolean containsError(){
		return !this.getMultiExceptionContainer().getContainedExceptions().isEmpty();
	}
}
