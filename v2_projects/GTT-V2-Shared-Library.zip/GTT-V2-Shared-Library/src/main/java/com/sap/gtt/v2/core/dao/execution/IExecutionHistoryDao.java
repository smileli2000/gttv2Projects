package com.sap.gtt.v2.core.dao.execution;

import com.sap.gtt.v2.core.entity.execution.ExecutionHistory;

import java.util.List;

public interface IExecutionHistoryDao {
    ExecutionHistory queryExecution(String id);

    List<String> queryStatus(String requestId);

    void insertExecution(ExecutionHistory executionHistory);

    void updateExecutionStatus(String id, String lastPhase, String status);
}
