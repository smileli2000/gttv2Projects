package com.sap.gtt.v2.core.dao.overdue;

import java.time.Instant;
import java.util.List;

import com.sap.gtt.v2.core.management.overdue.IOverdueManagement;

public interface IOverdueDao {
    /**
     //     * Find all the overdue plan event list of the given jobName
     //     *
     //     * @param jobName overdue detect job name
     //     * @return list of GTTOverdueEvent
     //     */
//    List<Event> getOverdueEventList(String jobName);
//

    /**
     * get the previous overdue job detection time.
     *
     * @param jobName overdue detect job name
     * @return Instant of the job execution time
     */
    Instant getPreviousDetectionTime(String jobName);

    /**
     * get the previous overdue job detection time.
     *
     * @param from overdue detect job last execution time.
     * @param to current time
     * @return the total number of the overdue event list
     */
    int countOverduePlannedEvent(Instant from, Instant to);

    /**
     * get overdue plan event info
     *
     * @param from overdue detect job last execution time.
     * @param to current time
     * @param skip read the data from the skip page
     * @param top return max number records is top.
     * @return the total number of the overdue event list
     */
    List<IOverdueManagement.PlannedEventIdentifier> getOverduePlannedEventsInfo(Instant from, Instant to, int skip, int top);

    /**
     * update the execution time to the  overdue info table
     *
     * @param jobName overdue detect job last execution time.
     * @param jobRunTime the job execution time.
     * @return the total number of the overdue event list
     */
    void updateOverdueInfo(String jobName,Instant jobRunTime);

}
