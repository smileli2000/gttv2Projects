package com.sap.gtt.v2.bp;

import com.google.gson.annotations.SerializedName;
import com.sap.gtt.v2.core.runtime.model.ObjectValue;

public class BPAccountDetail extends ObjectValue {

    public static final String BP_ID = "BpId";
    public static final String BP_TYPE = "BpType";
    public static final String BP_ACC_ID = "BpAccId";
    public static final String BP_STATUS = "Status";
    public static final String SUBSCRIBED_PLAN = "SubscribedPlan";
    public static final String SUBSCRIBED_APP = "SubscribedApp";
    public static final String GLOBAL_ACC_EXTERNAL_GUID = "GlobalAccExternalGUID";
    public static final String SUB_ACC_EXTERNAL_GUID = "SubAccExternalGUID";

    @SerializedName("BpId")
    private String bpId;
    @SerializedName("BpType")
    private String bpType;
    @SerializedName("BpAccId")
    private String bpAccId;
    @SerializedName("Status")
    private String status;
    @SerializedName("SubscribedPlan")
    private String subscribedPlan;
    @SerializedName("SubscribedApp")
    private String subscribedApp;
    @SerializedName("GlobalAccExternalGUID")
    private String globalAccExternalGUID;
    @SerializedName("SubAccExternalGUID")
    private String subAccExternalGUID;

    public String getBpId() {
        return bpId;
    }

    public void setBpId(String bpId) {
        this.bpId = bpId;
    }

    public String getBpType() {
        return bpType;
    }

    public void setBpType(String bpType) {
        this.bpType = bpType;
    }

    public String getBpAccId() {
        return bpAccId;
    }

    public void setBpAccId(String bpAccId) {
        this.bpAccId = bpAccId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getSubscribedPlan() {
        return subscribedPlan;
    }

    public void setSubscribedPlan(String subscribedPlan) {
        this.subscribedPlan = subscribedPlan;
    }

    public String getSubscribedApp() {
        return subscribedApp;
    }

    public void setSubscribedApp(String subscribedApp) {
        this.subscribedApp = subscribedApp;
    }

    public String getGlobalAccExternalGUID() {
        return globalAccExternalGUID;
    }

    public void setGlobalAccExternalGUID(String globalAccExternalGUID) {
        this.globalAccExternalGUID = globalAccExternalGUID;
    }

    public String getSubAccExternalGUID() {
        return subAccExternalGUID;
    }

    public void setSubAccExternalGUID(String subAccExternalGUID) {
        this.subAccExternalGUID = subAccExternalGUID;
    }

    public ObjectValue convertToObjectValue() {
        ObjectValue objectValue = new ObjectValue();
        objectValue.setValue(BP_ID, this.bpId);
        objectValue.setValue(BP_TYPE, this.bpType);
        objectValue.setValue(BP_ACC_ID, this.bpAccId);
        objectValue.setValue(BP_STATUS, this.status);
        objectValue.setValue(SUBSCRIBED_PLAN, this.subscribedPlan);
        objectValue.setValue(SUBSCRIBED_APP, this.subscribedApp);
        objectValue.setValue(GLOBAL_ACC_EXTERNAL_GUID, this.globalAccExternalGUID);
        objectValue.setValue(SUB_ACC_EXTERNAL_GUID, this.subAccExternalGUID);
        return objectValue;
    }
}
