package com.sap.gtt.v2.configuration;

import javax.servlet.ServletRequestEvent;

import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextListener;

@Component
public class CloudServletRequestListener extends RequestContextListener {

	@Override
	public void requestDestroyed(ServletRequestEvent sre) {
		// clear thread local variables as the thread may be reused by different request.
        super.requestDestroyed(sre);
		AccessContextHolder.clear();
	}

	@Override
	public void requestInitialized(ServletRequestEvent sre) {
		// we can not access SAP UserInfo from JWT here because this method is called
		// at very beginning and the whole authentication filter not yet went through and created into security context 
        super.requestInitialized(sre);
	}
}
