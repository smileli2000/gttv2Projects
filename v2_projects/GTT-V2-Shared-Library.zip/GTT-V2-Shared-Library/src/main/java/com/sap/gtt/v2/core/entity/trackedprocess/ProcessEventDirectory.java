package com.sap.gtt.v2.core.entity.trackedprocess;

import com.sap.gtt.v2.core.runtime.model.IPropertyValue;
import com.sap.gtt.v2.core.runtime.model.ObjectValue;

import java.util.Map;
import java.util.Objects;
import java.util.UUID;

public class ProcessEventDirectory extends ObjectValue {

    public static final String ID = "id";
    public static final String PROCESS_ID = "process_id";
    public static final String PLANNED_EVENT_ID = "plannedEvent_id";
    public static final String EVENT_ID = "event_id";
    public static final String CORRELATION_TYPE = "correlationType_code";

    public ProcessEventDirectory() {
        super();
    }

    public static ProcessEventDirectory build(UUID id, UUID processId, UUID plannedEventId, UUID eventId, String correlationType) {
        ProcessEventDirectory ped = new ProcessEventDirectory();
        ped.setId(id);
        ped.setProcessId(processId);
        ped.setPlannedEventId(plannedEventId);
        ped.setEventId(eventId);
        ped.setCorrelationType(correlationType);
        return ped;
    }

    public ProcessEventDirectory(Map<String, IPropertyValue> internalValue) {
        super(internalValue);
    }

    public UUID getId() {
        return getValueAsUUID(ID);
    }

    public void setId(UUID id) {
        setValue(ID, id);
    }

    public UUID getProcessId() {
        return getValueAsUUID(PROCESS_ID);
    }

    public void setProcessId(UUID processId) {
        setValue(PROCESS_ID, processId);
    }

    public UUID getPlannedEventId() {
        return getValueAsUUID(PLANNED_EVENT_ID);
    }

    public void setPlannedEventId(UUID plannedEventId) {
        setValue(PLANNED_EVENT_ID, plannedEventId);
    }

    public UUID getEventId() {
        return getValueAsUUID(EVENT_ID);
    }

    public void setEventId(UUID eventId) {
        setValue(EVENT_ID, eventId);
    }

    public String getCorrelationType() {
        return getValueAsString(CORRELATION_TYPE);
    }

    public void setCorrelationType(String correlationType) {
        setValue(CORRELATION_TYPE, correlationType);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null) {
            return false;
        }
        if (this.getClass() != o.getClass()) {
            return false;
        }
        ProcessEventDirectory that = (ProcessEventDirectory) o;
        return Objects.equals(getId(), that.getId()) &&
                Objects.equals(getProcessId(), that.getProcessId()) &&
                Objects.equals(getPlannedEventId(), that.getPlannedEventId()) &&
                Objects.equals(getEventId(), that.getEventId()) &&
                Objects.equals(getCorrelationType(), that.getCorrelationType());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getProcessId(), getPlannedEventId(), getEventId(), getCorrelationType());
    }

}
