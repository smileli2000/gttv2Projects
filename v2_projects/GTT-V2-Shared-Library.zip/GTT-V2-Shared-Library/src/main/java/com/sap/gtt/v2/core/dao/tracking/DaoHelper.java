package com.sap.gtt.v2.core.dao.tracking;

import com.sap.gtt.v2.core.domain.metadata.*;
import com.sap.gtt.v2.core.entity.trackedprocess.PlannedEvent;
import com.sap.gtt.v2.core.entity.trackedprocess.ProcessEventDirectory;
import com.sap.gtt.v2.core.entity.trackedprocess.QualifiedTrackingId;
import com.sap.gtt.v2.core.entity.trackedprocess.Reference;
import com.sap.gtt.v2.core.management.metadata.CsnParser;
import com.sap.gtt.v2.core.runtime.model.IPropertyValue;
import com.sap.gtt.v2.core.runtime.model.ListValue;
import com.sap.gtt.v2.core.runtime.model.ObjectValue;
import com.sap.gtt.v2.log.TenantAwareLogService;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.*;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import static com.sap.gtt.v2.core.entity.trackedprocess.TrackedProcess.VERSION;

@Component
public class DaoHelper {
    private static final String QUALIFIED_TRACKING_ID = "com.sap.gtt.core.CoreModel.QualifiedTrackingId";
    private static final String PROCESS_EVENT_DIRECTORY = "com.sap.gtt.core.CoreModel.ProcessEventDirectory";
    private static final String REFERENCE = "com.sap.gtt.core.CoreModel.Reference";
    private static final String SQL_VALUES = "sql: {}, values{}";
    private static final String SQL = "sql:{}";
    private static final String MSG = "{},{}";
    private static final String WHERE = " where ";
    private static final String SELECT_COUNT_FROM = " select count(*) from ";
    private static final String UPDATE = " update ";
    private static final String SQL_PLACEHOLDER = " = ? ";
    private static final String INSERT_INTO = " insert into ";
    private static final String PAGE_NUM = "pageNum: ";
    private static final String PAGE_SIZE = "pageSize: ";
    private static final String SELECT_FROM = " select * from ";
    private static final String SELECT = " select ";
    private static final String AND = " and ";
    private static final String DELETE_FROM = " delete from ";
    private static final String ORDER_BY = " order by ";
    private static final String OFFSET = " offset ";
    private static final String LIMIT = " limit ";
    private static final String SET = " set ";
    private static final String VALUES = " values (";
    @Autowired
    private JdbcTemplate jdbcTemplate;

    public NamedParameterJdbcTemplate getNamedParameterJdbcTemplate() {
        return namedParameterJdbcTemplate;
    }

    @Autowired
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @Autowired
    private TenantAwareLogService logService;

    public <T extends ObjectValue> T insert(T t) {
        CurrentMetadataEntity metadata = t.getMetadata();
        PhysicalName physicalName = getPhysicalName(metadata);
        insertPhysicalTable(t, physicalName);
        insertExTable(t, metadata, physicalName);

        saveCompositions(t);
        return t;
    }

    private <T extends ObjectValue> void insertExTable(T t, CurrentMetadataEntity metadata, PhysicalName physicalName) {
        Pair<String, Object[]> res;
        if (isExtensionEntity(t)) {
            res = generateSqlForInsertOfExTable(physicalName.getName(), t);
            logService.debug(SQL_VALUES, res.getLeft(), res.getRight());
            final Object[] objs = res.getRight();
            jdbcTemplate.update(res.getLeft(), ps ->
                    setParameters(objs, ps)
            );
        } else {
            logService.debug("no extension table found for insert. {}", metadata.getCurrentEntityName());
        }
    }

    private <T extends ObjectValue> void insertPhysicalTable(T t, PhysicalName physicalName) {
        Pair<String, Object[]> res;
        if (StringUtils.isNotEmpty(physicalName.getCorePhysicalName())) {
            res = generateSqlForInsert(physicalName.getCorePhysicalName(), t);
            logService.debug(SQL_VALUES, res.getLeft(), res.getRight());
            final Object[] objs = res.getRight();
            jdbcTemplate.update(res.getLeft(), ps ->
                    setParameters(objs, ps)
            );
        } else if (StringUtils.isNotEmpty(physicalName.getName())) {
            res = generateSqlForInsert(physicalName.getName(), t);
            logService.debug(SQL_VALUES, res.getLeft(), res.getRight());
            final Object[] objs = res.getRight();
            jdbcTemplate.update(res.getLeft(), ps ->
                    setParameters(objs, ps)
            );
        } else {
            logService.debug("no table found in core model and standalone model for insert. {}", t.getMetadata().getCurrentEntityName());
        }
    }

    protected <T extends ObjectValue> boolean isIncludeCustomizedFields(T t) {
        return t.getMetadata().getCurrentEntity().isIncludeCustomizedFields();
    }

    protected <T extends ObjectValue> boolean isExtensionEntity(T t) {
        return t.getMetadata().getCurrentEntity().getPhysicalName().isExtensionEntity();
    }

    protected <T extends ObjectValue> boolean hasCoreTable(T t) {
        return StringUtils.isNotEmpty(t.getMetadata().getCurrentEntity().getPhysicalName().getCorePhysicalName());
    }

    protected PhysicalName getPhysicalName(CurrentMetadataEntity metadata) {
        MetadataEntity metadataEntity = metadata.getCurrentEntity();
        return metadataEntity.getPhysicalName();
    }

    public <T extends ObjectValue> T update(T t) {
        return update(t, null);
    }

    public <T extends ObjectValue> T update(T t, Integer version) {
        PhysicalName physicalName = getPhysicalName(t.getMetadata());
        updatePhysicalTable(t, version, physicalName);

        updateExTable(t, physicalName);
        saveCompositions(t);
        return t;
    }

    private <T extends ObjectValue> void updateExTable(T t, PhysicalName physicalName) {
        Pair<String, Object[]> res;
        if (isExtensionEntity(t)) {
            res = generateSqlForUpdateOfExTable(physicalName, t, null);
            if (res != null) {
                logService.debug(SQL_VALUES, res.getLeft(), res.getRight());
                final Object[] objs = res.getRight();
                jdbcTemplate.update(res.getLeft(), ps ->
                        setParameters(objs, ps)
                );
            }
        } else {
            logService.debug("no extension table found for update. {}", t.getMetadata().getCurrentEntityName());
        }
    }

    private <T extends ObjectValue> void updatePhysicalTable(T t, Integer version, PhysicalName physicalName) {
        Pair<String, Object[]> res;
        if (StringUtils.isNotEmpty(physicalName.getCorePhysicalName())) {
            res = generateSqlForUpdate(physicalName.getCorePhysicalName(), t, null, version, false);
            logService.debug(SQL_VALUES, res.getLeft(), res.getRight());
            final Object[] objs = res.getRight();
            jdbcTemplate.update(res.getLeft(), ps ->
                    setParameters(objs, ps)
            );
            if (physicalName.isCoreExtensionEntity()) {
                res = generateSqlForUpdate(physicalName.getExtendedPhysicalName(), t, null, version, true);
                logService.debug(SQL_VALUES, res.getLeft(), res.getRight());
                final Object[] objsForCoreEx = res.getRight();
                jdbcTemplate.update(res.getLeft(), ps ->
                        setParameters(objsForCoreEx, ps)
                );
            }
        } else if (StringUtils.isNotEmpty(physicalName.getName())) {
            res = generateSqlForUpdate(physicalName.getName(), t, null, version, false);
            logService.debug(SQL_VALUES, res.getLeft(), res.getRight());
            final Object[] objs = res.getRight();
            jdbcTemplate.update(res.getLeft(), ps ->
                    setParameters(objs, ps)
            );
        } else {
            logService.debug("no table found in core model and standalone model for update. {}", t.getMetadata().getCurrentEntityName());
        }
    }

    private static void setParameters(Object[] objs, PreparedStatement ps) throws SQLException {
        for (int i = 0; i < objs.length; i++) {
            ps.setObject(i + 1, objs[i]);
        }
    }

    public <T extends ObjectValue> T save(T t) {
        if (exists(t)) {
            update(t);
        } else {
            insert(t);
        }
        saveCompositions(t);
        return t;
    }

    protected void saveCompositions(ObjectValue t) {
        Map<String, MetadataEntityElement> compositions = getCompositions(t.getMetadata());
        if (compositions != null) {
            for (MetadataEntityElement composition : compositions.values()) {
                saveEachComposition(t, composition);
            }
        }
    }

    private void saveEachComposition(ObjectValue t, MetadataEntityElement composition) {
        //!composition.isFromCoreModel()
        if (!CsnParser.isCoreModelEntity(composition.getTarget())) {
            List<IPropertyValue> compositionValues = t.isValueProvided(composition.getName()) ? t.getValueAsList(composition.getName()) : null;
            if (compositionValues != null) {
                for (IPropertyValue propertyValue : compositionValues) {
                    ObjectValue objectValue = (ObjectValue) propertyValue;
                    this.save(objectValue);
                }
            }
        } else {
            logService.debug("core model compositions will be handled at mgmt level {}", composition);
        }
    }

    @Transactional
    public <T extends ObjectValue> List<T> save(Iterable<T> entities) {
        List<T> list = new ArrayList<>();
        for (T t : entities) {
            list.add(save(t));
        }
        return list;
    }

    public <T extends ObjectValue> T updateSingleField(CurrentMetadataEntity metadata, T t, String fieldName) {
        return updateFields(metadata, t, fieldName);
    }

    public <T extends ObjectValue> T updateFields(CurrentMetadataEntity metadata, T t, String... fieldNames) {
        PhysicalName physicalName = getPhysicalName(metadata);
        Pair<String, Object[]> res = generateSqlForUpdate(physicalName.getName(), t, fieldNames);
        logService.debug(SQL_VALUES, res.getLeft(), res.getRight());
        final Object[] objs = res.getRight();
        jdbcTemplate.update(res.getLeft(), ps ->
                setParameters(objs, ps)
        );
        return t;
    }

    public long count(CurrentMetadataEntity metadata, String where, Object... parameters) {
        PhysicalName physicalName = getPhysicalName(metadata);
        String sql = generateSqlForCount(where, physicalName.getName());
        logService.debug(SQL_VALUES, sql, parameters);
        final Object[] objs = parameters.clone(); // to fix sonar
        return jdbcTemplate.query(sql, ps ->
                        setParameters(objs, ps)
                , rs -> {
                    if (rs.next()) {
                        return rs.getLong(1);
                    }
                    return 0L;
                });
    }

    public long count(CurrentMetadataEntity metadata, String where, MapSqlParameterSource namedParameters) {
        PhysicalName physicalName = getPhysicalName(metadata);
        return namedParameterJdbcTemplate.queryForObject(generateSqlForCount(where, physicalName.getName()),
                namedParameters, Long.class);
    }

    public <PKTYPE extends Serializable> boolean exists(CurrentMetadataEntity metadata, PKTYPE id) {
        return count(metadata, getPrimaryKeyColumn(metadata) + SQL_PLACEHOLDER, id) > 0;
    }

    public <T extends ObjectValue, PKTYPE extends Serializable> boolean exists(T t) {
        Map<String, Object> pks = getPrimaryKeyValues(t);
        if (pks.size() == 1) {
            return exists(t.getMetadata(), (PKTYPE) pks.values().iterator().next());
        } else if (pks.size() > 1) {
            Pair<String, Object[]> pair = generateWhereForPKs(pks);
            return count(t.getMetadata(), pair.getLeft(), pair.getRight()) > 0;
        } else {
            throw new IllegalArgumentException("cannot find primary keys of ");
        }
    }

    protected Pair<String, Object[]> generateWhereForPKs(Map<String, Object> pks) {
        StringBuilder whereBuilder = new StringBuilder();
        List<Object> objects = new ArrayList<>();
        for (Entry<String, Object> entry : pks.entrySet()) {
            if (!objects.isEmpty()) {
                whereBuilder.append(AND);
            }
            whereBuilder.append(entry.getKey()).append(SQL_PLACEHOLDER);
            objects.add(pks.get(entry.getKey()));
        }

        return Pair.of(whereBuilder.toString(), objects.toArray());
    }

    String getTableNameOfEntity(CurrentMetadataEntity metadata) {
        return getPhysicalName(metadata).getName();
    }

    public <T extends ObjectValue, PKTYPE extends Serializable> T findOneByPrimaryKey(Class<T> tClass, CurrentMetadataEntity metadata, PKTYPE id) {
        StringBuilder sbWhere = new StringBuilder(getTableNameOfEntity(metadata) + "." + getPrimaryKeyColumn(metadata)).append(" = ?");
        String sql = generateSqlForSelect(metadata, sbWhere.toString(), null, null, null);

        T res = jdbcTemplate.query(sql, rs -> {
            T t = null;
            if (rs.next()) {
                t = newInstance(tClass, metadata);
                extractData(rs, t);
            }
            return t;
        }, id);

        if (res != null) {
            fillCompositions(metadata, res);
        }

        return res;
    }

    protected void fillCompositions(CurrentMetadataEntity metadata, ObjectValue t) {
        Map<String, MetadataEntityElement> compositions = getCompositions(metadata);
        if (compositions != null) {
            for (MetadataEntityElement composition : compositions.values()) {
                CurrentMetadataEntity metadata1 = new CurrentMetadataEntity();
                metadata1.setAllRelatedEntityMap(metadata.getAllRelatedEntityMap());
                metadata1.setCurrentEntityName(composition.getTarget());
                Class clazz;
                if (StringUtils.containsIgnoreCase(composition.getTarget(), QUALIFIED_TRACKING_ID)) {
                    clazz = QualifiedTrackingId.class;
                } else if (StringUtils.equalsIgnoreCase(composition.getTarget(), MetadataConstants.CoreModelEntity.PLANNED_EVENT.getFullName())
                        || StringUtils.equalsIgnoreCase(composition.getTarget(), MetadataConstants.CoreModelEntity.PLANNED_EVENT_FOR_EVENT.getFullName())
                        || StringUtils.equalsIgnoreCase(composition.getTarget(), MetadataConstants.CoreModelEntity.PLANNED_EVENT_FOR_UPDATE_PLAN_EVENT.getFullName())) {
                    clazz = PlannedEvent.class;
                } else if (StringUtils.containsIgnoreCase(composition.getTarget(), PROCESS_EVENT_DIRECTORY)) {
                    clazz = ProcessEventDirectory.class;
                } else if (StringUtils.containsIgnoreCase(composition.getTarget(), REFERENCE)) {
                    clazz = Reference.class;
                } else {
                    clazz = ObjectValue.class;
                }

                List<ObjectValue> items = findAll(clazz, metadata1, composition.getForeignKey().getGeneratedFieldName() + " = ?", getPrimaryKeyValues(t).values().iterator().next());
                ListValue listValue = ListValue.valueOfEmpty();
                listValue.getInternalValue().addAll(items);
                t.setValue(composition.getName(), listValue);
            }
        }
    }

    public void extractData(ResultSet rs, ObjectValue t) throws SQLException {
        ResultSetMetaData metaData = rs.getMetaData();
        List<MetadataEntityElement> elements = t.getMetadata().getCurrentEntity().getElements();
        for (int i = 1; i <= metaData.getColumnCount(); ++i) {
            for (MetadataEntityElement element : elements) {
                if (element.getPhysicalName().equalsIgnoreCase(metaData.getColumnName(i))) {
                    t.setValue(element.getPhysicalName(), rs.getObject(i));
                    break;
                }
            }
        }
    }

    public <T extends ObjectValue> List<T> findAll(Class<T> tClass, CurrentMetadataEntity metadata) {
        return findAllInternal(tClass, metadata, null, null, null, null);
    }

    public <T extends ObjectValue> List<T> findAll(Class<T> tClass, CurrentMetadataEntity metadata, int pageNum, int pageSize) {
        return findAllInternal(tClass, metadata, null, null, pageNum, pageSize);
    }

    public <T extends ObjectValue> List<T> findAll(Class<T> tClass, CurrentMetadataEntity metadata, String where, Object... parameters) {
        return findAllInternal(tClass, metadata, where, null, null, null, parameters);
    }

    public <T extends ObjectValue> List<T> findAll(Class<T> tClass, CurrentMetadataEntity metadata, String where, MapSqlParameterSource namedParameters) {
        return findAllInternal(tClass, metadata, where, null, null, null, namedParameters);
    }

    public <T extends ObjectValue> List<T> findAll(Class<T> tClass, CurrentMetadataEntity metadata, int pageNum, int pageSize, String where, Object... parameters) {
        return findAllInternal(tClass, metadata, where, null, pageNum, pageSize, parameters);
    }

    public <T extends ObjectValue> List<T> findAll(Class<T> tClass, CurrentMetadataEntity metadata, int pageNum, int pageSize, String where, MapSqlParameterSource namedParameters) {
        return findAllInternal(tClass, metadata, where, null, pageNum, pageSize, namedParameters);
    }

    public <T extends ObjectValue> List<T> findAllWithOrderBy(Class<T> tClass, CurrentMetadataEntity metadata, String orderBy) {
        return findAllInternal(tClass, metadata, null, orderBy, null, null);
    }

    public <T extends ObjectValue> List<T> findAllWithOrderBy(Class<T> tClass, CurrentMetadataEntity metadata, String orderBy, String where, Object... parameters) {
        return findAllInternal(tClass, metadata, where, orderBy, null, null, parameters);
    }

    public <T extends ObjectValue> List<T> findAllWithOrderBy(Class<T> tClass, CurrentMetadataEntity metadata, String orderBy, int pageNum, int pageSize, String where, Object... parameters) {
        return findAllInternal(tClass, metadata, where, orderBy, pageNum, pageSize, parameters);
    }

    public <T extends ObjectValue> List<T> findAllWithOrderBy(Class<T> tClass, CurrentMetadataEntity metadata, String orderBy, int pageNum, int pageSize, String where, MapSqlParameterSource namedParameters) {
        return findAllInternal(tClass, metadata, where, orderBy, pageNum, pageSize, namedParameters);
    }

    protected <T extends ObjectValue> List<T> findAllInternal(Class<T> tClass, CurrentMetadataEntity metadata, String where, String orderBy, Integer pageNum, Integer pageSize, Object... parameters) {
        String sql = generateSqlForSelect(metadata, where, orderBy, pageNum, pageSize);
        logService.debug(SQL, sql);
        List<T> list = jdbcTemplate.query(sql, parameters, (rs, rowNum) -> {
            T t = newInstance(tClass, metadata);
            extractData(rs, t);
            return t;
        });

        for (T t : list) {
            fillCompositions(metadata, t);
        }

        return list;
    }

    protected <T extends ObjectValue> List<T> findAllInternal(Class<T> tClass, CurrentMetadataEntity metadata, String where, String orderBy, Integer pageNum, Integer pageSize, MapSqlParameterSource namedParameters) {
        String sql = generateSqlForSelect(metadata, where, orderBy, pageNum, pageSize);
        List<T> list = namedParameterJdbcTemplate.query(sql, namedParameters, (rs, rowNum) -> {
            T t = newInstance(tClass, metadata);
            extractData(rs, t);
            return t;
        });

        for (T t : list) {
            fillCompositions(metadata, t);
        }
        return list;
    }

    public <T extends ObjectValue> void delete(T t) {
        Map<String, MetadataEntityElement> compositions = getCompositions(t.getMetadata());
        if (compositions != null) {
            for (MetadataEntityElement composition : compositions.values()) {
                if (isNotCustomizedField(composition)) {
                    logService.debug("composition from core model will not be deleted here. {}", composition);
                    continue;
                }
                List<IPropertyValue> valueAsList = t.getValueAsList(composition.getName());
                for (IPropertyValue propertyValue : valueAsList) {
                    delete((ObjectValue) propertyValue);
                }
            }
        }

        Map<String, Object> pks = getPrimaryKeyValues(t);
        Pair<String, Object[]> pair = generateWhereForPKs(pks);
        deleteAll(t.getMetadata(), pair.getLeft(), pair.getRight());
    }

    private boolean isNotCustomizedField(MetadataEntityElement element) {
        return !element.isCustomizedField();
    }

    private boolean isCustomizedField(MetadataEntityElement element) {
        return element.isCustomizedField();
    }

    public <PKTYPE extends Serializable> void delete(CurrentMetadataEntity metadata, PKTYPE id) {
        ObjectValue objectValue = findOneByPrimaryKey(ObjectValue.class, metadata, id);
        delete(objectValue);
    }

    public void deleteAll(CurrentMetadataEntity metadata, String where, Object... parameters) {
        PhysicalName physicalName = getPhysicalName(metadata);
        boolean hasCoreModelName = StringUtils.isNotEmpty(physicalName.getCorePhysicalName());
        if ((hasCoreModelName && physicalName.isExtensionEntity())
                || !hasCoreModelName) {
            String sql = generateSqlForDelete(physicalName.getName(), where);
            logService.debug(MSG, sql, parameters);
            final Object[] objs = parameters.clone(); // to fix sonar
            jdbcTemplate.update(sql, objs);
        } else {
            logService.debug("no extension table found for delete. {}", metadata.getCurrentEntityName());
        }

        if (StringUtils.isNotEmpty(physicalName.getCorePhysicalName())) {
            String sql = generateSqlForDelete(physicalName.getCorePhysicalName(), where);
            logService.debug(MSG, sql, parameters);
            final Object[] objs = parameters.clone(); // to fix sonar
            jdbcTemplate.update(sql, ps ->
                    setParameters(objs, ps)
            );
        } else {
            logService.debug("no core model table found for delete. {}", metadata.getCurrentEntityName());
        }
    }

    public void deleteAll(String tableName, String where, MapSqlParameterSource namedParameters) {
        String sql = generateSqlForDelete(tableName, where);
        logService.debug(MSG, sql, namedParameters);
        namedParameterJdbcTemplate.update(sql, namedParameters);
    }

    protected String generateSqlForDelete(String tableName, String where) {
        StringBuilder sb = new StringBuilder(DELETE_FROM).append(tableName);
        if (StringUtils.isNotBlank(where)) {
            sb.append(WHERE).append(where);
        }
        return sb.toString();
    }

    protected String generateSqlForCount(String where, String tableName) {
        StringBuilder sb = new StringBuilder(SELECT_COUNT_FROM).append(tableName);
        if (StringUtils.isNotBlank(where)) {
            sb.append(WHERE).append(where);
        }
        return sb.toString();
    }

    protected <T extends ObjectValue> Pair<String, Object[]> generateSqlForUpdateOfExTable(PhysicalName physicalName, T t, String[] fields) {
        Map<String, MetadataEntityElement> elements = t.getMetadata().getCurrentEntity().getElementMap();
        StringBuilder sb = new StringBuilder(UPDATE).append(physicalName.getName())
                .append(SET);
        List<Object> objects = new ArrayList<>();
        for (Entry<String, IPropertyValue> entry : t.getInternalValue().entrySet()) {
            if ((fields == null || ArrayUtils.contains(fields, entry.getKey()))
                    && (entry.getValue() == null || entry.getValue().isCsnPrimitive())) {
                generateForEachEntry(elements, sb, objects, entry);
            }
        }
        if (objects.isEmpty()) {
            return null;
        }
        sb.append(WHERE).append(getPrimaryKeyColumn(t.getMetadata())).append(" = ?");
        objects.add(getPrimaryKeyValues(t).values().iterator().next());

        return Pair.of(sb.toString(), objects.toArray());

    }

    private void generateForEachEntry(Map<String, MetadataEntityElement> elements, StringBuilder sb, List<Object> objects, Entry<String, IPropertyValue> entry) {
        if (elements.containsKey(entry.getKey())) {
            MetadataEntityElement element = elements.get(entry.getKey());
            if (element.getType().equals(MetadataConstants.CdsDataType.CDS_COMPOSITION)) {
                return;
            }
            if (isCustomizedField(element)) {
                if (!objects.isEmpty()) {
                    sb.append(", ");
                }
                sb.append(entry.getKey()).append(SQL_PLACEHOLDER);
                objects.add(entry.getValue() == null ? null : entry.getValue().getInternalValue());
            }
        }
    }

    protected <T extends ObjectValue> Pair<String, Object[]> generateSqlForUpdate(String tableName, T t, String[] fields) {
        return generateSqlForUpdate(tableName, t, fields, null, false);
    }

    protected <T extends ObjectValue> Pair<String, Object[]> generateSqlForUpdate(String tableName, T t, String[] fields,
                                                                                  Integer version, boolean isCoreExtension) {
        Map<String, MetadataEntityElement> elements = t.getMetadata().getCurrentEntity().getElementMap();
        StringBuilder sb = new StringBuilder(UPDATE).append(tableName)
                .append(SET);
        List<Object> objects = new ArrayList<>();
        for (Entry<String, IPropertyValue> entry : t.getInternalValue().entrySet()) {
            if ((fields == null || ArrayUtils.contains(fields, entry.getKey()))
                    && (entry.getValue() == null || entry.getValue().isCsnPrimitive())) {
                generateSqlForEachEntry(t, elements, sb, objects, entry, isCoreExtension);
            }
        }

        Map<String, Object> pks = getPrimaryKeyValues(t);
        if (pks.size() > 1) {
            Pair<String, Object[]> pairPk = generateWhereForPKs(pks);
            sb.append(WHERE)
                    .append(pairPk.getLeft());
            objects.addAll(Arrays.asList(pairPk.getRight()));
        } else {
            sb.append(WHERE).append(getPrimaryKeyColumn(t.getMetadata())).append(SQL_PLACEHOLDER);
            objects.add(getPrimaryKeyValues(t).values().iterator().next());
        }

        if (version != null) {
            sb.append(AND).append(VERSION).append(SQL_PLACEHOLDER);
            objects.add(version);
        }

        return Pair.of(sb.toString(), objects.toArray());
    }

    private <T extends ObjectValue> void generateSqlForEachEntry(T t, Map<String, MetadataEntityElement> elements, StringBuilder sb,
                                                                 List<Object> objects, Entry<String, IPropertyValue> entry, boolean isCoreExtension) {
        if (elements.containsKey(entry.getKey())) {
            MetadataEntityElement element = elements.get(entry.getKey());
            if (element.getType().equals(MetadataConstants.CdsDataType.CDS_COMPOSITION)) {
                return;
            }
            if ((hasCoreTable(t) && (!isCoreExtension && isNotCustomizedField(element) || (isCoreExtension && !isNotCustomizedField(element)))) ||
                    !hasCoreTable(t)) {
                if (!objects.isEmpty()) {
                    sb.append(", ");
                }
                sb.append(entry.getKey()).append(SQL_PLACEHOLDER);
                objects.add(entry.getValue() == null ? null : entry.getValue().getInternalValue());
            }
        }
    }

    public <T extends ObjectValue> Pair<String, Object[]> generateSqlForInsert(String tableName, T t) {
        Map<String, MetadataEntityElement> elements = t.getMetadata().getCurrentEntity().getElementMap();
        StringBuilder sb = new StringBuilder(INSERT_INTO).append(tableName);
        List<Object> objects = new ArrayList<>();
        StringBuilder sbNames = new StringBuilder(" (");
        StringBuilder sbPlaceHolders = new StringBuilder(VALUES);

        for (Entry<String, IPropertyValue> entry : t.getInternalValue().entrySet()) {
            if ((entry.getValue() == null || entry.getValue().isCsnPrimitive())
                    && elements.containsKey(entry.getKey())) {
                generateSqlForEachEntry(t, elements, objects, sbNames, sbPlaceHolders, entry);
            }
        }
        sbNames.append(") ");
        sbPlaceHolders.append(") ");
        sb.append(sbNames);
        sb.append(sbPlaceHolders);
        return Pair.of(sb.toString(), objects.toArray());
    }

    private <T extends ObjectValue> void generateSqlForEachEntry(T t, Map<String, MetadataEntityElement> elements, List<Object> objects, StringBuilder sbNames, StringBuilder sbPlaceHolders, Entry<String, IPropertyValue> entry) {
        MetadataEntityElement element = elements.get(entry.getKey());
        if (element.getType().equals(MetadataConstants.CdsDataType.CDS_COMPOSITION)) {
            return;
        }
        if ((hasCoreTable(t) && isNotCustomizedField(element)) || !hasCoreTable(t)) {
            if (!objects.isEmpty()) {
                sbNames.append(", ");
                sbPlaceHolders.append(", ");
            }

            sbNames.append(entry.getKey());
            sbPlaceHolders.append("?");
            objects.add(entry.getValue() == null ? null : entry.getValue().getInternalValue());
        }
    }

    /**
     * For Core Model Tables and its extension tables
     *
     * @param tableName
     * @param t
     * @param <T>
     * @return
     */
    public <T extends ObjectValue> Pair<String, Object[]> generateSqlForBatchInsert(String tableName, T t, boolean isExtension) {
        Map<String, MetadataEntityElement> elements = t.getMetadata().getCurrentEntity().getElementMap();
        StringBuilder sb = new StringBuilder(INSERT_INTO).append(tableName);
        List<Object> objects = new ArrayList<>();
        StringBuilder sbNames = new StringBuilder(" (");
        StringBuilder sbPlaceHolders = new StringBuilder(VALUES);

        for (MetadataEntityElement element : elements.values()) {
            generateSqlForEachEntry(t, objects, sbNames, sbPlaceHolders, element, isExtension);
        }
        sbNames.append(") ");
        sbPlaceHolders.append(") ");
        sb.append(sbNames);
        sb.append(sbPlaceHolders);
        return Pair.of(sb.toString(), objects.toArray());
    }

    private <T extends ObjectValue> void generateSqlForEachEntry(T t, List<Object> objects,
                                                                 StringBuilder sbNames, StringBuilder sbPlaceHolders,
                                                                 MetadataEntityElement element, boolean isExtension) {
        if (element.getType().equals(MetadataConstants.CdsDataType.CDS_COMPOSITION)
                || element.getType().equals(MetadataConstants.CdsDataType.CDS_ASSOCIATION)) {
            return;
        }
        IPropertyValue propertyValue;
        if (t.isValueProvided(element.getPhysicalName())) {
            propertyValue = t.getValue(element.getPhysicalName());
        } else {
            propertyValue = null;
        }

        if (hasCoreTable(t) && (element.isKey() || (!isExtension && isNotCustomizedField(element)) || (isExtension && !isNotCustomizedField(element)))) {
            if (!objects.isEmpty()) {
                sbNames.append(", ");
                sbPlaceHolders.append(", ");
            }
            sbNames.append(element.getPhysicalName());
            sbPlaceHolders.append("?");
            objects.add(propertyValue == null ? null : propertyValue.getInternalValue());
        }
    }

    private <T extends ObjectValue> Pair<String, Object[]> generateSqlForInsertOfExTable(String tableName, T t) {
        Map<String, MetadataEntityElement> elements = t.getMetadata().getCurrentEntity().getElementMap();
        StringBuilder sb = new StringBuilder(INSERT_INTO).append(tableName);
        List<Object> objects = new ArrayList<>();
        StringBuilder sbNames = new StringBuilder(" (");
        StringBuilder sbPlaceHolders = new StringBuilder(VALUES);

        for (Entry<String, IPropertyValue> entry : t.getInternalValue().entrySet()) {
            if (entry.getValue() == null || entry.getValue().isCsnPrimitive()) {
                generateSqlForEachEntry(elements, objects, sbNames, sbPlaceHolders, entry);
            }
        }
        sbNames.append(") ");
        sbPlaceHolders.append(") ");
        sb.append(sbNames);
        sb.append(sbPlaceHolders);
        return Pair.of(sb.toString(), objects.toArray());

    }

    private void generateSqlForEachEntry(Map<String, MetadataEntityElement> elements, List<Object> objects, StringBuilder sbNames, StringBuilder sbPlaceHolders, Entry<String, IPropertyValue> entry) {
        if (elements.containsKey(entry.getKey())) {
            MetadataEntityElement element = elements.get(entry.getKey());
            if (element.getType().equals(MetadataConstants.CdsDataType.CDS_COMPOSITION)) {
                return;
            }
            if (isCustomizedField(element) || element.isKey()) {
                if (!objects.isEmpty()) {
                    sbNames.append(", ");
                    sbPlaceHolders.append(", ");
                }
                sbNames.append(entry.getKey());
                sbPlaceHolders.append("?");
                objects.add(entry.getValue() == null ? null : entry.getValue().getInternalValue());
            }
        }
    }

    private String generateSqlForSelect(CurrentMetadataEntity metadata, String where, String orderBy, Integer pageNum, Integer pageSize) {
        if (pageNum != null && pageNum < 0) {
            throw new IllegalArgumentException(PAGE_NUM + pageNum);
        }
        if (pageSize != null && pageSize <= 0) {
            throw new IllegalArgumentException(PAGE_SIZE + pageSize);
        }
        PhysicalName physicalName = getPhysicalName(metadata);
        StringBuilder sb = new StringBuilder(SELECT_FROM).append(
                physicalName.getName())
                .append(prepareInnerJoinIfExists(physicalName))
                .append(prepareInnerJoinCoreExIfExists(physicalName));
        if (StringUtils.isNotBlank(where)) {
            sb.append(WHERE).append(where);
        }
        if (StringUtils.isNotBlank(orderBy)) {
            sb.append(ORDER_BY).append(orderBy);
        }
        if (pageSize != null) {
            sb.append(LIMIT).append(pageSize);
        }
        if (pageNum != null) {
            if (pageSize == null || pageSize < 0) {
                throw new IllegalArgumentException(PAGE_SIZE + pageSize);
            }
            sb.append(OFFSET).append(pageSize * pageNum);
        }

        return sb.toString();
    }

    public <T extends ObjectValue> boolean versionExists(T t, int version) {
        PhysicalName physicalName = getPhysicalName(t.getMetadata());
        StringBuilder sb = new StringBuilder(SELECT).append(VERSION).append(" from ")
                .append(physicalName.getCorePhysicalName());

        Map<String, Object> pks = getPrimaryKeyValues(t);
        List<Object> objects = new ArrayList<>();
        if (pks.size() > 1) {
            Pair<String, Object[]> pairPk = generateWhereForPKs(pks);
            sb.append(WHERE)
                    .append(pairPk.getLeft());
            objects.addAll(Arrays.asList(pairPk.getRight()));
        } else {
            sb.append(WHERE).append(getPrimaryKeyColumn(t.getMetadata())).append(" = ?");
            objects.add(getPrimaryKeyValues(t).values().iterator().next());
        }
        sb.append(AND).append(VERSION).append(SQL_PLACEHOLDER)
                .append(" for update nowait");
        objects.add(version);

        logService.debug(SQL_VALUES, sb.toString(), objects);
        int version1 = jdbcTemplate.query(sb.toString(), ps -> {
            for (int i = 0; i < objects.size(); i++) {
                ps.setObject(i + 1, objects.get(i));
            }
        }, rs -> {
            if (rs.next()) {
                return rs.getInt(VERSION);
            }
            return -1;
        });

        return version1 >= 0;
    }

    protected String prepareInnerJoinIfExists(PhysicalName physicalName) {
        if (physicalName.isExtensionEntity() && StringUtils.isNotEmpty(physicalName.getCorePhysicalName())) {
            return new StringBuilder(" inner join ").append(physicalName.getCorePhysicalName())
                    .append(" on ").append(physicalName.getCorePhysicalName())
                    .append(".ID = ").append(physicalName.getName())
                    .append(".ID ").toString();
        }
        return "";
    }

    protected String prepareInnerJoinCoreExIfExists(PhysicalName physicalName) {
        if (physicalName.isCoreExtensionEntity() && StringUtils.isNotEmpty(physicalName.getExtendedPhysicalName())) {
            return new StringBuilder(" inner join ").append(physicalName.getExtendedPhysicalName())
                    .append(" on ").append(physicalName.getExtendedPhysicalName())
                    .append(".ID = ").append(physicalName.getName())
                    .append(".ID ").toString();
        }
        return "";
    }

    Map<String, MetadataEntityElement> findAllPrimaryKeysOfEntity(CurrentMetadataEntity metadata) {
        return metadata.getCurrentEntity().getElementMap().
                entrySet().stream().filter(e -> e.getValue().isKey() && e.getValue().getType() != MetadataConstants.CdsDataType.CDS_ASSOCIATION)
                .collect(Collectors.toMap(Entry::getKey, Entry::getValue));
    }

    protected String getPrimaryKeyColumn(CurrentMetadataEntity metadata) {
        Map<String, MetadataEntityElement> primaryKeys = findAllPrimaryKeysOfEntity(metadata);
        if (primaryKeys.size() > 1) {
            throw new IllegalArgumentException("multiple primary keys found for " + metadata.getCurrentEntityName());
        }
        return primaryKeys.values().iterator().next().getPhysicalName();
    }


    protected Map<String, Object> getPrimaryKeyValues(ObjectValue t) {
        CurrentMetadataEntity metadata = t.getMetadata();
        Map<String, MetadataEntityElement> primaryKeys = findAllPrimaryKeysOfEntity(metadata);
        Map<String, Object> values = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
        for (String propertyName : primaryKeys.keySet()) {
            values.put(propertyName, t.isValueProvided(propertyName) ? t.getValue(propertyName).getInternalValue() : null);
        }
        return values;
    }

    protected Map<String, MetadataEntityElement> getCompositions(CurrentMetadataEntity metadata) {
        Map<String, MetadataEntityElement> compositions = new HashMap<>();
        List<MetadataEntityElement> elements = metadata.getCurrentEntity().getElements();
        for (MetadataEntityElement element : elements) {
            if (element.getType().equals(MetadataConstants.CdsDataType.CDS_COMPOSITION)) {
                compositions.put(element.getName(), element);
            }
        }
        return compositions;
    }

    protected Map<String, MetadataEntityElement> getAssociations(CurrentMetadataEntity metadata) {
        Map<String, MetadataEntityElement> associations = new HashMap<>();
        List<MetadataEntityElement> elements = metadata.getCurrentEntity().getElements();
        for (MetadataEntityElement element : elements) {
            if (element.getType().equals(MetadataConstants.CdsDataType.CDS_ASSOCIATION)) {
                associations.put(element.getName(), element);
            }
        }
        return associations;
    }

    Map<String, MetadataEntityElement> findAllFieldsOfEntity(CurrentMetadataEntity metadata) {
        return metadata.getCurrentEntity().getElementMap();
    }

    protected <T extends ObjectValue> T newInstance(Class<T> tClass, CurrentMetadataEntity metadata) {
        try {
            T t = tClass.newInstance();
            if (t.getMetadata() == null) {
                t.setMetadata(metadata);
            }
            return t;
        } catch (InstantiationException | IllegalAccessException e) {
            logService.error("newInstance failed.", e);
        }

        return null;
    }

    public JdbcTemplate getJdbcTemplate() {
        return jdbcTemplate;
    }
}

