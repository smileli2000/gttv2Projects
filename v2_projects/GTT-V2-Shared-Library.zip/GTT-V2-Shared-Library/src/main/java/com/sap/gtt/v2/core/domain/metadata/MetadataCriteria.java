package com.sap.gtt.v2.core.domain.metadata;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class MetadataCriteria {
    private String id;
    private List<String> namespaces = new ArrayList<>();
    private String eventType;
    private List<String> trackedProcessTypes = new ArrayList<>();
    private String applicationObjectType;
    private String status;
    private boolean containProjectFileInfo = false;
    private String trackingIdType;

    public String getTrackingIdType() {
        return trackingIdType;
    }

    public void setTrackingIdType(String trackingIdType) {
        this.trackingIdType = trackingIdType;
    }


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public List<String> getNamespaces() {
        return new ArrayList<>(namespaces);
    }

    public void addNamespace(String namespace) {
        namespaces.add(namespace);
    }

    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    public List<String> getTrackedProcessTypes() {
        return new ArrayList<>(trackedProcessTypes);
    }

    public void addTrackedProcessType(String trackedProcessType) {
        trackedProcessTypes.add(trackedProcessType);
    }

    public String getApplicationObjectType() {
        return applicationObjectType;
    }

    public void setApplicationObjectType(String applicationObjectType) {
        this.applicationObjectType = applicationObjectType;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public boolean isContainProjectFileInfo() {
        return containProjectFileInfo;
    }

    public void setContainProjectFileInfo(boolean containProjectFileInfo) {
        this.containProjectFileInfo = containProjectFileInfo;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        MetadataCriteria criteria = (MetadataCriteria) o;
        return containProjectFileInfo == criteria.containProjectFileInfo &&
                Objects.equals(id, criteria.id) &&
                Objects.equals(namespaces, criteria.namespaces) &&
                Objects.equals(eventType, criteria.eventType) &&
                Objects.equals(trackedProcessTypes, criteria.trackedProcessTypes) &&
                Objects.equals(applicationObjectType, criteria.applicationObjectType) &&
                Objects.equals(trackingIdType, criteria.trackingIdType) &&
                Objects.equals(status, criteria.status);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, namespaces, eventType, trackedProcessTypes, applicationObjectType, status, containProjectFileInfo, trackingIdType);
    }
}
