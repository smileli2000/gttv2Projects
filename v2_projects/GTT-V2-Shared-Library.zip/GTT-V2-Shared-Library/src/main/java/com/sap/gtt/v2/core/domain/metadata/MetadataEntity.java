package com.sap.gtt.v2.core.domain.metadata;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.sap.gtt.v2.exception.JsonParseException;
import com.sap.gtt.v2.exception.MetadataException;
import com.sap.gtt.v2.util.DBUtils;
import com.sap.gtt.v2.util.JsonUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.util.ReflectionUtils;

import java.io.Serializable;
import java.lang.reflect.Field;
import java.time.Duration;
import java.time.format.DateTimeParseException;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static com.sap.gtt.v2.core.domain.metadata.MetadataConstants.CORE_MODEL_UNPLANNED_EVENTS;
import static com.sap.gtt.v2.core.domain.metadata.MetadataConstants.EntityBaseType.TRACKED_PROCESS;
import static com.sap.gtt.v2.exception.JsonParseException.MESSAGE_CODE_ERROR_DURATION_PARSE;

/**
 * Abstract for entities in derived CSN
 *
 * @author I321712
 */
public class MetadataEntity implements Serializable {
    private static final long serialVersionUID = -3759308165561433839L;

    private static String regEx = " (.) ";
    private static String dotExp = "\\.";

    private String name;
    private PhysicalName physicalName;
    private String baseType;
    private boolean processEvent;
    private boolean includeCustomizedFields;
    private String plannedEventsStr;
    private String unplannedEventsStr;
    private String inheritFromCore;
    private List<MetadataEntityEvent> plannedEvents = new ArrayList<>();
    private List<MetadataEntityEvent> unplannedEvents = new ArrayList<>();
    private String applicationObjectType;
    private String trackingIdType;
    private List<MetadataEntityElement> elements = new ArrayList<>();
    private String authorizationsStr;
    private List<Authorization> authorizations = new ArrayList<>();
    private String extendedPlanName;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return physical name of the entity
     */
    public PhysicalName getPhysicalName() {
        if (physicalName == null) {
            physicalName = DBUtils.getPhysicalName(getName(), getBaseType(), isIncludeCustomizedFields(),
                    getExtendedPlanName());
        }
        return physicalName;
    }

    public String getBaseType() {
        return baseType;
    }

    public void setBaseType(String baseType) {
        this.baseType = baseType;
    }

    public boolean isProcessEvent() {
        return processEvent;
    }

    public void setProcessEvent(boolean processEvent) {
        this.processEvent = processEvent;
    }

    public boolean isIncludeCustomizedFields() {
        return includeCustomizedFields;
    }

    public void setIncludeCustomizedFields(boolean includeCustomizedFields) {
        this.includeCustomizedFields = includeCustomizedFields;
    }

    public List<MetadataEntityEvent> getPlannedEvents() {
        return new ArrayList<>(plannedEvents);
    }

    public void initListProperties() {
        setEvents(getPlannedEventsStr(), plannedEvents);
        setEvents(getUnplannedEventsStr(), unplannedEvents);
        addCoreModelUnplannedEvents(unplannedEvents);
        setAuthorizations(getAuthorizationsStr(), authorizations);
        this.plannedEventsStr = null;
        this.unplannedEventsStr = null;
        this.authorizationsStr = null;
    }

    private void addCoreModelUnplannedEvents(final List<MetadataEntityEvent> unplannedEvents) {
        if (!TRACKED_PROCESS.getValue().equalsIgnoreCase(getBaseType())) {
            return;
        }
        CORE_MODEL_UNPLANNED_EVENTS.forEach(e -> {
            if (!unplannedEvents.contains(e)) {
                unplannedEvents.add(e);
            }
        });
    }

    private void setAuthorizations(String authStr, List<Authorization> authorizations) {
        if (StringUtils.isNotBlank(authStr) && authorizations.isEmpty()) {
            JsonArray jsonArray = JsonUtils.generateJsonElementFromString(authStr).getAsJsonArray();
            for (int i = 0; i < jsonArray.size(); i++) {
                Authorization authorization = JsonUtils.generateBeanFromJsonElement(jsonArray.get(i), Authorization.class);
                if (authorization != null) {
                    authorizations.add(authorization);
                }
            }
        }
    }


    private void setEvents(String eventsSource, List<MetadataEntityEvent> events) {
        if (StringUtils.isNotBlank(eventsSource) && events.isEmpty()) {
            JsonArray jsonArray = JsonUtils.generateJsonElementFromString(eventsSource).getAsJsonArray();
            for (int i = 0; i < jsonArray.size(); i++) {
                JsonObject eventObj = jsonArray.get(i).getAsJsonObject();
                addEvent(events, eventObj);
            }
        }
    }

    private void addEvent(List<MetadataEntityEvent> events, JsonObject eventObj) {
        MetadataEntityEvent event = new MetadataEntityEvent();
        JsonElement eventType = eventObj.get("eventType");
        event.setEventType(JsonUtils.isNull(eventType) ? null : eventType.getAsString());
        setDurationValue(event, eventObj, "businessToleranceValue");
        setDurationValue(event, eventObj, "technicalToleranceValue");
        JsonElement maxOverdueDetection = eventObj.get("maxOverdueDetection");
        if (!JsonUtils.isNull(maxOverdueDetection)) {
            event.setMaxOverdueDetection(maxOverdueDetection.getAsInt());
        }
        setDurationValue(event, eventObj, "periodicOverdueDetection");
        JsonElement matchLocation = eventObj.get("matchLocation");
        if (!JsonUtils.isNull(matchLocation)) {
            event.setMatchLocation(matchLocation.getAsBoolean());
        }
        setMatchExtensionFields(event, eventObj.get("matchExtensionFields"));
        events.add(event);
    }

    private void setDurationValue(MetadataEntityEvent event, JsonObject eventObj, String fieldName) {
        JsonElement periodicOverdueDetection = eventObj.get(fieldName);
        if (!JsonUtils.isNull(periodicOverdueDetection)) {
            String detection = periodicOverdueDetection.getAsString();
            try {
                Duration duration = Duration.parse(detection);
                Field field = MetadataEntityEvent.METADATA_ENTITY_EVENT_FIELD_MAP.get(fieldName);
                if (field == null) {
                    return;
                }
                ReflectionUtils.makeAccessible(field);
                ReflectionUtils.setField(field, event, duration);
            } catch (DateTimeParseException e) {
                throw new JsonParseException(e, MESSAGE_CODE_ERROR_DURATION_PARSE, new Object[]{detection, fieldName});
            }
        }
    }

    private void setMatchExtensionFields(MetadataEntityEvent event, JsonElement matchExtensionFieldsElement) {
        if (!JsonUtils.isNull(matchExtensionFieldsElement)) {
            JsonArray asJsonArray = matchExtensionFieldsElement.getAsJsonArray();
            asJsonArray.forEach(e -> {
                MatchExtensionField matchExtensionField = new MatchExtensionField();
                String fieldString = e.getAsString();
                //PlanEvent.mode = POGoodsReceivedEvent.mode

                Pattern pat = Pattern.compile(regEx);
                Matcher mat = pat.matcher(fieldString);
                if (mat.find()) {
                    matchExtensionField.setOperator(mat.group(0).trim());
                }
                String[] strs = fieldString.split(regEx);
                String[] sourceInfo = strs[0].split(dotExp);
                matchExtensionField.setSourceObject(sourceInfo[0]);
                matchExtensionField.setSourceField(sourceInfo[1]);
                String[] targetInfo = strs[1].split(dotExp);
                matchExtensionField.setTargetObject(targetInfo[0]);
                matchExtensionField.setTargetField(targetInfo[1]);
                event.addMatchExtensionField(matchExtensionField);
            });

        }
    }

    public void addPlannedEvent(MetadataEntityEvent plannedEvent) {
        this.plannedEvents.add(plannedEvent);
    }

    public List<MetadataEntityEvent> getUnplannedEvents() {
        return new ArrayList<>(unplannedEvents);
    }

    public void addUnplannedEvent(MetadataEntityEvent unplannedEvent) {
        this.unplannedEvents.add(unplannedEvent);
    }

    public String getPlannedEventsStr() {
        return plannedEventsStr;
    }

    public void setPlannedEventsStr(String plannedEventsStr) {
        this.plannedEventsStr = plannedEventsStr;
        setEvents(this.plannedEventsStr, plannedEvents);
    }

    public String getUnplannedEventsStr() {
        return unplannedEventsStr;
    }

    public void setUnplannedEventsStr(String unplannedEventsStr) {
        this.unplannedEventsStr = unplannedEventsStr;
        setEvents(this.unplannedEventsStr, unplannedEvents);
    }


    public String getInheritFromCore() {
        return inheritFromCore;
    }

    public void setInheritFromCore(String inheritFromCore) {
        this.inheritFromCore = inheritFromCore;
    }

    public String getApplicationObjectType() {
        return applicationObjectType;
    }

    public void setApplicationObjectType(String applicationObjectType) {
        this.applicationObjectType = applicationObjectType;
    }

    public String getTrackingIdType() {
        return trackingIdType;
    }

    public void setTrackingIdType(String trackingIdType) {
        this.trackingIdType = trackingIdType;
    }

    public List<MetadataEntityElement> getElements() {
        return new ArrayList<>(elements);
    }

    public void addElement(MetadataEntityElement element) {
        this.elements.add(element);
    }

    public void clearElements() {
        this.elements.clear();
    }

    public String getAuthorizationsStr() {
        return authorizationsStr;
    }

    public void setAuthorizationsStr(String authorizationsStr) {
        this.authorizationsStr = authorizationsStr;
    }

    public List<Authorization> getAuthorizations() {
        return new ArrayList<>(authorizations);
    }

    public void addAuthorization(Authorization authorization) {
        this.authorizations.add(authorization);
    }

    public void clearAuthorizations() {
        this.authorizations.clear();
    }

    public String getExtendedPlanName() {
        return extendedPlanName;
    }

    public void setExtendedPlanName(String extendedPlanName) {
        this.extendedPlanName = extendedPlanName;
    }

    public Map<String, MetadataEntityElement> getElementMap() {
        return elements.stream().collect(Collectors.toMap(MetadataEntityElement::getName, v -> v));
    }

    public MetadataEntityElement getPropertyMetadata(String propertyName) {
        MetadataEntityElement result = this.getElementMap().get(propertyName);
        if (result == null) {
            throw new MetadataException(MetadataException.MESSAGE_CODE_PROPERTY_NOT_FOUND, new Object[]{propertyName});
        }

        return result;

    }

    public boolean containsProperty(String propertyName) {
        return this.getElementMap().containsKey(propertyName);
    }

    public List<MetadataEntityElement> getPrimarykeys() {
        return elements.stream()
                .filter(MetadataEntityElement::isKey)
                .collect(Collectors.toList());
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        MetadataEntity entity = (MetadataEntity) o;
        return name.equals(entity.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name);
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", MetadataEntity.class.getSimpleName() + "[", "]")
                .add("name='" + name + "'")
                .add("baseType='" + baseType + "'")
                .add("processEvent=" + processEvent)
                .add("includeCustomizedFields=" + includeCustomizedFields)
                .add("applicationObjectType='" + applicationObjectType + "'")
                .add("trackingIdType='" + trackingIdType + "'")
                .add("inheritFromCore='" + inheritFromCore + "'")
                .toString();
    }
}
