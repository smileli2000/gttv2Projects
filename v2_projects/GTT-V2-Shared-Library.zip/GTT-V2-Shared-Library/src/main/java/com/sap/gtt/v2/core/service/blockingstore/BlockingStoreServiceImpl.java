/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.gtt.v2.core.service.blockingstore;

import com.sap.gtt.v2.configuration.GTTRestTemplate;
import com.sap.gtt.v2.configuration.ISAPCloudPlatformAgent;
import com.sap.gtt.v2.core.domain.blockingstore.BlockingStoreDto;
import com.sap.gtt.v2.core.domain.blockingstore.RelatedDocumentDto;
import com.sap.gtt.v2.core.domain.blockingstore.RelatedInstancesDto;
import com.sap.gtt.v2.core.entity.trackedprocess.Event;
import com.sap.gtt.v2.core.entity.trackedprocess.TrackedProcess;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

/**
 *
 * @author I326335
 */
@Component
public class BlockingStoreServiceImpl implements BlockingStoreService {
    @Autowired
    private GTTRestTemplate restTemplate;
    
    @Autowired
    private ISAPCloudPlatformAgent.ICurrentAccessContext currentAccessContext;
    
    @Override
    public void addTrackedProcess(TrackedProcess trackedProcess) {
        sendGuidToBlockingStore(trackedProcess.getIdAsInternalValue().toString(), Timestamp.from(trackedProcess.getLastChangedDateTime()));
    }

    @Override
    public void addEvents(List<Event> events) {
        for (Event event: events) {
            sendGuidToBlockingStore(event.getIdAsInternalValue().toString(), Timestamp.from(event.getLastChangedDateTime()));
        }
    }

    @Override
    public void addEventRelatedDocuments(UUID eventId, List<UUID> trackedProcessList) {
        RelatedInstancesDto relatedInstancesDto = new RelatedInstancesDto();
        trackedProcessList.stream().forEach(trackingProcessId -> {
            relatedInstancesDto.getRelatedDocumentDtos().add(createRelatedDocumentDto(eventId, trackingProcessId));
        });
        sendRelatedDocumentsToBlockingStore(relatedInstancesDto);
    }

    @Override
    public void addEventMapRelatedDocuments(Map<UUID, List<UUID>> eventIdMap) {
        RelatedInstancesDto relatedInstancesDto = new RelatedInstancesDto();
        eventIdMap.entrySet().stream().forEach(entry -> {
            entry.getValue().stream().forEach(trackingProcessId -> {
                relatedInstancesDto.getRelatedDocumentDtos().add(createRelatedDocumentDto(entry.getKey(), trackingProcessId));
            });
        });
    }

    private ResponseEntity<String> sendGuidToBlockingStore(String guid, Timestamp endOfBusinessDate) {
        String url = "";
        BlockingStoreDto blockingStoreDto = new BlockingStoreDto();
        blockingStoreDto.setAppName("GTT");
        blockingStoreDto.setAppGUID(guid);
        blockingStoreDto.setSubDomainId(currentAccessContext.getSubdomain());
        blockingStoreDto.setExternalGUID(guid);
        blockingStoreDto.setEndOfBusinessDate(endOfBusinessDate);
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON_UTF8));
        HttpEntity requestEntity = new HttpEntity(blockingStoreDto);
        
        return restTemplate.exchange(url, HttpMethod.POST, headers, requestEntity, String.class);
    }

    private ResponseEntity<String> sendRelatedDocumentsToBlockingStore(RelatedInstancesDto relatedInstancesDto) {
        String url = "";
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON_UTF8));
        HttpEntity requestEntity = new HttpEntity(relatedInstancesDto);
        
        return restTemplate.exchange(url, HttpMethod.POST, headers, requestEntity, String.class);
    }
    
    private RelatedDocumentDto createRelatedDocumentDto(UUID eventId, UUID trackingProcessId) {
        RelatedDocumentDto relatedDocumentDto = new RelatedDocumentDto();
        relatedDocumentDto.setExternalGuid1(eventId.toString());
        relatedDocumentDto.setExternalGuid2(trackingProcessId.toString());
        return relatedDocumentDto;
    }
}
