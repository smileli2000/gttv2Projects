package com.sap.gtt.v2.core.runtime.model;

import com.sap.gtt.v2.exception.OperationNotAllowed;

public abstract class NumberValue<T extends Number> extends AbstractPropertyValue<T> {

	protected NumberValue(T internalValue) {
		super(internalValue);
	}

	@Override
    public boolean isCsnPrimitive() {
        return true;
    }

    @Override
    public boolean isCollection() {
        return false;
    }
    
    @Override
	protected void generalInputCheck(IPropertyValue that) {
		if(that == null) throw new OperationNotAllowed(ERROR_OPERATE_ON_NULL);
		if(!NumberValue.class.isAssignableFrom(that.getClass())){
			throw new OperationNotAllowed(String.format(ERROR_IMCOMPATIBLE_DATA_TYPE, this.getClass().getSimpleName(),
					that.getClass().getSimpleName()));
		}
		
	}
}
