/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.gtt.v2.core.service.blockingstore;

import java.util.List;

/**
 *
 * @author I326335
 */
public interface RetentionManagementService {
    public void createApplicationNames(List<String> applicationNames);
    public void deleteApplicationName(List<String> applicationNames);
}
