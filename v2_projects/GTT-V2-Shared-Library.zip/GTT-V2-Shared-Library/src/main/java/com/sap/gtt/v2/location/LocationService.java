package com.sap.gtt.v2.location;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.sap.gtt.v2.configuration.EnvironmentsConfiguration.VcapServiceParser.LocationServiceInstance;
import com.sap.gtt.v2.configuration.GTTRestTemplate;
import com.sap.gtt.v2.configuration.ISAPCloudPlatformAgent.ICurrentAccessContext;
import com.sap.gtt.v2.configuration.ServiceInstancesMapping;
import com.sap.gtt.v2.util.JsonUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

@Service
public class LocationService {

    public static final String CACHE_NAME_LOCATION_BY_Alt_KEY = "locationByAltkey";

    @Autowired
    private ServiceInstancesMapping serviceInstancesMapping;
    @Autowired
    private GTTRestTemplate restTemplate;
    @Autowired
    private ICurrentAccessContext currentAccessContext;

    @Cacheable(cacheNames = CACHE_NAME_LOCATION_BY_Alt_KEY)
    public Location getLocationByAltkey(String locationAltkey) {
        if (locationAltkey == null) {
            return null;
        }
        LocationServiceInstance locationServiceInstance = serviceInstancesMapping.getLocationServiceInstance();
        String endpoint = locationServiceInstance.getEndpoint();
        String path = "/LocationService/LocationCreationForCoreEngine?$format=json&$filter=SourceUniversalObjectId eq '{0}'".replace("{0}", locationAltkey);
        String uri = endpoint.concat(path);
        HttpHeaders headers = new HttpHeaders();
        String jwt = locationServiceInstance.requestTechniqueToken(currentAccessContext.getSubdomain());
        headers.setBearerAuth(jwt);
        String response = restTemplate.exchange(uri, HttpMethod.GET, headers, null, String.class).getBody();

        return getLocationFromResponseBody(response);
    }

    private Location getLocationFromResponseBody(String body) {
        JsonObject obj = JsonUtils.generateJsonObjectFromJsonString(body);
        JsonArray results = obj.getAsJsonObject("d").getAsJsonArray("results");
        if (results.size() == 0) {
            return null;
        }
        JsonObject locationObj = results.get(0).getAsJsonObject();
        return JsonUtils.generateBeanFromJson(locationObj.toString(), Location.class);
    }

}
