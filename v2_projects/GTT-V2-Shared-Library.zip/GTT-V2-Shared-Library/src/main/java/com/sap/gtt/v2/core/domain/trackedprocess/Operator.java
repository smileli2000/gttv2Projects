package com.sap.gtt.v2.core.domain.trackedprocess;

public enum Operator {
    EQUAL("=");
    private String value;
    private Operator(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
