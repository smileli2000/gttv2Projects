package com.sap.gtt.v2.core.domain.trackedprocess;

import com.sap.gtt.v2.core.entity.trackedprocess.Event;
import com.sap.gtt.v2.core.runtime.model.ObjectValue;
import com.sap.gtt.v2.core.runtime.model.StringValue;
import com.sap.gtt.v2.core.runtime.model.TimestampValue;

import java.time.Instant;
import java.util.UUID;

/**
 * @author I302310
 */
public class CorrelatedEventInner extends ObjectValue {
    public static final String ID = "id";
    public static final String SUBACCOUNTID = "subaccountId";
    public static final String CLONEINSTANCEID = "cloneInstanceId";
    public static final String EVENT_TYPE = "eventType";
    public static final String MODEL_NAMESPACE = "modelNamespace";
    public static final String EVENT_REASON_TEXT = "eventReasonText";
    public static final String SENDER_PARTY_ID = "senderPartyId";
    public static final String SCHEME = "scheme";
    public static final String PARTYID = "partyId";
    public static final String LOGICAL_SYSTEM = "logicalSystem";
    public static final String TRACKING_ID_TYPE = "trackingIdType";
    public static final String TRACKING_ID = "trackingId";
    public static final String ALT_KEY = "altKey";
    public static final String ACTUAL_TECHNICAL_TIMESTAMP = "actualTechnicalTimestamp";
    public static final String ACTUAL_BUSINESS_TIMESTAMP = "actualBusinessTimestamp";
    public static final String ACTUAL_BUSINESS_TIME_ZONE = "actualBusinessTimeZone";
    public static final String LOCATION_ALT_KEY = "locationAltKey";
    public static final String EVENT_MATCH_KEY = "eventMatchKey";
    public static final String MESSAGE_SOURCE_TYPE = "messageSourceType";
    public static final String CORRELATION_TYPE = "correlationType";

    public static CorrelatedEventInner build(String correlationType, Event event) {
        CorrelatedEventInner correlatedEventInner = new CorrelatedEventInner();
        correlatedEventInner.setCorrelationType(correlationType);
        correlatedEventInner.getInternalValue().putAll(event.getInternalValue());
        return correlatedEventInner;
    }

    public UUID getId() {
        return this.getValueAsUUID(ID);
    }

    public void setId(UUID id) {
        this.setValue(ID, id);
    }

    public UUID getSubaccountId() {
        return this.getValueAsUUID(SUBACCOUNTID);
    }

    public void setSubaccountId(UUID subaccountId) {
        this.setValue(SUBACCOUNTID, subaccountId);
    }

    public UUID getCloneInstanceId() {
        return this.getValueAsUUID(CLONEINSTANCEID);
    }

    public void setCloneInstanceId(UUID cloneInstanceId) {
        this.setValue(CLONEINSTANCEID, cloneInstanceId);
    }

    public String getEventType() {
        return this.getValueAsString(EVENT_TYPE);
    }

    public void setEventType(String eventType) {
        this.setValue(EVENT_TYPE, StringValue.valueOf(eventType));
    }

    public String getModelNamespace() {
        return this.getValueAsString(MODEL_NAMESPACE);
    }

    public void setModelNamespace(String modelNamespace) {
        this.setValue(MODEL_NAMESPACE, StringValue.valueOf(modelNamespace));
    }

    public String getEventReasonText() {
        return this.getValueAsString(EVENT_REASON_TEXT);
    }

    public void setEventReasonText(String eventReasonText) {
        this.setValue(EVENT_REASON_TEXT, StringValue.valueOf(eventReasonText));
    }

    public String getSenderPartyId() {
        return this.getValueAsString(SENDER_PARTY_ID);
    }

    public void setSenderPartyId(String senderPartyId) {
        this.setValue(SENDER_PARTY_ID, senderPartyId);
    }

    public String getScheme() {
        return this.getValueAsString(SCHEME);
    }

    public void setScheme(String scheme) {
        this.setValue(SCHEME, StringValue.valueOf(scheme));
    }

    public String getPartyId() {
        return this.getValueAsString(PARTYID);
    }

    public void setPartyId(String partyId) {
        this.setValue(PARTYID, partyId);
    }

    public String getLogicalSystem() {
        return this.getValueAsString(LOGICAL_SYSTEM);
    }

    public void setLogicalSystem(String logicalSenderSystem) {
        this.setValue(LOGICAL_SYSTEM, StringValue.valueOf(logicalSenderSystem));
    }

    public String getTrackingIdType() {
        return this.getValueAsString(TRACKING_ID_TYPE);
    }

    public void setTrackingIdType(String trackingIdType) {
        this.setValue(TRACKING_ID_TYPE, StringValue.valueOf(trackingIdType));
    }

    public String getTrackingId() {
        return this.getValueAsString(TRACKING_ID);
    }

    public void setTrackingId(String trackingId) {
        this.setValue(TRACKING_ID, StringValue.valueOf(trackingId));
    }

    public String getAltKey() {
        return this.getValueAsString(ALT_KEY);
    }

    public void setAltKey(String altKey) {
        this.setValue(ALT_KEY, StringValue.valueOf(altKey));
    }

    public Instant getActualTechnicalTimestamp() {
        return this.getValueAsTimeStamp(ACTUAL_TECHNICAL_TIMESTAMP);
    }

    public void setActualTechnicalTimestamp(Instant actualTechnicalTimestamp) {
        this.setValue(ACTUAL_TECHNICAL_TIMESTAMP, actualTechnicalTimestamp);
    }

    public Instant getActualBusinessTimestamp() {
        return this.getValueAsTimeStamp(ACTUAL_BUSINESS_TIMESTAMP);
    }

    public void setActualBusinessTimestamp(Instant actualBusinessTimestamp) {
        this.setValue(ACTUAL_BUSINESS_TIMESTAMP, TimestampValue.valueOf(actualBusinessTimestamp));
    }

    public String getActualBusinessTimeZone() {
        return this.getValueAsString(ACTUAL_BUSINESS_TIME_ZONE);
    }

    public void setActualBusinessTimeZone(String actualBusinessTimeZone) {
        this.setValue(ACTUAL_BUSINESS_TIME_ZONE, actualBusinessTimeZone);
    }

    public String getLocationAltKey() {
        return this.getValueAsString(LOCATION_ALT_KEY);
    }

    public void setLocationAltKey(String locationAltKey) {
        this.setValue(LOCATION_ALT_KEY, StringValue.valueOf(locationAltKey));
    }

    public String getEventMatchKey() {
        return this.getValueAsString(EVENT_MATCH_KEY);
    }

    public void setEventMatchKey(String eventMatchKey) {
        this.setValue(EVENT_MATCH_KEY, StringValue.valueOf(eventMatchKey));
    }

    public String getMessageSourceType() {
        return this.getValueAsString(MESSAGE_SOURCE_TYPE);
    }

    public void setMessageSourceType(String messageSourceType) {
        this.setValue(MESSAGE_SOURCE_TYPE, StringValue.valueOf(messageSourceType));
    }

    public String getCorrelationType() {
        return this.getValueAsString(CORRELATION_TYPE);
    }

    public void setCorrelationType(String correlationType) {
        this.setValue(CORRELATION_TYPE, StringValue.valueOf(correlationType));
    }
}
