package com.sap.gtt.v2.core.domain.execution;

import java.time.Instant;

/**
 * @author I302310
 */
public class ExecutionMessageDto {
    private String executionHistoryId;
    private String phase;
    private String messageType;
    private Instant errorAt;
    private String message;
    private String detail;
    private String tag;

    public String getExecutionHistoryId() {
        return executionHistoryId;
    }

    public void setExecutionHistoryId(String executionHistoryId) {
        this.executionHistoryId = executionHistoryId;
    }

    public String getPhase() {
        return phase;
    }

    public void setPhase(String phase) {
        this.phase = phase;
    }

    public String getMessageType() {
        return messageType;
    }

    public void setMessageType(String messageType) {
        this.messageType = messageType;
    }

    public Instant getErrorAt() {
        return errorAt;
    }

    public void setErrorAt(Instant errorAt) {
        this.errorAt = errorAt;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }
}
