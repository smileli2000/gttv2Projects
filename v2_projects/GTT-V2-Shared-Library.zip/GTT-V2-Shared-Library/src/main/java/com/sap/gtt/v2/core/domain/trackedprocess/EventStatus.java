package com.sap.gtt.v2.core.domain.trackedprocess;

public enum EventStatus {
	PLANNED, EARLY_REPORTED, REPORTED, LATE_REPORTED, OVERDUE, DELAYED
}
