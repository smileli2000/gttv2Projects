package com.sap.gtt.v2.core.dao.tracking;

import com.sap.gtt.v2.core.domain.metadata.CurrentMetadataEntity;
import com.sap.gtt.v2.core.domain.metadata.PhysicalName;
import com.sap.gtt.v2.core.entity.trackedprocess.PlannedEvent;

import java.util.List;
import java.util.UUID;

public interface IPlannedEventDao {

	/**
	 * For all 3 types of Planned Event
	 * @param plannedEvents
	 */
	void insert(List<PlannedEvent> plannedEvents);
	
	void update(PlannedEvent plannedEvent);

	void deleteByProcessId(UUID processId, PhysicalName physicalName);

    PlannedEvent findOne(CurrentMetadataEntity metadata, UUID id);
}
