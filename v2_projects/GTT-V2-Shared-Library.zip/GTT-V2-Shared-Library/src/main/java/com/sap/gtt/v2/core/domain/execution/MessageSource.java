package com.sap.gtt.v2.core.domain.execution;

/**
 * @author I302310
 * For MML
 */
public enum MessageSource {
    ERP("SAP ERP"), VP("Visibility Provider"), OTHER("3rd Party");
    private String description;

    MessageSource(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }
}
