package com.sap.gtt.v2.core.service.reminder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.sap.gtt.v2.core.runtime.model.IPropertyValue;
import com.sap.gtt.v2.core.runtime.model.ObjectValue;
import com.sap.gtt.v2.log.TenantAwareLogService;
import com.sap.gtt.v2.util.SpringContextUtils;

@Service
public class ReminderServiceImpl extends ObjectValue implements IReminderService {
	private static final String FUNCTION_GENERATE_DIRECTMAIL = "generateDirectMail";
	private static final String FUNCTION_GENERATE_DIRECTMAILTEMPLATE = "generateDirectMailTemplate";
	protected static final Map<String, FunctionInterfaceDef> functionDefs = new HashMap<>();

	static{
		functionDefs.putAll(ObjectValue.functionDefs);

		List<Class<? extends IPropertyValue>> argumentEmptyType = new ArrayList<>();
		FunctionInterfaceDef funGenerateDirectMail = new FunctionInterfaceDef(FunctionInterfaceDef.Category.SYSTEM, FUNCTION_GENERATE_DIRECTMAIL, argumentEmptyType,
				((callerObject, args) -> {
					IReminderService reminderService = (IReminderService)SpringContextUtils.getBean(IReminderService.class);
			    	DirectMail dm = reminderService.generateDirectMail();
					return dm;
				}));
		functionDefs.put(funGenerateDirectMail.name,funGenerateDirectMail);
		
		
		FunctionInterfaceDef funGenerateDirectMailTemplate = new FunctionInterfaceDef(FunctionInterfaceDef.Category.SYSTEM, FUNCTION_GENERATE_DIRECTMAILTEMPLATE, argumentEmptyType,
				((callerObject, args) -> {
					IReminderService reminderService = (IReminderService)SpringContextUtils.getBean(IReminderService.class);
			    	DirectMailTemplate dm = reminderService.generateDirectMailTemplate();
					return dm;
				}));
		functionDefs.put(funGenerateDirectMailTemplate.name,funGenerateDirectMailTemplate);
	}
	@Override
	protected Map<String, FunctionInterfaceDef> getFunctionDefs(){
		return functionDefs;
	}
	
	
	
	
	@Override
	public DirectMail generateDirectMail() {
		return new DirectMail();
	}
	
	@Override
	public DirectMailTemplate generateDirectMailTemplate() {
		TenantAwareLogService logService = SpringContextUtils.getBean(TenantAwareLogService.class);
		logService.info("==> generateDirectMailTemplate");
		
		DirectMailTemplate ret = new DirectMailTemplate();
		ret.setTemplateSource("USERTEMPLATE");
    	ret.setLocale("en");
    	ret.setTemplateRecipientIgnore(false);
    	return ret;
	}
}
