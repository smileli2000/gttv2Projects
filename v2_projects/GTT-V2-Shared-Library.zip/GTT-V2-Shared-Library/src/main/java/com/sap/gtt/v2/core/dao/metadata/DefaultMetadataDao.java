package com.sap.gtt.v2.core.dao.metadata;

import com.sap.gtt.v2.configuration.EnvironmentsConfiguration.VcapServiceParser.DatabaseServiceInstance.DatabaseType;
import com.sap.gtt.v2.configuration.ISAPCloudPlatformAgent;
import com.sap.gtt.v2.core.domain.metadata.MetadataConstants;
import com.sap.gtt.v2.core.domain.metadata.MetadataConstants.*;
import com.sap.gtt.v2.core.domain.metadata.MetadataCriteria;
import com.sap.gtt.v2.core.entity.metadata.*;
import com.sap.gtt.v2.exception.DBException;
import com.sap.gtt.v2.util.DBUtils;
import com.sap.gtt.v2.util.SpringContextUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Repository;
import org.springframework.util.ReflectionUtils;

import java.lang.reflect.Field;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.*;

import static com.sap.gtt.v2.core.domain.metadata.MetadataConstants.*;
import static com.sap.gtt.v2.core.domain.metadata.MetadataConstants.CoreModelEntity.TRACKED_PROCESS;
import static com.sap.gtt.v2.core.domain.metadata.MetadataConstants.MetadataProjectFileField.IDOC_CONFIG;
import static com.sap.gtt.v2.core.domain.metadata.MetadataConstants.MetadataProjectFileField.READ_SWAGGER;

/**
 * Metadata related repository
 *
 * @author I321712
 */
@Repository(DefaultMetadataDao.BEAN_NAME)
public class DefaultMetadataDao implements IMetadataDao {
    public static final String BEAN_NAME = "com.sap.gtt.v2.core.dao.metadata.DefaultMetadataDao";
    public static final String SELECT = "SELECT ";
    public static final String FROM = " FROM ";
    public static final String INNER_JOIN = " INNER JOIN ";
    public static final String WHERE_1_1 = " WHERE 1=1 ";

    private static final String DESC = " DESC ";
    private static final String ORDER_BY = " ORDER BY ";
    private static final String MD_LEFT_JOIN = " MD LEFT JOIN ";
    private static final String SPACE = " ";
    private static final String EQUAL = "=";
    private static final String MP_ON = " MP ON ";
    private static final String MP_DOT = "MP.";
    private static final String AS_DRAFTSTATUS = " AS DRAFTSTATUS";
    private static final String MD_DOT = "MD.";
    private static final String PM_DOT = "PM.";
    private static final String MPT_DOT = " MPT.";
    private static final String MPT_ON = " MPT ON ";
    private static final String AS_TRANSLATION_DESC = " AS TRANSLATION_DESC";
    private static final String TRANSLATION_DESC = "TRANSLATION_DESC";
    private static final String MPT_METADATA_PROJECT_ID = " MPT.METADATA_PROJECT_ID";
    private static final String MP_ID = " MP.ID";
    private static final String AND = " AND ";
    private static final String LOCALE = " LOCALE ";
    private static final String LEFT_BRACE = " ( ";
    private static final String RIGHT_BRACE = " ) ";


    private static final String PROCESS_DESCRIPTION = "PROCESS_DESCRIPTION";
    public static final String LEFT_JOIN = " LEFT JOIN ";
    public static final String OR = "OR";
    public static final String QUESTION_MARK = "? ";

    protected Logger logger = LoggerFactory.getLogger(getClass());

    private static final Map<String, Field> METADATA_PROJECT_FILE_FIELD_MAP = new HashMap<>();

    static {
        Field[] fields = MetadataProjectFile.class.getDeclaredFields();
        for (Field field : fields) {
            METADATA_PROJECT_FILE_FIELD_MAP.put(field.getName().toUpperCase(Locale.ENGLISH), field);
        }
    }

    @Autowired
    private JdbcTemplate jdbcTemplate;
    @Autowired
    private ISAPCloudPlatformAgent.ICurrentAccessContext currentAccessContext;


    public static DefaultMetadataDao getInstance() {
        return (DefaultMetadataDao) SpringContextUtils.getBean(BEAN_NAME);
    }

    @Override
    public List<MetadataProject> findMetadataProjectInfo(MetadataCriteria criteria) {
        boolean containProjectFileInfo = criteria != null && criteria.isContainProjectFileInfo();
        List<String> selectedColsList = new ArrayList<>(Arrays.asList(MP_ID + " " + METADATA_PROJECT_ID, PM_ID, TRACKED_PROCESS_TYPE, APPLICATION_OBJECT_TYPE,
                NAMESPACE, UPLOADED_AT, VERSION, STATUS, "MP." + DESCRIPTION, MODE, CORE_MODEL_VERSION, COMPILER_VERSION, PM_DOT + DESCRIPTION + " " + PROCESS_DESCRIPTION));
        if (containProjectFileInfo) {
            selectedColsList.add(DERIVED_CSN);
            selectedColsList.add(RULES);
        }
        StringBuilder sqlSb = new StringBuilder()
                .append(SELECT)
                .append(StringUtils.join(selectedColsList, COMMA))
                .append(FROM)
                .append(MetadataTable.METADATA_PROJECT)
                .append(" MP ").append(LEFT_JOIN)
                .append(MetadataTable.METADATA_PROCESS)
                .append(" PM ON PM.").append(METADATA_PROJECT_ID).append(EQUAL).append("MP.").append(ID);
        if (containProjectFileInfo) {
            sqlSb.append(LEFT_JOIN).append(MetadataTable.METADATA_PROJECT_FILE).append(" MPF on MPF.")
                    .append(ID).append(EQUAL).append("MP.").append(ID);
        }
        sqlSb.append(WHERE_1_1);
        List<Object> params = new ArrayList<>();
        buildMetadataProjectInfoQuery(criteria, sqlSb, params);

        List<Map<String, Object>> mapList = jdbcTemplate.queryForList(sqlSb.toString(), params.toArray());
        Map<String, MetadataProject> projectMap = new HashMap<>(INITIAL_CAPACITY);
        mapList.forEach(obj -> {
            String metadataProjectId = obj.get(METADATA_PROJECT_ID).toString();
            MetadataProject project = projectMap.get(metadataProjectId);
            if (project == null) {
                project = new MetadataProject();
                project.setId(metadataProjectId);
                project.setNamespace(DBUtils.toStringValue(obj.get(NAMESPACE)));
                project.setUploadAt(((Timestamp) obj.get(UPLOADED_AT)).toInstant());
                project.setVersion(DBUtils.toStringValue(obj.get(VERSION)));
                project.setStatus(DBUtils.toStringValue(obj.get(STATUS)));
                project.setDescription(DBUtils.toStringValue(obj.get(DESCRIPTION)));
                project.setMode(DBUtils.toStringValue(obj.get(MODE)));
                project.setCoreModelVersion(DBUtils.toStringValue(obj.get(CORE_MODEL_VERSION)));
                project.setCompilerVersion(DBUtils.toStringValue(obj.get(COMPILER_VERSION)));
                if (containProjectFileInfo) {
                    MetadataProjectFile file = new MetadataProjectFile();
                    file.setDerivedCsn(DBUtils.toStringValue(obj.get(DERIVED_CSN)));
                    file.setRules(DBUtils.toStringValue(obj.get(RULES)));
                    project.setMetadataProjectFile(file);
                }
                projectMap.put(metadataProjectId, project);
            }
            MetadataProcess metadataProcess = new MetadataProcess();
            metadataProcess.setId(DBUtils.toStringValue(obj.get(ID)));
            metadataProcess.setMetadataProjectId(metadataProjectId);
            metadataProcess.setTrackedProcessType(DBUtils.toStringValue(obj.get(TRACKED_PROCESS_TYPE)));
            metadataProcess.setApplicationObjectType(DBUtils.toStringValue(obj.get(APPLICATION_OBJECT_TYPE)));
            metadataProcess.setDescription(DBUtils.toStringValue(obj.get(PROCESS_DESCRIPTION)));
            project.addProcessMetadata(metadataProcess);
        });
        return new ArrayList<>(projectMap.values());
    }

    private void buildMetadataProjectInfoQuery(MetadataCriteria criteria, StringBuilder sqlSb, List<Object> params) {
        if (criteria != null) {
            buildOrExpression(criteria.getNamespaces(), sqlSb, " MP.", NAMESPACE, params);
            buildOrExpression(criteria.getTrackedProcessTypes(), sqlSb, " PM.", TRACKED_PROCESS_TYPE, params);
            String status = criteria.getStatus();
            if (StringUtils.isNotBlank(status)) {
                sqlSb.append(" AND MP.").append(STATUS).append("=? ");
                params.add(status);
            }
        }
    }

    private void buildOrExpression(List<String> conditionVals, StringBuilder sqlSb, String alias, String conditionField, List<Object> params) {
        int conditionSize = conditionVals.size();
        for (int i = 0; i < conditionSize; i++) {
            if (i == 0) {
                sqlSb.append(" AND ( ");
            }
            sqlSb.append(alias).append(conditionField).append("=? ");
            params.add(conditionVals.get(i));
            if (i < conditionSize - 1) {
                sqlSb.append(" OR ");
            } else if (i == conditionSize - 1) {
                sqlSb.append(")");
            }
        }
    }

    @Override
    public List<MetadataProject> findAllMetadataProject() {
        String[] selectedCols = {ID, NAMESPACE, UPLOADED_AT, VERSION, STATUS, DESCRIPTION, MODE, CORE_MODEL_VERSION, COMPILER_VERSION};
        String sql = new StringBuilder()
                .append(SELECT)
                .append(StringUtils.join(selectedCols, COMMA))
                .append(FROM)
                .append(MetadataTable.METADATA_PROJECT)
                .append(" MP").toString();
        List<Map<String, Object>> mapList = jdbcTemplate.queryForList(sql);
        List<MetadataProject> ret = new ArrayList<>();
        mapList.forEach(obj -> {
            MetadataProject project = new MetadataProject();
            project.setId(DBUtils.toStringValue(obj.get(ID)));
            project.setNamespace(DBUtils.toStringValue(obj.get(NAMESPACE)));
            project.setUploadAt(((Timestamp) obj.get(UPLOADED_AT)).toInstant());
            project.setVersion(DBUtils.toStringValue(obj.get(VERSION)));
            project.setStatus(DBUtils.toStringValue(obj.get(STATUS)));
            project.setDescription(DBUtils.toStringValue(obj.get(DESCRIPTION)));
            project.setMode(DBUtils.toStringValue(obj.get(MODE)));
            project.setCoreModelVersion(DBUtils.toStringValue(obj.get(CORE_MODEL_VERSION)));
            project.setCompilerVersion(DBUtils.toStringValue(obj.get(COMPILER_VERSION)));
            ret.add(project);
        });
        return ret;
    }

    @Override
    public List<MetadataProject> findMetadataProjectInfoByNamespace(String namespace) {
        MetadataCriteria criteria = new MetadataCriteria();
        criteria.addNamespace(namespace);
        criteria.setContainProjectFileInfo(true);
        return this.findMetadataProjectInfo(criteria);
    }

    @Override
    public List<MetadataProcess> findAllMetadataProcess(MetadataCriteria criteria) {
        String[] selectedCols = {PM_ID, METADATA_PROJECT_ID, TRACKED_PROCESS_TYPE, APPLICATION_OBJECT_TYPE,
                TRACKING_ID_TYPE, PM_DOT + DESCRIPTION};
        StringBuilder sqlSb = new StringBuilder(SELECT)
                .append(StringUtils.join(selectedCols, COMMA))
                .append(FROM)
                .append(MetadataTable.METADATA_PROCESS)
                .append(" PM ");
        List<Object> params = new ArrayList<>();
        if (criteria != null) {
            String conditionVal = criteria.getEventType();
            if (StringUtils.isNotBlank(conditionVal)) {
                sqlSb.append(INNER_JOIN)
                        .append(MetadataTable.METADATA_EVENT)
                        .append(" EM on ").append(PM_ID)
                        .append("=EM.").append(PROCESS_METADATA_ID);
            }
            List<String> namespaces = criteria.getNamespaces();
            if (!namespaces.isEmpty()) {
                sqlSb.append(LEFT_JOIN)
                        .append(MetadataTable.METADATA_PROJECT)
                        .append(" MP on ").append(METADATA_PROJECT_ID)
                        .append(" = ").append(MP_ID);
            }
            sqlSb.append(WHERE_1_1);
            buildQueryCondition(EVENT_TYPE, conditionVal, sqlSb, params);
            buildQueryCondition(NAMESPACE, namespaces, sqlSb, params);
            buildQueryCondition(PM_ID, criteria.getId(), sqlSb, params);
            buildQueryCondition(APPLICATION_OBJECT_TYPE, criteria.getApplicationObjectType(), sqlSb, params);
            buildQueryCondition(TRACKING_ID_TYPE, criteria.getTrackingIdType(), sqlSb, params);
        }
        return jdbcTemplate.query(sqlSb.toString(), params.toArray(), (rs, rowNum) -> {
            String id = rs.getString(ID);
            String metadataProjectId = rs.getString(METADATA_PROJECT_ID);
            String trackedProcessType = rs.getString(TRACKED_PROCESS_TYPE);
            String applicationObjectType = rs.getString(APPLICATION_OBJECT_TYPE);
            String trackingIdType = rs.getString(TRACKING_ID_TYPE);
            String description = rs.getString(DESCRIPTION);
            return new MetadataProcess(id, metadataProjectId, trackedProcessType, applicationObjectType, trackingIdType, description);
        });
    }

    private void buildQueryCondition(String conditionCol, Object conditionVal, StringBuilder sqlSb, List<Object> params) {
        if (conditionVal != null) {
            if (conditionVal instanceof String) {
                sqlSb.append(AND).append(conditionCol).append(EQUAL).append(QUESTION_MARK);
                params.add(conditionVal);
            } else if (conditionVal instanceof List) {
                List<String> conditionVals = (List<String>) conditionVal;
                buildOrExpression(conditionVals, sqlSb, "", conditionCol, params);
            }
        }
    }

    @Override
    public String getMetadataDerivedCsn(MetadataCriteria criteria) {
        String ret = null;
        MetadataProjectFile projectFileInfo = getMetadataProjectFileInfo(new String[]{DERIVED_CSN}, criteria);
        if (projectFileInfo != null) {
            ret = projectFileInfo.getDerivedCsn();
        }
        return ret;
    }

    @Override
    public MetadataProjectFile getMetadataSwaggerDerivedCsnInfo(String namespace) {
        MetadataCriteria criteria = new MetadataCriteria();
        criteria.addNamespace(namespace);
        return getMetadataProjectFileInfo(new String[]{DERIVED_CSN, SWAGGER}, criteria);
    }

    @Override
    public void insertMetadataProject(MetadataProject newMetadataProject) {
        // 1. insert metadata project information
        StringBuilder insertSql = new StringBuilder();
        String[] projColumns = {ID, NAMESPACE, UPLOADED_AT, VERSION, STATUS, DESCRIPTION, MODE, CORE_MODEL_VERSION, COMPILER_VERSION};
        DBUtils.buildInsertSql(MetadataTable.METADATA_PROJECT.name(), projColumns, insertSql);
        Object[] insertParams = new Object[]{
                newMetadataProject.getId(),
                newMetadataProject.getNamespace(),
                newMetadataProject.getUploadAt(),
                newMetadataProject.getVersion(),
                newMetadataProject.getStatus(),
                newMetadataProject.getDescription(),
                newMetadataProject.getMode(),
                newMetadataProject.getCoreModelVersion(),
                newMetadataProject.getCompilerVersion()
        };
        int affectedRows = jdbcTemplate.update(insertSql.toString(), insertParams);
        if (affectedRows <= 0) {
            throw new DBException("Insert MetadataProject data failed. Affected rows " + affectedRows);
        }
        MetadataProjectFile metadataProjectFile = newMetadataProject.getMetadataProjectFile();
        if (metadataProjectFile != null) {
            insertSql = new StringBuilder();
            // 2. insert metadata project file information
            DBUtils.buildInsertSql(MetadataTable.METADATA_PROJECT_FILE.name(),
                    new String[]{ID, CDS, CSN, EDMX, ANNOTATION, I18N, SWAGGER, DERIVED_CSN, RULES, JSON_MODEL,
                            IDOC_CONFIG.name(), READ_SWAGGER.name()},
                    insertSql);
            insertParams = new Object[]{
                    metadataProjectFile.getId(),
                    metadataProjectFile.getCds(),
                    metadataProjectFile.getCsn(),
                    metadataProjectFile.getEdmx(),
                    metadataProjectFile.getAnnotation(),
                    metadataProjectFile.getI18n(),
                    metadataProjectFile.getSwagger(),
                    metadataProjectFile.getDerivedCsn(),
                    metadataProjectFile.getRules(),
                    metadataProjectFile.getJsonModel(),
                    metadataProjectFile.getIdocConfig(),
                    metadataProjectFile.getReadSwagger()
            };
            affectedRows = jdbcTemplate.update(insertSql.toString(), insertParams);
            if (affectedRows <= 0) {
                throw new DBException("Insert MetadataProject data failed. Affected rows " + affectedRows);
            }
            //update metadata project desc translation:
            upsertMetadataProjectTexts(newMetadataProject);
        }
    }

    @Override
    public void updateMetadataProject(MetadataProject updatedMetadataProject) {
        StringBuilder updateSql = new StringBuilder();
        List<Object> updateParam = new ArrayList<>();

        String[] updatedColumns = {UPLOADED_AT, VERSION, STATUS, DESCRIPTION, MODE, CORE_MODEL_VERSION, COMPILER_VERSION};
        Object[] updatedVal = {updatedMetadataProject.getUploadAt(),
                updatedMetadataProject.getVersion(),
                updatedMetadataProject.getStatus(),
                updatedMetadataProject.getDescription(),
                updatedMetadataProject.getMode(),
                updatedMetadataProject.getCoreModelVersion(),
                updatedMetadataProject.getCompilerVersion()
        };
        String[] whereColumns = {NAMESPACE};
        Object[] whereVals = {updatedMetadataProject.getNamespace()};

        DBUtils.buildUpdateSql(MetadataTable.METADATA_PROJECT.name(),
                updatedColumns,
                updatedVal,
                whereColumns,
                whereVals,
                updateSql,
                updateParam);
        jdbcTemplate.update(updateSql.toString(), updateParam.toArray());

        MetadataProjectFile metadataProjectFile = updatedMetadataProject.getMetadataProjectFile();
        if (metadataProjectFile != null) {
            updateSql = new StringBuilder();
            updateParam = new ArrayList<>();
            updatedColumns = new String[]{CDS, CSN, EDMX, ANNOTATION, I18N, SWAGGER, DERIVED_CSN, RULES,
                    JSON_MODEL, IDOC_CONFIG.name(), READ_SWAGGER.name()};
            updatedVal = new Object[]{
                    metadataProjectFile.getCds(),
                    metadataProjectFile.getCsn(),
                    metadataProjectFile.getEdmx(),
                    metadataProjectFile.getAnnotation(),
                    metadataProjectFile.getI18n(),
                    metadataProjectFile.getSwagger(),
                    metadataProjectFile.getDerivedCsn(),
                    metadataProjectFile.getRules(),
                    metadataProjectFile.getJsonModel(),
                    metadataProjectFile.getIdocConfig(),
                    metadataProjectFile.getReadSwagger()
            };
            whereColumns = new String[]{ID};
            whereVals = new Object[]{metadataProjectFile.getId()};
            DBUtils.buildUpdateSql(MetadataTable.METADATA_PROJECT_FILE.name(),
                    updatedColumns,
                    updatedVal,
                    whereColumns,
                    whereVals,
                    updateSql,
                    updateParam);
            jdbcTemplate.update(updateSql.toString(), updateParam.toArray());
        }

        //update metadata project desc translation:
        upsertMetadataProjectTexts(updatedMetadataProject);

    }

    @Override
    public void updateMetadataProjectStatus(MetadataProject updatedMetadataProject) {
        StringBuilder updateSql = new StringBuilder();
        List<Object> updateParam = new ArrayList<>();

        String[] updatedColumns = {UPLOADED_AT, STATUS};
        Object[] updatedVal = {updatedMetadataProject.getUploadAt(),
                updatedMetadataProject.getStatus()
        };
        String[] whereColumns = {NAMESPACE};
        Object[] whereVals = {updatedMetadataProject.getNamespace()};

        DBUtils.buildUpdateSql(MetadataTable.METADATA_PROJECT.name(),
                updatedColumns,
                updatedVal,
                whereColumns,
                whereVals,
                updateSql,
                updateParam);
        jdbcTemplate.update(updateSql.toString(), updateParam.toArray());

    }

    @Override
    public void insertMetadataProcess(MetadataProcess newMetadataProcess) {
        StringBuilder insertSql = new StringBuilder();
        String[] columns = {ID, METADATA_PROJECT_ID, TRACKED_PROCESS_TYPE, APPLICATION_OBJECT_TYPE, TRACKING_ID_TYPE, DESCRIPTION};
        DBUtils.buildInsertSql(MetadataTable.METADATA_PROCESS.name(), columns, insertSql);

        Object[] insertParams = new Object[]{
                newMetadataProcess.getId(),
                newMetadataProcess.getMetadataProjectId(),
                newMetadataProcess.getTrackedProcessType(),
                newMetadataProcess.getApplicationObjectType(),
                newMetadataProcess.getTrackingIdType(),
                newMetadataProcess.getDescription()
        };
        jdbcTemplate.update(insertSql.toString(), insertParams);
        saveMetadataEvents(newMetadataProcess);
    }

    @Override
    public void updateMetadataProcess(MetadataProcess updatedMetadataProcess) {
        StringBuilder updateSql = new StringBuilder();
        List<Object> updateParam = new ArrayList<>();

        List<String> updatedColumnList = new ArrayList<>();
        List<Object> updatedValList = new ArrayList<>();
        buildUpdateColumnValue(updatedColumnList, updatedValList, APPLICATION_OBJECT_TYPE,
                updatedMetadataProcess.getApplicationObjectType());
        buildUpdateColumnValue(updatedColumnList, updatedValList, TRACKING_ID_TYPE,
                updatedMetadataProcess.getTrackingIdType());
        buildUpdateColumnValue(updatedColumnList, updatedValList, DESCRIPTION,
                updatedMetadataProcess.getDescription());

        String[] whereColumns = {TRACKED_PROCESS_TYPE, METADATA_PROJECT_ID};
        Object[] whereVals = {updatedMetadataProcess.getTrackedProcessType(),
                updatedMetadataProcess.getMetadataProjectId()};

        DBUtils.buildUpdateSql(MetadataTable.METADATA_PROCESS.name(),
                updatedColumnList.toArray(new String[0]),
                updatedValList.toArray(),
                whereColumns,
                whereVals,
                updateSql,
                updateParam);
        jdbcTemplate.update(updateSql.toString(), updateParam.toArray());

        saveMetadataEvents(updatedMetadataProcess);
    }

    private void buildUpdateColumnValue(List<String> updatedColumnList, List<Object> updatedValList,
                                        String updateColumn, String newValue) {
        if (StringUtils.isNotBlank(newValue)) {
            updatedColumnList.add(updateColumn);
            updatedValList.add(newValue);
        }
    }

    @Override
    public void upsertMetadataProcessTexts(MetadataProcess metadataProcess) {
        List<MetadataProcessText> metadataProcessTexts = metadataProcess.getMetadataProcessTexts();
        if (!metadataProcessTexts.isEmpty()) {
            String metadataProcessId = metadataProcess.getId();
            String[] whereColumns = {METADATA_PROCESS_ID};
            Object[] whereVals = {metadataProcessId};
            StringBuilder deleteSql = new StringBuilder();
            //delete metadata process text by metadataProcessId:
            DBUtils.buildDeleteSql(MetadataConstants.MetadataTable.METADATA_PROCESS_TEXTS.name(), whereColumns, whereVals, deleteSql);
            jdbcTemplate.update(deleteSql.toString(), whereVals);
            //insert metadata process text:
            List<Object[]> batchArgs = new ArrayList<>();
            compositeBatchArgsForMetadataProcessTextValues(batchArgs, metadataProcessTexts);

            DatabaseType databaseType = getDatabaseType();
            DDLBuilder ddlBuilder = DBUtils.getDDLBuilder(databaseType);
            String sql = ddlBuilder.buildInsertTableForMetadataProcessTexts();
            jdbcTemplate.batchUpdate(sql, batchArgs);
        }
    }

    @Override
    public long countTrackedProcessByType(String trackedProcessType) {
        String tableName = DBUtils.toTableName(TRACKED_PROCESS.getFullName());
        StringBuilder sb = new StringBuilder("SELECT COUNT(1) AS TOTAL FROM ").append(tableName).append(WHERE_1_1)
                .append(AND).append(TRACKEDPROCESSTYPE).append("= ? ");
        SqlRowSet result = jdbcTemplate.queryForRowSet(sb.toString(), trackedProcessType);
        result.next();
        return result.getLong("TOTAL");
    }

    private void compositeBatchArgsForMetadataProcessTextValues(List<Object[]> batchArgs, List<MetadataProcessText> metadataProcessTexts) {
        metadataProcessTexts.forEach(metadataProcessText -> batchArgs.add(new Object[]{metadataProcessText.getMetadataProcessId(), metadataProcessText.getLocale(), metadataProcessText.getDescr()}));

    }

    @Override
    public void deleteMetadata(String namespace) {
        Object[] whereVals = {namespace};
        //delete metadata process text
        DatabaseType databaseType = getDatabaseType();
        DDLBuilder ddlBuilder = DBUtils.getDDLBuilder(databaseType);
        String deleteMetadataProcessTextSql = ddlBuilder.buildDeleteTableForMetadataProcessTexts();
        jdbcTemplate.update(deleteMetadataProcessTextSql, whereVals);

        StringBuilder deleteSql = new StringBuilder();
        // delete metadata process
        DBUtils.buildDeleteSqlUsingSubQuery(MetadataTable.METADATA_PROCESS.name(), METADATA_PROJECT_ID, whereVals,
                MetadataTable.METADATA_PROJECT.name(), ID, NAMESPACE, deleteSql);
        jdbcTemplate.update(deleteSql.toString(), whereVals);

        //delete metadata project text
        String deleteMetadataProjectTextSql = ddlBuilder.buildDeleteTableForMetadataProjectTexts();
        jdbcTemplate.update(deleteMetadataProjectTextSql, whereVals);

        // delete metadata project file
        deleteSql = new StringBuilder();
        DBUtils.buildDeleteSqlUsingSubQuery(MetadataTable.METADATA_PROJECT_FILE.name(), ID, whereVals,
                MetadataTable.METADATA_PROJECT.name(), ID, NAMESPACE, deleteSql);
        jdbcTemplate.update(deleteSql.toString(), whereVals);
        // delete metadata project
        deleteSql = new StringBuilder();
        String[] whereColumns = {NAMESPACE};
        DBUtils.buildDeleteSql(MetadataTable.METADATA_PROJECT.name(), whereColumns, whereVals, deleteSql);
        jdbcTemplate.update(deleteSql.toString(), whereVals);
        // delete metadata change history
        deleteSql = new StringBuilder();
        DBUtils.buildDeleteSql(MetadataTable.METADATA_CHANGE_HISTORY.name(), whereColumns, whereVals, deleteSql);
        jdbcTemplate.update(deleteSql.toString(), whereVals);
    }


    private void upsertMetadataProjectTexts(MetadataProject metadataProject) {
        List<MetadataProjectText> metadataProjectTexts = metadataProject.getMetadataProjectTexts();
        if (!metadataProjectTexts.isEmpty()) {
            String metadataProjectId = metadataProject.getId();
            String[] whereColumns = {METADATA_PROJECT_ID};
            Object[] whereVals = {metadataProjectId};
            StringBuilder deleteSql = new StringBuilder();
            //delete metadata process text by metadataProcessId:
            DBUtils.buildDeleteSql(MetadataTable.METADATA_PROJECT_TEXTS.name(), whereColumns, whereVals, deleteSql);
            jdbcTemplate.update(deleteSql.toString(), whereVals);
            //insert metadata project text:
            List<Object[]> batchArgs = new ArrayList<>();
            compositeBatchArgsForMetadataProjectTextValues(batchArgs, metadataProjectTexts);

            DatabaseType databaseType = getDatabaseType();
            DDLBuilder ddlBuilder = DBUtils.getDDLBuilder(databaseType);
            String sql = ddlBuilder.buildInsertTableForMetadataProjectTexts();
            jdbcTemplate.batchUpdate(sql, batchArgs);
        }
    }

    private void compositeBatchArgsForMetadataProjectTextValues(List<Object[]> batchArgs, List<MetadataProjectText> metadataProjectTexts) {
        metadataProjectTexts.forEach(metadataProjectText -> batchArgs.add(new Object[]{metadataProjectText.getMetadataProjectId(), metadataProjectText.getLocale(), metadataProjectText.getDescr()}));
    }

    public MetadataProjectFile getMetadataProjectFileInfo(String[] selectFields, MetadataCriteria criteria) {
        MetadataProjectFile ret = null;
        StringBuilder sqlSb = new StringBuilder(SELECT)
                .append(StringUtils.join(selectFields, COMMA))
                .append(FROM)
                .append(MetadataTable.METADATA_PROJECT)
                .append(" MP INNER JOIN ")
                .append(MetadataTable.METADATA_PROJECT_FILE)
                .append(" MPF ON " + MP_ID + "=" + MPF_ID + " ");
        List<Object> params = new ArrayList<>();
        String conditionVal = criteria.getApplicationObjectType();
        if (StringUtils.isNotBlank(conditionVal)) {
            sqlSb.append(INNER_JOIN)
                    .append(MetadataTable.METADATA_PROCESS)
                    .append(" PM ON PM." + METADATA_PROJECT_ID + "=").append(MP_ID);
        }
        sqlSb.append(WHERE_1_1);
        buildQueryCondition(APPLICATION_OBJECT_TYPE, conditionVal, sqlSb, params);
        buildQueryCondition(STATUS, criteria.getStatus(), sqlSb, params);
        buildOrExpression(criteria.getNamespaces(), sqlSb, "", NAMESPACE, params);

        List<Map<String, Object>> list = jdbcTemplate.queryForList(sqlSb.toString(), params.toArray());
        if (!list.isEmpty()) {
            Map<String, Object> valMap = list.get(0);
            ret = new MetadataProjectFile();
            for (String selField : selectFields) {
                Field field = getField(selField);
                setFieldValue(ret, valMap, selField, field);
            }
        }
        return ret;
    }

    private Field getField(String fieldName) {
        String upperName = fieldName.toUpperCase(Locale.ENGLISH);
        Field field = METADATA_PROJECT_FILE_FIELD_MAP.get(upperName);
        if (field == null) {
            String s = StringUtils.replaceChars(upperName,
                    UNDERSCORE, StringUtils.EMPTY);
            field = METADATA_PROJECT_FILE_FIELD_MAP.get(s);
        }
        return field;
    }

    private void setFieldValue(MetadataProjectFile ret, Map<String, Object> valMap, String selField, Field field) {
        if (field != null) {
            ReflectionUtils.makeAccessible(field);
            try {
                Object objVal = valMap.get(selField);
                field.set(ret, DBUtils.toStringValue(objVal));
            } catch (IllegalAccessException e) {
                logger.warn(e.getMessage(), e);
            }
        }
    }

    @Override
    public String getMetadataProjectFileFieldInfo(List<String> namespaces, MetadataProjectFileField fieldName) {
        String ret = "";
        MetadataCriteria criteria = new MetadataCriteria();
        for (String e : namespaces) {
            criteria.addNamespace(e);
        }
        String name = fieldName.name();
        MetadataProjectFile projectFile = getMetadataProjectFileInfo(new String[]{name}, criteria);
        if (projectFile == null) {
            return ret;
        }
        Field field = getField(name);
        return getFieldValue(ret, projectFile, field);
    }

    @Override
    public void insertMetadataChangeHistory(MetadataChangeHistory metadataChangeHistory) {
        StringBuilder insertSql = new StringBuilder();
        String[] columns = {ID, NAMESPACE, CHANGE_TIME, USER_EMAIL, COMMENT, ACTION};
        DBUtils.buildInsertSql(MetadataTable.METADATA_CHANGE_HISTORY.name(), columns, insertSql);

        Object[] insertParams = new Object[]{
                metadataChangeHistory.getId(),
                metadataChangeHistory.getNamespace(),
                metadataChangeHistory.getChangeTime(),
                metadataChangeHistory.getUserEmail(),
                metadataChangeHistory.getComment(),
                metadataChangeHistory.getAction()
        };
        jdbcTemplate.update(insertSql.toString(), insertParams);
    }

    @Override
    public List<MetadataChangeHistory> findMetadataChangeHistoryByNamespace(String namespace) {
        String[] columns = {ID, NAMESPACE, CHANGE_TIME, USER_EMAIL, COMMENT, ACTION};
        StringBuilder selectSql = new StringBuilder(SELECT)
                .append(StringUtils.join(columns, COMMA))
                .append(FROM)
                .append(MetadataTable.METADATA_CHANGE_HISTORY);
        List<Object> params = new ArrayList<>();
        selectSql.append(WHERE_1_1);
        buildQueryCondition(NAMESPACE, namespace, selectSql, params);

        return jdbcTemplate.query(selectSql.toString(), params.toArray(), (rs, rowNum) -> {
            String id = rs.getString(ID);
            Instant changeTime = rs.getTimestamp(CHANGE_TIME).toInstant();
            String ns = rs.getString(NAMESPACE);
            String userEmail = rs.getString(USER_EMAIL);
            String comment = rs.getString(COMMENT);
            String action = rs.getString(ACTION);
            return new MetadataChangeHistory(id, changeTime, comment, ns, userEmail, action);
        });
    }

    @Override
    public List<MetadataDraftModel> selectAllMetadataDraftModelsInfo(boolean includeJsonModel) {
        String[] columns = {MD_DOT.concat(ID), MD_DOT.concat(NAMESPACE), MD_DOT.concat(VERSION),
                MD_DOT.concat(DESCRIPTION), MPT_DOT.concat(DESCRIPTION ).concat(AS_TRANSLATION_DESC),
                MD_DOT.concat(STATUS).concat(AS_DRAFTSTATUS), MP_DOT.concat(STATUS), MD_DOT.concat(UPDATED_AT)};
        if (includeJsonModel) {
            columns = new String[]{MD_DOT.concat(ID), MD_DOT.concat(NAMESPACE), MD_DOT.concat(VERSION),
                    MD_DOT.concat(DESCRIPTION), MPT_DOT.concat(DESCRIPTION ).concat(AS_TRANSLATION_DESC),
                    MD_DOT.concat(STATUS).concat(AS_DRAFTSTATUS), MP_DOT.concat(STATUS), MD_DOT.concat(UPDATED_AT), JSON_MODEL};
        }
        StringBuilder selectSql = new StringBuilder(SELECT)
                .append(StringUtils.join(columns, COMMA))
                .append(FROM)
                .append(MetadataTable.METADATA_DRAFT_MODEL)
                .append(MD_LEFT_JOIN)
                .append(MetadataTable.METADATA_PROJECT)
                .append(MP_ON)
                .append(MP_NAMESPACE)
                .append(EQUAL)
                .append(MD_DOT.concat(NAMESPACE))
                .append(SPACE)
                .append(LEFT_JOIN)
                .append(LEFT_BRACE)
                .append(SELECT)
                .append(METADATA_PROJECT_ID)
                .append(COMMA)
                .append(DESCRIPTION)
                .append(FROM)
                .append(MetadataTable.METADATA_PROJECT_TEXTS)
                .append(WHERE_1_1)
                .append(AND)
                .append(LOCALE)
                .append(EQUAL)
                .append(QUESTION_MARK)
                .append(RIGHT_BRACE)
                .append(MPT_ON)
                .append(MPT_METADATA_PROJECT_ID)
                .append(EQUAL)
                .append(MP_ID)
                .append(SPACE);
        List<Object> params = new ArrayList<>();
        params.add(getLocale());
        selectSql.append(WHERE_1_1)
                .append(ORDER_BY)
                .append(UPDATED_AT)
                .append(DESC);

        return jdbcTemplate.query(selectSql.toString(), params.toArray(), (rs, rowNum) -> {
            String id = rs.getString(ID);
            String ns = rs.getString(NAMESPACE);
            String version = rs.getString(VERSION);
            String description = rs.getString(DESCRIPTION);
            String translationDesc = rs.getString(TRANSLATION_DESC);
            if (StringUtils.isNotBlank(translationDesc)) {
                description = translationDesc;
            }
            String draftStatus = rs.getString(DRAFTSTATUS);
            String status = rs.getString(STATUS);
            Instant updatedAt = rs.getTimestamp(UPDATED_AT).toInstant();
            String jsonModel = null;
            if (includeJsonModel) {
                jsonModel = rs.getString(JSON_MODEL);
            }
            return new MetadataDraftModel(id, ns, version, description, draftStatus, status, jsonModel, updatedAt);
        });
    }

    @Override
    public MetadataDraftModel getMetadataDraftModelInfoByNamespace(String namespace) {
        String[] columns = {MD_DOT.concat(ID), MD_DOT.concat(NAMESPACE), MD_DOT.concat(VERSION), MD_DOT.concat(DESCRIPTION), MD_DOT.concat(STATUS).concat(AS_DRAFTSTATUS), MP_DOT.concat(STATUS), MD_DOT.concat(UPDATED_AT)};
        StringBuilder selectSql = new StringBuilder(SELECT)
                .append(StringUtils.join(columns, COMMA))
                .append(FROM)
                .append(MetadataTable.METADATA_DRAFT_MODEL)
                .append(MD_LEFT_JOIN)
                .append(MetadataTable.METADATA_PROJECT)
                .append(MP_ON)
                .append(MP_NAMESPACE)
                .append(EQUAL)
                .append(MD_DOT.concat(NAMESPACE))
                .append(SPACE);
        List<Object> params = new ArrayList<>();
        selectSql.append(WHERE_1_1);
        buildQueryCondition(MD_DOT.concat(NAMESPACE), namespace, selectSql, params);

        List<MetadataDraftModel> result = jdbcTemplate.query(selectSql.toString(), params.toArray(), (rs, rowNum) -> {
            String id = rs.getString(ID);
            String ns = rs.getString(NAMESPACE);
            String version = rs.getString(VERSION);
            String description = rs.getString(DESCRIPTION);
            String draftStatus = rs.getString(DRAFTSTATUS);
            String status = rs.getString(STATUS);
            Instant updatedAt = rs.getTimestamp(UPDATED_AT).toInstant();
            return new MetadataDraftModel(id, ns, version, description, draftStatus, status, null, updatedAt);
        });
        if (!result.isEmpty()) {
            return result.get(0);
        } else {
            return null;
        }
    }

    @Override
    public MetadataDraftModel getMetadataDraftModelByNamespace(String namespace) {
        String[] columns = new String[]{MD_DOT.concat(ID), MD_DOT.concat(NAMESPACE), MD_DOT.concat(VERSION), MD_DOT.concat(DESCRIPTION), MD_DOT.concat(STATUS).concat(AS_DRAFTSTATUS), MP_DOT.concat(STATUS), MD_DOT.concat(UPDATED_AT), JSON_MODEL};
        StringBuilder selectSql = new StringBuilder(SELECT)
                .append(StringUtils.join(columns, COMMA))
                .append(FROM)
                .append(MetadataTable.METADATA_DRAFT_MODEL)
                .append(MD_LEFT_JOIN)
                .append(MetadataTable.METADATA_PROJECT)
                .append(MP_ON)
                .append(MP_NAMESPACE)
                .append(EQUAL)
                .append(MD_DOT.concat(NAMESPACE))
                .append(SPACE);
        List<Object> params = new ArrayList<>();
        selectSql.append(WHERE_1_1);
        buildQueryCondition(MD_DOT.concat(NAMESPACE), namespace, selectSql, params);

        List<MetadataDraftModel> result = jdbcTemplate.query(selectSql.toString(), params.toArray(), (rs, rowNum) -> {
            String id = rs.getString(ID);
            String ns = rs.getString(NAMESPACE);
            String version = rs.getString(VERSION);
            String description = rs.getString(DESCRIPTION);
            String draftStatus = rs.getString(DRAFTSTATUS);
            String status = rs.getString(STATUS);
            Instant updatedAt = rs.getTimestamp(UPDATED_AT).toInstant();
            String jsonModel = rs.getString(JSON_MODEL);
            return new MetadataDraftModel(id, ns, version, description, draftStatus, status, jsonModel, updatedAt);
        });
        if (!result.isEmpty()) {
            return result.get(0);
        } else {
            return null;
        }
    }

    @Override
    public void insertMetadataDraftModel(MetadataDraftModel metadataDraftModel) {
        StringBuilder insertSql = new StringBuilder();
        String[] columns = {ID, NAMESPACE, VERSION, DESCRIPTION, STATUS, JSON_MODEL, UPDATED_AT};
        DBUtils.buildInsertSql(MetadataTable.METADATA_DRAFT_MODEL.name(), columns, insertSql);

        Object[] insertParams = new Object[]{
                metadataDraftModel.getId(),
                metadataDraftModel.getNamespace(),
                metadataDraftModel.getVersion(),
                metadataDraftModel.getDescription(),
                metadataDraftModel.getDraftStatus(),
                metadataDraftModel.getJsonModel(),
                metadataDraftModel.getUpdatedAt()
        };
        jdbcTemplate.update(insertSql.toString(), insertParams);

    }

    @Override
    public void updateMetadataDraftModelInfo(MetadataDraftModel metadataDraftModel) {
        StringBuilder updateSql = new StringBuilder();
        List<Object> updateParam = new ArrayList<>();

        String[] updatedColumns = {VERSION, DESCRIPTION, STATUS, UPDATED_AT};
        Object[] updatedVal = {
                metadataDraftModel.getVersion(),
                metadataDraftModel.getDescription(),
                metadataDraftModel.getDraftStatus(),
                metadataDraftModel.getUpdatedAt()
        };
        String[] whereColumns = {NAMESPACE};
        Object[] whereVals = {metadataDraftModel.getNamespace()};

        DBUtils.buildUpdateSql(MetadataTable.METADATA_DRAFT_MODEL.name(),
                updatedColumns,
                updatedVal,
                whereColumns,
                whereVals,
                updateSql,
                updateParam);
        jdbcTemplate.update(updateSql.toString(), updateParam.toArray());
    }

    @Override
    public void updateMetadataDraftModel(String namespace, MetadataDraftModel metadataDraftModel) {
        StringBuilder updateSql = new StringBuilder();
        List<Object> updateParam = new ArrayList<>();

        String[] updatedColumns = {NAMESPACE, VERSION, DESCRIPTION, STATUS, JSON_MODEL, UPDATED_AT};
        Object[] updatedVal = {
                metadataDraftModel.getNamespace(),
                metadataDraftModel.getVersion(),
                metadataDraftModel.getDescription(),
                metadataDraftModel.getDraftStatus(),
                metadataDraftModel.getJsonModel(),
                metadataDraftModel.getUpdatedAt()
        };
        String[] whereColumns = {NAMESPACE};
        Object[] whereVals = {namespace};

        DBUtils.buildUpdateSql(MetadataTable.METADATA_DRAFT_MODEL.name(),
                updatedColumns,
                updatedVal,
                whereColumns,
                whereVals,
                updateSql,
                updateParam);
        jdbcTemplate.update(updateSql.toString(), updateParam.toArray());
    }

    @Override
    public void deleteMetadataDraftModel(String namespace) {
        Object[] whereVals = {namespace};
        StringBuilder deleteSql = new StringBuilder();
        String[] whereColumns = {NAMESPACE};
        DBUtils.buildDeleteSql(MetadataTable.METADATA_DRAFT_MODEL.name(), whereColumns, whereVals, deleteSql);
        jdbcTemplate.update(deleteSql.toString(), whereVals);
    }

    private String getFieldValue(String ret, MetadataProjectFile projectFile, Field field) {
        if (field != null) {
            ReflectionUtils.makeAccessible(field);
            try {
                ret = DBUtils.toStringValue(field.get(projectFile));
            } catch (IllegalAccessException e) {
                logger.warn(e.getMessage(), e);
            }
        }
        return ret;
    }

    private String getLocale() {
        Locale locale = ISAPCloudPlatformAgent.ICurrentAccessContext.getLocale();
        return locale.toString();
    }

    private DatabaseType getDatabaseType() {
        return currentAccessContext.getDatabaseServiceInstance().getDatabaseType();
    }

    @Override
    public void saveMetadataEvents(MetadataProcess metadataProcess) {
        final List<MetadataEvent> metadataEvents = metadataProcess.getMetadataEvents();
        if (metadataEvents.isEmpty()) {
            return;
        }
        String metadataProcessId = metadataProcess.getId();
        deleteMetadataEventsInfo(metadataProcessId);
        // insert metadata event information
        metadataEvents.forEach(e -> {
            StringBuilder insertSql = new StringBuilder();
            String[] columns = {ID, METADATA_PROCESS_ID, EVENT_TYPE, DESCRIPTION};
            DBUtils.buildInsertSql(MetadataTable.METADATA_EVENT.name(), columns, insertSql);
            Object[] insertParams = new Object[]{
                    e.getId(),
                    e.getMetadataProcessId(),
                    e.getEventType(),
                    e.getDescription()
            };
            jdbcTemplate.update(insertSql.toString(), insertParams);

            // insert metadata event description information
            List<MetadataEventText> metadataEventTexts = e.getMetadataEventTexts();
            if (!metadataEventTexts.isEmpty()) {
                List<Object[]> batchArgs = new ArrayList<>();
                columns = new String[]{METADATA_EVENT_ID, LOCALE, DESCRIPTION};
                insertSql = new StringBuilder();
                DBUtils.buildInsertSql(MetadataTable.METADATA_EVENT_TEXTS.name(), columns, insertSql);
                metadataEventTexts.forEach(t -> batchArgs.add(new Object[]{t.getMetadataEventId(), t.getLocale(), t.getDescr()}));
                jdbcTemplate.batchUpdate(insertSql.toString(), batchArgs);
            }
        });
    }

    private void deleteMetadataEventsInfo(String metadataProcessId) {
        String[] whereColumns = {METADATA_PROCESS_ID};
        Object[] whereVals = {metadataProcessId};
        StringBuilder deleteSql = new StringBuilder();
        //delete metadata event and its corresponding description by metadataProcessId:
        //delete from metadata_event_texts where metadata_event_id in (select id from metadata_event where metadata_process_id = ?)
        DBUtils.buildDeleteSqlUsingSubQuery(MetadataTable.METADATA_EVENT_TEXTS.name(), METADATA_EVENT_ID, whereVals,
                MetadataTable.METADATA_EVENT.name(), ID, METADATA_PROCESS_ID, deleteSql
        );
        jdbcTemplate.update(deleteSql.toString(), whereVals);
        deleteSql = new StringBuilder();
        DBUtils.buildDeleteSql(MetadataTable.METADATA_EVENT.name(), whereColumns, whereVals, deleteSql);
        jdbcTemplate.update(deleteSql.toString(), whereVals);
    }
}