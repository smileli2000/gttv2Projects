package com.sap.gtt.v2.core.domain.metadata;

/**
 * To record the model level configuration when generating derived csn
 * @author I321712
 */
public class ModelConfiguration {
    private boolean enableInstanceBasedAuthorization;
    private int eventCorrelationLevel = 1;

    public boolean isEnableInstanceBasedAuthorization() {
        return enableInstanceBasedAuthorization;
    }

    public void setEnableInstanceBasedAuthorization(boolean enableInstanceBasedAuthorization) {
        this.enableInstanceBasedAuthorization = enableInstanceBasedAuthorization;
    }

    public int getEventCorrelationLevel() {
        return eventCorrelationLevel;
    }

    public void setEventCorrelationLevel(int eventCorrelationLevel) {
        this.eventCorrelationLevel = eventCorrelationLevel;
    }
}
