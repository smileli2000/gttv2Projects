package com.sap.gtt.v2.core.dao.metadata;

import com.sap.gtt.v2.core.domain.metadata.MetadataConstants.CdsDataType;
import com.sap.gtt.v2.core.domain.metadata.MetadataEntity;
import com.sap.gtt.v2.core.domain.metadata.MetadataEntityElement;
import com.sap.gtt.v2.core.domain.metadata.PhysicalName;
import com.sap.gtt.v2.util.DBUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.util.stream.Collectors;

import static com.sap.gtt.v2.core.domain.metadata.MetadataConstants.CdsDataType.CDS_DECIMAL;
import static com.sap.gtt.v2.core.domain.metadata.MetadataConstants.MetadataTable.METADATA_PROCESS_TEXTS;
import static com.sap.gtt.v2.core.domain.metadata.MetadataConstants.MetadataTable.METADATA_PROJECT_TEXTS;

/**S
 * @author I321712
 */
public abstract class AbstractDefaultDDLBuilder implements DDLBuilder {


    public static final String ALTER_TABLE = "ALTER TABLE ";
    public static final String DROP_TABLE = "DROP TABLE ";
    public static final String DELETE_TABLE = "DELETE FROM ";
    public static final String INSERT_TABLE = "INSERT INTO ";
    public static final String INFORMATION_SCHEMA_TABLES = "information_schema.tables";
    private EnumMap<CdsDataType, String> cdsDataTypeSqlTypeMap = new EnumMap<>(CdsDataType.class);

    protected Logger logger = LoggerFactory.getLogger(getClass());

    /**
     * CdsDataType to SQL data type mapping
     *
     * @return CdsDataType to SQL data type
     */
    protected Map<CdsDataType, String> getCdsDataTypeSqlTypeMapping() {
        if (cdsDataTypeSqlTypeMap.size() == 0) {
            for (CdsDataType cdsDataType : CdsDataType.values()) {
                cdsDataTypeSqlTypeMap.put(cdsDataType, cdsDataType.getSqlType());
            }
        }
        return cdsDataTypeSqlTypeMap;
    }

    protected String buildCreateTableSQL(String entityName, List<MetadataEntityElement> elements, boolean isColumnTable, boolean supportIfNotExisted) {
        String tableName = DBUtils.toTableName(entityName);
        List<String> primarykeys = elements.stream().filter(MetadataEntityElement::isKey).map(MetadataEntityElement::getName).collect(Collectors.toList());
        StringBuilder sb = new StringBuilder("CREATE ")
                .append(isColumnTable ? " COLUMN " : "")
                .append(" TABLE ")
                .append(supportIfNotExisted ? " IF NOT EXISTS " : "")
                .append(tableName).append("( ");
        buildColumnForAddFieldCreateTable(elements, sb);
        if (primarykeys != null && !primarykeys.isEmpty()) {
            sb.append(",PRIMARY KEY(")
                    .append(StringUtils.join(primarykeys.iterator(), ","))
                    .append(")");
        }
        sb.append(")");
        return sb.toString();
    }

    @Override
    public String buildAddTableField(String entityName, List<MetadataEntityElement> elements) {
        String tableName = DBUtils.toTableName(entityName);
        StringBuilder sb = new StringBuilder(ALTER_TABLE).append(tableName).append(" ADD ( ");
        buildColumnForAddFieldCreateTable(elements, sb);
        sb.append(")");
        return sb.toString();
    }

    protected void buildColumnForAddFieldCreateTable(List<MetadataEntityElement> elements, StringBuilder sqlSb) {
        for (int i = 0; i < elements.size(); i++) {
            MetadataEntityElement element = elements.get(i);
            buildColumn(element, sqlSb);
            if (i < elements.size() - 1) {
                sqlSb.append(",");
            }
        }
    }

    @Override
    public List<String> buildAlterTableField(String entityName, List<MetadataEntityElement> elements) {
        List<String> updateFieldSqls = new ArrayList<>();
        String tableName = DBUtils.toTableName(entityName);
        for (int i = 0; i < elements.size(); i++) {
            StringBuilder sb = new StringBuilder(ALTER_TABLE).append(tableName).append(" ALTER ");
            MetadataEntityElement element = elements.get(i);
            buildColumn(element, sb);
            updateFieldSqls.add(sb.toString());
        }
        return updateFieldSqls;
    }

    @Override
    public String buildDropTableField(String entityName, List<MetadataEntityElement> elements) {
        String tableName = DBUtils.toTableName(entityName);
        StringBuilder sb = new StringBuilder(ALTER_TABLE).append(tableName).append(" DROP ( ");
        for (int i = 0; i < elements.size(); i++) {
            MetadataEntityElement element = elements.get(i);
            sb.append(element.getName());
            if (i < elements.size() - 1) {
                sb.append(",");
            }
        }
        sb.append(")");
        return sb.toString();
    }

    @Override
    public String buildDropTable(String entityName) {
        String tableName = DBUtils.toTableName(entityName);
        return new StringBuilder(DROP_TABLE).append(tableName).toString();
    }

    @Override
    public String buildDeleteTable(String entityName) {
        String tableName = DBUtils.toTableName(entityName);
        return new StringBuilder(DELETE_TABLE).append(tableName).toString();
    }

    @Override
    public String buildInsertTableForCodeList(String entityName) {
        String tableName = DBUtils.toTableName(entityName);
        return new StringBuilder(INSERT_TABLE)
                .append(tableName)
                .append(" (code, name) VALUES (?, ?)").toString();
    }

    @Override
    public String buildInsertTableForCodeListTexts(String entityName) {
        String tableName = DBUtils.toTableName(entityName);
        return new StringBuilder(INSERT_TABLE)
                .append(tableName)
                .append(" (code, name, locale) VALUES (?, ?, ?)").toString();
    }

    @Override
    public String buildDeleteTableForMetadataProcessTexts() {
        return new StringBuilder(DELETE_TABLE)
                .append(METADATA_PROCESS_TEXTS)
                .append(" WHERE METADATA_PROCESS_ID IN ( ")
                .append(" SELECT T1.ID  ")
                .append(" FROM METADATA_PROCESS T1 ")
                .append(" INNER JOIN METADATA_PROJECT T2 ON (T1.METADATA_PROJECT_ID = T2.ID) ")
                .append(" WHERE  T2.namespace = ?) ")
                .toString();
    }

    @Override
    public String buildDeleteTableForMetadataProjectTexts() {
        return new StringBuilder(DELETE_TABLE)
                .append(METADATA_PROJECT_TEXTS)
                .append(" WHERE METADATA_PROJECT_ID IN ( ")
                .append(" SELECT T1.ID  ")
                .append(" FROM METADATA_PROJECT T1 ")
                .append(" WHERE  T1.namespace = ?) ")
                .toString();
    }

    @Override
    public String buildInsertTableForMetadataProcessTexts() {
        return new StringBuilder(INSERT_TABLE)
                .append(METADATA_PROCESS_TEXTS.name())
                .append(" (METADATA_PROCESS_ID , LOCALE, DESCRIPTION) VALUES (?, ?, ?)").toString();
    }


    @Override
    public void buildColumn(MetadataEntityElement element, StringBuilder sqlBuf) {
        CdsDataType type = element.getType();
        int length = element.getLength();
        sqlBuf.append(element.getName()).append(" ").append(getCdsDataTypeSqlTypeMapping().get(type));
        if (CDS_DECIMAL.equals(type)) {
            sqlBuf.append(String.format("(%s,%s)", element.getPrecision(), element.getScale()));
        } else {
            if (length > 0) {
                sqlBuf.append(String.format("(%s)", length));
            }
        }
    }

    protected String getSysTablesName() {
        return INFORMATION_SCHEMA_TABLES;
    }

    protected String getCurrentSchemaCondition() {
        return StringUtils.EMPTY;
    }

    @Override
    public void buildFindTableQuery(List<MetadataEntity> entities, StringBuilder sqlBuf, List<String> params) {
        if (entities == null || entities.isEmpty()) {
            return;
        }
        params.clear();
        sqlBuf.append("SELECT TABLE_NAME FROM ").append(getSysTablesName()).append(" where ");
        int size = entities.size();
        String schemaCondition = getCurrentSchemaCondition();
        boolean notBlank = StringUtils.isNotBlank(schemaCondition);
        if (notBlank) {
            sqlBuf.append(schemaCondition).append(" ");
        }
        for (int i = 0; i < size; i++) {
            if (notBlank && i == 0) {
                sqlBuf.append(" AND ( ");
            }
            MetadataEntity entity = entities.get(i);
            PhysicalName physicalName = entity.getPhysicalName();
            String name = physicalName.getName().toUpperCase(Locale.ENGLISH);
            sqlBuf.append("upper(TABLE_NAME) = ? ");
            if (i < size - 1) {
                sqlBuf.append(" OR ");
            }
            if (notBlank && i == size - 1) {
                sqlBuf.append(" ) ");
            }
            params.add(name);
        }
    }

    @Override
    public String buildInsertTableForMetadataProjectTexts() {
        return new StringBuilder(INSERT_TABLE)
                .append(METADATA_PROJECT_TEXTS.name())
                .append(" (METADATA_PROJECT_ID , LOCALE, DESCRIPTION) VALUES (?, ?, ?)").toString();
    }
}