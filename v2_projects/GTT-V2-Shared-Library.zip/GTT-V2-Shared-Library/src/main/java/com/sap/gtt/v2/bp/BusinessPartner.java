package com.sap.gtt.v2.bp;

import com.google.gson.annotations.SerializedName;
import com.sap.gtt.v2.configuration.ServiceInstancesMapping;
import com.sap.gtt.v2.core.domain.trackedprocess.CorrelatedEventInner;
import com.sap.gtt.v2.core.runtime.model.IPropertyValue;
import com.sap.gtt.v2.core.runtime.model.ObjectValue;
import com.sap.gtt.v2.util.SpringContextUtils;
import com.sap.gtt.v2.configuration.EnvironmentsConfiguration.VcapServiceParser.SaasRegistryServiceInstance;
import org.springframework.stereotype.Component;

import java.beans.Transient;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * @author I053866
 */
public class BusinessPartner{

    public static final String ID = "Id";
    public static final String BP_NAME = "BpName";
    public static final String EMAIL = "Email";
    public static final String LBN_ID = "LbnId";
    public static final String TENANT_ID = "TenantId";
    public static final String SUB_DOMAIN = "SubDomain";
    public static final String BP_ACCOUNT_DETAILS = "bpAccountDetails";

    @SerializedName("Id")
    private String id;
    @SerializedName("BpName")
    private String bpName;
    @SerializedName("Email")
    private String email;
    @SerializedName("LbnId")
    private String lbnId;
    @SerializedName("TenantId")
    private String tenantId;
    @SerializedName("SubDomain")
    private String subDomain;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getBpName() {
        return bpName;
    }

    public void setBpName(String bpName) {
        this.bpName = bpName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getLbnId() {
        return "LBN#" + lbnId;
    }

    public void setLbnId(String lbnId) {
        this.lbnId = lbnId;
    }

    public String getTenantId() {
        return tenantId;
    }

    public void setTenantId(String tenantId) {
        this.tenantId = tenantId;
    }

    public String getSubDomain() {
        return subDomain;
    }

    public void setSubDomain(String subDomain) {
        this.subDomain = subDomain;
    }

    // BP Account
    private List<BPAccountDetail> bpAccountDetails = new ArrayList<>();

    public List<BPAccountDetail> getBpAccountDetails() {
        return bpAccountDetails;
    }

    public void setBpAccountDetails(List<BPAccountDetail> bpAccountDetails) {
        this.bpAccountDetails = bpAccountDetails;
    }

    public boolean subscribedGTTStandalone(){
        BPAccountDetail bpAccountDetail = this.getSubscribedGTTBPAccountDetail();
    	return bpAccountDetail != null;
    }

    public boolean isGTTStandaloneProductive(){
        BPAccountDetail detail = this.getSubscribedGTTBPAccountDetail();
    	return detail != null && ("default").equalsIgnoreCase(detail.getSubscribedPlan());
    }

    private BPAccountDetail getSubscribedGTTBPAccountDetail() {
        ServiceInstancesMapping serviceInstancesMapping = SpringContextUtils.getBean(ServiceInstancesMapping.class);

        SaasRegistryServiceInstance saasRegistryServiceInstance = serviceInstancesMapping.getApplicationSaasRegistryServiceInstance();
        String appName = saasRegistryServiceInstance.getAppName();
        for(int i = 0; i<this.bpAccountDetails.size();i++) {
            BPAccountDetail detail = this.bpAccountDetails.get(i);
            if(detail.getSubscribedApp().equalsIgnoreCase(appName))
                return detail;
        }
        return null;
    }

    public ObjectValue convertToObjectValue() {
        ObjectValue objectValue = new ObjectValue();
        objectValue.setValue(ID, this.getId());
        objectValue.setValue(BP_NAME, this.getBpName());
        objectValue.setValue(EMAIL, this.getEmail());
        objectValue.setValue(LBN_ID, this.getLbnId());
        objectValue.setValue(TENANT_ID, this.getTenantId());
        objectValue.setValue(SUB_DOMAIN, this.getSubDomain());

        List<IPropertyValue> list = new ArrayList<>();
        for(BPAccountDetail detail : this.getBpAccountDetails()) {
            ObjectValue tmp = detail.convertToObjectValue();
            list.add(tmp);
        }
        objectValue.setValue(BP_ACCOUNT_DETAILS, list);

        return objectValue;
    }
}
