package com.sap.gtt.v2.core.domain.execution;

import java.time.Instant;

/**
 * @author I302310
 */
public class RequestPayloadDto {
    private String id;
    private String parentId;
    private String messageNumber;
    private String sourceId;
    private String source;
    private Instant requestDataTime;
    private String writeServicePath;
    private String payload;
    private String subaccountId;
    private String cloneInstanceId;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public String getMessageNumber() {
        return messageNumber;
    }

    public void setMessageNumber(String messageNumber) {
        this.messageNumber = messageNumber;
    }

    public String getSourceId() {
        return sourceId;
    }

    public void setSourceId(String sourceId) {
        this.sourceId = sourceId;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public Instant getRequestDataTime() {
        return requestDataTime;
    }

    public void setRequestDataTime(Instant requestDataTime) {
        this.requestDataTime = requestDataTime;
    }

    public String getWriteServicePath() {
        return writeServicePath;
    }

    public void setWriteServicePath(String writeServicePath) {
        this.writeServicePath = writeServicePath;
    }

    public String getPayload() {
        return payload;
    }

    public void setPayload(String payload) {
        this.payload = payload;
    }

    public String getSubaccountId() {
        return subaccountId;
    }

    public void setSubaccountId(String subaccountId) {
        this.subaccountId = subaccountId;
    }

    public String getCloneInstanceId() {
        return cloneInstanceId;
    }

    public void setCloneInstanceId(String cloneInstanceId) {
        this.cloneInstanceId = cloneInstanceId;
    }
}
