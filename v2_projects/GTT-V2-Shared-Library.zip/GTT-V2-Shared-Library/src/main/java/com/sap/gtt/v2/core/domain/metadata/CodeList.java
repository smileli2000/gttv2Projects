package com.sap.gtt.v2.core.domain.metadata;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.StringJoiner;

/**
 * @author I301346
 */
public class CodeList implements Serializable {
    private static final long serialVersionUID = 1L;

    private String fullEntityName;

    private List<CodeListValue> codeListValues = new ArrayList<>();

    public String getFullEntityName() {
        return fullEntityName;
    }

    public void setFullEntityName(String fullEntityName) {
        this.fullEntityName = fullEntityName;
    }

    public List<CodeListValue> getCodeListValues() {
        return new ArrayList<>(codeListValues);
    }

    public void addCodeListValue(CodeListValue codeListValues) {
        this.codeListValues.add(codeListValues);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        CodeList entity = (CodeList) o;
        return fullEntityName.equals(entity.fullEntityName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(fullEntityName);
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", CodeList.class.getSimpleName() + "[", "]")
                .add("fullEntityName='" + fullEntityName + "'")
                .toString();
    }
}
