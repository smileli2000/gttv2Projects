package com.sap.gtt.v2.core.entity.metadata;

public class MetadataProcessText extends ObjectText {
    public String getMetadataProcessId() {
        return metadataProcessId;
    }

    public void setMetadataProcessId(String metadataProcessId) {
        this.metadataProcessId = metadataProcessId;
    }

    private String metadataProcessId;
}
