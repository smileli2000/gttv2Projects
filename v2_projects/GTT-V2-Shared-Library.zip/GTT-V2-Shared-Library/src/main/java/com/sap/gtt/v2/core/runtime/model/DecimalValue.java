package com.sap.gtt.v2.core.runtime.model;

import java.math.BigDecimal;

import com.sap.gtt.v2.exception.ValueParseException;

public final class DecimalValue extends NumberValue<BigDecimal>  {

    private DecimalValue(BigDecimal internalValue) {
        super(internalValue);
    }

   
	

	@Override
	protected IPropertyValue addInternal(IPropertyValue that) {
		BigDecimal resultValue = BigDecimal.valueOf(this.getInternalValue().doubleValue());
		if(that instanceof IntegerValue){
			return new DecimalValue(resultValue.add(BigDecimal.valueOf(((IntegerValue)that).getInternalValue())));
		}
		else if(that instanceof DecimalValue){
			return new DecimalValue(resultValue.add(((DecimalValue)that).getInternalValue()));
		}
		else{
			throw new UnsupportedOperationException(UnsupportedOperationException.class.getSimpleName());
		}
	}

	@Override
	public IPropertyValue subInternal(IPropertyValue that) {
		BigDecimal resultValue = BigDecimal.valueOf(this.getInternalValue().doubleValue());
		if(that instanceof IntegerValue){
			return new DecimalValue(resultValue.subtract(BigDecimal.valueOf(((IntegerValue)that).getInternalValue())));
		}
		else if(that instanceof DecimalValue){
			return new DecimalValue(resultValue.subtract(((DecimalValue)that).getInternalValue()));
		}
		else{
			throw new UnsupportedOperationException(UnsupportedOperationException.class.getSimpleName());
		}
	}
	
	@Override
	public IPropertyValue mulInternal(IPropertyValue that) {
		BigDecimal resultValue = BigDecimal.valueOf(this.getInternalValue().doubleValue());
		if(that instanceof IntegerValue){
			return new DecimalValue(resultValue.multiply(BigDecimal.valueOf(((IntegerValue)that).getInternalValue())));
		}
		else if(that instanceof DecimalValue){
			return new DecimalValue(resultValue.multiply(((DecimalValue)that).getInternalValue()));
		}
		else{
			throw new UnsupportedOperationException(UnsupportedOperationException.class.getSimpleName());
		}
	}

	@Override
	public IPropertyValue divInternal(IPropertyValue that) {
		BigDecimal resultValue = BigDecimal.valueOf(this.getInternalValue().doubleValue());
		if(that instanceof IntegerValue){
			return new DecimalValue(resultValue.divide(BigDecimal.valueOf(((IntegerValue)that).getInternalValue())));
		}
		else if(that instanceof DecimalValue){
			return new DecimalValue(resultValue.divide(((DecimalValue)that).getInternalValue()));
		}
		else{
			throw new UnsupportedOperationException(UnsupportedOperationException.class.getSimpleName());
		}
	}

	@Override
	protected IPropertyValue powInternal(IPropertyValue that) {
		if(that instanceof IntegerValue){
			BigDecimal resultValue = BigDecimal.valueOf(this.getInternalValue().doubleValue());
			return new DecimalValue(resultValue.pow(((IntegerValue)that).getInternalValue()));
		}
		else if(that instanceof DecimalValue){
			return new DecimalValue(BigDecimal.valueOf(Math.pow(this.getInternalValue().doubleValue(), ((DecimalValue)that).getInternalValue().doubleValue())));
		}
		else{
			throw new UnsupportedOperationException(UnsupportedOperationException.class.getSimpleName());
		}
	}
	
	@Override
	protected IPropertyValue negateInternal() {
		BigDecimal resultValue = BigDecimal.valueOf(this.getInternalValue().doubleValue());
		return new DecimalValue(resultValue.negate());
	}


	@Override
	protected int compareToInternal(IPropertyValue that) {
		
		int compareResult = 0;
		if(that instanceof IntegerValue){
			compareResult = this.getInternalValue().compareTo(new BigDecimal(((IntegerValue)that).getInternalValue()));
		}
		else if(that instanceof DecimalValue){
			compareResult = this.getInternalValue().compareTo(((DecimalValue)that).getInternalValue());
		}
		else{
			throw new UnsupportedOperationException(UnsupportedOperationException.class.getSimpleName());
		}
		
		return compareResult;
	}



	public static DecimalValue valueOf(BigDecimal value){
		return new DecimalValue(value);
	}

	public static DecimalValue valueOf(double value){
		return valueOf(BigDecimal.valueOf(value));
	}
	
	public static DecimalValue valueOf(String value){
		try{
			return valueOf(BigDecimal.valueOf(Double.parseDouble(value)));
		}
		catch(NumberFormatException e){
			throw new ValueParseException(e.getLocalizedMessage(), e);
		}
	}

	
    
}
