package com.sap.gtt.v2.core.management.metadata;

import com.sap.gtt.v2.core.dao.metadata.IMetadataDao;
import com.sap.gtt.v2.core.domain.metadata.*;
import com.sap.gtt.v2.core.entity.metadata.*;
import org.apache.commons.lang3.tuple.Pair;

import java.util.List;
import java.util.Map;

/**
 * Interface to extract metadata parts required by the core engine. An
 * implementation of this interface could e.g. take a CSN and extract the
 * requested data from that CSN.
 *
 * @author I321712
 */
public interface IMetadataManagement {

    public IMetadataDao getMetadataDao();

    /**
     * Find all the process metadata by given criteria.
     *
     * @param criteria search criteria
     * @return list of MetadataProcess
     */
    List<MetadataProcess> findAllMetadataProcess(MetadataCriteria criteria);

    /**
     * Find all the metadata project basic information
     *
     * @return all the metedata project basic information
     */
    List<MetadataProject> findAllMetadataProject();

    /**
     * Find all the metadata project information including metadata project, metadata process or metadata project file
     * by criteria.
     *
     * @param criteria criteria
     * @return list of MetadataProject
     */
    List<MetadataProject> findMetadataProjectInfo(MetadataCriteria criteria);

    /**
     * Find all the metadata project information including metadata project and process metadata by namespace.
     *
     * @param namespace namespace
     * @return list of MetadataProject
     */
    List<MetadataProject> findMetadataProjectInfoByNamespace(String namespace);

    /**
     * Insert metadata project information including metadata project, metadata project file
     *
     * @param newMetadataProject new metadata project object
     */
    void insertMetadataProject(MetadataProject newMetadataProject);

    /**
     * Update metadata project including metadata project file except primary key and namespace
     *
     * @param updatedMetadataProject updated metadata project object
     */
    void updateMetadataProject(MetadataProject updatedMetadataProject);

    /**
     * Update metadata project status
     *
     * @param updatedMetadataProject
     */
    void updateMetadataProjectStatus(MetadataProject updatedMetadataProject);

    /**
     * Insert a process metadata
     *
     * @param newMetadataProcess new process metadata
     */
    void insertMetadataProcess(MetadataProcess newMetadataProcess);

    /**
     * Update tracked process type/application object type of a process metadata
     *
     * @param updatedMetadataProcess updated process metadata object
     */
    void updateMetadataProcess(MetadataProcess updatedMetadataProcess);

    /**
     * Insert a process metadata text
     *
     * @param newMetadataProcess new process metadata text
     */
    void upsertMetadataProcessText(MetadataProcess newMetadataProcess);


    /**
     * Delete all the metadata information by namespace
     *
     * @param namespace namespace of a metadata project
     */
    void deleteMetadata(String namespace);

    /**
     * Get metadata project file field information by namespace and field name
     *
     * @param namespace namespace
     * @param fieldName field name
     * @return metadata project file field information
     */
    String getMetadataProjectFileFieldInfo(String namespace, MetadataConstants.MetadataProjectFileField fieldName);

    /**
     * Get metadata project file field information by namespace and field name
     *
     * @param namespace      namespace
     * @param selectedFields field name list
     * @return metadata project file field information
     */
    MetadataProjectFile getMetadataProjectFileInfo(String[] selectedFields, String namespace);

    /**
     * Create all the tables based on the metadata entity list
     *
     * @param newEntities newly added metadata entities
     */
    void createTable(List<MetadataEntity> newEntities);

    /**
     * Drop all the tables based on the metadata entity list
     *
     * @param tobeDroppedEntities to be dropped metadata entities
     */
    void dropTable(List<MetadataEntity> tobeDroppedEntities);

    /**
     * Add new columns to the corresponding tables of specific entities
     *
     * @param newFieldEntities newly added metadata elements
     */
    void addTableField(List<MetadataEntity> newFieldEntities);

    /**
     * Modify columns for specific entities
     *
     * @param modifiedFieldEntities
     */
    void modifyTableField(List<MetadataEntity> modifiedFieldEntities);

    /**
     * Delete columns for specific entities
     *
     * @param deletedFieldEntities
     */
    void deleteTableField(List<MetadataEntity> deletedFieldEntities);

    /**
     * Check whether a given event is an unplanned event
     *
     * @param trackedProcessType tracked process type
     * @param eventType          event type
     * @return true if the given event is an unplanned event
     */
    boolean checkIfEventIsUnplanned(String trackedProcessType, String eventType);

    /**
     * Get the event information of a given entity name via entity type
     *
     * @param entityName entity full name such as com.sap.gtt.app.mim.delivery.DeliveryModel.DeliveryProcess
     * @param eventType  event type such as com.sap.gtt.app.mim.poitem.POItemModel.ConfirmedEvent
     * @return the details of the given event type under a particular entity
     */
    MetadataEntityEvent getEntityEvent(String entityName, String eventType);

    /**
     * Find all the fields of an entity
     *
     * @param namespace  namespace such as com.sap.gtt.app.mim
     * @param entityName entity name such as com.sap.gtt.app.mim.DeliveryModel.DeliveryProcess
     * @return all the fields of the entity
     */
    Map<String, MetadataEntityElement> findAllFieldsOfEntity(String namespace, String entityName);

    /**
     * Get the corresponding tracked process metadata entity by event type.<p/>
     * If there is no tracked process entity found, a MetadataException will be thrown.
     *
     * @param namespace namespace such as com.sap.gtt.app.mim
     * @param eventType process event such as com.sap.gtt.app.mim.POItemModel.POItemEvent
     * @return the corresponding tracked process entity such as com.sap.gtt.app.mim.POItemModel.POItemProcess
     */
    MetadataEntity getTrackedProcessEntityByEventType(String namespace, String eventType);

    /**
     * Get metadata Swagger information for write service including swagger, tp type, event type etc.
     * If the entity is a process event, the corresponding tracked process entity related information will be returned.
     * If the entity is an ordinary event, the planned events will be empty.
     * If the entity is neither a tracked process nor an event, an Internal exception will be thrown.
     * If namespace is not found, an ResourceNotFound exception will be thrown
     *
     * @param namespace       namespace of a metadata project
     * @param eventEntityName entity name
     * @return metadata swagger related information
     */
    MetadataSwaggerInfo getMetadataSwaggerInfo(String namespace, String eventEntityName);


    /**
     * Get physical name of a given entity
     *
     * @param namespace  namespace such as com.sap.gtt.app.mim
     * @param entityName entity name such as com.sap.gtt.app.mim.DeliveryModel.DeliveryProcess
     * @return table name of the entity
     */
    PhysicalName getPhysicalNameOfEntity(String namespace, String entityName);

    /**
     * Get OData Edmx for a given OData model
     *
     * @param odataModel OData model such as com.sap.gtt.app.mim
     * @return Edmx
     */
    String getODataEdmx(String odataModel);

    /**
     * Find all the entities for a given odata main entity type by path
     *
     * @param odataMainEntityType OData main entity type such as com.sap.gtt.app.mim.MIMService.ProcessEventDirectory
     * @param path                path such as event/eventType
     * @return all the corresponding entities of the navigation properties
     */
    List<MetadataEntity> findODataNavigationEntitiesByPath(String odataMainEntityType, String path);

    /**
     * Find all the reversed navigation entities backing to the root event or tracked process for a given entity.
     *
     * @param namespace      model namespace
     * @param entityAbbrName entity abbr name
     * @return
     */
    List<List<MetadataEntity>> findReversedNavigationEntities(String namespace, String entityAbbrName);

    /**
     * Find all the related entities recursively of a given entity
     *
     * @param namespace  namespace
     * @param entityName main entity name
     * @return all the related entities associated the given entity
     */
    CurrentMetadataEntity findAllEntitiesRecursively(String namespace, String entityName);

    /**
     * Insert metadata change history
     *
     * @param metadataChangeHistory
     */
    void insertMetadataChangeHistory(MetadataChangeHistory metadataChangeHistory);

    /**
     * Get metadata change history by namespace
     *
     * @param namespace
     * @return
     */
    List<MetadataChangeHistory> findMetadataChangeHistoryByNamespace(String namespace);

    /**
     * Find all the DPP related fields for a given entity type and DPP type
     *
     * @param namespace  namespace
     * @param entityType entity full name
     * @param dppType    dppType
     * @return all the attributes with the annotation of DPP
     */
    List<String> findDppFieldList(String namespace, String entityType, MetadataConstants.DppType dppType);

    /**
     * Get all draft models information
     *
     * @param includeJsonModel true if including jsonModel
     * @return all the draft models
     */
    List<MetadataDraftModel> getAllMetadataDraftModelsInfo(boolean includeJsonModel);

    /**
     * Create a draft model
     *
     * @param metadataDraftModel
     */
    void createMetadataDraftModel(MetadataDraftModel metadataDraftModel);

    /**
     * Update a draft model header info
     *
     * @param metadataDraftModel
     */
    void updateMetadataDraftModelInfo(MetadataDraftModel metadataDraftModel);

    /**
     * Update a draft model
     *
     * @param namespace
     * @param metadataDraftModel
     */
    void updateMetadataDraftModel(String namespace, MetadataDraftModel metadataDraftModel);

    /**
     * Delete a draft model
     *
     * @param namespace
     */
    void deleteMetadataDraftModel(String namespace);

    /**
     * Get draft model header info by namespace
     *
     * @param namespace
     * @return
     */
    MetadataDraftModel getMetadataDraftModelInfoByNamespace(String namespace);

    /**
     * Get draft model by namespace
     *
     * @param namespace
     * @return
     */
    MetadataDraftModel getMetadataDraftModelByNamespace(String namespace);

    /**
     * Find all the event entity types of a given namespace
     *
     * @param namespace             namespace
     * @param excludeCoreModelEvent true if excludes core model events
     * @return all the event entity types
     */
    List<MetadataEntity> findAllEventEntitiesByNamespace(String namespace, boolean excludeCoreModelEvent);

    /**
     * Find all the tracked process and event entity types of a given namespace
     *
     * @param namespace             namespace
     * @param excludeCoreModelEvent true if excludes core model events
     * @return all the tracked process and event entity types
     */
    List<MetadataEntity> findAllTrackedProcessAndEventEntitiesByNamespace(String namespace, boolean excludeCoreModelEvent);

    /**
     * Get PDM schema
     *
     * @return
     */
    String getPdmSchema();

    /**
     * Upsert PDM schema
     *
     * @param namespace
     * @return
     */
    void upsertPdmSchema(String namespace);

    /**
     * Delete PDM schema
     *
     * @param namespace
     */
    void deletePdmSchema(String namespace);

    /**
     * Check if the dataSubjectId value exists in DB.
     *
     * @param dataSubjectIdValue
     * @return
     */
    boolean isDataSubjectIdValueExistsInDB(String dataSubjectIdValue);

    /**
     * Get the dpp related attributes and the data from DB.
     *
     * @param entityName
     * @param dataSubjectIdValue
     * @return
     */
    List<Map<String, Object>> getPdmDataInfo(String entityName, String dataSubjectIdValue);

    long countTableRows(MetadataEntity metadataEntity);

    /**
     * Get the specified I18N information of a namespace
     *
     * @param namespace namespace
     * @param fileName  i18n file name
     * @return specified i18n file content
     */
    String getI18nInfo(String namespace, String fileName);

    /**
     * Get the uiAnnotation of a namespace
     *
     * @param namespace namespace
     * @return uiAnnotation of a namespace
     */
    String getUiAnnotation(String namespace);

    /**
     * delete table according to the table name
     *
     * @param tableName
     */
    void emptyTable(String tableName);

    /**
     * insert codeList into corresponding tables
     *
     * @param codeList
     */
    void insertCodeList(CodeList codeList);

    /**
     * insert codeListTexts into corresponding tables
     *
     * @param codeList
     */
    void insertCodeListTexts(CodeList codeList);

    /**
     * Get the service namespace for a given model
     *
     * @param modelNamespace  model namespace
     * @param forWriteService true for write service
     * @return service namespace such as com.sap.gtt.app.mim.MIMWriteService
     */
    String getServiceNamespace(String modelNamespace, boolean forWriteService);

    /**
     * Get processEvent forWrite
     *
     * @param processType
     * @return
     */
    CurrentMetadataEntity getProcessEventEntity(String processType);

    /**
     * GetEvent forWrite
     *
     * @param eventType
     * @return
     */
    CurrentMetadataEntity getEventEntity(String eventType);

    /**
     * Get model is active or not
     *
     * @param namespace
     * @return
     */
    boolean isModelActive(String namespace);

    /**
     * Get model level configuration for a given model namespace
     * @param namespace model namespace
     * @return model level configuration such as instanceBasedAuthorizationEnabled flag and event correlation level etc.
     */
    ModelConfiguration getModelConfiguration(String namespace);

    /**
     * Find matched extension field pairs for a given customer event type in replaceActualEventFields
     *
     * @param eventType event type full name
     * @return
     */
    List<Pair<String, String>> findMatchedExtensionFieldPairs(String eventType);

    /**
     * count tracked process
     *
     * @param trackedProcessType
     * @return
     */
    long countTrackedProcessByType(String trackedProcessType);
}