/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.gtt.v2.core.domain.blockingstore;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 *
 * @author I326335
 */
public class ApplicationNamesDto {
    private List<ApplicationNameDto> applicationNames;

    public List<ApplicationNameDto> getApplicationNames() {
        if (applicationNames == null) {
            applicationNames = new ArrayList<>();
        }
        return applicationNames;
    }

    public void setApplicationNames(List<ApplicationNameDto> applicationNames) {
        this.applicationNames = applicationNames;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 17 * hash + Objects.hashCode(this.applicationNames);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final ApplicationNamesDto other = (ApplicationNamesDto) obj;
        if (!Objects.equals(this.applicationNames, other.applicationNames)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ApplicationNamesDto{" + "applicationNames=" + applicationNames + '}';
    }
}
