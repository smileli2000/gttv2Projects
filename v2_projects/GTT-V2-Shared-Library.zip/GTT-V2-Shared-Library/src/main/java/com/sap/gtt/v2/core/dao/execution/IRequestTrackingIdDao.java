package com.sap.gtt.v2.core.dao.execution;

import com.sap.gtt.v2.core.entity.execution.RequestTrackingId;

import java.util.List;

public interface IRequestTrackingIdDao {
    void insertRequestTrackingIds(List<RequestTrackingId> trackingIds);

    List<RequestTrackingId> queryRequestTrackingIds(String requestId);
}
