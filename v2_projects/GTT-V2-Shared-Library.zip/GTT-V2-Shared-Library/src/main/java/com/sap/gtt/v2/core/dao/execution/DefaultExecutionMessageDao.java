package com.sap.gtt.v2.core.dao.execution;

import com.sap.gtt.v2.core.entity.execution.ExecutionMessage;
import com.sap.gtt.v2.exception.DBException;
import com.sap.gtt.v2.util.DBUtils;
import com.sap.gtt.v2.util.SpringContextUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

/**
 * @author I302310
 */
@Repository(DefaultExecutionMessageDao.BEAN_NAME)
public class DefaultExecutionMessageDao implements IExecutionMessageDao {
    public static final String BEAN_NAME = "com.sap.gtt.v2.core.dao.execution.DefaultExecutionMessageDao";
    public static final String TABLE_NAME = "EXECUTION_MESSAGE";
    public static final int MAX_LENGTH_MESSAGE = 255;

    public static final String SELECT_FROM = "select * from ";
    public static final String WEHRE = " where ";

    public static final String ID = "ID";
    public static final String PHASE_ID = "PHASE_ID";
    public static final String ERROR_AT = "ERROR_AT";
    public static final String MESSAGE_TYPE = "MESSAGE_TYPE";
    public static final String MESSAGE = "MESSAGE";
    public static final String DETAIL = "DETAIL";
    public static final String TAG = "TAG";

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public static DefaultExecutionMessageDao getInstance() {
        return (DefaultExecutionMessageDao) SpringContextUtils.getBean(BEAN_NAME);
    }

    @Override
    public ExecutionMessage queryExecutionMessage(String id) {
        List<String> args = new ArrayList<>();
        args.add(id);
        StringBuilder sql = new StringBuilder();
        sql.append(SELECT_FROM).append(DefaultExecutionMessageDao.TABLE_NAME)
                .append(WEHRE)
                .append(ID).append("=?");
        List<ExecutionMessage> messages = query(sql.toString(), id);
        return messages.isEmpty() ? null : messages.get(0);
    }

    @Override
    public List<ExecutionMessage> queryExecutionMessages(String phaseId) {
        StringBuilder sql = new StringBuilder();
        sql.append(SELECT_FROM).append(DefaultExecutionMessageDao.TABLE_NAME)
                .append(WEHRE)
                .append(PHASE_ID).append("=?");
        return query(sql.toString(), phaseId);
    }

    private List<ExecutionMessage> query(String sql, Object... args) {
        return jdbcTemplate.query(sql, args, (rs, rowNum) -> {
            String rs_id = rs.getString(ID);
            String rs_phaseId = rs.getString(PHASE_ID);
            Instant rs_errorAt = rs.getTimestamp(ERROR_AT).toInstant();
            String rs_messageType = rs.getString(MESSAGE_TYPE);
            String rs_message = rs.getString(MESSAGE);
            String rs_detail = rs.getString(DETAIL);
            String rs_tag = rs.getString(TAG);
            return new ExecutionMessage(rs_id, rs_phaseId, rs_messageType, rs_message, rs_detail, rs_errorAt, rs_tag);
        });
    }

    @Override
    public void insertExecutionMessage(ExecutionMessage executionMessage) {
        StringBuilder sql = new StringBuilder();
        String[] columns = {ID, PHASE_ID, ERROR_AT, MESSAGE_TYPE, MESSAGE, DETAIL, TAG};
        DBUtils.buildInsertSql(TABLE_NAME, columns, sql);
        String message = executionMessage.getMessage();
        if (message != null && message.length() > MAX_LENGTH_MESSAGE) {
            message = message.substring(0, MAX_LENGTH_MESSAGE);
        }
        Object[] args = new Object[]{executionMessage.getId(), executionMessage.getPhaseId(), executionMessage.getErrorAt(),
                executionMessage.getMessageType(), message, executionMessage.getDetail(), executionMessage.getTag()};
        int affectedRows = jdbcTemplate.update(sql.toString(), args);
        if (affectedRows <= 0) {
            throw new DBException("Insert Execution_Message data failed. Affected rows " + affectedRows);
        }
    }

}
