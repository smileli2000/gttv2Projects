package com.sap.gtt.v2.core.entity.execution;

/**
 * @author I302310
 */
public class RequestMapping {
    private String id;
    private String rootRequestId;
    private String requestId;
    private String targetId;
    private String messageType;
    private String message;
    private String messageDetail;

    public RequestMapping(String id, String rootRequestId, String requestId, String targetId, String messageType, String message, String messageDetail) {
        this.id = id;
        this.rootRequestId = rootRequestId;
        this.requestId = requestId;
        this.targetId = targetId;
        this.messageType = messageType;
        this.message = message;
        this.messageDetail = messageDetail;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getRootRequestId() {
        return rootRequestId;
    }

    public void setRootRequestId(String rootRequestId) {
        this.rootRequestId = rootRequestId;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public String getTargetId() {
        return targetId;
    }

    public void setTargetId(String targetId) {
        this.targetId = targetId;
    }

    public String getMessageType() {
        return messageType;
    }

    public void setMessageType(String messageType) {
        this.messageType = messageType;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getMessageDetail() {
        return messageDetail;
    }

    public void setMessageDetail(String messageDetail) {
        this.messageDetail = messageDetail;
    }
}
