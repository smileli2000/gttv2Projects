/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.gtt.v2.core.service.blockingstore;

import com.sap.gtt.v2.core.entity.trackedprocess.Event;
import com.sap.gtt.v2.core.entity.trackedprocess.TrackedProcess;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 *
 * @author I326335
 */
public interface BlockingStoreService {
    public void addTrackedProcess(TrackedProcess trackedProcess);
    public void addEvents(List<Event> events);
    public void addEventRelatedDocuments(UUID eventId, List<UUID> trackedProcessList);
    public void addEventMapRelatedDocuments(Map<UUID, List<UUID>> eventIdMap);
}
