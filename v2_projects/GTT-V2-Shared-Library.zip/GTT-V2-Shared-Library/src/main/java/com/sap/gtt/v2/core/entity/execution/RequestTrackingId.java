package com.sap.gtt.v2.core.entity.execution;

/**
 * @author I302310
 */
public class RequestTrackingId {
    private String id;
    private String requestId;
    private String trackingId;

    public RequestTrackingId() {
    }

    public RequestTrackingId(String id, String requestId, String trackingId) {
        this.id = id;
        this.requestId = requestId;
        this.trackingId = trackingId;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public String getTrackingId() {
        return trackingId;
    }

    public void setTrackingId(String trackingId) {
        this.trackingId = trackingId;
    }
}
