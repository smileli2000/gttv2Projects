/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.gtt.v2.core.domain.blockingstore;

import java.util.Objects;
import lombok.Data;

/**
 *
 * @author I326335
 */
@Data
public class ApplicationNameDto {

    private String applicationName;

}
