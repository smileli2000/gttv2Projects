package com.sap.gtt.v2.tenant;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.http.HttpStatus;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sap.gtt.v2.exception.GeneralNoneTranslatableException;

public class GTTTenantSetting {

	public static final String SETTING_PARAM_LOGGER_LOGLEVEL = "logger.logLevel";
	public static final String SETTING_PARAM_WS_E2A_MAX_TIME = "writeService.eventToAction.maxExecutionTime"; // second
	//public static final String SETTING_PARAM_WS_E2A_MAX_MEMORY = "writeService.eventToAction.maxMemoryConsumption"; // MB
	public static final String SETTING_PARAM_RS_RATELIMIT_MAX_RESULT_COUNT = "readService.rateLimit.maxResultCount"; // COUNT
	public static final String SETTING_PARAM_MM_RATELIMIT_MAX_IMPORT_SIZE = "manageModels.rateLimit.maxImportFileSize"; // MB
	
	public static final String SETTING_PARAM_LOGGER_LOGLEVEL_ERROR = "ERROR";
	public static final String SETTING_PARAM_LOGGER_LOGLEVEL_DEBUG = "DEBUG";
	public static final String SETTING_PARAM_LOGGER_LOGLEVEL_INFO = "INFO";
	
	protected static final Set<String> SETTING_PARAM_NAMES = new HashSet<>();
	
	protected static final Set<String> SETTING_PARAM_LOGGER_LOGLEVEL_VALUES = new HashSet<>();
	
	static{
		SETTING_PARAM_NAMES.add(SETTING_PARAM_LOGGER_LOGLEVEL);
		SETTING_PARAM_NAMES.add(SETTING_PARAM_WS_E2A_MAX_TIME);
		SETTING_PARAM_NAMES.add(SETTING_PARAM_RS_RATELIMIT_MAX_RESULT_COUNT);
		SETTING_PARAM_NAMES.add(SETTING_PARAM_MM_RATELIMIT_MAX_IMPORT_SIZE);
		
		
		SETTING_PARAM_LOGGER_LOGLEVEL_VALUES.add(SETTING_PARAM_LOGGER_LOGLEVEL_ERROR);
		SETTING_PARAM_LOGGER_LOGLEVEL_VALUES.add(SETTING_PARAM_LOGGER_LOGLEVEL_DEBUG);
		SETTING_PARAM_LOGGER_LOGLEVEL_VALUES.add(SETTING_PARAM_LOGGER_LOGLEVEL_INFO);
	}
	
	public static class ParameterNameNotSupportException extends GeneralNoneTranslatableException{ 
		public ParameterNameNotSupportException(String paramName) {
			super(String.format("Parameter name '%s' not support",  paramName), null,HttpStatus.SC_BAD_REQUEST);
		}

		/**
		 * 
		 */
		private static final long serialVersionUID = -1121277585294283688L;
		
		
	}
	
	public static class ParameterValueEmptyException extends GeneralNoneTranslatableException{ 
		/**
		 * 
		 */
		private static final long serialVersionUID = -5362345253272199079L;

		public ParameterValueEmptyException(String paramName) {
			super(String.format("Value of parameter name '%s' cannot be empty",  paramName), null,HttpStatus.SC_BAD_REQUEST);
		}
		
		
	}
	
	public static class ParameterValueNotSupportException extends GeneralNoneTranslatableException{ 
		
		/**
		 * 
		 */
		private static final long serialVersionUID = -3706846876173529586L;

		public ParameterValueNotSupportException(String paramName, String paramValue) {
			super(String.format("Value '%s' of parameter name '%s' not support", paramValue, paramName), null,HttpStatus.SC_BAD_REQUEST);
		}
		
		
	}
	
	private String instanceMappingId;
	
	private Map<String, String> parameters = new HashMap<>();
	

	public String getInstanceMappingId() {
		return instanceMappingId;
	}

	public void setInstanceMappingId(String instanceMappingId) {
		this.instanceMappingId = instanceMappingId;
	}

	public Map<String, String> getParameters() {
		return parameters;
	}

	public void setParameters(Map<String, String> parameters) {
		this.parameters = parameters;
	}
	
	@JsonIgnore
	public String getLogLevel() {
		return this.getParameters().getOrDefault(SETTING_PARAM_LOGGER_LOGLEVEL, SETTING_PARAM_LOGGER_LOGLEVEL_INFO);
	}
	@JsonIgnore
	public void setLogLevel(String logLevel) {
		this.getParameters().put(SETTING_PARAM_LOGGER_LOGLEVEL, logLevel);
	}
	
	@JsonIgnore
	public int getEventToActionMaxTime() {
		return Integer.parseInt(this.getParameters().getOrDefault(SETTING_PARAM_WS_E2A_MAX_TIME,"30"));
	}
	@JsonIgnore
	public void setEventToActionMaxTime(int timeout) {
		this.getParameters().put(SETTING_PARAM_WS_E2A_MAX_TIME, String.valueOf(timeout));
	}
	
	@JsonIgnore
	public int getReadServiceRateLimitMaxResultCount() {
		return Integer.parseInt(this.getParameters().getOrDefault(SETTING_PARAM_RS_RATELIMIT_MAX_RESULT_COUNT,"128"));
	}
	@JsonIgnore
	public void setReadServiceRateLimitMaxResultCount(int count) {
		this.getParameters().put(SETTING_PARAM_RS_RATELIMIT_MAX_RESULT_COUNT, String.valueOf(count));
	}
	
	@JsonIgnore
	public int getMMRateLimitMaxImportSize() {
		return Integer.parseInt(this.getParameters().getOrDefault(SETTING_PARAM_MM_RATELIMIT_MAX_IMPORT_SIZE,"2"));
	}
	@JsonIgnore
	public void setMMRateLimitMaxImportSize(int size) {
		this.getParameters().put(SETTING_PARAM_MM_RATELIMIT_MAX_IMPORT_SIZE, String.valueOf(size));
	}
	
	public void validate(){
		for(Entry<String, String> entry : this.getParameters().entrySet()){
			String paramName = entry.getKey();
			String paramValue = entry.getValue();
			
			if(!SETTING_PARAM_NAMES.contains(paramName)){
				throw new ParameterNameNotSupportException(paramName);
			}
			
			if(StringUtils.isBlank(paramValue)){
				throw new ParameterValueEmptyException(paramName);
			}
			
			if(
					(StringUtils.equals(paramName, SETTING_PARAM_LOGGER_LOGLEVEL)
					&& !SETTING_PARAM_LOGGER_LOGLEVEL_VALUES.contains(paramValue))
					||
					(StringUtils.equals(paramName, SETTING_PARAM_WS_E2A_MAX_TIME)
							&&
							!NumberUtils.isParsable(paramValue)
					)
			  )
			
			{
				throw new ParameterValueNotSupportException(paramName,paramValue);
			}
			
		}
	}
}
