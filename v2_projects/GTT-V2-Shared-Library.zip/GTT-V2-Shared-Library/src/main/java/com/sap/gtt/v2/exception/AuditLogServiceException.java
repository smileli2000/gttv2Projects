package com.sap.gtt.v2.exception;

/**
 * @author I321712
 */
public class AuditLogServiceException extends InternalErrorException {

    public AuditLogServiceException(Throwable cause) {
        super(cause);
    }

    public AuditLogServiceException(String message) {
        super(message);
    }

    public AuditLogServiceException(String message, Throwable cause) {
        super(message, cause);
    }
}
