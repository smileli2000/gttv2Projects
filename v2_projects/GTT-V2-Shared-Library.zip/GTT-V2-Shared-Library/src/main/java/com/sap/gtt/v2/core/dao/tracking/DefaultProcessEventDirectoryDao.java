package com.sap.gtt.v2.core.dao.tracking;

import com.sap.gtt.v2.core.domain.metadata.CurrentMetadataEntity;
import com.sap.gtt.v2.core.domain.metadata.MetadataConstants;
import com.sap.gtt.v2.core.entity.trackedprocess.ProcessEventDirectory;
import com.sap.gtt.v2.log.TenantAwareLogService;
import com.sap.gtt.v2.util.DBUtils;
import com.sap.gtt.v2.util.SpringContextUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

import static com.sap.gtt.v2.core.entity.trackedprocess.ProcessEventDirectory.PLANNED_EVENT_ID;
import static com.sap.gtt.v2.core.entity.trackedprocess.ProcessEventDirectory.PROCESS_ID;


@Repository(DefaultProcessEventDirectoryDao.BEAN_NAME)
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class DefaultProcessEventDirectoryDao implements IProcessEventDirectoryDao{
	public static final String BEAN_NAME = "com.sap.gtt.v2.core.dao.tracking.DefaultProcessEventDirectoryDao";

	protected DefaultProcessEventDirectoryDao(){
		
	}
	
	public static DefaultProcessEventDirectoryDao getInstance(){
		return (DefaultProcessEventDirectoryDao)SpringContextUtils.getBean(BEAN_NAME);
	}

	@Autowired
	private DaoHelper daoHelper;

	@Autowired
	private TenantAwareLogService logService;

	@Override
	public void insert(ProcessEventDirectory processEventDirectory) {
		daoHelper.insert(processEventDirectory);
	}

	@Override
	public void insert(List<ProcessEventDirectory> pedList) {
		for(ProcessEventDirectory ped : pedList) {
			insert(ped);
		}
	}

	@Override
	public void delete(CurrentMetadataEntity metadata, UUID id) {
		daoHelper.delete(metadata, id);
	}

	@Override
	public void deleteByProcessId(UUID processId) {
		String  sql = new StringBuilder("delete from ")
				.append(DBUtils.toTableName(
						MetadataConstants.CoreModelEntity.PROCESS_EVENT_DIRECTORY.getFullName()))
				.append(" where ").append(PROCESS_ID)
				.append(" = ?").toString();
		logService.debug("sql:{}, values:{}", sql, processId);
		daoHelper.getJdbcTemplate().update(sql, processId);
	}

	@Override
	public void update(ProcessEventDirectory processEventDirectory) {
		daoHelper.update(processEventDirectory);
	}

	@Override
	public ProcessEventDirectory findOne(CurrentMetadataEntity metadata, UUID id) {
		return daoHelper.findOneByPrimaryKey(ProcessEventDirectory.class, metadata, id);
	}

	@Override
	public void deleteByPlannedEventId(UUID plannedEventId) {
		String  sql = new StringBuilder("delete from ")
				.append(DBUtils.toTableName(
						MetadataConstants.CoreModelEntity.PROCESS_EVENT_DIRECTORY.getFullName()))
				.append(" where ").append(PLANNED_EVENT_ID)
				.append(" = ?").toString();
		logService.debug("sql:{}, values:{}", sql, plannedEventId);
		daoHelper.getJdbcTemplate().update(sql, plannedEventId);
	}
}
