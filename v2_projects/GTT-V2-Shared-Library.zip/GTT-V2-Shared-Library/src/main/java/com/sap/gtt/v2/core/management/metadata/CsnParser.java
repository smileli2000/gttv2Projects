package com.sap.gtt.v2.core.management.metadata;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import com.sap.gtt.v2.core.domain.metadata.*;
import com.sap.gtt.v2.core.domain.metadata.MetadataConstants.*;
import com.sap.gtt.v2.exception.JsonParseException;
import com.sap.gtt.v2.exception.MetadataException;
import com.sap.gtt.v2.util.EnumUtils;
import com.sap.gtt.v2.util.GTTUtils;
import com.sap.gtt.v2.util.JsonUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.ReflectionUtils;

import java.lang.reflect.Field;
import java.time.Duration;
import java.time.format.DateTimeParseException;
import java.util.*;
import java.util.stream.Collectors;

import static com.sap.gtt.v2.core.domain.metadata.MetadataConstants.*;
import static com.sap.gtt.v2.core.domain.metadata.MetadataConstants.CdsDataType.CDS_ASSOCIATION;
import static com.sap.gtt.v2.core.domain.metadata.MetadataConstants.CdsDataType.CDS_COMPOSITION;
import static com.sap.gtt.v2.core.domain.metadata.MetadataConstants.CoreModelEntity.*;
import static com.sap.gtt.v2.exception.JsonParseException.MESSAGE_CODE_ERROR_DURATION_PARSE;
import static com.sap.gtt.v2.exception.MetadataException.*;
import static java.util.Arrays.asList;
import static java.util.Arrays.stream;

/**
 * Utility to parse CSN related data
 *
 * @author I321712
 */
public class CsnParser {

    private static Logger logger = LoggerFactory.getLogger(CsnParser.class);

    private static final String SELF = "$self";

    private static final List<String> CORE_TYPES = asList(EVENT.getFullName(),
            TRACKED_PROCESS.getFullName(),
            GTT_DELAYED_EVENT.getFullName(),
            GTT_ONTIME_EVENT.getFullName());

    private static final List<String> REQUIRED_ENTITY_PROPERTIES = asList(ENTITY_BASE_TYPE,
            ENTITY_IS_PROCESS_EVENT, ENTITY_APPLICATION_OBJECT_TYPE, ENTITY_TRACKING_ID_TYPE,
            ENTITY_ADMISSIBLE_UNPLANNED_EVENTS, ENTITY_PLANNED_EVENTS, ENTITY_AUTHORIZATION,
            ENTITY_EXTENDED_PLAN_NAME);

    private static final List<String> REQUIRED_ELEMENT_PROPERTIES = asList(ELEMENT_KEY, ELEMENT_TYPE,
            ELEMENT_LENGTH, ELEMENT_DEFAULT, ELEMENT_ENUM, ELEMENT_TARGET, ELEMENT_CARDINALITY,
            ELEMENT_KEYS, ELEMENT_FROM_CORE_MODEL, ELEMENT_PRECISION,
            ELEMENT_SCALE, ELEMENT_SOURCE_ALT_KEY, ELEMENT_BACK_LINK, ELEMENT_ON, ELEMENT_FOREIGN_KEY_FLD
            , ELEMENT_DPP_PII
            , ELEMENT_DPP_SPI
            , ELEMENT_DPP_DATA_SUBJECTID
            , FIELD_CONTENT_INTEGER_MAXIMUM
            , FIELD_CONTENT_INTEGER_MINIMUM
            , FIELD_CONTENT_INTEGER_EXCLUSIVE_MINIMUM
            , FIELD_CONTENT_INTEGER_EXCLUSIVE_MAXIMUM
            , FIELD_CONTENT_INTEGER_MULTIPLE_OF
            , FIELD_CONTENT_DECIMAL_MAXIMUM
            , FIELD_CONTENT_DECIMAL_MINIMUM
            , FIELD_CONTENT_DECIMAL_EXCLUSIVE_MINIMUM
            , FIELD_CONTENT_DECIMAL_EXCLUSIVE_MAXIMUM
            , FIELD_CONTENT_DECIMAL_MULTIPLE_OF
            , FIELD_CONTENT_STRING_MIN_LENGTH
            , FIELD_CONTENT_STRING_PATTERN
            , FIELD_CONTENT_ARRAY_MIN_ITEMS
            , FIELD_CONTENT_ARRAY_MAX_ITEMS
            , ELEMENT_REPLACE_ACTUAL_EVENT_FIELDS
    );

    private static final Map<String, Field> ENTITY_ELEMENT_FIELD_MAP = new HashMap<>();
    private static final Map<String, Field> ENTITY_FIELD_MAP = new HashMap<>();
    private static final Map<String, Field> ENTITY_ELEMENT_FIELD_CONTENT_MAP = new HashMap<>();

    static {
        Field[] declaredFields = MetadataEntity.class.getDeclaredFields();
        for (Field f : declaredFields) {
            ENTITY_FIELD_MAP.put(f.getName(), f);
        }
        declaredFields = MetadataEntityElement.class.getDeclaredFields();
        for (Field f : declaredFields) {
            ENTITY_ELEMENT_FIELD_MAP.put(f.getName(), f);
        }
        declaredFields = FieldContent.class.getDeclaredFields();
        for (Field f : declaredFields) {
            ENTITY_ELEMENT_FIELD_CONTENT_MAP.put(f.getName(), f);
        }
    }

    /**
     * Utility classes should not have public constructors
     */
    private CsnParser() {
        throw new IllegalStateException();
    }

    /**
     * Set the property value for a particular metadata entity or entity element object.
     *
     * @param instObj      instance object
     * @param fieldName    field name
     * @param propertyName CSN property name
     * @param valueMap     value map
     */
    private static void setPropertyVal(Object instObj, String fieldName, String propertyName, JsonObject valueMap) {
        Field field = null;
        try {
            String clazzName = instObj.getClass().getSimpleName();
            if (MetadataEntityElement.class.getSimpleName().equalsIgnoreCase(clazzName)) {
                field = ENTITY_ELEMENT_FIELD_MAP.get(fieldName);
            } else if (MetadataEntity.class.getSimpleName().equalsIgnoreCase(clazzName)) {
                field = ENTITY_FIELD_MAP.get(fieldName);
            } else if (FieldContent.class.getSimpleName().equalsIgnoreCase(clazzName)) {
                field = ENTITY_ELEMENT_FIELD_CONTENT_MAP.get(fieldName);
            }
            if (field == null) {
                return;
            }
            setFieldValue(instObj, propertyName, valueMap, field);
        } catch (IllegalAccessException e) {
            logger.warn(e.getMessage(), e);
        }
    }

    private static void setFieldValue(Object instObj, String propertyName, JsonObject valueMap, Field field) throws IllegalAccessException {

        ReflectionUtils.makeAccessible(field);

        String type = field.getType().getSimpleName();
        JsonElement valElement = valueMap.get(propertyName);
        if (valElement == null) {
            return;
        }
        switch (type) {
            case "CdsDataType":
                field.set(instObj, EnumUtils.getEnumTypeByValue(CdsDataType.class, valElement.getAsString()));
                break;
            case "String":
                if (valElement.isJsonPrimitive()) {
                    field.set(instObj, valElement.getAsString());
                } else {
                    field.set(instObj, valElement.toString());
                }
                break;
            case "int":
            case "Integer":
                field.set(instObj, valElement.getAsInt());
                break;
            case "boolean":
            case "Boolean":
                field.set(instObj, valElement.getAsBoolean());
                break;
            case "Duration":
                Duration ret = Duration.ZERO;
                if (StringUtils.isNotBlank(valElement.getAsString())) {
                    try {
                        ret = Duration.parse(valElement.getAsString());
                    } catch (DateTimeParseException e) {
                        throw new JsonParseException(e, MESSAGE_CODE_ERROR_DURATION_PARSE,
                                new Object[]{valElement.getAsString(), propertyName});
                    }
                }
                field.set(instObj, ret);
                break;
            default:
        }
    }

    /**
     * Parse the derived CSN string to MetadataEntity map
     *
     * @param derivedCsn derived CSN string
     * @return metadata entity map
     */
    public static Map<String, MetadataEntity> parseToEntityMap(String derivedCsn) {
        List<MetadataEntity> entities = new ArrayList<>();
        JsonElement jsonElement = JsonUtils.generateJsonElementFromString(derivedCsn);
        parseToEntities(jsonElement, entities);
        return entities.stream().collect(Collectors.toMap(MetadataEntity::getName, v -> v));
    }

    /**
     * Parse the derived CSN string to MetadataEntity list
     *
     * @param derivedCsn derived CSN string
     * @return metadata entity list
     */
    public static List<MetadataEntity> parseToEntities(String derivedCsn) {
        List<MetadataEntity> entities = new ArrayList<>();
        JsonElement jsonElement = JsonUtils.generateJsonElementFromString(derivedCsn);
        parseToEntities(jsonElement, entities);
        return entities;
    }
    
    /**
     * Get all tracked process and event entities from MetadataEntity list
     *
     * @param metadataEntites MetadataEntity list from derived csn
     * @param excludeCoreModelEvent
     * @return tracked process and event entity list
     */
    public static List<MetadataEntity> getAllTrackedProcessAndEventEntities(List<MetadataEntity> metadataEntites, boolean excludeCoreModelEvent) {
        return metadataEntites.stream().filter(e -> {
            boolean ret = isEvent(e.getBaseType()) || isTrackedProcess(e.getBaseType());
            if (excludeCoreModelEvent) {
                ret = ret && !CsnParser.isCoreModelEntity(e.getName());
            }
            return ret;

        }).collect(Collectors.toList());
    }

    /**
     * Check if entity is tracked process
     * @param baseType
     * @return 
     */
    public static boolean isTrackedProcess(String baseType) {
        return EntityBaseType.TRACKED_PROCESS.getValue().equalsIgnoreCase(baseType);
    }

    /**
     * Check if entity is event
     * @param baseType
     * @return 
     */
    public static boolean isEvent(String baseType) {
        return EntityBaseType.EVENT.getValue().equalsIgnoreCase(baseType);
    }
    
    /**
     * Parse the derived CSN Json element to MetadataEntity list
     *
     * @param derivedCsnJson    derived CSN Json element
     * @param resultEntities    to record all the metadata entities
     * @param targetEntityNames full or abbr. entity name
     *                          such as com.sap.gtt.app.mim.poitem.POItemModel.ConfirmedEvent or ConfirmedEvent
     */
    private static void parseToEntities(JsonElement derivedCsnJson, List<MetadataEntity> resultEntities, String... targetEntityNames) {
        final JsonObject derivedCsnObject = derivedCsnJson.getAsJsonObject();
        JsonObject baseTypeEventElements = derivedCsnObject.get(CoreModelEntity.EVENT.getFullName()).getAsJsonObject().get(ELEMENTS).getAsJsonObject();
        JsonObject baseTypeTrackedProcessElements = derivedCsnObject.get(CoreModelEntity.TRACKED_PROCESS.getFullName()).getAsJsonObject().get(ELEMENTS).getAsJsonObject();
        Map<String, String> basePlanExtendedFields = getBasePlanExtendedFields(derivedCsnObject.get(BASE_PLAN.getFullName()));
        derivedCsnObject.entrySet().forEach(entry -> {
            String key = entry.getKey();
            if (targetEntityNames != null && targetEntityNames.length > 0
                    && !isConditionName(key, asList(targetEntityNames))) {
                return;
            }
            JsonElement value = entry.getValue();
            if (value.isJsonObject()) {
                Boolean coreModel = isCoreModelEntity(key);
                JsonObject valueObj = value.getAsJsonObject();
                MetadataEntity entity = new MetadataEntity();
                entity.setName(key);
                setPropertyVal(entity, ENTITY_FIELD_BASE_TYPE, ENTITY_BASE_TYPE, valueObj);
                setPropertyVal(entity, ENTITY_FIELD_IS_PROCESS_EVENT, ENTITY_IS_PROCESS_EVENT, valueObj);
                setPropertyVal(entity, ENTITY_FIELD_APPLICATION_OBJECT_TYPE,
                        ENTITY_APPLICATION_OBJECT_TYPE, valueObj);
                setPropertyVal(entity, ENTITY_FIELD_TRACKING_ID_TYPE,
                        ENTITY_TRACKING_ID_TYPE, valueObj);
                setPropertyVal(entity, ENTITY_FIELD_INHERIT_FROM_CORE_TYPE,
                        ENTITY_INHERIT_FROM_CORE_TYPE, valueObj);
                setPropertyVal(entity, ENTITY_FIELD_ADMISSIBLE_UNPLANNED_EVENTS, ENTITY_ADMISSIBLE_UNPLANNED_EVENTS, valueObj);
                setPropertyVal(entity, ENTITY_FIELD_PLANNED_EVENTS, ENTITY_PLANNED_EVENTS, valueObj);
                setPropertyVal(entity, ENTITY_FIELD_AUTHORIZATION, ENTITY_AUTHORIZATION, valueObj);
                setPropertyVal(entity, ENTITY_FIELD_EXTENDED_PLAN_NAME, ENTITY_EXTENDED_PLAN_NAME, valueObj);
                JsonElement elements = valueObj.get(ELEMENTS);
                handleCoreBaseType(baseTypeEventElements, baseTypeTrackedProcessElements, basePlanExtendedFields, coreModel, valueObj, entity, elements);
                entity.setIncludeCustomizedFields(false);
                //if entity has one or more customized field, then @@includeCustomizedFields" is true
                Optional<MetadataEntityElement> elementOptional = entity.getElements().stream().filter(e ->
                        e.isCustomizedField() && !CdsDataType.CDS_COMPOSITION.equals(e.getType())).findFirst();
                if (elementOptional.isPresent()) {
                    entity.setIncludeCustomizedFields(true);
                }
                entity.initListProperties();
                resultEntities.add(entity);
            }
        });
    }

    private static void handleCoreBaseType(JsonObject baseTypeEventElements, JsonObject baseTypeTrackedProcessElements,
                                           Map<String, String> basePlanExtendedFields,
                                           Boolean coreModel, JsonObject valueObj, MetadataEntity entity, JsonElement elements) {
        String[] baseType = {""};
        if (valueObj.has(ENTITY_BASE_TYPE)) {
            baseType[0] = valueObj.get(ENTITY_BASE_TYPE).getAsString();
        }
        boolean isPlannedObj = isPlannedObject(entity.getName());
        elements.getAsJsonObject().entrySet().forEach(eleJson -> {
            JsonObject baseTypeElements = null;
            if (CoreModelEntity.EVENT.getValue().equals(baseType[0])) {
                //"@com.sap.gtt.core.CoreModel.BaseType": "Event"
                baseTypeElements = baseTypeEventElements;
            } else if (CoreModelEntity.TRACKED_PROCESS.getValue().equals(baseType[0])) {
                //"@com.sap.gtt.core.CoreModel.BaseType": "TrackedProcess"
                baseTypeElements = baseTypeTrackedProcessElements;
            }
            MetadataEntityElement entityElement = generateMetadataEntityElement(eleJson, baseTypeElements, basePlanExtendedFields, isPlannedObj, coreModel);
            entity.addElement(entityElement);
        });
    }

    private static MetadataEntityElement generateMetadataEntityElement(Map.Entry<String, JsonElement> eleJson, JsonObject baseTypeElements,
                                                                       Map<String, String> basePlanExtendedFields,
                                                                       boolean isPlannedObj, boolean coreModel) {
        String eleKey = eleJson.getKey();
        MetadataEntityElement entityElement = new MetadataEntityElement();
        entityElement.setName(eleKey);
        JsonElement eleValJson = eleJson.getValue();
        if (eleValJson.isJsonObject()) {
            JsonObject eleValJsonObj = eleValJson.getAsJsonObject();
            setPropertyVal(entityElement, ELEMENT_KEY, ELEMENT_KEY, eleValJsonObj);
            setPropertyVal(entityElement, ELEMENT_TYPE, ELEMENT_TYPE, eleValJsonObj);
            setPropertyVal(entityElement, ELEMENT_LENGTH, ELEMENT_LENGTH, eleValJsonObj);
            setPropertyVal(entityElement, ELEMENT_FIELD_DEFAULT, ELEMENT_DEFAULT, eleValJsonObj);
            setPropertyVal(entityElement, ELEMENT_FIELD_ENUM, ELEMENT_ENUM, eleValJsonObj);
            setPropertyVal(entityElement, ELEMENT_TARGET, ELEMENT_TARGET, eleValJsonObj);
            setPropertyVal(entityElement, ELEMENT_CARDINALITY, ELEMENT_CARDINALITY, eleValJsonObj);
            setPropertyVal(entityElement, ELEMENT_KEYS, ELEMENT_KEYS, eleValJsonObj);
            setPropertyVal(entityElement, ELEMENT_FIELD_FROM_CORE_MODEL, ELEMENT_FROM_CORE_MODEL, eleValJsonObj);
            setPropertyVal(entityElement, ELEMENT_PRECISION, ELEMENT_PRECISION, eleValJsonObj);
            setPropertyVal(entityElement, ELEMENT_SCALE, ELEMENT_SCALE, eleValJsonObj);
            setPropertyVal(entityElement, ELEMENT_FIELD_SOURCE_ALT_KEY, ELEMENT_SOURCE_ALT_KEY, eleValJsonObj);
            setPropertyVal(entityElement, ELEMENT_FIELD_BACK_LINK, ELEMENT_BACK_LINK, eleValJsonObj);
            setPropertyVal(entityElement, ELEMENT_ON, ELEMENT_ON, eleValJsonObj);
            setPropertyVal(entityElement, ELEMENT_FIELD_FOREIGN_KEY_FLD, ELEMENT_FOREIGN_KEY_FLD, eleValJsonObj);
            setPropertyVal(entityElement, ELEMENT_FIELD_DPP_DATA_SUBJECTID, ELEMENT_DPP_DATA_SUBJECTID, eleValJsonObj);
            setPropertyVal(entityElement, ELEMENT_FIELD_DPP_PII, ELEMENT_DPP_PII, eleValJsonObj);
            setPropertyVal(entityElement, ELEMENT_FIELD_DPP_SPI, ELEMENT_DPP_SPI, eleValJsonObj);
            setPropertyVal(entityElement, ELEMENT_FIELD_REPLACE_ACTUAL_EVENT_FIELDS_STR, ELEMENT_REPLACE_ACTUAL_EVENT_FIELDS, eleValJsonObj);
            boolean customizedField = isCustomizedField(baseTypeElements, basePlanExtendedFields, isPlannedObj, coreModel, eleKey);
            entityElement.setCustomizedField(customizedField);

            List<String> fieldConentKeys = getFieldConentKeys(eleValJsonObj);
            if (!fieldConentKeys.isEmpty()) {
                FieldContent fieldContent = entityElement.getFieldContent();
                if (fieldContent == null) {
                    fieldContent = new FieldContent();
                    entityElement.setFieldContent(fieldContent);
                }
                for (String fcKey : fieldConentKeys) {
                    setPropertyVal(fieldContent, GTTUtils.toLowerCaseFirstCharacter(getAbbrName(fcKey)), fcKey, eleValJsonObj);
                }
            }
        }
        entityElement.initListProperties();
        return entityElement;
    }

    /**
     * find customizedField which are not from "Event" OR "TrackedProcess", then use these fields to create table
     * 1)	For core model entity, if no base type:
     * "@@includeCustomizedFields": false
     * “customizedField” in elements: false
     * <p>
     * 2)	For user model entity, if no base type:
     * "@@includeCustomizedFields": true
     * “customizedField” in elements: true
     * <p>
     * 3)	For all the other entities,  if base type is “Event” or “TrackedProcess”,
     * then compare entities’ elements with elements of  “Event” or “TrackedProcess”
     * to generate “customizedField” and "@@includeCustomizedFields"
     *
     * @param baseTypeElements base type element
     * @param coreModel        core model flag
     * @param eleKey           element key
     * @return
     */
    private static boolean isCustomizedField(JsonObject baseTypeElements, Map<String, String> basePlanExtendedFields,
                                             boolean isPlannedObj, boolean coreModel, String eleKey) {
        boolean ret = true;
        if ((baseTypeElements == null && coreModel)
                || (baseTypeElements != null && baseTypeElements.has(eleKey))) {
            ret = false;
        }
        if (baseTypeElements == null && coreModel && basePlanExtendedFields.get(eleKey) != null && isPlannedObj) {
            ret = true;
        }
        return ret;
    }

    private static List<String> getFieldConentKeys(JsonObject valueMap) {
        return valueMap.keySet().stream().filter(k -> k.startsWith(FIELD_CONTENT_PREFIX)).collect(Collectors.toList());
    }

    /**
     * Find specific entities by a given target entity full or abbr. name
     *
     * @param derivedCsn       derived csn
     * @param targetEntityName target entity name
     * @return all the entities of the given name
     */
    static List<MetadataEntity> findEntities(String derivedCsn, String targetEntityName) {
        List<MetadataEntity> entities = new ArrayList<>();
        JsonElement jsonElement = JsonUtils.generateJsonElementFromString(derivedCsn);
        String abbrName = getEntityAbbrName(targetEntityName);
        parseToEntities(jsonElement, entities, targetEntityName, abbrName);
        return entities;
    }

    /**
     * Derive to a simple CSN with necessary properties.
     *
     * @param originalCsnStr                   original CSN string
     * @param modelConfiguration model level configuration
     * @return a derived CSN with necessary properties
     */
    public static String deriveCsn(String originalCsnStr, ModelConfiguration modelConfiguration) {
        JsonElement jsonElement = JsonUtils.generateJsonElementFromString(originalCsnStr);
        return deriveCsn(jsonElement, modelConfiguration);
    }

    /**
     * Derive to a simple CSN with necessary properties
     *
     * @param originalCSN original CSN JsonElement
     * @param modelConfiguration model level configuration
     * @return a derived CSN with necessary properties
     */
    private static String deriveCsn(JsonElement originalCSN, ModelConfiguration modelConfiguration) {
        JsonObject retJsonObject = new JsonObject();
        Map<String, JsonElement> entityMap = new HashMap<>(INITIAL_CAPACITY);
        Set<String> tableEntities = new HashSet<>();

        JsonElement rootElement = originalCSN.getAsJsonObject().get(DEFINITIONS);
        Map<String, List<String>> backLinkFieldsMap = new HashMap<>(INITIAL_CAPACITY);
        rootElement.getAsJsonObject().entrySet()
                .forEach(entry -> handleMainEntity(entityMap, tableEntities, backLinkFieldsMap,
                        entry.getKey(), entry.getValue(), false));
        correctBackLinkFields(entityMap, backLinkFieldsMap);
        if (!tableEntities.isEmpty()) {
            Map<String, JsonElement> coreEntityMap = new HashMap<>(INITIAL_CAPACITY);
            for (CoreModelEntity s : CoreModelEntity.values()) {
                coreEntityMap.put(s.getFullName(), entityMap.get(s.getFullName()));
            }
            for (String entity : tableEntities) {
                JsonElement entityElement = entityMap.get(entity);
                if (entityElement != null) {
                    List<String> backLinkFields = backLinkFieldsMap.get(entity);
                    retJsonObject.add(entity, generateDesiredEntity(entity, entityMap.get(entity), coreEntityMap, backLinkFields, entityMap));
                }
            }
        }
        String readService = fetchReadService(rootElement);
        if (StringUtils.isNotBlank(readService)) {
            retJsonObject.addProperty(EntityKind.SERVICE.getValue(), readService);
        }
        String namespace = cutStringFromLastDot(readService);
        handlePlannedEventExtension(retJsonObject, rootElement, namespace);
        retJsonObject.addProperty(ENABLE_INSTANCE_BASED_AUTHORIZATION, modelConfiguration.isEnableInstanceBasedAuthorization());
        retJsonObject.addProperty(EVENT_CORRELATION_LEVEL, modelConfiguration.getEventCorrelationLevel());
        return retJsonObject.toString();
    }

    private static void correctBackLinkFields(Map<String, JsonElement> entityMap, Map<String, List<String>> backLinkFieldsMap) {
        backLinkFieldsMap.forEach((k, v) -> {
            JsonElement element = entityMap.get(k);
            if (JsonUtils.isNull(element)) {
                return;
            }
            JsonObject entity = element.getAsJsonObject();
            JsonObject elementsObj = entity.get(ELEMENTS).getAsJsonObject();
            int size = v.size();
            for (int i = 0; i < size; i++) {
                String ky = v.get(i);
                JsonElement kyElement = elementsObj.get(ky);
                if (JsonUtils.isNull(kyElement)) {
                    continue;
                }
                JsonObject eleObj = kyElement.getAsJsonObject();
                String type = eleObj.get(ELEMENT_TYPE).getAsString();
                if (CDS_ASSOCIATION.getValue().equalsIgnoreCase(type)) {
                    String generatedFieldName = getGeneratedFieldName(eleObj);
                    if (!v.contains(generatedFieldName)) {
                        v.add(generatedFieldName);
                    }
                }
            }
        });
    }

    /**
     * Fetch read service namespace from CSN
     *
     * @param rootElement root definitions
     * @return read service namespace which its kind is service
     */
    private static String fetchReadService(JsonElement rootElement) {
        for (Map.Entry<String, JsonElement> entry : rootElement.getAsJsonObject().entrySet()) {
            String key = entry.getKey();
            JsonElement eValue = entry.getValue();
            if (!JsonUtils.isNull(eValue)) {
                String kind = eValue.getAsJsonObject().get(ENTITY_KIND).getAsString();
                if (EntityKind.SERVICE.getValue().equalsIgnoreCase(kind)) {
                    return key;
                }
            }
        }
        return null;
    }

    private static void handlePlannedEventExtension(JsonObject retJsonObject, JsonElement rootElement, String namespace) {
        String basePlanFullName = BASE_PLAN.getFullName();
        JsonElement basePlanElement = rootElement.getAsJsonObject().get(basePlanFullName);
        if (JsonUtils.isNull(basePlanElement)) {
            return;
        }
        Map<String, String> extendedFields = getBasePlanExtendedFields(basePlanElement);
        if (extendedFields.size() > 0) {
            List<String> extendedFieldsList = extendedFields.keySet().stream().collect(Collectors.toList());
            addExtensionEntity(retJsonObject, namespace, PLANNED_EVENT, extendedFieldsList);
            addExtensionEntity(retJsonObject, namespace, PLANNED_EVENT_FOR_EVENT, extendedFieldsList);
            addExtensionEntity(retJsonObject, namespace, PLANNED_EVENT_FOR_UPDATE_PLAN_EVENT, extendedFieldsList);
        }
    }

    private static Map<String, String> getBasePlanExtendedFields(JsonElement basePlanEntity) {
        Map<String, String> extendedFields = new HashMap<>();
        if (JsonUtils.isNull(basePlanEntity)) {
            return extendedFields;
        }
        JsonObject basePlanObject = basePlanEntity.getAsJsonObject();
        JsonObject basePlanElementsObj = basePlanObject.get(ELEMENTS).getAsJsonObject();
        Set<String> keySet = basePlanElementsObj.keySet();
        keySet.forEach(k -> {
            BasePlanField planField = EnumUtils.getEnumTypeByValue(BasePlanField.class, k);
            if (planField == null) {
                extendedFields.put(k, k);
            }
        });
        return extendedFields;
    }

    private static boolean isPlannedObject(String entityFullName) {
        return PLANNED_EVENT.getFullName().equalsIgnoreCase(entityFullName)
                || PLANNED_EVENT_FOR_EVENT.getFullName().equalsIgnoreCase(entityFullName)
                || PLANNED_EVENT_FOR_UPDATE_PLAN_EVENT.getFullName().equalsIgnoreCase(entityFullName)
                ;
    }

    private static void addExtensionEntity(JsonObject retJsonObject, String namespace,
                                           CoreModelEntity coreModelEntity,
                                           List<String> extendedFields) {
        JsonElement plannedEventElement = retJsonObject.get(coreModelEntity.getFullName());
        JsonObject asJsonObject = plannedEventElement.getAsJsonObject();
        asJsonObject.addProperty(ENTITY_INCLUDE_CUSTOMIZED_FIELDS, Boolean.TRUE);
        JsonObject plannedElementsObj = asJsonObject.get(ELEMENTS).getAsJsonObject();
        JsonObject extendObj = new JsonObject();
        extendObj.addProperty(ENTITY_INCLUDE_CUSTOMIZED_FIELDS, Boolean.TRUE);
        JsonObject elementsObj = new JsonObject();
        plannedElementsObj.keySet().forEach(k -> {
            JsonObject eleObj = plannedElementsObj.get(k).getAsJsonObject();
            if (extendedFields.contains(k) || eleObj.has(ELEMENT_KEY) && eleObj.get(ELEMENT_KEY).getAsBoolean()) {
                elementsObj.add(k, eleObj);
            }
        });
        extendObj.add(ELEMENTS, elementsObj);
        String customModelEntity = getCustomModelEntity(namespace, getExtensionEntityName(coreModelEntity));
        extendObj.addProperty(ENTITY_INHERIT_FROM_CORE_TYPE, coreModelEntity.getFullName());
        asJsonObject.addProperty(ENTITY_EXTENDED_PLAN_NAME, customModelEntity);
        retJsonObject.add(customModelEntity, extendObj);
    }

    public static String getCustomModelEntity(String namespace, String abbrEntityName) {
        return namespace + DOT + abbrEntityName;
    }

    public static String getExtensionEntityName(CoreModelEntity coreModelEntity) {
        return coreModelEntity.getValue() + "_extension";
    }

    private static void handleMainEntity(Map<String, JsonElement> entityMap, Set<String> tableEntities,
                                         Map<String, List<String>> backLinkFieldsMap,
                                         String entryKey, JsonElement entryValue, boolean isSubEntity) {
        String key = entryKey;
        JsonElement value = entryValue;
        if (JsonUtils.isNull(value) || !value.isJsonObject()) {
            return;
        }
        JsonObject valueObj = value.getAsJsonObject();
        String kind = valueObj.get(ENTITY_KIND).getAsString();
        if (!EntityKind.ENTITY.getValue().equalsIgnoreCase(kind)) {
            return;
        }
        JsonElement elements = valueObj.get(ELEMENTS);
        Set<Map.Entry<String, JsonElement>> elementSet = elements.getAsJsonObject().entrySet();
        if (elementSet.isEmpty()) {
            return;
        }
        handleHashOrEqualKey(valueObj, ENTITY_USAGE_TYPE, HASH);
        handleHashOrEqualKey(valueObj, ENTITY_BASE_TYPE, HASH);
        handleEventType(valueObj, ENTITY_ADMISSIBLE_UNPLANNED_EVENTS);
        handleEventType(valueObj, ENTITY_PLANNED_EVENTS);
        handleAuthorizationRestrict(valueObj, ENTITY_RESTRICT);
        boolean isTableEntity = isMainTableEntity(key, valueObj);
        entityMap.put(key, value);
        if (isTableEntity || isCoreModelEntity(key) || isSubEntity || tableEntities.contains(key)) {
            tableEntities.add(key);
            Iterator<Map.Entry<String, JsonElement>> eleIterator = elementSet.iterator();
            eleIterator.forEachRemaining(e -> handleMainElement(entityMap, tableEntities, backLinkFieldsMap, e.getValue()));
        }
    }

    private static void handleMainElement(Map<String, JsonElement> entityMap, Set<String> tableEntities, Map<String,
            List<String>> backLinkFieldsMap, JsonElement element) {
        if (element == null || element.isJsonNull()) {
            return;
        }
        JsonObject eleObj = element.getAsJsonObject();
        JsonElement typeElement = eleObj.get(ELEMENT_TYPE);
        //recursively find all the association or composition fields
        handleAssociationOrCompositionSubEntities(entityMap, tableEntities, backLinkFieldsMap, eleObj, typeElement);
        JsonElement enumElement = eleObj.get(ELEMENT_ENUM);
        if (enumElement != null && enumElement.isJsonObject()) {
            handleElementEnumObject(enumElement.getAsJsonObject());
        }
        JsonElement defaultElement = eleObj.get(ELEMENT_DEFAULT);
        if (!JsonUtils.isNull(defaultElement) && defaultElement.isJsonObject() && eleObj.isJsonObject()) {
            handleElementDefaultObject(eleObj.getAsJsonObject(), defaultElement.getAsJsonObject());
        }
        JsonElement enumDefaultElement = eleObj.get(ELEMENT_ENUM_DEFAULT_VALUE);
        if (!JsonUtils.isNull(enumDefaultElement) && enumDefaultElement.isJsonPrimitive()) {
            String defVal = enumDefaultElement.getAsString();
            eleObj.remove(ELEMENT_ENUM_DEFAULT_VALUE);
            eleObj.addProperty(ELEMENT_DEFAULT, defVal);
        }
        JsonElement replaceActualEventFieldEle = eleObj.get(ELEMENT_CORE_REPLACE_ACTUAL_EVENT_FIELD);
        if (!JsonUtils.isNull(replaceActualEventFieldEle)) {
            eleObj.remove(ELEMENT_CORE_REPLACE_ACTUAL_EVENT_FIELD);
            eleObj.add(ELEMENT_REPLACE_ACTUAL_EVENT_FIELDS, replaceActualEventFieldEle);
        }
    }

    private static void handleAssociationOrCompositionSubEntities(Map<String, JsonElement> entityMap,
                                                                  Set<String> tableEntities,
                                                                  Map<String, List<String>> backLinkFieldsMap,
                                                                  JsonObject eleObj, JsonElement typeElement) {
        if (JsonUtils.isNull(typeElement) || !typeElement.isJsonPrimitive()) {
            return;
        }
        String elementType = typeElement.getAsString();
        if (!CDS_COMPOSITION.getValue().equalsIgnoreCase(elementType)
                && !CdsDataType.CDS_ASSOCIATION.getValue().equalsIgnoreCase(elementType)) {
            return;
        }
        String targetEntity = eleObj.get(ELEMENT_TARGET).getAsString();
        JsonElement targetEntityElement = entityMap.get(targetEntity);
        if (!tableEntities.contains(targetEntity)) {
            tableEntities.add(targetEntity);
            handleMainEntity(entityMap, tableEntities, backLinkFieldsMap, targetEntity, targetEntityElement, true);
        }
        if (CDS_COMPOSITION.getValue().equalsIgnoreCase(elementType)) {
            handleComposition(eleObj, backLinkFieldsMap, targetEntityElement);
        } else {
            handleAssociation(eleObj, entityMap.get(targetEntity));
        }
    }

    /**
     * Handle association node
     *
     * @param assoElementObject a element json object
     */
    private static void handleAssociation(JsonObject assoElementObject, JsonElement targetEntity) {
        JsonElement keysElement = assoElementObject.get(ELEMENT_KEYS);
        if (keysElement != null && keysElement.isJsonArray()) {
            JsonArray keysArray = keysElement.getAsJsonArray();
            for (int i = 0; i < keysArray.size(); i++) {
                JsonObject keyObj = keysArray.get(i).getAsJsonObject();
                JsonElement refElement = keyObj.get(ELEMENT_KEYS_REF);
                if (!refElement.isJsonArray()) {
                    continue;
                }
                String refValue = refElement.getAsJsonArray().get(0).getAsString();
                keyObj.remove(ELEMENT_KEYS_REF);
                keyObj.addProperty(ELEMENT_KEYS_REF, refValue);
            }
            JsonElement keyElement = assoElementObject.get(ELEMENT_KEY);
            if (keyElement != null) {
                assoElementObject.remove(ELEMENT_KEY);
            }
        } else {
            handleElementOn(assoElementObject, CDS_ASSOCIATION, targetEntity);
        }
    }

    /**
     * Generate the tailored CSN entities from the original one
     *
     * @param currentEntityName current entity name
     * @param originalEntity    original CSN entity Json element
     * @param coreEntityMap     core entity map
     * @return the tailored and desired CSN entity
     */
    private static JsonElement generateDesiredEntity(String currentEntityName, JsonElement originalEntity, Map<String, JsonElement> coreEntityMap, List<String> backLinkFields, Map<String, JsonElement> allEntityMap) {
        JsonObject newJsonEntity = new JsonObject();
        JsonObject origEntityObj = originalEntity.getAsJsonObject();
        // Handle properties of entity itself excluding elements
        for (String entityProperty : REQUIRED_ENTITY_PROPERTIES) {
            JsonElement entityPropElement = origEntityObj.get(entityProperty);
            if (entityPropElement != null) {
                newJsonEntity.add(entityProperty, entityPropElement);
            }
        }
        // Handle elements property
        JsonObject newElements = new JsonObject();
        JsonElement elements = origEntityObj.get(ELEMENTS);
        List<String> coreModelEntities = getCoreModelEntityFromInclude(currentEntityName, origEntityObj);
        Map<String, String> coreModelFields = new HashMap<>(INITIAL_CAPACITY);
        fetchCoreModelFields(coreEntityMap, coreModelEntities, coreModelFields);
        Set<Map.Entry<String, JsonElement>> elementEntries = elements.getAsJsonObject().entrySet();
        Iterator<Map.Entry<String, JsonElement>> eleIterator = elementEntries.iterator();

        Boolean[] includeCustomizedFields = {Boolean.FALSE};
        if (coreModelFields.size() == 0 && !isForWriteEntity(currentEntityName)) {
            includeCustomizedFields[0] = Boolean.TRUE;
        }
        List<JsonObject> associationElements = new ArrayList<>();
        List<String> associationElementNames = new ArrayList<>();
        eleIterator.forEachRemaining(e ->
                generateNewElement(allEntityMap, newElements, coreModelFields,
                        includeCustomizedFields, associationElements, associationElementNames, e));

        addBackLinkProperty(associationElements, backLinkFields);
        addForeignKeyFldProperty(associationElementNames, associationElements, newElements);
        if (Boolean.TRUE.equals(includeCustomizedFields[0])) {
            newJsonEntity.addProperty(ENTITY_INCLUDE_CUSTOMIZED_FIELDS, Boolean.TRUE);
        }

        //only add @@inheritFromCore for the user defined event/process type
        if (origEntityObj.has(ENTITY_BASE_TYPE) && (EntityBaseType.EVENT.getValue().equals(origEntityObj.get(ENTITY_BASE_TYPE).getAsString()) || EntityBaseType.TRACKED_PROCESS.getValue().equals(origEntityObj.get(ENTITY_BASE_TYPE).getAsString()))) {
            //add an annotation “@@inheritFromCore” for each user defined process type and event type, to record the inherited core type
            generateInheritFromCore(currentEntityName, origEntityObj, newJsonEntity);
        }

        newJsonEntity.add(ELEMENTS, newElements);
        return newJsonEntity;
    }

    private static void fetchCoreModelFields(Map<String, JsonElement> coreEntityMap, List<String> coreModelEntities, Map<String, String> coreModelFields) {
        if (!coreModelEntities.isEmpty()) {
            for (String s : coreModelEntities) {
                JsonElement coreEntity = coreEntityMap.get(s);
                if (coreEntity == null || coreEntity.getAsJsonObject().get(ELEMENTS) == null) {
                    continue;
                }
                JsonElement coreElements = coreEntity.getAsJsonObject().get(ELEMENTS);
                Map<String, String> map = coreElements.getAsJsonObject().keySet().stream().collect(Collectors.toMap(String::toString, v -> v));
                coreModelFields.putAll(map);
            }
        }
    }

    private static void generateInheritFromCore(String currentEntityName, JsonObject origEntityObj, JsonObject newJsonEntity) {
        //handle includes property
        if (!origEntityObj.has(ENTITY_INCLUDES)) {
            throw new MetadataException(MESSAGE_CODE_INCLUDES_NOT_FOUND, new Object[]{currentEntityName});
        } else {
            JsonArray includesElement = origEntityObj.get(ENTITY_INCLUDES).getAsJsonArray();
            List<String> coreTypes = new ArrayList<>();
            includesElement.forEach(element -> {
                String elementStr = element.getAsString();
                if (CORE_TYPES.indexOf(elementStr) != -1) {
                    coreTypes.add(elementStr);
                }
            });

            //the user defined event/process type must inherit one of core types directly
            if (coreTypes.size() > 1) {
                throw new MetadataException(MESSAGE_CODE_INHERIT_MORE_THAN_ONE_CORE_TYPE, new Object[]{currentEntityName, coreTypes});
            } else if (coreTypes.size() == 1) {
                newJsonEntity.addProperty(ENTITY_INHERIT_FROM_CORE_TYPE, coreTypes.get(0));
            }
        }
    }

    private static void generateNewElement(Map<String, JsonElement> allEntityMap, JsonObject newElements,
                                           Map<String, String> coreModelFields, Boolean[] includeCustomizedFields,
                                           List<JsonObject> associationElements,
                                           List<String> associationElementNames,
                                           Map.Entry<String, JsonElement> e) {
        String elementName = e.getKey();
        JsonElement element = e.getValue();
        JsonObject eleObj = element.getAsJsonObject();
        JsonObject newElementObj = new JsonObject();
        for (String elementProp : REQUIRED_ELEMENT_PROPERTIES) {
            JsonElement elementPropElement = eleObj.get(elementProp);
            if (elementPropElement != null) {
                newElementObj.add(elementProp, elementPropElement);
            }
        }
        String type = eleObj.get(ELEMENT_TYPE).getAsString();
        if (CDS_ASSOCIATION.getValue().equalsIgnoreCase(type)) {
            String targetEntityName = newElementObj.get(ELEMENT_TARGET).getAsString();
            handleAssociation(newElementObj, allEntityMap.get(targetEntityName));
            associationElements.add(newElementObj);
            associationElementNames.add(elementName);
        } else if (CDS_COMPOSITION.getValue().equalsIgnoreCase(type)) {
            String targetEntityName = newElementObj.get(ELEMENT_TARGET).getAsString();
            handleElementOn(newElementObj, CDS_COMPOSITION, allEntityMap.get(targetEntityName));
        }
        if (coreModelFields.size() > 0) {
            String coreModelField = coreModelFields.get(elementName);
            if (StringUtils.isBlank(coreModelField)) {
                includeCustomizedFields[0] = Boolean.TRUE;
            } else {
                newElementObj.addProperty(ELEMENT_FROM_CORE_MODEL, Boolean.TRUE);
            }
        }
        newElements.add(elementName, newElementObj);
    }

    private static void handleComposition(JsonObject eleObj, Map<String, List<String>> backLinkFieldsMap, JsonElement targetEntity) {
        String ref = handleElementOn(eleObj, CDS_COMPOSITION, targetEntity);

        String targetEntityName = eleObj.get(ELEMENT_TARGET).getAsString();
        JsonElement newOnElement = eleObj.get(ELEMENT_ON);
        boolean handleId = false;
        if (newOnElement != null && newOnElement.isJsonObject()) {
            String newOnRef = newOnElement.getAsJsonObject().get(ELEMENT_KEYS_REF).getAsString();
            if (SELF.equalsIgnoreCase(newOnRef)) {
                handleId = true;
            }
        }
        addBackLinkField(backLinkFieldsMap, ref, targetEntityName, handleId);
        if (!targetEntityName.endsWith(FOR_WRITE_SUFFIX)) {
            String forWriteEntityName = targetEntityName + FOR_WRITE_SUFFIX;
            addBackLinkField(backLinkFieldsMap, ref, forWriteEntityName, handleId);
        }
    }

    private static String handleElementOn(JsonObject eleOjb, CdsDataType cdsDataType, JsonElement targetEntity) {
        JsonElement onElement = eleOjb.get(ELEMENT_ON);
        if (onElement == null) {
            return StringUtils.EMPTY;
        }
        if (!onElement.isJsonArray()) {
            return handleSelf(targetEntity, onElement);
        }
        JsonArray onArray = onElement.getAsJsonArray();
        JsonElement refObj = onArray.get(0).getAsJsonObject().get(ELEMENT_ON_REF).getAsJsonArray().get(1);
        String refStr = refObj.getAsString();
        JsonElement genObj = onArray.get(2).getAsJsonObject().get(ELEMENT_ON_REF).getAsJsonArray().get(0);
        String genStr = genObj.getAsString();
        eleOjb.remove(ELEMENT_ON);

        JsonObject newOnObj = new JsonObject();
        switch (cdsDataType) {
            case CDS_COMPOSITION:
                newOnObj.addProperty(ELEMENT_ON_REF, genStr);
                newOnObj.addProperty(ELEMENT_KEYS_GENERATED_FIELD_NAME, refStr);
                break;
            case CDS_ASSOCIATION:
                newOnObj.addProperty(ELEMENT_ON_REF, refStr);
                newOnObj.addProperty(ELEMENT_KEYS_GENERATED_FIELD_NAME, genStr);
                break;
            default:
        }

        eleOjb.add(ELEMENT_ON, newOnObj);
        return refStr;
    }

    private static String handleSelf(JsonElement targetEntity, JsonElement onElement) {
        JsonObject onElementObj = onElement.getAsJsonObject();
        String ref = onElementObj.get(ELEMENT_KEYS_REF).getAsString();
        if (!SELF.equalsIgnoreCase(ref) || targetEntity == null) {
            return StringUtils.EMPTY;
        }
        //replace $self with a concrete property name
        String generatedField = onElement.getAsJsonObject().get(ELEMENT_KEYS_GENERATED_FIELD_NAME).getAsString();
        JsonElement generatedFieldElement = targetEntity.getAsJsonObject().get(ELEMENTS).getAsJsonObject().get(generatedField);
        JsonElement generatedOnElement = generatedFieldElement.getAsJsonObject().get(ELEMENT_ON);
        JsonObject generatedOnObj;
        if (generatedOnElement == null) {
            generatedOnElement = generatedFieldElement.getAsJsonObject().get(ELEMENT_KEYS);
            generatedOnObj = generatedOnElement.getAsJsonArray().get(0).getAsJsonObject();
        } else {
            generatedOnObj = generatedOnElement.getAsJsonObject();
        }
        if (generatedOnObj == null) {
            return StringUtils.EMPTY;
        }
        onElementObj.remove(ELEMENT_KEYS_REF);
        onElementObj.addProperty(ELEMENT_KEYS_REF, generatedOnObj.get(ELEMENT_KEYS_REF).getAsString());
        onElementObj.remove(ELEMENT_KEYS_GENERATED_FIELD_NAME);
        onElementObj.addProperty(ELEMENT_KEYS_GENERATED_FIELD_NAME, generatedOnObj.get(ELEMENT_KEYS_GENERATED_FIELD_NAME).getAsString());
        return generatedOnObj.get(ELEMENT_KEYS_REF).getAsString();
    }

    private static void addBackLinkField(Map<String, List<String>> backLinkFieldsMap, String ref, String targetEntityName, boolean handleId) {
        List<String> refs = new ArrayList<>();
        refs.add(ref);
        if (handleId) {
            refs.add(ref + "_id");
        }
        List<String> backLinks = backLinkFieldsMap.computeIfAbsent(targetEntityName, k -> new ArrayList<>());
        for (String rf : refs) {
            if (!backLinks.contains(rf)) {
                backLinks.add(rf);
            }
        }
    }

    private static void addBackLinkProperty(List<JsonObject> associationElements, List<String> backLinkFields) {
        if (backLinkFields == null || backLinkFields.isEmpty()) {
            return;
        }
        for (JsonObject eleObj : associationElements) {
            JsonElement backLinkElement = eleObj.get(ELEMENT_BACK_LINK);
            if (backLinkElement != null) {
                continue;
            }
            String generatedFieldStr = getGeneratedFieldName(eleObj);
            if (backLinkFields.contains(generatedFieldStr)) {
                eleObj.addProperty(ELEMENT_BACK_LINK, Boolean.TRUE);
            }
        }
    }

    /**
     * Extract generatedFieldName from association element object.
     *
     * @param associationObj association object
     * @return generated field name
     */
    private static String getGeneratedFieldName(JsonObject associationObj) {
        JsonElement keysElement = associationObj.get(ELEMENT_KEYS);
        JsonElement generatedFieldElement = null;
        if (keysElement != null) {
            generatedFieldElement = keysElement.getAsJsonArray().get(0).getAsJsonObject().get(ELEMENT_KEYS_GENERATED_FIELD_NAME);
        } else {
            keysElement = associationObj.get(ELEMENT_ON);
            if (keysElement != null) {
                if (keysElement.isJsonObject()) {
                    generatedFieldElement = keysElement.getAsJsonObject().get(ELEMENT_KEYS_GENERATED_FIELD_NAME);
                } else if (keysElement.isJsonArray()) {
                    generatedFieldElement = keysElement.getAsJsonArray().get(2).getAsJsonObject().get(ELEMENT_KEYS_REF);
                }
            }
        }
        return generatedFieldElement == null ? "" : generatedFieldElement.getAsString();
    }

    /**
     * Add foreignKeyFld property to generated field of a given association element
     *
     * @param associationElementNames association element names
     * @param associationElements     association elements
     * @param allElements             all the element of a given metadata entity
     */
    private static void addForeignKeyFldProperty(List<String> associationElementNames, List<JsonObject> associationElements, JsonObject allElements) {
        for (int i = 0; i < associationElements.size(); i++) {
            String generatedFieldName = getGeneratedFieldName(associationElements.get(i));
            JsonElement generatedFldElement = allElements.get(generatedFieldName);
            if (generatedFldElement != null) {
                JsonObject asJsonObject = generatedFldElement.getAsJsonObject();
                JsonElement fkFldElement = asJsonObject.get(ELEMENT_FOREIGN_KEY_FLD);
                if (fkFldElement == null) {
                    asJsonObject.addProperty(ELEMENT_FOREIGN_KEY_FLD, associationElementNames.get(i));
                }
            }
        }
    }

    private static List<String> getCoreModelEntityFromInclude(String currentEntityName, JsonObject origEntityObj) {
        List<String> ret = new ArrayList<>();
        JsonElement includesElement = origEntityObj.get(ENTITY_INCLUDES);
        if (includesElement == null) {
            if (isCoreModelEntity(currentEntityName)) {
                ret.add(currentEntityName);
            }
            return ret;
        }
        JsonArray includeArray = includesElement.getAsJsonArray();
        for (int i = 0; i < includeArray.size(); i++) {
            String baseType = includeArray.get(i).getAsString();
            if (baseType.startsWith(CORE_MODEL_PREFIX) && !baseType.endsWith(FOR_WRITE_SUFFIX)) {
                ret.add(baseType);
            }
        }
        return ret;
    }

    /**
     * Handle event type to remove the "=" key from the value node.
     *
     * @param valueObj     events Json object
     * @param propertyName events node name such as
     *                     {@link MetadataConstants#ENTITY_ADMISSIBLE_UNPLANNED_EVENTS}
     */
    private static void handleEventType(JsonObject valueObj, String propertyName) {
        JsonElement eventsElement = valueObj.get(propertyName);
        if (eventsElement == null) {
            return;
        }
        JsonArray eventsArray = eventsElement.getAsJsonArray();
        for (int i = 0; i < eventsArray.size(); i++) {
            JsonObject eventObj = eventsArray.get(i).getAsJsonObject();
            handleHashOrEqualKey(eventObj, ENTITY_EVENT_TYPE, EQUAL);
        }
    }

    /**
     * Change @restrict to @@authorization
     * Change below annotation
     * "@restrict": [{
     * "grant": ["Read", "Report"],
     * "where": "supplierId = $user.LBNID"
     * }],
     * to
     * "@@authorization":[{"principalType": "LBNID", "element" : "supplierId", "permission": ["Read", "Report"]}]
     *
     * @param valueObj
     * @param propertyName restrict property name such as @restrict
     */
    private static void handleAuthorizationRestrict(JsonObject valueObj, String propertyName) {
        JsonElement restrictElement = valueObj.get(propertyName);
        if (restrictElement == null) {
            return;
        }
        JsonArray restrictArray = restrictElement.getAsJsonArray();
        JsonArray authorizationArray = new JsonArray();
        for (int i = 0; i < restrictArray.size(); i++) {
            JsonObject restrictObj = restrictArray.get(i).getAsJsonObject();
            JsonObject authorizationObj = new JsonObject();
            JsonElement grantElement = restrictObj.get(ENTITY_RESTRICT_GRANT);
            if (grantElement != null && !grantElement.isJsonNull()) {
                authorizationObj.add(ENTITY_AUTHORIZATION_PERMMISIONS, grantElement);
            }
            JsonElement whereElement = restrictObj.get(ENTITY_RESTRICT_WHERE);
            if (whereElement != null && !whereElement.isJsonNull()) {
                String whereString = whereElement.getAsString();
                String[] split = StringUtils.split(whereString, EQUAL);
                authorizationObj.addProperty(ENTITY_AUTHORIZATION_ELEMENT, split[0].trim());
                String elementStr = split[1];
                authorizationObj.addProperty(ENTITY_AUTHORIZATION_PRINCIPAL_TYPE, elementStr.substring(elementStr.lastIndexOf(DOT) + 1));
            }
            authorizationArray.add(authorizationObj);
        }
        valueObj.add(ENTITY_AUTHORIZATION, authorizationArray);
        valueObj.remove(propertyName);
    }

    /**
     * Handle property which has "#" or "=" as key in the value property. e.g.:
     * "@com.sap.gtt.core.CoreModel.BaseType": {
     * "#": "Event"
     * }
     * will be changed to
     * "@com.sap.gtt.core.CoreModel.BaseType": "Event"
     *
     * @param valueObj     Json object to be handled
     * @param propertyName property name
     */
    private static void handleHashOrEqualKey(JsonObject valueObj, String propertyName, String hashOrEqualKey) {
        JsonElement propertyElement = valueObj.get(propertyName);
        if (propertyElement != null && !propertyElement.isJsonPrimitive()) {
            String propertyValStr;
            if (propertyElement.isJsonArray()) {
                propertyValStr = propertyElement.getAsJsonArray().get(0).getAsJsonObject().get(hashOrEqualKey).getAsString();
            } else {
                propertyValStr = propertyElement.getAsJsonObject().get(hashOrEqualKey).getAsString();
            }
            valueObj.remove(propertyName);
            valueObj.addProperty(propertyName, propertyValStr);
        }
    }

    /**
     * Handle Enum object just retain "value" node
     *
     * @param enumObj enum Json object
     */
    private static void handleElementEnumObject(JsonObject enumObj) {
        enumObj.entrySet().iterator().forEachRemaining(e -> {
            JsonElement valElement = e.getValue();
            if (valElement.isJsonPrimitive()) {
                return;
            }
            JsonObject valObj = valElement.getAsJsonObject();
            final JsonElement[] val = new JsonElement[1];
            Iterator<Map.Entry<String, JsonElement>> innerIterator = valObj.entrySet().iterator();
            innerIterator.forEachRemaining(e1 -> {
                String key1 = e1.getKey();
                if (VAL.equalsIgnoreCase(key1)) {
                    val[0] = e1.getValue();
                }
            });
            if (JsonUtils.isNull(val[0])) {
                val[0] = new JsonPrimitive(e.getKey());
            }
            e.setValue(val[0]);
        });
    }

    private static void handleElementDefaultObject(JsonObject eleObj, JsonObject defaultObj) {
        if (!defaultObj.isJsonPrimitive()) {
            JsonElement valElement = defaultObj.get(VAL);
            if (JsonUtils.isNull(valElement)) {
                valElement = defaultObj.get(HASH);
            }
            if (valElement != null) {
                String val = valElement.getAsString();
                eleObj.remove(ELEMENT_DEFAULT);
                eleObj.addProperty(ELEMENT_DEFAULT, val);
            }
        }
    }

    /**
     * Check whether an entity has a corresponding table or not.
     * To fetch this kind of entities, it should meet below criteria:
     * 1. The value of base type annotation(@com.sap.gtt.core.CoreModel.BaseType) is {@link EntityBaseType#EVENT}
     * or {@link EntityBaseType#TRACKED_PROCESS};
     * 2. It is not a projection, that means it only has "includes".
     * <p>
     * Note: Entities which end with {@link MetadataConstants#FOR_WRITE_SUFFIX} share the same table with the one without this suffix
     *
     * @param entityName entity full name
     * @param jsonObject a CSN entity json object
     * @return true if there is a corresponding table
     */
    private static boolean isMainTableEntity(String entityName, JsonObject jsonObject) {
        boolean ret = false;
        boolean isForWriteEntity = isForWriteEntity(entityName);
        if (isForWriteEntity) {
            ret = true;
        } else {
            ret = isBaseTypeTrackedProcessOrEvent(jsonObject);
        }

        JsonElement includesEle = jsonObject.get(ENTITY_INCLUDES);
        if (includesEle == null) {
            ret = false;
        } else {
            JsonArray includes = includesEle.getAsJsonArray();
            for (int i = 0; i < includes.size(); i++) {
                String includeEnt = includes.get(i).getAsString();
                if (isCoreModelEntity(includeEnt)) {
                    ret = true;
                    break;
                }
            }
        }

        return ret;
    }

    private static boolean isBaseTypeTrackedProcessOrEvent(JsonObject jsonObject) {
        JsonElement baseType = jsonObject.get(ENTITY_BASE_TYPE);
        if (baseType == null) {
            return false;
        }
        String baseTypeStr;
        if (baseType.isJsonPrimitive()) {
            baseTypeStr = baseType.getAsString();
        } else {
            baseTypeStr = baseType.getAsJsonObject().get(HASH).getAsJsonObject().getAsString();
        }
        return StringUtils.equalsIgnoreCase(baseTypeStr, EntityBaseType.TRACKED_PROCESS.getValue())
                || StringUtils.equalsIgnoreCase(baseTypeStr, EntityBaseType.EVENT.getValue());
    }

    /**
     * Fetch all the metadata entities of a particular base type from derived CSN
     *
     * @param derivedCsn     derived CSN Json string
     * @param entityBaseType entity base type, such as {@link EntityBaseType#TRACKED_PROCESS}
     * @return all the metadata entities of a particular base type
     */
    public static List<MetadataEntity> getAllTheMetadataEntitiesOf(String derivedCsn, EntityBaseType entityBaseType) {
        List<MetadataEntity> entities = parseToEntities(derivedCsn);
        return entities.stream()
                .filter(e -> StringUtils.equalsIgnoreCase(entityBaseType.getValue(), e.getBaseType()))
                .collect(Collectors.toList());
    }

    /**
     * Extract metadata project namespace from full entity name.
     * <pre>
     * For OData entity type:
     * com.sap.gtt.app.mim.MIMService.Event
     * 1. name: Event
     * 2. service: MIMService
     * 3. namespace: com.sap.gtt.app.mim
     * </pre>
     * <pre>
     * For model entity type:
     * com.sap.gtt.app.mim.DeliveryModel.DeliveryProcess
     * 1. process name: DeliveryProcess
     * 2. context: DeliveryModel
     * 3. namespace: com.sap.gtt.app.mim
     * </pre>
     * </p>
     *
     * @param fullEntityName entity full name
     * @return namespace information
     */
    public static String getProjectNamespace(String fullEntityName) {
        String namespaceWithContext = cutStringFromLastDot(fullEntityName);
        return cutStringFromLastDot(namespaceWithContext);
    }

    public static String cutStringFromLastDot(String string) {
        if (StringUtils.isBlank(string) || StringUtils.lastIndexOf(string, DOT) == -1) {
            return string;
        }
        return StringUtils.substring(string, 0, StringUtils.lastIndexOf(string, DOT));
    }

    /**
     * <pre>
     * For model entity type:
     * com.sap.gtt.app.mim.DeliveryModel.DeliveryProcess
     * 1. process name: DeliveryProcess
     * 2. context: DeliveryModel
     * 3. namespace: com.sap.gtt.app.mim
     * </pre>
     *
     * @param fullEntityName entity full name
     * @return context of the entity
     */
    public static String getContextName(String fullEntityName) {
        // com.sap.gtt.app.mim.DeliveryModel.DeliveryProcess
        int leastStrArrLength = 4;
        if (StringUtils.isBlank(fullEntityName)) {
            return StringUtils.EMPTY;
        }
        String[] strs = StringUtils.split(fullEntityName, DOT);
        if (strs.length < leastStrArrLength) {
            return StringUtils.EMPTY;
        }
        return strs[strs.length - 2];
    }

    /**
     * Get the abbr name of a given entity
     *
     * @param entityName entity full or abbr entity name
     * @return abbr name of the given entity name
     */
    public static String getEntityAbbrName(String entityName) {
        return getAbbrName(entityName);
    }

    private static String getAbbrName(String fullName) {
        if (StringUtils.isBlank(fullName)) {
            return StringUtils.EMPTY;
        }
        if (StringUtils.indexOf(fullName, DOT) == -1) {
            return fullName;
        }
        return StringUtils.substring(fullName, (StringUtils.lastIndexOf(fullName, DOT) + 1));
    }

    /**
     * Check whether a given entity full or abbr. name is the same as the condition
     *
     * @param tobeCheckedEntName to be checked entity name such as
     * @param conditionEntNames  conditional entity name such as com.sap.gtt.app.mim.delivery.DeliveryModel.DeliveryProcess or DeliveryProcess
     * @return true if its full or abbr. name is the same as the condition
     */
    protected static boolean isConditionName(String tobeCheckedEntName, List<String> conditionEntNames) {
        return conditionEntNames.stream()
                .anyMatch(s -> s.equalsIgnoreCase(tobeCheckedEntName) ||
                        s.equalsIgnoreCase(getEntityAbbrName(tobeCheckedEntName)));
    }

    /**
     * Check whether a given entity is a core model entity or not
     *
     * @param entityFullName entity full name
     * @return true if the given entity is a core model entity
     */
    public static boolean isCoreModelEntity(String entityFullName) {
        if (isForWriteEntity(entityFullName)) {
            entityFullName = StringUtils.substring(entityFullName, 0, StringUtils.lastIndexOfIgnoreCase(entityFullName, FOR_WRITE_SUFFIX));
        }
        String entityName = entityFullName;
        CoreModelEntity[] values = CoreModelEntity.values();
        return stream(values).anyMatch(e -> e.getFullName().equalsIgnoreCase(entityName));
    }

    /**
     * Check whether a given entity is a master data entity or not
     *
     * @param entityFullName entity full name
     * @return true if the given entity is a core model entity
     */
    public static boolean isMasterDataEntity(String entityFullName) {
        MasterDataEntity[] values = MasterDataEntity.values();
        return stream(values).anyMatch(e -> e.getFullName().equalsIgnoreCase(entityFullName));
    }

    /**
     * Check whether a given entity ends with ForWrite or not
     *
     * @param entityFullName entity full name
     * @return true if the given entity ends with ForWrite
     */
    public static boolean isForWriteEntity(String entityFullName) {
        return StringUtils.endsWithIgnoreCase(entityFullName, FOR_WRITE_SUFFIX);
    }

    public static void findRelatedEntities(Map<String, MetadataEntity> allEntityMap, MetadataEntity currentEntity, Map<String, MetadataEntity> relatedEntityMap) {
        List<String> allTargetEntityNames = currentEntity.getElements().stream()
                .filter(e -> (CDS_ASSOCIATION.equals(e.getType()) || CDS_COMPOSITION.equals(e.getType()))
                        && !CsnParser.isMasterDataEntity(e.getTarget())
                ).map(MetadataEntityElement::getTarget).distinct().collect(Collectors.toList());
        if (allTargetEntityNames.isEmpty()) {
            return;
        }
        allTargetEntityNames.forEach(e -> {
            MetadataEntity targetEntity = allEntityMap.get(e);
            if (targetEntity == null) {
                throw new MetadataException(MESSAGE_CODE_NOT_FOUND, new Object[]{e});
            }
            if (relatedEntityMap.containsKey(e)) {
                return;
            }
            relatedEntityMap.put(e, targetEntity);
            findRelatedEntities(allEntityMap, targetEntity, relatedEntityMap);
        });
    }
}