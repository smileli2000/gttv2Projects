package com.sap.gtt.v2.core.domain.execution;

import java.util.List;

/**
 * @author I302310
 */
public class RequestTrackingIdDto {
    private String requestId;
    private List<String> trackingIds;

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public List<String> getTrackingIds() {
        return trackingIds;
    }

    public void setTrackingIds(List<String> trackingIds) {
        this.trackingIds = trackingIds;
    }
}
