package com.sap.gtt.v2.core.dao.execution;

import com.sap.gtt.v2.core.entity.execution.ExecutionUnit;

/**
 * @author I302310
 */
public interface IExecutionUnitDao {
    /**
     * query id by eventId and correlatedTpId
     * @param objectId
     * @param transformId
     * @param relatedId
     * @return
     */
    ExecutionUnit queryExecutionUnit(String eventId, String correlatedTpId);

    ExecutionUnit queryExecutionUnit(String lastExecutionId);

    /**
     * insert one execution_unit, id is set outside
     * @param execution
     */
    void insertExecutionUnit(ExecutionUnit execution);

    void updateExecutionUnit(String id, int executionCount, String lastExecutionId);
}
