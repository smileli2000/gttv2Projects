package com.sap.gtt.v2.core.domain.dpp;

import com.sap.gtt.v2.core.domain.metadata.MetadataConstants;

public class DppProperty {
    private String name;
    private String physicalName;
    private MetadataConstants.CdsDataType type;
    private int length;

    public void setLength(int length) {
        this.length = length;
    }

    public int getLength() {
        return length;
    }

    public void setType(MetadataConstants.CdsDataType type) {
        this.type = type;
    }

    public MetadataConstants.CdsDataType getType() {
        return type;
    }

    public String getName() {
        return name;
    }

    public String getPhysicalName() {
        return physicalName;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPhysicalName(String physicalName) {
        this.physicalName = physicalName;
    }

    @Override
    public String toString() {
        return "DppProperty{" +
                "name='" + name + '\'' +
                ", physicalName='" + physicalName + '\'' +
                ", type=" + type +
                ", length=" + length +
                '}';
    }
}
