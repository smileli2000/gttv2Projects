package com.sap.gtt.v2.core.domain.metadata;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.sap.gtt.v2.util.DBUtils;
import com.sap.gtt.v2.util.JsonUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;

import java.io.Serializable;
import java.util.*;

import static com.sap.gtt.v2.core.domain.metadata.MetadataConstants.*;

/**
 * Abstract for metadata entity elements from derived CSN
 *
 * @author I321712
 */
public class MetadataEntityElement implements Serializable {
    private static final long serialVersionUID = 731838202992034842L;

    private String name;
    private String physicalName;
    private CdsDataType type;
    private boolean key;
    private int length;
    private String defaultVal;
    private String enumVal;
    private Map<String, String> enumVals;
    private String target;
    private String cardinality;
    private String keys;
    private List<MetadataForeignKey> foreignKeyList = new ArrayList<>();
    private MetadataForeignKey foreignKey;
    private boolean fromCoreModel;
    private boolean customizedField;
    private int precision;
    private int scale;
    private String sourceAltKey;
    private boolean backLink;
    private String on;
    private String foreignKeyFld;
    private FieldContent fieldContent;
    private boolean dppPii;
    private boolean dppSpi;
    private boolean dppDataSubjectId;
    private List<String> replaceActualEventFields = new ArrayList<>();
    private String replaceActualEventFieldsStr;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhysicalName() {
        if (physicalName == null) {
            physicalName = DBUtils.toElementPhysicalName(name);
        }
        return physicalName;
    }

    public CdsDataType getType() {
        return type;
    }

    public void setType(CdsDataType type) {
        this.type = type;
    }

    public boolean isKey() {
        return key;
    }

    public void setKey(boolean key) {
        this.key = key;
    }

    public int getLength() {
        return length;
    }

    public void setLength(int length) {
        this.length = length;
    }

    public String getDefaultVal() {
        return defaultVal;
    }

    public void setDefaultVal(String defaultVal) {
        this.defaultVal = defaultVal;
    }

    public String getEnumVal() {
        return enumVal;
    }

    public void setEnumVal(String enumVal) {
        this.enumVal = enumVal;
    }

    public Map<String, String> getEnumVals() {
        String val = getEnumVal();
        if (StringUtils.isNotBlank(val) && enumVals == null) {
            enumVals = new HashMap<>(INITIAL_CAPACITY);
            JsonObject enumObj = JsonUtils.generateJsonObjectFromJsonString(val);
            enumObj.keySet().iterator().forEachRemaining(e -> {
                String value = JsonUtils.getValueAsString(enumObj, e);
                if (StringUtils.isNotBlank(value)) {
                    enumVals.put(e, value);
                }
            });
        }
        return enumVals;
    }

    public String getTarget() {
        return target;
    }

    public void setTarget(String target) {
        this.target = target;
    }

    public String getCardinality() {
        return cardinality;
    }

    public void setCardinality(String cardinality) {
        this.cardinality = cardinality;
    }

    public String getKeys() {
        return keys;
    }

    public void setKeys(String keys) {
        this.keys = keys;
        initForeighKeyList(this.keys);
    }

    public void initListProperties() {
        initForeighKeyList(getKeys());
        initForeighKeyList(getOn());
        initReplaceActualEventFields();
    }

    private void initReplaceActualEventFields() {
        String replaceStr = getReplaceActualEventFieldsStr();
        if (StringUtils.isNotBlank(replaceStr) && CollectionUtils.isEmpty(replaceActualEventFields)) {
            JsonArray jsonArray = JsonUtils.generateJsonElementFromString(replaceStr).getAsJsonArray();
            for (int i = 0; i < jsonArray.size(); i++) {
                this.replaceActualEventFields.add(jsonArray.get(i).getAsString());
            }
        }
        setReplaceActualEventFieldsStr(null);
    }

    private void initForeighKeyList(String fkJsonStr) {
        if (StringUtils.isNotBlank(keys) && StringUtils.equals(fkJsonStr, keys)) {
            JsonArray jsonArray = JsonUtils.generateJsonElementFromString(keys).getAsJsonArray();
            for (int i = 0; i < jsonArray.size(); i++) {
                JsonObject arrObj = jsonArray.get(i).getAsJsonObject();
                MetadataForeignKey fk = new MetadataForeignKey();
                fk.setReferenceFieldName(arrObj.get(ELEMENT_KEYS_REF).getAsString());
                fk.setGeneratedFieldName(arrObj.get(ELEMENT_KEYS_GENERATED_FIELD_NAME).getAsString());
                foreignKeyList.add(fk);
            }
        } else if (StringUtils.isNotBlank(on) && StringUtils.equals(fkJsonStr, on)) {
            JsonObject onObj = JsonUtils.generateJsonObjectFromJsonString(on);
            MetadataForeignKey fk = new MetadataForeignKey();
            fk.setReferenceFieldName(onObj.get(ELEMENT_KEYS_REF).getAsString());
            fk.setGeneratedFieldName(onObj.get(ELEMENT_KEYS_GENERATED_FIELD_NAME).getAsString());
            foreignKeyList.add(fk);
        }
    }

    public List<MetadataForeignKey> getForeignKeyList() {
        return Collections.unmodifiableList(foreignKeyList);
    }

    public MetadataForeignKey getForeignKey() {
        if (!getForeignKeyList().isEmpty()) {
            foreignKey = foreignKeyList.get(0);
        }
        return foreignKey;
    }

    public int getPrecision() {
        return precision;
    }

    public void setPrecision(int precision) {
        this.precision = precision;
    }

    public int getScale() {
        return scale;
    }

    public void setScale(int scale) {
        this.scale = scale;
    }

    public String getSourceAltKey() {
        return sourceAltKey;
    }

    public void setSourceAltKey(String sourceAltKey) {
        this.sourceAltKey = sourceAltKey;
    }

    public boolean isFromCoreModel() {
        return fromCoreModel;
    }

    public void setFromCoreModel(boolean fromCoreModel) {
        this.fromCoreModel = fromCoreModel;
    }

    public boolean isCustomizedField() {
        return customizedField;
    }

    public void setCustomizedField(boolean customizedField) {
        this.customizedField = customizedField;
    }

    public boolean isBackLink() {
        return backLink;
    }

    public void setBackLink(boolean backLink) {
        this.backLink = backLink;
    }

    public String getOn() {
        return on;
    }

    public void setOn(String on) {
        this.on = on;
        initForeighKeyList(this.on);
    }

    public String getForeignKeyFld() {
        return foreignKeyFld;
    }

    public void setForeignKeyFld(String foreignKeyFld) {
        this.foreignKeyFld = foreignKeyFld;
    }

    /**
     * Check whether this field is a generated field pointing to another entity
     *
     * @return true if this field is a foreign key field
     */
    public boolean isForeignKey() {
        return StringUtils.isNotBlank(getForeignKeyFld());
    }

    public FieldContent getFieldContent() {
        return fieldContent;
    }

    public void setFieldContent(FieldContent fieldContent) {
        this.fieldContent = fieldContent;
    }

    public boolean isDppPii() {
        return dppPii;
    }

    public void setDppPii(boolean dppPii) {
        this.dppPii = dppPii;
    }

    public boolean isDppSpi() {
        return dppSpi;
    }

    public void setDppSpi(boolean dppSpi) {
        this.dppSpi = dppSpi;
    }

    public boolean isDppDataSubjectId() {
        return dppDataSubjectId;
    }

    public void setDppDataSubjectId(boolean dppDataSubjectId) {
        this.dppDataSubjectId = dppDataSubjectId;
    }

    public List<String> getReplaceActualEventFields() {
        return new ArrayList<>(replaceActualEventFields);
    }

    public void addReplaceActualEventField(String replaceActualEventField) {
        this.replaceActualEventFields.add(replaceActualEventField);
    }

    public void clearReplaceActualEventFields() {
        this.replaceActualEventFields.clear();
    }

    public String getReplaceActualEventFieldsStr() {
        return replaceActualEventFieldsStr;
    }

    public void setReplaceActualEventFieldsStr(String replaceActualEventFieldsStr) {
        this.replaceActualEventFieldsStr = replaceActualEventFieldsStr;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        MetadataEntityElement that = (MetadataEntityElement) o;
        return name.equals(that.name) &&
                type.equals(that.type) &&
                key == that.key &&
                length == that.length &&
                precision == that.precision &&
                scale == that.scale;
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, type, key, length, precision, scale);
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", MetadataEntityElement.class.getSimpleName() + "[", "]")
                .add("name='" + name + "'")
                .add("type=" + type)
                .add("key=" + key)
                .add("length=" + length)
                .add("defaultVal='" + defaultVal + "'")
                .add("enumVal='" + enumVal + "'")
                .add("target='" + target + "'")
                .add("cardinality='" + cardinality + "'")
                .add("keys='" + keys + "'")
                .add("on=" + on)
                .add("fromCoreModel=" + fromCoreModel)
                .add("precision=" + precision)
                .add("scale=" + scale)
                .add("sourceAltKey='" + sourceAltKey + "'")
                .add("backLink='" + backLink + "'")
                .add("dppPii='" + dppPii + "'")
                .add("dppSpi='" + dppSpi + "'")
                .add("dppDataSubjectId='" + dppDataSubjectId + "'")
                .toString();
    }
}
