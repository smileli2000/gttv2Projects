package com.sap.gtt.v2.servicemanager;

import java.io.Serializable;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpStatus;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.google.gson.JsonObject;
import com.sap.gtt.v2.configuration.EnvironmentsConfiguration.VcapServiceParser.DatabaseServiceInstance;
import com.sap.gtt.v2.configuration.EnvironmentsConfiguration.VcapServiceParser.ManagedHanaServiceInstance.ManagedHanaTenant;
import com.sap.gtt.v2.configuration.ServiceInstancesMapping;
import com.sap.gtt.v2.exception.GeneralNoneTranslatableException;
import com.sap.gtt.v2.exception.OperationNotAllowed;
import com.sap.gtt.v2.util.JsonUtils;
import com.sap.gtt.v2.util.SpringContextUtils;

public class GTTInstance implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 510064492819456060L;
	public static final String STORAGE_TYPE_MANAGED_HANA = "managed-hana";
	public static final String STORAGE_TYPE_HANA = "hana";
	@JsonInclude
	private String id;
	@JsonInclude
	private String instanceName;
	@JsonInclude
	private String storageType;
	@JsonInclude
	private String storageConnectionInfo;
	@JsonInclude
	private String namespace;
	
	public static class StorageTypeNotSupportException extends GeneralNoneTranslatableException{

		
		/**
		 * 
		 */
		private static final long serialVersionUID = 3382596932041992267L;

		public StorageTypeNotSupportException(String storageType) {
			super(String.format("Storage Type '%s' not support",  storageType), null,HttpStatus.SC_BAD_REQUEST);
		}
		
	}
	
	public abstract static class StorageConnectionInfo{
		protected String databaseServiceInstanceName;
		private String plan;

		public String getDatabaseServiceInstanceName() {
			return databaseServiceInstanceName;
		}

		public void setDatabaseServiceInstanceName(String databaseServiceInstanceName) {
			this.databaseServiceInstanceName = databaseServiceInstanceName;
		}
		
		protected StorageConnectionInfo(String plan) {
			super();
			this.plan = plan;
		}

		public String getPlan() {
			return plan;
		}

		public abstract void provisionPersistence();
		
		public abstract void deprovisionPersistence();
		
		public void init() {
			DatabaseServiceInstance databaseServiceInstance = this.getStorage();
			databaseServiceInstance.init();
		}

		public void empty() {
			DatabaseServiceInstance databaseServiceInstance = this.getStorage();
			databaseServiceInstance.empty();
		}

		public void upgrade(String procedureName){
			DatabaseServiceInstance databaseServiceInstance = this.getStorage();
			databaseServiceInstance.upgrade(procedureName);

		}

		
		public DatabaseServiceInstance getStorage() {
			ServiceInstancesMapping serviceInstancesMapping = SpringContextUtils.getBean(ServiceInstancesMapping.class);
			return serviceInstancesMapping.getNormalStorage(this.getDatabaseServiceInstanceName());
		}
		
		public String toJsonString(){
			return JsonUtils.generateJsonStringFromBean(this);
		}
	}
	
	public static class HanaStorageConnectionInfoForSharedPlan extends StorageConnectionInfo{
		public HanaStorageConnectionInfoForSharedPlan(String databaseServiceInstanceName){
			super(GTTInstanceMapping.PLAN_SHARED);
			this.setDatabaseServiceInstanceName(databaseServiceInstanceName);
		}
		
		@Override
		public void provisionPersistence() {
			throw new OperationNotAllowed("HanaStorageConnectionInfoForSharedPlan.provisionPersistence");
		}
		
		
		@Override
		public void deprovisionPersistence() {
			throw new OperationNotAllowed("HanaStorageConnectionInfoForSharedPlan.deprovisionPersistence");
		}
	}
	
	public abstract static class StorageConnectionInfoForStandalonePlan extends StorageConnectionInfo{
		
		private String subaccountId;
		private String subdomain;
		private String cloneInstanceId;
		
		public String getSubaccountId() {
			return subaccountId;
		}


		public String getSubdomain() {
			return subdomain;
		}


		public String getCloneInstanceId() {
			return cloneInstanceId;
		}


		protected StorageConnectionInfoForStandalonePlan(String subaccountId, String subdomain,String cloneInstanceId) {
			super(GTTInstanceMapping.PLAN_STANDALONE);
			this.subaccountId = subaccountId;
			this.subdomain = subdomain;
			this.cloneInstanceId = cloneInstanceId;
			
			this.databaseServiceInstanceName = this.generateDatabaseServiceInstanceName();
		}

		
		
		public String generateDatabaseServiceInstanceName(){
			String result = "";
			if(StringUtils.isBlank(this.getCloneInstanceId())){
				result += this.getSubdomain() + "$" + this.getSubaccountId();
			}
			else{
				result += this.getSubdomain() + "@" + this.getCloneInstanceId();
			}
			return result;
		}
		
		
	}
	

	public static class HanaStorageConnectionInfoForStandalonePlan extends StorageConnectionInfoForStandalonePlan{
		
		
		public HanaStorageConnectionInfoForStandalonePlan(String subaccountId, String subdomain,String cloneInstanceId, String databaseId) {
			super(subaccountId, subdomain,cloneInstanceId);
			this.databaseId = databaseId;
		}
		private String databaseId;
		
		public String getDatabaseId() {
			return databaseId;
		}

		public void setDatabaseId(String databaseId) {
			this.databaseId = databaseId;
		}

		@Override
		public void provisionPersistence() {
			throw new OperationNotAllowed("HanaStorageConnectionInfoForStandalonePlan.provisionPersistence");
		}
		
		
		@Override
		public void deprovisionPersistence() {
			throw new OperationNotAllowed("HanaStorageConnectionInfoForStandalonePlan.deprovisionPersistence");
		}

		
		
	}
	
	public static class ManagedHanaStorageConnectionInfo extends HanaStorageConnectionInfoForStandalonePlan{
		public ManagedHanaStorageConnectionInfo(String subaccountId, String subdomain,String cloneInstanceId, String databaseId) {
			super( subaccountId, subdomain, cloneInstanceId, databaseId);
		}

		@Override
		public void provisionPersistence() {
			ServiceInstancesMapping serviceInstancesMapping = SpringContextUtils.getBean(ServiceInstancesMapping.class);
			// check if hana schema already exists
			ManagedHanaTenant managedHanaTenant  = serviceInstancesMapping.getManagedHanaServiceInstance().getManagedHanaTenant(this.getDatabaseServiceInstanceName());
			if(managedHanaTenant == null){
				serviceInstancesMapping.getManagedHanaServiceInstance().provision(this.getDatabaseServiceInstanceName(), this.getDatabaseId());
				this.init();
			}
			// TODO:
			// if managed hana tenant exists, we shall update database_id into the current storage connection info
			// to avoid inconsistency.
			/*
			 * "provisioning_parameters": {
        		"database_id": "8495da7f-88a1-4fc7-afbd-9544d0fb26c9"
    			}, 
			 */
		}
		
		@Override
		public void deprovisionPersistence() {
			// TODO: for the moment we do not deprevision hana schema, because even customer off-boarding
			// we shall keep their data for a period of time
			/*ServiceInstancesMapping serviceInstancesMapping = SpringContextUtils.getBean(ServiceInstancesMapping.class);
			serviceInstancesMapping.getManagedHanaServiceInstance().deprovision(this.getDatabaseServiceInstanceName());
		*/
		}
		
		@Override
		public DatabaseServiceInstance getStorage() {
			ServiceInstancesMapping serviceInstancesMapping = SpringContextUtils.getBean(ServiceInstancesMapping.class);
			return serviceInstancesMapping.getManagedHanaDatabaseServiceInstance(this.getDatabaseServiceInstanceName()); 
		}
	}
	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getInstanceName() {
		return instanceName;
	}
	public void setInstanceName(String instanceName) {
		this.instanceName = instanceName;
	}
	public String getStorageType() {
		return storageType;
	}
	public void setStorageType(String storageType) {
		this.storageType = storageType;
	}
	public String getStorageConnectionInfo() {
		return storageConnectionInfo;
	}
	public void setStorageConnectionInfo(String storageConnectionInfo) {
		this.storageConnectionInfo = storageConnectionInfo;
	}
	
	protected StorageConnectionInfo buildStorageConnectionInfoForStandalonePlan(String subaccountId, String subdomain, String cloneInstanceId, String physicalId){
		if(StringUtils.equals(this.getStorageType(), STORAGE_TYPE_MANAGED_HANA)){
			return new ManagedHanaStorageConnectionInfo(subaccountId, subdomain, cloneInstanceId ,physicalId);
		}
		else if(StringUtils.equals(this.getStorageType(), STORAGE_TYPE_HANA)){
			return new HanaStorageConnectionInfoForStandalonePlan(subaccountId, subdomain, cloneInstanceId ,physicalId);
		}
		else{
			throw new StorageTypeNotSupportException(this.getStorageType());
		}
	}
	
	public void fillStorageConnectionInfoForStandalonePlan(String subaccountId, String subdomain, String cloneInstanceId, String physicalId){
		StorageConnectionInfo connectionInfo = this.buildStorageConnectionInfoForStandalonePlan(subaccountId, subdomain, cloneInstanceId, physicalId);
		this.setStorageConnectionInfo(connectionInfo.toJsonString());
	}
	
	protected StorageConnectionInfo buildStorageConnectionInfoForSharedPlan(String databaseServiceInstanceName){
		if(StringUtils.equals(this.getStorageType(), STORAGE_TYPE_HANA)){
			return new HanaStorageConnectionInfoForSharedPlan(databaseServiceInstanceName);
		}
		else{
			throw new StorageTypeNotSupportException(this.getStorageType());
		}
	}
	
	public void fillStorageConnectionInfoForSharedPlan(String databaseServiceInstanceName){
		StorageConnectionInfo connectionInfo = this.buildStorageConnectionInfoForSharedPlan(databaseServiceInstanceName);
		this.setStorageConnectionInfo(connectionInfo.toJsonString());
	}
	
	protected StorageConnectionInfo parseStorageConnectionInfoForStandalonePlan(){
		if(StringUtils.equals(this.getStorageType(), STORAGE_TYPE_HANA)){
			return JsonUtils.generateBeanFromJson(this.getStorageConnectionInfo(), HanaStorageConnectionInfoForStandalonePlan.class);
		}
		else if(StringUtils.equals(this.getStorageType(), STORAGE_TYPE_MANAGED_HANA)){
			return JsonUtils.generateBeanFromJson(this.getStorageConnectionInfo(), ManagedHanaStorageConnectionInfo.class);
		}
		else{
			throw new StorageTypeNotSupportException(this.getStorageType());
		}
	}
	
	protected StorageConnectionInfo parseStorageConnectionInfoForSharedPlan(){
		if(StringUtils.equals(this.getStorageType(), STORAGE_TYPE_HANA)){
			return JsonUtils.generateBeanFromJson(this.getStorageConnectionInfo(), HanaStorageConnectionInfoForSharedPlan.class);
		}
		else{
			throw new StorageTypeNotSupportException(this.getStorageType());
		}
	}
	
	public StorageConnectionInfo parseStorageConnectionInfo(){
		JsonObject jsonObject = JsonUtils.generateJsonObjectFromJsonString(this.getStorageConnectionInfo());
		String plan = JsonUtils.getValueAsString(jsonObject, "plan");
		if(StringUtils.equals(plan, GTTInstanceMapping.PLAN_SHARED)){
			return this.parseStorageConnectionInfoForSharedPlan();
		}
		else{
			return this.parseStorageConnectionInfoForStandalonePlan();
		}
	}
	
	
	public String getNamespace() {
		return namespace;
	}
	public void setNamespace(String namespace) {
		this.namespace = namespace;
	}
	@Override
	public String toString() {
		return "GTTInstance [id=" + id + ", instanceName=" + instanceName + ", storageType=" + storageType
				+ ", storageConnectionInfo=" + storageConnectionInfo + ", namespace=" + namespace + "]";
	}
	
	
}
