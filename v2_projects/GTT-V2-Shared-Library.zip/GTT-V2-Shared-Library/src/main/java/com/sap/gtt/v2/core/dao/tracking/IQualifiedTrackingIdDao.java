package com.sap.gtt.v2.core.dao.tracking;

import com.sap.gtt.v2.core.domain.metadata.CurrentMetadataEntity;
import com.sap.gtt.v2.core.entity.trackedprocess.QualifiedTrackingId;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public interface IQualifiedTrackingIdDao {

	void insert(QualifiedTrackingId qualifiedTrackingId);

	void insert(List<QualifiedTrackingId> qualifiedTrackingIds);

	void update(QualifiedTrackingId qualifiedTrackingId);

	boolean exists(QualifiedTrackingId qualifiedTrackingId);

	void delete(CurrentMetadataEntity metadata, UUID processId, UUID observedProcessId);

	void delete(QualifiedTrackingId qualifiedTrackingId);

	List<QualifiedTrackingId> findAll(CurrentMetadataEntity metadata, UUID observedProcessId, Instant actualBusinessTime);

	List<QualifiedTrackingId> findAll(UUID observedProcessId, Instant actualBusinessTime);

	void deleteByProcessId(CurrentMetadataEntity metadata, UUID processId);

	void deleteByProcessId(UUID processId);

	List<UUID> getCorrelatedProcessId(CurrentMetadataEntity metadata, UUID internalValue, Instant actualBizTs);

	List<UUID> getCorrelatedProcessId(UUID internalValue, Instant actualBizTs, int eventCorrelationLevel);

	Map<UUID, String> getCorrelatedProcessMap(UUID internalValue, Instant actualBizTs, int eventCorrelationLevel);
}
