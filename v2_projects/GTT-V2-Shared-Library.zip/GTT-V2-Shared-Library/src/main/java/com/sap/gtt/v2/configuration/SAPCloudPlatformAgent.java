package com.sap.gtt.v2.configuration;

import com.sap.gtt.v2.bp.BusinessPartner;
import com.sap.gtt.v2.bp.BusinessPartnerService;
import com.sap.gtt.v2.configuration.AccessContextHolder.AccessContext;
import com.sap.gtt.v2.configuration.EnvironmentsConfiguration.VcapServiceParser.DatabaseServiceInstance;
import com.sap.gtt.v2.configuration.EnvironmentsConfiguration.VcapServiceParser.UaaServiceInstance;
import com.sap.gtt.v2.exception.InternalErrorException;
import com.sap.gtt.v2.servicemanager.GTTInstance;
import com.sap.gtt.v2.tenant.TenantService;
import com.sap.gtt.v2.util.SpringContextUtils;
import com.sap.xs2.security.container.SecurityContext;
import com.sap.xs2.security.container.UserInfo;
import com.sap.xs2.security.container.UserInfoException;
import com.sap.xsa.security.container.XSUserInfo;
import com.sap.xsa.security.container.XSUserInfoException;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.authentication.AuthenticationCredentialsNotFoundException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;


@Component
public class SAPCloudPlatformAgent implements ISAPCloudPlatformAgent {
    private static final Logger logger = LoggerFactory.getLogger(SAPCloudPlatformAgent.class);

    @Component(ICurrentAccessContext.BEAN_NAME)
    @Profile("cloud")
    public static class CurrentAccessContext implements ICurrentAccessContext {

        @Autowired
        private ServiceInstancesMapping serviceInstancesMapping;
        @Autowired
        private TenantService tenantService;
        @Autowired
        private BusinessPartnerService bpService;

        @Override
        public AccessContextHolder.AccessContext cloneContext() {
            return new AccessContextHolder.AccessContext(
                    this.getSubaccountId(), this.getLogonName(), this.getSubdomain(), this.getCloneServiceInstanceId(),
                    ICurrentAccessContext.getLocale(),
                    this.getInstance(),
                    this.isUserToken(),
                    this.isIntegrationUserToken(),
                    this.isProductive(),
                    this.isSolutionOwner()
            );
        }

        protected XSUserInfo getCurrentUserInfo() {
            try {
                return SecurityContext.getUserInfo();
            } catch (UserInfoException e) {
                // usually - user not authenticated
                throw new AuthenticationCredentialsNotFoundException(e.getMessage(), e);
            }
        }

        @Override
        public String getSubaccountId() {
            AccessContext accessContext = AccessContextHolder.get();
            if (accessContext != null) {
                return accessContext.getSubaccountId();
            }
            try {

                return this.getCurrentUserInfo().getSubaccountId();
            } catch (XSUserInfoException e) {
                throw new InternalErrorException(e.getMessage(), e);
            }
        }

        @Override
        public BusinessPartner getBusinessPartner() {
            if (isUserToken() && isIntegrationUserToken()) { // technique user, get BP from integration user
                return bpService.getBPByIntegrationUser(this.getLogonName());
            } else {
                return bpService.getBPByTenantId(this.getSubaccountId());
            }

        }

        @Override
        public String getLogonName() {
            AccessContext accessContext = AccessContextHolder.get();
            if (accessContext != null) {
                return accessContext.getLogonName();
            }

            try {
                XSUserInfo userInfo = this.getCurrentUserInfo();
                if (StringUtils.equals(userInfo.getGrantType(), UserInfo.GRANTTYPE_CLIENTCREDENTIAL)) {
                    return null;
                } else {
                    return userInfo.getLogonName();
                }
            } catch (XSUserInfoException e) {
                throw new InternalErrorException(e.getMessage(), e);
            }
        }

        @Override
        public String getSubdomain() {
            AccessContext accessContext = AccessContextHolder.get();
            if (accessContext != null) {
                return accessContext.getSubdomain();
            }

            try {
                return this.getCurrentUserInfo().getSubdomain();
            } catch (XSUserInfoException e) {
                throw new InternalErrorException(e.getMessage(), e);
            }
        }

        protected String getCloneServiceInstanceIdInternal() {
            AccessContext accessContext = AccessContextHolder.get();
            if (accessContext != null) {
                return accessContext.getCloneServiceInstanceId();
            }

            try {
                XSUserInfo userInfo = this.getCurrentUserInfo();
                String cloneServiceInstanceId = userInfo.getCloneServiceInstanceId();

                //check special case:
                String clientId = userInfo.getClientId();
                // Client Id NOT applicable, only end with gtt xsappname for example "lbn_gtt_core_acc!b6660"
                UaaServiceInstance uaaServiceInstance = SpringContextUtils.getBean(ServiceInstancesMapping.class).getUaaServiceInstance();
                if (!StringUtils.endsWith(clientId, uaaServiceInstance.getXsappname())) {
                    // NOT a JWT token generated from GTT, for example, PDM callback will generate JWT from PDM service instance
                    // in such case, treat the JWT as lbn-gtt standalone app token
                    logger.warn("The client Id {} of clone Instance which generating the current JWT is NOT a GTT Clone Instance "
                            + " generated from {}, ignoring the clone instance id {} and switching into standalone mode", clientId, uaaServiceInstance.getXsappname(), cloneServiceInstanceId);
                    cloneServiceInstanceId = null;
                }

                return cloneServiceInstanceId;

            } catch (XSUserInfoException e) {
                // service instance id not found
                logger.debug(e.getMessage(), e);
                return null;
            }
        }

        @Override
        public String getCloneServiceInstanceId() {
            return getCloneServiceInstanceIdInternal();

        }

        @Override
        public boolean containsCloneServiceInstanceId() {
            return !StringUtils.isBlank(getCloneServiceInstanceIdInternal());
        }

        @Override
        public DatabaseServiceInstance getDatabaseServiceInstance() {
            AccessContext accessContext = AccessContextHolder.get();
            GTTInstance gttInstance = null;
            if (accessContext != null) {
                gttInstance = accessContext.getInstance();
            }

            if (gttInstance == null) {
                if (this.containsCloneServiceInstanceId()) {
                    return serviceInstancesMapping.getDatabaseServiceInstance(this.getSubaccountId(), this.getCloneServiceInstanceId());
                } else {
                    return serviceInstancesMapping.getDatabaseServiceInstance(this.getSubaccountId(), StringUtils.EMPTY);

                }

            } else {
                return serviceInstancesMapping.getDatabaseServiceInstance(gttInstance);
            }


        }

        @Override
        public boolean isAuthenticated() {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            if (authentication == null) {
                return false;
            } else {
                if (authentication instanceof AnonymousAuthenticationToken) {
                    // AnonymousAuthenticationToken in spring always set authenticated = true
                    // in our context, AnonymousAuthenticationToken means authenticated = false
                    return false;
                } else {
                    return authentication.isAuthenticated();
                }

            }
        }

        @Override
        public boolean isUserToken() {
            // better
            AccessContext accessContext = AccessContextHolder.get();
            if (accessContext != null) {
                return accessContext.isUserToken();
            }
            return StringUtils.equals(getGrantType(), "password");
        }

        protected String getGrantType() {
            try {
                return this.getCurrentUserInfo().getGrantType();
            } catch (XSUserInfoException e) {
                throw new InternalErrorException(e);
            }
        }

        @Override
        public String getJWT() {
            AccessContext accessContext = AccessContextHolder.get();
            if (accessContext != null) {
                return null;
            }

            return this.getCurrentUserInfo().getAppToken();

        }

        @Override
        public GTTInstance getInstance() {
            AccessContext accessContext = AccessContextHolder.get();
            if (accessContext != null) {
                return accessContext.getInstance();
            }
            String subaccountId = this.getSubaccountId();
            String cloneInstanceId = null;
            if (this.containsCloneServiceInstanceId()) {
                cloneInstanceId = this.getCloneServiceInstanceId();
            }
            return tenantService.getGTTInstance(subaccountId, cloneInstanceId);
        }

        @Override
        public boolean isIntegrationUserToken() {
            AccessContext accessContext = AccessContextHolder.get();
            if (accessContext != null) {
                return accessContext.isIntegrationUserToken();
            }
            if (!isUserToken()) {
                return false;
            }
            try {
                XSUserInfo userInfo = this.getCurrentUserInfo();
                if (!userInfo.hasAttributes()) {
                    return false;
                }
                String[] isIntUserAttrValues = userInfo.getAttribute(TOKEN_ATTRIBUTE_NAME_IS_INT_USER);
                if (ArrayUtils.isEmpty(isIntUserAttrValues)) {
                    return false;
                }
                return Boolean.parseBoolean(isIntUserAttrValues[0]);
            } catch (XSUserInfoException e) {
                logger.debug(e.getMessage(), e);
                return false;
            }
        }

        @Override
        public boolean isProductive() {
            AccessContext accessContext = AccessContextHolder.get();
            if (accessContext != null) {
                return accessContext.isProductive();
            }

            if (!isStandalonePlan()) {
                return true; //share plan, always productive
            }
            // standalone plan
            BusinessPartner bpForCurrentTenant = bpService.getBPByTenantId(this.getSubaccountId());
            return bpForCurrentTenant.isGTTStandaloneProductive();
        }

        @Override
        public boolean isSolutionOwner() {
            if (!isStandalonePlan()) {
                return false; //share plan, no solution owner
            }

            // standalone  plan
            BusinessPartner bpForCurrentTenant = bpService.getBPByTenantId(this.getSubaccountId());
            // check if bpForCurrentTenant subscribed for GTT App
            if (!bpForCurrentTenant.subscribedGTTStandalone()) {
                return false;
            }
            return StringUtils.equals(bpForCurrentTenant.getId(), this.getBusinessPartner().getId());
        }

        @Override
        public boolean isStandalonePlan() {
            return !this.containsCloneServiceInstanceId();// has clone instance, means share plan
        }


    }


    @Value("${VCAP_SERVICES:#{null}}")
    private String envVcapService;

    @Value("${SAAS_SUBSCRIPTION_API_HOST:#{null}}")
    private String envSaasSubscriptionAPIHost;

    @Override
    public Map<String, String> getenv() {

        Map<String, String> result = new HashMap<>();
        result.putAll(System.getenv());

        // search for user provided properties
        if (!StringUtils.isBlank(envVcapService)) {
            result.put(ENV_VARIABLE_NAME_VCAP_SERVICES, envVcapService);
        }

        if (!StringUtils.isBlank(envSaasSubscriptionAPIHost)) {
            result.put(ENV_VARIABLE_NAME_SAAS_SUBSCRIPTION_API_HOST, envSaasSubscriptionAPIHost);
        }

        return result;
    }

}
