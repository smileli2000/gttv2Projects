package com.sap.gtt.v2.core.dao.tracking;

public interface ICoreModelDataProcessDao {
    void deleteAllCoreModelData(String namespace);
}
