package com.sap.gtt.v2.core.domain.trackedprocess;

import com.sap.gtt.v2.core.entity.trackedprocess.PlannedEvent;
import com.sap.gtt.v2.core.runtime.model.IPropertyValue;
import com.sap.gtt.v2.core.runtime.model.ObjectValue;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MatchedCorrelatedEvent extends ObjectValue {
    public static final String PLANNED_EVENT = "plannedEvent";
    public static final String ACTUAL_EVENTS = "actualEvents";

    public void setPlannedEvent(PlannedEvent plannedEvent) {
        this.setValue(PLANNED_EVENT, plannedEvent);
    }

    public PlannedEvent getPlannedEvent() {
        return (PlannedEvent)this.getValue(PLANNED_EVENT);
    }

    public void setActualEvents(List<CorrelatedEventInner> actualEvents) {
        List<IPropertyValue> list = new ArrayList<>();
        for(CorrelatedEventInner event : actualEvents) {
            list.add(event);
        }
        this.setValue(ACTUAL_EVENTS, list);
    }

    public List<CorrelatedEventInner> getActualEvents() {
        List<IPropertyValue> list = getValueAsList(ACTUAL_EVENTS);
        if (!CollectionUtils.isEmpty(list)) {
            List<CorrelatedEventInner> actualEvents = new ArrayList<>(list.size());
            for (IPropertyValue value : list) {
                CorrelatedEventInner event = (CorrelatedEventInner)value;
                actualEvents.add(event);
            }
            return actualEvents;
        }
        return Collections.emptyList();
    }

}
