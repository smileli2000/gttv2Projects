package com.sap.gtt.v2.core.domain.metadata;

import java.util.Map;
import java.util.StringJoiner;

/**
 * @author I321712
 */
public class CurrentMetadataEntity {
    private String namespace;
    private String currentEntityName;
    private Map<String, MetadataEntity> allRelatedEntityMap;
    private MetadataEntity currentEntity;
    private boolean enableInstanceBasedAuthorization;
    private int eventCorrelationLevel;


    public String getNamespace() {
        return namespace;
    }

    public void setNamespace(String namespace) {
        this.namespace = namespace;
    }

    public String getCurrentEntityName() {
        return currentEntityName;
    }

    public void setCurrentEntityName(String currentEntityName) {
        this.currentEntityName = currentEntityName;
    }

    public Map<String, MetadataEntity> getAllRelatedEntityMap() {
        return allRelatedEntityMap;
    }

    public void setAllRelatedEntityMap(Map<String, MetadataEntity> allRelatedEntityMap) {
        this.allRelatedEntityMap = allRelatedEntityMap;
    }

    public MetadataEntity getCurrentEntity() {
        if (currentEntity == null && allRelatedEntityMap != null && allRelatedEntityMap.size() > 0) {
            currentEntity = allRelatedEntityMap.get(getCurrentEntityName());
        }
        return currentEntity;
    }

    public boolean isEnableInstanceBasedAuthorization() {
        return enableInstanceBasedAuthorization;
    }

    public void setEnableInstanceBasedAuthorization(boolean enableInstanceBasedAuthorization) {
        this.enableInstanceBasedAuthorization = enableInstanceBasedAuthorization;
    }

    public int getEventCorrelationLevel() {
        return eventCorrelationLevel;
    }

    public void setEventCorrelationLevel(int eventCorrelationLevel) {
        this.eventCorrelationLevel = eventCorrelationLevel;
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", CurrentMetadataEntity.class.getSimpleName() + "[", "]")
                .add("currentEntityName='" + currentEntityName + "'")
                .toString();
    }
}