package com.sap.gtt.v2.core.management.metering;

import java.time.Instant;

/**
 * @author I301346
 */
public interface IMeteringManagement {
    /**
     * get the last metering time
     * @param jobName
     * @return the last metering time
     */
    Instant getPreviousMeteringTime(String jobName);

    /**
     * count event through CreationDateTime
     * @param from
     * @param to
     * @return new created events' number
     */
    int countEvent(Instant from, Instant to);

    /**
     * count TP through CreationDateTime
     * @param from
     * @param to
     * @return new created TPs' number
     */
    int countTP(Instant from, Instant to);

    /**
     * update job run time with current time
     * @param jobName
     * @param jobRunTime
     */
    void updateMeteringJobInfo(String jobName, Instant jobRunTime);
}
