package com.sap.gtt.v2.core.runtime.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.sap.gtt.v2.core.runtime.model.IPropertyValue.FunctionInterfaceDef.Category;
import com.sap.gtt.v2.exception.OperationNotAllowed;

public final class ListValue extends AbstractPropertyValue<List<IPropertyValue>> {

	public static final String ERROR_INDEX_OUT_OF_RANGE= "Index '%s' in out of range [0,'%s')";
	
	protected ListValue(List<IPropertyValue> internalValue) {
		super(internalValue);
	}

	private static final String FUNCTION_SIZE = "size";
	private static final String FUNCTION_PUSH = "push";
	protected static final Map<String, FunctionInterfaceDef> functionDefs = new HashMap<>();
	
	static{
		functionDefs.putAll(AbstractPropertyValue.functionDefs);
		
		FunctionInterfaceDef sizeDef = new FunctionInterfaceDef(Category.SYSTEM, FUNCTION_SIZE, new ArrayList<>(),
				(callerObject, arg) -> {
					ListValue caller = (ListValue) callerObject;
					return IntegerValue.valueOf(caller.size());
				}
		);
		functionDefs.put(sizeDef.name, sizeDef);

		List<Class<? extends IPropertyValue>> pushArgumentTypes = new ArrayList<>();
		pushArgumentTypes.add(IPropertyValue.class);
		FunctionInterfaceDef pushDef = new FunctionInterfaceDef(Category.SYSTEM, FUNCTION_PUSH,	pushArgumentTypes,
				(callerObject, arg) -> {
					ListValue caller = (ListValue) callerObject;
					return BooleanValue.valueOf(caller.add(arg.get(0)));
				}
		);
		functionDefs.put(pushDef.name, pushDef);
		
		
	}

	@Override
	public String toString(){
		List<IPropertyValue> list = this.getInternalValue();
		String str = "[";
		for(int i=0; i<list.size(); i++){
			if(i==list.size()-1){
				if(list.get(i).getInternalValue() instanceof String){
					str+="\""+list.get(i)+"\"";
				}else {
					str+=list.get(i);
				}
			}else {
				if(list.get(i).getInternalValue() instanceof String){
					str+="\""+list.get(i)+"\",";
				}else {
					str+=list.get(i)+",";
				}
			}
		}
		return str+"]";
	}

	@Override
	public boolean isCsnPrimitive() {
		return false;
	}

	@Override
	public boolean isCollection() {
		return true;
	}

	
	public IPropertyValue get(int index) {
		return this.getInternalValue().get(index);
	}

	public int size(){
		return this.getInternalValue().size();
	}
	
	public IPropertyValue set(int index, IPropertyValue value){
		if(index < 0 && index >= this.size()){
			throw new OperationNotAllowed(String.format(ERROR_INDEX_OUT_OF_RANGE, index, this.size()));
		}
		return this.getInternalValue().set(index, value);
		
	}
	
	public boolean add(IPropertyValue value){
		return this.getInternalValue().add(value);
	}
	//system method exposed
	@Override
	protected Map<String, FunctionInterfaceDef> getFunctionDefs(){
		return functionDefs;
	}

	public static ListValue valueOf(List<IPropertyValue> value){
		return new ListValue(value);
	}
	
	public static ListValue valueOfEmpty(){
		return valueOf(new ArrayList<>());
	}

	
}
