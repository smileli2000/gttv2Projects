package com.sap.gtt.v2.configuration;

import com.sap.gtt.v2.configuration.IThreadPoolTaskExecutor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.ThreadPoolExecutor;

/**
 * @author i311486
 */
@Configuration
@EnableAsync
@Lazy
public class GTTEmbededRuleScriptExecutorConfiguration implements IThreadPoolTaskExecutor {
    @Value("${event2action.executor.thread.core-pool-size}")
    private int corePoolSize;
    @Value("${event2action.executor.thread.max-pool-size}")
    private int maxPoolSize;
    @Value("${event2action.executor.thread.queue-capacity}")
    private int queueCapacity;
    @Value("${event2action.executor.thread.prefix}")
    private String namePrefix;

    @Override
    @Bean(name = "Event2ActionExecutor")
    public ThreadPoolTaskExecutor initTaskExecutor(){
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(corePoolSize);
        executor.setMaxPoolSize(maxPoolSize);
        executor.setQueueCapacity(queueCapacity);
        executor.setThreadNamePrefix(namePrefix);
        executor.setRejectedExecutionHandler(new ThreadPoolExecutor.CallerRunsPolicy());
        executor.initialize();
        return executor;
    }
}
