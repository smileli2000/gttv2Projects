package com.sap.gtt.v2.exception;

public class GTTEmbededRuleScriptInternalException extends InternalErrorException {

    private int line;
    private int charPositionInLine;
    private String errorReason;


    public GTTEmbededRuleScriptInternalException(int line, int charPositionInLine, String errorReason, Throwable cause) {
        super(null, cause);
        this.line = line;
        this.charPositionInLine = charPositionInLine;
        this.errorReason = errorReason;
    }


    public int getLine() {
        return line;
    }


    public int getCharPositionInLine() {
        return charPositionInLine;
    }


    public String getErrorReason() {
        return errorReason;
    }

    @Override
    public String getMessage() {
        return ("line " + this.getLine() + ":" + this.getCharPositionInLine() + " " + this.getErrorReason());
    }
}
