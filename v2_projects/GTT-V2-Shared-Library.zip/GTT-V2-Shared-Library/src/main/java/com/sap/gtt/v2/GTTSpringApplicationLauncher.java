package com.sap.gtt.v2;


public class GTTSpringApplicationLauncher {
	
	private GTTSpringApplicationLauncher(){
		
	}
	
	public static void run(GTTBaseSpringApplication application, String[] args){
		application.run(args);
	}
}
