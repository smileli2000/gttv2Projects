package com.sap.gtt.v2.core.entity.execution;

/**
 * @author I302310
 */
public class ExecutionUnit {
    private String id;
    private String requestId;
    private String eventId;
    private String eventType;
    private String altkey;
    private String locationAltkey;
    private String correlatedTpId;
    private String correlatedTpAltkey;
    private int executionCount;
    private String lastExecutionId;
    private boolean isProcessEvent;

    public ExecutionUnit() {
    }

    public ExecutionUnit(String id, String requestId, String eventId, String eventType, String altkey, String locationAltkey,
                         String correlatedTpId, String correlatedTpAltkey, int executionCount, String lastExecutionId,
                         boolean isProcessEvent) {
        this.id = id;
        this.requestId = requestId;
        this.eventId = eventId;
        this.eventType = eventType;
        this.altkey = altkey;
        this.locationAltkey = locationAltkey;
        this.correlatedTpId = correlatedTpId;
        this.correlatedTpAltkey = correlatedTpAltkey;
        this.executionCount = executionCount;
        this.lastExecutionId = lastExecutionId;
        this.isProcessEvent = isProcessEvent;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public String getEventId() {
        return eventId;
    }

    public void setEventId(String eventId) {
        this.eventId = eventId;
    }

    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    public String getAltkey() {
        return altkey;
    }

    public void setAltkey(String altkey) {
        this.altkey = altkey;
    }

    public String getLocationAltkey() {
        return locationAltkey;
    }

    public void setLocationAltkey(String locationAltkey) {
        this.locationAltkey = locationAltkey;
    }

    public String getCorrelatedTpId() {
        return correlatedTpId;
    }

    public void setCorrelatedTpId(String correlatedTpId) {
        this.correlatedTpId = correlatedTpId;
    }

    public String getCorrelatedTpAltkey() {
        return correlatedTpAltkey;
    }

    public void setCorrelatedTpAltkey(String correlatedTpAltkey) {
        this.correlatedTpAltkey = correlatedTpAltkey;
    }

    public int getExecutionCount() {
        return executionCount;
    }

    public void setExecutionCount(int executionCount) {
        this.executionCount = executionCount;
    }

    public String getLastExecutionId() {
        return lastExecutionId;
    }

    public void setLastExecutionId(String lastExecutionId) {
        this.lastExecutionId = lastExecutionId;
    }

    public boolean isProcessEvent() {
        return isProcessEvent;
    }

    public void setProcessEvent(boolean processEvent) {
        isProcessEvent = processEvent;
    }
}
