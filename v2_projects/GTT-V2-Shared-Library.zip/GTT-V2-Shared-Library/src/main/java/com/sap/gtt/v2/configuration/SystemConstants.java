package com.sap.gtt.v2.configuration;

import java.util.Locale;

import com.sap.gtt.v2.configuration.CacheConfiguration.CacheControl;

public final class SystemConstants {

	private SystemConstants(){
		
	}
	
	public static final String SERVICE_MANAGER_ROOT_URL = "/sap/logistics/gtt/service-manager/v1";
	
	public static final Locale DEFAULT_LOCALE = Locale.ENGLISH;
	
	public static final String SPRING_BEAN_SPEL_CONDITION_ON_IS_CACHE_ENABLED = "@" + CacheControl.BEAN_NAME+".isCacheEnabled()";
	
}
