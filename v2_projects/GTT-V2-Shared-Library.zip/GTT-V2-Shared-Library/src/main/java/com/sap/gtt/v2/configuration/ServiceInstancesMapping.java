package com.sap.gtt.v2.configuration;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


import com.sap.gtt.v2.configuration.EnvironmentsConfiguration.VcapServiceParser;
import com.sap.gtt.v2.configuration.EnvironmentsConfiguration.VcapServiceParser.BpServiceInstance;
import com.sap.gtt.v2.configuration.EnvironmentsConfiguration.VcapServiceParser.LocationServiceInstance;
import com.sap.gtt.v2.configuration.EnvironmentsConfiguration.VcapServiceParser.DatabaseServiceInstance;
import com.sap.gtt.v2.configuration.EnvironmentsConfiguration.VcapServiceParser.DestinationServiceInstance;
import com.sap.gtt.v2.configuration.EnvironmentsConfiguration.VcapServiceParser.JdbcEnabledDatabaseServiceInstance;
import com.sap.gtt.v2.configuration.EnvironmentsConfiguration.VcapServiceParser.ManagedHanaServiceInstance;
import com.sap.gtt.v2.configuration.EnvironmentsConfiguration.VcapServiceParser.PortalServiceInstance;
import com.sap.gtt.v2.configuration.EnvironmentsConfiguration.VcapServiceParser.ReminderServiceInstance;
import com.sap.gtt.v2.configuration.EnvironmentsConfiguration.VcapServiceParser.SaasRegistryServiceInstance;
import com.sap.gtt.v2.configuration.EnvironmentsConfiguration.VcapServiceParser.SaasSubscriptionServiceInstance;
import com.sap.gtt.v2.configuration.EnvironmentsConfiguration.VcapServiceParser.UaaServiceInstance;
import com.sap.gtt.v2.exception.InternalErrorException;
import com.sap.gtt.v2.servicemanager.GTTInstance;
import com.sap.gtt.v2.tenant.TenantService;

@Component
public class ServiceInstancesMapping implements InitializingBean{
	private static Logger logger = LoggerFactory.getLogger(ServiceInstancesMapping.class);
	
	
	private static final String MULTIPLE_DESTINATION_SERVICE_BOUND = "Multiple destination service bound";
	private static final String NO_DESTINATION_SERVICE_BOUND = "No destination service bound";

    private static final String MULTIPLE_SAAS_REGISTRY_SERVICE_BOUND = "Multiple saas registry service bound for plan '%s'";
	private static final String NO_SAAS_REGISTRY_SERVICE_BOUND = "No saas registry service bound for plan '%s'";
    
    private static final String MULTIPLE_SAAS_SUBSCRIPTION_SERVICE_BOUND = "Multiple saas subscription service bound";
	private static final String NO_SAAS_SUBSCRIPTION_SERVICE_BOUND = "No saas subscription service bound";
	
	private static final String NO_UAA_SERVICE_BOUND = "No uaa service bound";
	private static final String MULTIPLE_UAA_SERVICE_BOUND = "Multiple uaa service bound";
	private static final String UAA_SERVICE_IS_NOT_BROKER_PLAN = "Uaa service is not broker plan";
	
	private static final String MULTIPLE_PORTAL_SERVICE_BOUND = "Multiple portal service bound";
	private static final String NO_PORTAL_SERVICE_BOUND = "No portal service bound";
	
	private static final String NO_MANAGED_HANA_SERVICE_BOUND = "No managed-hana service bound";
	private static final String MULTIPLE_MANAGED_HANA_SERVICE_BOUND = "Multiple managed-hana service bound";
	
	private static final String NO_BP_SERVICE_BOUND = "No LBN Business Partner service bound";
	private static final String MULTIPLE_BP_SERVICE_BOUND = "Multiple LBN Business Partner service bound";

	private static final String NO_LOCATION_SERVICE_BOUND = "No LBN Location service bound";
	private static final String MULTIPLE_LOCATION_SERVICE_BOUND = "Multiple LBN Location service bound";

	private static final String NO_REMINDER_SERVICE_BOUND = "No reminder service bound";
	private static final String MULTIPLE_REMINDER_SERVICE_BOUND = "Multiple reminder service service bound";
	
	
  
	
	@Autowired
	private VcapServiceParser vcapServiceParser;
	@Autowired
	private TenantService tenantService;
	
	private DatabaseServiceInstance serviceManagerDBServiceInstance = null;
	
	
	private final Map<String, DatabaseServiceInstance> storageServiceInstanceMap = new HashMap<>();
	
	private final Map<String, JdbcEnabledDatabaseServiceInstance> secureStoreServiceInstanceMap = new HashMap<>();
	
	private final Map<String, DestinationServiceInstance> destinationServiceInstanceMap = new HashMap<>();
	
	private final Map<String, UaaServiceInstance> uaaServiceInstanceMap = new HashMap<>();

	private final Map<String, PortalServiceInstance> portalServiceInstanceMap = new HashMap<>();

	private final Map<String, SaasRegistryServiceInstance> saasRegistryServiceInstanceMap = new HashMap<>();
    
	private final Map<String, SaasSubscriptionServiceInstance> saasSubscriptionServiceInstanceMap = new HashMap<>();
	
	private final Map<String, ManagedHanaServiceInstance> managedHanaServiceInstanceMap = new HashMap<>();
	
	private final Map<String, BpServiceInstance> bpServiceInstanceMap = new HashMap<>();

	private final Map<String, LocationServiceInstance> locationServiceInstanceMap = new HashMap<>();

	private final Map<String, ReminderServiceInstance> reminderServiceInstanceMap = new HashMap<>();
	
	
	public Map<String, PortalServiceInstance> getPortalServiceInstanceMap() {
		return portalServiceInstanceMap;
	}

	public Map<String, BpServiceInstance> getBpServiceInstanceMap() {
		return bpServiceInstanceMap;
	}

	public Map<String, LocationServiceInstance> getLocationServiceInstanceMap(){
		return locationServiceInstanceMap;
	}

	public Map<String, ManagedHanaServiceInstance> getManagedHanaServiceInstanceMap() {
		return managedHanaServiceInstanceMap;
	}

	public DatabaseServiceInstance getNormalStorage(String instanceName){
		return storageServiceInstanceMap.get(instanceName);
	}
	
	public Map<String, DatabaseServiceInstance> getStorageServiceInstanceMap() {
		return storageServiceInstanceMap;
	}

	public Map<String, DestinationServiceInstance> getDestinationServiceInstanceMap() {
		return destinationServiceInstanceMap;
	}

	public Map<String, UaaServiceInstance> getUaaServiceInstanceMap() {
		return uaaServiceInstanceMap;
	}


	public JdbcEnabledDatabaseServiceInstance getSecureStorage(String instanceName){
		return secureStoreServiceInstanceMap.get(instanceName);
	}


    public Map<String, SaasRegistryServiceInstance> getSaasRegistryServiceInstanceMap() {
        return saasRegistryServiceInstanceMap;
    }

    public Map<String, SaasSubscriptionServiceInstance> getSaasSubscriptionServiceInstanceMap() {
        return saasSubscriptionServiceInstanceMap;
    }
	

	public Map<String, JdbcEnabledDatabaseServiceInstance> getSecureStoreServiceInstanceMap() {
		return secureStoreServiceInstanceMap;
	}
	
	public Map<String, ReminderServiceInstance> getReminderServiceInstanceMap() {
		return reminderServiceInstanceMap;
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		List<DatabaseServiceInstance> databaseServiceInstances = new ArrayList<>();
		// Hana with schema plan
		databaseServiceInstances.addAll(vcapServiceParser.getHanaSchemaHDIContainerSchemaPlanServiceInstances());
		// H2
		databaseServiceInstances.addAll(vcapServiceParser.getH2SchemaServiceInstance());
		// Other DB
		
		// Hana with securestore plan
		List<JdbcEnabledDatabaseServiceInstance> secureStoreServiceInstances = new ArrayList<>();
		secureStoreServiceInstances.addAll(vcapServiceParser.getHanaSchemaHDIContainerSecurestorePlanServiceInstances());
		
		logger.info("Starting to bind Storage Sources...");
		for(DatabaseServiceInstance databaseServiceInstance : databaseServiceInstances){
			logger.info(databaseServiceInstance.getInstanceName());
			// distinguish if serviceManagerDBServiceInstance or not
			if(StringUtils.equals(EnvironmentsConfiguration.SERVICE_MANAGER_DB_INSTANCE_NAME, databaseServiceInstance.getInstanceName())){
				// Service Manager DB
				serviceManagerDBServiceInstance = databaseServiceInstance;
			}
			else{
				// normal storage
				storageServiceInstanceMap.put(databaseServiceInstance.getInstanceName(), databaseServiceInstance);
			}
			
		}
		logger.info("Ending to bind Storage Sources...");
		
		logger.info("Starting to bind secure store service instance...");
		for(JdbcEnabledDatabaseServiceInstance databaseServiceInstance : secureStoreServiceInstances){
			logger.info(databaseServiceInstance.getInstanceName());
			secureStoreServiceInstanceMap.put(databaseServiceInstance.getInstanceName(), databaseServiceInstance);
		}
		logger.info("Ending to bind store service instance...");
		
		// Destination Service
		List<DestinationServiceInstance> destinationServiceInstances = new ArrayList<>();
		destinationServiceInstances.addAll(vcapServiceParser.getDestinationServiceInstance());
		for(DestinationServiceInstance destinationServiceInstance : destinationServiceInstances){
			destinationServiceInstanceMap.put(destinationServiceInstance.getInstanceName(), destinationServiceInstance);
		}
		
		// UAA Service
		List<UaaServiceInstance> uaaServiceInstances = new ArrayList<>();
		uaaServiceInstances.addAll(vcapServiceParser.getUaaServiceInstances());
		for(UaaServiceInstance uaaServiceInstance : uaaServiceInstances){
			uaaServiceInstanceMap.put(uaaServiceInstance.getInstanceName(), uaaServiceInstance);
		}
    
		// Portal Service
		List<PortalServiceInstance> portalServiceInstances = new ArrayList<>();
		portalServiceInstances.addAll(vcapServiceParser.getPortalServiceInstances());
		for(PortalServiceInstance portalServiceInstance : portalServiceInstances){
			portalServiceInstanceMap.put(portalServiceInstance.getInstanceName(), portalServiceInstance);
		}
    
    //BP Service
    List<BpServiceInstance> bpServiceInstances = new ArrayList<>();
    bpServiceInstances.addAll(vcapServiceParser.getBPServiceInstances());
    for (BpServiceInstance bpServiceInstance : bpServiceInstances) {
        bpServiceInstanceMap.put(bpServiceInstance.getInstanceName(), bpServiceInstance);
    }

        // Saas Registry Service
        List<SaasRegistryServiceInstance> saasRegistryServiceInstances = new ArrayList<>();
        saasRegistryServiceInstances.addAll(vcapServiceParser.getSaasRegistryServiceInstances());
        for (SaasRegistryServiceInstance saasRegistryServiceInstance : saasRegistryServiceInstances) {
            saasRegistryServiceInstanceMap.put(saasRegistryServiceInstance.getInstanceName(), saasRegistryServiceInstance);
        }
        // Saas Subscription Service

		List<SaasSubscriptionServiceInstance> saasSubscriptionServiceInstances = new ArrayList<>();
		saasSubscriptionServiceInstances.addAll(vcapServiceParser.getSaasSubscriptionServiceInstances());
		for(SaasSubscriptionServiceInstance saasSubscriptionServiceInstance : saasSubscriptionServiceInstances){
			saasSubscriptionServiceInstanceMap.put(saasSubscriptionServiceInstance.getInstanceName(), saasSubscriptionServiceInstance);
		}
		// Managed-Hana Service
		List<ManagedHanaServiceInstance> managedHanaServiceInstances = new ArrayList<>();
		managedHanaServiceInstances.addAll(vcapServiceParser.getManagedHanaServiceInstance());
		for(ManagedHanaServiceInstance serviceInstance : managedHanaServiceInstances){
			managedHanaServiceInstanceMap.put(serviceInstance.getInstanceName(), serviceInstance);
		}
		
		// Reminder Service
		List<ReminderServiceInstance> reminderServiceInstances = new ArrayList<>();
		reminderServiceInstances.addAll(vcapServiceParser.getReminderServiceInstance());
		for(ReminderServiceInstance reminderServiceInstance : reminderServiceInstances){
			reminderServiceInstanceMap.put(reminderServiceInstance.getInstanceName(), reminderServiceInstance);
		}
		
		// Location Service
		List<LocationServiceInstance> locationServiceInstances = new ArrayList<>();
		locationServiceInstances.addAll(vcapServiceParser.getLocationServiceInstances());
		for(LocationServiceInstance locationServiceInstance : locationServiceInstances){
			locationServiceInstanceMap.put(locationServiceInstance.getInstanceName(), locationServiceInstance);
		}
		
		//TODO: Connectivity Service
	}
	
	
	public DatabaseServiceInstance getServiceManagerDBServiceInstance() {
		if(this.serviceManagerDBServiceInstance == null){
			throw new InternalError(String.format("Database service instance '%s' not found for Service Manager Settings", EnvironmentsConfiguration.SERVICE_MANAGER_DB_INSTANCE_NAME));
		}
		else{
			return this.serviceManagerDBServiceInstance;
		}
	}

	public DatabaseServiceInstance getDatabaseServiceInstance(String subaccountId, String cloneServiceInstanceId){
		GTTInstance gttInstance = tenantService.getGTTInstance(subaccountId, cloneServiceInstanceId);

		return this.getDatabaseServiceInstance(gttInstance);
	}
	
	public DatabaseServiceInstance getDatabaseServiceInstance(GTTInstance gttInstance){
		DatabaseServiceInstance result = gttInstance.parseStorageConnectionInfo().getStorage();
		if(result == null){
			throw new InternalErrorException(String.format("Database service instance not found for GTT Instance id - '%s', name - '%s' ", gttInstance.getId(),gttInstance.getInstanceName() ));
		}
		
		return result;
	}
	
	
	public DestinationServiceInstance getDestinationServiceInstance(){
		DestinationServiceInstance result = null;
		if(getDestinationServiceInstanceMap().size() > 1){
    		throw new InternalErrorException(MULTIPLE_DESTINATION_SERVICE_BOUND,null);
    	}
    	
    	for(DestinationServiceInstance instance : getDestinationServiceInstanceMap().values()){
    		result = instance;
    	}
    	if(result == null){
    		throw new InternalError(NO_DESTINATION_SERVICE_BOUND,null);
    	}
    	
    	return result;
	}
	
	public UaaServiceInstance getUaaServiceInstance(){
		UaaServiceInstance result = null;
		if(getUaaServiceInstanceMap().size() > 1){
    		throw new InternalError(MULTIPLE_UAA_SERVICE_BOUND,null);
    	}
    	
    	for(UaaServiceInstance instance : getUaaServiceInstanceMap().values()){
    		result = instance;
    	}
    	if(result == null){
    		throw new InternalError(NO_UAA_SERVICE_BOUND,null);
    	}
    	
    	if(!StringUtils.equals(result.getPlanName(), UaaServiceInstance.Plan.broker.toString()) ){
    		throw new InternalError(UAA_SERVICE_IS_NOT_BROKER_PLAN,null);
    	}
    	
    	return result;
	}

	public PortalServiceInstance getPortalServiceInstance(){
		PortalServiceInstance result = null;
		if(getPortalServiceInstanceMap().size() > 1){
    		throw new InternalError(MULTIPLE_PORTAL_SERVICE_BOUND,null);
    	}
    	
    	for(PortalServiceInstance instance : getPortalServiceInstanceMap().values()){
    		result = instance;
    	}
    	if(result == null){
    		throw new InternalError(NO_PORTAL_SERVICE_BOUND,null);
    	}
    	
    	return result;
	}
	
	 

    public BpServiceInstance getBpServiceInstance() {
        BpServiceInstance result = null;
        if (getBpServiceInstanceMap().size() > 1) {
            throw new InternalError(MULTIPLE_BP_SERVICE_BOUND, null);
        }

        for (BpServiceInstance instance : getBpServiceInstanceMap().values()) {
            result = instance;
        }
        if (result == null) {
            throw new InternalError(NO_BP_SERVICE_BOUND, null);
        }
        return result;
    }

	public LocationServiceInstance getLocationServiceInstance() {
		LocationServiceInstance result = null;

		if (getLocationServiceInstanceMap().size() > 1) {
			throw new InternalError(MULTIPLE_LOCATION_SERVICE_BOUND, null);
		}

		for (LocationServiceInstance instance : getLocationServiceInstanceMap().values()) {
			result = instance;
		}

		if (result == null) {
			throw new InternalError(NO_LOCATION_SERVICE_BOUND, null);
		}
		return result;
	}

    public ReminderServiceInstance getReminderServiceInstance(){
		ReminderServiceInstance result = null;
		if(getReminderServiceInstanceMap().size() > 1){
    		throw new InternalErrorException(MULTIPLE_REMINDER_SERVICE_BOUND,null);
    	}
    	
    	for(ReminderServiceInstance instance : getReminderServiceInstanceMap().values()){
    		result = instance;
    	}
    	if(result == null){
    		throw new InternalError(NO_REMINDER_SERVICE_BOUND,null);
    	}
    	
    	return result;
	}
    

	
	public SaasRegistryServiceInstance getApplicationSaasRegistryServiceInstance(){
		return this.getSaasRegistryServiceInstance(SaasRegistryServiceInstance.Plan.APPLICATION.getPlanName());
	}
	
	public SaasRegistryServiceInstance getServiceSaasRegistryServiceInstance(){
		return this.getSaasRegistryServiceInstance(SaasRegistryServiceInstance.Plan.SERVICE.getPlanName());
	}
	
     protected SaasRegistryServiceInstance getSaasRegistryServiceInstance(String plan) {
    	List<SaasRegistryServiceInstance> result = new ArrayList<>();
    	for(Entry<String, SaasRegistryServiceInstance> entry : this.getSaasRegistryServiceInstanceMap().entrySet()){
    		if(StringUtils.equals(plan, entry.getValue().getPlanName())){
    			entry.getValue().setSaasSubscriptionServiceInstance(this.getSaasSubscriptionServiceInstance());
    			result.add(entry.getValue());
    		}
    	}
    	
        if (result.size() > 1) {
            throw new InternalError(String.format(MULTIPLE_SAAS_REGISTRY_SERVICE_BOUND, plan), null);
        }

        if (result.isEmpty()) {
            throw new InternalError(String.format(NO_SAAS_REGISTRY_SERVICE_BOUND,plan), null);
        }
        return result.get(0);
    }

    public SaasSubscriptionServiceInstance getSaasSubscriptionServiceInstance() {
        SaasSubscriptionServiceInstance result = null;
        if (getSaasSubscriptionServiceInstanceMap().size() > 1) {
            throw new InternalError(MULTIPLE_SAAS_SUBSCRIPTION_SERVICE_BOUND, null);
        }

        for (SaasSubscriptionServiceInstance instance : getSaasSubscriptionServiceInstanceMap().values()) {
            result = instance;
        }
        if (result == null) {
            throw new InternalError(NO_SAAS_SUBSCRIPTION_SERVICE_BOUND, null);
        }
        return result;
    }
    
    public ManagedHanaServiceInstance getManagedHanaServiceInstance() {
    	ManagedHanaServiceInstance result = null;
        if (getManagedHanaServiceInstanceMap().size() > 1) {
            throw new InternalError(MULTIPLE_MANAGED_HANA_SERVICE_BOUND, null);
        }

        for (ManagedHanaServiceInstance instance : getManagedHanaServiceInstanceMap().values()) {
            result = instance;
        }
        if (result == null) {
            throw new InternalError(NO_MANAGED_HANA_SERVICE_BOUND, null);
        }
        return result;
	}

    
    public synchronized DatabaseServiceInstance  getManagedHanaDatabaseServiceInstance(String databaseServiceInstanceName){
    	//MUST enable cache, otherwise for same tenant id multiple datasource will be created
    	DatabaseServiceInstance result = this.getNormalStorage(databaseServiceInstanceName);
    	if(result == null){
    		result = this.getManagedHanaServiceInstance().getDatabaseServiceInstance(databaseServiceInstanceName);
    		this.storageServiceInstanceMap.put(databaseServiceInstanceName, result);
    	}
    	return result;
    	
    }
}