package com.sap.gtt.v2.core.management.tracking;

import com.sap.gtt.v2.core.dao.tracking.*;
import com.sap.gtt.v2.core.domain.metadata.CurrentMetadataEntity;
import com.sap.gtt.v2.core.domain.metadata.MetadataConstants;
import com.sap.gtt.v2.core.domain.trackedprocess.CorrelatedEvent;
import com.sap.gtt.v2.core.domain.trackedprocess.CorrelatedEventInner;
import com.sap.gtt.v2.core.domain.trackedprocess.EventWrapper;
import com.sap.gtt.v2.core.domain.trackedprocess.MatchedCorrelatedEvent;
import com.sap.gtt.v2.core.entity.trackedprocess.Event;
import com.sap.gtt.v2.core.entity.trackedprocess.PlannedEvent;
import com.sap.gtt.v2.core.entity.trackedprocess.Reference;
import com.sap.gtt.v2.core.management.metadata.DefaultMetadataManagement;
import com.sap.gtt.v2.core.management.metadata.IMetadataManagement;
import com.sap.gtt.v2.core.runtime.model.UUIDValue;
import com.sap.gtt.v2.core.service.MessageUtil;
import com.sap.gtt.v2.exception.MessageValidationException;
import com.sap.gtt.v2.log.TenantAwareLogService;
import com.sap.gtt.v2.util.SpringContextUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

import static com.sap.gtt.v2.exception.MessageValidationException.MESSAGE_CODE_EVENT_NOT_EXISTED;

@Service(DefaultEventManagement.BEAN_NAME)
public class DefaultEventManagement implements IEventManagement {
    public static final String BEAN_NAME = "com.sap.gtt.v2.core.management.tracking.DefaultEventManagement";
    @Autowired
    private TenantAwareLogService logService;

    protected DefaultEventManagement() {
    }

    public static DefaultEventManagement getInstance() {
        return (DefaultEventManagement) SpringContextUtils.getBean(BEAN_NAME);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    public void post(Event event) {
        getEventDao().insert(event);
        if (!MessageUtil.isNull(event, Event.PLANNED_EVENTS)) {
            //Use plannedEventDao for plannedEventForEvent
            getPlannedEventDao().insert(event.getPlannedEvents());
        }
        if (!MessageUtil.isNull(event, Event.REFERENCES)) {
            getReferenceDao().insert(event.getReferences());
        }
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    public void post(List<Event> events) {
        getEventDao().insert(events);
        List<PlannedEvent> plannedEvents = new ArrayList<>();
        List<Reference> references = new ArrayList<>();
        for (Event event : events) {
            if (!MessageUtil.isNull(event, Event.PLANNED_EVENTS)) {
                plannedEvents.addAll(event.getPlannedEvents());
            }
            if (!MessageUtil.isNull(event, Event.REFERENCES)) {
                references.addAll(event.getReferences());
            }
        }
        if (!plannedEvents.isEmpty()) {
            getPlannedEventDao().insert(plannedEvents);
        }
        if (!references.isEmpty()) {
            getReferenceDao().insert(references);
        }
    }

    @Override
    public CorrelatedEvent getCorrelatedEventsIncludeEventTypes(UUIDValue tpId, List<String> eventTypes) {
        if (eventTypes == null || eventTypes.isEmpty()) {
            return null;
        }
        List<EventWrapper> events = getEventDao().getActualEventsForCurrentTPIncludeEventTypes(tpId.getInternalValue(), eventTypes);
        return correlateEvents(events);
    }

    @Override
    public CorrelatedEvent getCorrelatedEventsExcludeEventTypes(UUIDValue tpId, List<String> eventTypes) {
        List<EventWrapper> events = getEventDao().getActualEventsForCurrentTPExcludeEventTypes(tpId.getInternalValue(), eventTypes);
        return correlateEvents(events);
    }

    @Override
    public Event getLastCorrelatedEventIncludeEventTypes(UUIDValue tpId, String trackedProcessType, List<String> eventTypes) {
        IEventDao eventDao = getEventDao();
        Event coreEvent = eventDao.findLatestByTpIdAndEventTypeList(tpId.getInternalValue(), eventTypes);
        if (coreEvent == null) {
            return null;
        }
        String eventType = coreEvent.getEventType();
        String namespace = coreEvent.getModelNamespace();
        CurrentMetadataEntity metadata = getMetadataManagement().findAllEntitiesRecursively(namespace, eventType);
        return eventDao.findOne(metadata, coreEvent.getIdAsInternalValue());
    }

    @Override
    /**
     * only return core model event part
     */
    public Event getSingleEventById(UUIDValue id) {
        return getEventDao().findOneById(id.getInternalValue());
    }

    @Override
    public Event get(UUIDValue id) {
        Event coreEvent = getSingleEventById(id);
        if (coreEvent == null) {
            return null;
        }
        CurrentMetadataEntity metadata = getMetadataManagement().findAllEntitiesRecursively(coreEvent.getModelNamespace(), coreEvent.getEventType());
        return get(id, metadata);
    }

    @Override
    public Event get(UUIDValue id, CurrentMetadataEntity metadata) {
        return getEventDao().findOne(metadata, id.getInternalValue());
    }

    private CorrelatedEvent correlateEvents(List<EventWrapper> events) {
        List<CorrelatedEventInner> unmatched = new ArrayList<>();
        Map<UUID, MatchedCorrelatedEvent> matchedEventMap = new HashMap<>();
        for (EventWrapper eventWrapper : events) {
            UUID plannedEventId = eventWrapper.getPlannedEventId();
            Event event = eventWrapper.getEvent();
            if (plannedEventId != null) {
                CurrentMetadataEntity metadata = getMetadataManagement().findAllEntitiesRecursively(event.getModelNamespace(),
                        MetadataConstants.CoreModelEntity.PLANNED_EVENT.getFullName());
                PlannedEvent plannedEvent = getPlannedEventDao().findOne(metadata, plannedEventId);
                if (matchedEventMap.containsKey(plannedEventId)) {
                    MatchedCorrelatedEvent correlatedEvent = matchedEventMap.get(plannedEventId);
                    CorrelatedEventInner correlatedEventInner = CorrelatedEventInner.build(eventWrapper.getCorrelationType(), event);
                    List<CorrelatedEventInner> actualEvents = correlatedEvent.getActualEvents();
                    actualEvents.add(correlatedEventInner);
                    correlatedEvent.setActualEvents(actualEvents);
                } else {
                    MatchedCorrelatedEvent correlatedEvent = new MatchedCorrelatedEvent();
                    correlatedEvent.setPlannedEvent(plannedEvent);
                    CorrelatedEventInner correlatedEventInner = CorrelatedEventInner.build(eventWrapper.getCorrelationType(), event);
                    List<CorrelatedEventInner> actualEvents = new ArrayList<>();
                    actualEvents.add(correlatedEventInner);
                    correlatedEvent.setActualEvents(actualEvents);
                    matchedEventMap.put(plannedEventId, correlatedEvent);
                }
            } else {
                CorrelatedEventInner correlatedEventInner = CorrelatedEventInner.build(eventWrapper.getCorrelationType(), event);
                unmatched.add(correlatedEventInner);
            }

        }
        List<MatchedCorrelatedEvent> correlatedPlannedEvents = new ArrayList<>(matchedEventMap.values());
        correlatedPlannedEvents.stream().forEach(plannedEvent -> {
            List<CorrelatedEventInner> actualEvents = plannedEvent.getActualEvents();
            actualEvents.sort(Comparator.comparing(o -> o.getActualBusinessTimestamp()));
        });
        unmatched.sort(Comparator.comparing(o -> o.getActualBusinessTimestamp()));

        CorrelatedEvent correlatedEvent = new CorrelatedEvent();
        correlatedEvent.setMatched(correlatedPlannedEvents);
        correlatedEvent.setUnmatched(unmatched);
        return correlatedEvent;
    }

    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    @Override
    public void delete(List<String> eventIds) {
        if (eventIds == null || eventIds.isEmpty()) {
            return;
        }
        for (String eventId : eventIds) {
            UUID id = UUID.fromString(eventId);
            Event coreEvent = getEventDao().findOneById(id);
            if (coreEvent == null) {
                throw new MessageValidationException(MESSAGE_CODE_EVENT_NOT_EXISTED, new Object[]{eventId});
            }
            String eventType = coreEvent.getEventType();
            String namespace = coreEvent.getModelNamespace();
            CurrentMetadataEntity metadata = getMetadataManagement().findAllEntitiesRecursively(namespace, eventType);
            getEventDao().delete(metadata, id);
        }
        logService.info("Have deleted all events with id {}", eventIds);
    }

    protected IEventDao getEventDao() {
        return DefaultEventDao.getInstance();
    }

    protected IPlannedEventDao getPlannedEventDao() {
        return DefaultPlannedEventDao.getInstance();
    }

    protected IReferenceDao getReferenceDao() {
        return DefaultReferenceDao.getInstance();
    }

    protected IMetadataManagement getMetadataManagement() {
        return DefaultMetadataManagement.getInstance();
    }
}
