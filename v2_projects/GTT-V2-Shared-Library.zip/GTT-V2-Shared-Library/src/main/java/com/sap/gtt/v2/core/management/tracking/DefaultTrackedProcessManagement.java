package com.sap.gtt.v2.core.management.tracking;

import com.sap.gtt.v2.core.dao.tracking.*;
import com.sap.gtt.v2.core.domain.metadata.CurrentMetadataEntity;
import com.sap.gtt.v2.core.domain.metadata.MetadataConstants;
import com.sap.gtt.v2.core.domain.metadata.PhysicalName;
import com.sap.gtt.v2.core.domain.trackedprocess.CorrelationType;
import com.sap.gtt.v2.core.entity.trackedprocess.PlannedEvent;
import com.sap.gtt.v2.core.entity.trackedprocess.ProcessEventDirectory;
import com.sap.gtt.v2.core.entity.trackedprocess.QualifiedTrackingId;
import com.sap.gtt.v2.core.entity.trackedprocess.TrackedProcess;
import com.sap.gtt.v2.core.management.metadata.CsnParser;
import com.sap.gtt.v2.core.management.metadata.DefaultMetadataManagement;
import com.sap.gtt.v2.core.management.metadata.IMetadataManagement;
import com.sap.gtt.v2.core.runtime.model.TimestampValue;
import com.sap.gtt.v2.core.runtime.model.UUIDValue;
import com.sap.gtt.v2.core.service.MessageUtil;
import com.sap.gtt.v2.exception.LockException;
import com.sap.gtt.v2.util.SpringContextUtils;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

/**
 * @author I302310
 */
@Service(DefaultTrackedProcessManagement.BEAN_NAME)
public class DefaultTrackedProcessManagement implements ITrackedProcessManagement {
    public static final String BEAN_NAME = "com.sap.gtt.v2.core.management.tracking.DefaultTrackedProcessManagement";

    protected DefaultTrackedProcessManagement() {

    }

    public static DefaultTrackedProcessManagement getInstance() {
        return (DefaultTrackedProcessManagement) SpringContextUtils.getBean(BEAN_NAME);
    }

    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    @Override
    public void create(TrackedProcess trackedProcess) {
        getTrackedProcessDao().insert(trackedProcess);
        getQualifiedTrackingIdDao().insert(trackedProcess.getTrackingIds());
        getProcessEventDirectoryDao().insert(trackedProcess.getPEDs());
        if (!MessageUtil.isNull(trackedProcess, TrackedProcess.PLANNED_EVENTS)) {
            getPlannedEventDao().insert(trackedProcess.getPlannedEvents());
        }
    }

    /**
     * update the whole tp
     *
     * @param trackedProcess
     */
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
    @Override
    public void update(TrackedProcess trackedProcess) {
        lock(trackedProcess);
        ITrackedProcessDao processDao = getTrackedProcessDao();
        IQualifiedTrackingIdDao trackingIdDao = getQualifiedTrackingIdDao();
        List<QualifiedTrackingId> trackingIds = trackedProcess.getTrackingIds();
        UUID tpId = trackedProcess.getIdAsInternalValue();
        trackingIdDao.deleteByProcessId(tpId);
        processDao.delete(trackedProcess.getMetadata(), tpId);
        processDao.insert(trackedProcess);
        trackingIdDao.insert(trackingIds);
        getProcessEventDirectoryDao().deleteByProcessId(tpId);
        getProcessEventDirectoryDao().insert(trackedProcess.getPEDs());
        PhysicalName physicalNameForPE = trackedProcess.getMetadata().getAllRelatedEntityMap().get(MetadataConstants.CoreModelEntity.PLANNED_EVENT.getFullName()).getPhysicalName();
        getPlannedEventDao().deleteByProcessId(tpId, physicalNameForPE);
        getPlannedEventDao().insert(trackedProcess.getPlannedEvents());
    }


    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
    @Override
    public void update(TrackedProcess trackedProcess, ProcessEventDirectory newProcessEventDirectory, PlannedEvent plannedEvent) {
        lock(trackedProcess);
        ITrackedProcessDao processDao = getTrackedProcessDao();
        IQualifiedTrackingIdDao trackingIdDao = getQualifiedTrackingIdDao();
        List<QualifiedTrackingId> trackingIds = trackedProcess.getTrackingIds();
        UUID tpId = trackedProcess.getIdAsInternalValue();
        trackingIdDao.deleteByProcessId(tpId);
        processDao.delete(trackedProcess.getMetadata(), tpId);
        processDao.insert(trackedProcess);
        trackingIdDao.insert(trackingIds);
        if (newProcessEventDirectory != null) {
            getProcessEventDirectoryDao().insert(newProcessEventDirectory);
        }
        if (plannedEvent != null) {
            getPlannedEventDao().update(plannedEvent);
        } else if (newProcessEventDirectory != null
                && CorrelationType.UNPLANNED_PROCESS_CREATION_UPDATE.name().equals(newProcessEventDirectory.getCorrelationType())) {
            PhysicalName physicalNameForPE = trackedProcess.getMetadata().getAllRelatedEntityMap().get(MetadataConstants.CoreModelEntity.PLANNED_EVENT.getFullName()).getPhysicalName();
            getPlannedEventDao().deleteByProcessId(tpId, physicalNameForPE);
            getPlannedEventDao().insert(trackedProcess.getPlannedEvents());
        }
    }

    /**
     * For eventToAction
     *
     * @param trackedProcess        tracked process
     * @param isUpdateTrackingIds   isUpdateTrackingIds flag
     * @param isUpdatePlannedEvents isUpdatePlannedEvents flag
     */
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
    @Override
    public void update(TrackedProcess trackedProcess, boolean isUpdateTrackingIds, boolean isUpdatePlannedEvents) {
        MessageUtil.fillMetadata(trackedProcess);
        lock(trackedProcess);
        ITrackedProcessDao processDao = getTrackedProcessDao();
        UUID tpId = trackedProcess.getIdAsInternalValue();
        processDao.delete(trackedProcess.getMetadata(), tpId);
        processDao.insert(trackedProcess);

        if (isUpdateTrackingIds) {
            IQualifiedTrackingIdDao trackingIdDao = getQualifiedTrackingIdDao();
            List<QualifiedTrackingId> trackingIds = trackedProcess.getTrackingIds();
            trackingIdDao.deleteByProcessId(tpId);
            trackingIdDao.insert(trackingIds);
        }

        if (isUpdatePlannedEvents) {
            PhysicalName physicalNameForPE = trackedProcess.getMetadata().getAllRelatedEntityMap().get(MetadataConstants.CoreModelEntity.PLANNED_EVENT.getFullName()).getPhysicalName();
            getPlannedEventDao().deleteByProcessId(tpId, physicalNameForPE);
            getPlannedEventDao().insert(trackedProcess.getPlannedEvents());
        }

    }

    protected void lock(TrackedProcess trackedProcess) {
        ITrackedProcessDao processDao = getTrackedProcessDao();
        try {
            boolean versionExists = processDao.versionExists(trackedProcess, trackedProcess.getVersion());
            if (versionExists) {
                trackedProcess.increaseVersion();
            } else {
                throw new LockException(LockException.MESSAGE_CODE_PROCESS_HAS_BEEN_CHANGED);
            }
        } catch (DataAccessException e) {
            throw new LockException(LockException.MESSAGE_CODE_RESOURCE_BUSY, e);
        }
    }

    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    @Override
    public void delete(TrackedProcess trackedProcess) {
        ITrackedProcessDao processDao = getTrackedProcessDao();
        UUID processId = trackedProcess.getIdAsInternalValue();
        getQualifiedTrackingIdDao().deleteByProcessId(processId);
        PhysicalName physicalNameForPE = trackedProcess.getMetadata().getAllRelatedEntityMap().get(MetadataConstants.CoreModelEntity.PLANNED_EVENT.getFullName()).getPhysicalName();
        getPlannedEventDao().deleteByProcessId(processId, physicalNameForPE);
        getProcessEventDirectoryDao().deleteByProcessId(processId);
        processDao.delete(trackedProcess.getMetadata(), processId);
    }

    @Override
    public void deleteAllTheTrackedProcessByNamespace(String namespace) {
        ICoreModelDataProcessDao coreModelDataProcessDao = getCoreModelDataProcessDao();
        coreModelDataProcessDao.deleteAllCoreModelData(namespace);
    }

    @Override
    public TrackedProcess get(UUIDValue id) {
        return getInternal(id, false);
    }

    @Override
    public TrackedProcess getWithOnlyValidDPPStatus(UUIDValue id) {
        // only find TP with DPP status BUSINESS_ACTIVE or END_OF_BUSINESS
        return getInternal(id, true);
    }

    protected TrackedProcess getInternal(UUIDValue id, boolean onlyValidDPPStatus) {
        ITrackedProcessDao processDao = getTrackedProcessDao();

        UUID idValue = id.getInternalValue();
        TrackedProcess coreTP = onlyValidDPPStatus ? processDao.findOneWithValidStatus(idValue) : processDao.findOne(idValue);

        if (coreTP == null) {
            return null;
        }
        String trackedProcessType = coreTP.getTrackedProcessType();
        String namespace = CsnParser.getProjectNamespace(trackedProcessType);
        CurrentMetadataEntity metadata = getMetadataManagement().findAllEntitiesRecursively(namespace, trackedProcessType);
        return processDao.findOne(metadata, idValue);
    }

    @Override
    public TrackedProcess get(CurrentMetadataEntity metadata, UUIDValue id) {
        ITrackedProcessDao processDao = getTrackedProcessDao();
        return processDao.findOne(metadata, id.getInternalValue());
    }

    @Override
    public List<UUIDValue> getCorrelatedProcessId(UUIDValue observedId, TimestampValue actualBizTs, int eventCorrelationLevel) {
        IQualifiedTrackingIdDao trackingIdDao = getQualifiedTrackingIdDao();
        List<UUID> processIds = trackingIdDao.getCorrelatedProcessId(observedId.getInternalValue(), actualBizTs.getInternalValue(),
                eventCorrelationLevel);
        List<UUIDValue> result = new ArrayList<>();
        for (UUID processId : processIds) {
            result.add(UUIDValue.valueOf(processId));
        }
        return result;
    }

    @Override
    public Map<UUIDValue, String> getCorrelatedProcessMap(UUIDValue observedId, TimestampValue actualBizTs, int eventCorrelationLevel) {
        IQualifiedTrackingIdDao trackingIdDao = getQualifiedTrackingIdDao();
        Map<UUID, String> processIdMap = trackingIdDao.getCorrelatedProcessMap(observedId.getInternalValue(),
                actualBizTs.getInternalValue(), eventCorrelationLevel);
        Map<UUIDValue, String> result = new HashMap<>();
        for (Map.Entry<UUID, String> entry : processIdMap.entrySet()) {
            UUID processId = entry.getKey();
            result.put(UUIDValue.valueOf(processId), entry.getValue());
        }
        return result;
    }

    protected ICoreModelDataProcessDao getCoreModelDataProcessDao() {
        return DefaultCoreModelDataProcessDao.getInstance();
    }

    protected ITrackedProcessDao getTrackedProcessDao() {
        return DefaultTrackedProcessDao.getInstance();
    }

    protected IPlannedEventDao getPlannedEventDao() {
        return DefaultPlannedEventDao.getInstance();
    }

    protected IQualifiedTrackingIdDao getQualifiedTrackingIdDao() {
        return DefaultQualifiedTrackingIdDao.getInstance();
    }

    protected IProcessEventDirectoryDao getProcessEventDirectoryDao() {
        return DefaultProcessEventDirectoryDao.getInstance();
    }

    protected IMetadataManagement getMetadataManagement() {
        return DefaultMetadataManagement.getInstance();
    }

}
