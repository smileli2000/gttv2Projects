/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.gtt.v2.core.domain.blockingstore;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 *
 * @author I326335
 */
public class RelatedInstancesDto {
    private List<RelatedDocumentDto> relatedDocumentDtos;

    public List<RelatedDocumentDto> getRelatedDocumentDtos() {
        if (relatedDocumentDtos == null) {
            relatedDocumentDtos = new ArrayList<>();
        }
        return relatedDocumentDtos;
    }

    public void setRelatedDocumentDtos(List<RelatedDocumentDto> relatedDocumentDtos) {
        this.relatedDocumentDtos = relatedDocumentDtos;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 47 * hash + Objects.hashCode(this.relatedDocumentDtos);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final RelatedInstancesDto other = (RelatedInstancesDto) obj;
        if (!Objects.equals(this.relatedDocumentDtos, other.relatedDocumentDtos)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "RelatedInstancesDto{" + "relatedDocumentDtos=" + relatedDocumentDtos + '}';
    }
    
}
