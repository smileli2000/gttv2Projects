package com.sap.gtt.v2.core.dao.tracking;

import com.sap.gtt.v2.core.domain.metadata.CurrentMetadataEntity;
import com.sap.gtt.v2.core.entity.trackedprocess.ProcessEventDirectory;

import java.util.List;
import java.util.UUID;

public interface IProcessEventDirectoryDao {

	void insert(ProcessEventDirectory processEventDirectory);

	void insert(List<ProcessEventDirectory> pedList);

	void delete(CurrentMetadataEntity metadata, UUID id);

    void deleteByProcessId(UUID processId);

    void deleteByPlannedEventId(UUID plannedEventId);

    void update(ProcessEventDirectory processEventDirectory);

	ProcessEventDirectory findOne(CurrentMetadataEntity metadata, UUID id);
}
