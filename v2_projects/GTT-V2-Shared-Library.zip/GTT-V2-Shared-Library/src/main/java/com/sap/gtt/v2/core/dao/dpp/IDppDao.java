package com.sap.gtt.v2.core.dao.dpp;

import com.sap.gtt.v2.core.domain.dpp.DppEntity;

import java.util.List;
import java.util.Map;

public interface IDppDao {
    /**
     * Get the schema of PDM
     *
     * @return the PDM schema of the tenant
     */
    String getPdmSchema();

    /**
     * Insert the schema of PDM
     *
     * @param pdmSchema
     */
    void insertPdmSchema(String pdmSchema);

    /**
     * Update the schema of PDM
     *
     * @param pdmSchema
     */
    void updatePdmSchema(String pdmSchema);

    /**
     * Check if the datasubjectId field has the dataSubjectIdValue in DB.
     *
     * @param dataSubjectIdValue
     * @param dppEntities
     * @return
     */
    boolean isDataSubjectIdExistsInDB(String dataSubjectIdValue, List<DppEntity> dppEntities);

    /**
     * Get the get dpp attributes values of the entity from table where the dataSubjectIdvalue exists.
     *
     * @param dppEntity
     * @return
     * @parma dataSubjectIdValue
     */
    List<Map<String, Object>> getPdmDataInfo(String dataSubjectIdValue, DppEntity dppEntity);
}
