package com.sap.gtt.v2.exception;

public class HttpStatus4xxException extends GeneralNoneTranslatableException {
    //ERROR_CODE should not be stored into DB
    public static final String ERROR_CODE = "ERROR_CODE_4XX";

    public HttpStatus4xxException(String message, Throwable cause, int httpStatus) {
        super(message, cause, httpStatus);
    }

    @Override
    public String getErrorCode() {
        return ERROR_CODE;
    }

}
