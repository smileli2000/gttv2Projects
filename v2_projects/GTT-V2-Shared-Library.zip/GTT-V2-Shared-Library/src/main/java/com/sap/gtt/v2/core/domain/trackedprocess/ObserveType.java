package com.sap.gtt.v2.core.domain.trackedprocess;

/**
 * from v1
 */
public enum ObserveType {
    PARENTSTART, PARENTEND, CHILDSTART, CHILDEND, OBSERVE;

    @Override
    public String toString() {
        switch (this) {
            case PARENTSTART:
                return "ParentStart";
            case PARENTEND:
                return "ParentEnd";
            case CHILDSTART:
                return "ChildStart";
            case CHILDEND:
                return "ChildEnd";
            default:
                return "Observe";
        }
    }

    public static ObserveType fromValue(String value) {
        switch (value) {
            case "ParentStart":
                return PARENTSTART;
            case "ParentEnd":
                return PARENTEND;
            case "ChildStart":
                return CHILDSTART;
            case "ChildEnd":
                return CHILDEND;
            default:
                return OBSERVE;
        }
    }

    public static ObserveType fromActionReference(Action action, ObjectReference referenceType) {
        if(action == null || referenceType == null) {
            return OBSERVE;
        }
        if (action.equals(Action.ADD)) {
            if (referenceType.equals(ObjectReference.PARENT)) {
                return PARENTSTART;
            } else return CHILDSTART;
        } else if (action.equals(Action.DELETE)) {
            if (referenceType.equals(ObjectReference.PARENT)) {
                return PARENTEND;
            } else return CHILDEND;
        } else return OBSERVE;
    }

    public static ObserveType revise(ObserveType value) {
        switch (value) {
            case PARENTSTART:
                return CHILDSTART;
            case PARENTEND:
                return CHILDEND;
            case CHILDSTART:
                return PARENTSTART;
            case CHILDEND:
                return PARENTEND;
            default:
                return OBSERVE;
        }
    }
}
