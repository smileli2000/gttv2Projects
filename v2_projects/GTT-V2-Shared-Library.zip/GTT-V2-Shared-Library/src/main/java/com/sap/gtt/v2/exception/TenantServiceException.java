package com.sap.gtt.v2.exception;

public class TenantServiceException extends InternalErrorException {

    public TenantServiceException(Throwable cause) {
        super(cause);
    }


    public TenantServiceException(String message) {
        super(message);
    }


    /**
     *
     */
    private static final long serialVersionUID = -4047188974689364783L;

}
