package com.sap.gtt.v2.core.entity.metadata;

import java.io.Serializable;
import java.time.Instant;
import java.util.Objects;

/**
 * @author i311486
 */
public class MetadataDraftModel implements Serializable {

    private String id;
    private String namespace;
    private String version;
    private String description;
    private String draftStatus;
    private String status;
    private String jsonModel;
    private Instant updatedAt;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNamespace() {
        return namespace;
    }

    public void setNamespace(String namespace) {
        this.namespace = namespace;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDraftStatus() {
        return draftStatus;
    }

    public void setDraftStatus(String draftStatus) {
        this.draftStatus = draftStatus;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getJsonModel() {
        return jsonModel;
    }

    public void setJsonModel(String jsonModel) {
        this.jsonModel = jsonModel;
    }
    public Instant getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Instant updatedAt) {
        this.updatedAt = updatedAt;
    }

    public MetadataDraftModel(String id, String namespace, String version, String description, String draftStatus, String status, String jsonModel, Instant updatedAt) {
        this.id = id;
        this.namespace = namespace;
        this.version = version;
        this.description = description;
        this.draftStatus = draftStatus;
        this.status = status;
        this.jsonModel = jsonModel;
        this.updatedAt = updatedAt;
    }

    public MetadataDraftModel(){}


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        MetadataDraftModel that = (MetadataDraftModel) o;
        return id.equals(that.id) &&
                Objects.equals(namespace, that.namespace) &&
                Objects.equals(version, that.version) &&
                Objects.equals(description, that.description) &&
                Objects.equals(draftStatus, that.draftStatus) &&
                Objects.equals(status, that.status) &&
                Objects.equals(jsonModel, that.jsonModel) &&
                Objects.equals(updatedAt, that.updatedAt);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, namespace, version, description, draftStatus, status, jsonModel, updatedAt);
    }
}
