package com.sap.gtt.v2.core.service;

import com.sap.gtt.v2.configuration.AccessContextHolder;
import com.sap.gtt.v2.configuration.ISAPCloudPlatformAgent.ICurrentAccessContext;
import com.sap.gtt.v2.configuration.SystemConstants;
import com.sap.gtt.v2.core.domain.execution.ExecutionMessageDto;
import com.sap.gtt.v2.core.domain.execution.ExecutionStatus;
import com.sap.gtt.v2.core.domain.execution.Phase;
import com.sap.gtt.v2.core.domain.metadata.*;
import com.sap.gtt.v2.core.domain.trackedprocess.*;
import com.sap.gtt.v2.core.entity.trackedprocess.*;
import com.sap.gtt.v2.core.management.execution.IMessageLogManagement;
import com.sap.gtt.v2.core.management.metadata.CsnParser;
import com.sap.gtt.v2.core.management.metadata.IMetadataManagement;
import com.sap.gtt.v2.core.management.tracking.IEventManagement;
import com.sap.gtt.v2.core.management.tracking.ITrackedProcessManagement;
import com.sap.gtt.v2.core.rule.impl.GTTEmbededRuleScriptLauncher;
import com.sap.gtt.v2.core.runtime.model.ObjectValue;
import com.sap.gtt.v2.core.runtime.model.UUIDValue;
import com.sap.gtt.v2.exception.*;
import com.sap.gtt.v2.log.TenantAwareLogService;
import com.sap.gtt.v2.util.GTTUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.apache.commons.lang3.tuple.Triple;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.PrintStream;
import java.time.Duration;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.sap.gtt.v2.core.domain.metadata.MetadataConstants.CoreModelEntity.*;
import static com.sap.gtt.v2.core.rule.impl.GTTEmbededRuleScriptLauncher.TIME_OUT;
import static com.sap.gtt.v2.exception.InstanceBasedAuthorizationCheckException.MESSAGE_CODE_INSTANCE_NOT_AUTHORIZED;
import static com.sap.gtt.v2.exception.TrackedProcessCheckException.*;

/**
 * @author I302310
 */
@Service
public class MessageProcessingAsync {
    @Autowired
    private ICurrentAccessContext currentContext;
    @Autowired
    private GTTEmbededRuleScriptLauncher ruleScriptLauncher;
    @Autowired
    private TenantAwareLogService logService;


    public void processProcessEvent(Event event, String executionId) {
        TrackedProcess trackedProcess;
        try {
            trackedProcess = eventToProcess(event);
        } catch (BaseRuntimeException e) {
            insertExecutionMessage(executionId, Phase.INIT.name(), ExecutionStatus.ERROR.name(), Instant.now(), e);
            throw e;
        }
        UUIDValue tpId = trackedProcess.getId();
        TrackedProcess tpExisted = queryTrackedProcess(trackedProcess.getMetadata(), tpId);
        if (tpExisted != null) {
            if (trackedProcess.getLastChangedAtBusinessTime().isBefore(tpExisted.getLastChangedAtBusinessTime())) {
                TrackedProcessCheckException e = new TrackedProcessCheckException(MESSAGE_CODE_NEW_TP_IS_OLD, null);
                logService.warn(e.getMessage());
                insertExecutionMessage(executionId, Phase.INIT.name(), ExecutionStatus.ERROR.name(),
                        Instant.now(), e);
                return;
            }
            if (isInBlockingStatus(tpExisted)) {
                TrackedProcessCheckException exception = new TrackedProcessCheckException(MESSAGE_CODE_TP_IN_BLOCKING_STATUS,
                        new Object[]{tpExisted.getIdAsInternalValue()});
                logService.warn(exception.getMessage());
                insertExecutionMessage(executionId, Phase.INIT.name(), ExecutionStatus.ERROR.name(),
                        Instant.now(), exception);
                throw exception;
            }
            updateTP(event, trackedProcess, tpExisted, executionId);
        } else {
            insertTP(trackedProcess, event, executionId);
        }
        try {
            eventToAction(tpExisted, trackedProcess, null, event);
        } catch (BaseRuntimeException e) {
            insertExecutionMessage(executionId, Phase.EVENT2ACTION.name(), ExecutionStatus.ERROR.name(), Instant.now(), e);
            throw e;
        }

    }


    private boolean isInBlockingStatus(TrackedProcess trackedProcess) {
        LifeCycleStatus lifeCycleStatus = trackedProcess.getLifeCycleStatus();
        return LifeCycleStatus.END_OF_PURPOSE.equals(lifeCycleStatus) || LifeCycleStatus.END_OF_RETENTION.equals(lifeCycleStatus);
    }

    private TrackedProcess queryTrackedProcess(Event event, UUIDValue tpId) {
        String eventType = event.getEventType();
        if (isGTTOverdueEvent(eventType)) {
            String trackedProcessType = ((OverdueEvent) event).getTrackedProcessType();
            String namespace = event.getModelNamespace();
            CurrentMetadataEntity metadata = getMetadataManagement().findAllEntitiesRecursively(namespace, trackedProcessType);
            return queryTrackedProcess(metadata, tpId);
        } else if (isGTTDPPDeletionEvent(eventType)) {
            return queryTrackedProcessWithAllStatus(tpId);
        } else {
            return queryTrackedProcess(tpId);
        }
    }

    private TrackedProcess queryTrackedProcess(CurrentMetadataEntity metadata, UUIDValue tpId) {
        return getProcessManagement().get(metadata, tpId);
    }

    private TrackedProcess queryTrackedProcess(UUIDValue tpId) {
        return getProcessManagement().getWithOnlyValidDPPStatus(tpId);
    }

    private TrackedProcess queryTrackedProcessWithAllStatus(UUIDValue tpId) {
        return getProcessManagement().get(tpId);
    }

    private TrackedProcess eventToProcess(Event event) {
        TrackedProcess trackedProcess = new TrackedProcess();
        String namespace = event.getModelNamespace();
        IMetadataManagement metadataManagement = getMetadataManagement();
        MetadataEntity trackProcessEntity = metadataManagement.getTrackedProcessEntityByEventType(namespace, event.getEventType());
        String trackedProcessType = trackProcessEntity.getName();
        trackedProcess.setTrackedProcessType(trackedProcessType);
        CurrentMetadataEntity metadata = metadataManagement.findAllEntitiesRecursively(namespace, trackedProcessType);
        trackedProcess.setMetadata(metadata);

        MessageUtil.copy(event, trackedProcess);
        UUID tpId = GTTUtils.UUIDUtils.generateNameBasedUUID(trackedProcess.getAltKey());
        trackedProcess.setId(tpId);
        MessageUtil.processBacklinkProperty(trackedProcess, null);

        Instant now = Instant.now();
        if (!MessageUtil.isNull(trackedProcess, TrackedProcess.PLANNED_EVENTS)) {
            List<PlannedEvent> plannedEvents = trackedProcess.getPlannedEvents();
            int payloadSequence = 1;
            for (PlannedEvent pe : plannedEvents) {
                fillPlannedEvent(trackedProcessType, now, pe);
                pe.setPayloadSequence(payloadSequence++);
            }
            trackedProcess.setPlannedEvents(plannedEvents);
        }
        trackedProcess.setCreationDateTime(now);
        trackedProcess.setLastChangedDateTime(now);
        trackedProcess.setLastChangedAtBusinessTime(event.getActualBusinessTimestamp());
        trackedProcess.setCreatedByUser(currentContext.getLogonName());
        trackedProcess.setLastChangedByUser(currentContext.getLogonName());
        return trackedProcess;
    }

    private void fillPlannedEvent(String trackedProcessType, Instant now, PlannedEvent pe) {
        pe.setId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
        pe.setEventStatus(EventStatus.PLANNED.name());
        MetadataEntityEvent eventConfig = getMetadataManagement().getEntityEvent(trackedProcessType, pe.getEventType());
        int maxOverdueDetection = eventConfig.getMaxOverdueDetection();
        if (maxOverdueDetection == 0) {
            pe.setNextOverdueDetection(Constant.MAX_TIMESTAMP);
        } else {
            pe.setNextOverdueDetection(getInitialValueOfNextOverdueDetection(pe.getPlannedTechTsLatest(), now));
        }
        pe.setOverdueDetectionCounter(0);
    }

    private Instant getInitialValueOfNextOverdueDetection(Instant plannedTechTsLatest, Instant nowTs) {
        Instant tsOption = nowTs.plus(Constant.BUFFER_TIME);
        if (plannedTechTsLatest.isAfter(tsOption)) {
            return plannedTechTsLatest;
        }
        return tsOption;
    }

    private void updateTP(Event event, TrackedProcess trackedProcess, TrackedProcess existedTP, String executionId) {
        try {
            if (event.isValueProvided(Event.REFERENCES)) {
                trackedProcess.setTrackingIds(manageTrackingId(event.getModelNamespace(), trackedProcess.getIdAsInternalValue(),
                        event.getReferences(), existedTP.getTrackingIds()));
            }
            MessageUtil.copyMissingValue(existedTP, trackedProcess);
            MessageUtil.processDefaultValue(trackedProcess);
            List<ProcessEventDirectory> peds = new ArrayList<>();
            peds.addAll(existedTP.getPEDs());
            trackedProcess.setPEDs(peds);
            List<PlannedEvent> plannedEvents = mergePlannedEvents(trackedProcess, existedTP);
            trackedProcess.setPlannedEvents(plannedEvents);
            List<PlannedEvent> sortedPlannedEvents = trackedProcess.getPlannedEventsSortByPlannedBusinessTime(false);
            ProcessStatus processStatus = MessageUtil.getProcessStatus(sortedPlannedEvents);
            trackedProcess.setProcessStatus(processStatus.name());
            trackedProcess.setCreationDateTime(existedTP.getCreationDateTime());
            trackedProcess.setCreatedByUser(existedTP.getCreatedByUser());
        } catch (BaseRuntimeException e) {
            insertExecutionMessage(executionId, Phase.MERGE.name(), ExecutionStatus.ERROR.name(), Instant.now(), e);
            throw e;
        }

        try {
            ProcessEventDirectory ped = createProcessEventDirectory(event.getModelNamespace(),
                    trackedProcess, event.getIdAsInternalValue(), null,
                    CorrelationType.UNPLANNED_PROCESS_CREATION_UPDATE);
            getProcessManagement().update(trackedProcess, ped, null);
        } catch (BaseRuntimeException e) {
            insertExecutionMessage(executionId, Phase.DB.name(), ExecutionStatus.ERROR.name(), Instant.now(), e);
            throw e;
        }
    }

    private ProcessEventDirectory createProcessEventDirectory(String namespace, TrackedProcess tp,
                                                              UUID eventId, UUID plannedEventId,
                                                              CorrelationType correlationType) {
        CurrentMetadataEntity metadata = getMetadataManagement().findAllEntitiesRecursively(namespace,
                PROCESS_EVENT_DIRECTORY.getFullName());
        List<ProcessEventDirectory> peds = tp.isValueProvided(TrackedProcess.PROCESS_EVENT_DIRECTORIES) ? tp.getPEDs() : new ArrayList<>();
        Optional<ProcessEventDirectory> rst = peds.stream().filter(ped -> ped.getEventId().equals(eventId)).findAny();
        if (!rst.isPresent()) {
            ProcessEventDirectory ped = ProcessEventDirectory.build(
                    GTTUtils.UUIDUtils.generateTimeBasedUUID(),
                    tp.getIdAsInternalValue(),
                    plannedEventId,
                    eventId,
                    correlationType.name());
            ped.setMetadata(metadata);
            peds.add(ped);
            tp.setPEDs(peds);
            return ped;
        }
        return null;
    }

    private List<PlannedEvent> mergePlannedEvents(TrackedProcess trackedProcess, TrackedProcess existedTP) {
        Map<UUID, PlannedEvent> reportedPlannedEvents = new HashMap<>();
        int maxPayloadSequence = 0;
        List<PlannedEvent> plannedEventsOfExistedTP = null;
        if (!MessageUtil.isNull(existedTP, TrackedProcess.PLANNED_EVENTS)) {
            plannedEventsOfExistedTP = existedTP.getPlannedEvents();
            reportedPlannedEvents = plannedEventsOfExistedTP.stream().filter(PlannedEvent::isReported)
                    .collect(Collectors.toMap(PlannedEvent::getId, Function.identity()));
            maxPayloadSequence = MessageUtil.getMaxPayloadSequence(reportedPlannedEvents.values());
        }

        List<PlannedEvent> plannedEvents = new ArrayList<>();
        if (!MessageUtil.isNull(trackedProcess, TrackedProcess.PLANNED_EVENTS)) {
            plannedEvents = trackedProcess.getPlannedEvents();
            int payloadSequence = maxPayloadSequence + 1;
            for (PlannedEvent plannedEvent : plannedEvents) {
                PlannedEvent matchedPE = matchPlannedEvent(existedTP.getTrackedProcessType(), plannedEventsOfExistedTP, plannedEvent, Tag.PLANNEDEVENT);
                if (matchedPE != null) {
                    if (matchedPE.isReported()) {
                        plannedEvent.copy(matchedPE);
                        reportedPlannedEvents.remove(matchedPE.getId());
                    } else {
                        plannedEvent.setId(matchedPE.getId());
                        plannedEvent.setPayloadSequence(payloadSequence++);
                    }
                } else {
                    plannedEvent.setPayloadSequence(payloadSequence++);
                }
            }
        }
        plannedEvents.addAll(reportedPlannedEvents.values());
        return plannedEvents;
    }


    private void insertTP(TrackedProcess trackedProcess, Event event, String executionId) {
        try {
            String namespace = event.getModelNamespace();
            List<QualifiedTrackingId> trackingIds = new ArrayList<>();
            UUID tpId = trackedProcess.getIdAsInternalValue();
            trackingIds.add(buildQualifiedTrackingId(namespace, tpId, tpId, null, null));
            if (event.isValueProvided(Event.REFERENCES)) {
                trackingIds.addAll(manageTrackingId(namespace, tpId, event.getReferences(), null));
            }
            trackedProcess.setTrackingIds(trackingIds);

            MessageUtil.processDefaultValue(trackedProcess);
            createProcessEventDirectory(namespace,
                    trackedProcess, event.getIdAsInternalValue(), null,
                    CorrelationType.UNPLANNED_PROCESS_CREATION_UPDATE);
            trackedProcess.setVersion(Constant.TP_START_VERSION);
        } catch (BaseRuntimeException e) {
            insertExecutionMessage(executionId, Phase.INIT.name(), ExecutionStatus.ERROR.name(), Instant.now(), e);
            throw e;
        }
        try {
            getProcessManagement().create(trackedProcess);
        } catch (BaseRuntimeException e) {
            insertExecutionMessage(executionId, Phase.DB.name(), ExecutionStatus.ERROR.name(), Instant.now(), e);
            throw e;
        }
    }

    public void processCommonEvent(UUID processId, Event event, String executionId) {
        TrackedProcess tp = queryTrackedProcess(event, UUIDValue.valueOf(processId));
        if (tp == null) {
            TrackedProcessCheckException e = new TrackedProcessCheckException(MESSAGE_CODE_TP_NOT_EXIST, new Object[]{processId});
            logService.warn(e.getMessage());
            insertExecutionMessage(executionId, Phase.VALIDATION.name(), ExecutionStatus.ERROR.name(), Instant.now(), e);
            return;
        }
        try {
            validateAuthorization(event, tp);
        } catch (InstanceBasedAuthorizationCheckException e) {
            logService.warn(e.getMessage());
            insertExecutionMessage(executionId, Phase.VALIDATION.name(), ExecutionStatus.ERROR.name(), Instant.now(), e);
            throw e;
        }
        TrackedProcess oldTP = queryTrackedProcess(tp.getMetadata(), UUIDValue.valueOf(processId));
        PlannedEvent matchedPlannedEvent = null;
        ProcessEventDirectory ped = null;
        String eventType = event.getEventType();
        if (isGTTDPPDeletionEvent(eventType)) {
            tp.setLifeCycleStatus(LifeCycleStatus.END_OF_RETENTION);
        } else if (isGTTUpdatePlanEvent(eventType)) {
            try {
                processGTTUpdatePlanEvent(event, tp);
            } catch (BaseRuntimeException e) {
                insertExecutionMessage(executionId, Phase.PROCESS.name(), ExecutionStatus.ERROR.name(), Instant.now(), e);
                throw e;
            }
        } else if (!isGTTDeletionEvent(eventType)) {
            matchedPlannedEvent = matchPlannedEvent(tp, event);
            Event lastEffectiveEvent = getLastEffectiveEvent(tp, matchedPlannedEvent);
            boolean valid = isValidEvent(tp.getTrackedProcessType(), event, matchedPlannedEvent, lastEffectiveEvent);
            if (!valid) {
                String message = String.format("Event match failed for event with id %s", event.getIdAsInternalValue());
                logService.warn(message);
                EventMatchException e = new EventMatchException(message);
                insertExecutionMessage(executionId, Phase.VALIDATION.name(), ExecutionStatus.ERROR.name(), Instant.now(), e);
                return;
            }
            try {
                ped = processEventInner(event, tp, matchedPlannedEvent, lastEffectiveEvent);
            } catch (BaseRuntimeException e) {
                insertExecutionMessage(executionId, Phase.PROCESS.name(), ExecutionStatus.ERROR.name(), Instant.now(), e);
                throw e;
            }
        }
        try {
            saveDB(tp, ped, matchedPlannedEvent, eventType);
        } catch (BaseRuntimeException e) {
            insertExecutionMessage(executionId, Phase.DB.name(), ExecutionStatus.ERROR.name(), Instant.now(), e);
            throw e;
        }

        try {
            UUID matchedPlannedEventId = matchedPlannedEvent == null ? null : matchedPlannedEvent.getId();
            eventToAction(oldTP, tp, matchedPlannedEventId, event);
        } catch (BaseRuntimeException e) {
            insertExecutionMessage(executionId, Phase.EVENT2ACTION.name(), ExecutionStatus.ERROR.name(), Instant.now(), e);
            throw e;
        }
    }

    private void validateAuthorization(Event event, TrackedProcess trackedProcess) {
        CurrentMetadataEntity metadata = event.getMetadata();
        boolean isEnable = metadata.isEnableInstanceBasedAuthorization();
        boolean isProcessEvent = metadata.getCurrentEntity().isProcessEvent();
        if (!isEnable || isProcessEvent) {
            return;
        }
        String senderPartyId = event.getSenderPartyId();
        MetadataEntity tpMetadataEntity = trackedProcess.getMetadata().getCurrentEntity();
        String processPartyId = trackedProcess.getPartyId();
        List<Authorization> authorizationList = tpMetadataEntity.getAuthorizations();
        if (senderPartyId.equals(processPartyId)) {
            return;
        } else {
            for (Authorization authorization : authorizationList) {
                if (authorization.getPrincipalType().equals(MetadataConstants.PrincipalTypeEnum.LBNID.getValue())) {
                    String element = authorization.getElement();
                    String elementValue = trackedProcess.getValueAsString(element);
                    List<String> permissions = authorization.getPermissions();
                    if (permissions.contains(MetadataConstants.PermissionEnum.REPORT.getValue()) && senderPartyId.equals(elementValue)) {
                        return;
                    }
                }
            }
        }
        throw new InstanceBasedAuthorizationCheckException(MESSAGE_CODE_INSTANCE_NOT_AUTHORIZED, new Object[]{trackedProcess.getTrackedProcessType()});
    }

    private ProcessEventDirectory processEventInner(Event event, TrackedProcess tp, PlannedEvent matchedPlannedEvent, Event lastEffectiveEvent) {
        processReferences(event, tp);
        tp.setLastChangedDateTime(Instant.now());
        tp.setLastChangedByUser(currentContext.getLogonName());
        return processPlannedEvent(matchedPlannedEvent, event, tp, lastEffectiveEvent);
    }

    private void processReferences(Event event, TrackedProcess tp) {
        String namespace = event.getModelNamespace();
        if (event.isValueProvided(Event.REFERENCES)) {
            List<QualifiedTrackingId> trackingIds = manageTrackingId(namespace, tp.getIdAsInternalValue(),
                    event.getReferences(), tp.getTrackingIds());
            tp.setTrackingIds(trackingIds);
        }
    }

    private void processGTTUpdatePlanEvent(Event event, TrackedProcess tp) {
        processReferences(event, tp);
        tp.setLastChangedDateTime(Instant.now());
        tp.setLastChangedByUser(currentContext.getLogonName());
        int maxPayloadSequence = getMaxPayloadSequence(tp);
        if (event.isValueProvided(Event.PLANNED_EVENTS)) {
            List<PlannedEvent> plannedEvents = event.getPlannedEvents();
            List<PlannedEvent> plannedEventsOfTp = tp.getPlannedEvents();
            List<ProcessEventDirectory> peds = tp.getPEDs();
            String trackedProcessType = tp.getTrackedProcessType();
            for (PlannedEvent plannedEvent : plannedEvents) {
                String action = plannedEvent.getValueAsString(PlannedEvent.ACTION);
                PlannedEvent newPlannedEvent = buildPlannedEvent(trackedProcessType, plannedEvent, tp.getId());
                PlannedEvent matchedPlannedEvent = matchPlannedEvent(trackedProcessType, plannedEventsOfTp, newPlannedEvent, Tag.PLANNEDEVENT);
                if (matchedPlannedEvent != null) {
                    processPlannedEventForGTTUpdatePlanEvent(plannedEventsOfTp, peds, action, newPlannedEvent, matchedPlannedEvent);
                } else if (Action.ADD.name().equals(action)) {
                    newPlannedEvent.setPayloadSequence(++maxPayloadSequence);
                    plannedEventsOfTp.add(newPlannedEvent);
                }
            }
            tp.setPlannedEvents(plannedEventsOfTp);
            tp.setPEDs(peds);
            ProcessStatus processStatus = MessageUtil.getProcessStatus(tp, null, event.getEventType());
            tp.setProcessStatus(processStatus.name());
        }
        createProcessEventDirectory(event.getModelNamespace(), tp, event.getIdAsInternalValue(), null, CorrelationType.UNPLANNED_UPDATE_PLAN);
    }

    private void processPlannedEventForGTTUpdatePlanEvent(List<PlannedEvent> plannedEventsOfTp, List<ProcessEventDirectory> peds,
                                                          String action, PlannedEvent newPlannedEvent, PlannedEvent matchedPlannedEvent) {
        UUID plannedEventId = matchedPlannedEvent.getId();
        if (Action.ADD.name().equals(action)) {
            newPlannedEvent.setId(plannedEventId);
            newPlannedEvent.setPayloadSequence(matchedPlannedEvent.getPayloadSequence());
            newPlannedEvent.setLastProcessEventDirectoryId(matchedPlannedEvent.getLastProcessEventDirectoryId());
            if (matchedPlannedEvent.isReported()) {
                recalculatePlannedEvent(newPlannedEvent, peds);
            } else {
                newPlannedEvent.setEventStatus(matchedPlannedEvent.getEventStatus());
                newPlannedEvent.setOverdueDetectionCounter(matchedPlannedEvent.getOverdueDetectionCounter());
            }
            removeOnePlannedEvent(plannedEventsOfTp, plannedEventId);
            plannedEventsOfTp.add(newPlannedEvent);
        } else if (Action.RESET.name().equals(action)) {
            newPlannedEvent.setId(plannedEventId);
            newPlannedEvent.setPayloadSequence(matchedPlannedEvent.getPayloadSequence());
            clearPEDOfOnePlannedEvent(peds, plannedEventId);
            removeOnePlannedEvent(plannedEventsOfTp, plannedEventId);
            plannedEventsOfTp.add(newPlannedEvent);
        } else if (Action.DELETE.name().equals(action)) {
            clearPEDOfOnePlannedEvent(peds, plannedEventId);
            removeOnePlannedEvent(plannedEventsOfTp, plannedEventId);
        }
    }

    private void recalculatePlannedEvent(PlannedEvent newPlannedEvent, List<ProcessEventDirectory> peds) {
        UUID plannedEventId = newPlannedEvent.getId();
        UUID lastPEDId = newPlannedEvent.getLastProcessEventDirectoryId();
        Instant earliestTs = newPlannedEvent.getPlannedBizTsEarliest();
        Instant latestTs = newPlannedEvent.getPlannedBizTsLatest();
        for (ProcessEventDirectory ped : peds) {
            if (plannedEventId.equals(ped.getPlannedEventId())) {
                String correlationType = ped.getCorrelationType();
                if (!CorrelationType.REPORTED.name().equals(correlationType)
                        && !CorrelationType.LATE_REPORTED.name().equals(correlationType)
                        && !CorrelationType.EARLY_REPORTED.name().equals(correlationType)) {
                    continue;
                }
                UUID eventId = ped.getEventId();
                Event event = getEventManagement().getSingleEventById(UUIDValue.valueOf(eventId));
                EventStatus eventStatus = calculateEventStatus(event.getActualBusinessTimestamp(), earliestTs, latestTs);
                CorrelationType newCorrelationType = CorrelationType.valueOf(eventStatus.name());
                ped.setCorrelationType(newCorrelationType.name());
                if (ped.getId().equals(lastPEDId)) {
                    newPlannedEvent.setEventStatus(eventStatus.name());
                }
            }
        }
    }

    private void removeOnePlannedEvent(List<PlannedEvent> plannedEvents, UUID plannedEventId) {
        int index = 0;
        for (; index < plannedEvents.size(); index++) {
            PlannedEvent pe = plannedEvents.get(index);
            if (plannedEventId.equals(pe.getId())) {
                break;
            }
        }
        plannedEvents.remove(index);
    }

    private PlannedEvent buildPlannedEvent(String trackedProcessType, PlannedEvent plannedEventForEvent, UUIDValue tpId) {
        PlannedEvent plannedEvent = new PlannedEvent();
        String namespace = CsnParser.getProjectNamespace(trackedProcessType);
        CurrentMetadataEntity metadata = getMetadataManagement().findAllEntitiesRecursively(namespace, PLANNED_EVENT.getFullName());
        plannedEvent.setMetadata(metadata);
        MessageUtil.copy(plannedEventForEvent, plannedEvent);
        plannedEvent.setProcessId(tpId);
        plannedEvent.setLastProcessEventDirectoryId(null);
        fillPlannedEvent(trackedProcessType, Instant.now(), plannedEvent);
        return plannedEvent;
    }

    private int getMaxPayloadSequence(TrackedProcess tp) {
        List<PlannedEvent> plannedEvents = null;
        if (tp.isValueProvided(TrackedProcess.PLANNED_EVENTS)) {
            plannedEvents = tp.getPlannedEvents();
        }
        if (plannedEvents == null || plannedEvents.isEmpty()) {
            return 0;
        }
        Optional<PlannedEvent> optionalPlannedEvent = plannedEvents.stream().max(Comparator.comparingInt(PlannedEvent::getPayloadSequence));
        if (optionalPlannedEvent.isPresent()) {
            PlannedEvent plannedEvent = optionalPlannedEvent.get();
            return plannedEvent.getPayloadSequence();
        }
        return 0;
    }


    private void saveDB(TrackedProcess tp, ProcessEventDirectory newPED, PlannedEvent matchedPlannedEvent, String eventType) {
        if (isGTTDeletionEvent(eventType) || isGTTDPPDeletionEvent(eventType)) {
            getProcessManagement().delete(tp);
        } else if (isGTTUpdatePlanEvent(eventType)) {
            getProcessManagement().update(tp);
        } else {
            getProcessManagement().update(tp, newPED, matchedPlannedEvent);
        }
    }

    private Event getLastEffectiveEvent(TrackedProcess tp, PlannedEvent matchedPlannedEvent) {
        if (matchedPlannedEvent == null || matchedPlannedEvent.getLastProcessEventDirectoryId() == null) {
            return null;
        }

        Optional<UUID> eventID = tp.getPEDs().stream().filter(
                ped -> ped.getId().equals(matchedPlannedEvent.getLastProcessEventDirectoryId())
        ).map(ProcessEventDirectory::getEventId).findFirst();

        UUID lastEventId = eventID.isPresent() ? eventID.get() : null;
        if (lastEventId != null) {
            return getEventManagement().getSingleEventById(UUIDValue.valueOf(lastEventId));
        }
        return null;
    }

    private ProcessEventDirectory processPlannedEvent(PlannedEvent matchedPlannedEvent, Event event,
                                                      TrackedProcess tp, Event lastEffectiveEvent) {
        if (matchedPlannedEvent != null) {
            return processPlannedEventWhenMatched(matchedPlannedEvent, event, tp, lastEffectiveEvent);
        }
        return processPlannedEventWhenNotMatched(event, tp);
    }

    private ProcessEventDirectory processPlannedEventWhenMatched(PlannedEvent matchedPlannedEvent, Event event,
                                                                 TrackedProcess tp, Event lastEffectiveEvent) {
        String eventType = event.getEventType();
        String trackedProcessType = tp.getTrackedProcessType();
        String preStatus = matchedPlannedEvent.getEventStatus();
        CorrelationType correlationType;
        if (isGTTOverdueEvent(eventType)) {
            MetadataEntityEvent eventConfig = getMetadataManagement().getEntityEvent(trackedProcessType,
                    matchedPlannedEvent.getEventType());
            processOverdueEvent(eventConfig, matchedPlannedEvent);
            if (matchedPlannedEvent.getEventStatus().equals(EventStatus.PLANNED.name()) && lastEffectiveEvent == null) {
                matchedPlannedEvent.setEventStatus(EventStatus.OVERDUE.name());
            }
            correlationType = CorrelationType.UNPLANNED_OVERDUE;
        } else if (isOrInheritFrom(event, GTT_DELAYED_EVENT)) {
            processDelayedEvent(matchedPlannedEvent, event, lastEffectiveEvent);
            correlationType = CorrelationType.UNPLANNED_DELAYED;
        } else if (isOrInheritFrom(event, GTT_ONTIME_EVENT)) {
            processOnTimeEvent(matchedPlannedEvent, event, lastEffectiveEvent);
            correlationType = CorrelationType.UNPLANNED_ONTIME;
        } else {
            Instant actualBizTs = event.getActualBusinessTimestamp();
            EventStatus eventStatus = calculateEventStatus(actualBizTs,
                    matchedPlannedEvent.getPlannedBizTsEarliest(), matchedPlannedEvent.getPlannedBizTsLatest());
            if (!matchedPlannedEvent.isReported() || hasMorePrivilege(event, lastEffectiveEvent)) {
                matchedPlannedEvent.setEventStatus(eventStatus.name());
            }
            correlationType = CorrelationType.valueOf(eventStatus.name());
        }
        ProcessStatus processStatus = MessageUtil.getProcessStatus(tp, matchedPlannedEvent, eventType);
        tp.setProcessStatus(processStatus.name());

        ProcessEventDirectory ped;
        ped = createProcessEventDirectory(event.getModelNamespace(), tp, event.getIdAsInternalValue(),
                matchedPlannedEvent.getId(), correlationType);
        if (ped != null && shouldUpdateLastPED(preStatus, matchedPlannedEvent.getEventStatus(), event, lastEffectiveEvent)) {
            matchedPlannedEvent.setLastProcessEventDirectoryId(ped.getId());
        }

        // DPP setting - if the planned event is final event and reported, set the tp as EOB
        if (matchedPlannedEvent.getIsFinalPlannedEvent() != null && matchedPlannedEvent.getIsFinalPlannedEvent()
                && matchedPlannedEvent.isReported()) {
            tp.setLifeCycleStatus(LifeCycleStatus.END_OF_BUSINESS);
        }
        return ped;
    }

    private void processOnTimeEvent(PlannedEvent matchedPlannedEvent, Event event, Event lastEffectiveEvent) {
        if (EventStatus.OVERDUE.name().equals(matchedPlannedEvent.getEventStatus()) ||
                (EventStatus.DELAYED.name().equals(matchedPlannedEvent.getEventStatus()) &&
                        (lastEffectiveEvent == null || event.getActualBusinessTimestamp().compareTo(lastEffectiveEvent.getActualBusinessTimestamp()) >= 0))) {
            matchedPlannedEvent.setEventStatus(EventStatus.PLANNED.name());
        }
    }

    private void processDelayedEvent(PlannedEvent matchedPlannedEvent, Event event, Event lastEffectiveEvent) {
        if (EventStatus.OVERDUE.name().equals(matchedPlannedEvent.getEventStatus()) ||
                (EventStatus.PLANNED.name().equals(matchedPlannedEvent.getEventStatus()) &&
                        (lastEffectiveEvent == null || event.getActualBusinessTimestamp().compareTo(lastEffectiveEvent.getActualBusinessTimestamp()) >= 0))) {
            matchedPlannedEvent.setEventStatus(EventStatus.DELAYED.name());
        }
    }

    private boolean shouldUpdateLastPED(String preStatus, String postStatus, Event event, Event lastEffectiveEvent) {
        if (lastEffectiveEvent == null) {
            return true;
        }
        if (!preStatus.equals(postStatus)) {
            return true;
        }
        if (MessageUtil.isReported(postStatus)) {
            return hasMorePrivilege(event, lastEffectiveEvent);
        }
        if ((EventStatus.DELAYED.name().equals(postStatus) || EventStatus.PLANNED.name().equals(postStatus)) && isGTTOverdueEvent(event.getEventType())) {
            return false;
        }
        return event.getActualBusinessTimestamp().compareTo(lastEffectiveEvent.getActualBusinessTimestamp()) >= 0;
    }

    private boolean hasMorePrivilege(Event event, Event lastEffectiveEvent) {
        return event.getPriority() > lastEffectiveEvent.getPriority()
                || (event.getPriority() == lastEffectiveEvent.getPriority()
                && event.getActualBusinessTimestamp().compareTo(lastEffectiveEvent.getActualBusinessTimestamp()) >= 0);
    }

    private ProcessEventDirectory processPlannedEventWhenNotMatched(Event event, TrackedProcess tp) {
        String eventType = event.getEventType();
        CorrelationType correlationType = CorrelationType.UNPLANNED;
        if (isGTTDPPBlockingEvent(eventType)) {
            tp.setLifeCycleStatus(LifeCycleStatus.END_OF_PURPOSE);
            correlationType = CorrelationType.UNPLANNED_BLOCKING;
        } else if (isOrInheritFrom(event, GTT_DELAYED_EVENT)) {
            correlationType = CorrelationType.UNPLANNED_DELAYED;
        } else if (isOrInheritFrom(event, GTT_ONTIME_EVENT)) {
            correlationType = CorrelationType.UNPLANNED_ONTIME;
        }
        return createProcessEventDirectory(event.getModelNamespace(), tp, event.getIdAsInternalValue(), null, correlationType);
    }

    private PlannedEvent matchPlannedEvent(TrackedProcess tp, Event event) {
        String eventType = event.getEventType();
        if (isGTTOverdueEvent(eventType)) {
            UUID refPlannedEventUUID = event.getValueAsUUID(OverdueEvent.REF_PLANNED_EVENT_UUID);
            return matchPlannedEvent(tp, refPlannedEventUUID);
        }
        if (isGTTDPPBlockingEvent(eventType)) {
            // There is no matched planned event for DPP blocking event
            return null;
        } else {
            return matchPlannedEventByEvent(tp, event);
        }
    }

    private PlannedEvent matchPlannedEventByEvent(TrackedProcess tp, Event event) {
        List<PlannedEvent> plannedEvents = tp.isValueProvided(TrackedProcess.PLANNED_EVENTS) ? tp.getPlannedEvents() : null;
        if (isOrInheritFrom(event, GTT_DELAYED_EVENT) || isOrInheritFrom(event, GTT_ONTIME_EVENT)) {
            return matchPlannedEvent(tp.getTrackedProcessType(), plannedEvents, event, Tag.REFEVENT);
        } else {
            return matchPlannedEvent(tp.getTrackedProcessType(), plannedEvents, event, Tag.COMMONEVENT);
        }
    }

    private PlannedEvent matchPlannedEvent(String trackedProcessType, List<PlannedEvent> plannedEventsOfTp, ObjectValue objectValue, Tag tag) {
        String eventType;
        String eventMatchKey;
        String locationAltKey;

        if (Tag.PLANNEDEVENT == tag || Tag.COMMONEVENT == tag) {
            eventType = objectValue.getValueAsString(Event.EVENT_TYPE);
            eventMatchKey = MessageUtil.getPropertyValueAsString(objectValue, Event.EVENT_MATCH_KEY);
            locationAltKey = MessageUtil.getPropertyValueAsString(objectValue, Event.LOCATION_ALT_KEY);
        } else {
            eventType = MessageUtil.getPropertyValueAsString(objectValue, Constant.REF_PLANNED_EVENT_TYPE);
            if (StringUtils.isBlank(eventType)) {
                return null;
            }
            eventMatchKey = MessageUtil.getPropertyValueAsString(objectValue, Constant.REF_PLANNED_EVENT_MATCH_KEY);
            locationAltKey = MessageUtil.getPropertyValueAsString(objectValue, Constant.REF_PLANNED_EVENT_LOCATION_ALEKEY);
        }
        MetadataEntityEvent eventConfig = getMetadataManagement().getEntityEvent(trackedProcessType, eventType);
        if (eventConfig == null) {
            return null;
        }
        if (plannedEventsOfTp != null && !plannedEventsOfTp.isEmpty()) {
            List<Triple<Object, String, String>> plannedEventKeyList = buildPlannedEventKeyList(objectValue, tag, eventType, eventMatchKey, locationAltKey, eventConfig);
            return MessageUtil.matchPlannedEvent(plannedEventsOfTp, plannedEventKeyList);
        }
        return null;
    }

    private List<Triple<Object, String, String>> buildPlannedEventKeyList(ObjectValue objectValue, Tag tag, String eventType,
                                                                          String eventMatchKey, String locationAltKey,
                                                                          MetadataEntityEvent eventConfig) {
        List<Triple<Object, String, String>> plannedEventKeyList = new ArrayList<>();
        plannedEventKeyList.add(Triple.of(eventType, Operator.EQUAL.getValue(), PlannedEvent.EVENTTYPE));
        plannedEventKeyList.add(Triple.of(eventMatchKey, Operator.EQUAL.getValue(), PlannedEvent.EVENT_MATCH_KEY));
        boolean locationMatched = eventConfig.isMatchLocation();
        if (locationMatched) {
            plannedEventKeyList.add(Triple.of(locationAltKey, Operator.EQUAL.getValue(), PlannedEvent.LOCATION_ALTKEY));
        }
        Map<String, String> delayedEventFieldMap = new HashMap<>();
        if (Tag.REFEVENT == tag) {
            List<Pair<String, String>> replaceFields = getMetadataManagement().findMatchedExtensionFieldPairs(eventType);
            delayedEventFieldMap = replaceFields.stream().collect(Collectors.toMap(Pair::getRight, Pair::getLeft));
        }
        List<MatchExtensionField> matchExtensionFields = eventConfig.getMatchExtensionFields();
        if (matchExtensionFields != null) {
            for (MatchExtensionField field : matchExtensionFields) {
                if (Tag.PLANNEDEVENT == tag) {
                    String sourceField = field.getSourceField();
                    plannedEventKeyList.add(Triple.of(MessageUtil.getPropertyValue(objectValue, sourceField), field.getOperator(), sourceField));
                } else if (Tag.COMMONEVENT == tag) {
                    String sourceField = field.getSourceField();
                    String targetField = field.getTargetField();
                    plannedEventKeyList.add(Triple.of(MessageUtil.getPropertyValue(objectValue, targetField), field.getOperator(), sourceField));
                } else {
                    String sourceField = field.getSourceField();
                    String targetField = field.getTargetField();
                    String eventField = delayedEventFieldMap.get(targetField);
                    plannedEventKeyList.add(Triple.of(MessageUtil.getPropertyValue(objectValue, eventField), field.getOperator(), sourceField));
                }
            }
        }
        return plannedEventKeyList;
    }

    private PlannedEvent matchPlannedEvent(TrackedProcess tp, UUID refPlannedEventUUID) {
        if (tp.isValueProvided(TrackedProcess.PLANNED_EVENTS)) {
            return MessageUtil.matchPlannedEvent(tp.getPlannedEvents(), refPlannedEventUUID);
        }
        return null;
    }

    private boolean isValidEvent(String trackedProcessType, Event event, PlannedEvent matchedPlannedEvent, Event lastEffectiveEvent) {
        String eventType = event.getEventType();
        if (matchedPlannedEvent == null) {
            if (isGTTDPPBlockingEvent(eventType)) {
                return true;
            } else {
                return getMetadataManagement().checkIfEventIsUnplanned(trackedProcessType, eventType);
            }
        } else if (isGTTOverdueEvent(eventType)) {
            return !matchedPlannedEvent.isReported();
        } else if (isOrInheritFrom(event, GTT_DELAYED_EVENT) || isOrInheritFrom(event, GTT_ONTIME_EVENT)) {
            return !matchedPlannedEvent.isReported() ||
                    (lastEffectiveEvent != null && isBefore(event.getActualBusinessTimestamp(), lastEffectiveEvent.getActualBusinessTimestamp()));
        }
        return true;
    }

    private boolean isOrInheritFrom(Event event, MetadataConstants.CoreModelEntity coreExtendedEvent) {
        String eventFullName = coreExtendedEvent.getFullName();
        String eventType = event.getEventType();
        return eventFullName.equals(eventType) || eventFullName.equals(event.getMetadata().getCurrentEntity().getInheritFromCore());
    }

    private boolean isBefore(Instant first, Instant second) {
        return first != null && second != null && first.isBefore(second);
    }

    private boolean isGTTOverdueEvent(String eventType) {
        return GTT_OVERDUE_EVENT.getFullName().equals(eventType);
    }

    private boolean isGTTDPPBlockingEvent(String eventType) {
        return GTT_DPP_BLOCKING_EVENT.getFullName().equals(eventType);
    }

    private boolean isGTTDPPDeletionEvent(String eventType) {
        return GTT_DPP_DELETION_EVENT.getFullName().equals(eventType);
    }

    private boolean isGTTDeletionEvent(String eventType) {
        return GTT_DELETION_EVENT.getFullName().equals(eventType);
    }

    private boolean isGTTUpdatePlanEvent(String eventType) {
        return GTT_UPDATE_PLAN_EVENT.getFullName().equals(eventType);
    }

    private void processOverdueEvent(MetadataEntityEvent eventConfig, PlannedEvent matchedPlannedEvent) {
        int overdueDetectionCounter = matchedPlannedEvent.getOverdueDetectionCounter() + 1;
        matchedPlannedEvent.setOverdueDetectionCounter(overdueDetectionCounter);
        int maxOverdueDetection = eventConfig.getMaxOverdueDetection();
        if (overdueDetectionCounter < maxOverdueDetection) {
            Duration periodicOverdueDetection = eventConfig.getPeriodicOverdueDetection();
            Instant nextOverdueDetection = matchedPlannedEvent.getNextOverdueDetection()
                    .plus(periodicOverdueDetection.getSeconds(), ChronoUnit.SECONDS);
            matchedPlannedEvent.setNextOverdueDetection(nextOverdueDetection);
        } else {
            matchedPlannedEvent.setNextOverdueDetection(Constant.MAX_TIMESTAMP);
        }
    }

    private EventStatus calculateEventStatus(Instant actualBusinessTimestamp, Instant plannedBizTsEarliest, Instant plannedBizTsLatest) {
        if (actualBusinessTimestamp.isBefore(plannedBizTsEarliest)) {
            return EventStatus.EARLY_REPORTED;
        }
        if (actualBusinessTimestamp.isAfter(plannedBizTsLatest)) {
            return EventStatus.LATE_REPORTED;
        }
        return EventStatus.REPORTED;
    }

    private List<QualifiedTrackingId> manageTrackingId(String namespace, UUID processId,
                                                       List<Reference> references,
                                                       List<QualifiedTrackingId> existedQualifiedTrackingIds) {
        Map<UUID, QualifiedTrackingId> trackingIdMap = new HashMap<>();
        if (existedQualifiedTrackingIds != null) {
            for (QualifiedTrackingId trackingId : existedQualifiedTrackingIds) {
                trackingIdMap.put(trackingId.getObservedProcessId(), trackingId);
            }
        }
        if (references != null) {
            for (Reference ref : references) {
                String altKey = ref.getAltKey();
                UUID observedPID = GTTUtils.UUIDUtils.generateNameBasedUUID(altKey);
                if (!processId.equals(observedPID)) {
                    String action = ref.getAction();
                    if (Action.ADD.toString().equalsIgnoreCase(action)) {
                        QualifiedTrackingId trackingId = buildQualifiedTrackingId(namespace, processId, observedPID, ref.getValidFrom(), ref.getValidTo());
                        trackingIdMap.put(observedPID, trackingId);
                    } else if (Action.DELETE.toString().equalsIgnoreCase(action)
                            && trackingIdMap.containsKey(observedPID)) {
                        trackingIdMap.remove(observedPID);
                    }
                }
            }
        }
        List<QualifiedTrackingId> trackingIds = new ArrayList<>();
        trackingIds.addAll(trackingIdMap.values());
        return trackingIds;
    }

    private QualifiedTrackingId buildQualifiedTrackingId(String namespace,
                                                         UUID processId, UUID observedPID,
                                                         Instant validFrom, Instant validTo) {
        QualifiedTrackingId trackingId = QualifiedTrackingId.build(processId, observedPID, validFrom, validTo);
        String entityName = QUALIFIED_TRACKING_ID.getFullName();
        CurrentMetadataEntity metadata = getMetadataManagement().findAllEntitiesRecursively(namespace, entityName);
        trackingId.setMetadata(metadata);
        return trackingId;
    }

    private void clearPEDOfOnePlannedEvent(List<ProcessEventDirectory> peds, UUID plannedEventId) {
        List<ProcessEventDirectory> removedItems = peds.stream().filter(ped -> plannedEventId.equals(ped.getPlannedEventId())).collect(Collectors.toList());
        peds.removeAll(removedItems);
    }

    private void eventToAction(TrackedProcess oldTP, TrackedProcess trackedProcess, UUID matchedPlannedEventId, Event event) {
        logService.info("begin to do event to action");
        PrintStream printStream = new PrintStream(System.out);
        String namespace = event.getModelNamespace();
        String script = getMetadataManagement().getMetadataProjectFileFieldInfo(namespace, MetadataConstants.MetadataProjectFileField.RULES);
        if (script != null && script.length() > 0) {
            TrackedProcess newTP = getProcessManagement().get(UUIDValue.valueOf(trackedProcess.getIdAsInternalValue()));
            PlannedEvent oldPlannedEvent = pickOnePlannedEventFromTP(oldTP, matchedPlannedEventId);
            PlannedEvent newPlannedEvent = pickOnePlannedEventFromTP(newTP, matchedPlannedEventId);
            //Event already fetch from DB, if fetch here, for deletion event, will get null
            Event eventForEventAction = event;
            String eventType = event.getEventType();
            if (!(isGTTDeletionEvent(eventType) || isGTTDPPDeletionEvent(eventType))) {
                eventForEventAction = getEventManagement().get(event.getId(), event.getMetadata());
            }

            AccessContextHolder.AccessContext accessContext = currentContext.cloneContext();
            Future<String> futureTask = ruleScriptLauncher.execute(script, printStream, oldTP, newTP, oldPlannedEvent, newPlannedEvent, eventForEventAction, accessContext);
            try {
                futureTask.get(TIME_OUT, TimeUnit.MILLISECONDS);
            } catch (InterruptedException e) {
                logService.error(e.getMessage(), e);
                futureTask.cancel(true);
                Thread.currentThread().interrupt();
                throw new GTTEmbededRuleScriptInternalException(0, 0, e.getMessage(), e);
            } catch (ExecutionException e) {
                logService.error(e.getMessage(), e);
                futureTask.cancel(true);
                throw new GTTEmbededRuleScriptInternalException(0, 0, e.getMessage(), e);
            } catch (TimeoutException e) {
                logService.error(e.getMessage(), e);
                futureTask.cancel(true);
                throw new EventToActionRateLimitException(e.getMessage(), e, EventToActionRateLimitException.MESSAGE_CODE_TIMEOUT, new Object[]{TIME_OUT / 1000L});
            } catch (BaseRuntimeException e) {
                logService.error(e.getMessage(), e);
                futureTask.cancel(true);
                throw e;
            }
        }
    }

    private PlannedEvent pickOnePlannedEventFromTP(TrackedProcess trackedProcess, UUID plannedEventId) {
        if (trackedProcess == null) {
            return null;
        }
        if (plannedEventId == null) {
            return null;
        }
        if (!trackedProcess.isValueProvided(TrackedProcess.PLANNED_EVENTS)) {
            return null;
        }
        Optional<PlannedEvent> plannedEventFound = trackedProcess.getPlannedEvents().stream().filter(plannedEvent -> plannedEvent.getId().equals(plannedEventId)).findAny();
        return plannedEventFound.isPresent() ? plannedEventFound.get() : null;
    }

    private void insertExecutionMessage(String executionHistoryId, String phase, String status, Instant errorTime, BaseRuntimeException e) {
        ExecutionMessageDto executionMessageDto = new ExecutionMessageDto();
        executionMessageDto.setExecutionHistoryId(executionHistoryId);
        executionMessageDto.setPhase(phase);
        executionMessageDto.setMessageType(status);
        executionMessageDto.setErrorAt(errorTime);
        executionMessageDto.setMessage(e.getErrorCode());
        executionMessageDto.setDetail(e.getLocalizedMessage(SystemConstants.DEFAULT_LOCALE));
        getExecutionHistoryManagement().insertExecutionMessage(executionMessageDto);
    }

    private IMetadataManagement getMetadataManagement() {
        return currentContext.createBusinessOperator().getMetadataManagement();
    }

    private ITrackedProcessManagement getProcessManagement() {
        return currentContext.createBusinessOperator().getTrackedProcessManagement();
    }

    private IEventManagement getEventManagement() {
        return currentContext.createBusinessOperator().getEventManagement();
    }

    private IMessageLogManagement getExecutionHistoryManagement() {
        return currentContext.createBusinessOperator().getMessageLogManagement();
    }

    private enum Tag {
        PLANNEDEVENT, COMMONEVENT, REFEVENT;
    }
}
