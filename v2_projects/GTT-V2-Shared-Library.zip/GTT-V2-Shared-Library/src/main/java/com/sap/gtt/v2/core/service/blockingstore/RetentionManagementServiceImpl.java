/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.gtt.v2.core.service.blockingstore;

import com.sap.gtt.v2.configuration.GTTRestTemplate;
import com.sap.gtt.v2.core.domain.blockingstore.ApplicationNameDto;
import com.sap.gtt.v2.core.domain.blockingstore.ApplicationNamesDto;
import java.util.Arrays;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

/**
 *
 * @author I326335
 */
public class RetentionManagementServiceImpl implements RetentionManagementService {

    @Autowired
    private GTTRestTemplate restTemplate;
    
    @Override
    public void createApplicationNames(List<String> applicationNames) {
        callRetentionManagement(HttpMethod.POST, applicationNames);
    }

    @Override
    public void deleteApplicationName(List<String> applicationNames) {
        callRetentionManagement(HttpMethod.DELETE, applicationNames);
    }
    
    private ResponseEntity<String> callRetentionManagement(HttpMethod httpMethod, List<String> applicationNames) {
        String url = "";
        ApplicationNamesDto applicationNamesDto = new ApplicationNamesDto();
        applicationNames.stream().forEach(applicationName -> {
            ApplicationNameDto applicationNameDto = new ApplicationNameDto();
            applicationNameDto.setApplicationName(applicationName);
            applicationNamesDto.getApplicationNames().add(applicationNameDto);
        });
        
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON_UTF8));
        HttpEntity requestEntity = new HttpEntity(applicationNamesDto);
        
        return restTemplate.exchange(url, httpMethod, headers, requestEntity, String.class);
    }
}
