package com.sap.gtt.v2.core.dao.execution;

import com.sap.gtt.v2.core.entity.execution.CorrelatedTrackedProcess;
import com.sap.gtt.v2.util.DBUtils;
import com.sap.gtt.v2.util.SpringContextUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

/**
 * @author I302310
 */
@Repository(DefaultCorrelatedTrackedProcessDao.BEAN_NAME)
public class DefaultCorrelatedTrackedProcessDao implements ICorrelatedTrackedProcessDao {
    public static final String BEAN_NAME = "com.sap.gtt.v2.core.dao.execution.DefaultCorrelatedTrackedProcessDao";
    public static final String TABLE_NAME = "CORRELATED_TRACKED_PROCESS";

    public static final String ID = "ID";
    public static final String EXECUTION_ID = "EXECUTION_ID";
    public static final String CORRELATED_TP_ID = "CORRELATED_TP_ID";
    public static final String CORRELATED_TP_ALTKEY = "CORRELATED_TP_ALTKEY";

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public static DefaultCorrelatedTrackedProcessDao getInstance() {
        return (DefaultCorrelatedTrackedProcessDao) SpringContextUtils.getBean(BEAN_NAME);
    }

    @Override
    public void insert(List<CorrelatedTrackedProcess> trackedProcesses) {
        StringBuilder sql = new StringBuilder();
        String[] columns = {ID, EXECUTION_ID, CORRELATED_TP_ID, CORRELATED_TP_ALTKEY};
        DBUtils.buildInsertSql(TABLE_NAME, columns, sql);
        List<Object[]> argList = new ArrayList<>();
        for (CorrelatedTrackedProcess trackedProcess : trackedProcesses) {
            Object[] args = new Object[]{trackedProcess.getId(), trackedProcess.getExecutionId(),
                    trackedProcess.getCorrelatedTpId(), trackedProcess.getCorrelatedTpAltkey()};
            argList.add(args);
        }
        jdbcTemplate.batchUpdate(sql.toString(), argList);
    }

    @Override
    public List<CorrelatedTrackedProcess> query(String executionId) {
        List<String> args = new ArrayList<>();
        args.add(executionId);
        StringBuilder sql = new StringBuilder();
        sql.append("select * from ").append(TABLE_NAME)
                .append(" where ")
                .append(EXECUTION_ID).append("=?");
        return jdbcTemplate.query(sql.toString(), args.toArray(), (rs, rowNum) -> {
            String rs_id = rs.getString(ID);
            String rs_executionId = rs.getString(EXECUTION_ID);
            String rs_correlatedTpId = rs.getString(CORRELATED_TP_ID);
            String rs_correlatedTpAltkey = rs.getString(CORRELATED_TP_ALTKEY);
            return new CorrelatedTrackedProcess(rs_id, rs_executionId, rs_correlatedTpId, rs_correlatedTpAltkey);
        });
    }
}
