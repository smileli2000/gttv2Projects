package com.sap.gtt.v2.core.entity.trackedprocess;

import com.sap.gtt.v2.core.domain.metadata.MetadataConstants.CoreModelEntity;

import java.util.UUID;

public class OverdueEvent extends Event {
    
    public static final String REF_PLANNED_EVENT_UUID = "refPlannedEventUUID";
    private String trackedProcessType;
    
    public OverdueEvent(){
        super();
        this.setEventType(CoreModelEntity.GTT_OVERDUE_EVENT.getFullName());
    }

    public UUID getRefPlannedEventUUID() {
        return this.getValueAsUUID(REF_PLANNED_EVENT_UUID);
    }

    public void setRefPlannedEventUUID(UUID refPlannedEventUUID) {
        this.setValue(REF_PLANNED_EVENT_UUID, refPlannedEventUUID);
    }

    public String getTrackedProcessType() {
        return trackedProcessType;
    }

    public void setTrackedProcessType(String trackedProcessType) {
        this.trackedProcessType = trackedProcessType;
    }
}
