package com.sap.gtt.v2.core.rule.impl;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

import com.sap.gtt.v2.exception.*;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.ParserRuleContext;
import org.antlr.v4.runtime.RuleContext;
import org.antlr.v4.runtime.Token;
import org.antlr.v4.runtime.tree.ParseTree;
import org.antlr.v4.runtime.tree.RuleNode;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sap.gtt.v2.core.rule.GTTEmbededRuleScriptBaseVisitor;
import com.sap.gtt.v2.core.rule.GTTEmbededRuleScriptParser.ArrayLiteralContext;
import com.sap.gtt.v2.core.rule.GTTEmbededRuleScriptParser.BoolAndContext;
import com.sap.gtt.v2.core.rule.GTTEmbededRuleScriptParser.BoolEqContext;
import com.sap.gtt.v2.core.rule.GTTEmbededRuleScriptParser.BoolGeContext;
import com.sap.gtt.v2.core.rule.GTTEmbededRuleScriptParser.BoolGtContext;
import com.sap.gtt.v2.core.rule.GTTEmbededRuleScriptParser.BoolLeContext;
import com.sap.gtt.v2.core.rule.GTTEmbededRuleScriptParser.BoolLiteralContext;
import com.sap.gtt.v2.core.rule.GTTEmbededRuleScriptParser.BoolLtContext;
import com.sap.gtt.v2.core.rule.GTTEmbededRuleScriptParser.BoolNotEqContext;
import com.sap.gtt.v2.core.rule.GTTEmbededRuleScriptParser.BoolOrContext;
import com.sap.gtt.v2.core.rule.GTTEmbededRuleScriptParser.BoolReverseContext;
import com.sap.gtt.v2.core.rule.GTTEmbededRuleScriptParser.DecimalLiteralContext;
import com.sap.gtt.v2.core.rule.GTTEmbededRuleScriptParser.DeclarationContext;
import com.sap.gtt.v2.core.rule.GTTEmbededRuleScriptParser.ElseIfStatementContext;
import com.sap.gtt.v2.core.rule.GTTEmbededRuleScriptParser.ElseStatementContext;
import com.sap.gtt.v2.core.rule.GTTEmbededRuleScriptParser.ExecutionBlockContext;
import com.sap.gtt.v2.core.rule.GTTEmbededRuleScriptParser.ExprContext;
import com.sap.gtt.v2.core.rule.GTTEmbededRuleScriptParser.ExprParensContext;
import com.sap.gtt.v2.core.rule.GTTEmbededRuleScriptParser.FunctionCallContext;
import com.sap.gtt.v2.core.rule.GTTEmbededRuleScriptParser.IdentifierAssignContext;
import com.sap.gtt.v2.core.rule.GTTEmbededRuleScriptParser.IfStatementContext;
import com.sap.gtt.v2.core.rule.GTTEmbededRuleScriptParser.IntegerLiteralContext;
import com.sap.gtt.v2.core.rule.GTTEmbededRuleScriptParser.MathAddSubContext;
import com.sap.gtt.v2.core.rule.GTTEmbededRuleScriptParser.MathMulDivContext;
import com.sap.gtt.v2.core.rule.GTTEmbededRuleScriptParser.MathPowContext;
import com.sap.gtt.v2.core.rule.GTTEmbededRuleScriptParser.MathUnitaryContext;
import com.sap.gtt.v2.core.rule.GTTEmbededRuleScriptParser.NullLiteralContext;
import com.sap.gtt.v2.core.rule.GTTEmbededRuleScriptParser.PrintStatementContext;
import com.sap.gtt.v2.core.rule.GTTEmbededRuleScriptParser.QualifiedNameContext;
import com.sap.gtt.v2.core.rule.GTTEmbededRuleScriptParser.ReferAssignContext;
import com.sap.gtt.v2.core.rule.GTTEmbededRuleScriptParser.ReferContext;
import com.sap.gtt.v2.core.rule.GTTEmbededRuleScriptParser.ReturnStatementContext;
import com.sap.gtt.v2.core.rule.GTTEmbededRuleScriptParser.StringLiteralContext;
import com.sap.gtt.v2.core.rule.GTTEmbededRuleScriptParser.WhileStatementContext;
import com.sap.gtt.v2.core.runtime.model.BooleanValue;
import com.sap.gtt.v2.core.runtime.model.DecimalValue;
import com.sap.gtt.v2.core.runtime.model.IPropertyValue;
import com.sap.gtt.v2.core.runtime.model.IntegerValue;
import com.sap.gtt.v2.core.runtime.model.ListValue;
import com.sap.gtt.v2.core.runtime.model.NullValue;
import com.sap.gtt.v2.core.runtime.model.ObjectValue;
import com.sap.gtt.v2.core.runtime.model.StringValue;

public class GTTEmbededRuleScriptVisitorImpl extends GTTEmbededRuleScriptBaseVisitor<IPropertyValue>{

	public static final String ERROR_NULL_VALUE = "Operating on null value";
	public static final String MATH_UNITARY_OP_NOT_SUPPORT = "Math Unitary '%s' not support";
	public static final String MATH_BINARY_OP_NOT_SUPPORT = "Math Binary op '%s' not support";
	public static final String EXPECTING_BOOLEAN_VALUE = "Expecting boolean value instead of type '%s' with value '%s'";
	public static final String ARRAY_INDEX_MUST_BE_INT = "Expecting integer value instead of type '%s' with value '%s' when indexing";
	public static final String EXPECTING_OBJECT_VALUE = "Expecting object value instead of type '%s' with value '%s'";
	public static final String EXPECTING_LIST_VALUE = "Expecting list value instead of type '%s' with value '%s'";
	public static final String VAR_NOT_LIST_VALUE = "Host variable '%s' should be a 'ListValue' instead of '%s'.";
	public static final String VAR_NOT_OBJECT_VALUE = "Host variable '%s' should be a 'ObjectValue' instead of '%s'.";
	public static final String WHILE_LOOP_EXCEED_LIMIT = "While loop exceed limit of '%s'";

	

	private MemoryBlock variables = MemoryBlock.createInstance();
	
	private CommonTokenStream tokens;
	
	private PrintStream printStream;
	
	protected Logger logger = LoggerFactory.getLogger(GTTEmbededRuleScriptVisitorImpl.class);

	
	public GTTEmbededRuleScriptVisitorImpl(CommonTokenStream tokens, PrintStream printStream){
		this.tokens = tokens;
		this.printStream = printStream;
	}

	protected void setSystemVariable(String varName, IPropertyValue value){
		try{
			variables.declareVariable(varName);
			if(value != null){
				variables.setVariableValue(varName, value);
			}
		}
		catch (MemoryBlockException e) {
			throw new GTTEmbededRuleScriptInternalException(0, 0, e.getMessage(), e);
		}
	}

	@Override
	public IPropertyValue visitWhileStatement(WhileStatementContext ctx){
		BooleanValue whileConditionValue = this.getBooleanExprValue(ctx.expr());
		int count = 0;
		final int LOOP_LIMIT = 100;
		while(whileConditionValue.getInternalValue()){
			if(count++ >= LOOP_LIMIT){
				throw this.generateRuntimeError(ctx,String.format(WHILE_LOOP_EXCEED_LIMIT, LOOP_LIMIT),null);
			}
			this.visit(ctx.executionBlock());
			whileConditionValue = this.getBooleanExprValue(ctx.expr());
		}
		return null;
	}

	@Override
	public IPropertyValue visitDeclaration(DeclarationContext ctx) {
		String variableName = ctx.IDENTIFIER().getText();
		try {
			variables.declareVariable(variableName);
		} catch (MemoryBlockException e) {
			throw this.generateRuntimeError(ctx, e.getMessage(), e);
		}
		
		// assign value if provided
		if(ctx.expr() != null){
			IPropertyValue value = this.visit(ctx.expr());
			try {
				variables.setVariableValue(variableName, value);
			} catch (MemoryBlockException e) {
				throw this.generateRuntimeError(ctx, e.getMessage(), e);
			}
		}
		
		return null;
		
	}

	

	@Override
	public IPropertyValue visitFunctionCall(FunctionCallContext ctx) {
		IPropertyValue mainObject = this.variables;
		if(ctx.qualifiedName() != null){
			mainObject = this.visit(ctx.qualifiedName());
		}
		
		String functionName = ctx.IDENTIFIER().getText();
		List<IPropertyValue> args = new ArrayList<>();
		for(ExprContext exprContext : ctx.expr()){
			args.add(this.visit(exprContext));
		}
		return mainObject.callFunction(functionName, args);
	}

	@Override
	public IPropertyValue visitReferAssign(ReferAssignContext ctx){
		IPropertyValue qualifiedNameResult = this.visitQualifiedName(ctx.qualifiedName());
		IPropertyValue referValue = this.getNoneNullExprValue(ctx.refer());
		if(referValue instanceof StringValue){
			try{
				((ObjectValue) qualifiedNameResult).setValue(referValue.getInternalValue().toString(),this.getNoneNullExprValue(ctx.expr()));
			} catch (ClassCastException e){
				throw new OperationNotAllowed(String.format(VAR_NOT_OBJECT_VALUE, ctx.qualifiedName().getText(), qualifiedNameResult.getClass().getSimpleName()));
			}
		}else if(referValue instanceof IntegerValue){
			try{
				((ListValue) qualifiedNameResult).set((Integer) referValue.getInternalValue(), this.getNoneNullExprValue(ctx.expr()));
			}
			catch (ClassCastException e) {
				throw new OperationNotAllowed(String.format(VAR_NOT_LIST_VALUE, ctx.qualifiedName().getText(), qualifiedNameResult.getClass().getSimpleName()));
			}
		}
		return null ;
	}

	@Override
	public IPropertyValue visitIdentifierAssign(IdentifierAssignContext ctx){
		String variableName = ctx.IDENTIFIER().getText();
		IPropertyValue value = this.getNoneNullExprValue(ctx.expr());
		try {
			variables.setVariableValue(variableName, value);
		} catch (MemoryBlockException e) {
			throw this.generateRuntimeError(ctx, e.getMessage(), e);
		}
		return null ;

	}

	@Override
	public IPropertyValue visitArrayLiteral(ArrayLiteralContext ctx) {
		List<ExprContext> exprs = ctx.expr();
		List<IPropertyValue> values = new ArrayList<>();
		for(ExprContext expr : exprs){
			values.add(this.getNoneNullExprValue(expr));
		}
		
		return ListValue.valueOf(values);
		
	}


	

	@Override
	public IPropertyValue visitExprParens(ExprParensContext ctx) {
		return this.getNoneNullExprValue(ctx.expr());
	}


	

	@Override
	public IPropertyValue visitBoolReverse(BoolReverseContext ctx) {
		BooleanValue value = this.getBooleanExprValue(ctx.expr());
		return value.not();
	}



	@Override
	public IPropertyValue visitBoolGe(BoolGeContext ctx) {
		
		IPropertyValue v1 = this.getNoneNullExprValue(ctx.expr(0));
		IPropertyValue v2 = this.getNoneNullExprValue(ctx.expr(1));
		return v1.greaterEquals(v2);
		
	}



	@Override
	public IPropertyValue visitBoolOr(BoolOrContext ctx) {
		BooleanValue v1 = this.getBooleanExprValue(ctx.expr(0));
		if(v1.getInternalValue()) return BooleanValue.TRUE;
		
		BooleanValue v2 = this.getBooleanExprValue(ctx.expr(1));
		return v1.or(v2);
	}



	@Override
	public IPropertyValue visitBoolNotEq(BoolNotEqContext ctx) {
		IPropertyValue v1 = this.getNoneNullExprValue(ctx.expr(0));
		IPropertyValue v2 = this.getNoneNullExprValue(ctx.expr(1));
		
		return v1.semanticNotEquals(v2);
	}



	@Override
	public IPropertyValue visitBoolLe(BoolLeContext ctx) {
		IPropertyValue v1 = this.getNoneNullExprValue(ctx.expr(0));
		IPropertyValue v2 = this.getNoneNullExprValue(ctx.expr(1));
		
		return v1.lessEquals(v2);
	}



	@Override
	public IPropertyValue visitBoolAnd(BoolAndContext ctx) {
		BooleanValue v1 = this.getBooleanExprValue(ctx.expr(0));
		if(!v1.getInternalValue()) return BooleanValue.FALSE;
		
		BooleanValue v2 = this.getBooleanExprValue(ctx.expr(1));
		return v1.and(v2);
	}



	@Override
	public IPropertyValue visitBoolLt(BoolLtContext ctx) {
		IPropertyValue v1 = this.getNoneNullExprValue(ctx.expr(0));
		IPropertyValue v2 = this.getNoneNullExprValue(ctx.expr(1));
		
		return v1.lessThan(v2);
	}



	@Override
	public IPropertyValue visitBoolGt(BoolGtContext ctx) {
		IPropertyValue v1 = this.getNoneNullExprValue(ctx.expr(0));
		IPropertyValue v2 = this.getNoneNullExprValue(ctx.expr(1));
		
		return v1.greaterThan(v2);
	}



	@Override
	public IPropertyValue visitIfStatement(IfStatementContext ctx) {
		BooleanValue ifConditionValue = this.getBooleanExprValue(ctx.expr());
		if(ifConditionValue.getInternalValue()){
			// execute if block
			this.visit(ctx.executionBlock());
			return ifConditionValue;
		}
		else{
			// check else if
			List<ElseIfStatementContext> elseIfStatementContexts = ctx.elseIfStatement();
			for(ElseIfStatementContext elseIfStatementContext : elseIfStatementContexts){
				BooleanValue elseIfConditionValue = (BooleanValue)this.visitElseIfStatement(elseIfStatementContext);
				if(elseIfConditionValue.getInternalValue()){
					// stop here
					return elseIfConditionValue;
				}
			}
			
			// check else
			ElseStatementContext elseStatementContext = ctx.elseStatement();
			if(elseStatementContext == null) return BooleanValue.FALSE;
			return (BooleanValue)this.visitElseStatement(elseStatementContext);
		}
	}

	
	@Override
	public IPropertyValue visitMathUnitary(MathUnitaryContext ctx) {
		
		IPropertyValue result = this.getNoneNullExprValue(ctx.expr());
		String op = ctx.op.getText();
		
		if(StringUtils.equals(op,"+")){
			return result;
		}
		else if(StringUtils.equals(op,"-")){
			return result.negate();
		}
		else{
			throw this.generateInternalError(ctx, String.format(MATH_UNITARY_OP_NOT_SUPPORT, op), null);
			
		}
	}


	@Override
	public IPropertyValue visitMathAddSub(MathAddSubContext ctx) {
		String op = ctx.op.getText();
		IPropertyValue n1 = this.getNoneNullExprValue(ctx.expr(0));
		IPropertyValue n2 = this.getNoneNullExprValue(ctx.expr(1));
		
		if(StringUtils.equals(op, "+")){
			return n1.plus(n2);
		}
		else if(StringUtils.equals(op, "-")){
			return n1.sub(n2);
		}
		else{
			throw this.generateInternalError(ctx, String.format(MATH_BINARY_OP_NOT_SUPPORT, op), null);
			
		}
		
	}

	@Override
	public IPropertyValue visitMathMulDiv(MathMulDivContext ctx) {
		String op = ctx.op.getText();
		IPropertyValue n1 = this.getNoneNullExprValue(ctx.expr(0));
		IPropertyValue n2 = this.getNoneNullExprValue(ctx.expr(1));
		
		if(StringUtils.equals(op, "*")){
			return n1.mul(n2);
		}
		else if(StringUtils.equals(op, "/")){
			return n1.div(n2);
		}
		else{
			throw this.generateInternalError(ctx, String.format(MATH_BINARY_OP_NOT_SUPPORT, op), null);
			
		}
	}

	@Override
	public IPropertyValue visitMathPow(MathPowContext ctx) {
		IPropertyValue n1 = this.getNoneNullExprValue(ctx.expr(0));
		IPropertyValue n2 = this.getNoneNullExprValue(ctx.expr(1));
		
		return n1.pow(n2);
	}


	
	@Override
	public IPropertyValue visitBoolEq(BoolEqContext ctx) {
		IPropertyValue left = this.getNoneNullExprValue(ctx.expr(0));
		IPropertyValue right = this.getNoneNullExprValue(ctx.expr(1));
		
		return left.semanticEquals(right);
	}	
	
	@Override
	public IPropertyValue visitIntegerLiteral(IntegerLiteralContext ctx) {
		return IntegerValue.valueOf(ctx.INTEGER_LITERAL().getText());
	}

	
	@Override
	public IPropertyValue visitDecimalLiteral(DecimalLiteralContext ctx) {
		return DecimalValue.valueOf(ctx.DECIMAL_LITERAL().getText());
	}



	@Override
	public IPropertyValue visitBoolLiteral(BoolLiteralContext ctx) {
		return BooleanValue.valueOf((ctx.BOOLEAN_LITERAL().getText()));
	}



	@Override
	public IPropertyValue visitStringLiteral(StringLiteralContext ctx) {
		String literal = ctx.STRING_LITERAL().getText();
		// remove first and last boundary
		String value = StringUtils.substring(literal, 1, literal.length()-1);
		
		// replace \\ to \
		value = StringUtils.replace(value, "\\\\", "\\");
				
		// replace \" to "
		value = StringUtils.replace(value, "\\\"", "\"");
		
		// replace \t to tab
		value = StringUtils.replace(value, "\\t", "\t");
		
		// replace \r\n to enter
		value = StringUtils.replace(value, "\\r", "\r");
		
		// replace \r\n to enter
		value = StringUtils.replace(value, "\\n", "\n");
				
		return StringValue.valueOf(value);
	}



	@Override
	public IPropertyValue visitNullLiteral(NullLiteralContext ctx) {
		return NullValue.NULL;
	}



	@Override
	public IPropertyValue visitPrintStatement(PrintStatementContext ctx) {
		IPropertyValue result = this.getNoneNullExprValue(ctx.expr());
		printStream.println(result);
		return result;
	}

	
	@Override
	public IPropertyValue visitRefer(ReferContext ctx) {
		if(ctx.expr() != null){
			IPropertyValue result = this.getNoneNullExprValue(ctx.expr());
			if(!(result instanceof IntegerValue)){
				throw new OperationNotAllowed(String.format(ARRAY_INDEX_MUST_BE_INT, result.getClass().getName(), result));
			}
			return result;
		}
		else if(ctx.IDENTIFIER() != null){
			return StringValue.valueOf(ctx.IDENTIFIER().getText());
		}
		else{
			throw new UnsupportedOperationException();
		}
	}


	@Override
	public IPropertyValue visitQualifiedName(QualifiedNameContext ctx) {
		IPropertyValue result = this.variables;
		String identifier = ctx.IDENTIFIER().getText();
		result = ((ObjectValue)result).getValue(identifier);
		for(int i = 0; i< ctx.refer().size();i++){
			IPropertyValue referValue = this.getNoneNullExprValue(ctx.refer(i));
			if(referValue instanceof StringValue){
				if(!(result instanceof ObjectValue)){
					throw new OperationNotAllowed(String.format(EXPECTING_OBJECT_VALUE, result.getClass().getName(),result));
				}
				String propertyName = ((StringValue)referValue).getInternalValue();
				result = ((ObjectValue)result).getValue(propertyName);
			}
			else if(referValue instanceof IntegerValue){
				if(!(result instanceof ListValue)){
					throw new OperationNotAllowed(String.format(EXPECTING_LIST_VALUE, result.getClass().getName(),result));
				}
				ListValue listValue = (ListValue)result;
				result = listValue.get(((IntegerValue)referValue).getInternalValue());
			}
		}
		
		return result;
	}


	@Override
	public IPropertyValue visitElseIfStatement(ElseIfStatementContext ctx) {
		BooleanValue elseIfConditionValue = this.getBooleanExprValue(ctx.expr());
		if(elseIfConditionValue.getInternalValue()){
			// execute else if block
			this.visit(ctx.executionBlock());
		}
		return elseIfConditionValue;
	}


	@Override
	public IPropertyValue visitElseStatement(ElseStatementContext ctx) {
		this.visit(ctx.executionBlock());
		return BooleanValue.TRUE;
	}


	@Override
	public IPropertyValue visitReturnStatement(ReturnStatementContext ctx) {
		
		IPropertyValue returnedValue = NullValue.NULL;
		if(ctx.expr() != null) {
			returnedValue = this.getNoneNullExprValue(ctx.expr());
		}
		
		this.variables.setReturnedValue(returnedValue);
		return returnedValue;
	}


	@Override
	protected boolean shouldVisitNextChild(RuleNode node, IPropertyValue currentResult) {
		if(this.variables.getReturnedValue() != null){
			//returned
			return false;
		}
		else{
			return true;
		}
	}

	@Override
	public IPropertyValue visitExecutionBlock(ExecutionBlockContext ctx) {
		// TODO Auto-generated method stub
		return super.visitExecutionBlock(ctx);
	}


	protected BooleanValue getBooleanExprValue(ExprContext expr){
		
		IPropertyValue value = this.getNoneNullExprValue(expr);
		
		if(isBoolean(value)) return (BooleanValue)value;
		else{
			throw this.generateRuntimeError(expr, String.format(EXPECTING_BOOLEAN_VALUE, value.getClass().getName(), value), null);
		}
		
		
	}
	
	protected IPropertyValue getNoneNullExprValue(RuleContext expr){
		IPropertyValue value = this.visit(expr);
		if(value == null) 
			throw this.generateInternalError(expr,ERROR_NULL_VALUE, null);
		return value;
	}
	
	@Override
	public IPropertyValue visit(ParseTree tree) {
		try{
			IPropertyValue result = super.visit(tree);
			return result;
		}
		catch(GTTEmbededRuleScriptException | GTTEmbededRuleScriptInternalException e){
			// avoid recursively throw
			throw e;
		}
		catch(InternalErrorException e){
			throw this.generateInternalError(tree,e.getMessage(), e);
		}
		catch(BaseRuntimeException e){
			throw this.generateRuntimeError(tree,e.getMessage() , e);
		}
	}
	
	
	
	public static boolean isBoolean(IPropertyValue v){
		return (v instanceof BooleanValue);
	}
	
	
	 
	protected GTTEmbededRuleScriptException generateRuntimeError(ParserRuleContext ctx, String msg, Throwable cause){
		Token token = this.tokens.get(ctx.getSourceInterval().a);
		return this.generateRuntimeError(token, msg, cause);
	}
	
	protected GTTEmbededRuleScriptException generateRuntimeError(ParseTree tree, String msg, Throwable cause){
		Token token = this.tokens.get(tree.getSourceInterval().a);
		return this.generateRuntimeError(token, msg, cause);
	}
	
	protected GTTEmbededRuleScriptException generateRuntimeError(Token token, String msg, Throwable cause){
		if(token != null){
			return new GTTEmbededRuleScriptException(token.getLine(), token.getCharPositionInLine(),msg, cause);
		}
		else{
			return new GTTEmbededRuleScriptException(0, 0,msg, cause);
		}
	}
	
	
	protected GTTEmbededRuleScriptInternalException generateInternalError(ParserRuleContext ctx, String msg, Throwable cause){
		Token token = this.tokens.get(ctx.getSourceInterval().a);
		return this.generateInternalError(token, msg, cause);
	}
	
	protected GTTEmbededRuleScriptInternalException generateInternalError(ParseTree tree, String msg, Throwable cause){
		Token token = this.tokens.get(tree.getSourceInterval().a);
		return this.generateInternalError(token, msg, cause);
	}
	
	protected GTTEmbededRuleScriptInternalException generateInternalError(Token token, String msg, Throwable cause){
		if(token != null){
			return new GTTEmbededRuleScriptInternalException(token.getLine(), token.getCharPositionInLine(),msg, cause);
		}
		else{
			return new GTTEmbededRuleScriptInternalException(0, 0,msg, cause);
		}
	}
}
