package com.sap.gtt.v2.core.runtime.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.sap.gtt.v2.core.rule.impl.MemoryBlockException;
import com.sap.gtt.v2.exception.GTTEmbededRuleScriptInternalException;
import com.sap.gtt.v2.exception.OperationNotAllowed;

public abstract class AbstractPropertyValue<T> implements IPropertyValue, Comparable<IPropertyValue>{
	
	private T internalValue;
	
	private static final String FUNCTION_TO_STRING = "toString";
	
	protected static final Map<String, FunctionInterfaceDef> functionDefs = new HashMap<>();
	

	static{
		List<Class<? extends IPropertyValue>> toStringArgumentTypes = new ArrayList<>();
		
		FunctionInterfaceDef toStringDef = new FunctionInterfaceDef(
				FunctionInterfaceDef.Category.SYSTEM, FUNCTION_TO_STRING, toStringArgumentTypes,
				new IFunction(){

					@Override
					public IPropertyValue execute(IPropertyValue callerObject, List<IPropertyValue> args)
							throws MemoryBlockException {
						return StringValue.valueOf(callerObject.toString());
					}
					
				});
		functionDefs.put(toStringDef.name, toStringDef);
	}
	protected AbstractPropertyValue(T internalValue){
		this.internalValue = internalValue;
	}
	@Override
	public T getInternalValue(){
		return internalValue;
	}

	public void setInternalValue(T internalValue){
		this.internalValue = internalValue;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((internalValue == null) ? 0 : internalValue.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AbstractPropertyValue other = (AbstractPropertyValue) obj;
		if (internalValue == null) {
			if (other.internalValue != null)
				return false;
		} 
		else if (!internalValue.equals(other.internalValue))
			return false;
		
		return true;
	}
	@Override
	public String toString() {
		return internalValue == null? null : internalValue.toString();
	}
	
	protected void generalInputCheck(IPropertyValue that){
		if(that == null) throw new OperationNotAllowed(ERROR_OPERATE_ON_NULL);
		if (getClass() != that.getClass())
			throw new OperationNotAllowed(String.format(ERROR_IMCOMPATIBLE_DATA_TYPE, this.getClass().getSimpleName(),
					that.getClass().getSimpleName()));
	
	}
	
	@Override
	public BooleanValue greaterEquals(IPropertyValue that) {
		return (this.compareTo(that) >= 0) ? BooleanValue.TRUE:BooleanValue.FALSE;

	}

	
	@Override
	public BooleanValue greaterThan(IPropertyValue that) {
		return (this.compareTo(that) > 0) ? BooleanValue.TRUE:BooleanValue.FALSE;
		
	}

	@Override
	public BooleanValue lessThan(IPropertyValue that) {
		return (this.compareTo(that) < 0) ? BooleanValue.TRUE:BooleanValue.FALSE;
	}

	@Override
	public BooleanValue lessEquals(IPropertyValue that) {
		return (this.compareTo(that) <= 0) ? BooleanValue.TRUE:BooleanValue.FALSE;
	}

	@Override
	public BooleanValue semanticEquals(IPropertyValue that) {
		BooleanValue result = this.semanticEqualsInvolveNullValue(that);
		if(result != null) return result;
		return (this.getInternalValue().equals(that.getInternalValue())) ? BooleanValue.TRUE : BooleanValue.FALSE;
	}
	
	protected BooleanValue semanticEqualsInvolveNullValue(IPropertyValue that){
		if(this instanceof NullValue && that instanceof NullValue){
			return BooleanValue.TRUE;
		}
		if(that instanceof NullValue){
			return BooleanValue.FALSE;
		}
		if(this instanceof NullValue && that != null){
			return BooleanValue.FALSE;
		}
		return null;
	}
	
	@Override
	public BooleanValue semanticNotEquals(IPropertyValue that) {
		if(semanticEquals(that).getInternalValue()){
			return BooleanValue.FALSE;
		}
		else{
			return BooleanValue.TRUE;
		}
	}
	
	@Override
	public IPropertyValue plus(IPropertyValue that) {
		this.generalInputCheck(that);
		return this.addInternal(that);
	}
	
	protected IPropertyValue addInternal(IPropertyValue that) {
		return IPropertyValue.super.plus(that);
	} 
	
	@Override
	public IPropertyValue sub(IPropertyValue that) {
		this.generalInputCheck(that);
		return this.subInternal(that);
	}

	protected IPropertyValue subInternal(IPropertyValue that) {
		return IPropertyValue.super.sub(that);
	}
	
	
	@Override
	public IPropertyValue mul(IPropertyValue that) {
		this.generalInputCheck(that);
		return this.mulInternal(that);
	}
	
	protected IPropertyValue mulInternal(IPropertyValue that) {
		return IPropertyValue.super.mul(that);
	}
	
	@Override
	public IPropertyValue div(IPropertyValue that) {
		this.generalInputCheck(that);
		return this.divInternal(that);
	}

	protected IPropertyValue divInternal(IPropertyValue that) {
		return IPropertyValue.super.div(that);
	}
	
	@Override
	public IPropertyValue pow(IPropertyValue that) {
		this.generalInputCheck(that);
		return this.powInternal(that);
	}

	protected IPropertyValue powInternal(IPropertyValue that) {
		return IPropertyValue.super.pow(that);
	}
	
	@Override
	public IPropertyValue negate() {
		return this.negateInternal();
	}
	
	protected IPropertyValue negateInternal() {
		return IPropertyValue.super.negate();
	}
	
	@Override
    public BooleanValue or(IPropertyValue that){
    	this.generalInputCheck(that);
    	return this.orInternal(that);
    }
	
    protected BooleanValue orInternal(IPropertyValue that){
    	return IPropertyValue.super.or(that);
    }
    
	@Override
    public BooleanValue and(IPropertyValue that){
    	this.generalInputCheck(that);
    	return this.andInternal(that);
    }
    
    protected BooleanValue andInternal(IPropertyValue that){
		return IPropertyValue.super.and(that);
    }
	
	@Override
    public BooleanValue not(){
    	return this.notInternal();
    }
	
    protected BooleanValue notInternal(){
		return IPropertyValue.super.not();
    }
	
	@Override
	public int compareTo(IPropertyValue that) {
		this.generalInputCheck(that);
		return this.compareToInternal(that);
	}
	
	protected int compareToInternal(IPropertyValue that) {
		throw new OperationNotAllowed(String.format(ERROR_OPERATE_NOT_SUPPORT, "compare",
				that.getClass().getSimpleName()));
	}
	
	
	@Override
	public IPropertyValue callFunction(String functionName, List<IPropertyValue> args) {
		
		FunctionInterfaceDef functionDef = getFunctionDef(functionName);
		// check arg type matches
		if(functionDef.argumentTypes.size() != args.size()){
			throw new OperationNotAllowed(String.format(ERROR_FUNCTION_ARGUMENTS_MISMATCH_SIZE, functionDef.name, functionDef.argumentTypes.size(), args.size()));
		}
		for(int i = 0; i<args.size();i++ ){
			Class<? extends IPropertyValue> argType = functionDef.argumentTypes.get(i);
			IPropertyValue argValue = args.get(i);
			// check type
			if(!argType.isInstance(argValue)){
				throw new OperationNotAllowed(String.format(ERROR_FUNCTION_ARGUMENTS_MISMATCH_TYPE, functionDef.name, i , argType.getName(), argValue.getClass().getSimpleName()));	
			}
		}
					
		// call function
		if(functionDef.category == FunctionInterfaceDef.Category.SYSTEM){
			try{
				return functionDef.function.execute(this, args);
			}catch (MemoryBlockException e){
				throw new GTTEmbededRuleScriptInternalException(0,0,e.getMessage(),e);
			}
		}
		else if(functionDef.category == FunctionInterfaceDef.Category.CUSTOMIZED){
			throw new UnsupportedOperationException();
		}
		else{
			throw new UnsupportedOperationException(String.format(ERROR_FUNCTION_CATEGORY_NOT_SUPPORT, functionDef.category.name(), functionDef.name));	
		}		
		
	}
	
	protected Map<String, FunctionInterfaceDef> getFunctionDefs(){
		return functionDefs;
	}
	
	@Override
	public FunctionInterfaceDef getFunctionDef(String functionName) {
		FunctionInterfaceDef functionDef = this.getFunctionDefs().get(functionName);
		if(functionDef == null){
			throw new OperationNotAllowed(String.format(ERROR_FUNCTION_NOT_FOUND, functionName, this.getClass().getSimpleName()));
		}
		
		return functionDef;
	}
}
