/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.gtt.v2.configuration.handler;

import com.google.json.JsonSanitizer;
import com.sap.gtt.v2.core.auditlog.AuditLogService;
import com.sap.gtt.v2.exception.InternalErrorException;
import java.io.IOException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

/**
 *
 * @author I326335
 */
public class RestSecurityHandlerBase {

    protected static final Logger LOGGER = LoggerFactory.getLogger(RestSecurityHandlerBase.class);
    
    private static final String MESSAGE = "message";
    private static final String X_FORWARDED_FOR = "X-FORWARDED-FOR";
    
    protected void auditSecurityEvent(AuditLogService auditLogService, String message) {
        String ipAddress = getClientIPAddress();
        /**
         * send the logs to persist for security reasons
         */
        auditLogService.auditSecurityEvent(ipAddress, message);
    }
    
    /**
     * Get the client IP address
     *
     * @return
     */
    private String getClientIPAddress() {
        HttpServletRequest request = getHttpServletRequest(); 
        if (request == null) {
            LOGGER.warn("No HttpServletRequest.");
            return null;
        }
        String ipAddress = request.getHeader(X_FORWARDED_FOR);
        if (ipAddress == null) {
            ipAddress = request.getRemoteAddr();
        }
        ipAddress = ((!StringUtils.isEmpty(ipAddress) && ipAddress.contains(",")) ? ipAddress.substring(0, ipAddress.indexOf(",")) : ipAddress);
        return ipAddress;
    }

    private HttpServletRequest getHttpServletRequest() {
        RequestAttributes attribs = RequestContextHolder.getRequestAttributes();
        if (attribs instanceof ServletRequestAttributes) {
            return ((ServletRequestAttributes) attribs).getRequest();
        }
        return null;
    }
    
    protected void generateResponse(HttpServletRequest request, HttpServletResponse response, String message, int status) throws InternalErrorException, IOException {
        /**
         * send the response to the client
         */
        //response.setContentType(MediaType.APPLICATION_JSON_UTF8_VALUE);
        response.setStatus(status);
        try {
            response.getWriter().write(JsonSanitizer.sanitize((new JSONObject()
                .put(MESSAGE, message))
                .toString()));
        } catch (JSONException e) {
            throw new InternalErrorException(e.getMessage(), e);
        }
    }
}
