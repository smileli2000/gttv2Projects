package com.sap.gtt.v2.core.dao.execution;

import com.sap.gtt.v2.core.entity.execution.ExecutionUnit;
import com.sap.gtt.v2.exception.DBException;
import com.sap.gtt.v2.util.DBUtils;
import com.sap.gtt.v2.util.SpringContextUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

/**
 * @author I302310
 */
@Repository(DefaultExecutionUnitDao.BEAN_NAME)
public class DefaultExecutionUnitDao implements IExecutionUnitDao {
    public static final String BEAN_NAME = "com.sap.gtt.v2.core.dao.execution.DefaultExecutionUnitDao";
    public static final String TABLE_NAME = "EXECUTION_UNIT";

    public static final String ID = "ID";
    public static final String REQUEST_ID = "REQUEST_ID";
    public static final String EVENT_ID = "EVENT_ID";
    public static final String EVENT_TYPE = "EVENT_TYPE";
    public static final String ALTKEY = "ALTKEY";
    public static final String LOCATION_ALTKEY = "LOCATION_ALTKEY";
    public static final String CORRELATED_TP_ID = "CORRELATED_TP_ID";
    public static final String CORRELATED_TP_ALTKEY = "CORRELATED_TP_ALTKEY";
    public static final String EXECUTION_COUNT = "EXECUTION_CNT";
    public static final String LAST_EXECUTION_ID = "LAST_EXECUTION_ID";
    public static final String IS_PROCESS_EVENT = "IS_PROCESS_EVENT";

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public static DefaultExecutionUnitDao getInstance() {
        return (DefaultExecutionUnitDao) SpringContextUtils.getBean(BEAN_NAME);
    }

    @Override
    public ExecutionUnit queryExecutionUnit(String eventId, String correlatedTpId) {
        List<String> args = new ArrayList<>();
        args.add(eventId);
        StringBuilder sql = new StringBuilder();
        sql.append("select * from ").append(DefaultExecutionUnitDao.TABLE_NAME)
                .append(" where ")
                .append(EVENT_ID).append("=? and ")
                .append(CORRELATED_TP_ID);
        if (correlatedTpId == null) {
            sql.append(" is null ");
        } else {
            sql.append("=?");
            args.add(correlatedTpId);
        }
        return query(sql.toString(), args);
    }

    @Override
    public ExecutionUnit queryExecutionUnit(String lastExecutionId) {
        List<String> args = new ArrayList<>();
        args.add(lastExecutionId);
        StringBuilder sql = new StringBuilder();
        sql.append("select * from ").append(DefaultExecutionUnitDao.TABLE_NAME)
                .append(" where ")
                .append(LAST_EXECUTION_ID).append("=?");
        return query(sql.toString(), args);
    }

    private ExecutionUnit query(String sql, List<String> args) {
        List<ExecutionUnit> units = jdbcTemplate.query(sql, args.toArray(), (rs, rowNum) -> {
            String rs_id = rs.getString(ID);
            String rs_requestId = rs.getString(REQUEST_ID);
            String rs_eventId = rs.getString(EVENT_ID);
            String rs_eventType = rs.getString(EVENT_TYPE);
            String rs_altkey = rs.getString(ALTKEY);
            String rs_locationAltkey = rs.getString(LOCATION_ALTKEY);
            String rs_correlatedTpId = rs.getString(CORRELATED_TP_ID);
            String rs_correlatedTpAltkey = rs.getString(CORRELATED_TP_ALTKEY);
            int rs_executionCount = rs.getInt(EXECUTION_COUNT);
            String rs_lastExecutionId = rs.getString(LAST_EXECUTION_ID);
            boolean rs_isProcessEvent = rs.getBoolean(IS_PROCESS_EVENT);
            return new ExecutionUnit(rs_id, rs_requestId, rs_eventId, rs_eventType, rs_altkey, rs_locationAltkey,
                    rs_correlatedTpId, rs_correlatedTpAltkey, rs_executionCount, rs_lastExecutionId, rs_isProcessEvent);
        });
        return units.isEmpty() ? null : units.get(0);
    }

    @Override
    public void insertExecutionUnit(ExecutionUnit unit) {
        StringBuilder sql = new StringBuilder();
        String[] columns = {ID, REQUEST_ID, EVENT_ID, EVENT_TYPE, ALTKEY, LOCATION_ALTKEY,
                CORRELATED_TP_ID, CORRELATED_TP_ALTKEY, EXECUTION_COUNT, LAST_EXECUTION_ID, IS_PROCESS_EVENT};
        DBUtils.buildInsertSql(TABLE_NAME, columns, sql);
        Object[] args = new Object[]{unit.getId(), unit.getRequestId(), unit.getEventId(),
                unit.getEventType(), unit.getAltkey(), unit.getLocationAltkey(), unit.getCorrelatedTpId(), unit.getCorrelatedTpAltkey(),
                unit.getExecutionCount(), unit.getLastExecutionId(), unit.isProcessEvent()};
        int affectedRows = jdbcTemplate.update(sql.toString(), args);
        if (affectedRows <= 0) {
            throw new DBException("Insert Execution_Unit data failed. Affected rows " + affectedRows);
        }
    }

    @Override
    public void updateExecutionUnit(String id, int executionCount, String lastExecutionId) {
        StringBuilder sql = new StringBuilder();
        String[] updatedColumns = {EXECUTION_COUNT, LAST_EXECUTION_ID};
        Object[] updateValues = new Object[]{executionCount, lastExecutionId};
        String[] whereColumns = {ID};
        Object[] whereValues = new Object[]{id};
        List<Object> updateParam = new ArrayList<>();

        DBUtils.buildUpdateSql(TABLE_NAME, updatedColumns, updateValues, whereColumns, whereValues, sql, updateParam);
        Object[] args = updateParam.toArray();
        jdbcTemplate.update(sql.toString(), args);
    }

}
