package com.sap.gtt.v2.exception;


public class TypeMismatchException extends InternalErrorException {

    public TypeMismatchException(Throwable cause) {
        super(cause);
    }

    public TypeMismatchException(String message) {
        super(message);
    }
}
