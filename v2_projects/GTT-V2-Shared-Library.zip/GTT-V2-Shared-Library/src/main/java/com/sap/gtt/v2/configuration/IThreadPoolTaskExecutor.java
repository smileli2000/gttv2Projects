package com.sap.gtt.v2.configuration;

import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

/**
 * @author i311486
 */
public interface IThreadPoolTaskExecutor {
    public ThreadPoolTaskExecutor initTaskExecutor();
}
