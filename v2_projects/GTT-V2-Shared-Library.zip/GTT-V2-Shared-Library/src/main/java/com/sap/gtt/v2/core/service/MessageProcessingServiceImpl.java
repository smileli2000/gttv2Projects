package com.sap.gtt.v2.core.service;

import com.sap.gtt.v2.configuration.ISAPCloudPlatformAgent.ICurrentAccessContext;
import com.sap.gtt.v2.configuration.SystemConstants;
import com.sap.gtt.v2.core.domain.execution.*;
import com.sap.gtt.v2.core.domain.metadata.MetadataConstants;
import com.sap.gtt.v2.core.domain.metadata.MetadataEntity;
import com.sap.gtt.v2.core.domain.metadata.MetadataEntityElement;
import com.sap.gtt.v2.core.domain.metadata.MetadataForeignKey;
import com.sap.gtt.v2.core.entity.trackedprocess.Event;
import com.sap.gtt.v2.core.entity.trackedprocess.PlannedEvent;
import com.sap.gtt.v2.core.entity.trackedprocess.Reference;
import com.sap.gtt.v2.core.entity.trackedprocess.TrackedProcess;
import com.sap.gtt.v2.core.management.execution.IMessageLogManagement;
import com.sap.gtt.v2.core.management.metadata.CsnParser;
import com.sap.gtt.v2.core.management.tracking.IEventManagement;
import com.sap.gtt.v2.core.management.tracking.ITrackedProcessManagement;
import com.sap.gtt.v2.core.runtime.model.IPropertyValue;
import com.sap.gtt.v2.core.runtime.model.ObjectValue;
import com.sap.gtt.v2.core.runtime.model.TimestampValue;
import com.sap.gtt.v2.core.runtime.model.UUIDValue;
import com.sap.gtt.v2.exception.BaseRuntimeException;
import com.sap.gtt.v2.exception.CorrelationException;
import com.sap.gtt.v2.exception.HttpStatus4xxException;
import com.sap.gtt.v2.exception.MultiExceptionContainer;
import com.sap.gtt.v2.log.TenantAwareLogService;
import com.sap.gtt.v2.util.GTTUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * @author I302310
 */
@Service
public class MessageProcessingServiceImpl implements MessageProcessingService {

    @Autowired
    private MessageProcessingAsync processingAsync;
    @Autowired
    private ICurrentAccessContext currentContext;
    @Autowired
    private MessageValidation messageValidation;
    @Autowired
    private TenantAwareLogService logService;

    @Override
    public void processEvents(List<Event> events, String requestId, String writeServiceId) {
        Instant inTime = Instant.now();
        messageValidation.validate(events, requestId, writeServiceId);
        try {
            for (Event event : events) {
                fillData(event);
            }
            getEventManagement().post(events);
        } catch (BaseRuntimeException e) {
            insertErrorMappingMessage(requestId, writeServiceId, e);
        }
        MultiExceptionContainer multiExceptionContainer = new MultiExceptionContainer(HttpStatus.INTERNAL_SERVER_ERROR.value());
        for (Event event : events) {
            try {
                processEvent(event, inTime, requestId);
            } catch (BaseRuntimeException e) {
                multiExceptionContainer.addException(e);
            }
        }
        if (!multiExceptionContainer.getContainedExceptions().isEmpty()) {
            throw multiExceptionContainer;
        }
    }

    private void fillData(Event event) {
        processSourceAltKeyProperty(event);
        MessageUtil.processBacklinkProperty(event, null);
        Instant now = Instant.now();
        event.setCreationDateTime(now);
        if (!event.isValueProvided(Event.PRIORITY)) {
            event.setPriority(0);
        }
        Instant actualTechnicalTs = event.isValueProvided(Event.ACTUAL_TECHNICAL_TIMESTAMP) ? event.getActualTechnicalTimestamp() : null;
        if (actualTechnicalTs == null) {
            event.setActualTechnicalTimestamp(now);
        }
        event.setCreatedByUser(currentContext.getLogonName());
        parseAltKey(event);
        if (!event.isValueProvided(Event.SUBACCOUNTID)) {
            event.setSubaccountId(UUID.fromString(currentContext.getSubaccountId()));
        }
        if (!event.isValueProvided(Event.CLONEINSTANCEID)) {
            String cloneInstanceId = currentContext.getCloneServiceInstanceId();
            if (!StringUtils.isBlank(cloneInstanceId)) {
                event.setCloneInstanceId(UUID.fromString(cloneInstanceId));
            }
        }
        MessageUtil.processDefaultValue(event);

        if (event.isValueProvided(Event.REFERENCES) && event.getReferences() != null) {
            List<Reference> references = event.getReferences();
            for (Reference reference : references) {
                reference.setId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
            }
            event.setReferences(references);
        }
        if (event.isValueProvided(Event.PLANNED_EVENTS) && event.getPlannedEvents() != null) {
            List<PlannedEvent> plannedEvents = event.getPlannedEvents();
            for (PlannedEvent pe : plannedEvents) {
                pe.setId(GTTUtils.UUIDUtils.generateTimeBasedUUID());
            }
            event.setPlannedEvents(plannedEvents);
        }
    }

    @Override
    public void reprocess(String eventId, String correlatedTpId) {
        Instant inTime = Instant.now();
        UUIDValue eventIdValue = UUIDValue.valueOf(eventId);
        Event event = getEventManagement().get(eventIdValue);
        if (event == null) {
            throw new HttpStatus4xxException("Event is not existed.", null, HttpStatus.BAD_REQUEST.value());
        }

        boolean isProcessEvent = event.getMetadata().getCurrentEntity().isProcessEvent();
        if (isProcessEvent) {
            TrackedProcess trackedProcess = getProcessManagement().get(UUIDValue.valueOf(correlatedTpId));
            if (event.getActualBusinessTimestamp().isBefore(trackedProcess.getLastChangedAtBusinessTime())) {
                throw new HttpStatus4xxException("Process has been updated by newer event.", null, HttpStatus.BAD_REQUEST.value());
            }
            processProcessEvent(event, inTime, null);
        } else if (correlatedTpId == null) {
            processCorrelationTP(event, inTime, null);
        } else {
            processOneCommonEvent(event, UUID.fromString(correlatedTpId), event.getAltKey(), inTime, null);
        }
    }

    private void processEvent(Event event, Instant inTime, String requestId) {
        boolean isProcessEvent = event.getMetadata().getCurrentEntity().isProcessEvent();
        String eventType = event.getEventType();
        if (isProcessEvent) {
            processProcessEvent(event, inTime, requestId);
        } else if (CsnParser.isCoreModelEntity(eventType)) {
            UUID processId = GTTUtils.UUIDUtils.generateNameBasedUUID(event.getAltKey());
            processOneCommonEvent(event, processId, event.getAltKey(), inTime, requestId);
        } else {
            processCorrelationTP(event, inTime, requestId);
        }
    }

    private void processOneCommonEvent(Event event, UUID processId, String processAltkey, Instant inTime, String requestId) {
        String executionHistoryId = UUID.randomUUID().toString();
        insertExecution(requestId, event, processId.toString(), processAltkey, false, inTime, executionHistoryId,
                Phase.EVENT2ACTION.name());
        processingAsync.processCommonEvent(processId, event, executionHistoryId);
    }

    private void processProcessEvent(Event event, Instant inTime, String requestId) {
        String correlatedTpId = GTTUtils.UUIDUtils.generateNameBasedUUID(event.getAltKey()).toString();
        String executionHistoryId = UUID.randomUUID().toString();
        insertExecution(requestId, event, correlatedTpId, event.getAltKey(), true, inTime, executionHistoryId,
                Phase.EVENT2ACTION.name());
        processingAsync.processProcessEvent(event, executionHistoryId);
    }

    private void processCorrelationTP(Event event, Instant inTime, String requestId) {
        String eventId = event.getIdAsInternalValue().toString();
        logService.info("Correlate processes for event with id {}", eventId);
        String executionHistoryId = UUID.randomUUID().toString();
        insertExecution(requestId, event, null, null, false, inTime, executionHistoryId,
                Phase.CORRELATION.name());
        int eventCorrelationLevel = event.getMetadata().getEventCorrelationLevel();
        Map<UUIDValue, String> correlationMap = eventCorrelation(event.getAltKey(), event.getActualBusinessTimestamp(), eventCorrelationLevel);
        if (correlationMap.isEmpty()) {
            String message = String.format("Event with id %s cannot correlate any process.", eventId);
            logService.warn(message);
            CorrelationException e = new CorrelationException(message);
            insertExecutionMessage(executionHistoryId, Phase.CORRELATION.name(), ExecutionStatus.ERROR.name(),
                    Instant.now(), e);
        } else {
            CorrelatedTrackedProcessDto trackedProcessDto = new CorrelatedTrackedProcessDto();
            trackedProcessDto.setExecutionId(executionHistoryId);
            Map<String, String> tpIdMap = new HashMap<>();
            correlationMap.forEach((key, value) -> tpIdMap.put(key.toString(), value));
            trackedProcessDto.setTpMap(tpIdMap);
            getMessageLogManagement().insertCorrelatedTrackedProcess(trackedProcessDto);
        }
        MultiExceptionContainer multiExceptionContainer = new MultiExceptionContainer(HttpStatus.INTERNAL_SERVER_ERROR.value());
        for (Map.Entry<UUIDValue, String> entry : correlationMap.entrySet()) {
            try {
                processOneCommonEvent(event, entry.getKey().getInternalValue(), entry.getValue(), inTime, requestId);
            } catch (BaseRuntimeException e) {
                multiExceptionContainer.addException(e);
            }
        }
        if (!multiExceptionContainer.getContainedExceptions().isEmpty()) {
            throw multiExceptionContainer;
        }
    }

    private void parseAltKey(Event event) {
        GTTUtils.AltKey altKey = GTTUtils.parseAltKey(event.getAltKey());
        event.setScheme(altKey.getScheme());
        event.setPartyId(altKey.getParty());
        event.setLogicalSystem(altKey.getLogicalSystem());
        event.setTrackingIdType(altKey.getType());
        event.setTrackingId(altKey.getId());
    }
    
    private Map<UUIDValue, String> eventCorrelation(String altKey, Instant actualBizTs, int eventCorrelationLevel) {
        UUID pid = GTTUtils.UUIDUtils.generateNameBasedUUID(altKey);
        return getProcessManagement().getCorrelatedProcessMap(UUIDValue.valueOf(pid), TimestampValue.valueOf(actualBizTs), eventCorrelationLevel);
    }

    private void processSourceAltKeyProperty(ObjectValue dataObject) {
        MetadataEntity metadataEntity = dataObject.getMetadata().getCurrentEntity();
        Map<String, MetadataEntityElement> metadata = metadataEntity.getElementMap();
        for (Map.Entry<String, MetadataEntityElement> entry : metadata.entrySet()) {
            String fieldName = entry.getKey();
            MetadataEntityElement fieldConfig = entry.getValue();
            MetadataConstants.CdsDataType fieldType = fieldConfig.getType();
            if (MetadataConstants.CdsDataType.CDS_ASSOCIATION.equals(fieldType)) {
                processSourceAltKeyPropertyInner(dataObject, fieldConfig);
            } else if (MetadataConstants.CdsDataType.CDS_COMPOSITION.equals(fieldType)
                    && !MessageUtil.isNull(dataObject, fieldName)) {
                List<IPropertyValue> items = dataObject.getValueAsList(fieldName);
                for (IPropertyValue item : items) {
                    processSourceAltKeyProperty((ObjectValue) item);
                }
            }
        }
    }

    private void processSourceAltKeyPropertyInner(ObjectValue dataObject, MetadataEntityElement fieldConfig) {
        String sourceAltKey = fieldConfig.getSourceAltKey();
        if (sourceAltKey != null && !MessageUtil.isNull(dataObject, sourceAltKey)) {
            List<MetadataForeignKey> foreignKeyList = fieldConfig.getForeignKeyList();
            String target = fieldConfig.getTarget();
            for (MetadataForeignKey fk : foreignKeyList) {
                String generatedFieldName = fk.getGeneratedFieldName();
                //TODO: do different things according to target type (TP or Masterdata)
                if (!MetadataConstants.MasterDataEntity.LOCATION.getFullName().equals(target) &&
                        !MetadataConstants.MasterDataEntity.BUSINESS_PARTNER.getFullName().equals(target)) {
                    dataObject.setValue(generatedFieldName,
                            GTTUtils.UUIDUtils.generateNameBasedUUID(dataObject.getValueAsString(sourceAltKey)));
                }
            }
        }
    }

    private void insertExecution(String requestId, Event event, String correlatedTpId, String correlatedTpAltkey,
                                 boolean isProcessEvent, Instant inTime, String executionHistoryId, String lastPhase) {
        ExecutionDto executionDto = new ExecutionDto();
        executionDto.setRequestId(requestId);
        executionDto.setEventId(event.getIdAsInternalValue().toString());
        executionDto.setEventType(event.getEventType());
        executionDto.setAltkey(event.getAltKey());
        executionDto.setLocationAltkey(event.isValueProvided(Event.LOCATION_ALT_KEY) ? event.getLocationAltKey() : null);
        executionDto.setCorrelatedTpId(correlatedTpId);
        executionDto.setCorrelatedTpAltkey(correlatedTpAltkey);
        executionDto.setProcessEvent(isProcessEvent);
        executionDto.setExecutionAt(inTime);
        executionDto.setLastPhase(lastPhase);
        executionDto.setExecutionHistoryId(executionHistoryId);
        getMessageLogManagement().insertExecution(executionDto);
    }

    private void insertExecutionMessage(String executionHistoryId, String phase, String status, Instant errorTime, BaseRuntimeException e) {
        ExecutionMessageDto executionMessageDto = new ExecutionMessageDto();
        executionMessageDto.setExecutionHistoryId(executionHistoryId);
        executionMessageDto.setPhase(phase);
        executionMessageDto.setMessageType(status);
        executionMessageDto.setErrorAt(errorTime);
        executionMessageDto.setMessage(e.getErrorCode());
        executionMessageDto.setDetail(e.getLocalizedMessage(SystemConstants.DEFAULT_LOCALE));
        getMessageLogManagement().insertExecutionMessage(executionMessageDto);
    }

    private void insertErrorMappingMessage(String requestId, String writeServiceId, BaseRuntimeException e) {
        MappingMessageDto messageDto = new MappingMessageDto();
        messageDto.setRootRequestId(requestId);
        messageDto.setObjectId(writeServiceId);
        messageDto.setStatus(ExecutionStatus.ERROR);
        messageDto.setMessage(e.getErrorCode());
        messageDto.setDetail(e.getLocalizedMessage(SystemConstants.DEFAULT_LOCALE));
        getMessageLogManagement().insertMappingMessage(messageDto);
    }

    private ITrackedProcessManagement getProcessManagement() {
        return currentContext.createBusinessOperator().getTrackedProcessManagement();
    }

    private IEventManagement getEventManagement() {
        return currentContext.createBusinessOperator().getEventManagement();
    }

    private IMessageLogManagement getMessageLogManagement() {
        return currentContext.createBusinessOperator().getMessageLogManagement();
    }

    protected void setProcessingAsync(MessageProcessingAsync processingAsync) {
        this.processingAsync = processingAsync;
    }
}
