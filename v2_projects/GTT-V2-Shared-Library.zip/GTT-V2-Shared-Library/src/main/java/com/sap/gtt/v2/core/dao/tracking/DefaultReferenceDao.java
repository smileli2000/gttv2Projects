package com.sap.gtt.v2.core.dao.tracking;

import com.sap.gtt.v2.core.domain.metadata.CurrentMetadataEntity;
import com.sap.gtt.v2.core.entity.trackedprocess.Reference;
import com.sap.gtt.v2.util.SpringContextUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

@Repository(DefaultReferenceDao.BEAN_NAME)
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class DefaultReferenceDao implements IReferenceDao {
    public static final String BEAN_NAME = "com.sap.gtt.v2.core.dao.tracking.DefaultReferenceDao";

    public static DefaultReferenceDao getInstance() {
        return (DefaultReferenceDao) SpringContextUtils.getBean(BEAN_NAME);
    }

    @Autowired
    private DaoHelper daoHelper;

    @Override
    public void insert(Reference reference) {
        daoHelper.insert(reference);
    }

    @Override
    public void insert(List<Reference> references) {
        for(Reference reference : references) {
            daoHelper.insert(reference);
        }
    }

    @Override
    public void delete(CurrentMetadataEntity metadata, UUID id) {
        daoHelper.delete(metadata, id);
    }

    @Override
    public void update(Reference reference) {
        daoHelper.update(reference);
    }
}
