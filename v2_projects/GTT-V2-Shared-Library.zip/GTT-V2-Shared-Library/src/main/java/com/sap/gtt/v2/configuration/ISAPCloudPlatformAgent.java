package com.sap.gtt.v2.configuration;

import com.sap.gtt.v2.bp.BusinessPartner;
import com.sap.gtt.v2.configuration.EnvironmentsConfiguration.VcapServiceParser.DatabaseServiceInstance;
import com.sap.gtt.v2.servicemanager.GTTInstance;
import com.sap.gtt.v2.util.GTTUtils;
import com.sap.gtt.v2.util.GTTUtils.BusinessOperator;
import org.springframework.context.i18n.LocaleContextHolder;

import java.util.Locale;
import java.util.Map;


public interface ISAPCloudPlatformAgent {

	public static final String ENV_VARIABLE_NAME_VCAP_SERVICES = "VCAP_SERVICES";
	public static final String ENV_VARIABLE_NAME_SAAS_SUBSCRIPTION_API_HOST = "SAAS_SUBSCRIPTION_API_HOST";
	
	public static final String TOKEN_ATTRIBUTE_NAME_IS_INT_USER = "isIntUser";
	
	public interface ICurrentAccessContext{
		public static final String BEAN_NAME = "currentAccessContext";
		
		public AccessContextHolder.AccessContext cloneContext();
		    
		public String getSubaccountId();
		public String getLogonName();
		public String getSubdomain();
		public String getCloneServiceInstanceId();
		public boolean containsCloneServiceInstanceId();
		public GTTInstance getInstance();
		public DatabaseServiceInstance getDatabaseServiceInstance();
		public boolean isAuthenticated();
		public boolean isUserToken();
		public String getJWT();
		public boolean isIntegrationUserToken();
		public boolean isProductive();
		
		public boolean isSolutionOwner();
		public boolean isStandalonePlan();
		
		public BusinessPartner getBusinessPartner();
		
		public default BusinessOperator createBusinessOperator(){
			return GTTUtils.createBusinessOperator(this.getDatabaseServiceInstance().getDatabaseType());
		}
		public static Locale getLocale(){
			return LocaleContextHolder.getLocale();
		}
		public static String getLanguage(){
			return getLocale().getLanguage();
		}
		
	}
	
	public Map<String, String> getenv();
	
	public default String getVcapServicesString(){
		return this.getenv().get(ENV_VARIABLE_NAME_VCAP_SERVICES);
	}
	
	public default String getSaasSubscriptionAPIHost(){
		return this.getenv().get(ENV_VARIABLE_NAME_SAAS_SUBSCRIPTION_API_HOST);
		
	}
	
}
