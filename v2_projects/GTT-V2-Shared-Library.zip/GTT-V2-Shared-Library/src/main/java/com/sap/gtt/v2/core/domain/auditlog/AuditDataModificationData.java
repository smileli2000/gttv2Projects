/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.gtt.v2.core.domain.auditlog;

/**
 *
 * @author I326335
 */
public class AuditDataModificationData {
    private String field;
    private String oldValue;
    private String newValue;

    public AuditDataModificationData(String field, String oldValue, String newValue) {
        this.field = field;
        this.oldValue = oldValue;
        this.newValue = newValue;
    }

    public String getField() {
        return field;
    }

    public void setField(String field) {
        this.field = field;
    }

    public String getOldValue() {
        return oldValue;
    }

    public void setOldValue(String oldValue) {
        this.oldValue = oldValue;
    }

    public String getNewValue() {
        return newValue;
    }

    public void setNewValue(String newValue) {
        this.newValue = newValue;
    }

    @Override
    public String toString() {
        return "AuditDataModificationData{" + "field=" + field + ", oldValue=" + oldValue + ", newValue=" + newValue + '}';
    }
}
