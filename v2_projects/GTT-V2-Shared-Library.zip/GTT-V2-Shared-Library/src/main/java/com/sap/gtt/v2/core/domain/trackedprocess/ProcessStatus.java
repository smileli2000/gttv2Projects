package com.sap.gtt.v2.core.domain.trackedprocess;

public enum ProcessStatus {
	AS_PLANNED, EARLY, LATE, OVERDUE, DELAYED;

	public static ProcessStatus from(EventStatus eventStatus) {
		if (eventStatus.equals(EventStatus.PLANNED))
			return AS_PLANNED;
		else if (eventStatus.equals(EventStatus.OVERDUE))
			return OVERDUE;
		else if (eventStatus.equals(EventStatus.EARLY_REPORTED))
			return EARLY;
		else if (eventStatus.equals(EventStatus.REPORTED))
			return AS_PLANNED;
		else if (eventStatus.equals(EventStatus.LATE_REPORTED))
			return LATE;
		else return DELAYED;
	}
}
