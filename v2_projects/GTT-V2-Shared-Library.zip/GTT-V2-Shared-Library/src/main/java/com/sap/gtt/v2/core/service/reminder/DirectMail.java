package com.sap.gtt.v2.core.service.reminder;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.sap.gtt.v2.configuration.EnvironmentsConfiguration.VcapServiceParser.ReminderServiceInstance;
import com.sap.gtt.v2.configuration.ServiceInstancesMapping;
import com.sap.gtt.v2.core.runtime.model.IPropertyValue;
import com.sap.gtt.v2.core.runtime.model.StringValue;
import com.sap.gtt.v2.util.SpringContextUtils;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class DirectMail extends MailNotification implements IMailNotification {
    public static final String EMAIL_BODY = "emailBody";
    public static final String EMAIL_SUBJECT = "emailSubject";
    public static final String SYSTEMDEF_PLACEHOLDERS = "systemdefinedPlaceholders";
    public static final String SYSTEMDEF_PLACEHOLDERS_NAME = "systemdefined_placeholders";
    public static final String RECIPIENTS = "recipients";

    public void setSubject(String subject) {
        this.setValue(EMAIL_SUBJECT, StringValue.valueOf(subject));
    }

    public String getSubject() {
        if (!isValueProvided(EMAIL_SUBJECT))
            return null;
        return (String) this.getValue(EMAIL_SUBJECT).getInternalValue();
    }

    public void setBody(String body) {
        this.setValue(EMAIL_BODY, StringValue.valueOf(body));
    }

    public String getBody() {
        if (!isValueProvided(EMAIL_BODY))
            return null;
        return (String) this.getValue(EMAIL_BODY).getInternalValue();
    }

    public void setRecipients(List<String> recipients) {
        List<IPropertyValue> list = new ArrayList<>();
        for (String s : recipients) {
            list.add(StringValue.valueOf(s));
        }
        this.setValue(RECIPIENTS, list);
    }

    public List<String> getRecipients() {
        List<IPropertyValue> list = getValueAsList(RECIPIENTS);
        if (!CollectionUtils.isEmpty(list)) {
            List<String> rs = new ArrayList<>(list.size());
            for (IPropertyValue value : list) {
                StringValue s = (StringValue) value;
                rs.add(s.getInternalValue());
            }
            return rs;
        }
        return Collections.emptyList();
    }

    public void setSystemDefPlaceHolders(List<String> placeHolders) {
        List<IPropertyValue> list = new ArrayList<>();
        for (String s : placeHolders) {
            list.add(StringValue.valueOf(s));
        }
        this.setValue(SYSTEMDEF_PLACEHOLDERS, list);
    }

    public List<String> getSystemDefPlaceHolders() {
        List<IPropertyValue> list = getValueAsList(SYSTEMDEF_PLACEHOLDERS);
        if (!CollectionUtils.isEmpty(list)) {
            List<String> rs = new ArrayList<>(list.size());
            for (IPropertyValue value : list) {
                StringValue s = (StringValue) value;
                rs.add(s.getInternalValue());
            }
            return rs;
        }
        return Collections.emptyList();
    }

    @Override
    public String getMailUri() {
        ServiceInstancesMapping serviceInstancesMapping = SpringContextUtils.getBean(ServiceInstancesMapping.class);
        ReminderServiceInstance reminderServiceInstance = serviceInstancesMapping.getReminderServiceInstance();
        return reminderServiceInstance.getEndpoint() + "directmail";
    }

    @Override
    public JsonObject getRequestBody() {
        JsonObject requestBody = new JsonObject();
        requestBody.addProperty(EMAIL_BODY, getBody());
        requestBody.addProperty(EMAIL_SUBJECT, getSubject());
        JsonArray placeHolders = new JsonArray();
        for (String h : this.getSystemDefPlaceHolders())
            placeHolders.add(h);
        JsonArray recipients = new JsonArray();
        for (String r : this.getRecipients())
            recipients.add(r);
        requestBody.add(SYSTEMDEF_PLACEHOLDERS_NAME, placeHolders);
        requestBody.add(RECIPIENTS, recipients);
        return requestBody;
    }
}
