package com.sap.gtt.v2.location;

import com.google.gson.annotations.SerializedName;

public class Location {

    @SerializedName("SourceUniversalObjectId")
    private String sourceUniversalObjectId;
    @SerializedName("Longitude")
    private String longitude;
    @SerializedName("Latitude")
    private String latitude;
    @SerializedName("LocationDescription")
    private String locationDescription;
    @SerializedName("AddressTimeZone")
    private String addressTimeZone;
    @SerializedName("CountryCode")
    private String countryCode;
    @SerializedName("CountryName")
    private String countryName;
    @SerializedName("RegionCode")
    private String regionCode;
    @SerializedName("RegionName")
    private String regionName;
    @SerializedName("CityName")
    private String cityName;
    @SerializedName("StreetName")
    private String streetName;
    @SerializedName("HouseNumber")
    private String houseNumber;
    @SerializedName("HouseNumberSupplementText")
    private String houseNumberSupplementText;
    @SerializedName("PostalCode")
    private String postalCode;
    @SerializedName("Number")
    private String number;
    @SerializedName("NumberExtension")
    private String numberExtension;
    @SerializedName("EmailAddress")
    private String emailAddress;

    public String getSourceUniversalObjectId() {
        return sourceUniversalObjectId;
    }

    public void setSourceUniversalObjectId(String sourceUniversalObjectId) {
        this.sourceUniversalObjectId = sourceUniversalObjectId;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLocationDescription() {
        return locationDescription;
    }

    public void setLocationDescription(String locationDescription) {
        this.locationDescription = locationDescription;
    }

    public String getAddressTimeZone() {
        return addressTimeZone;
    }

    public void setAddressTimeZone(String addressTimeZone) {
        this.addressTimeZone = addressTimeZone;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    public String getRegionCode() {
        return regionCode;
    }

    public void setRegionCode(String regionCode) {
        this.regionCode = regionCode;
    }

    public String getRegionName() {
        return regionName;
    }

    public void setRegionName(String regionName) {
        this.regionName = regionName;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public String getStreetName() {
        return streetName;
    }

    public void setStreetName(String streetName) {
        this.streetName = streetName;
    }

    public String getHouseNumber() {
        return houseNumber;
    }

    public void setHouseNumber(String houseNumber) {
        this.houseNumber = houseNumber;
    }

    public String getHouseNumberSupplementText() {
        return houseNumberSupplementText;
    }

    public void setHouseNumberSupplementText(String houseNumberSupplementText) {
        this.houseNumberSupplementText = houseNumberSupplementText;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getNumberExtension() {
        return numberExtension;
    }

    public void setNumberExtension(String numberExtension) {
        this.numberExtension = numberExtension;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }
}
