package com.sap.gtt.v2.exception;

import org.apache.http.HttpStatus;

public class EventToActionRateLimitException extends BaseRuntimeException{

	public static final String ERROR_CODE = "ERROR_CODE_EVENT_TO_ACTION_RATE_LIMIT";
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -2608958097214830578L;
	public static final String MESSAGE_CODE_TIMEOUT = EventToActionRateLimitException.class.getName() + ".Timeout";
	

	public EventToActionRateLimitException(String internalMessage, Throwable cause, String messageCode,
			Object[] localizedMsgParams) {
		super(internalMessage, cause, messageCode, localizedMsgParams);
	}

	
	@Override
	public int getHttpStatus() {
		return HttpStatus.SC_GONE;
	}


	@Override
	public String getErrorCode() {
		return ERROR_CODE;
	}

}
