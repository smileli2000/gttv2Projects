// Generated from GTTEmbededRuleScript.g4 by ANTLR 4.7.2
package com.sap.gtt.v2.core.rule;
import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link GTTEmbededRuleScriptParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface GTTEmbededRuleScriptVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link GTTEmbededRuleScriptParser#script}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitScript(GTTEmbededRuleScriptParser.ScriptContext ctx);
	/**
	 * Visit a parse tree produced by {@link GTTEmbededRuleScriptParser#operationStatement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOperationStatement(GTTEmbededRuleScriptParser.OperationStatementContext ctx);
	/**
	 * Visit a parse tree produced by {@link GTTEmbededRuleScriptParser#declaration}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDeclaration(GTTEmbededRuleScriptParser.DeclarationContext ctx);
	/**
	 * Visit a parse tree produced by {@link GTTEmbededRuleScriptParser#printStatement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPrintStatement(GTTEmbededRuleScriptParser.PrintStatementContext ctx);
	/**
	 * Visit a parse tree produced by {@link GTTEmbededRuleScriptParser#ifStatement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIfStatement(GTTEmbededRuleScriptParser.IfStatementContext ctx);
	/**
	 * Visit a parse tree produced by {@link GTTEmbededRuleScriptParser#elseIfStatement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitElseIfStatement(GTTEmbededRuleScriptParser.ElseIfStatementContext ctx);
	/**
	 * Visit a parse tree produced by {@link GTTEmbededRuleScriptParser#elseStatement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitElseStatement(GTTEmbededRuleScriptParser.ElseStatementContext ctx);
	/**
	 * Visit a parse tree produced by {@link GTTEmbededRuleScriptParser#whileStatement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWhileStatement(GTTEmbededRuleScriptParser.WhileStatementContext ctx);
	/**
	 * Visit a parse tree produced by {@link GTTEmbededRuleScriptParser#returnStatement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitReturnStatement(GTTEmbededRuleScriptParser.ReturnStatementContext ctx);
	/**
	 * Visit a parse tree produced by {@link GTTEmbededRuleScriptParser#executionBlock}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExecutionBlock(GTTEmbededRuleScriptParser.ExecutionBlockContext ctx);
	/**
	 * Visit a parse tree produced by {@link GTTEmbededRuleScriptParser#refer}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRefer(GTTEmbededRuleScriptParser.ReferContext ctx);
	/**
	 * Visit a parse tree produced by {@link GTTEmbededRuleScriptParser#qualifiedName}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitQualifiedName(GTTEmbededRuleScriptParser.QualifiedNameContext ctx);
	/**
	 * Visit a parse tree produced by {@link GTTEmbededRuleScriptParser#functionCall}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunctionCall(GTTEmbededRuleScriptParser.FunctionCallContext ctx);
	/**
	 * Visit a parse tree produced by the {@code referAssign}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#assignStatement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitReferAssign(GTTEmbededRuleScriptParser.ReferAssignContext ctx);
	/**
	 * Visit a parse tree produced by the {@code identifierAssign}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#assignStatement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIdentifierAssign(GTTEmbededRuleScriptParser.IdentifierAssignContext ctx);
	/**
	 * Visit a parse tree produced by the {@code exprAtom}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExprAtom(GTTEmbededRuleScriptParser.ExprAtomContext ctx);
	/**
	 * Visit a parse tree produced by the {@code boolGe}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBoolGe(GTTEmbededRuleScriptParser.BoolGeContext ctx);
	/**
	 * Visit a parse tree produced by the {@code boolNotEq}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBoolNotEq(GTTEmbededRuleScriptParser.BoolNotEqContext ctx);
	/**
	 * Visit a parse tree produced by the {@code boolOr}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBoolOr(GTTEmbededRuleScriptParser.BoolOrContext ctx);
	/**
	 * Visit a parse tree produced by the {@code boolLe}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBoolLe(GTTEmbededRuleScriptParser.BoolLeContext ctx);
	/**
	 * Visit a parse tree produced by the {@code mathUnitary}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMathUnitary(GTTEmbededRuleScriptParser.MathUnitaryContext ctx);
	/**
	 * Visit a parse tree produced by the {@code boolReverse}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBoolReverse(GTTEmbededRuleScriptParser.BoolReverseContext ctx);
	/**
	 * Visit a parse tree produced by the {@code mathPow}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMathPow(GTTEmbededRuleScriptParser.MathPowContext ctx);
	/**
	 * Visit a parse tree produced by the {@code exprQulifiedName}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExprQulifiedName(GTTEmbededRuleScriptParser.ExprQulifiedNameContext ctx);
	/**
	 * Visit a parse tree produced by the {@code boolAnd}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBoolAnd(GTTEmbededRuleScriptParser.BoolAndContext ctx);
	/**
	 * Visit a parse tree produced by the {@code exprParens}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExprParens(GTTEmbededRuleScriptParser.ExprParensContext ctx);
	/**
	 * Visit a parse tree produced by the {@code mathAddSub}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMathAddSub(GTTEmbededRuleScriptParser.MathAddSubContext ctx);
	/**
	 * Visit a parse tree produced by the {@code boolLt}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBoolLt(GTTEmbededRuleScriptParser.BoolLtContext ctx);
	/**
	 * Visit a parse tree produced by the {@code boolGt}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBoolGt(GTTEmbededRuleScriptParser.BoolGtContext ctx);
	/**
	 * Visit a parse tree produced by the {@code boolEq}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBoolEq(GTTEmbededRuleScriptParser.BoolEqContext ctx);
	/**
	 * Visit a parse tree produced by the {@code mathMulDiv}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMathMulDiv(GTTEmbededRuleScriptParser.MathMulDivContext ctx);
	/**
	 * Visit a parse tree produced by the {@code exprFunctionCall}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExprFunctionCall(GTTEmbededRuleScriptParser.ExprFunctionCallContext ctx);
	/**
	 * Visit a parse tree produced by the {@code integerLiteral}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#atom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIntegerLiteral(GTTEmbededRuleScriptParser.IntegerLiteralContext ctx);
	/**
	 * Visit a parse tree produced by the {@code decimalLiteral}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#atom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDecimalLiteral(GTTEmbededRuleScriptParser.DecimalLiteralContext ctx);
	/**
	 * Visit a parse tree produced by the {@code boolLiteral}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#atom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBoolLiteral(GTTEmbededRuleScriptParser.BoolLiteralContext ctx);
	/**
	 * Visit a parse tree produced by the {@code stringLiteral}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#atom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStringLiteral(GTTEmbededRuleScriptParser.StringLiteralContext ctx);
	/**
	 * Visit a parse tree produced by the {@code arrayLiteral}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#atom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitArrayLiteral(GTTEmbededRuleScriptParser.ArrayLiteralContext ctx);
	/**
	 * Visit a parse tree produced by the {@code nullLiteral}
	 * labeled alternative in {@link GTTEmbededRuleScriptParser#atom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNullLiteral(GTTEmbededRuleScriptParser.NullLiteralContext ctx);
}