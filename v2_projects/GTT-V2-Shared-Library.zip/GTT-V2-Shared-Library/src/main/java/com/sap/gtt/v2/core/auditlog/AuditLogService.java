/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.gtt.v2.core.auditlog;

import com.sap.gtt.v2.core.domain.auditlog.AuditDataAccessData;
import com.sap.gtt.v2.core.domain.auditlog.AuditDataModificationData;
import java.util.List;

/**
 *
 * @author I326335
 */
public interface AuditLogService {
    public void auditDataModification(String dataSubjectId, String type, String role, String channel, List<AuditDataModificationData> attributes);
    public void auditDataAccess(String dataSubjectId, String type, String role, String channel, List<AuditDataAccessData> attributes);
    public void auditSecurityEvent(String ip, String description);
}
