package com.sap.gtt.v2.core.entity.execution;

import java.time.Instant;

/**
 * @author I302310
 */
public class ExecutionMessage {
    private String id;
    private String phaseId;
    private String messageType;
    private String message;
    private String detail;
    private Instant errorAt;
    private String tag;

    public ExecutionMessage(String id, String phaseId, String messageType, String message, String detail,
                            Instant errorAt, String tag) {
        this.id = id;
        this.phaseId = phaseId;
        this.messageType = messageType;
        this.message = message;
        this.detail = detail;
        this.errorAt = errorAt;
        this.tag = tag;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPhaseId() {
        return phaseId;
    }

    public void setPhaseId(String phaseId) {
        this.phaseId = phaseId;
    }

    public String getMessageType() {
        return messageType;
    }

    public void setMessageType(String messageType) {
        this.messageType = messageType;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    public Instant getErrorAt() {
        return errorAt;
    }

    public void setErrorAt(Instant errorAt) {
        this.errorAt = errorAt;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }
}
