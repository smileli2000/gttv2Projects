package com.sap.gtt.v2.core.runtime.model;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.sap.gtt.v2.core.domain.metadata.*;
import com.sap.gtt.v2.core.domain.trackedprocess.Constant;
import com.sap.gtt.v2.core.runtime.model.IPropertyValue.FunctionInterfaceDef;
import com.sap.gtt.v2.exception.PropertyValidationException;
import com.sap.gtt.v2.exception.OperationNotAllowed;
import com.sap.gtt.v2.exception.TypeMismatchException;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ObjectValue extends AbstractPropertyValue<Map<String, IPropertyValue>>{

	public static final String ERROR_NO_METADATA_FOUND = "No meta data info found for current entity";
	
	// define functions
		protected static final Map<String, FunctionInterfaceDef> functionDefs = new HashMap<>();
		static{
			functionDefs.putAll(AbstractPropertyValue.functionDefs);
		}
		@Override
		protected Map<String, FunctionInterfaceDef> getFunctionDefs(){
			return functionDefs;
		}
		//
		
	protected ObjectValue(Map<String, IPropertyValue> internalValue) {
		super(internalValue);
	}

	public ObjectValue() {//TODO: to be changed back to protected
		super(new HashMap<>());
	}

	@Override
	public boolean isCsnPrimitive() {
		return false;
	}
	@Override
	public boolean isCollection() {
		return false;
	}

	@Override
    public String toString(){
	    String str= "{";
	    int count = 1;
        for (Map.Entry<String, IPropertyValue> entry : this.getInternalValue().entrySet()) {
            if(count == this.getInternalValue().size()){
                if(entry.getValue().getInternalValue() instanceof String){
                    str+="\""+entry.getKey()+"\"" + ":\"" + entry.getValue().toString()+"\"";
                }else{
                    str+="\""+entry.getKey()+"\"" + ":" + entry.getValue().toString();
                }

            }else{
                if(entry.getValue().getInternalValue() instanceof String){
                    str+="\""+entry.getKey()+"\"" + ":\"" + entry.getValue().toString() + "\",";
                }else{
                    str+="\""+entry.getKey()+"\"" + ":" + entry.getValue().toString() + ",";
                }
                count++;
            }
        }
        return str+"}";
    }

    private CurrentMetadataEntity metadata;
   
    public CurrentMetadataEntity getMetadata() {
		return metadata;
	}

	public void setMetadata(CurrentMetadataEntity metadata) {
		this.metadata = metadata;
	}

	public void setValue(String propertyName, IPropertyValue propertyValue){
       // check metadata
    	this.checkMetadata(propertyName, propertyValue);
    	if (propertyValue == null) {
            propertyValue = NullValue.NULL;
        }
    	this.getInternalValue().put(propertyName, propertyValue);
    }
    
    protected void checkMetadata(String propertyName, IPropertyValue propertyValue){
        if(!this.containsMetadata()) return;
        MetadataEntity metadataEntity = this.getMetadataEntity();
        MetadataEntityElement propertyMetadataEntity = metadataEntity.getPropertyMetadata(propertyName);
        if (propertyMetadataEntity == null || propertyValue == null || propertyValue instanceof NullValue || propertyValue.getInternalValue() == null) {
            return;
        }
        FieldContent fieldContent = propertyMetadataEntity.getFieldContent();
        switch (propertyMetadataEntity.getType()) {
            case CDS_DECIMAL:
                checkDecimal(propertyName, propertyValue, propertyMetadataEntity, fieldContent);
                break;
            case CDS_UUID:
                if (!(propertyValue instanceof UUIDValue)) {
                    throwValidationException(propertyName, propertyValue);
                }
                break;
            case CDS_BOOLEAN:
                if (!(propertyValue instanceof BooleanValue)) {
                    throwValidationException(propertyName, propertyValue);
                }
                break;
            case CDS_INTEGER:
                checkInteger(propertyName, propertyValue, fieldContent);
                break;
            case CDS_DATE:
                checkDate(propertyName, propertyValue);
                break;
            case CDS_TIMESTAMP:
                checkTimeStamp(propertyName, propertyValue);
                break;
            case CDS_STRING:
                checkString(propertyName, propertyValue, propertyMetadataEntity, fieldContent);
                break;
            case CDS_COMPOSITION:
                checkComposition(propertyName, propertyValue, fieldContent);
                break;
            default:
                break;
        }
    }

    private void checkComposition(String propertyName, IPropertyValue propertyValue, FieldContent fieldContent) {
        if (!(propertyValue instanceof ListValue)) {
            throwValidationException(propertyName, propertyValue);
        }

        if (fieldContent != null) {
            List internalValue = (List)propertyValue.getInternalValue();
            if (internalValue.size() < fieldContent.getMinItems()) {
                throwValidationException(propertyName, propertyValue);
            }

            if (internalValue.size() > fieldContent.getMaxItems()) {
                throwValidationException(propertyName, propertyValue);
            }
        }
    }

    private void checkString(String propertyName, IPropertyValue propertyValue, MetadataEntityElement propertyMetadataEntity, FieldContent fieldContent) {
        if (propertyValue instanceof StringValue) {
            String str = (String)propertyValue.getInternalValue();
            if (str.length() > propertyMetadataEntity.getLength()) {
                throwValidationException(propertyName, propertyValue);
            }

            if (fieldContent != null) {
                if (str.length() < fieldContent.getMinLength()) {
                    throwValidationException(propertyName, propertyValue);
                }
                Pattern pattern = Pattern.compile(fieldContent.getPattern());
                Matcher matcher = pattern.matcher(str);
                if (!matcher.matches()) {
                    throwValidationException(propertyName, propertyValue);
                }
            }
        } else {
            throwValidationException(propertyName, propertyValue);
        }
    }

    private void checkTimeStamp(String propertyName, IPropertyValue propertyValue) {
        if (!(propertyValue instanceof TimestampValue)) {
            throwValidationException(propertyName, propertyValue);
        } else {
            Instant instant = (Instant)propertyValue.getInternalValue();
            if (instant.isBefore(Constant.MIN_TIMESTAMP) || instant.isAfter(Constant.MAX_TIMESTAMP)
            || instant.getNano()%1000000 != 0) {
                throwValidationException(propertyName, propertyValue);
            }
        }
    }

    private void checkDate(String propertyName, IPropertyValue propertyValue) {
        if (!(propertyValue instanceof DateValue)) {
            throwValidationException(propertyName, propertyValue);
        } else {
            LocalDate localDate = (LocalDate) propertyValue.getInternalValue();
            LocalDate min = LocalDate.parse("0000-01-01");
            LocalDate max = LocalDate.parse("9999-12-31");
            if (localDate.isBefore(min) || localDate.isAfter(max)) {
                throwValidationException(propertyName, propertyValue);
            }
        }
    }

    private void checkInteger(String propertyName, IPropertyValue propertyValue, FieldContent fieldContent) {
        if (!(propertyValue instanceof IntegerValue)) {
            throwValidationException(propertyName, propertyValue);
        }
        if (fieldContent != null) {
            Integer internalValue = (Integer) propertyValue.getInternalValue();
            checkMaximum(propertyName, propertyValue, fieldContent, internalValue);
            checkMinimum(propertyName, propertyValue, fieldContent, internalValue);
            checkIsMultipleOf(propertyName, propertyValue, fieldContent, internalValue);
        }
    }

    private void checkIsMultipleOf(String propertyName, IPropertyValue propertyValue, FieldContent fieldContent, Integer internalValue) {
        if (StringUtils.isNotEmpty(fieldContent.getMultipleOf())) {
            Integer val = Integer.parseInt(fieldContent.getMultipleOf());
            if (internalValue % val != 0) {
                throwValidationException(propertyName, propertyValue);
            }
        }
    }

    private void checkMinimum(String propertyName, IPropertyValue propertyValue, FieldContent fieldContent, Integer internalValue) {
        if (StringUtils.isNotEmpty(fieldContent.getMinimum())) {
            Integer min = Integer.parseInt(fieldContent.getMinimum());
            if ((fieldContent.isExclusiveMinimum() && internalValue <= min)
                || internalValue < min) {
                throwValidationException(propertyName, propertyValue);
            }
        }
    }

    private void checkMaximum(String propertyName, IPropertyValue propertyValue, FieldContent fieldContent, Integer internalValue) {
        if (StringUtils.isNotEmpty(fieldContent.getMaximum())) {
            Integer max = Integer.parseInt(fieldContent.getMaximum());
            if ((fieldContent.isExclusiveMaximum() && internalValue >= max)
                || (internalValue > max)) {
                throwValidationException(propertyName, propertyValue);
            }
        }
    }

    private void checkDecimal(String propertyName, IPropertyValue propertyValue, MetadataEntityElement propertyMetadataEntity, FieldContent fieldContent) {
        BigDecimal value = (BigDecimal)propertyValue.getInternalValue();
        if (value.precision() > propertyMetadataEntity.getPrecision() ||
            value.scale() > propertyMetadataEntity.getScale()) {
            throwValidationException(propertyName, propertyValue);
        }

        if (fieldContent != null) {
            BigDecimal internalValue = (BigDecimal) propertyValue.getInternalValue();
            checkMaximum(propertyName, propertyValue, fieldContent, internalValue);
            checkMinimum(propertyName, propertyValue, fieldContent, internalValue);
            checkIsEmpty(propertyName, propertyValue, fieldContent, internalValue);
        }
    }

    private void checkIsEmpty(String propertyName, IPropertyValue propertyValue, FieldContent fieldContent, BigDecimal internalValue) {
        if (StringUtils.isNotEmpty(fieldContent.getMultipleOf())) {
            BigDecimal val = new BigDecimal(fieldContent.getMultipleOf());
            if (internalValue.remainder(val).intValueExact() != 0) {
                throwValidationException(propertyName, propertyValue);
            }
        }
    }

    private void checkMinimum(String propertyName, IPropertyValue propertyValue, FieldContent fieldContent, BigDecimal internalValue) {
        if (StringUtils.isNotEmpty(fieldContent.getMinimum())) {
            BigDecimal min = new BigDecimal(fieldContent.getMinimum());
            if ((fieldContent.isExclusiveMinimum() && internalValue.compareTo(min) <= 0)
                || (internalValue.compareTo(min) < 0)) {
                throwValidationException(propertyName, propertyValue);
            }
        }
    }

    private void checkMaximum(String propertyName, IPropertyValue propertyValue, FieldContent fieldContent, BigDecimal internalValue) {
        if (StringUtils.isNotEmpty(fieldContent.getMaximum())) {
            BigDecimal max = new BigDecimal(fieldContent.getMaximum());
            if ((fieldContent.isExclusiveMaximum() && internalValue.compareTo(max) >= 0)
                || (internalValue.compareTo(max) > 0)) {
                throwValidationException(propertyName, propertyValue);
            }
        }
    }

    private void throwValidationException(String propertyName, IPropertyValue propertyValue) {
        throw new PropertyValidationException(PropertyValidationException.MESSAGE_CODE_PROPERTY_INVALID_VALUE, new Object[]{propertyValue, propertyName});
    }

    public void setValue(String propertyName, Integer propertyValue) {
        setValue(propertyName, IntegerValue.valueOf(propertyValue));
    }

    public void setValue(String propertyName, String propertyValue) {
        setValue(propertyName, StringValue.valueOf(propertyValue));
    }

    public void setValue(String propertyName, Instant propertyValue) {
        setValue(propertyName, TimestampValue.valueOf(propertyValue));
    }

    public void setValue(String propertyName, LocalDate propertyValue) {
        setValue(propertyName, DateValue.valueOf(propertyValue));
    }

    public void setValue(String propertyName, BigDecimal propertyValue) {
        setValue(propertyName, DecimalValue.valueOf(propertyValue));
    }

    public void setValue(String propertyName, Double propertyValue) {
        setValue(propertyName, DecimalValue.valueOf(propertyValue));
    }

    public void setValue(String propertyName, Boolean propertyValue) {
    	setValue(propertyName, BooleanValue.valueOf(propertyValue));
        
    }

    public void setValue(String propertyName, UUID propertyValue) {
        setValue(propertyName, UUIDValue.valueOf(propertyValue));
    }

    public void setValue(String propertyName, List<IPropertyValue> propertyValue) {
        setValue(propertyName, ListValue.valueOf(propertyValue));
    }

    public void setValue(String propertyName, Map<String, IPropertyValue> propertyValue) {
        setValue(propertyName, new ObjectValue(propertyValue));
    }

    public IPropertyValue getValue(String propertyName){
        IPropertyValue result = this.getInternalValue().get(propertyName);
        if(result == null) {
            throw new PropertyValidationException(PropertyValidationException.MESSAGE_CODE_PROPERTY_NOT_FOUND, new Object[]{propertyName});
        }
        return result;
    }

    public Integer getValueAsInteger(String propertyName) {
        IPropertyValue propertyValue = getValue(propertyName);
        if (propertyValue == null || propertyValue instanceof NullValue) {
            return null;
        }else if(propertyValue instanceof IntegerValue) {
            return ((IntegerValue)propertyValue).getInternalValue();
        } else {
            throw new TypeMismatchException("Not an integer value.");
        }
    }

    public String getValueAsString(String propertyName) {
        IPropertyValue propertyValue = getValue(propertyName);
        if (propertyValue == null || propertyValue instanceof NullValue) {
            return null;
        }else if (propertyValue instanceof StringValue) {
            return ((StringValue)propertyValue).getInternalValue();
        } else {
            throw new TypeMismatchException("Not an string value.");
        }
    }

    public Instant getValueAsTimeStamp(String propertyName) {
        IPropertyValue propertyValue = getValue(propertyName);
        if (propertyValue == null || propertyValue instanceof NullValue) {
            return null;
        }else if (propertyValue instanceof TimestampValue) {
            return ((TimestampValue)propertyValue).getInternalValue();
        } else {
            throw new TypeMismatchException("Not an timestamp value.");
        }
    }

    public LocalDate getValueAsDate(String propertyName) {
        IPropertyValue propertyValue = getValue(propertyName);
        if (propertyValue == null || propertyValue instanceof NullValue) {
            return null;
        }else if (propertyValue instanceof DateValue) {
            return ((DateValue)propertyValue).getInternalValue();
        } else {
            throw new TypeMismatchException("Not an date value.");
        }
    }

    public BigDecimal getValueAsDecimal(String propertyName) {
        IPropertyValue propertyValue = getValue(propertyName);
        if (propertyValue == null || propertyValue instanceof NullValue) {
            return null;
        }else if (propertyValue instanceof DecimalValue) {
            return ((DecimalValue)propertyValue).getInternalValue();
        } else {
            throw new TypeMismatchException("Not an date value.");
        }
    }

    public Boolean getValueAsBoolean(String propertyName) {
        IPropertyValue propertyValue = getValue(propertyName);
        if (propertyValue == null || propertyValue instanceof NullValue) {
            return null;
        }else if (propertyValue instanceof BooleanValue) {
            return ((BooleanValue)propertyValue).getInternalValue();
        } else {
            throw new TypeMismatchException("Not an boolean value.");
        }
    }

    public UUID getValueAsUUID(String propertyName) {
        IPropertyValue propertyValue = getValue(propertyName);
        if (propertyValue == null || propertyValue instanceof NullValue) {
            return null;
        }else if (propertyValue instanceof UUIDValue) {
            return ((UUIDValue)propertyValue).getInternalValue();
        } else {
            throw new TypeMismatchException("Not an UUID value.");
        }
    }

    public List<IPropertyValue> getValueAsList(String propertyName) {
        IPropertyValue propertyValue = getValue(propertyName);
        if (propertyValue == null || propertyValue instanceof NullValue) {
            return null;
        }else if (propertyValue instanceof ListValue) {
            return ((ListValue)propertyValue).getInternalValue();
        } else {
            throw new TypeMismatchException("Not an list value.");
        }
    }

    public void setValue(String propertyName, Object value) {
        value = setValueOfString(propertyName, value);
        if (value instanceof Boolean) {
            setValue(propertyName, (Boolean)value);
        } else if (value instanceof String) {
	        setValue(propertyName, (String)value);
        } else if (value instanceof Integer) {
	        setValue(propertyName, (Integer)value);
        } else if (value instanceof Float) {
	        setValue(propertyName, BigDecimal.valueOf((Float)value));
        } else if (value instanceof Double) {
	        setValue(propertyName, BigDecimal.valueOf((Double)value));
        } else if (value instanceof BigDecimal) {
	        setValue(propertyName, (BigDecimal)value);
        } else if (value instanceof LocalDate) {
	        setValue(propertyName, (LocalDate)value);
        } else if (value instanceof Instant) {
	        setValue(propertyName, (Instant)value);
        } else if (value instanceof Timestamp){
	        setValue(propertyName, ((Timestamp)value).toLocalDateTime().toInstant(ZoneOffset.UTC));
        } else if (value instanceof Date){
            setValue(propertyName, ((Date)value).toLocalDate());
	    }else if (value instanceof UUID) {
	        setValue(propertyName, (UUID)value);
        } else if (value instanceof IPropertyValue) {
	        setValue(propertyName, (IPropertyValue)value);
        } else if (value == null) {
	        setValue(propertyName, NullValue.NULL);
        }
	    else {
	        throw new IllegalArgumentException(propertyName + ": " +value);
        }
    }

    private Object setValueOfString(String propertyName, Object value) {
        if(this.containsMetadata() && value instanceof String) {
            MetadataEntity metadataEntity = this.getMetadataEntity();
            MetadataEntityElement propertyMetadataEntity = metadataEntity.getPropertyMetadata(propertyName);
            if (propertyMetadataEntity.getType().equals(MetadataConstants.CdsDataType.CDS_UUID)) {
                value = UUID.fromString((String)value);
            }

        } else {
            if ((propertyName.equalsIgnoreCase("ID") || propertyName.endsWith("_id")
                    || propertyName.endsWith("_ID")) && value instanceof String) {
                value = UUID.fromString((String)value);
            }
        }
        return value;
    }

    public boolean isValueProvided(String propertyName) {
        IPropertyValue value = this.getInternalValue().get(propertyName);
        return value != null;
    }
    
    /**
     * Parse json string to Object value
     * @param jsonObject
     * @return ObjectValue
     */
    public static ObjectValue valueOf(JsonObject jsonObject){
        ObjectValue resultObject = new ObjectValue();
        if(jsonObject.isJsonObject() && 0 != jsonObject.size()){
            Set<Map.Entry<String,JsonElement>> entryset = jsonObject.entrySet();
            entryset.forEach(entry -> {
                String key = entry.getKey();
                JsonElement value = entry.getValue();
                if(value.isJsonPrimitive()){
                    valueOfJsonPrimitive(resultObject, key, value);
                }else if(value.isJsonObject()){
                    resultObject.setValue(key,ObjectValue.valueOf(value.getAsJsonObject()));
                }else if(value.isJsonArray()){
                    List<IPropertyValue> list = valueOfJsonArray(value);
                    resultObject.setValue(key,list);
                }else if(value.isJsonNull()){
                    resultObject.setValue(key,NullValue.NULL);
                }
            });
        }
        return resultObject;
    }

    private static void valueOfJsonPrimitive(ObjectValue resultObject, String key, JsonElement value) {
        if(value.getAsJsonPrimitive().isString()){
            resultObject.setValue(key, StringValue.valueOf(value.getAsString()));
        }else if(value.getAsJsonPrimitive().isNumber()){
            String numberStr = value.getAsString();
            if(numberStr.contains(".")){
                resultObject.setValue(key, DecimalValue.valueOf(value.getAsBigDecimal()));
            }else {
                resultObject.setValue(key, IntegerValue.valueOf(value.getAsInt()));
            }
        }else if(value.getAsJsonPrimitive().isBoolean()){
            resultObject.setValue(key, BooleanValue.valueOf(value.getAsBoolean()));
        }
    }

    private static List<IPropertyValue> valueOfJsonArray(JsonElement value) {
        JsonArray jsonArray = value.getAsJsonArray();
        List<IPropertyValue> list = new ArrayList<>();
        jsonArray.forEach(jsonElement -> {
            if(jsonElement.isJsonPrimitive()){
                if(jsonElement.getAsJsonPrimitive().isString()){
                    list.add(StringValue.valueOf(jsonElement.getAsString()));
                }else if(jsonElement.getAsJsonPrimitive().isNumber()){
                    String numberStr = jsonElement.getAsString();
                    if(numberStr.contains(".")){
                        list.add(DecimalValue.valueOf(jsonElement.getAsBigDecimal()));
                    }else {
                        list.add(IntegerValue.valueOf(jsonElement.getAsInt()));
                    }
                }else if(jsonElement.getAsJsonPrimitive().isBoolean()){
                    list.add(BooleanValue.valueOf(jsonElement.getAsBoolean()));
                }
            }else if(jsonElement.isJsonObject()) {
                list.add(ObjectValue.valueOf(jsonElement.getAsJsonObject()));
            }
        });
        return list;
    }

    public boolean containsMetadata(){
    	return this.getMetadata() != null;
    }
    
    protected MetadataEntity getMetadataEntity(){
    	if(this.containsMetadata()){
    		MetadataEntity result = this.getMetadata().getAllRelatedEntityMap().get(this.getMetadata().getCurrentEntityName());
    		if(result != null){
        		return result;
        	}
        	else{
        		throw new OperationNotAllowed(ERROR_NO_METADATA_FOUND);
        	}
    	}
    	else{
    		throw new OperationNotAllowed(ERROR_NO_METADATA_FOUND);
    	}
    }
    public static ObjectValue valueOfEmpty(){
    	return new ObjectValue();
    }
    
    public static ObjectValue valueOf(Map<String, IPropertyValue> internalValue){
    	return new ObjectValue(internalValue);
    }

}
