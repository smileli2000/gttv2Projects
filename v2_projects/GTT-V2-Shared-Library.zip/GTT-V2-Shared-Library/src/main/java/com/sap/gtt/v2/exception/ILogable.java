package com.sap.gtt.v2.exception;

public interface ILogable {
	
}
