package com.sap.gtt.v2.core.service;

import com.sap.gtt.v2.core.entity.trackedprocess.Event;

import java.util.List;

/**
 * @author I302310
 */
public interface MessageProcessingService {
    void processEvents(List<Event> events, String requestId, String writeServiceId);

    void reprocess(String eventId, String correlatedTpId);
}
