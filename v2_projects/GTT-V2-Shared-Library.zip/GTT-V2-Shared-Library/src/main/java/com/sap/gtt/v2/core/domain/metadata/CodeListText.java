package com.sap.gtt.v2.core.domain.metadata;

import java.io.Serializable;
import java.util.Objects;
import java.util.StringJoiner;

/**
 * @author I301346
 */
public class CodeListText implements Serializable {
    private static final long serialVersionUID = 1L;

    private String code;

    private String name;

    private String language;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        CodeListText entity = (CodeListText) o;
        return Objects.equals(code, entity.code) &&
                Objects.equals(name, entity.name) &&
                Objects.equals(language, entity.language);
    }

    @Override
    public int hashCode() {
        return Objects.hash(code, name, language);
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", CodeListText.class.getSimpleName() + "[", "]")
                .add("code='" + code + "'")
                .add("name='" + name + "'")
                .add("language='" + language + "'")
                .toString();
    }
}
