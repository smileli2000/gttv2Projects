package com.sap.gtt.v2.exception;

import org.apache.http.HttpStatus;

/**
 * @author i311486
 */
public class InstanceBasedAuthorizationCheckException extends BaseRuntimeException {
    public static final String ERROR_CODE = "ERROR_CODE_INSTANCE_BASED_AUTHORIZATION_CHECK";

    public static final String MESSAGE_CODE_INSTANCE_NOT_AUTHORIZED= InstanceBasedAuthorizationCheckException.class.getName() + ".InstanceNotAuthorized";


    public InstanceBasedAuthorizationCheckException(String messageCode,
                                        Object[] localizedMsgParams) {
        super(null, null, messageCode, localizedMsgParams);
    }

    @Override
    public int getHttpStatus() {
        return HttpStatus.SC_UNAUTHORIZED;
    }

    @Override
    public String getErrorCode() {
        return ERROR_CODE;
    }
}
