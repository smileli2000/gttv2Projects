package com.sap.gtt.v2.core.runtime.model;

import org.apache.commons.lang3.StringUtils;

public final class StringValue extends AbstractPropertyValue<String> {

	private StringValue(String internalValue) {
		super(internalValue);
	}

	@Override
	public boolean isCsnPrimitive() {
		return true;
	}

	@Override
	public boolean isCollection() {
		return false;
	}


	@Override
	protected IPropertyValue addInternal(IPropertyValue that) {
		return new StringValue(this.getInternalValue() + ((StringValue)that).getInternalValue());
	}

	
	@Override
	protected int compareToInternal(IPropertyValue that) {
		return StringUtils.compare(this.getInternalValue(), ((StringValue)that).getInternalValue());
	}
	
	public static StringValue valueOf(String value){
		return new StringValue(value);
	}
	
}
