package com.sap.gtt.v2.exception;

import org.apache.http.HttpStatus;

public class OperationNotAllowed extends GeneralNoneTranslatableException {
    public static final String ERROR_CODE = "ERROR_CODE_OPERATION_NOT_ALLOWED";

    public OperationNotAllowed(String message) {
        super(message, null, HttpStatus.SC_BAD_REQUEST);
    }

    @Override
    public String getErrorCode() {
        return ERROR_CODE;
    }

}
