package com.sap.gtt.v2.core.domain.metadata;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * @author I321712
 */
public class Authorization implements Serializable {
    private static final long serialVersionUID = -1L;

    private String principalType;
    private String element;
    private List<String> permissions = new ArrayList<>();

    public String getPrincipalType() {
        return principalType;
    }

    public void setPrincipalType(String principalType) {
        this.principalType = principalType;
    }

    public String getElement() {
        return element;
    }

    public void setElement(String element) {
        this.element = element;
    }

    public List<String> getPermissions() {
        return new ArrayList<>(permissions);
    }

    public void addPermission(String permission) {
        this.permissions.add(permission);
    }

    public void clearPermissions() {
        this.permissions.clear();
    }
}
