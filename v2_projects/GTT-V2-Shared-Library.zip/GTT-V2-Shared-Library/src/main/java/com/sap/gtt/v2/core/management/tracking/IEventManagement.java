package com.sap.gtt.v2.core.management.tracking;

import com.sap.gtt.v2.core.domain.metadata.CurrentMetadataEntity;
import com.sap.gtt.v2.core.domain.trackedprocess.CorrelatedEvent;
import com.sap.gtt.v2.core.entity.trackedprocess.Event;
import com.sap.gtt.v2.core.runtime.model.UUIDValue;

import java.util.List;

/**
 * @author I053866
 */
public interface IEventManagement {
    /**
     * save one event
     *
     * @param event
     */
    void post(Event event);

    /**
     * save multiple events
     *
     * @param events
     */
    void post(List<Event> events);

    /**
     * getCorrelatedEventsIncludeEventTypes
     *
     * @param tpId
     * @param eventTypes
     * @return
     */
    CorrelatedEvent getCorrelatedEventsIncludeEventTypes(UUIDValue tpId, List<String> eventTypes);

    /**
     * getCorrelatedEventsExcludeEventTypes
     *
     * @param tpId
     * @param eventTypes
     * @return
     */
    CorrelatedEvent getCorrelatedEventsExcludeEventTypes(UUIDValue tpId, List<String> eventTypes);

    /**
     * query last event among eventTypes under this trackedProcess
     *
     * @param tpId
     * @param trackedProcessType
     * @param eventTypes
     * @return
     */
    Event getLastCorrelatedEventIncludeEventTypes(UUIDValue tpId, String trackedProcessType, List<String> eventTypes);

    /**
     * get core event with eventId
     *
     * @param id
     * @return only core event data
     */
    Event getSingleEventById(UUIDValue id);

    Event get(UUIDValue id);

    /**
     * get complete event
     *
     * @param id
     * @param metadata
     * @return
     */
    Event get(UUIDValue id, CurrentMetadataEntity metadata);

    /**
     * @param eventIds delete events with a set of eventId in one transaction
     */
    void delete(List<String> eventIds);
}
