package com.sap.gtt.v2.exception;

import org.apache.http.HttpStatus;

public class GTTEmbededRuleScriptException extends GeneralNoneTranslatableException {
    public static final String ERROR_CODE = "ERROR_CODE_EVENT2ACTION";

    private int line;
    private int charPositionInLine;
    private String errorReason;

    public GTTEmbededRuleScriptException(int line,
                                         int charPositionInLine, String errorReason, Throwable cause) {
        super(errorReason, cause, HttpStatus.SC_BAD_REQUEST);
        this.line = line;
        this.charPositionInLine = charPositionInLine;
        this.errorReason = errorReason;

    }

    public int getLine() {
        return line;
    }


    public int getCharPositionInLine() {
        return charPositionInLine;
    }


    public String getErrorReason() {
        return errorReason;
    }


    @Override
    public String getMessage() {
        return ("line " + this.getLine() + ":" + this.getCharPositionInLine() + " " + this.getErrorReason());
    }

    @Override
    public String getErrorCode() {
        return ERROR_CODE;
    }

}
