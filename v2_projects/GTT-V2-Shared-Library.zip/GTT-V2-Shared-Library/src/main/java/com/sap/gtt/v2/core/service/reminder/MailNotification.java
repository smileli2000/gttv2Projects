package com.sap.gtt.v2.core.service.reminder;

import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;

import com.google.gson.JsonObject;
import com.sap.gtt.v2.configuration.AccessContextHolder;
import com.sap.gtt.v2.configuration.AccessContextHolder.AccessContext;
import com.sap.gtt.v2.configuration.EnvironmentsConfiguration.VcapServiceParser.ReminderServiceInstance;
import com.sap.gtt.v2.configuration.GTTRestTemplate;
import com.sap.gtt.v2.configuration.ISAPCloudPlatformAgent.ICurrentAccessContext;
import com.sap.gtt.v2.configuration.ServiceInstancesMapping;
import com.sap.gtt.v2.core.domain.execution.ExecutionMessageDto;
import com.sap.gtt.v2.core.domain.execution.ExecutionStatus;
import com.sap.gtt.v2.core.domain.execution.Phase;
import com.sap.gtt.v2.core.management.execution.IMessageLogManagement;
import com.sap.gtt.v2.core.runtime.model.IPropertyValue;
import com.sap.gtt.v2.core.runtime.model.ObjectValue;
import com.sap.gtt.v2.log.TenantAwareLogService;
import com.sap.gtt.v2.util.GTTUtils;
import com.sap.gtt.v2.util.SpringContextUtils;

public class MailNotification extends ObjectValue implements BaseNotification, IMailNotification {
	
	public static final String POST = "post";
	
	protected static final Map<String, FunctionInterfaceDef> functionDefs = new HashMap<>();

	static{
		functionDefs.putAll(ObjectValue.functionDefs);

		List<Class<? extends IPropertyValue>> argumentEmptyType = new ArrayList<>();
		FunctionInterfaceDef funPost = new FunctionInterfaceDef(FunctionInterfaceDef.Category.SYSTEM, POST, argumentEmptyType,
				((callerObject, args) -> {
					((MailNotification)callerObject).post();
					return null;
				}));
		functionDefs.put(funPost.name,funPost);
		
	}
	@Override
	protected Map<String, FunctionInterfaceDef> getFunctionDefs(){
		return functionDefs;
	}
	
	
	
	@Override
	public String getMailUri() {
		return "";
	}
	
	@Override
	public JsonObject getRequestBody() {
		return null;
	}
	
	@Override
	public void post() {
		ICurrentAccessContext currentContext = SpringContextUtils.getBean(ICurrentAccessContext.class);
		AccessContextHolder.AccessContext accessContext = currentContext.cloneContext();
		
		SpringContextUtils.getBean(AsyncMail.class).asyncPost(accessContext, this);
	}

	@Service
	public static class AsyncMail {
		@Autowired
	    private ICurrentAccessContext currentContext;
		
		@Async
		protected void asyncPost(AccessContext accessContext, MailNotification mail) {
			doPost(accessContext, mail);
		}
		
		private IMessageLogManagement getExecutionHistoryManagement() {
	        return currentContext.createBusinessOperator().getMessageLogManagement();
	    }
		
		private void insertExecutionMessage(String tag, String status, String error) {
	        ExecutionMessageDto executionMessageDto = new ExecutionMessageDto();
	        executionMessageDto.setPhase(Phase.PROCESS.name());
	        executionMessageDto.setMessageType(status);
	        executionMessageDto.setErrorAt(Instant.now());
	        executionMessageDto.setTag(tag);
	        if(error != null) {
	        	executionMessageDto.setMessage(error);
	        }
	        getExecutionHistoryManagement().insertExecutionMessage(executionMessageDto);
	    }
		
		public void doPost(AccessContext accessContext, MailNotification mail) {
			String tag = GTTUtils.UUIDUtils.generateTimeBasedUUID().toString();
			insertExecutionMessage(tag, ExecutionStatus.PENDING.name(), null);
			
			TenantAwareLogService logService = SpringContextUtils.getBean(TenantAwareLogService.class);
			AccessContextHolder.set(accessContext);
			try {
		        String body = mail.getRequestBody().toString();
		        
		        final String uri = mail.getMailUri();
		        
		        logService.info("###> post: " + body);
				HttpHeaders headers = new HttpHeaders();
		        headers.setContentType(MediaType.APPLICATION_JSON);
		        
		        ServiceInstancesMapping serviceInstancesMapping = SpringContextUtils.getBean(ServiceInstancesMapping.class);
				ReminderServiceInstance reminderServiceInstance = serviceInstancesMapping.getReminderServiceInstance();
		        headers.setBearerAuth(reminderServiceInstance.requestTechniqueTokenForSaasSubaccount());
		        GTTRestTemplate restTemplate = SpringContextUtils.getBean(GTTRestTemplate.class);
		        restTemplate.exchange(uri, HttpMethod.POST, headers, body, String.class);
		        insertExecutionMessage(tag, ExecutionStatus.SUCCESS.name(), null);
			}
			catch(RestClientException e) {
				insertExecutionMessage(tag, ExecutionStatus.ERROR.name(), e.getMessage());
				throw e;
			}
			finally{
				AccessContextHolder.clear();
			}
		}
	}
}
