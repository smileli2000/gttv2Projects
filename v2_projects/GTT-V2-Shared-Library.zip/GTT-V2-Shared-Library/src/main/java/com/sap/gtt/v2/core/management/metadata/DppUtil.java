package com.sap.gtt.v2.core.management.metadata;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.sap.gtt.v2.core.domain.dpp.DppEntity;
import com.sap.gtt.v2.core.domain.dpp.DppProperty;
import com.sap.gtt.v2.core.domain.metadata.MetadataConstants;
import com.sap.gtt.v2.core.domain.metadata.MetadataEntity;
import com.sap.gtt.v2.core.domain.metadata.MetadataEntityElement;
import com.sap.gtt.v2.util.JsonUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

import static com.sap.gtt.v2.core.domain.metadata.MetadataConstants.*;
import java.util.stream.Collectors;

public class DppUtil {
    private static final Logger logger = LoggerFactory.getLogger(DppUtil.class);
    private static final String REPORTED_BY = "reportedBy";
    private static final String CREATED_BY_USER = "createdByUser";
    private static final String EVENT_TYPE = "eventType";
    private static final String COMSAPGTTCORE_CORE_MODEL = "com.sap.gtt.core.CoreModel";
    public static final String COMSAPGTTCORE_CORE_MODEL_NAMESPACE = "com.sap.gtt.core";
    
    private static final Map<CdsDataType, String> CDS_DATA_TYPE_EDMX_DATA_TYPE = new EnumMap<>(CdsDataType.class);
    static {
        CDS_DATA_TYPE_EDMX_DATA_TYPE.put(CdsDataType.CDS_BOOLEAN, "Edm.Boolean");
        CDS_DATA_TYPE_EDMX_DATA_TYPE.put(CdsDataType.CDS_DATE, "Edm.DateTime");
        CDS_DATA_TYPE_EDMX_DATA_TYPE.put(CdsDataType.CDS_TIMESTAMP, "Edm.DateTimeOffset");
        CDS_DATA_TYPE_EDMX_DATA_TYPE.put(CdsDataType.CDS_DECIMAL, "Edm.Decimal");
        CDS_DATA_TYPE_EDMX_DATA_TYPE.put(CdsDataType.CDS_INTEGER, "Edm.Int64");
        CDS_DATA_TYPE_EDMX_DATA_TYPE.put(CdsDataType.CDS_STRING, "Edm.String");
        CDS_DATA_TYPE_EDMX_DATA_TYPE.put(CdsDataType.CDS_UUID, "Edm.Guid");
    }

    private DppUtil() {
    }

    static String getUpsertPdmSchema(String pdmSchemaStr, List<MetadataEntity> metadataEntities) {
        //create or get pdmSchema:
        JsonObject pdmSchema = null;
        if (StringUtils.isNotBlank(pdmSchemaStr)) {
            pdmSchema = JsonUtils.generateJsonObjectFromJsonString(pdmSchemaStr);
        }
        List<DppEntity> dppEntities = findDppEntitiesElements(metadataEntities);
        dppEntities = (pdmSchema == null ? dppEntities : dppEntities.stream().filter(entity -> !MetadataConstants.CoreModelEntity.EVENT.getFullName().equals(entity.getName())).collect(Collectors.toList()));
        if (pdmSchema == null) {
            pdmSchema = DppUtil.createPdmSchema();
        }
        Set<String> entityNamesOfDpp = new HashSet();
        if (!dppEntities.isEmpty()) {
            dppEntities.forEach(e -> entityNamesOfDpp.add(e.getName()));
            Set<String> nameSpacesOfNewCSN = extractNamespace(entityNamesOfDpp);
            JsonArray entities = pdmSchema.get(PDM_ENTITIES).getAsJsonArray();
            for (String nameSpaceOfNewCSN : nameSpacesOfNewCSN) {
                removeDppEntity(nameSpaceOfNewCSN, entities);
            }
            dppEntities.forEach(e -> addPdmEntityOfTheEntity(entities, e));
        }
        return pdmSchema.toString();
    }

     static List<DppEntity> findDppEntitiesElements(List<MetadataEntity> metadataEntities) {
        List<DppEntity> dppEntities = new ArrayList();
        metadataEntities.stream().forEach(metadataEntity -> findDppEntitiesElements( metadataEntity, dppEntities));
        return dppEntities;
    }

    static void findDppEntitiesElements(MetadataEntity metadataEntity,List<DppEntity> dppEntities) {
        List<DppProperty> dppSpiProperties = new ArrayList();
        List<DppProperty> dppPiiProperties = new ArrayList();
        List<DppProperty> keyProperties = new ArrayList();
        List<DppProperty> specialDataSubjectIdProperties = new ArrayList();
        List<DppProperty> otherProperties = new ArrayList();
        DppProperty dppDataSubjectIdProperty = new DppProperty();
        metadataEntity.getElements().stream().forEach(metadataEntityElement -> setDppProperties(metadataEntityElement, dppDataSubjectIdProperty, specialDataSubjectIdProperties, dppSpiProperties, dppPiiProperties,keyProperties, otherProperties));
        //if it has dpp related properties, then do the set. But exclude ProcessEvent/TrackedProcess/Event entity from CoreModel
        if ((dppDataSubjectIdProperty.getName() != null || !specialDataSubjectIdProperties.isEmpty()) 
            && (!MetadataConstants.CoreModelEntity.EVENT.getValue().equals(metadataEntity.getBaseType()) || metadataEntity.isProcessEvent())
            && (!metadataEntity.getName().startsWith(COMSAPGTTCORE_CORE_MODEL)
                || metadataEntity.getName().equals(MetadataConstants.CoreModelEntity.EVENT.getFullName()))) {
            DppEntity dppEntity = new DppEntity();
            if (metadataEntity.getName().startsWith(COMSAPGTTCORE_CORE_MODEL)) {
                dppEntities.add(0, dppEntity);
            } else {
                dppEntities.add(dppEntity);
            }
            generateDppEntity(dppEntity, metadataEntity, dppDataSubjectIdProperty, dppSpiProperties, dppPiiProperties, keyProperties, specialDataSubjectIdProperties, otherProperties);
        }
    }

    private static void generateDppEntity(DppEntity dppEntity, MetadataEntity metadataEntity, DppProperty dppDataSubjectIdProperty, List<DppProperty> dppSpiProperties, List<DppProperty> dppPiiProperties, List<DppProperty> keyProperties, List<DppProperty> specialDataSubjectIdProperties, List<DppProperty> otherProperties) {
        dppEntity.setName(metadataEntity.getName());
        dppEntity.setEvent(!MetadataConstants.CoreModelEntity.TRACKED_PROCESS.getValue().equals(metadataEntity.getBaseType()));
        dppEntity.setPhsicalName(metadataEntity.getPhysicalName().getName());
        if (dppDataSubjectIdProperty.getName() != null && !dppSpiProperties.isEmpty()) {
            dppEntity.setSpiProperties(dppSpiProperties);
        }
        if (dppDataSubjectIdProperty.getName() != null && !dppPiiProperties.isEmpty()) {
            dppEntity.setPiiProperties(dppPiiProperties);
        }
        //if it has dpp related properties, then set the key.
        if (!keyProperties.isEmpty()) {
            dppEntity.setKeyProperties(keyProperties);
        }
        if (dppDataSubjectIdProperty.getName() != null) {
            dppEntity.setDataSubjectIdProperty(dppDataSubjectIdProperty);
        }
        if (!specialDataSubjectIdProperties.isEmpty()) {
            dppEntity.setSpecialdataSubjectIdProperties(specialDataSubjectIdProperties);
        }
        if (metadataEntity.getName().equals(MetadataConstants.CoreModelEntity.EVENT.getFullName()) && !otherProperties.isEmpty()) {
            dppEntity.setOtherProperties(otherProperties);
        }
    }

    static void setDppProperties(MetadataEntityElement metadataEntityElement,DppProperty dppDataSubjectIdProperty, List<DppProperty> specialDataSubjectIdProperties,
        List<DppProperty> dppSpiProperties, List<DppProperty> dppPiiProperties, List<DppProperty> keyProperties, List<DppProperty> otherProperties) {
        if (metadataEntityElement.isDppDataSubjectId()) {
            dppDataSubjectIdProperty.setName(metadataEntityElement.getName());
            dppDataSubjectIdProperty.setPhysicalName(metadataEntityElement.getPhysicalName());
            dppDataSubjectIdProperty.setLength(metadataEntityElement.getLength());
            dppDataSubjectIdProperty.setType(metadataEntityElement.getType());
        }
        if (CREATED_BY_USER.equalsIgnoreCase(metadataEntityElement.getName()) || REPORTED_BY.equalsIgnoreCase(metadataEntityElement.getName())) {
            DppProperty dppSpiProperty = new DppProperty();
            dppSpiProperty.setName(metadataEntityElement.getName());
            dppSpiProperty.setPhysicalName(metadataEntityElement.getPhysicalName());
            dppSpiProperty.setLength(metadataEntityElement.getLength());
            dppSpiProperty.setType(metadataEntityElement.getType());
            specialDataSubjectIdProperties.add(dppSpiProperty);
        }
        if (metadataEntityElement.isDppSpi()) {
            DppProperty dppSpiProperty = new DppProperty();
            dppSpiProperty.setName(metadataEntityElement.getName());
            dppSpiProperty.setPhysicalName(metadataEntityElement.getPhysicalName());
            dppSpiProperty.setLength(metadataEntityElement.getLength());
            dppSpiProperty.setType(metadataEntityElement.getType());
            dppSpiProperties.add(dppSpiProperty);
        }
        if (metadataEntityElement.isDppSpi()) {
            DppProperty dppPiiProperty = new DppProperty();
            dppPiiProperty.setName(metadataEntityElement.getName());
            dppPiiProperty.setPhysicalName(metadataEntityElement.getPhysicalName());
            dppPiiProperty.setLength(metadataEntityElement.getLength());
            dppPiiProperty.setType(metadataEntityElement.getType());
            dppPiiProperties.add(dppPiiProperty);
        }
        if (metadataEntityElement.isKey()) {
            DppProperty keyProperty = new DppProperty();
            keyProperty.setName(metadataEntityElement.getName());
            keyProperty.setPhysicalName(metadataEntityElement.getPhysicalName());
            keyProperty.setLength(metadataEntityElement.getLength());
            keyProperty.setType(metadataEntityElement.getType());
            keyProperties.add(keyProperty);
        }
        if (EVENT_TYPE.equalsIgnoreCase(metadataEntityElement.getName())) {
            DppProperty dppSpiProperty = new DppProperty();
            dppSpiProperty.setName(metadataEntityElement.getName());
            dppSpiProperty.setPhysicalName(metadataEntityElement.getPhysicalName());
            dppSpiProperty.setLength(metadataEntityElement.getLength());
            dppSpiProperty.setType(metadataEntityElement.getType());
            otherProperties.add(dppSpiProperty);
        }
    }

    static void removeDppEntity(String namespace, JsonArray entities) {
        int entitiesLength = entities.size();
        Set<JsonObject> needToRemoveEntityObjs = new HashSet();
        for (int i = 0; i < entitiesLength; i++) {
            JsonObject entityObj = entities.get(i).getAsJsonObject();
            String entityName = entityObj.get(PDM_NAME).getAsString();
            String nameSpaceOfOldEntity = CsnParser.getProjectNamespace(convertNameFromUnderScoreToDot(entityName));
            if (namespace.equals(nameSpaceOfOldEntity)) {
                needToRemoveEntityObjs.add(entityObj);
            }
        }
        for (JsonObject needToRemoveEntityObj : needToRemoveEntityObjs) {
            entities.remove(needToRemoveEntityObj);
        }
    }

    static Set<String> getAllNamespacesOfPdmSchema(JsonObject pdmSchemaJsonObj) {
        Set<String> namesapceSetOfPdmSchema = new HashSet();
        JsonArray entities = pdmSchemaJsonObj.getAsJsonArray(PDM_ENTITIES);
        if (entities != null && entities.size() > 0) {
            for (JsonElement entity : entities) {
                String entityNameWithUnderScore = entity.getAsJsonObject().get(PDM_NAME).getAsString();
                if (!entityNameWithUnderScore.equals(PDM_DATA_SUBJECT_IDENTITY_ENTITY_NAME)) {
                    String entityNameWithDot = convertNameFromUnderScoreToDot(entityNameWithUnderScore);
                    String namesapceWithDot = CsnParser.getProjectNamespace(entityNameWithDot);
                    namesapceSetOfPdmSchema.add(namesapceWithDot);
                }
            }
        }
        return namesapceSetOfPdmSchema;
    }

    private static Set<String> extractNamespace(Set<String> entityNames) {
        Set<String> nameSpaces = new HashSet<>();
        entityNames.forEach(e -> nameSpaces.add(CsnParser.getProjectNamespace(convertNameFromUnderScoreToDot(e))));
        return nameSpaces;
    }

    private static JsonObject createPdmSchema() {
        JsonObject pdmSchema = new JsonObject();
        pdmSchema.addProperty(PDM_NAMESPACE, PDM_CORE_NAMESPACE);
        JsonArray entities = new JsonArray();
        pdmSchema.add(PDM_ENTITIES, entities);
        //setDefaultEntityInfo
        JsonObject defaultObjectOfEntity = new JsonObject();
        entities.add(defaultObjectOfEntity);
        defaultObjectOfEntity.addProperty(PDM_NAME, PDM_DATA_SUBJECT_IDENTITY_ENTITY_NAME);
        defaultObjectOfEntity.addProperty(PDM_SEMATICS, PDM_DATA_SUBJECT_IDENTITY);
        defaultObjectOfEntity.addProperty(PDM_BUSINESS_OBJECT, PDM_DATA_SUBJECT_IDENTITY);
        defaultObjectOfEntity.addProperty(PDM_BUSINESS_NODE, PDM_DATA_SUBJECT_IDENTITY);

        JsonArray keys = new JsonArray();
        JsonObject keyObject = new JsonObject();
        keyObject.addProperty(PDM_NAME, PDM_DATA_SUBJECT_ID_PROPERTY);
        keys.add(keyObject);
        defaultObjectOfEntity.add(PDM_KEYS, keys);

        JsonArray defaultProperts = new JsonArray();
        JsonObject defaultPropertyObject = new JsonObject();
        defaultProperts.add(defaultPropertyObject);
        defaultObjectOfEntity.add(PDM_PROPERTIES, defaultProperts);

        defaultPropertyObject.addProperty(PDM_NAME, PDM_DATA_SUBJECT_ID_PROPERTY);

        defaultPropertyObject.addProperty(PDM_TYPE, CDS_DATA_TYPE_EDMX_DATA_TYPE.get(CdsDataType.CDS_STRING));
        //As MetadataEntityElement currently donot have the nuable attribute, so here hardcoded it to true to let all the attributes could be null.
        defaultPropertyObject.addProperty(PDM_NULLABLE, Boolean.TRUE);
        defaultPropertyObject.addProperty(PDM_MAXLENGTH, 255);
        defaultPropertyObject.addProperty(PDM_SEMATICS, PDM_DATA_SUBJECT_ID);
        //for the pk property, the sequence no should be -1 according to the doc.
        defaultPropertyObject.addProperty(PDM_PROPERTY, PDM_DATA_SUBJECT_ID_PROPERTY);
        return pdmSchema;
    }

    private static void addPdmEntityOfTheEntity(JsonArray entities, DppEntity dppEntity) {
        JsonObject entityObject = new JsonObject();
        entities.add(entityObject);
        setEntityHeadInfo(dppEntity.getName(), entityObject);
        setEntityKeyInfoOfTheEntity(dppEntity.getKeyProperties(), entityObject);
        setDppPropertiesInfoOfTheEntity(entityObject, dppEntity);
    }

    private static void setEntityHeadInfo(String entityName, JsonObject entityObject) {
        String entityTypeName = CsnParser.getEntityAbbrName(entityName);
        String convertedEntityName = convertNameFromDotToUnderScore(entityName);
        entityObject.addProperty(PDM_NAME, convertedEntityName);
        entityObject.addProperty(PDM_SEMATICS, PDM_BUSINESS_DATA);
        entityObject.addProperty(PDM_BUSINESS_OBJECT, entityTypeName);
        entityObject.addProperty(PDM_BUSINESS_NODE, entityTypeName);
        entityObject.addProperty(PDM_LABLE, entityName);
    }

    private static String convertNameFromDotToUnderScore(String originalName) {
        return originalName.replace(DOT, PDM_UNDER_SCORE);
    }

    private static String convertNameFromUnderScoreToDot(String originalName) {
        return originalName.replace(PDM_UNDER_SCORE, DOT);
    }

    private static void setEntityKeyInfoOfTheEntity(List<DppProperty> keyProperties, JsonObject entityObject) {
        JsonArray keys = new JsonArray();
        entityObject.add(PDM_KEYS, keys);
        keyProperties.stream().forEach(e -> {
            JsonObject keyObject = new JsonObject();
            keyObject.addProperty(PDM_NAME, e.getName());
            keys.add(keyObject);
        });
    }

    private static void setDppPropertiesInfoOfTheEntity(JsonObject entityObject, DppEntity dppEntity) {
        if (dppEntity != null) {
            JsonArray properties = new JsonArray();
            entityObject.add(PDM_PROPERTIES, properties);
            Set<String> dppPropertyNames = new HashSet();
            setDppProperties(properties, dppPropertyNames, dppEntity.getKeyProperties(), -1, PDM_DATA_SUBJECT_TECH_ID);
            DppProperty dataSubjectIdProperty = dppEntity.getDataSubjectIdProperty();
            List<DppProperty> dataSubjectIdProperties = new ArrayList();
            dataSubjectIdProperties.add(dataSubjectIdProperty != null ? dataSubjectIdProperty : dppEntity.getSpecialdataSubjectIdProperties().get(0));
            int sequenceNo = 0;
            sequenceNo = setDppProperties(properties, dppPropertyNames, dataSubjectIdProperties, sequenceNo, PDM_DATA_SUBJECT_ID);
            if (!dppEntity.getPiiProperties().isEmpty()) {
                sequenceNo = setDppProperties(properties, dppPropertyNames, dppEntity.getPiiProperties(), sequenceNo, PDM_PERSONAL_DATA);
            } else {
                logger.info("*** dppEntity.getPiiProperties is null.");
            }
            if (!dppEntity.getSpiProperties().isEmpty()) {
                setDppProperties(properties, dppPropertyNames, dppEntity.getSpiProperties(), sequenceNo, PDM_SENSITIVE_PERSONAL_DATA);
            } else {
                logger.info("*** dppEntity.getSpiProperties is null.");
            }
            if (!dppEntity.getOtherProperties().isEmpty()) {
                setDppProperties(properties, dppPropertyNames, dppEntity.getOtherProperties(), sequenceNo, null);
            }
        } else {
            logger.error(" *** in setDppPropertiesInfoOfTheEntity, dppEntity is null");
        }

    }

    private static int setDppProperties(JsonArray properties, DppProperty dppProperty, Set<String> dppPropertyNames, int sequenceNo, String pdmSemantics) {
        if (dppPropertyNames != null && !dppPropertyNames.contains(dppProperty.getName())) {
            dppPropertyNames.add(dppProperty.getName());
            JsonObject dppObject = new JsonObject();
            dppObject.addProperty(PDM_NAME, PDM_DATA_SUBJECT_ID.equals(pdmSemantics) ? PDM_DATA_SUBJECT_ID_PROPERTY : dppProperty.getName());
            dppObject.addProperty(PDM_TYPE, CDS_DATA_TYPE_EDMX_DATA_TYPE.get(dppProperty.getType()));
            setNullableProperty(pdmSemantics, dppObject);

            setMaxlengthProperty(dppProperty, dppObject);
            setSemanticsProperty(pdmSemantics, dppObject);
            //for the pk property, the sequence no should be -1 according to the doc.
            if (PDM_DATA_SUBJECT_TECH_ID.equals(pdmSemantics)) {
                dppObject.addProperty(PDM_SEQ_NO, -1);
            } else {
                ++sequenceNo;
                dppObject.addProperty(PDM_SEQ_NO, sequenceNo);
            }
            //currently there are no lable property for the MetadataEntityElement, use name instead.
            dppObject.addProperty(PDM_LABLE, PDM_DATA_SUBJECT_ID.equals(pdmSemantics) ? PDM_DATA_SUBJECT_ID_PROPERTY : dppProperty.getName());
            properties.add(dppObject);
        }
        return sequenceNo;
    }

    private static void setNullableProperty(String pdmSemantics, JsonObject dppObject) {
        //As MetadataEntityElement currently donot have the nuable attribute, so here hardcoded it to true to let all the attributes could be null.
        if (PDM_DATA_SUBJECT_TECH_ID.equals(pdmSemantics) || PDM_DATA_SUBJECT_ID.equals(pdmSemantics)) {
            dppObject.addProperty(PDM_NULLABLE, Boolean.FALSE);
        } else {
            dppObject.addProperty(PDM_NULLABLE, Boolean.TRUE);
        }
    }

    private static void setMaxlengthProperty(DppProperty dppProperty, JsonObject dppObject) {
        if (dppProperty.getLength() > 0) {
            dppObject.addProperty(PDM_MAXLENGTH, dppProperty.getLength());
        }
    }

    private static void setSemanticsProperty(String pdmSemantics, JsonObject dppObject) {
        if (pdmSemantics != null) {
            dppObject.addProperty(PDM_SEMATICS, pdmSemantics);
        }
    }


  private static int setDppProperties(JsonArray properties, Set<String> dppPropertyNames, List<DppProperty> dppProperties, int sequenceNo, String pdmSemantics) {
        if(dppProperties !=null) {
            for (DppProperty dppProperty : dppProperties) {
                if (dppPropertyNames !=null && !dppPropertyNames.contains(dppProperty.getName())) {
                    sequenceNo = setDppProperties( properties, dppProperty,  dppPropertyNames, sequenceNo,  pdmSemantics);
                }
            }
        }else {
            logger.info("***  in setDppProperties, dppProperties is null, setDppProperties is abandon.");
        }
        return sequenceNo;
    }
}
