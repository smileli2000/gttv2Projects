package com.sap.gtt.v2.core.domain.metadata;

import com.google.gson.JsonObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MetadataSwaggerInfo {
    private JsonObject swaggerObj;
    private String namespace;
    private String trackedProcessType;
    private String eventType;
    private boolean trackedProcess;
    private String applicationObjectType;
    private List<String> plannedEvents = new ArrayList<>();

    public JsonObject getSwaggerObj() {
        return swaggerObj;
    }

    public void setSwaggerObj(JsonObject swaggerObj) {
        this.swaggerObj = swaggerObj;
    }

    public String getNamespace() {
        return namespace;
    }

    public void setNamespace(String namespace) {
        this.namespace = namespace;
    }

    public String getTrackedProcessType() {
        return trackedProcessType;
    }

    public void setTrackedProcessType(String trackedProcessType) {
        this.trackedProcessType = trackedProcessType;
    }

    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    public String getApplicationObjectType() {
        return applicationObjectType;
    }

    public void setApplicationObjectType(String applicationObjectType) {
        this.applicationObjectType = applicationObjectType;
    }

    public List<String> getPlannedEvents() {
        return Collections.unmodifiableList(plannedEvents);
    }

    public void setPlannedEvents(List<String> plannedEvents) {
        this.plannedEvents = Collections.unmodifiableList(plannedEvents);
    }

    public boolean isTrackedProcess() {
        return trackedProcess;
    }

    public void setTrackedProcess(boolean trackedProcess) {
        this.trackedProcess = trackedProcess;
    }
}
