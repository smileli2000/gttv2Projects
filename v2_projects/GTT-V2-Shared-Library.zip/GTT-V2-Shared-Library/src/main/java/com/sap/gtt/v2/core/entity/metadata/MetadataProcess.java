package com.sap.gtt.v2.core.entity.metadata;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.StringJoiner;

public class MetadataProcess implements Serializable {
    private String id;
    private String metadataProjectId;
    private String trackedProcessType;
    private String applicationObjectType;
    private String trackingIdType;
    private String description;
    private List<MetadataProcessText> metadataProcessTexts = new ArrayList();
    private List<MetadataEvent> metadataEvents = new ArrayList<>();

    public MetadataProcess() {
    }

    public MetadataProcess(String id, String metadataProjectId, String trackedProcessType, String applicationObjectType
            , String trackingIdType, String description) {
        this.id = id;
        this.metadataProjectId = metadataProjectId;
        this.trackedProcessType = trackedProcessType;
        this.applicationObjectType = applicationObjectType;
        this.trackingIdType = trackingIdType;
        this.description = description;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getMetadataProjectId() {
        return metadataProjectId;
    }

    public void setMetadataProjectId(String metadataProjectId) {
        this.metadataProjectId = metadataProjectId;
    }

    public String getTrackedProcessType() {
        return trackedProcessType;
    }

    public void setTrackedProcessType(String trackedProcessType) {
        this.trackedProcessType = trackedProcessType;
    }

    public String getApplicationObjectType() {
        return applicationObjectType;
    }

    public void setApplicationObjectType(String applicationObjectType) {
        this.applicationObjectType = applicationObjectType;
    }

    public String getTrackingIdType() {
        return trackingIdType;
    }

    public void setTrackingIdType(String trackingIdType) {
        this.trackingIdType = trackingIdType;
    }

    public List<MetadataProcessText> getMetadataProcessTexts() {
        return metadataProcessTexts;
    }

    public void add(MetadataProcessText metadataProcessText) {
        this.metadataProcessTexts.add(metadataProcessText);
    }

    public void addAllMetadataProcesTexts(List<MetadataProcessText> metadataProcessTexts) {
        this.metadataProcessTexts.addAll(metadataProcessTexts);
    }

    public void clearMetadataProcessText() {
        this.metadataProcessTexts.clear();
    }

    public List<MetadataEvent> getMetadataEvents() {
        return new ArrayList<>(metadataEvents);
    }

    public void addMetadataEvent(MetadataEvent metadataEvent) {
        this.metadataEvents.add(metadataEvent);
    }

    public void clearMetadataEvents() {
        this.metadataEvents.clear();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        MetadataProcess that = (MetadataProcess) o;
        return id.equals(that.id) &&
                metadataProjectId.equals(that.metadataProjectId) &&
                Objects.equals(trackedProcessType, that.trackedProcessType) &&
                applicationObjectType.equals(that.applicationObjectType) &&
                Objects.equals(trackingIdType, that.trackingIdType);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, metadataProjectId, trackedProcessType, applicationObjectType, trackingIdType);
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", MetadataProcess.class.getSimpleName() + "[", "]")
                .add("id='" + id + "'")
                .add("metadataProjectId='" + metadataProjectId + "'")
                .add("trackedProcessType='" + trackedProcessType + "'")
                .add("applicationObjectType='" + applicationObjectType + "'")
                .add("trackingIdType='" + trackingIdType + "'")
                .add("metadataProcessTexts=" + metadataProcessTexts + "")
                .toString();
    }
}
