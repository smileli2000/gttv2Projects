package com.sap.gtt.v2.core.runtime.model;

public final class NullValue extends AbstractPropertyValue<Object> {
    
	private NullValue(){
		super(null);
	}

	public static final NullValue NULL = new NullValue();
    @Override
    public boolean isCsnPrimitive() {
        return true;
    }

    @Override
    public boolean isCollection() {
        return false;
    }

    
}
