package com.sap.gtt.v2.core.domain.trackedprocess;

import com.sap.gtt.v2.core.entity.trackedprocess.Event;

import java.util.StringJoiner;
import java.util.UUID;

public class EventWrapper {
    private UUID plannedEventId;
    private String correlationType;
    private Event event;

    public EventWrapper(UUID plannedEventId, String correlationType, Event event) {
        this.plannedEventId = plannedEventId;
        this.correlationType = correlationType;
        this.event = event;
    }

    public UUID getPlannedEventId() {
        return plannedEventId;
    }

    public void setPlannedEventId(UUID plannedEventId) {
        this.plannedEventId = plannedEventId;
    }

    public String getCorrelationType() {
        return correlationType;
    }

    public void setCorrelationType(String correlationType) {
        this.correlationType = correlationType;
    }

    public Event getEvent() {
        return event;
    }

    public void setEvent(Event event) {
        this.event = event;
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", EventWrapper.class.getSimpleName() + "[", "]")
                .add("plannedEventId='" + plannedEventId + "'")
                .add("correlationType='" + correlationType + "'")
                .add("event=" + event)
                .toString();
    }
}
