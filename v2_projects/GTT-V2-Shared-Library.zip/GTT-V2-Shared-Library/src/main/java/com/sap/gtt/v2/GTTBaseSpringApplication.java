package com.sap.gtt.v2;

import java.util.HashMap;
import java.util.Map;
import java.util.TimeZone;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.actuate.autoconfigure.security.servlet.ManagementWebSecurityAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.security.core.context.SecurityContextHolder;

import com.sap.gtt.v2.util.SpringContextUtils;
import com.sap.gtt.v2.util.SpringContextUtils.ISpringContextListener;

import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

@SpringBootApplication(scanBasePackages = "com.sap.gtt.v2"
, exclude = { SecurityAutoConfiguration.class, ManagementWebSecurityAutoConfiguration.class }
)
public abstract class GTTBaseSpringApplication extends SpringBootServletInitializer implements InitializingBean, ISpringContextListener{

	protected Map<String, Object> getDefaultParameterMap(){
		Map<String, Object> result = new HashMap<>();
		result.put("spring.profiles.default", "local");
		
		return result;
	}
	
	public void run(String[] args){
		TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
		SpringApplication application = new SpringApplication(this.getClass());
		application.setDefaultProperties(getDefaultParameterMap());
		// Enable MODE_INHERITABLETHREADLOCAL so that child thread can load thread context from parent
		SecurityContextHolder.setStrategyName(SecurityContextHolder.MODE_INHERITABLETHREADLOCAL);
		application.run(args);
		// message Basenames
		SpringContextUtils.getMessageSource().addBasenames(getMessageSourceBasenamesTobeAdded());
	}
	
	protected String [] getMessageSourceBasenamesTobeAdded(){
		return new String[]{};
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		SpringContextUtils.addContextListener(this);
	}

	@Override
	public void afterContextReady() {
		
	}
    

}
