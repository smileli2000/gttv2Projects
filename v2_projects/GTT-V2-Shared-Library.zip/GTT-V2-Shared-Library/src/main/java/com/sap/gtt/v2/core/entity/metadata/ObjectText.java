package com.sap.gtt.v2.core.entity.metadata;

import java.io.Serializable;

public class ObjectText implements Serializable {
    private String id;
    private String descr;
    private String locale;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDescr() {
        return descr;
    }

    public void setDescr(String descr) {
        this.descr = descr;
    }

    public String getLocale() {
        return locale;
    }

    public void setLocale(String locale) {
        this.locale = locale;
    }

    @Override
    public String toString() {
        return "ObjectText{" +
                "id='" + id + '\'' +
                ", descr='" + descr + '\'' +
                ", locale='" + locale + '\'' +
                '}';
    }
}
