package com.sap.gtt.v2.core.dao.execution;

import com.sap.gtt.v2.core.entity.execution.ExecutionPhase;

import java.util.List;

public interface IExecutionPhaseDao {
    ExecutionPhase queryExecutionPhase(String id);

    ExecutionPhase queryExecutionPhase(String executionHistoryId, String phase);

    List<ExecutionPhase> queryExecutionPhases(String executionHistoryId);

    void insertExecutionPhase(ExecutionPhase phase);

    void updateExecutionPhaseStatus(String id, String status);
}
