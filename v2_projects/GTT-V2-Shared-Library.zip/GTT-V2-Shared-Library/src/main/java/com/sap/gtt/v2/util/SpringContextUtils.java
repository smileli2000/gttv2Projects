package com.sap.gtt.v2.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.slf4j.MDC;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.ConstructorArgumentValues;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.beans.factory.support.GenericBeanDefinition;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.support.GenericApplicationContext;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

/**
 * 
 * @author I053866
 *
 */
@Component
public class SpringContextUtils implements ApplicationContextAware{

	private static ApplicationContext APPLICATION_CONTEXT;

	public static interface ISpringContextListener{
		public void afterContextReady();
	}
	
	private static final List<ISpringContextListener> contextListeners = new ArrayList<>();

	
	public static void addContextListener(ISpringContextListener listener){
		contextListeners.add(listener);
	}
	public static boolean isSpringEnable(){
		return APPLICATION_CONTEXT != null;
	}
	
	public static void setContext(ApplicationContext applicationContext){
		APPLICATION_CONTEXT = applicationContext;
		
	}
	@Override
	public void setApplicationContext(ApplicationContext applicationContext)
			throws BeansException {
		setContext(applicationContext); 
		
		// trigger listener
		for(ISpringContextListener listener : contextListeners){
			listener.afterContextReady();
		}
	}

	public static <T> T getBean(Class<T> clazz){
		return APPLICATION_CONTEXT.getBean(clazz);
	}
	
	public static <T> T getBean(Class<T> clazz, Object... args){
		return APPLICATION_CONTEXT.getBean(clazz, args);
	}
	
	public static Object getBean(String beanName, Object... args){
		return APPLICATION_CONTEXT.getBean(beanName, args);
	}
	
	public static Object getBean(String beanName){
		return APPLICATION_CONTEXT.getBean(beanName);
	}
	
	public static boolean containsBean(String beanName){
		return APPLICATION_CONTEXT.containsBean(beanName);
	}
	
	public static void autowireBean(Object obj){
		APPLICATION_CONTEXT.getAutowireCapableBeanFactory().autowireBean(obj);
	}
	public static <T> T createSingletonBean(Class<T> clazz, String beanName, Object[] args){
		GenericApplicationContext context = (GenericApplicationContext)APPLICATION_CONTEXT;
		GenericBeanDefinition beanDefinition = new GenericBeanDefinition();
		beanDefinition.setBeanClass(clazz);
		beanDefinition.setAutowireCandidate(false);
		if(args != null){
			ConstructorArgumentValues constructorArgumentValues = new ConstructorArgumentValues();
			for(int i=0;i<args.length;i++){
				constructorArgumentValues.addIndexedArgumentValue(i, args[i]);
			}
			beanDefinition.setConstructorArgumentValues(constructorArgumentValues);
		}
		
		context.getDefaultListableBeanFactory().registerBeanDefinition(beanName, beanDefinition);
		return context.getBean(beanName, clazz);
	}
	
	public static void destroyAndRemoveBean(String beanName){
		Object bean = getBean(beanName);
		APPLICATION_CONTEXT.getAutowireCapableBeanFactory().destroyBean(bean); // don't know why prototype bean is not affected by this call
		((BeanDefinitionRegistry)APPLICATION_CONTEXT.getAutowireCapableBeanFactory()).removeBeanDefinition(beanName);
	}
	
	public static String[] getBeanNamesForType(Class<?> clazz){
		return APPLICATION_CONTEXT.getBeanNamesForType(clazz);
	}
	public static ReloadableResourceBundleMessageSource getMessageSource(){
		return APPLICATION_CONTEXT.getBean(ReloadableResourceBundleMessageSource.class);
	}
    
    public static void supportAsynCorrespondingIdInLogs() {
        HttpServletRequest httpRequest = getHttpServletRequest();
        if (httpRequest == null) {
            return;
        }
        Object contextMap = httpRequest.getAttribute(MDC.class.getName());
        if (contextMap == null || contextMap instanceof Map) {
            return;
        }
        
        MDC.setContextMap((Map<String, String>)contextMap);
    }
    
    private static HttpServletRequest getHttpServletRequest() {
        RequestAttributes attribs = RequestContextHolder.getRequestAttributes();
        if (attribs instanceof ServletRequestAttributes) {
            return ((ServletRequestAttributes) attribs).getRequest();
        }
        return null;
    }
	
}
