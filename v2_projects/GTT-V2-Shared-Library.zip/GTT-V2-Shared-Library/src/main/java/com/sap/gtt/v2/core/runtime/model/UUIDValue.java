package com.sap.gtt.v2.core.runtime.model;

import java.util.UUID;

import com.sap.gtt.v2.exception.ValueParseException;

public final class UUIDValue extends AbstractPropertyValue<UUID> {
    private UUIDValue(UUID internalValue) {
        super(internalValue);
    }

    @Override
    public boolean isCsnPrimitive() {
        return true;
    }

    @Override
    public boolean isCollection() {
        return false;
    }

    public static UUIDValue valueOf(String uuidStr){
        try {
            UUIDValue uuid = valueOf(UUID.fromString(uuidStr));
            return uuid;
        }catch (IllegalArgumentException e){
            throw new ValueParseException(e.getLocalizedMessage(), e);
        }
    }
    
    public static UUIDValue valueOf(UUID value){
    	return new UUIDValue(value);
    }
}
