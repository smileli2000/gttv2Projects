package com.sap.gtt.v2.core.management.overdue;

import java.time.Instant;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sap.gtt.v2.core.dao.overdue.DefaultOverdueDao;
import com.sap.gtt.v2.core.dao.overdue.IOverdueDao;
import com.sap.gtt.v2.util.SpringContextUtils;

@Service(DefaultOverdueManagement.BEAN_NAME)
public class DefaultOverdueManagement implements IOverdueManagement {
	public static final String BEAN_NAME = "com.sap.gtt.v2.core.management.overdue.DefaultOverdueManagement";
	Logger logger = LoggerFactory.getLogger(DefaultOverdueManagement.class);
	

    @Override
    public Instant getPreviousDetectionTime(String jobName){
        return this.getOverdueDao().getPreviousDetectionTime(jobName);
    }

    @Override
    public int countOverduePlannedEvent(Instant from, Instant to) {
        return this.getOverdueDao().countOverduePlannedEvent(from,to);

    }

    @Override
    public List<PlannedEventIdentifier> getOverduePlannedEventsInfo(Instant from, Instant to, int skip, int top) {
        return this.getOverdueDao().getOverduePlannedEventsInfo(from,to,skip,top);
    }
    
    public static DefaultOverdueManagement getInstance() {
        return (DefaultOverdueManagement) SpringContextUtils.getBean(BEAN_NAME);
    }

    protected IOverdueDao getOverdueDao() {
        return DefaultOverdueDao.getInstance();
    }

    @Override
    public void updateOverdueInfo(String jobName,Instant jobRunTime) {
        this.getOverdueDao().updateOverdueInfo(jobName,jobRunTime);
    }
}
