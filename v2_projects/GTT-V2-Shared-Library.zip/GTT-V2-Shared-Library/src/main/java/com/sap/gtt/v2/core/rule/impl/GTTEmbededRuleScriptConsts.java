package com.sap.gtt.v2.core.rule.impl;

public interface GTTEmbededRuleScriptConsts {

	public static final String SYSTEM_VAR_TRACKED_PROCESS_BEFORE_EVENT_POST = "trackedProcessBeforeEventPost";
	public static final String SYSTEM_VAR_PLANNED_EVENT_BEFORE_EVENT_POST = "plannedEventBeforeEventPost";
	
	public static final String SYSTEM_VAR_TRACKED_PROCESS = "trackedProcess";
	public static final String SYSTEM_VAR_ACTUAL_EVENT = "actualEvent";
	public static final String SYSTEM_VAR_PLANNED_EVENT = "plannedEvent";
	
	public static final String SYSTEM_VAR_REMINDER_SERVICE = "reminderService";
}
