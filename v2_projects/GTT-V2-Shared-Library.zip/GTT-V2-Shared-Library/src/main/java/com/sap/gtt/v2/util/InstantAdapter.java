package com.sap.gtt.v2.util;

import com.google.gson.TypeAdapter;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import org.apache.commons.lang3.StringUtils;

import java.io.IOException;
import java.time.Instant;
import java.time.format.DateTimeFormatter;

/**
 * Type adapter for Instant and Long json conversion
 *
 * @author I321712
 */
public class InstantAdapter extends TypeAdapter<Instant> {
    @Override
    public void write(JsonWriter out, Instant value) throws IOException {
        if (value == null) {
            out.nullValue();
        } else {
            out.value(value.toEpochMilli());
        }
    }

    @Override
    public Instant read(JsonReader in) throws IOException {
        if (in.peek() == null) {
            return null;
        }
        String s = in.nextString();
        if (StringUtils.isBlank(s)) {
            return null;
        }
        Instant ret;
        try {
            long milliseconds = Long.parseLong(s);
            ret = Instant.ofEpochMilli(milliseconds);
        } catch (NumberFormatException ex) {
            ret = Instant.from(DateTimeFormatter.ISO_DATE_TIME.parse(s));
        }
        return ret;
    }
}