package com.sap.gtt.v2.exception;

import org.apache.http.HttpStatus;

public class LockException extends BaseRuntimeException implements ILogable {
    public static final String ERROR_CODE = "ERROR_CODE_DB_LOCK";

    public static final String MESSAGE_CODE_PROCESS_HAS_BEEN_CHANGED = LockException.class.getName() + ".ProcessHasBeenChanged";
    public static final String MESSAGE_CODE_RESOURCE_BUSY = LockException.class.getName() + ".ResourceBusy";

    public LockException(String messageCode, Throwable cause) {
        super(null, cause, messageCode, null);
    }

    public LockException(String messageCode) {
        super(messageCode, null);
    }

    @Override
    public int getHttpStatus() {
        return HttpStatus.SC_LOCKED;
    }

    @Override
    public String getErrorCode() {
        return ERROR_CODE;
    }
}
