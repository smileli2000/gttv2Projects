drop procedure gtt_schema_empty;$$

create procedure gtt_schema_empty( )
LANGUAGE SQLScript
    AS
BEGIN
	DECLARE CURSOR tableCursor FOR SELECT *  FROM TABLES where SCHEMA_NAME = CURRENT_SCHEMA;
	DECLARE LV_TABLE_NAME NVARCHAR(255);
	
	FOR tableCursorRow AS tableCursor
	DO
		LV_TABLE_NAME := tableCursorRow.TABLE_NAME;
		EXEC 'DROP TABLE ' || :LV_TABLE_NAME;
	END FOR;

END;$$

call gtt_schema_empty();$$