/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.gtt.v2.servicemanager.dto;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author I326335
 */
public class DependantServiceDtoTest {
    
    public DependantServiceDtoTest() {
    }

    /**
     * Test of getXsappname method, of class DependantServiceDto.
     */
    @Test
    public void testDependantServiceDto() {
        DependantServiceDto instance = new DependantServiceDto();
        instance.setXsappname("lbn-gtt");
        assertNotNull(instance.getXsappname());
        assertNotNull(instance.toString());
    }

}
