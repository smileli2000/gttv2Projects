package com.sap.gtt.v2.servicemanager;

import static org.mockito.Mockito.when;

import com.google.gson.JsonObject;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.sap.gtt.v2.configuration.EnvironmentsConfiguration.VcapServiceParser.ManagedHanaServiceInstance.ManagedHanaTenant;
import com.sap.gtt.v2.configuration.EnvironmentsConfiguration.VcapServiceParser.SaasRegistryServiceInstance.ReturnOfGetSubscriptions;
import com.sap.gtt.v2.configuration.GTTRestTemplate;
import com.sap.gtt.v2.configuration.local.LocalMockedCurrentAccessContext;
import com.sap.gtt.v2.log.TenantAwareLogService;
import com.sap.gtt.v2.servicemanager.App;
import com.sap.gtt.v2.tenant.TenantService;
import com.sap.gtt.v2.tenant.GTTTenantSetting;
import com.sap.gtt.v2.util.JsonUtils;

import ch.qos.logback.classic.Level;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = App.class)
@ActiveProfiles("test")
@Transactional // Enable transaction and rollback after each @Test
@Rollback
public abstract class BaseTest {
	public static final String TEST_URL_REQUEST_TOKEN = "lbn-platform.authentication.sap.hana.ondemand.com/oauth/token";
	public static final String TEST_URL_APP_SUBSCRIPTION = "/saas-manager/v1/application/subscriptions";
	public static final String TEST_URL_SERVICE_SUBSCRIPTION = "/saas-manager/v1/service/subscriptions";
	public static final String TEST_URL_MANAGED_HANA = "/managed/managed_instances/e370d2b7-e830-41db-b64c-2dacd7b6c8d1";
	
	
	@MockBean
	private GTTRestTemplate restTemplate;
	@Value("${TEST_DATA_DUMMY_TOKEN}")
	private String dummyToken;
	
	@Value("${TEST_DATA_APP_ALL_SUBSCRIPTIONS}")
	private String appAllSubscription;
	
	@Value("${TEST_DATA_SERVICE_ALL_SUBSCRIPTIONS}")
	private String serviceAllSubscription;
	
	@Value("${TEST_DATA_MANAGED_HANA_TENANT}")
	private String managedHanaTenant;
	
	
	@Mock
	protected TenantService tenantService ;
	@InjectMocks
	@Autowired
	protected TenantAwareLogService logService;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);

    	/*AccessContext accessContext = new AccessContext(LocalMockedServletRequestListener.TENANT_SUBACCOUNT_ID,
    			LocalMockedServletRequestListener.LOGON_NAME,
    			LocalMockedServletRequestListener.TENANT_SUBDOMAIN,
    			LocalMockedServletRequestListener.CLONE_SERVICE_INSTANCE_ID,
				LocaleContextHolder.getLocale(),
				null
				);
		AccessContextHolder.set(accessContext);*/

		GTTTenantSetting tenantSetting1 = new GTTTenantSetting();
		/*tenantSetting1.setSubaccountId(LocalMockedCurrentAccessContext.TENANT_SUBACCOUNT_ID);
		tenantSetting1.setCloneServiceInstanceId(LocalMockedCurrentAccessContext.CLONE_SERVICE_INSTANCE_ID);
		tenantSetting1.setLogLevel(Level.DEBUG.levelStr);*/
		when(tenantService.get(ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(tenantSetting1);

		ResponseEntity<Object> getManagedHanaTenantResponse = new ResponseEntity<>(JsonUtils.generateBeanFromJson(managedHanaTenant, ManagedHanaTenant.class),HttpStatus.OK);
    	when(restTemplate.exchange(ArgumentMatchers.contains(TEST_URL_MANAGED_HANA), ArgumentMatchers.same(HttpMethod.GET), ArgumentMatchers.any(),ArgumentMatchers.any() , ArgumentMatchers.any())).thenReturn(getManagedHanaTenantResponse);
	
		ResponseEntity<Object> tokenResponse = new ResponseEntity<>(dummyToken,HttpStatus.OK);
    	when(restTemplate.exchange(ArgumentMatchers.contains(TEST_URL_REQUEST_TOKEN), ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(tokenResponse);
    	
    	ResponseEntity<Object> appSubscriptionsResponse = new ResponseEntity<>(JsonUtils.generateBeanFromJson(appAllSubscription, ReturnOfGetSubscriptions.class),HttpStatus.OK);
    	when(restTemplate.exchange(ArgumentMatchers.contains(TEST_URL_APP_SUBSCRIPTION), ArgumentMatchers.same(HttpMethod.GET), ArgumentMatchers.any(),ArgumentMatchers.any() , ArgumentMatchers.any())).thenReturn(appSubscriptionsResponse);

        JsonObject technicalToken = new JsonObject();
        technicalToken.addProperty("access_token", "abc");
        ResponseEntity<Object> technicalTokenResponse = new ResponseEntity<>(technicalToken.toString(), HttpStatus.OK);
        when(restTemplate.exchange(ArgumentMatchers.contains(TEST_URL_REQUEST_TOKEN), ArgumentMatchers.same(HttpMethod.GET), ArgumentMatchers.any(),ArgumentMatchers.any() , ArgumentMatchers.any())).thenReturn(technicalTokenResponse);
	
    	ResponseEntity<Object> serviceSubscriptionsResponse = new ResponseEntity<>(JsonUtils.generateBeanFromJson(serviceAllSubscription, ReturnOfGetSubscriptions.class),HttpStatus.OK);
    	when(restTemplate.exchange(ArgumentMatchers.contains(TEST_URL_SERVICE_SUBSCRIPTION), ArgumentMatchers.same(HttpMethod.GET), ArgumentMatchers.any(),ArgumentMatchers.any() , ArgumentMatchers.any())).thenReturn(serviceSubscriptionsResponse);
	
	}

	public GTTTenantSetting getDummyTenantSetting(){
		return tenantService.get("", "");
	}
}