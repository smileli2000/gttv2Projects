package com.sap.gtt.v2.servicemanager.subscription;

import org.junit.Test;

public class SubscriptionExceptionTest{

    @Test(expected = SubscriptionException.class)
	public void testException() {
		throw new SubscriptionException("Test Message", new RuntimeException());
	}

	
}
