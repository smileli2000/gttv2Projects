package com.sap.gtt.v2.servicemanager.upgrade;

import com.google.gson.JsonObject;
import com.sap.gtt.v2.servicemanager.GTTInstance;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class ExampleOfUseJdbcTemplate extends AbstractCustomDbUpgrade {
    Logger logger = LoggerFactory.getLogger(ExampleOfUseJdbcTemplate.class);

    public ExampleOfUseJdbcTemplate() {}


    public JsonObject doUpgrade(GTTInstance gttInstance, String methodParamJson) {
        JsonObject jsonObject = new JsonObject();
        jdbcTemplate.execute("CREATE TABLE IF NOT EXISTS UPGRADE_DUMMY(ID NVARCHAR(36))");
        return jsonObject;
    }
}
