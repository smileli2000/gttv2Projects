/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.gtt.v2.servicemanager.management;


import static org.junit.Assert.assertEquals;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.sap.gtt.v2.configuration.EnvironmentsConfiguration.VcapServiceParser.DatabaseServiceInstance.DatabaseType;
import com.sap.gtt.v2.configuration.local.LocalMockedCurrentAccessContext;
import com.sap.gtt.v2.servicemanager.BaseTest;
import com.sap.gtt.v2.servicemanager.GTTInstance;
import com.sap.gtt.v2.servicemanager.GTTInstanceMapping;
import com.sap.gtt.v2.servicemanager.GTTPhysicalStorage;
import com.sap.gtt.v2.servicemanager.GTTPhysicalStorage.PhysicalTypeNotSupportException;
import com.sap.gtt.v2.util.GTTUtils;



public class ServiceManagerManagementTest extends BaseTest{
	private static final String DATABASE_INSTANCE_NAME_SHARED_PLAN = "lbn-gtt-core-storage-h2";
	private static final String DATABASE_PHYSICAL_ID = "8495da7f-88a1-4fc7-afbd-9544d0fb26c9";
	private static final String DUMMY = "DUMMY";
	
	
	@Autowired
    private ServiceManagerManagement serviceManager; 
	
	private GTTInstance gttInstanceStandaloneForApp;
	private GTTInstance gttInstanceStandaloneForCloneInstance;
    private GTTInstance gttInstanceShared;
    
    private GTTInstanceMapping gttInstanceMappingStandaloneForApp;
    private GTTInstanceMapping gttInstanceMappingStandaloneForCloneInstance;
    private GTTInstanceMapping gttInstanceMappingShared;
    
    private GTTPhysicalStorage  gttPhysicalStorage;
    
   
    @Override
    public void setUp(){
    	super.setUp();
    	
    	gttInstanceShared = new GTTInstance();
    	gttInstanceShared.setInstanceName(LocalMockedCurrentAccessContext.CLONE_SERVICE_INSTANCE_NAME_SHARED_PLAN);
    	gttInstanceShared.setStorageType(GTTInstance.STORAGE_TYPE_HANA);
    	gttInstanceShared.fillStorageConnectionInfoForSharedPlan(DATABASE_INSTANCE_NAME_SHARED_PLAN);
    
    	gttInstanceStandaloneForApp = new GTTInstance();
    	gttInstanceStandaloneForApp.setInstanceName(LocalMockedCurrentAccessContext.TENANT_SUBDOMAIN);
    	gttInstanceStandaloneForApp.setStorageType(GTTInstance.STORAGE_TYPE_MANAGED_HANA);
    	gttInstanceStandaloneForApp.fillStorageConnectionInfoForStandalonePlan(LocalMockedCurrentAccessContext.TENANT_SUBACCOUNT_ID,
    			LocalMockedCurrentAccessContext.TENANT_SUBDOMAIN, null, DATABASE_PHYSICAL_ID);
    
    	gttInstanceStandaloneForCloneInstance = new GTTInstance();
    	gttInstanceStandaloneForCloneInstance.setInstanceName(LocalMockedCurrentAccessContext.TENANT_SUBDOMAIN);
    	gttInstanceStandaloneForCloneInstance.setStorageType(GTTInstance.STORAGE_TYPE_MANAGED_HANA);
    	gttInstanceStandaloneForCloneInstance.fillStorageConnectionInfoForStandalonePlan(LocalMockedCurrentAccessContext.TENANT_SUBACCOUNT_ID,
    			LocalMockedCurrentAccessContext.TENANT_SUBDOMAIN, LocalMockedCurrentAccessContext.CLONE_SERVICE_INSTANCE_ID_STANDALONE_PLAN, DATABASE_PHYSICAL_ID);
    
    
    	gttInstanceMappingStandaloneForApp = new GTTInstanceMapping();
    	gttInstanceMappingStandaloneForApp.setPlan(GTTInstanceMapping.PLAN_STANDALONE);
    	gttInstanceMappingStandaloneForApp.setSubaccountId(LocalMockedCurrentAccessContext.TENANT_SUBACCOUNT_ID);
    	gttInstanceMappingStandaloneForApp.setSubdomain(LocalMockedCurrentAccessContext.TENANT_SUBDOMAIN);
    	
    	gttInstanceMappingStandaloneForCloneInstance = new GTTInstanceMapping();
    	gttInstanceMappingStandaloneForCloneInstance.setPlan(GTTInstanceMapping.PLAN_STANDALONE);
    	gttInstanceMappingStandaloneForCloneInstance.setSubaccountId(LocalMockedCurrentAccessContext.TENANT_SUBACCOUNT_ID);
    	gttInstanceMappingStandaloneForCloneInstance.setSubdomain(LocalMockedCurrentAccessContext.TENANT_SUBDOMAIN);
    	gttInstanceMappingStandaloneForCloneInstance.setCloneInstanceId(LocalMockedCurrentAccessContext.CLONE_SERVICE_INSTANCE_ID_STANDALONE_PLAN);
    	
    	gttInstanceMappingShared = new GTTInstanceMapping();
    	gttInstanceMappingShared.setPlan(GTTInstanceMapping.PLAN_SHARED);
    	gttInstanceMappingShared.setSubaccountId(LocalMockedCurrentAccessContext.TENANT_SUBACCOUNT_ID);
    	gttInstanceMappingShared.setSubdomain(LocalMockedCurrentAccessContext.TENANT_SUBDOMAIN);
    	gttInstanceMappingShared.setCloneInstanceId(LocalMockedCurrentAccessContext.CLONE_SERVICE_INSTANCE_ID_SHARED_PLAN);
    	
    	gttPhysicalStorage = new GTTPhysicalStorage();
    	gttPhysicalStorage.setGlobalAccountId(DUMMY + "1");
    	gttPhysicalStorage.setGlobalAccountName(DUMMY + "2");
    	gttPhysicalStorage.setOrgId(DUMMY + "3");
    	gttPhysicalStorage.setOrgName(DUMMY + "4");
    	gttPhysicalStorage.setPhysicalId(DATABASE_PHYSICAL_ID);
    	gttPhysicalStorage.setPhysicalType(DatabaseType.hana.name());
    	gttPhysicalStorage.setSpaceId(DUMMY + "5");
    	gttPhysicalStorage.setSpaceName(DUMMY + "6");
    	
    	/*JsonObject jsonObject = JsonUtils.generateJsonObjectFromJsonString(vcapService);
    	
    	doReturn(new ManagedHanaServiceInstanceDummy(JsonUtils.getByPath(ServiceCategory.managedhana.getCategoryName(), jsonObject).getAsJsonArray().get(0).getAsJsonObject())).when(serviceInstancesMapping).getManagedHanaServiceInstance();
    */
    
    }

   @Test
   public void testCreateGTTInstanceForSharedPlan(){
	  
	  GTTInstance creatingGTTInstance = GTTUtils.createAndCopyBean(gttInstanceShared, GTTInstance.class, true);
	  creatingGTTInstance.setInstanceName("   " + creatingGTTInstance.getInstanceName() + "   ");
	  
	  String id = serviceManager.createGTTInstanceForSharedPlan(creatingGTTInstance, DATABASE_INSTANCE_NAME_SHARED_PLAN);
	  GTTInstance gttInstance = serviceManager.getGTTInstance(id);
	  assertEquals(gttInstanceShared.getInstanceName(),gttInstance.getInstanceName());
	  assertEquals(gttInstanceShared.getStorageConnectionInfo(),gttInstance.getStorageConnectionInfo());
	  assertEquals(gttInstanceShared.getStorageType(),gttInstance.getStorageType());
   }
   
   @Test
   public void testCreateGTTInstanceForStandalonePlan(){
	   GTTInstance creatingGTTInstance = GTTUtils.createAndCopyBean(gttInstanceStandaloneForApp, GTTInstance.class, true);
	   creatingGTTInstance.setInstanceName("   " + creatingGTTInstance.getInstanceName() + "   ");
		  
		  
	  String id = serviceManager.createGTTInstanceForStandalonePlan(creatingGTTInstance, 
			  LocalMockedCurrentAccessContext.TENANT_SUBACCOUNT_ID, 
			  LocalMockedCurrentAccessContext.TENANT_SUBDOMAIN, 
			  null,
			  DATABASE_PHYSICAL_ID
	  );
	  GTTInstance gttInstance = serviceManager.getGTTInstance(id);
	  assertEquals(gttInstanceStandaloneForApp.getInstanceName(),gttInstance.getInstanceName());
	  assertEquals(gttInstanceStandaloneForApp.getStorageConnectionInfo(),gttInstance.getStorageConnectionInfo());
	  assertEquals(gttInstanceStandaloneForApp.getStorageType(),gttInstance.getStorageType());
   }
   
   @Test
   public void testCreateGTTInstanceValidation(){
	  serviceManager.createGTTInstance(gttInstanceShared);
	  
	  GTTInstance creatingGTTInstance = GTTUtils.createAndCopyBean(gttInstanceShared, GTTInstance.class, true);
	  try{
		  serviceManager.createGTTInstance(creatingGTTInstance);
	  }
	  catch(ServiceManagerException e){
		  Assert.assertEquals(String.format(ServiceManagerManagement.GTT_INSTANCE_NAME_ALREADY_EXISTS, creatingGTTInstance.getInstanceName()), e.getMessage());
			 
	  }
	  
	  creatingGTTInstance = GTTUtils.createAndCopyBean(gttInstanceShared, GTTInstance.class, true);
	  creatingGTTInstance.setInstanceName("    ");
	  try{
		  serviceManager.createGTTInstance(creatingGTTInstance);
	  }
	  catch(ServiceManagerException e){
		  Assert.assertEquals(String.format(ServiceManagerManagement.GTT_INSTANCE_MISSING_INSTANCE_NAME), e.getMessage());
		 
	  }
	  
	  
	  creatingGTTInstance = GTTUtils.createAndCopyBean(gttInstanceShared, GTTInstance.class, true);
	  creatingGTTInstance.setNamespace("");
	  creatingGTTInstance.setInstanceName(creatingGTTInstance.getInstanceName() + "1");
	  creatingGTTInstance.setStorageConnectionInfo("         ");
	  try{
		  serviceManager.createGTTInstance(creatingGTTInstance);
	  }
	  catch(ServiceManagerException e){
		  Assert.assertEquals(String.format(ServiceManagerManagement.GTT_INSTANCE_CONNECTION_INFO_MISSING), e.getMessage());
	  }
	  
	  
	  
	  Assert.assertTrue(true);
	 
   
   }
   
   @Test
   public void testUpdateGTTInstanceValidation(){
	  try{
		  serviceManager.validGTTInstance(gttInstanceShared, false);
	  }
	  catch(ServiceManagerException e){
		  Assert.assertEquals(String.format(ServiceManagerManagement.GTT_INSTANCE_NOT_FOUND,gttInstanceShared.getId()), e.getMessage());
	  }
	   
	  serviceManager.createGTTInstance(gttInstanceShared);
	  
	  GTTInstance creatingGTTInstance = GTTUtils.createAndCopyBean(gttInstanceShared, GTTInstance.class, true);
	  creatingGTTInstance.setInstanceName("INSTANCE_NAME_CHANGE");
	  try{
		  serviceManager.validGTTInstance(creatingGTTInstance, false);
	  }
	  catch(ServiceManagerException e){
		  Assert.assertEquals(String.format(ServiceManagerManagement.GTT_INSTANCE_NAME_CANNOT_BE_CHANGED,gttInstanceShared.getInstanceName(),creatingGTTInstance.getInstanceName()), e.getMessage());
	  }
   }
   
   @Test
   public void testCreateGTTInstanceMapping(){
	   String gttInstanceId = serviceManager.createGTTInstanceForSharedPlan(gttInstanceShared, DATABASE_INSTANCE_NAME_SHARED_PLAN);
	   
	   gttInstanceMappingShared.setInstanceId(gttInstanceId);
	   GTTInstanceMapping creatingGTTInstanceMapping = GTTUtils.createAndCopyBean(gttInstanceMappingShared, GTTInstanceMapping.class, true);
	   creatingGTTInstanceMapping.setSubdomain("        " + creatingGTTInstanceMapping.getSubdomain() + "    ");
	   String id = serviceManager.createGTTInstanceMapping(creatingGTTInstanceMapping);
	   
	   GTTInstanceMapping createdGTTInstanceMapping = serviceManager.getGTTInstanceMapping(id);
	   assertEquals(gttInstanceMappingShared.getCloneInstanceId(), createdGTTInstanceMapping.getCloneInstanceId());
	   assertEquals(gttInstanceMappingShared.getInstanceId(), createdGTTInstanceMapping.getInstanceId());
	   assertEquals(gttInstanceMappingShared.getPlan(), createdGTTInstanceMapping.getPlan());
	   assertEquals(gttInstanceMappingShared.getSubaccountId(), createdGTTInstanceMapping.getSubaccountId());
	   assertEquals(gttInstanceMappingShared.getSubdomain(), createdGTTInstanceMapping.getSubdomain());
   
   }
   
   @Test
   public void testCreateGTTInstanceMappingValidation(){
	   String gttInstanceId = serviceManager.createGTTInstanceForSharedPlan(gttInstanceShared, DATABASE_INSTANCE_NAME_SHARED_PLAN);
	   
	   
	   // SHARED PLAN
	   GTTInstanceMapping creatingGTTInstanceMapping = GTTUtils.createAndCopyBean(gttInstanceMappingShared, GTTInstanceMapping.class, true);
	 
	   try{
		   serviceManager.createGTTInstanceMapping(creatingGTTInstanceMapping);
	   }
	   catch(ServiceManagerException e){
		   Assert.assertEquals(String.format(ServiceManagerManagement.GTT_INSTANCE_MAPPING_MISSING_INSTANCE_ID), e.getMessage());

	   }
	   
	   creatingGTTInstanceMapping = GTTUtils.createAndCopyBean(gttInstanceMappingShared, GTTInstanceMapping.class, true);
	   creatingGTTInstanceMapping.setInstanceId(gttInstanceId);
	   creatingGTTInstanceMapping.setCloneInstanceId("     ");
	   try{
		   serviceManager.createGTTInstanceMapping(creatingGTTInstanceMapping);
	   }
	   catch(ServiceManagerException e){
		   Assert.assertEquals(String.format(ServiceManagerManagement.GTT_INSTANCE_MAPPING_MISSING_CLONE_INSTANCE_ID), e.getMessage());
	   }
	  
   
	   creatingGTTInstanceMapping = GTTUtils.createAndCopyBean(gttInstanceMappingShared, GTTInstanceMapping.class, true);
	   creatingGTTInstanceMapping.setInstanceId("NOT_EXISTS");
	   try{
		   serviceManager.createGTTInstanceMapping(creatingGTTInstanceMapping);
	   }
	   catch(ServiceManagerException e){
		   Assert.assertEquals(String.format(ServiceManagerManagement.GTT_INSTANCE_NOT_FOUND,creatingGTTInstanceMapping.getInstanceId()), e.getMessage());
		  
	   }
	   
	   // STANDALONE PLAN
	   creatingGTTInstanceMapping = GTTUtils.createAndCopyBean(gttInstanceMappingStandaloneForApp, GTTInstanceMapping.class, true);
	   creatingGTTInstanceMapping.setSubaccountId("    ");
	   try{
		   serviceManager.createGTTInstanceMapping(creatingGTTInstanceMapping);
	   }
	   catch(ServiceManagerException e){
		   Assert.assertEquals(String.format(ServiceManagerManagement.GTT_INSTANCE_MAPPING_MISSING_SUBACCOUNT_ID), e.getMessage());
	   }
	   
	   creatingGTTInstanceMapping = GTTUtils.createAndCopyBean(gttInstanceMappingStandaloneForApp, GTTInstanceMapping.class, true);
	   creatingGTTInstanceMapping.setSubdomain("    ");
	   try{
		   serviceManager.createGTTInstanceMapping(creatingGTTInstanceMapping);
	   }
	   catch(ServiceManagerException e){
		   Assert.assertEquals(String.format(ServiceManagerManagement.GTT_INSTANCE_MAPPING_MISSING_SUBDOMAIN), e.getMessage());
	   }
   }
   
   @Test
   public void testCreateGTTPhysicalStorage(){
	  
	   String id = serviceManager.createGTTPhysicalStorage(gttPhysicalStorage);
	   GTTPhysicalStorage createdGTTPhysicalStorage = serviceManager.getGTTPhysicalStorage(id);
   
	   assertEquals(gttPhysicalStorage.getGlobalAccountId(), createdGTTPhysicalStorage.getGlobalAccountId());
	   assertEquals(gttPhysicalStorage.getGlobalAccountName(), createdGTTPhysicalStorage.getGlobalAccountName());
	   assertEquals(gttPhysicalStorage.getOrgId(), createdGTTPhysicalStorage.getOrgId());
	   assertEquals(gttPhysicalStorage.getOrgName(), createdGTTPhysicalStorage.getOrgName());
	   assertEquals(gttPhysicalStorage.getPhysicalId(), createdGTTPhysicalStorage.getPhysicalId());
	   assertEquals(gttPhysicalStorage.getPhysicalType(), createdGTTPhysicalStorage.getPhysicalType());
	   assertEquals(gttPhysicalStorage.getSpaceId(), createdGTTPhysicalStorage.getSpaceId());
	   assertEquals(gttPhysicalStorage.getSpaceName(), createdGTTPhysicalStorage.getSpaceName());
	      
   }
   
   @Test
   public void testCreateGTTPhysicalStorageValidation(){
	  
	   GTTPhysicalStorage creatingGTTPhysicalStorage = GTTUtils.createAndCopyBean(gttPhysicalStorage, GTTPhysicalStorage.class, true);
	   creatingGTTPhysicalStorage.setPhysicalId("         ");
	   try{
		   serviceManager.createGTTPhysicalStorage(gttPhysicalStorage);
	   }
	   catch(ServiceManagerException e){
		   Assert.assertEquals(String.format(ServiceManagerManagement.GTT_PHYSICAL_STORAGE_MISSING_PHYSICAL_ID), e.getMessage());

	   }
	  
	   creatingGTTPhysicalStorage = GTTUtils.createAndCopyBean(gttPhysicalStorage, GTTPhysicalStorage.class, true);
	   creatingGTTPhysicalStorage.setPhysicalType(DatabaseType.h2.name());
	   try{
		   serviceManager.createGTTPhysicalStorage(gttPhysicalStorage);
	   }
	   catch(PhysicalTypeNotSupportException e){
		   Assert.assertTrue(true);
	   }
   }
   
   @Test
   public void testDeleteGTTInstance(){
	   GTTInstance creatingGTTInstance = GTTUtils.createAndCopyBean(gttInstanceShared, GTTInstance.class, true);
	   GTTInstance createdGTTInstance = serviceManager.getGTTInstance(serviceManager.createGTTInstance(creatingGTTInstance));
	   
	   serviceManager.deleteGTTInstance(createdGTTInstance.getId());
	   
	   try{
		   serviceManager.deleteGTTInstance(createdGTTInstance.getId());
	   }
	   catch(ServiceManagerException e){
		   Assert.assertEquals(String.format(ServiceManagerManagement.GTT_INSTANCE_NOT_FOUND, createdGTTInstance.getId()), e.getMessage());
	   }
		
	}
   
   @Test
   public void testDeleteGTTInstanceMapping(){
	   GTTInstance createdGTTInstance = serviceManager.getGTTInstance(serviceManager.createGTTInstance(gttInstanceShared));
	   
	   gttInstanceMappingShared.setInstanceId(createdGTTInstance.getId());
	   GTTInstanceMapping creatingGTTInstanceMapping = GTTUtils.createAndCopyBean(gttInstanceMappingShared, GTTInstanceMapping.class, true);
	   GTTInstanceMapping createdGTTInstanceMapping = serviceManager.getGTTInstanceMapping(serviceManager.createGTTInstanceMapping(creatingGTTInstanceMapping));
	   
	   serviceManager.deleteGTTInstanceMapping(createdGTTInstanceMapping.getId());
	   
	   try{
		   serviceManager.deleteGTTInstanceMapping(createdGTTInstanceMapping.getId());
	   }
	   catch(ServiceManagerException e){
		   Assert.assertEquals(String.format(ServiceManagerManagement.GTT_INSTANCE_MAPPING_NOT_FOUND, createdGTTInstanceMapping.getId()), e.getMessage());
	   }
		
	}
   
   
   @Test
   public void testDeleteGTTPhysicalStorage(){
	   GTTPhysicalStorage createdGTTPhysicalStorage = serviceManager.getGTTPhysicalStorage(serviceManager.createGTTPhysicalStorage(gttPhysicalStorage));
	   
	   serviceManager.deleteGTTPhysicalStorage(createdGTTPhysicalStorage.getId());
	   
	   try{
		   serviceManager.deleteGTTPhysicalStorage(createdGTTPhysicalStorage.getId());
	   }
	   catch(ServiceManagerException e){
		   Assert.assertEquals(String.format(ServiceManagerManagement.GTT_PHYSICAL_STORAGE_NOT_FOUND, createdGTTPhysicalStorage.getId()), e.getMessage());
	   }
		
	}
   
   @Test 
   public void testDeprovisionSharedPlan(){
	   GTTInstance createdGTTInstance = serviceManager.getGTTInstance(serviceManager.createGTTInstance(gttInstanceShared));
	   gttInstanceMappingShared.setInstanceId(createdGTTInstance.getId());
	   GTTInstanceMapping creatingGTTInstanceMapping = GTTUtils.createAndCopyBean(gttInstanceMappingShared, GTTInstanceMapping.class, true);
	   GTTInstanceMapping createdGTTInstanceMapping = serviceManager.getGTTInstanceMapping(serviceManager.createGTTInstanceMapping(creatingGTTInstanceMapping));
	   
	   Assert.assertTrue(serviceManager.gttInstanceMappingExists(createdGTTInstanceMapping.getSubaccountId(), createdGTTInstanceMapping.getCloneInstanceId()));
	   serviceManager.deprovision(createdGTTInstanceMapping);
	   Assert.assertFalse(serviceManager.gttInstanceMappingExists(createdGTTInstanceMapping.getSubaccountId(), createdGTTInstanceMapping.getCloneInstanceId()));
	   
	   Assert.assertNotNull(serviceManager.getGTTInstance(createdGTTInstanceMapping.getInstanceId()));
	   
	}
   
   @Test 
   public void testDeprovisionStandalonePlan(){
	   GTTInstance createdGTTInstance = serviceManager.getGTTInstance(serviceManager.createGTTInstance(gttInstanceStandaloneForApp));
	   gttInstanceMappingStandaloneForApp.setInstanceId(createdGTTInstance.getId());
	   GTTInstanceMapping creatingGTTInstanceMapping = GTTUtils.createAndCopyBean(gttInstanceMappingStandaloneForApp, GTTInstanceMapping.class, true);
	   GTTInstanceMapping createdGTTInstanceMapping = serviceManager.getGTTInstanceMapping(serviceManager.createGTTInstanceMapping(creatingGTTInstanceMapping));
	   
	   Assert.assertTrue(serviceManager.gttInstanceMappingExists(createdGTTInstanceMapping.getSubaccountId(), createdGTTInstanceMapping.getCloneInstanceId()));
	   Assert.assertNotNull(serviceManager.getGTTInstance(createdGTTInstanceMapping.getInstanceId()));
	   
	   serviceManager.deprovision(createdGTTInstanceMapping);
	   Assert.assertFalse(serviceManager.gttInstanceMappingExists(createdGTTInstanceMapping.getSubaccountId(), createdGTTInstanceMapping.getCloneInstanceId()));
	   
	   try{
		   serviceManager.getGTTInstance(createdGTTInstanceMapping.getInstanceId());
	   }
	   catch(ServiceManagerException e){
		   Assert.assertEquals(String.format(ServiceManagerManagement.GTT_INSTANCE_NOT_FOUND, createdGTTInstanceMapping.getInstanceId()), e.getMessage());
	   }
	   
	}
   
   @Test
   public void testGetGTTInstanceByName(){
	   serviceManager.getGTTInstance(serviceManager.createGTTInstance(gttInstanceShared));
	  
	   serviceManager.getGTTInstanceByName(gttInstanceShared.getInstanceName());
	   try{
		   serviceManager.getGTTInstanceByName("NOT_EXISTS");
	   }
	   catch(ServiceManagerException e){
		   Assert.assertEquals(String.format(ServiceManagerManagement.GTT_INSTANCE_BY_NAME_NOT_FOUND, "NOT_EXISTS"), e.getMessage());
	   }
		
	}
   
   @Test
   public void testGetGTTInstanceMappingBySubaccountIdAndCloneInstanceId(){
	   GTTInstance createdGTTInstance = serviceManager.getGTTInstance(serviceManager.createGTTInstance(gttInstanceShared));
	   gttInstanceMappingShared.setInstanceId(createdGTTInstance.getId());
	   GTTInstanceMapping creatingGTTInstanceMapping = GTTUtils.createAndCopyBean(gttInstanceMappingShared, GTTInstanceMapping.class, true);
	   GTTInstanceMapping createdGTTInstanceMapping = serviceManager.getGTTInstanceMapping(serviceManager.createGTTInstanceMapping(creatingGTTInstanceMapping));
	   
	   Assert.assertNotNull(serviceManager.getGTTInstanceMappingBySubaccountIdAndCloneInstanceId(createdGTTInstanceMapping.getSubaccountId(), createdGTTInstanceMapping.getCloneInstanceId()));
	   
	   try{
		   serviceManager.getGTTInstanceMappingBySubaccountIdAndCloneInstanceId(createdGTTInstanceMapping.getSubaccountId(), "NOT_EXISTS");
		   
	   }
	   catch(ServiceManagerException e){
		   Assert.assertEquals(String.format(ServiceManagerManagement.GTT_INSTANCE_MAPPING_BY_SUBACCOUNT_ID_CLONEINSTANCE_ID_NOT_FOUND, createdGTTInstanceMapping.getSubaccountId(), "NOT_EXISTS"), e.getMessage());
	   }
	  
	}
   
   @Test
   public void testGetGTTInstanceMappings(){
	   GTTInstance createdGTTInstance = serviceManager.getGTTInstance(serviceManager.createGTTInstance(gttInstanceShared));
	   
	   gttInstanceMappingShared.setInstanceId(createdGTTInstance.getId());
	   GTTInstanceMapping creatingGTTInstanceMapping = GTTUtils.createAndCopyBean(gttInstanceMappingShared, GTTInstanceMapping.class, true);
	   serviceManager.getGTTInstanceMapping(serviceManager.createGTTInstanceMapping(creatingGTTInstanceMapping));
	   
	   
	   createdGTTInstance = serviceManager.getGTTInstance(serviceManager.createGTTInstance(gttInstanceStandaloneForApp));
	   gttInstanceMappingStandaloneForApp.setInstanceId(createdGTTInstance.getId());
	   creatingGTTInstanceMapping = GTTUtils.createAndCopyBean(gttInstanceMappingStandaloneForApp, GTTInstanceMapping.class, true);
	   serviceManager.getGTTInstanceMapping(serviceManager.createGTTInstanceMapping(creatingGTTInstanceMapping));
	   
	   Assert.assertEquals(2, serviceManager.getGTTInstanceMappings().size());
	}
   
   @Test
   public void testGetGTTInstanceMappingsByCloneInstanceId(){
	   GTTInstance createdGTTInstance = serviceManager.getGTTInstance(serviceManager.createGTTInstance(gttInstanceShared));
	   gttInstanceMappingShared.setInstanceId(createdGTTInstance.getId());
	   GTTInstanceMapping creatingGTTInstanceMapping = GTTUtils.createAndCopyBean(gttInstanceMappingShared, GTTInstanceMapping.class, true);
	   GTTInstanceMapping createdGTTInstanceMapping = serviceManager.getGTTInstanceMapping(serviceManager.createGTTInstanceMapping(creatingGTTInstanceMapping));
	   
	   Assert.assertNotNull(serviceManager.getGTTInstanceMappingBySubaccountIdAndCloneInstanceId(createdGTTInstanceMapping.getSubaccountId(), createdGTTInstanceMapping.getCloneInstanceId()));
	   
	   Assert.assertEquals(1, serviceManager.getGTTInstanceMappingsByCloneInstanceId(createdGTTInstanceMapping.getCloneInstanceId()).size());
	  
	  
	}
   
   @Test
   public void testGetGTTInstances(){
	   serviceManager.createGTTInstance(gttInstanceShared);
	   serviceManager.createGTTInstance(gttInstanceStandaloneForApp);
	   
	   Assert.assertEquals(2, serviceManager.getGTTInstances().size());
	}
   
   @Test
   public void testGetGTTPhysicalStorages(){
	   serviceManager.createGTTPhysicalStorage(gttPhysicalStorage);
	   
	   Assert.assertEquals(1, serviceManager.getGTTPhysicalStorages().size());
	}
   
   @Test
   public void testGetGTTPhysicalStorage(){
	   String id = serviceManager.createGTTPhysicalStorage(gttPhysicalStorage);
	   Assert.assertNotNull(serviceManager.getGTTPhysicalStorage(id));
	   try{
		   serviceManager.getGTTPhysicalStorage("NOT_EXISTS");
	   }
	   catch(ServiceManagerException e){
		   Assert.assertEquals(String.format(ServiceManagerManagement.GTT_PHYSICAL_STORAGE_NOT_FOUND, "NOT_EXISTS"), e.getMessage());
	   }
	}
   
   @Test
   public void testGetGTTPhysicalStoragesByType(){
	   serviceManager.createGTTPhysicalStorage(gttPhysicalStorage);
	   
	   Assert.assertEquals(1, serviceManager.getGTTPhysicalStoragesByType(DatabaseType.hana.name()).size());
	}
   
   
   @Test
   public void testProvisionForSharedPlanOK(){
	   GTTInstance createdGTTInstance = serviceManager.getGTTInstance(serviceManager.createGTTInstance(gttInstanceShared));
	   gttInstanceMappingShared.setInstanceId(createdGTTInstance.getId());
	   
	   Assert.assertEquals(0, serviceManager.getGTTInstanceMappings().size());
	   Assert.assertEquals(1, serviceManager.getGTTInstances().size());
	   
	   serviceManager.provisionForSharedPlan(gttInstanceMappingShared);
	   Assert.assertNotNull(serviceManager.getGTTInstanceMappingBySubaccountIdAndCloneInstanceId(gttInstanceMappingShared.getSubaccountId(), gttInstanceMappingShared.getCloneInstanceId()));
	   Assert.assertEquals(1, serviceManager.getGTTInstanceMappings().size());
	   Assert.assertEquals(1, serviceManager.getGTTInstances().size());
   }

   /**
    * Not sure why the "when" stub is NOT working particularly for TEST_URL_MANAGED_HANA mock
    */
  /* @Test
   public void testProvisionForStandalonePlan(){
	   serviceManager.createGTTPhysicalStorage(gttPhysicalStorage);
	   
	   Assert.assertEquals(0, serviceManager.getGTTInstanceMappings().size());
	   Assert.assertEquals(0, serviceManager.getGTTInstances().size());
	   
	   System.out.print("ceshi:" +serviceManager + " / " +  gttInstanceMappingStandaloneForApp);
	   serviceManager.provisionForStandalonePlan(gttInstanceMappingStandaloneForApp, GTTInstance.STORAGE_TYPE_MANAGED_HANA);
	   
	   Assert.assertEquals(1, serviceManager.getGTTInstanceMappings().size());
	   Assert.assertEquals(1, serviceManager.getGTTInstances().size());
	}*/
   
   
}
