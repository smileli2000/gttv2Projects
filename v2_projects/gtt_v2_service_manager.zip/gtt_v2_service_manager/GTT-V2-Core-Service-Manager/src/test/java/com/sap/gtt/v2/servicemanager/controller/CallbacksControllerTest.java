/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.gtt.v2.servicemanager.controller;


import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.doThrow;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.junit.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;

import com.sap.gtt.v2.configuration.ServiceInstancesMapping;
import com.sap.gtt.v2.configuration.local.LocalMockedCurrentAccessContext;
import com.sap.gtt.v2.exception.MultiExceptionContainer;
import com.sap.gtt.v2.servicemanager.BaseTest;
import com.sap.gtt.v2.servicemanager.dto.DependantServiceDto;
import com.sap.gtt.v2.servicemanager.dto.PayloadDataDto;
import com.sap.gtt.v2.servicemanager.management.ServiceManagerManagement;
import com.sap.gtt.v2.servicemanager.subscription.SubscriptionService;
import com.sap.gtt.v2.tenant.GTTTenantSetting;


/**
 *
 * @author I326335
 */
public class CallbacksControllerTest extends BaseTest{
    
	private static final String CLONE_INSTANCE_ID_NOT_EXIST = "CLONE_INSTANCE_ID_NOT_EXIST";
    @Autowired
    private ServiceManagerManagement serviceManager; // must be explicitly @Autowired
    
    @InjectMocks
    @Autowired
    private CallbacksController callbacksController;
   
    @Autowired
    private ServiceInstancesMapping serviceInstancesMapping;
    
	@Mock
	private SubscriptionService subscriptionService;
	
   
    
    private PayloadDataDto appSubscriptionPayload;
    private PayloadDataDto serviceSubscriptionPayload;
    
    
    @Override
    public void setUp(){
    	super.setUp();

    	serviceManager.getClass();
    	
    	appSubscriptionPayload = new PayloadDataDto();
    	appSubscriptionPayload.setSubscribedSubaccountId(LocalMockedCurrentAccessContext.TENANT_SUBACCOUNT_ID);
    	appSubscriptionPayload.setSubscribedSubdomain(LocalMockedCurrentAccessContext.TENANT_SUBDOMAIN);
    	appSubscriptionPayload.setSubscriptionAppId(serviceInstancesMapping.getUaaServiceInstance().getXsappname());
    
    	serviceSubscriptionPayload = new PayloadDataDto();
    	serviceSubscriptionPayload.setSubscribedSubaccountId(LocalMockedCurrentAccessContext.TENANT_SUBACCOUNT_ID);
    	serviceSubscriptionPayload.setSubscribedSubdomain(LocalMockedCurrentAccessContext.TENANT_SUBDOMAIN);
    	serviceSubscriptionPayload.setSubscriptionAppId("test-lbn-gtt-core_sbx!t6660");
    	serviceSubscriptionPayload.setDependantServiceInstanceAppIds(new String[]{
    			LocalMockedCurrentAccessContext.CLONE_SERVICE_INSTANCE_ID_SHARED_PLAN + "!b6660|lbn-gtt-core_sbx!b6660"
    	
    	});
    	
    	doThrow(new RuntimeException()).when(subscriptionService).onSubscribe(ArgumentMatchers.anyString(), ArgumentMatchers.anyString(), ArgumentMatchers.eq(CLONE_INSTANCE_ID_NOT_EXIST));
    	doThrow(new RuntimeException()).when(subscriptionService).onUnsubscribe(ArgumentMatchers.anyString(), ArgumentMatchers.eq(CLONE_INSTANCE_ID_NOT_EXIST));
    	
    }

    /**
     * Test of callbackDependencies method, of class CallbacksController.
     */
    @Test
    public void testCallbackAppDependencies() {
        
        List<DependantServiceDto> result = callbacksController.callbackAppDependencies();
        assertEquals(6, result.size());
    }

   
    @Test
    public void testCallbackAppTenantSubscribeOK(){
    	GTTTenantSetting tenantSetting = getDummyTenantSetting();
        String appUrl = callbacksController.callbackAppTenantSubscribe(LocalMockedCurrentAccessContext.TENANT_SUBACCOUNT_ID,appSubscriptionPayload);
        assertEquals("https://lbn-platform-lbn-gtt-flp-sbx.cfapps.sap.hana.ondemand.com", appUrl);
    }
    
    @Test
    public void testCallbackAppTenantSubscribeFailed(){
    	GTTTenantSetting tenantSetting = getDummyTenantSetting();
    	appSubscriptionPayload.setSubscriptionAppId("NOT_EXIST");
        String appUrl = callbacksController.callbackAppTenantSubscribe(LocalMockedCurrentAccessContext.TENANT_SUBACCOUNT_ID,appSubscriptionPayload);
        assertEquals(StringUtils.EMPTY, appUrl);
    }

    @Test
    public void testCallbackAppTenantUnsubscribeOK(){
    	GTTTenantSetting tenantSetting = getDummyTenantSetting();
        callbacksController.callbackAppTenantUnsubscribe(LocalMockedCurrentAccessContext.TENANT_SUBACCOUNT_ID,appSubscriptionPayload);
    }

    
    @Test
    public void testCallbackServiceDependencies() {
        
        List<DependantServiceDto> result = callbacksController.callbackServiceDependencies();
        assertEquals(1, result.size());
    }
    
    @Test
    public void testCallbackServiceTenantSubscribeOK(){
    	GTTTenantSetting tenantSetting = getDummyTenantSetting();
        callbacksController.callbackServiceTenantSubscribe(LocalMockedCurrentAccessContext.TENANT_SUBACCOUNT_ID,serviceSubscriptionPayload);
        
    }
    
    @Test
    public void testCallbackServiceTenantSubscribeFailed1(){
    	GTTTenantSetting tenantSetting = getDummyTenantSetting();
    	serviceSubscriptionPayload.setSubscriptionAppId(serviceInstancesMapping.getUaaServiceInstance().getXsappname());
    	callbacksController.callbackServiceTenantSubscribe(LocalMockedCurrentAccessContext.TENANT_SUBACCOUNT_ID,serviceSubscriptionPayload);
    }

    @Test(expected = MultiExceptionContainer.class)
    public void testCallbackServiceTenantSubscribeFailed2(){
    	GTTTenantSetting tenantSetting = getDummyTenantSetting();
    	serviceSubscriptionPayload.setDependantServiceInstanceAppIds(new String[]{
    			CLONE_INSTANCE_ID_NOT_EXIST+ "!b6660|lbn-gtt-core_sbx!b6660"
    	});
    	callbacksController.callbackServiceTenantSubscribe(LocalMockedCurrentAccessContext.TENANT_SUBACCOUNT_ID,serviceSubscriptionPayload);
    }
    
    @Test
    public void testCallbackServiceTenantUnsubscribeOK(){
    	GTTTenantSetting tenantSetting = getDummyTenantSetting();
        callbacksController.callbackServiceTenantUnsubscribe(LocalMockedCurrentAccessContext.TENANT_SUBACCOUNT_ID, serviceSubscriptionPayload);
    }
    
    @Test
    public void testCallbackServiceTenantUnsubscribeFailed1(){
    	GTTTenantSetting tenantSetting = getDummyTenantSetting();
    	serviceSubscriptionPayload.setSubscriptionAppId(serviceInstancesMapping.getUaaServiceInstance().getXsappname());
        callbacksController.callbackServiceTenantUnsubscribe(LocalMockedCurrentAccessContext.TENANT_SUBACCOUNT_ID, serviceSubscriptionPayload);
    }
    
    @Test(expected = MultiExceptionContainer.class)
    public void testCallbackServiceTenantUnsubscribeFailed2(){
    	GTTTenantSetting tenantSetting = getDummyTenantSetting();
    	serviceSubscriptionPayload.setDependantServiceInstanceAppIds(new String[]{
    			CLONE_INSTANCE_ID_NOT_EXIST+ "!b6660|lbn-gtt-core_sbx!b6660"
    	});
        callbacksController.callbackServiceTenantUnsubscribe(LocalMockedCurrentAccessContext.TENANT_SUBACCOUNT_ID, serviceSubscriptionPayload);
    }
}
