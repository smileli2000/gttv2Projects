/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.gtt.v2.servicemanager.dto;

import java.util.Map;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author I326335
 */
public class PayloadDataDtoTest {
    
    public PayloadDataDtoTest() {
    }

    /**
     * Test of getSubscriptionAppName method, of class PayloadDataDto.
     */
    @Test
    public void testPayloadDataDto() {
        PayloadDataDto instance = new PayloadDataDto();
        instance = new PayloadDataDto();
        instance.setSubscribedSubdomain("");
        instance.setSubscribedTenantId("");
        instance.setSubscriptionAppId("");
        instance.setSubscriptionAppName("");
        instance.setSubscriptionAppPlan("");
        instance.setSubscriptionAppAmount(0);
        instance.setAdditionalInformation(null);
        instance.setDependantServiceInstanceAppIds(new String[]{});
        assertEquals("", instance.getSubscribedSubdomain());
        assertEquals("", instance.getSubscribedTenantId());
        assertEquals("", instance.getSubscriptionAppId());
        assertEquals("", instance.getSubscriptionAppName());
        assertEquals("", instance.getSubscriptionAppPlan());
        assertEquals(0, instance.getSubscriptionAppAmount());
        assertNotNull(instance.getAdditionalInformation());
        assertNotNull(instance.getDependantServiceInstanceAppIds());
        assertNotNull(instance.toString());
    }

}
