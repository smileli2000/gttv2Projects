/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.gtt.v2.servicemanager.configuration;

import com.sap.gtt.v2.configuration.EnvironmentsConfiguration;
import com.sap.gtt.v2.configuration.ServiceInstancesMapping;
import java.util.HashMap;
import org.junit.Test;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;
import org.springframework.security.config.annotation.ObjectPostProcessor;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.test.util.ReflectionTestUtils;

/**
 *
 * @author I326335
 */
public class CloudSecurityConfigurationTest {
    
    /**
     * Test of configure method, of class CloudSecurityConfiguration.
     */
    @Test
    public void testConfigure() throws Exception {
        ServiceInstancesMapping serviceInstanceMapping = mock(ServiceInstancesMapping.class);
        given(serviceInstanceMapping.getUaaServiceInstance()).willReturn(mock(EnvironmentsConfiguration.VcapServiceParser.UaaServiceInstance.class));
        CloudSecurityConfiguration instance = new CloudSecurityConfiguration();
        ReflectionTestUtils.setField(instance, "serviceInstanceMapping", serviceInstanceMapping);
        HttpSecurity http = new HttpSecurity(mock(ObjectPostProcessor.class), mock(AuthenticationManagerBuilder.class), new HashMap<Class<? extends Object>, Object>());
        instance.configure(http);
    }
    
}
