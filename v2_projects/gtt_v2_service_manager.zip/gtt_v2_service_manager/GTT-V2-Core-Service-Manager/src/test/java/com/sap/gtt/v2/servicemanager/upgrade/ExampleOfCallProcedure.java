package com.sap.gtt.v2.servicemanager.upgrade;

import com.google.gson.JsonObject;
import com.sap.gtt.v2.servicemanager.GTTInstance;
import com.sap.gtt.v2.util.JsonUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

@Service
public class ExampleOfCallProcedure extends AbstractCustomDbUpgrade {
    public static final String NAME = "name";
    public static final String MESSAGE = "message";
    public static final String LACK_OF_NAME_PROPERTY_FOR_THE_INPUT_JSON = "Lack of name property for the input json.";

    public ExampleOfCallProcedure() {}


    public JsonObject doUpgrade(GTTInstance gttInstance, String methodParamJson) {
        JsonObject returnObj = new JsonObject();
        if (StringUtils.isNotBlank(methodParamJson)) {
            JsonObject jsonObject = JsonUtils.generateJsonObjectFromJsonString(methodParamJson);
            if (jsonObject.has(NAME)) {
                String sqlScriptFileName = jsonObject.get(NAME).getAsString();
                gttInstance.parseStorageConnectionInfo().getStorage().upgrade(sqlScriptFileName);
            } else {
                returnObj.addProperty(MESSAGE, LACK_OF_NAME_PROPERTY_FOR_THE_INPUT_JSON);
            }
        }
        return returnObj;
    }
}
