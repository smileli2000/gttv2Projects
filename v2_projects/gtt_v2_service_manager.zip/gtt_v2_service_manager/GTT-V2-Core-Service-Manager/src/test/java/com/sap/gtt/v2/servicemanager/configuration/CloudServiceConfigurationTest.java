/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.gtt.v2.servicemanager.configuration;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.sap.gtt.v2.configuration.ServiceInstancesMapping;
import com.sap.gtt.v2.servicemanager.BaseTest;

/**
 *
 * @author I326335
 */
public class CloudServiceConfigurationTest extends BaseTest {
  
   
	@Autowired
	private ServiceInstancesMapping serviceInstancesMapping;
	
	@Test
	public void testServiceManagerDatasource(){
		CloudServiceConfiguration cloudServiceConfiguration = new CloudServiceConfiguration();
		Assert.assertNotNull(cloudServiceConfiguration.serviceManagerDataSource(serviceInstancesMapping));
	}
	
    /*@Test(expected = InternalError.class)
    public void testSecureStoreDataSourceWithExceedSize() {
        Map<String, EnvironmentsConfiguration.VcapServiceParser.JdbcEnabledDatabaseServiceInstance> secureStoreServiceInstanceMap = new HashMap<>();
        EnvironmentsConfiguration.VcapServiceParser.JdbcEnabledDatabaseServiceInstance jdbcInstance = mock(EnvironmentsConfiguration.VcapServiceParser.JdbcEnabledDatabaseServiceInstance.class);
        secureStoreServiceInstanceMap.put("instance1", jdbcInstance);
        secureStoreServiceInstanceMap.put("instance2", jdbcInstance);
        ServiceInstancesMapping serviceInstanceMapping = new ServiceInstancesMapping();
        ReflectionTestUtils.setField(serviceInstanceMapping, "secureStoreServiceInstanceMap", secureStoreServiceInstanceMap);
        CloudServiceConfiguration instance = new CloudServiceConfiguration();
       // ReflectionTestUtils.setField(instance, "serviceInstancesMapping", serviceInstanceMapping);
        instance.serviceManagerDataSource(serviceInstanceMapping);
    }

    @Test(expected = InternalError.class)
    public void testSecureStoreDataSourceWithoutDataSource() {
        Map<String, EnvironmentsConfiguration.VcapServiceParser.JdbcEnabledDatabaseServiceInstance> secureStoreServiceInstanceMap = new HashMap<>();
        ServiceInstancesMapping serviceInstanceMapping = new ServiceInstancesMapping();
        ReflectionTestUtils.setField(serviceInstanceMapping, "secureStoreServiceInstanceMap", secureStoreServiceInstanceMap);
        CloudServiceConfiguration instance = new CloudServiceConfiguration();
       // ReflectionTestUtils.setField(instance, "serviceInstancesMapping", serviceInstanceMapping);
        instance.serviceManagerDataSource(serviceInstanceMapping);
    }*/
    
}
