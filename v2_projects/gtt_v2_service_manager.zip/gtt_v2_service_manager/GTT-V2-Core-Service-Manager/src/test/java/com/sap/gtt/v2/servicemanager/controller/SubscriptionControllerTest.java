/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.gtt.v2.servicemanager.controller;

import com.sap.gtt.v2.configuration.local.LocalMockedCurrentAccessContext;
import com.sap.gtt.v2.log.TenantAwareLogService;
import com.sap.gtt.v2.servicemanager.subscription.SubscriptionService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

/**
 *
 * @author I326335
 */
@RunWith(MockitoJUnitRunner.class)
public class SubscriptionControllerTest {
    @InjectMocks
    private SubscriptionController subscriptionController;
    @Mock
    private TenantAwareLogService tenantAwareLogService;
    @Mock
    private SubscriptionService subscriptionService;
    
    public SubscriptionControllerTest() {
    }

    /**
     * Test of updateDependencies method, of class SubscriptionController.
     */
    @Test
    public void testUpdateDependencies() {
        subscriptionController.updateServiceDependencies();
        subscriptionController.updateApplicationDependencies();
    }
    
    @Test
    public void testGetSubscription() {
        subscriptionController.getApplicationSubscription(LocalMockedCurrentAccessContext.TENANT_SUBACCOUNT_ID);
        subscriptionController.getServiceSubscriptions(LocalMockedCurrentAccessContext.TENANT_SUBACCOUNT_ID);
    }

    @Test
    public void testCreateSubscription() {
        subscriptionController.createApplicationSubscription(LocalMockedCurrentAccessContext.TENANT_SUBACCOUNT_ID);
        subscriptionController.createServiceSubscription(LocalMockedCurrentAccessContext.TENANT_SUBACCOUNT_ID,LocalMockedCurrentAccessContext.CLONE_SERVICE_INSTANCE_ID_STANDALONE_PLAN, LocalMockedCurrentAccessContext.TENANT_SUBDOMAIN);
    }
    
    @Test
    public void testUpdateSubscription() {
        subscriptionController.updateApplicationSubscription(LocalMockedCurrentAccessContext.TENANT_SUBACCOUNT_ID);
        subscriptionController.updateServiceSubscription(LocalMockedCurrentAccessContext.TENANT_SUBACCOUNT_ID,LocalMockedCurrentAccessContext.CLONE_SERVICE_INSTANCE_ID_STANDALONE_PLAN, LocalMockedCurrentAccessContext.TENANT_SUBDOMAIN);
    }
    
    @Test
    public void testDeleteSubscription() {
        subscriptionController.deleteApplicationSubscription(LocalMockedCurrentAccessContext.TENANT_SUBACCOUNT_ID);
        subscriptionController.deleteServiceSubscription(LocalMockedCurrentAccessContext.TENANT_SUBACCOUNT_ID,LocalMockedCurrentAccessContext.CLONE_SERVICE_INSTANCE_ID_STANDALONE_PLAN);
    }
}
