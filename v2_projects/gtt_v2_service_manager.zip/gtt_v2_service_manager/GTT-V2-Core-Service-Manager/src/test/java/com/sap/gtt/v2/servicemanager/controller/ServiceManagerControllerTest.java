package com.sap.gtt.v2.servicemanager.controller;

import static org.junit.Assert.assertNotNull;

import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.datasource.init.CannotReadScriptException;

import com.sap.gtt.v2.configuration.EnvironmentsConfiguration.VcapServiceParser.DatabaseServiceInstance.DatabaseType;
import com.sap.gtt.v2.configuration.local.LocalMockedCurrentAccessContext;
import com.sap.gtt.v2.servicemanager.BaseTest;
import com.sap.gtt.v2.servicemanager.GTTInstance;
import com.sap.gtt.v2.servicemanager.GTTInstanceMapping;
import com.sap.gtt.v2.servicemanager.GTTInstanceMapping.PlanNotSupportException;
import com.sap.gtt.v2.servicemanager.GTTPhysicalStorage;
import com.sap.gtt.v2.servicemanager.controller.ServiceManagerController.ProvisionParams;
import com.sap.gtt.v2.servicemanager.management.ServiceManagerException;
import com.sap.gtt.v2.servicemanager.subscription.SubscriptionService;
import com.sap.gtt.v2.tenant.GTTTenantSetting;

public class ServiceManagerControllerTest extends BaseTest{
	private static final String DATABASE_INSTANCE_NAME_SHARED_PLAN = "lbn-gtt-core-storage-h2";
	private static final String DATABASE_PHYSICAL_ID = "8495da7f-88a1-4fc7-afbd-9544d0fb26c9";
	private static final String DUMMY = "DUMMY";
	
	@Mock
	private SubscriptionService subscriptionService;
	
	@Autowired
	@InjectMocks
	private ServiceManagerController serviceManagerController;
	
	private GTTInstance gttInstanceStandaloneForApp;
	private GTTInstance gttInstanceStandaloneForCloneInstance;
    private GTTInstance gttInstanceShared;
    
    private GTTInstanceMapping gttInstanceMappingStandaloneForApp;
    private GTTInstanceMapping gttInstanceMappingStandaloneForCloneInstance;
    private GTTInstanceMapping gttInstanceMappingShared;
    
    private GTTPhysicalStorage  gttPhysicalStorage;
    
    @Override
    public void setUp(){
    	super.setUp();
    	
    	gttInstanceShared = new GTTInstance();
    	gttInstanceShared.setInstanceName(LocalMockedCurrentAccessContext.CLONE_SERVICE_INSTANCE_NAME_SHARED_PLAN);
    	gttInstanceShared.setStorageType(GTTInstance.STORAGE_TYPE_HANA);
    	gttInstanceShared.fillStorageConnectionInfoForSharedPlan(DATABASE_INSTANCE_NAME_SHARED_PLAN);
    
    	gttInstanceStandaloneForApp = new GTTInstance();
    	gttInstanceStandaloneForApp.setInstanceName(LocalMockedCurrentAccessContext.TENANT_SUBDOMAIN);
    	gttInstanceStandaloneForApp.setStorageType(GTTInstance.STORAGE_TYPE_MANAGED_HANA);
    	gttInstanceStandaloneForApp.fillStorageConnectionInfoForStandalonePlan(LocalMockedCurrentAccessContext.TENANT_SUBACCOUNT_ID,
    			LocalMockedCurrentAccessContext.TENANT_SUBDOMAIN, null, DATABASE_PHYSICAL_ID);
    
    	gttInstanceStandaloneForCloneInstance = new GTTInstance();
    	gttInstanceStandaloneForCloneInstance.setInstanceName(LocalMockedCurrentAccessContext.TENANT_SUBDOMAIN);
    	gttInstanceStandaloneForCloneInstance.setStorageType(GTTInstance.STORAGE_TYPE_MANAGED_HANA);
    	gttInstanceStandaloneForCloneInstance.fillStorageConnectionInfoForStandalonePlan(LocalMockedCurrentAccessContext.TENANT_SUBACCOUNT_ID,
    			LocalMockedCurrentAccessContext.TENANT_SUBDOMAIN, LocalMockedCurrentAccessContext.CLONE_SERVICE_INSTANCE_ID_STANDALONE_PLAN, DATABASE_PHYSICAL_ID);
    
    
    	gttInstanceMappingStandaloneForApp = new GTTInstanceMapping();
    	gttInstanceMappingStandaloneForApp.setPlan(GTTInstanceMapping.PLAN_STANDALONE);
    	gttInstanceMappingStandaloneForApp.setSubaccountId(LocalMockedCurrentAccessContext.TENANT_SUBACCOUNT_ID);
    	gttInstanceMappingStandaloneForApp.setSubdomain(LocalMockedCurrentAccessContext.TENANT_SUBDOMAIN);
    	
    	gttInstanceMappingStandaloneForCloneInstance = new GTTInstanceMapping();
    	gttInstanceMappingStandaloneForCloneInstance.setPlan(GTTInstanceMapping.PLAN_STANDALONE);
    	gttInstanceMappingStandaloneForCloneInstance.setSubaccountId(LocalMockedCurrentAccessContext.TENANT_SUBACCOUNT_ID);
    	gttInstanceMappingStandaloneForCloneInstance.setSubdomain(LocalMockedCurrentAccessContext.TENANT_SUBDOMAIN);
    	gttInstanceMappingStandaloneForCloneInstance.setCloneInstanceId(LocalMockedCurrentAccessContext.CLONE_SERVICE_INSTANCE_ID_STANDALONE_PLAN);
    	
    	gttInstanceMappingShared = new GTTInstanceMapping();
    	gttInstanceMappingShared.setPlan(GTTInstanceMapping.PLAN_SHARED);
    	gttInstanceMappingShared.setSubaccountId(LocalMockedCurrentAccessContext.TENANT_SUBACCOUNT_ID);
    	gttInstanceMappingShared.setSubdomain(LocalMockedCurrentAccessContext.TENANT_SUBDOMAIN);
    	gttInstanceMappingShared.setCloneInstanceId(LocalMockedCurrentAccessContext.CLONE_SERVICE_INSTANCE_ID_SHARED_PLAN);
    	
    	gttPhysicalStorage = new GTTPhysicalStorage();
    	gttPhysicalStorage.setGlobalAccountId(DUMMY + "1");
    	gttPhysicalStorage.setGlobalAccountName(DUMMY + "2");
    	gttPhysicalStorage.setOrgId(DUMMY + "3");
    	gttPhysicalStorage.setOrgName(DUMMY + "4");
    	gttPhysicalStorage.setPhysicalId(DATABASE_PHYSICAL_ID);
   	gttPhysicalStorage.setPhysicalType(DatabaseType.hana.name());
    	gttPhysicalStorage.setSpaceId(DUMMY + "5");
    	gttPhysicalStorage.setSpaceName(DUMMY + "6");
    	
    }
    
	@Test
	public void testCreateGTTInstanceSharedPlan() {
    	
		GTTTenantSetting tenantSetting = getDummyTenantSetting();
		
		assertNotNull(serviceManagerController.createGTTInstance(gttInstanceShared,
				GTTInstanceMapping.PLAN_SHARED, LocalMockedCurrentAccessContext.TENANT_SUBACCOUNT_ID,
				LocalMockedCurrentAccessContext.TENANT_SUBDOMAIN, 
				LocalMockedCurrentAccessContext.CLONE_SERVICE_INSTANCE_ID_SHARED_PLAN, 
				DATABASE_PHYSICAL_ID, DATABASE_INSTANCE_NAME_SHARED_PLAN)
				);
		
		
    }
	@Test
	public void testCreateGTTInstanceStandalonePlan() {
    	
		GTTTenantSetting tenantSetting = getDummyTenantSetting();
		
		assertNotNull(serviceManagerController.createGTTInstance(gttInstanceStandaloneForApp,
				GTTInstanceMapping.PLAN_STANDALONE, LocalMockedCurrentAccessContext.TENANT_SUBACCOUNT_ID,
				LocalMockedCurrentAccessContext.TENANT_SUBDOMAIN, 
				LocalMockedCurrentAccessContext.CLONE_SERVICE_INSTANCE_ID_STANDALONE_PLAN, 
				DATABASE_PHYSICAL_ID, null)
				);
		
		
    }
	
	@Test(expected = PlanNotSupportException.class)
	public void testCreateGTTInstanceFailed() {
    	
		GTTTenantSetting tenantSetting = getDummyTenantSetting();
		
		assertNotNull(serviceManagerController.createGTTInstance(gttInstanceStandaloneForApp,
				"NOT_EXISTS", LocalMockedCurrentAccessContext.TENANT_SUBACCOUNT_ID,
				LocalMockedCurrentAccessContext.TENANT_SUBDOMAIN, 
				LocalMockedCurrentAccessContext.CLONE_SERVICE_INSTANCE_ID_STANDALONE_PLAN, 
				DATABASE_PHYSICAL_ID, null)
				);
		
    }
	
	@Test
	public void testCreateGTTInstanceMapping() {
		GTTTenantSetting tenantSetting = getDummyTenantSetting();
		GTTInstance createdGTTInstance = serviceManagerController.createGTTInstance(gttInstanceShared,
				GTTInstanceMapping.PLAN_SHARED, LocalMockedCurrentAccessContext.TENANT_SUBACCOUNT_ID,
				LocalMockedCurrentAccessContext.TENANT_SUBDOMAIN, 
				LocalMockedCurrentAccessContext.CLONE_SERVICE_INSTANCE_ID_SHARED_PLAN, 
				DATABASE_PHYSICAL_ID, DATABASE_INSTANCE_NAME_SHARED_PLAN)
		;
		gttInstanceMappingShared.setInstanceId(createdGTTInstance.getId());
		assertNotNull(serviceManagerController.createGTTInstanceMapping(gttInstanceMappingShared));
    }
	
	@Test
	public void testCreateGTTPhysicalStorage() {
		assertNotNull(serviceManagerController.createGTTPhysicalStorage(gttPhysicalStorage));

    }
	
	@Test
	public void testDeleteGTTInstance() {
		GTTTenantSetting tenantSetting = getDummyTenantSetting();
		GTTInstance createdGTTInstance = serviceManagerController.createGTTInstance(gttInstanceShared,
				GTTInstanceMapping.PLAN_SHARED, LocalMockedCurrentAccessContext.TENANT_SUBACCOUNT_ID,
				LocalMockedCurrentAccessContext.TENANT_SUBDOMAIN, 
				LocalMockedCurrentAccessContext.CLONE_SERVICE_INSTANCE_ID_SHARED_PLAN, 
				DATABASE_PHYSICAL_ID, DATABASE_INSTANCE_NAME_SHARED_PLAN)
		;
		
		serviceManagerController.deleteGTTInstance(createdGTTInstance.getId());

    }
	
	@Test
	public void testDeleteGTTInstanceMapping() {
		GTTTenantSetting tenantSetting = getDummyTenantSetting();
		GTTInstance createdGTTInstance = serviceManagerController.createGTTInstance(gttInstanceShared,
				GTTInstanceMapping.PLAN_SHARED, LocalMockedCurrentAccessContext.TENANT_SUBACCOUNT_ID,
				LocalMockedCurrentAccessContext.TENANT_SUBDOMAIN, 
				LocalMockedCurrentAccessContext.CLONE_SERVICE_INSTANCE_ID_SHARED_PLAN, 
				DATABASE_PHYSICAL_ID, DATABASE_INSTANCE_NAME_SHARED_PLAN)
		;
		gttInstanceMappingShared.setInstanceId(createdGTTInstance.getId());
		GTTInstanceMapping createdGTTInstanceMapping = serviceManagerController.createGTTInstanceMapping(gttInstanceMappingShared);
		serviceManagerController.deleteGTTInstanceMapping(createdGTTInstanceMapping.getId());
    }
	
	@Test
	public void testDeleteGTTPhysicalStorage() {
		GTTPhysicalStorage createdGTTPhysicalStorage = serviceManagerController.createGTTPhysicalStorage(gttPhysicalStorage);
		serviceManagerController.deleteGTTPhysicalStorage(createdGTTPhysicalStorage.getId());
    }
	
	@Test(expected = CannotReadScriptException.class)
	public void testInit() {
		GTTTenantSetting tenantSetting = getDummyTenantSetting();
		GTTInstance createdGTTInstance = serviceManagerController.createGTTInstance(gttInstanceShared,
				GTTInstanceMapping.PLAN_SHARED, LocalMockedCurrentAccessContext.TENANT_SUBACCOUNT_ID,
				LocalMockedCurrentAccessContext.TENANT_SUBDOMAIN, 
				LocalMockedCurrentAccessContext.CLONE_SERVICE_INSTANCE_ID_SHARED_PLAN, 
				DATABASE_PHYSICAL_ID, DATABASE_INSTANCE_NAME_SHARED_PLAN)
		;
		serviceManagerController.init(createdGTTInstance.getInstanceName());
    }
	
	@Test(expected = CannotReadScriptException.class)
	public void testInitDB() {
		serviceManagerController.initDB();
    }
	
	@Test(expected = CannotReadScriptException.class)
	public void testEmpty() {
		GTTTenantSetting tenantSetting = getDummyTenantSetting();
		GTTInstance createdGTTInstance = serviceManagerController.createGTTInstance(gttInstanceShared,
				GTTInstanceMapping.PLAN_SHARED, LocalMockedCurrentAccessContext.TENANT_SUBACCOUNT_ID,
				LocalMockedCurrentAccessContext.TENANT_SUBDOMAIN, 
				LocalMockedCurrentAccessContext.CLONE_SERVICE_INSTANCE_ID_SHARED_PLAN, 
				DATABASE_PHYSICAL_ID, DATABASE_INSTANCE_NAME_SHARED_PLAN)
		;
		serviceManagerController.empty(createdGTTInstance.getInstanceName());
    }
	
	@Test(expected = CannotReadScriptException.class)
	public void testEmptyDB() {
		serviceManagerController.emptyDB();
    }
	
	@Test
	public void testOnDeprovision() {
		GTTTenantSetting tenantSetting = getDummyTenantSetting();
		GTTInstance createdGTTInstance = serviceManagerController.createGTTInstance(gttInstanceShared,
				GTTInstanceMapping.PLAN_SHARED, LocalMockedCurrentAccessContext.TENANT_SUBACCOUNT_ID,
				LocalMockedCurrentAccessContext.TENANT_SUBDOMAIN, 
				LocalMockedCurrentAccessContext.CLONE_SERVICE_INSTANCE_ID_SHARED_PLAN, 
				DATABASE_PHYSICAL_ID, DATABASE_INSTANCE_NAME_SHARED_PLAN)
		;
		
		gttInstanceMappingShared.setInstanceId(createdGTTInstance.getId());
		serviceManagerController.createGTTInstanceMapping(gttInstanceMappingShared);
	
		gttInstanceMappingShared.setSubaccountId(StringUtils.EMPTY);
		gttInstanceMappingShared.setSubdomain(StringUtils.EMPTY);
		serviceManagerController.createGTTInstanceMapping(gttInstanceMappingShared);
		
		
		serviceManagerController.onDeprovision(LocalMockedCurrentAccessContext.CLONE_SERVICE_INSTANCE_ID_SHARED_PLAN, true);
		
		try{
			serviceManagerController.onDeprovision("", true);
		}
		catch(ServiceManagerException e){
			Assert.assertEquals(String.format(ServiceManagerController.DEPROVISION_MISSING_ClONEINSTANCE_ID), e.getMessage());
		}
    }
	
	
	@Test
	public void testOnProvision() {
		GTTTenantSetting tenantSetting = getDummyTenantSetting();
		GTTInstance createdGTTInstance = serviceManagerController.createGTTInstance(gttInstanceShared,
				GTTInstanceMapping.PLAN_SHARED, LocalMockedCurrentAccessContext.TENANT_SUBACCOUNT_ID,
				LocalMockedCurrentAccessContext.TENANT_SUBDOMAIN, 
				LocalMockedCurrentAccessContext.CLONE_SERVICE_INSTANCE_ID_SHARED_PLAN, 
				DATABASE_PHYSICAL_ID, DATABASE_INSTANCE_NAME_SHARED_PLAN)
		;
	
		gttInstanceMappingShared.setInstanceId(createdGTTInstance.getId());
		serviceManagerController.createGTTInstanceMapping(gttInstanceMappingShared);
	
		ProvisionParams provisionParams = new ProvisionParams();
		provisionParams.setCloneInstanceId(gttInstanceMappingShared.getCloneInstanceId());
		provisionParams.setPlan(GTTInstanceMapping.PLAN_SHARED);
		provisionParams.setInstanceName(createdGTTInstance.getInstanceName());
		
		provisionParams.setCloneInstanceSubaccountId(gttInstanceMappingShared.getSubaccountId());
		provisionParams.setCloneInstanceSubdomain(gttInstanceMappingShared.getSubdomain());
		provisionParams.setStorageType(GTTInstance.STORAGE_TYPE_HANA);
		
		serviceManagerController.onProvision(provisionParams, true);
		
		
    }
	
	@Test(expected = PlanNotSupportException.class)
	public void testOnProvisionFailed1() {
		
	
		ProvisionParams provisionParams = new ProvisionParams();
		provisionParams.setCloneInstanceId(gttInstanceMappingShared.getCloneInstanceId());
		provisionParams.setPlan("NOT_EXISTS");
		
		serviceManagerController.onProvision(provisionParams, true);
    }
	
	@Test
	public void testGetGTTInstanceBySubaccountIdAndCloneInstanceId() {
		GTTTenantSetting tenantSetting = getDummyTenantSetting();
		
		GTTInstance createdGTTInstance = serviceManagerController.createGTTInstance(gttInstanceShared,
				GTTInstanceMapping.PLAN_SHARED, LocalMockedCurrentAccessContext.TENANT_SUBACCOUNT_ID,
				LocalMockedCurrentAccessContext.TENANT_SUBDOMAIN, 
				LocalMockedCurrentAccessContext.CLONE_SERVICE_INSTANCE_ID_SHARED_PLAN, 
				DATABASE_PHYSICAL_ID, DATABASE_INSTANCE_NAME_SHARED_PLAN)
		;
		gttInstanceMappingShared.setInstanceId(createdGTTInstance.getId());
		serviceManagerController.createGTTInstanceMapping(gttInstanceMappingShared);
		
		Assert.assertNotNull(serviceManagerController.getGTTInstance(LocalMockedCurrentAccessContext.TENANT_SUBACCOUNT_ID, LocalMockedCurrentAccessContext.CLONE_SERVICE_INSTANCE_ID_SHARED_PLAN));
		
    }
	
	@Test
	public void testGetGTTPhysicalStorages() {
    	serviceManagerController.getGTTPhysicalStorages();
    }
	
	@Test
	public void testGetGTTInstances() {
    	serviceManagerController.getGTTInstances();
    }
	
	@Test
	public void testGetGTTInstanceMappings() {
		serviceManagerController.getGTTInstanceMappings();
    }
    
    @Test
    public void testGetGTTInstanceMapping() {
    	
    	GTTTenantSetting tenantSetting = getDummyTenantSetting();
		
		GTTInstance createdGTTInstance = serviceManagerController.createGTTInstance(gttInstanceShared,
				GTTInstanceMapping.PLAN_SHARED, LocalMockedCurrentAccessContext.TENANT_SUBACCOUNT_ID,
				LocalMockedCurrentAccessContext.TENANT_SUBDOMAIN, 
				LocalMockedCurrentAccessContext.CLONE_SERVICE_INSTANCE_ID_SHARED_PLAN, 
				DATABASE_PHYSICAL_ID, DATABASE_INSTANCE_NAME_SHARED_PLAN)
		;
		gttInstanceMappingShared.setInstanceId(createdGTTInstance.getId());
		GTTInstanceMapping createdGTTInstanceMapping = serviceManagerController.createGTTInstanceMapping(gttInstanceMappingShared);
		
		
    	Assert.assertNotNull(serviceManagerController.getGTTInstanceMapping(createdGTTInstanceMapping.getId()));
    }
	

}
