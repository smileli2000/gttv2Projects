/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.gtt.v2.servicemanager.subscription;

import static org.mockito.Mockito.doNothing;

import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;
import org.junit.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.test.util.ReflectionTestUtils;

import com.sap.gtt.v2.configuration.EnvironmentsConfiguration.VcapServiceParser.DatabaseServiceInstance.DatabaseType;
import com.sap.gtt.v2.configuration.local.LocalMockedCurrentAccessContext;
import com.sap.gtt.v2.servicemanager.BaseTest;
import com.sap.gtt.v2.servicemanager.GTTInstance;
import com.sap.gtt.v2.servicemanager.GTTInstanceMapping;
import com.sap.gtt.v2.servicemanager.GTTPhysicalStorage;
import com.sap.gtt.v2.servicemanager.dao.ServiceManagerDao;
import com.sap.gtt.v2.servicemanager.management.ServiceManagerManagement;
import com.sap.gtt.v2.util.GTTUtils;


public class SubscriptionServiceTest extends BaseTest {

	@SpyBean
	private ServiceManagerManagement serviceManager;
	
	
	@Autowired
	@InjectMocks
	private SubscriptionService subscriptionService;

	@Autowired
	private ServiceManagerDao serviceManagerDao;
	
	
	private static final String DATABASE_INSTANCE_NAME_SHARED_PLAN = "lbn-gtt-core-storage-h2";
	private static final String DATABASE_PHYSICAL_ID = "8495da7f-88a1-4fc7-afbd-9544d0fb26c9";
	private static final String DUMMY = "DUMMY";
	
	private GTTInstance gttInstanceStandaloneForApp;
	private GTTInstance gttInstanceStandaloneForCloneInstance;
    private GTTInstance gttInstanceShared;
    
    private GTTInstanceMapping gttInstanceMappingStandaloneForApp;
    private GTTInstanceMapping gttInstanceMappingStandaloneForCloneInstance;
    private GTTInstanceMapping gttInstanceMappingShared;
    
    private GTTPhysicalStorage  gttPhysicalStorage;
    
	@Override
    public void setUp(){
    	super.setUp();
    	ReflectionTestUtils.setField(serviceManager, "serviceManagerDao", serviceManagerDao);
    	
    	gttInstanceShared = new GTTInstance();
    	gttInstanceShared.setInstanceName(LocalMockedCurrentAccessContext.CLONE_SERVICE_INSTANCE_NAME_SHARED_PLAN);
    	gttInstanceShared.setStorageType(GTTInstance.STORAGE_TYPE_HANA);
    	gttInstanceShared.fillStorageConnectionInfoForSharedPlan(DATABASE_INSTANCE_NAME_SHARED_PLAN);
    
    	gttInstanceStandaloneForApp = new GTTInstance();
    	gttInstanceStandaloneForApp.setInstanceName(LocalMockedCurrentAccessContext.TENANT_SUBDOMAIN);
    	gttInstanceStandaloneForApp.setStorageType(GTTInstance.STORAGE_TYPE_MANAGED_HANA);
    	gttInstanceStandaloneForApp.fillStorageConnectionInfoForStandalonePlan(LocalMockedCurrentAccessContext.TENANT_SUBACCOUNT_ID,
    			LocalMockedCurrentAccessContext.TENANT_SUBDOMAIN, null, DATABASE_PHYSICAL_ID);
    
    	gttInstanceStandaloneForCloneInstance = new GTTInstance();
    	gttInstanceStandaloneForCloneInstance.setInstanceName(LocalMockedCurrentAccessContext.TENANT_SUBDOMAIN);
    	gttInstanceStandaloneForCloneInstance.setStorageType(GTTInstance.STORAGE_TYPE_MANAGED_HANA);
    	gttInstanceStandaloneForCloneInstance.fillStorageConnectionInfoForStandalonePlan(LocalMockedCurrentAccessContext.TENANT_SUBACCOUNT_ID,
    			LocalMockedCurrentAccessContext.TENANT_SUBDOMAIN, LocalMockedCurrentAccessContext.CLONE_SERVICE_INSTANCE_ID_STANDALONE_PLAN, DATABASE_PHYSICAL_ID);
    
    
    	gttInstanceMappingStandaloneForApp = new GTTInstanceMapping();
    	gttInstanceMappingStandaloneForApp.setPlan(GTTInstanceMapping.PLAN_STANDALONE);
    	gttInstanceMappingStandaloneForApp.setSubaccountId(LocalMockedCurrentAccessContext.TENANT_SUBACCOUNT_ID);
    	gttInstanceMappingStandaloneForApp.setSubdomain(LocalMockedCurrentAccessContext.TENANT_SUBDOMAIN);
    	
    	gttInstanceMappingStandaloneForCloneInstance = new GTTInstanceMapping();
    	gttInstanceMappingStandaloneForCloneInstance.setPlan(GTTInstanceMapping.PLAN_STANDALONE);
    	gttInstanceMappingStandaloneForCloneInstance.setSubaccountId(LocalMockedCurrentAccessContext.TENANT_SUBACCOUNT_ID);
    	gttInstanceMappingStandaloneForCloneInstance.setSubdomain(LocalMockedCurrentAccessContext.TENANT_SUBDOMAIN);
    	gttInstanceMappingStandaloneForCloneInstance.setCloneInstanceId(LocalMockedCurrentAccessContext.CLONE_SERVICE_INSTANCE_ID_STANDALONE_PLAN);
    	
    	gttInstanceMappingShared = new GTTInstanceMapping();
    	gttInstanceMappingShared.setPlan(GTTInstanceMapping.PLAN_SHARED);
    	gttInstanceMappingShared.setSubaccountId(LocalMockedCurrentAccessContext.TENANT_SUBACCOUNT_ID);
    	gttInstanceMappingShared.setSubdomain(LocalMockedCurrentAccessContext.TENANT_SUBDOMAIN);
    	gttInstanceMappingShared.setCloneInstanceId(LocalMockedCurrentAccessContext.CLONE_SERVICE_INSTANCE_ID_SHARED_PLAN);
    	
    	gttPhysicalStorage = new GTTPhysicalStorage();
    	gttPhysicalStorage.setGlobalAccountId(DUMMY + "1");
    	gttPhysicalStorage.setGlobalAccountName(DUMMY + "2");
    	gttPhysicalStorage.setOrgId(DUMMY + "3");
    	gttPhysicalStorage.setOrgName(DUMMY + "4");
    	gttPhysicalStorage.setPhysicalId(DATABASE_PHYSICAL_ID);
    	gttPhysicalStorage.setPhysicalType(DatabaseType.hana.name());
    	gttPhysicalStorage.setSpaceId(DUMMY + "5");
    	gttPhysicalStorage.setSpaceName(DUMMY + "6");
    	
    	doNothing().when(serviceManager).provisionForStandalonePlan(ArgumentMatchers.any(), ArgumentMatchers.anyString());
    	doNothing().when(serviceManager).deprovision(ArgumentMatchers.any());
    	
    	
	}
    
    @Test
    public void testOnSubscribeSharedPlan(){

      GTTInstance creatingGTTInstance = GTTUtils.createAndCopyBean(gttInstanceShared, GTTInstance.class, true);
   	  String gttInstanceId = serviceManager.createGTTInstanceForSharedPlan(creatingGTTInstance, DATABASE_INSTANCE_NAME_SHARED_PLAN);
   	  
   	  GTTInstanceMapping creatingGTTInstanceMapping = GTTUtils.createAndCopyBean(gttInstanceMappingShared, GTTInstanceMapping.class, true);
   	  creatingGTTInstanceMapping.setSubaccountId(StringUtils.EMPTY);
   	  creatingGTTInstanceMapping.setSubdomain(StringUtils.EMPTY);
   	  creatingGTTInstanceMapping.setInstanceId(gttInstanceId);
   	  serviceManager.createGTTInstanceMapping(creatingGTTInstanceMapping);
   	 
   	  Assert.assertEquals(1, serviceManager.getGTTInstanceMappings().size());
	  Assert.assertEquals(1, serviceManager.getGTTInstances().size());
	    
      subscriptionService.onSubscribe(gttInstanceMappingShared.getSubaccountId(), gttInstanceMappingShared.getSubdomain(), gttInstanceMappingShared.getCloneInstanceId());
      
      Assert.assertEquals(2, serviceManager.getGTTInstanceMappings().size());
	  Assert.assertEquals(1, serviceManager.getGTTInstances().size());
    }
    
    @Test
    public void testOnSubscribeStandalonePlan(){

      serviceManager.createGTTPhysicalStorage(gttPhysicalStorage);
   	 
      subscriptionService.onSubscribe(gttInstanceMappingStandaloneForCloneInstance.getSubaccountId(), gttInstanceMappingStandaloneForCloneInstance.getSubdomain(), gttInstanceMappingStandaloneForCloneInstance.getCloneInstanceId());
      subscriptionService.onSubscribe(gttInstanceMappingStandaloneForCloneInstance.getSubaccountId(), gttInstanceMappingStandaloneForCloneInstance.getSubdomain(), gttInstanceMappingStandaloneForApp.getCloneInstanceId());
      
    }
    
    
    @Test
    public void testOnUnsubscribeSharedPlan() {
    	
    	GTTInstance creatingGTTInstance = GTTUtils.createAndCopyBean(gttInstanceShared, GTTInstance.class, true);
     	String gttInstanceId = serviceManager.createGTTInstanceForSharedPlan(creatingGTTInstance, DATABASE_INSTANCE_NAME_SHARED_PLAN);
     	  
     	GTTInstanceMapping creatingGTTInstanceMapping = GTTUtils.createAndCopyBean(gttInstanceMappingShared, GTTInstanceMapping.class, true);
     	creatingGTTInstanceMapping.setSubaccountId(StringUtils.EMPTY);
     	creatingGTTInstanceMapping.setSubdomain(StringUtils.EMPTY);
     	creatingGTTInstanceMapping.setInstanceId(gttInstanceId);
     	serviceManager.createGTTInstanceMapping(creatingGTTInstanceMapping);
     	
     	subscriptionService.onUnsubscribe(creatingGTTInstanceMapping.getSubaccountId(), creatingGTTInstanceMapping.getCloneInstanceId());  
    	
    }
    
    @Test
    public void testOnUnsubscribeStandalonePlan() {
    	GTTInstance creatingGTTInstance = GTTUtils.createAndCopyBean(gttInstanceStandaloneForCloneInstance, GTTInstance.class, true);
     	String gttInstanceId = serviceManager.createGTTInstanceForStandalonePlan(creatingGTTInstance, gttInstanceMappingStandaloneForCloneInstance.getSubaccountId(), 
     			gttInstanceMappingStandaloneForCloneInstance.getSubdomain(), gttInstanceMappingStandaloneForCloneInstance.getCloneInstanceId(), DATABASE_PHYSICAL_ID);
     	  
     	GTTInstanceMapping creatingGTTInstanceMapping = GTTUtils.createAndCopyBean(gttInstanceMappingStandaloneForCloneInstance, GTTInstanceMapping.class, true);
     	creatingGTTInstanceMapping.setInstanceId(gttInstanceId);
     	serviceManager.createGTTInstanceMapping(creatingGTTInstanceMapping);
     	
     	subscriptionService.onUnsubscribe(creatingGTTInstanceMapping.getSubaccountId(), creatingGTTInstanceMapping.getCloneInstanceId());  
    	
     	
    }
    
    @Test
    public void testOnUnsubscribeStandalonePlanNotExists() {
     	subscriptionService.onUnsubscribe("NOT_EXISTS", "NOT_EXISTS");  
    	
    }
    
    @Test
    public void testCreateSubscription(){
    	subscriptionService.createApplicationSubscription(gttInstanceMappingStandaloneForApp.getSubaccountId());
    	subscriptionService.createServiceSubscription(gttInstanceMappingStandaloneForCloneInstance.getSubaccountId(), gttInstanceMappingStandaloneForCloneInstance.getSubdomain(), gttInstanceMappingStandaloneForCloneInstance.getCloneInstanceId());
    }
    
    @Test
    public void testDeleteSubscription(){
    	subscriptionService.deleteApplicationSubscription(gttInstanceMappingStandaloneForApp.getSubaccountId());
    	subscriptionService.deleteServiceSubscription(gttInstanceMappingStandaloneForCloneInstance.getSubaccountId(), gttInstanceMappingStandaloneForCloneInstance.getCloneInstanceId());
    }
    
    @Test
    public void testupdateAllSubscriptions(){
    	subscriptionService.updateAllApplicationSubscriptions();
    	subscriptionService.updateAllServiceSubscriptions();
    }
    
    @Test
    public void testupdateSubscription(){
    	subscriptionService.updateApplicationSubscription(gttInstanceMappingStandaloneForApp.getSubaccountId());
    	subscriptionService.updateServiceSubscription(gttInstanceMappingStandaloneForCloneInstance.getSubaccountId(), gttInstanceMappingStandaloneForCloneInstance.getSubdomain(), gttInstanceMappingStandaloneForCloneInstance.getCloneInstanceId());
    }
    
    @Test
    public void testGetAllSubscriptions(){
    	subscriptionService.getApplicationSubscriptions(gttInstanceMappingStandaloneForApp.getSubaccountId());
    	subscriptionService.getServiceSubscriptions(gttInstanceMappingStandaloneForApp.getSubaccountId());
    }
}
