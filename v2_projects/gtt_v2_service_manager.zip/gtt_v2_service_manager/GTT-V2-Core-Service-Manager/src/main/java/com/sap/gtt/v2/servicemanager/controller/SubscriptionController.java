/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.gtt.v2.servicemanager.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sap.gtt.v2.configuration.EnvironmentsConfiguration.VcapServiceParser.SaasRegistryServiceInstance.ReturnOfGetSubscriptions;
import com.sap.gtt.v2.configuration.SystemConstants;
import com.sap.gtt.v2.controller.IBaseRestController;
import com.sap.gtt.v2.servicemanager.subscription.SubscriptionService;

/**
 *
 * @author I326335
 */
@RestController
@RequestMapping(SubscriptionController.ROOT_URL)
public class SubscriptionController implements IBaseRestController{
    public static final String ROOT_URL =  SystemConstants.SERVICE_MANAGER_ROOT_URL + "/subscription";
    
    public static final String SERVICE_URL = "/service";
    public static final String APPLICATION_URL = "/application";
    
    public static final String SERVICE_SUBSCRIPTION_URL = SERVICE_URL + "/subaccounts/{subaccountId}/instances/{cloneInstanceId}";
    public static final String APPLICATION_SUBSCRIPTION_URL = APPLICATION_URL + "/subaccounts/{subaccountId}";
    public static final String APPLICATION_GET_ALL_SUBSCRIPTION_URL = APPLICATION_URL + "/subaccounts";
    
    
    public static final String SERVICE_GET_SUBSCRIPTION_URL = SERVICE_URL + "/subaccounts/{subaccountId}";
    public static final String SERVICE_GET_ALL_SUBSCRIPTION_URL = SERVICE_URL + "/subaccounts";
    
    
    private static final Logger logger = LoggerFactory.getLogger(SubscriptionController.class);
	
    @Autowired
    private SubscriptionService subscriptionService;
    
    @PatchMapping(value = SERVICE_URL,
			 produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.ACCEPTED)
    public void updateServiceDependencies() {
    	logger.info("updateServiceDependencies - update all subscription dependencies");
    	subscriptionService.updateAllServiceSubscriptions();
    }
    
    @PatchMapping(value = APPLICATION_URL,
			 produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.ACCEPTED)
   public void updateApplicationDependencies() {
   	logger.info("updateApplicationDependencies - update all subscription dependencies");
   	subscriptionService.updateAllApplicationSubscriptions();
   }
    
    @GetMapping(value = {APPLICATION_SUBSCRIPTION_URL,APPLICATION_GET_ALL_SUBSCRIPTION_URL}
    ,produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.OK)
    public ReturnOfGetSubscriptions getApplicationSubscription(@PathVariable(name = "subaccountId", required=false) String subaccountId) {
    	return subscriptionService.getApplicationSubscriptions(subaccountId);
    }
    
    @PostMapping(value = APPLICATION_SUBSCRIPTION_URL,produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.ACCEPTED)
    public void createApplicationSubscription(@PathVariable(name = "subaccountId") String subaccountId) {
    	subscriptionService.createApplicationSubscription(subaccountId);
    }
    @DeleteMapping(value = APPLICATION_SUBSCRIPTION_URL,produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.ACCEPTED)
    public void deleteApplicationSubscription(@PathVariable(name = "subaccountId") String subaccountId) {
    	subscriptionService.deleteApplicationSubscription(subaccountId);
    }
    @PutMapping(value = APPLICATION_SUBSCRIPTION_URL,produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.ACCEPTED)
    public void updateApplicationSubscription(@PathVariable(name = "subaccountId") String subaccountId) {
    	subscriptionService.updateApplicationSubscription(subaccountId);
    }
    
    @GetMapping(value = {SERVICE_GET_SUBSCRIPTION_URL,SERVICE_GET_ALL_SUBSCRIPTION_URL}
    ,produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.OK)
    public ReturnOfGetSubscriptions getServiceSubscriptions(@PathVariable(name = "subaccountId", required = false) String subaccountId
    		) {
    	return subscriptionService.getServiceSubscriptions(subaccountId);
    }
    
    @PostMapping(value = SERVICE_SUBSCRIPTION_URL,produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.ACCEPTED)
    public void createServiceSubscription(@PathVariable(name = "subaccountId") String subaccountId,
    		@PathVariable(name = "cloneInstanceId") String cloneInstanceId,
    		@RequestParam(name = "subdomain") String subdomain) {
    	subscriptionService.createServiceSubscription(subaccountId, subdomain, cloneInstanceId);
    }
    @DeleteMapping(value = SERVICE_SUBSCRIPTION_URL,produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.ACCEPTED)
    public void deleteServiceSubscription(@PathVariable(name = "subaccountId") String subaccountId,
    		@PathVariable(name = "cloneInstanceId") String cloneInstanceId) {
    	subscriptionService.deleteServiceSubscription(subaccountId,cloneInstanceId);
    }
    @PutMapping(value = SERVICE_SUBSCRIPTION_URL,produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.ACCEPTED)
    public void updateServiceSubscription(@PathVariable(name = "subaccountId") String subaccountId,
    		@PathVariable(name = "cloneInstanceId") String cloneInstanceId,
    		@RequestParam(name = "subdomain") String subdomain) {
    	subscriptionService.updateServiceSubscription(subaccountId, subdomain, cloneInstanceId);
    }
}
