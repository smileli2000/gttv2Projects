package com.sap.gtt.v2.servicemanager.upgrade;

import org.springframework.jdbc.core.JdbcTemplate;

public abstract class AbstractCustomDbUpgrade implements IDbUpgrade {
    protected JdbcTemplate jdbcTemplate;

    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }
}
