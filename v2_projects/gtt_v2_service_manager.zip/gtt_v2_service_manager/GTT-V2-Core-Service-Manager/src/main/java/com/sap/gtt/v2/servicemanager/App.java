package com.sap.gtt.v2.servicemanager;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.FilterType;

import com.sap.gtt.v2.GTTBaseSpringApplication;
import com.sap.gtt.v2.GTTSpringApplicationLauncher;
import com.sap.gtt.v2.configuration.TenantAwareDataSource;


@ComponentScan(   

        excludeFilters = {
                @ComponentScan.Filter(type = FilterType.ASSIGNABLE_TYPE, value = TenantAwareDataSource.class)
        })
/**
 * We will have a pooled datasource for securestore, so we must disable the multitenant datasource we created in shared-library,
 * otherwise there will be two datasource bean in spring context, which lead to creation failure of jdbcTemplate by JDBCTemplateAutoConfiguration
 * @author I053866
 *
 */
public class App extends GTTBaseSpringApplication{

	public static void main(String[] args) {
		GTTSpringApplicationLauncher.run(new App(), args);
		
	}
}