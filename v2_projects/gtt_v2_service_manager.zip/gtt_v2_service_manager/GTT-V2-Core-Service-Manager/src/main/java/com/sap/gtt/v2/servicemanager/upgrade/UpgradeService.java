package com.sap.gtt.v2.servicemanager.upgrade;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.json.JsonSanitizer;
import com.sap.gtt.v2.servicemanager.GTTInstance;
import com.sap.gtt.v2.servicemanager.configuration.UpgradeConfiguration;
import com.sap.gtt.v2.servicemanager.management.ServiceManagerManagement;
import com.sap.gtt.v2.util.JsonUtils;
import com.sap.gtt.v2.util.SpringContextUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static com.sap.gtt.v2.servicemanager.upgrade.Constant.GTT_DB_UPGRADE_CLASS_INVALID;
import static com.sap.gtt.v2.servicemanager.upgrade.Constant.GTT_DB_UPGRADE_CLASS_NAME_NOT_FOUND;

@Service
public class UpgradeService {
    public static final String INSTANCES = "instances";
    @Autowired
    UpgradeConfiguration upgradeConfiguration;
    @Autowired
    private ServiceManagerManagement serviceManager;
    private static final Logger logger = LoggerFactory.getLogger(UpgradeService.class);
    public static final String NAME = "name";

    private UpgradeService() {}

    public String upgradeAllDb(String body) {
        List<JsonObject> resultObjs = new ArrayList();
        List<GTTInstance> gttInstancesToBeUpgrade = getGTTInstanceNeedUpgrade(Collections.emptyList());
        if (!gttInstancesToBeUpgrade.isEmpty()) {
            for (GTTInstance gttInstance : gttInstancesToBeUpgrade) {
                if (upgradeConfiguration.isClassEnabled()) {
                    JsonObject resultObj = upgradeTheDbByClass(gttInstance, body);
                    resultObjs.add(resultObj);
                }
            }
        } else {
            JsonObject jsonObj = new JsonObject();
            jsonObj.addProperty("warning", "no db instances found, no upgrade processed.");
            resultObjs.add(jsonObj);
        }
        return resultObjs.toString();
    }

    public String upgradeTheDb(String body) {
        List<String> instanceNames = new ArrayList();
        List<JsonObject> resultObjs = new ArrayList();
        if (StringUtils.isNotBlank(body)) {
            JsonObject bodyObj = JsonUtils.generateJsonObjectFromJsonString(JsonSanitizer.sanitize(body));
            instanceNames = getInstanceForUpgrade(bodyObj);
        }
        List<GTTInstance> gttInstancesToBeUpgrade = getGTTInstanceNeedUpgrade(instanceNames);
        if (!gttInstancesToBeUpgrade.isEmpty()) {
            for (GTTInstance gttInstance : gttInstancesToBeUpgrade) {
                if (upgradeConfiguration.isClassEnabled()) {
                    JsonObject resultObj = upgradeTheDbByClass(gttInstance, body);
                    resultObjs.add(resultObj);
                }
            }
        } else {
            JsonObject jsonObj = new JsonObject();
            jsonObj.addProperty("warning", "no db instances found, no upgrade processed.");
            resultObjs.add(jsonObj);
        }
        return resultObjs.toString();
    }

    private List<GTTInstance> getGTTInstanceNeedUpgrade(List<String> instanceNames) {
        if (instanceNames.isEmpty()) {
            return serviceManager.getGTTInstances();
        } else {
            List<GTTInstance> gttInstances = new ArrayList();
            for (String instanceName : instanceNames) {
                GTTInstance instance = serviceManager.getGTTInstanceByName(instanceName);
                gttInstances.add(instance);
            }
            return gttInstances;
        }
    }

    private List<String> getInstanceForUpgrade(JsonObject bodyObj) {
        List<String> instanceNames = new ArrayList();
        if (bodyObj.has(INSTANCES)) {
            JsonArray instanceArray = bodyObj.get(INSTANCES).getAsJsonArray();
            instanceArray.forEach(e -> {
                JsonObject instanceObj = e.getAsJsonObject();
                if (instanceObj.has(NAME)) {
                    String instanceName = instanceObj.get(NAME).getAsString();
                    instanceNames.add(instanceName);
                }
            });
        }
        return instanceNames;
    }

    private JsonObject upgradeTheDbByClass(GTTInstance gttInstance, String paramJson) {
        JsonObject resultObj;
        logger.info(" *** in UpgradeService.upgradeTheDbByClass. gttInstance.getInstanceName() is {} ", gttInstance.getInstanceName());
        String className = upgradeConfiguration.getUpgradeClassName();
        if (StringUtils.isNotBlank(className)) {
            AbstractCustomDbUpgrade abstractCustomDbUpgrade = loadCustomClass(className);
            UpgradeCustomServiceAgent upgradeCustomServiceAgent = getUpgradeCustomServiceAgent(abstractCustomDbUpgrade, gttInstance);
            resultObj= upgradeCustomServiceAgent.execute(paramJson);
            logger.info("*** in UpgradeService.upgradeTheDbByClass. end  ");
        } else {
            throw new UpgradeServicerException(String.format(GTT_DB_UPGRADE_CLASS_NAME_NOT_FOUND, className), null);
        }
        if (!resultObj.has("processClassMessage")) {
            resultObj.addProperty("processClassMessage", String.format("class call on instance %s is success", gttInstance.getInstanceName()));
        }
        return resultObj;
    }

    private UpgradeCustomServiceAgent getUpgradeCustomServiceAgent(IDbUpgrade iDbUpgrade, GTTInstance gttInstance) {
        String instanceName = gttInstance.getInstanceName();
        String beanName = getBeanName(instanceName, UpgradeCustomServiceAgent.BEAN_NAME);
        if (SpringContextUtils.containsBean(beanName)) {
            return (UpgradeCustomServiceAgent) SpringContextUtils.getBean(beanName);
        } else {
            return SpringContextUtils.createSingletonBean(UpgradeCustomServiceAgent.class, beanName, new Object[]{iDbUpgrade,gttInstance});
        }

    }


    private AbstractCustomDbUpgrade loadCustomClass(String className) {
        AbstractCustomDbUpgrade dbUpgradeObj;
        try {
            dbUpgradeObj = (AbstractCustomDbUpgrade) SpringContextUtils.getBean(Class.forName(className));
        } catch (ClassNotFoundException e) {
            throw new UpgradeServicerException(String.format(GTT_DB_UPGRADE_CLASS_INVALID, className), null);
        }
        return dbUpgradeObj;
    }

    private String getBeanName(String instanceName, String className) {
        return instanceName + StringUtils.capitalize(className);
    }


}
