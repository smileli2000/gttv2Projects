package com.sap.gtt.v2.servicemanager.subscription;

import org.apache.http.HttpStatus;

import com.sap.gtt.v2.exception.GeneralNoneTranslatableException;

public class SubscriptionException extends GeneralNoneTranslatableException{

    private static final long serialVersionUID = 5675399672644576670L;
	
	public SubscriptionException(String message, Throwable cause) {
		super(message, cause,HttpStatus.SC_BAD_REQUEST);
	}

	
}
