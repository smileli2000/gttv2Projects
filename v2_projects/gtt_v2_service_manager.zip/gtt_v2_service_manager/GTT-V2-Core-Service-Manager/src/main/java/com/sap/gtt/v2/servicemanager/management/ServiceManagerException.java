package com.sap.gtt.v2.servicemanager.management;

import org.apache.http.HttpStatus;

import com.sap.gtt.v2.exception.GeneralNoneTranslatableException;

public class ServiceManagerException extends GeneralNoneTranslatableException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3147084007156029025L;
	
	public ServiceManagerException(String message, Throwable cause) {
		super(message, cause,HttpStatus.SC_BAD_REQUEST);
	}

	
}
