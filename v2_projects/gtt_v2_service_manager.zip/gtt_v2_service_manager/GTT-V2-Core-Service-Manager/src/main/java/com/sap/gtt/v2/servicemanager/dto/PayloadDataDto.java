package com.sap.gtt.v2.servicemanager.dto;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;

public class PayloadDataDto {
	@JsonInclude
	private String subscriptionAppName;
	@JsonInclude
	private String subscriptionAppId;
	@JsonInclude
	private String subscribedTenantId;
	@JsonInclude
	private String subscribedSubaccountId;
	@JsonInclude
	private String subscribedSubdomain;
	@JsonInclude
	private String subscriptionAppPlan;
	@JsonInclude
	private long subscriptionAppAmount;
	@JsonInclude
	private String[] dependantServiceInstanceAppIds = null;
	@JsonInclude
	private String eventType;
	
	private Map<String, String> additionalInformation;


	public String getEventType() {
		return eventType;
	}

	public void setEventType(String eventType) {
		this.eventType = eventType;
	}

	public String getSubscriptionAppName() {
		return subscriptionAppName;
	}

	public void setSubscriptionAppName(String subscriptionAppName) {
		this.subscriptionAppName = subscriptionAppName;
	}

	public String getSubscriptionAppId() {
		return subscriptionAppId;
	}

	public void setSubscriptionAppId(String subscriptionAppId) {
		this.subscriptionAppId = subscriptionAppId;
	}

	public String getSubscribedTenantId() {
		return subscribedTenantId;
	}

	public void setSubscribedTenantId(String subscribedTenantId) {
		this.subscribedTenantId = subscribedTenantId;
	}

	public String getSubscribedSubdomain() {
		return subscribedSubdomain;
	}

	public void setSubscribedSubdomain(String subscribedSubdomain) {
		this.subscribedSubdomain = subscribedSubdomain;
	}

	public String getSubscriptionAppPlan() {
		return subscriptionAppPlan;
	}

	public void setSubscriptionAppPlan(String subscriptionAppPlan) {
		this.subscriptionAppPlan = subscriptionAppPlan;
	}

	public Map<String, String> getAdditionalInformation() {
        if (additionalInformation == null) {
            additionalInformation = new HashMap<>();
        }
		return additionalInformation;
	}

	public void setAdditionalInformation(Map<String, String> additionalInformation) {
		this.additionalInformation = additionalInformation;
	}

	public long getSubscriptionAppAmount() {
		return subscriptionAppAmount;
	}

	public void setSubscriptionAppAmount(long subscriptionAppAmount) {
		this.subscriptionAppAmount = subscriptionAppAmount;
	}

	public String[] getDependantServiceInstanceAppIds() {
		if(dependantServiceInstanceAppIds != null){
			return dependantServiceInstanceAppIds.clone();
		}
		else{
			return new String[]{};
		}
		
	}

	public void setDependantServiceInstanceAppIds(
			String[] dependantServiceInstanceAppIds) {
		this.dependantServiceInstanceAppIds = dependantServiceInstanceAppIds.clone();
	}

	public String getSubscribedSubaccountId() {
		return subscribedSubaccountId;
	}

	public void setSubscribedSubaccountId(String subscribedSubaccountId) {
		this.subscribedSubaccountId = subscribedSubaccountId;
	}

	@Override
	public String toString() {
		return "PayloadDataDto [subscriptionAppName=" + subscriptionAppName + ", subscriptionAppId=" + subscriptionAppId
				+ ", subscribedTenantId=" + subscribedTenantId + ", subscribedSubaccountId=" + subscribedSubaccountId
				+ ", subscribedSubdomain=" + subscribedSubdomain + ", subscriptionAppPlan=" + subscriptionAppPlan
				+ ", subscriptionAppAmount=" + subscriptionAppAmount + ", dependantServiceInstanceAppIds="
				+ Arrays.toString(dependantServiceInstanceAppIds) + ", eventType=" + eventType
				+ ", additionalInformation=" + additionalInformation + "]";
	}

	

	
}
