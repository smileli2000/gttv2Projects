package com.sap.gtt.v2.servicemanager.configuration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class UpgradeConfiguration {

    @Value("${dbUpgrade.class.enabled}")
    private boolean isClassEnabled;

    @Value("${dbUpgrade.class.name}")
    private String upgradeClassName;

    public boolean isClassEnabled() {
        return isClassEnabled;
    }

    public String getUpgradeClassName() {
        return upgradeClassName;
    }

}
