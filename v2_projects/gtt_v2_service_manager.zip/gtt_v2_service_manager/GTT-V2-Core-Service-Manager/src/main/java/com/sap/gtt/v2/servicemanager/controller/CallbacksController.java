package com.sap.gtt.v2.servicemanager.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sap.gtt.v2.configuration.EnvironmentsConfiguration;
import com.sap.gtt.v2.configuration.ServiceInstancesMapping;
import com.sap.gtt.v2.controller.IBaseRestController;
import com.sap.gtt.v2.exception.MultiExceptionContainer;
import com.sap.gtt.v2.servicemanager.dto.DependantServiceDto;
import com.sap.gtt.v2.servicemanager.dto.PayloadDataDto;
import com.sap.gtt.v2.servicemanager.subscription.SubscriptionService;

@RestController
@RequestMapping(CallbacksController.ROOT_URL)
public class CallbacksController implements IBaseRestController{
	public static final String ROOT_URL =  "/callback/v1.0";
	private static final Logger logger = LoggerFactory.getLogger(CallbacksController.class);
	
	@Value("${TT_APP_SUBSCRIPTION_URL_PATTERN}")
    private String appSubscriptionPattern;
    
    @Value("${TT_PDM_SERVICE_XSAPP_NAME}")
	private String pdmServiceXsappName;
	
    @Autowired
    private ServiceInstancesMapping serviceInstancesMapping;

    @Autowired
    private SubscriptionService subscriptionService;
    
   /**
    * /callback/v1.0/service/dependencies?tenantId=86cbb49a-0deb-4c74-9c85-9a85908569f1
    * @return
    */
    @GetMapping(value = "/app/dependencies", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<DependantServiceDto> callbackAppDependencies() {
       List<DependantServiceDto> result = new ArrayList<>();
       result.addAll(this.getCommonCallbackDependencies());
       EnvironmentsConfiguration.VcapServiceParser.PortalServiceInstance portalService = serviceInstancesMapping.getPortalServiceInstance();
       EnvironmentsConfiguration.VcapServiceParser.BpServiceInstance bpService = serviceInstancesMapping.getBpServiceInstance();
       EnvironmentsConfiguration.VcapServiceParser.ReminderServiceInstance reminderService = serviceInstancesMapping.getReminderServiceInstance();
       EnvironmentsConfiguration.VcapServiceParser.LocationServiceInstance locationService = serviceInstancesMapping.getLocationServiceInstance();
       result.add(new DependantServiceDto(portalService.getXsappname()));
       result.add(new DependantServiceDto(bpService.getXsappname()));
       result.add(new DependantServiceDto(reminderService.getXsappname()));
       result.add(new DependantServiceDto(pdmServiceXsappName));
       result.add(new DependantServiceDto(locationService.getXsappname()));
             
       return result;
    }
    
    @GetMapping(value = "/service/dependencies", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<DependantServiceDto> callbackServiceDependencies() {
       return this.getCommonCallbackDependencies();
    }
    
    protected List<DependantServiceDto> getCommonCallbackDependencies(){
    	 EnvironmentsConfiguration.VcapServiceParser.DestinationServiceInstance destinationService = serviceInstancesMapping.getDestinationServiceInstance();
         return Arrays.asList(
             new DependantServiceDto(destinationService.getXsappname())
         );
    }
    
    
    /**
     * 
     * @param tenantID
     * @param payload
     */
    @PutMapping(value = "/app/tenants/{tenantId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public String callbackAppTenantSubscribe(@PathVariable(value = "tenantId") String tenantId, @RequestBody PayloadDataDto payload) {
    	logger.info("callbackAppTenantSubscribe: {} ", payload);
    	String masterUAAXSAppname = serviceInstancesMapping.getUaaServiceInstance().getXsappname(); //lbn-gtt-core_sbx!b6660
    	String subaccountId = payload.getSubscribedSubaccountId(); 
    	String subdomain = payload.getSubscribedSubdomain();
    	
    	boolean forMasterUAA = false;
    	if(StringUtils.equals(payload.getSubscriptionAppId(), masterUAAXSAppname)){
    		forMasterUAA = true;
    	}
    	else{
    		logger.error("Subscribe Error: subaccountId - {}, subdomain - {}, expecting app {} but {}", 
					subaccountId, subdomain, masterUAAXSAppname, payload.getSubscriptionAppId());
    	}
    	
    	
    	
    	// master UAA subscription
    	if(forMasterUAA){
    		subscriptionService.onSubscribe(subaccountId, subdomain, null);
    		return StringUtils.replace(appSubscriptionPattern, "<subdomain>", subdomain);
    	}
    	else{
    		return StringUtils.EMPTY;
    	}
    	
    	
    	
    }
    
    /**
     * will be trigger when stack service api is called to subscribe / unsubscribe tenant on clone instance
     * in such case: 
     * the subscription can be retrieved via the saas-service of this clone instance BUT,
     * this method should NOT be used, because we cannot get clone instance id in the payload during the CIS of stack service call (dependantServiceInstanceAppIds = null)
     * or
     * will be trigger by a CIS for host app in which GTT clone instance is a dependency,
     * in such case:
     * the subscription on this clone instance can NOT be retrieved via saas-service registry of this clone instance
     * the subscription is together with the host app subscription in host app's saas-app registry
	 * subscriptionAppName and id, is the host app name / id, not GTT's, but dependantServiceInstanceAppIds will contain GTT clone instance id 
     * 
     * 
     * @param tenantId
     * @param payload
     */
    @PutMapping(value = "/service/tenants/{tenantId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public void callbackServiceTenantSubscribe(@PathVariable(value = "tenantId") String tenantId, @RequestBody PayloadDataDto payload) {
    	logger.info("callbackServiceTenantSubscribe: {} ", payload);
    	/*
    	 * When a stack service call:
    	 *CloneService:  - 2020-03-08 09:09:45 [INFO] - callbackServiceTenantSubscribe: 
    	 *PayloadDataDto 
    	 *[subscriptionAppName=lbn-gtt-core_sbx-service, 
    	 *subscriptionAppId=lbn-gtt-core_sbx!b6660, 
    	 *subscribedTenantId=ba77fcf8-6aae-48d5-a787-32e768e303e8, 
    	 *subscribedSubaccountId=ba77fcf8-6aae-48d5-a787-32e768e303e8,
    	 * subscribedSubdomain=lbn-platform, 
    	 * subscriptionAppPlan=null, 
    	 * subscriptionAppAmount=0, 
    	 * dependantServiceInstanceAppIds=null, 
    	 * additionalInformation=null]  
    	 * 
    	 * when a host app CIS call with dependency:
    	 * callbackServiceTenantSubscribe: PayloadDataDto 
    	 * [subscriptionAppName=test-lbn-gtt-core_sbx-app, 
    	 * subscriptionAppId=test-lbn-gtt-core_sbx!t6660, 
    	 * subscribedTenantId=86cbb49a-0deb-4c74-9c85-9a85908569f1, 
    	 * subscribedSubaccountId=86cbb49a-0deb-4c74-9c85-9a85908569f1, 
    	 * subscribedSubdomain=lbn-gtt, subscriptionAppPlan=null, subscriptionAppAmount=0, 
    	 * dependantServiceInstanceAppIds=[9b482ecd-1f47-4745-a095-e2e1abd18293!b6660|lbn-gtt-core_sbx!b6660], 
    	 * additionalInformation={tenantMetadataUrl=https://lbn-gtt.authentication.sap.hana.ondemand.com/saml/metadata}]
    	 */
    	String masterUAAXSAppname = serviceInstancesMapping.getUaaServiceInstance().getXsappname(); //lbn-gtt-core_sbx!b6660
    	if(StringUtils.equals(payload.getSubscriptionAppId(), masterUAAXSAppname)){
    		// triggered from stack service call, should stop as no clone instance info in payload 
    		logger.warn("CIS callback is triggered from stack service call, should stop here as no clone instance info in payload ");
    		return;
    	}
    	
    	// triggered by a host app cis dependency
    	String subaccountId = payload.getSubscribedSubaccountId();
    	String subdomain = payload.getSubscribedSubdomain();
		
    	List<String> cloneInstanceIds =  this.getCloneInstanceIdFromDependencies(payload.getDependantServiceInstanceAppIds(),masterUAAXSAppname);
    	// clone instance subscription
		MultiExceptionContainer multiExceptionContainer = new MultiExceptionContainer(HttpStatus.INTERNAL_SERVER_ERROR.value());
		
		for(String cloneInstanceId : cloneInstanceIds){
			try{
				subscriptionService.onSubscribe(subaccountId, subdomain, cloneInstanceId);
			}
			catch(Exception e){
				multiExceptionContainer.addException(e);
				logger.error("Subscribe Error: subaccountId - {}, subdomain - {}, cloneInstanceId - {}, message - {} ", 
						subaccountId, subdomain , cloneInstanceId, e.getMessage());
			}
		}
    		
		if(multiExceptionContainer.containsError()) throw multiExceptionContainer;    	
    	
    }
    
    @DeleteMapping(value = "/app/tenants/{tenantId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public void callbackAppTenantUnsubscribe(@PathVariable(value = "tenantId") String tenantId, @RequestBody PayloadDataDto payload) {
    	logger.info("callbackAppTenantUnsubscribe: {} ", payload);
    	String masterUAAXSAppname = serviceInstancesMapping.getUaaServiceInstance().getXsappname(); //lbn-gtt-core_sbx!b6660
    	String subaccountId = payload.getSubscribedSubaccountId();
    	
    	boolean forMasterUAA = false;
    	if(StringUtils.equals(payload.getSubscriptionAppId(), masterUAAXSAppname)){
    		forMasterUAA = true;
    	}
    	else{
    		logger.error("Unsubscribe Error: subaccountId - {}, expecting app {} but {} ", 
					subaccountId, masterUAAXSAppname, payload.getSubscriptionAppId());
    	}
    	
    	if(forMasterUAA){
    		// master UAA subscription
    		subscriptionService.onUnsubscribe(subaccountId, null);
    	}
    	
    }
    
    @DeleteMapping(value = "/service/tenants/{tenantId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public void callbackServiceTenantUnsubscribe(@PathVariable(value = "tenantId") String tenantId, @RequestBody PayloadDataDto payload) {
    	logger.info("callbackServiceTenantUnsubscribe: {} ", payload);
    	String masterUAAXSAppname = serviceInstancesMapping.getUaaServiceInstance().getXsappname(); //lbn-gtt-core_sbx!b6660
    	if(StringUtils.equals(payload.getSubscriptionAppId(), masterUAAXSAppname)){
    		// triggered from stack service call, should stop as no clone instance in payload
    		logger.warn("CIS callback is triggered from stack service call, should stop here as no clone instance info in payload ");
    		return;
    	}
    	
    	String subaccountId = payload.getSubscribedSubaccountId();
    	List<String> cloneInstanceIds =  this.getCloneInstanceIdFromDependencies(payload.getDependantServiceInstanceAppIds(),masterUAAXSAppname);
    	// clone instance subscription
		MultiExceptionContainer multiExceptionContainer = new MultiExceptionContainer(HttpStatus.INTERNAL_SERVER_ERROR.value());
		
		for(String cloneInstanceId : cloneInstanceIds){
			try{
				subscriptionService.onUnsubscribe(subaccountId, cloneInstanceId);
			}
			catch(Exception e){
				multiExceptionContainer.addException(e);
				logger.error("Unsubscribe Error: subaccountId - {}, cloneInstanceId - {}, message - {} ", 
						subaccountId, cloneInstanceId, e.getMessage());
			}
		}
		
		if(multiExceptionContainer.containsError()) throw multiExceptionContainer;
    	
    	
    }
    
    protected List<String> getCloneInstanceIdFromDependencies(String [] dependantServiceInstanceAppIds, String masterUAAXSAppname){
    	List<String> result = new ArrayList<>();
    	if(dependantServiceInstanceAppIds == null
    			|| dependantServiceInstanceAppIds.length == 0
    			){
    		return result;
    	}
    	
    	
    	for(String dependantServiceInstanceAppId : dependantServiceInstanceAppIds){
    		//abe1d1d6-9691-41b5-ade9-f04976232c05!b6660|lbn-gtt-core_sbx!b6660
    		if(StringUtils.endsWith(dependantServiceInstanceAppId, masterUAAXSAppname)){
    			String cloneInstanceId = StringUtils.substringBefore(dependantServiceInstanceAppId, "!");
    			result.add(cloneInstanceId);
    		}
    	}
    	
    	return result;
    }
}
