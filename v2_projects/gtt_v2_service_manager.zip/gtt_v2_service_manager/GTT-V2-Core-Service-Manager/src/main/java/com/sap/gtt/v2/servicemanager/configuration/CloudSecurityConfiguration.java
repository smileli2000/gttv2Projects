package com.sap.gtt.v2.servicemanager.configuration;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.ExpressionUrlAuthorizationConfigurer;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer;

import com.sap.gtt.v2.configuration.AbstractCloudSecurityConfiguration;
import com.sap.gtt.v2.servicemanager.controller.ServiceManagerController;
import com.sap.gtt.v2.servicemanager.controller.SubscriptionController;

@Configuration
@EnableWebSecurity
@EnableResourceServer
@EnableGlobalMethodSecurity(prePostEnabled = true) 
@Profile("cloud")
public class CloudSecurityConfiguration extends AbstractCloudSecurityConfiguration {

	public static final String SCOPE_SYSMGR = "sysmgr";
	public static final String SCOPE_STORAGE_READ = "storage.r";
	public static final String SCOPE_CIS = "Callback";
	
    @Override
	public ExpressionUrlAuthorizationConfigurer<HttpSecurity>.ExpressionInterceptUrlRegistry setProtectedExpressionInterceptUrlRegistry(
			ExpressionUrlAuthorizationConfigurer<HttpSecurity>.ExpressionInterceptUrlRegistry expressionInterceptUrlRegistry) {

		ExpressionUrlAuthorizationConfigurer<HttpSecurity>.ExpressionInterceptUrlRegistry registry = super.setProtectedExpressionInterceptUrlRegistry(expressionInterceptUrlRegistry);

		registry
				.antMatchers("/callback/v1.0/**").access(getScopeCheckExpress(SCOPE_CIS,true))
				.antMatchers(ServiceManagerController.ROOT_URL + "**/**").access(getScopeCheckExpress(SCOPE_SYSMGR,true))
				.antMatchers(SubscriptionController.ROOT_URL + "**/**").access(getScopeCheckExpress(SCOPE_SYSMGR,true))
		;

		return registry;
	}
}
