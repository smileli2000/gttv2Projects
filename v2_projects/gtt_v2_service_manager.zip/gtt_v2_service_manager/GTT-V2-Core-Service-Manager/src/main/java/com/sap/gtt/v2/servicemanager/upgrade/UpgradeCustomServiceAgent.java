package com.sap.gtt.v2.servicemanager.upgrade;

import com.google.gson.JsonObject;
import com.sap.gtt.v2.configuration.AccessContextHolder;
import com.sap.gtt.v2.configuration.ISAPCloudPlatformAgent;
import com.sap.gtt.v2.configuration.TenantAwareDataSource;
import com.sap.gtt.v2.log.TenantAwareLogService;
import com.sap.gtt.v2.servicemanager.GTTInstance;
import com.sap.gtt.v2.util.SpringContextUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

@Service
public class UpgradeCustomServiceAgent extends AbstractCustomDbUpgrade {
    public static final String BEAN_NAME = "com.sap.gtt.v2.servicemanager.upgrade.UpgradeCustomServiceAgent";
    @Autowired
    private TenantAwareLogService logService;
    private GTTInstance gttInstance;
    private AbstractCustomDbUpgrade abstractCustomDbUpgrade;
    private javax.sql.DataSource originalDatasource;
    @Autowired
    private ISAPCloudPlatformAgent.ICurrentAccessContext currentAccessContext;
    @Autowired
    private TenantAwareDataSource tenantAwareDataSource;

    private UpgradeCustomServiceAgent() {
    }

    public UpgradeCustomServiceAgent(AbstractCustomDbUpgrade abstractCustomDbUpgrade, GTTInstance gttInstance) {
        this.gttInstance = gttInstance;
        this.abstractCustomDbUpgrade = abstractCustomDbUpgrade;
    }

    public JsonObject execute(String methodParamJson) {
        beforeRun();
        JsonObject resultObj = doUpgrade(gttInstance, methodParamJson);
        afterRun();
        return resultObj;
    }

    private void beforeRun() {
        // set access context in context holder
        AccessContextHolder.AccessContext accessContext = new AccessContextHolder.AccessContext
                (null, null, null, null,
                        ISAPCloudPlatformAgent.ICurrentAccessContext.getLocale(),
                        gttInstance,
                        false,
                        false,
                        false,
                        true);
        AccessContextHolder.set(accessContext);
        this.jdbcTemplate = SpringContextUtils.getBean(JdbcTemplate.class);
        originalDatasource = jdbcTemplate.getDataSource();
        this.jdbcTemplate.setDataSource(tenantAwareDataSource);
    }

    public JsonObject doUpgrade(GTTInstance gttInstance, String methodParamJson) {
        this.abstractCustomDbUpgrade.setJdbcTemplate(this.jdbcTemplate);
        JsonObject resultObj = new JsonObject();
        JsonObject customResultObj = this.abstractCustomDbUpgrade.doUpgrade(gttInstance, methodParamJson);
        if (customResultObj != null) {
            return customResultObj;
        } else {
            return resultObj;
        }
    }

    private void afterRun() {
        AccessContextHolder.clear();
        jdbcTemplate.setDataSource(originalDatasource);

    }

}
