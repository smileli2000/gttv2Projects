package com.sap.gtt.v2.servicemanager.dto;

import com.fasterxml.jackson.annotation.JsonInclude;

public class DependantServiceDto {
	@JsonInclude
    private String xsappname;

    public DependantServiceDto() {}

    /**
     * @param appName
     */
    public DependantServiceDto(String appName) {
        this.xsappname = appName;
    }

    public String getXsappname() {
        return xsappname;
    }

    public void setXsappname(String xsappname) {
        this.xsappname = xsappname;
    }

    @Override
    public String toString() {
        return "xsappname=" + xsappname;
    }
}