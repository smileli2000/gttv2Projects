package com.sap.gtt.v2.servicemanager.management;

import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;

import org.apache.commons.lang3.RegExUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.sap.gtt.v2.configuration.EnvironmentsConfiguration.VcapServiceParser.DatabaseServiceInstance;
import com.sap.gtt.v2.configuration.EnvironmentsConfiguration.VcapServiceParser.DatabaseServiceInstance.DatabaseType;
import com.sap.gtt.v2.servicemanager.GTTInstance;
import com.sap.gtt.v2.servicemanager.GTTInstance.StorageConnectionInfo;
import com.sap.gtt.v2.servicemanager.GTTInstanceMapping;
import com.sap.gtt.v2.servicemanager.GTTPhysicalStorage;
import com.sap.gtt.v2.servicemanager.GTTPhysicalStorage.PhysicalTypeNotSupportException;
import com.sap.gtt.v2.servicemanager.dao.ServiceManagerDao;
import com.sap.gtt.v2.tenant.GTTTenantSetting;
import com.sap.gtt.v2.tenant.GTTTenantSettingParam;
import com.sap.gtt.v2.util.GTTUtils;

@Service
public class ServiceManagerManagement {
		
	protected static final String GTT_INSTANCE_NOT_FOUND = "GTT Instance with id '%s' not found";
	protected static final String GTT_INSTANCE_BY_NAME_NOT_FOUND = "GTT Instance with name '%s' not found";
	protected static final String GTT_INSTANCE_CONNECTION_INFO_MISSING = "GTT Instance Connection Info must be provided";
	protected static final String GTT_INSTANCE_MISSING_INSTANCE_NAME = "Instance name must be provided";
	protected static final String GTT_INSTANCE_MISSING_NAMESPACE = "Namespace must be provided";
	protected static final String GTT_INSTANCE_NAMESPACE_ALREADY_EXISTS = "Namespace '%s' already exists";
	
	
	protected static final String GTT_INSTANCE_MAPPING_NOT_FOUND = "GTT Instance Mapping with id '%s' not found";
	protected static final String GTT_INSTANCE_MAPPING_BY_SUBACCOUNT_ID_CLONEINSTANCE_ID_NOT_FOUND = "GTT Instance Mapping not found by subaccount id '%s' and cloneInstanceId '%s'";
	protected static final String GTT_INSTANCE_MAPPING_MISSING_SUBACCOUNT_ID = "Subaccount id must be provided";
	protected static final String GTT_INSTANCE_MAPPING_MISSING_SUBDOMAIN = "Subdomain must be provided";
	
	protected static final String GTT_INSTANCE_MAPPING_MISSING_CLONE_INSTANCE_ID = "CloneInstanceId must be provided";
	protected static final String GTT_INSTANCE_MAPPING_MISSING_INSTANCE_ID = "GTT Instance Id must be provided";
	protected static final String GTT_INSTANCE_MAPPING_DUPLICATE_MAPPING = "GTT Instance Mapping already exists for subaccount id '%s' and clone instance id '%s' ";
	
	
	
	protected static final String GTT_INSTANCE_NAME_ALREADY_EXISTS = "GTT Instance Name '%s' already exists";
	protected static final String GTT_INSTANCE_NAME_CANNOT_BE_CHANGED = "GTT Instance Name cannot be changed, old:'%s', new:'%s'";
	
	protected static final String GTT_PHYSICAL_STORAGE_MISSING_PHYSICAL_ID = "Physical Id must be provided";
	protected static final String GTT_PHYSICAL_STORAGE_NOT_FOUND = "Physical storage with id '%s' not found";
	
	@Autowired
	private ServiceManagerDao serviceManagerDao;
	
	protected String createGTTInstance(GTTInstance gttInstance){
		gttInstance.setId(GTTUtils.UUIDUtils.generateTimeBasedUUID().toString());
		validGTTInstance(gttInstance, true);
		serviceManagerDao.insertGTTInstance(gttInstance);
		return gttInstance.getId();
	}
	
	protected String updateGTTInstance(GTTInstance gttInstance){
		validGTTInstance(gttInstance, false);
		serviceManagerDao.deleteGTTInstance(gttInstance.getId());
		serviceManagerDao.insertGTTInstance(gttInstance);
		return gttInstance.getId();
	}
	
	@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public String createGTTInstanceForStandalonePlan(GTTInstance gttInstance, String subaccountId, String subdomain, String cloneInstanceId, String physicalId){
		gttInstance.fillStorageConnectionInfoForStandalonePlan(subaccountId, subdomain, cloneInstanceId, physicalId);
		return this.createGTTInstance(gttInstance);
	}
	
	@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public String createGTTInstanceForSharedPlan(GTTInstance gttInstance, String databaseServiceInstanceName){
		gttInstance.fillStorageConnectionInfoForSharedPlan(databaseServiceInstanceName);
		return this.createGTTInstance(gttInstance);
	}
	
	@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public String updateGTTInstanceForSharedPlan(GTTInstance gttInstance, String databaseServiceInstanceName){
		gttInstance.fillStorageConnectionInfoForSharedPlan(databaseServiceInstanceName);
		return this.updateGTTInstance(gttInstance);
	}
	
	@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public void deleteGTTInstance(String id){
		if(serviceManagerDao.deleteGTTInstance(id) == 0){
			throw new ServiceManagerException(String.format(GTT_INSTANCE_NOT_FOUND, id), null);
		}
	}
	
	protected void validGTTInstance(GTTInstance newGttInstance, boolean forCreate){
		
		newGttInstance.setInstanceName(StringUtils.trimToEmpty(newGttInstance.getInstanceName()));
		newGttInstance.setStorageConnectionInfo(StringUtils.trimToEmpty(newGttInstance.getStorageConnectionInfo()));
		if(StringUtils.isBlank(newGttInstance.getInstanceName())){
			throw new ServiceManagerException(String.format(GTT_INSTANCE_MISSING_INSTANCE_NAME), null); 
		}
		
		// instance name unique check
		GTTInstance oldGttInstance = null;
		if(forCreate){
			oldGttInstance = serviceManagerDao.getGTTInstanceByName(newGttInstance.getInstanceName());
			if(oldGttInstance != null){
				throw new ServiceManagerException(String.format(GTT_INSTANCE_NAME_ALREADY_EXISTS, newGttInstance.getInstanceName()), null); 
			}
			
			if(StringUtils.isBlank(newGttInstance.getNamespace())){
				// namespace not provided, need generate one
				newGttInstance.setNamespace(generateNamespace(newGttInstance));
			}
		
		}
		else{
			oldGttInstance = serviceManagerDao.getGTTInstance(newGttInstance.getId());
			if(oldGttInstance == null){
				throw new ServiceManagerException(String.format(GTT_INSTANCE_NOT_FOUND, newGttInstance.getId()), null); 
			}
			// instanceName cannot be changed
			if(!StringUtils.equals(oldGttInstance.getInstanceName(), newGttInstance.getInstanceName())){
				throw new ServiceManagerException(String.format(GTT_INSTANCE_NAME_CANNOT_BE_CHANGED, oldGttInstance.getInstanceName(), newGttInstance.getInstanceName()), null); 
			}
			
		}
		
		if(StringUtils.isBlank(newGttInstance.getNamespace())){
			// namespace not set, error
			throw new ServiceManagerException(String.format(GTT_INSTANCE_MISSING_NAMESPACE), null); 
		}
		
		// check duplicate namespace
		if(this.serviceManagerDao.duplicateCheckGTTInstanceByNamespace(newGttInstance.getNamespace(), newGttInstance.getId())){
			throw new ServiceManagerException(String.format(GTT_INSTANCE_NAMESPACE_ALREADY_EXISTS, newGttInstance.getNamespace()), null); 
		}
		
		newGttInstance.setStorageType(newGttInstance.getStorageType());
		if(StringUtils.isBlank(newGttInstance.getStorageConnectionInfo())){
			throw new ServiceManagerException(String.format(GTT_INSTANCE_CONNECTION_INFO_MISSING), null); 
		}
	}
	
	protected String generateNamespace(GTTInstance gttInstance){
		String normalizedInstanceName = normalizeGTTInstanceName(gttInstance.getInstanceName());
		int count = 0;
		for(GTTInstance gttInstanceInDB : this.serviceManagerDao.getGTTInstances()){
			String normalizedInDB = normalizeGTTInstanceName(gttInstanceInDB.getInstanceName());
			if(StringUtils.equals(normalizedInDB, normalizedInstanceName)){
				count++;
			}
		}

		if(count > 0){
			normalizedInstanceName = normalizedInstanceName + count;
		}
		
		return concatNamespace(normalizedInstanceName);
	}
	
	public static String concatNamespace(String normalizedInstanceName){
		return "com." + normalizedInstanceName + ".gtt.app";
	}
	public static String normalizeGTTInstanceName(String gttInstanceName){
		String normalizedInstanceName = gttInstanceName;
		normalizedInstanceName = StringUtils.trimToEmpty(normalizedInstanceName);
		// lowercasing
		normalizedInstanceName = StringUtils.lowerCase(normalizedInstanceName);
		// only keep letter and number
		normalizedInstanceName = RegExUtils.removePattern(normalizedInstanceName, "[^a-zA-Z0-9]");
		
		return normalizedInstanceName;
	}
	
	public GTTInstance getGTTInstance(String id){
		GTTInstance result = serviceManagerDao.getGTTInstance(id);
		if(result == null){
			throw new ServiceManagerException(String.format(GTT_INSTANCE_NOT_FOUND, id), null);
		}
		return result;
	}

	public List<GTTInstance> getGTTInstances(){
		return serviceManagerDao.getGTTInstances();
	}
	
	public GTTInstance getGTTInstanceByName(String instanceName){
		GTTInstance result = serviceManagerDao.getGTTInstanceByName(instanceName);
		if(result == null){
			throw new ServiceManagerException(String.format(GTT_INSTANCE_BY_NAME_NOT_FOUND, instanceName), null);
		}
		return result;
	}
	
	public GTTInstanceMapping getGTTInstanceMappingBySubaccountIdAndCloneInstanceId(String subaccountId, String cloneInstanceId){
		subaccountId = StringUtils.trimToEmpty(subaccountId);
		cloneInstanceId = StringUtils.trimToEmpty(cloneInstanceId);
		GTTInstanceMapping result = this.getGTTInstanceMappingBySubaccountIdAndCloneInstanceIdInternal(subaccountId, cloneInstanceId);
		if(result == null){
			throw new ServiceManagerException(String.format(GTT_INSTANCE_MAPPING_BY_SUBACCOUNT_ID_CLONEINSTANCE_ID_NOT_FOUND, subaccountId, cloneInstanceId), null);
		}
		return result;
	}
	
	protected GTTInstanceMapping getGTTInstanceMappingBySubaccountIdAndCloneInstanceIdInternal(String subaccountId, String cloneInstanceId){
		List<GTTInstanceMapping> gttInstanceMappings = this.getGTTInstanceMappings();
		GTTInstanceMapping result = null;
		for(GTTInstanceMapping gttInstanceMapping : gttInstanceMappings){
			if(StringUtils.equals(gttInstanceMapping.getSubaccountId(), subaccountId)
				&&
				StringUtils.equals(gttInstanceMapping.getCloneInstanceId(), cloneInstanceId)){
					result = gttInstanceMapping;
					break;
				}
		}
		
		return result;
	}
	
	public boolean gttInstanceMappingExists(String subaccountId, String cloneInstanceId){
		subaccountId = StringUtils.trimToEmpty(subaccountId);
		cloneInstanceId = StringUtils.trimToEmpty(cloneInstanceId);
		GTTInstanceMapping result = this.getGTTInstanceMappingBySubaccountIdAndCloneInstanceIdInternal(subaccountId, cloneInstanceId);
		return result != null; 
	}
	
	public List<GTTInstanceMapping> getGTTInstanceMappingsByCloneInstanceId(String cloneInstanceId){
		List<GTTInstanceMapping> gttInstanceMappings = this.getGTTInstanceMappings();
		List<GTTInstanceMapping> result = new ArrayList<>();
		for(GTTInstanceMapping gttInstanceMapping : gttInstanceMappings){
			if(
				StringUtils.equals(gttInstanceMapping.getCloneInstanceId(), cloneInstanceId)){
				result.add(gttInstanceMapping);
				}
		}
		
		return result;
	}
	
	public List<GTTInstanceMapping> getGTTInstanceMappings(){
		return serviceManagerDao.getGTTInstanceMappings();
		
	}
	
	@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public String createGTTInstanceMapping(GTTInstanceMapping gttInstanceMapping){
		gttInstanceMapping.setId(GTTUtils.UUIDUtils.generateTimeBasedUUID().toString());
		validGTTInstanceMapping(gttInstanceMapping);
		serviceManagerDao.insertGTTInstanceMapping(gttInstanceMapping);
		return gttInstanceMapping.getId();
	}
	
	@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public void deleteGTTInstanceMapping(String id){
		if(serviceManagerDao.deleteGTTInstanceMapping(id) == 0){
			throw new ServiceManagerException(String.format(GTT_INSTANCE_MAPPING_NOT_FOUND, id), null);
		}
	}
	
	protected void validGTTInstanceMapping(GTTInstanceMapping gttInstanceMapping){

		gttInstanceMapping.setCloneInstanceId(StringUtils.trimToEmpty(gttInstanceMapping.getCloneInstanceId()));
		gttInstanceMapping.setSubaccountId(StringUtils.trimToEmpty(gttInstanceMapping.getSubaccountId()));
		gttInstanceMapping.setSubdomain(StringUtils.trimToEmpty(gttInstanceMapping.getSubdomain()));
		
		if(StringUtils.equals(gttInstanceMapping.getPlan(), GTTInstanceMapping.PLAN_STANDALONE)){
			if(StringUtils.isBlank(gttInstanceMapping.getSubaccountId())){
				throw new ServiceManagerException(String.format(GTT_INSTANCE_MAPPING_MISSING_SUBACCOUNT_ID), null);
			}
			if(StringUtils.isBlank(gttInstanceMapping.getSubdomain())){
				throw new ServiceManagerException(String.format(GTT_INSTANCE_MAPPING_MISSING_SUBDOMAIN), null);
			}
		}
		else if(StringUtils.equals(gttInstanceMapping.getPlan(), GTTInstanceMapping.PLAN_SHARED)){
			if(StringUtils.isBlank(gttInstanceMapping.getCloneInstanceId())){
				throw new ServiceManagerException(String.format(GTT_INSTANCE_MAPPING_MISSING_CLONE_INSTANCE_ID), null);
			}
			
			if(StringUtils.isBlank(gttInstanceMapping.getInstanceId())){
				throw new ServiceManagerException(String.format(GTT_INSTANCE_MAPPING_MISSING_INSTANCE_ID), null);
			}
			
			// gtt instance must exits
			GTTInstance gttInstance = serviceManagerDao.getGTTInstance(gttInstanceMapping.getInstanceId());
			if(gttInstance == null){
				throw new ServiceManagerException(String.format(GTT_INSTANCE_NOT_FOUND,gttInstanceMapping.getInstanceId() ), null);
			}
		}
		else{
			throw new GTTInstanceMapping.PlanNotSupportException(gttInstanceMapping.getPlan());
		}
		
		//check duplicate
		if(this.gttInstanceMappingExists(gttInstanceMapping.getSubaccountId(), gttInstanceMapping.getCloneInstanceId())){
			throw new ServiceManagerException(String.format(GTT_INSTANCE_MAPPING_DUPLICATE_MAPPING,gttInstanceMapping.getSubaccountId(), gttInstanceMapping.getCloneInstanceId() ), null);
		}
		
		
	}
	
	
	public GTTInstanceMapping getGTTInstanceMapping(String id){
		GTTInstanceMapping result = serviceManagerDao.getGTTInstanceMapping(id);
		if(result == null){
			throw new ServiceManagerException(String.format(GTT_INSTANCE_MAPPING_NOT_FOUND, id), null);
		}
		return result;
	}
	
	
	
	private GTTPhysicalStorage determinePhysicalStorage(GTTInstanceMapping gttInstanceMapping, String storageType){
		List<GTTPhysicalStorage> physicalStorages = new ArrayList<>();
		if(StringUtils.equalsAny(storageType, GTTInstance.STORAGE_TYPE_MANAGED_HANA
				,GTTInstance.STORAGE_TYPE_HANA)){
			physicalStorages.addAll(this.getGTTPhysicalStoragesByType(DatabaseServiceInstance.DatabaseType.hana.name()));
		}
		else{
			throw new GTTInstance.StorageTypeNotSupportException(storageType);
		}
		
		//TODO: enhance logic
		
		GTTPhysicalStorage result = physicalStorages.get(0);
		return result;
	}

	protected String createServiceMapping(GTTInstanceMapping gttInstanceMapping, String storageType){
		
		if(StringUtils.equals(gttInstanceMapping.getPlan(), GTTInstanceMapping.PLAN_STANDALONE)){
			GTTPhysicalStorage physicalStorage = this.determinePhysicalStorage(gttInstanceMapping, storageType);
			
			GTTInstance gttInstance = new GTTInstance();
			if(StringUtils.isBlank(gttInstanceMapping.getCloneInstanceId())){
				gttInstance.setInstanceName(gttInstanceMapping.getSubdomain());
			}
			else{
				gttInstance.setInstanceName(gttInstanceMapping.getSubdomain() + "@" + gttInstanceMapping.getCloneInstanceId());
			}
			gttInstance.setStorageType(storageType);
			String gttInstanceId = this.createGTTInstanceForStandalonePlan(gttInstance, gttInstanceMapping.getSubaccountId(), gttInstanceMapping.getSubdomain(), gttInstanceMapping.getCloneInstanceId(), physicalStorage.getPhysicalId());
			gttInstanceMapping.setInstanceId(gttInstanceId);
			
			return this.createGTTInstanceMapping(gttInstanceMapping);
		}
		else if(StringUtils.equals(gttInstanceMapping.getPlan(), GTTInstanceMapping.PLAN_SHARED)){
			return this.createGTTInstanceMapping(gttInstanceMapping);
		}
		else{
			throw new GTTInstanceMapping.PlanNotSupportException(gttInstanceMapping.getPlan());
		}
		
	}
	
	@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public void provisionForStandalonePlan(GTTInstanceMapping gttInstanceMapping, String storageType){
		
		if(this.gttInstanceMappingExists(gttInstanceMapping.getSubaccountId(), gttInstanceMapping.getCloneInstanceId())){
			return;
		}
		
		gttInstanceMapping.setPlan(GTTInstanceMapping.PLAN_STANDALONE);
		String gttInstanceMappingId = this.createServiceMapping(gttInstanceMapping, storageType);
		// provision 
		GTTInstanceMapping savedGTTInstanceMapping = this.getGTTInstanceMapping(gttInstanceMappingId);
		GTTInstance savedGTTInstance = this.getGTTInstance(savedGTTInstanceMapping.getInstanceId());
		StorageConnectionInfo connectionInfo = savedGTTInstance.parseStorageConnectionInfo();
		connectionInfo.provisionPersistence();

	}
	
	@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public void deprovision(GTTInstanceMapping gttInstanceMapping){
		
		if(!this.gttInstanceMappingExists(gttInstanceMapping.getSubaccountId(), gttInstanceMapping.getCloneInstanceId())){
			return;
		}
		this.deleteGTTInstanceMapping(gttInstanceMapping.getId());
		if(StringUtils.isBlank(gttInstanceMapping.getInstanceId())) return;
		if(StringUtils.equals(gttInstanceMapping.getPlan(), GTTInstanceMapping.PLAN_STANDALONE)){
			// deprovision the storage
			GTTInstance gttInstance = this.getGTTInstance(gttInstanceMapping.getInstanceId());
			StorageConnectionInfo connectionInfo = gttInstance.parseStorageConnectionInfo();
			this.deleteGTTInstance(gttInstance.getId());
			
			connectionInfo.deprovisionPersistence();
		}
		
	}
	
	@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public void provisionForSharedPlan(GTTInstanceMapping gttInstanceMapping){
		
		if(this.gttInstanceMappingExists(gttInstanceMapping.getSubaccountId(), gttInstanceMapping.getCloneInstanceId())){
			return;
		}
		gttInstanceMapping.setPlan(GTTInstanceMapping.PLAN_SHARED);
		this.createServiceMapping(gttInstanceMapping,null);
	}
	
	public String createGTTPhysicalStorage(GTTPhysicalStorage  gttPhysicalStorage){
		gttPhysicalStorage.setId(GTTUtils.UUIDUtils.generateTimeBasedUUID().toString());
		this.validateGTTPhysicalStorage(gttPhysicalStorage);
		serviceManagerDao.insertGTTPhysicalStorage(gttPhysicalStorage);
		return gttPhysicalStorage.getId();
	}
	
	protected void validateGTTPhysicalStorage(GTTPhysicalStorage gttPhysicalStorage){
		if(StringUtils.isBlank(gttPhysicalStorage.getPhysicalId())){
			throw new ServiceManagerException(String.format(GTT_PHYSICAL_STORAGE_MISSING_PHYSICAL_ID), null);
		}
	
		if(!StringUtils.equalsAny(gttPhysicalStorage.getPhysicalType(), DatabaseType.hana.name())){
			throw new PhysicalTypeNotSupportException(gttPhysicalStorage.getPhysicalType());
		}
		
		
	}
	
	public void deleteGTTPhysicalStorage(String id){
		if(serviceManagerDao.deleteGTTPhysicalStorage(id) == 0){
			throw new ServiceManagerException(String.format(GTT_PHYSICAL_STORAGE_NOT_FOUND, id), null);
		}
	}

	public List<GTTPhysicalStorage> getGTTPhysicalStorages(){
		return serviceManagerDao.getGTTPhysicalStorages();
	}
	
	public List<GTTPhysicalStorage> getGTTPhysicalStoragesByType(String physicalType){
		List<GTTPhysicalStorage> physicalStorages = this.getGTTPhysicalStorages();
		List<GTTPhysicalStorage> result = new ArrayList<>();
		for(GTTPhysicalStorage physicalStorage : physicalStorages){
			if(StringUtils.equals(physicalStorage.getPhysicalType(),physicalType)){
				result.add(physicalStorage);
			}
		}
		return result;
	}
	
	public GTTPhysicalStorage getGTTPhysicalStorage(String id){
		GTTPhysicalStorage result = serviceManagerDao.getGTTPhysicalStorage(id);
		if(result == null){
			throw new ServiceManagerException(String.format(GTT_PHYSICAL_STORAGE_NOT_FOUND, id), null);
		}
		
		return result;
	}

	@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public void updateGTTTenantSetting(GTTTenantSetting gttTenantSetting){
		gttTenantSetting.validate();
		GTTInstanceMapping instanceMapping = this.getGTTInstanceMapping(gttTenantSetting.getInstanceMappingId());
		this.serviceManagerDao.deleteGTTTenantSettingParams(instanceMapping.getId());
		
		for(Entry<String, String> entry : gttTenantSetting.getParameters().entrySet()){
			String paramName = entry.getKey();
			String paramValue = entry.getValue();
			GTTTenantSettingParam gttTenantSettingParam = new GTTTenantSettingParam();
			gttTenantSettingParam.setId(GTTUtils.UUIDUtils.generateTimeBasedUUID().toString());
			gttTenantSettingParam.setInstanceMappingId(instanceMapping.getId());
			gttTenantSettingParam.setParamName(paramName);
			gttTenantSettingParam.setParamValue(paramValue);
			this.serviceManagerDao.insertGTTTenantSettingParam(gttTenantSettingParam);
		}
		
	}
	
	public GTTTenantSetting getGTTTenantSetting(String subaccountId, String cloneInstanceId){
		GTTInstanceMapping instanceMapping = this.getGTTInstanceMappingBySubaccountIdAndCloneInstanceId(subaccountId, cloneInstanceId);
		return this.getGTTTenantSetting(instanceMapping.getId());
	}
	
	protected GTTTenantSetting getGTTTenantSetting(String instanceMappingId){
		List<GTTTenantSettingParam> tenantSettingParams = this.serviceManagerDao.getGTTTenantSettingParams(instanceMappingId);
		
		GTTTenantSetting result = new GTTTenantSetting();
		result.setInstanceMappingId(instanceMappingId);
		for(GTTTenantSettingParam param : tenantSettingParams){
			result.getParameters().put(param.getParamName(), param.getParamValue());
		}
		
		return result;
		
	}
	
}
