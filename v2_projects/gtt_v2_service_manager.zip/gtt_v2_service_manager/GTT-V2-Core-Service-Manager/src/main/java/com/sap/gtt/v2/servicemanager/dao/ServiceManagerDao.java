package com.sap.gtt.v2.servicemanager.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.sap.gtt.v2.servicemanager.GTTInstance;
import com.sap.gtt.v2.servicemanager.GTTInstanceMapping;
import com.sap.gtt.v2.servicemanager.GTTPhysicalStorage;
import com.sap.gtt.v2.tenant.GTTTenantSettingParam;

@Repository
public class ServiceManagerDao {

	private static final String TABLE_NAME_GTT_INSTANCE = "GTT_INSTANCE";
	private static final String TABLE_NAME_GTT_INSTANCE_MAPPING = "GTT_INSTANCE_MAPPING";
	private static final String TABLE_NAME_GTT_PHYSICAL_STORAGE = "GTT_PHYSICAL_STORAGE";
	private static final String TABLE_NAME_GTT_TENANT_SETTING_PARAM = "GTT_TENANT_SETTING_PARAM";
	
	private static final String SQL_INSERT_GTT_INSTANCE = "INSERT INTO "+TABLE_NAME_GTT_INSTANCE+" VALUES(?,?,?,?,?)";
	private static final String SQL_DELETE_GTT_INSTANCE = "DELETE FROM "+TABLE_NAME_GTT_INSTANCE+" WHERE ID = ?";
	private static final String SQL_SELECT_ALL_GTT_INSTANCE = "SELECT * FROM " + TABLE_NAME_GTT_INSTANCE;
	private static final String SQL_SELECT_SINGLE_GTT_INSTANCE_BY_NAMESPACE = "SELECT * FROM " + TABLE_NAME_GTT_INSTANCE + " WHERE NAMESPACE = ? ";
	private static final String SQL_SELECT_SINGLE_GTT_INSTANCE = "SELECT * FROM " + TABLE_NAME_GTT_INSTANCE +" WHERE ID = ?";
	private static final String SQL_SELECT_SINGLE_GTT_INSTANCE_BY_NAME = "SELECT * FROM " + TABLE_NAME_GTT_INSTANCE +" WHERE INSTANCE_NAME = ?";
	private static final String SQL_SELECT_DUPLICATE_CHECK_GTT_INSTANCE_BY_NAMESPACE = "SELECT COUNT(*) FROM " + TABLE_NAME_GTT_INSTANCE + " WHERE NAMESPACE = ? AND ID <> ?";
	
	
	private static final String SQL_INSERT_GTT_INSTANCE_MAPPING = "INSERT INTO "+TABLE_NAME_GTT_INSTANCE_MAPPING+" VALUES(?,?,?,?,?,?)";
	private static final String SQL_DELETE_GTT_INSTANCE_MAPPING = "DELETE FROM "+TABLE_NAME_GTT_INSTANCE_MAPPING+" WHERE ID = ?";
	private static final String SQL_SELECT_ALL_GTT_INSTANCE_MAPPING = "SELECT * FROM " + TABLE_NAME_GTT_INSTANCE_MAPPING;
	private static final String SQL_SELECT_SINGLE_GTT_INSTANCE_MAPPING = "SELECT * FROM " + TABLE_NAME_GTT_INSTANCE_MAPPING +" WHERE ID = ?";
	
	private static final String SQL_INSERT_GTT_PHYSICAL_STORAGE = "INSERT INTO "+TABLE_NAME_GTT_PHYSICAL_STORAGE+" VALUES(?,?,?,?,?,?,?,?,?)";
	private static final String SQL_DELETE_GTT_PHYSICAL_STORAGE = "DELETE FROM "+TABLE_NAME_GTT_PHYSICAL_STORAGE+" WHERE ID = ?";
	private static final String SQL_SELECT_ALL_GTT_PHYSICAL_STORAGE = "SELECT * FROM " + TABLE_NAME_GTT_PHYSICAL_STORAGE;
	private static final String SQL_SELECT_SINGLE_GTT_PHYSICAL_STORAGE = "SELECT * FROM " + TABLE_NAME_GTT_PHYSICAL_STORAGE +" WHERE ID = ?";
	
	private static final String SQL_INSERT_GTT_TENANT_SETTING_PARAM = "INSERT INTO "+ TABLE_NAME_GTT_TENANT_SETTING_PARAM+" VALUES(?,?,?,?)";
	private static final String SQL_DELETE_GTT_TENANT_SETTING_PARAMS = "DELETE FROM "+ TABLE_NAME_GTT_TENANT_SETTING_PARAM+" WHERE INSTANCE_MAPPING_ID = ?";
	private static final String SQL_SELECT_GTT_TENANT_SETTING_PARAMS = "SELECT * FROM " + TABLE_NAME_GTT_TENANT_SETTING_PARAM+" WHERE INSTANCE_MAPPING_ID = ?";
	
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	
	public int insertGTTInstance(GTTInstance gttInstance){
		return jdbcTemplate.update(SQL_INSERT_GTT_INSTANCE, 
				gttInstance.getId(),
				gttInstance.getInstanceName(),
				gttInstance.getStorageType(),
				gttInstance.getStorageConnectionInfo(),
				gttInstance.getNamespace()
		);
	}
	
	private static class GTTInstanceRowMapper implements RowMapper<GTTInstance>{

		@Override
		public GTTInstance mapRow(ResultSet rs, int rowNum) throws SQLException {
			GTTInstance result = new GTTInstance();
			result.setId(rs.getString("ID"));
			result.setInstanceName(rs.getString("INSTANCE_NAME"));
			result.setStorageType(rs.getString("STORAGE_TYPE"));
			result.setStorageConnectionInfo(rs.getString("STORAGE_CONNECTION_INFO"));
			result.setNamespace(rs.getString("NAMESPACE"));
			return result;
		}
		
	}
	
	public int deleteGTTInstance(String id){
		return jdbcTemplate.update(SQL_DELETE_GTT_INSTANCE, new Object[]{
				id
		});
	}
	
	public List<GTTInstance> getGTTInstances(){
		return jdbcTemplate.query(SQL_SELECT_ALL_GTT_INSTANCE, new GTTInstanceRowMapper());
	}
	
	public GTTInstance getGTTInstance(String id){
		List<GTTInstance> result = jdbcTemplate.query(SQL_SELECT_SINGLE_GTT_INSTANCE, new Object[]{id},new GTTInstanceRowMapper());
		return result.isEmpty()? null : result.get(0);
	}
	
	public GTTInstance getGTTInstanceByName(String instanceName){
		List<GTTInstance> result = jdbcTemplate.query(SQL_SELECT_SINGLE_GTT_INSTANCE_BY_NAME, new Object[]{instanceName},new GTTInstanceRowMapper());
		return result.isEmpty()? null : result.get(0);
	}
	
	public GTTInstance getGTTInstanceByNamespace(String namespace){
		List<GTTInstance> result = jdbcTemplate.query(SQL_SELECT_SINGLE_GTT_INSTANCE_BY_NAMESPACE, new Object[]{namespace},new GTTInstanceRowMapper());
		return result.isEmpty()? null : result.get(0);
	}
	
	public boolean duplicateCheckGTTInstanceByNamespace(String namespace, String id){
		int result = jdbcTemplate.queryForObject(SQL_SELECT_DUPLICATE_CHECK_GTT_INSTANCE_BY_NAMESPACE, new Object[]{namespace,id},Integer.class);
		return result == 0? false : true;
	}
	

	public int insertGTTInstanceMapping(GTTInstanceMapping gttInstanceMapping){
		return jdbcTemplate.update(SQL_INSERT_GTT_INSTANCE_MAPPING, new Object[]{
				gttInstanceMapping.getId(),
				gttInstanceMapping.getCloneInstanceId(),
				gttInstanceMapping.getPlan(),
				gttInstanceMapping.getSubaccountId(),
				gttInstanceMapping.getSubdomain(),
				gttInstanceMapping.getInstanceId()
				
		});
	}
	
	private static class GTTInstanceMappingRowMapper implements RowMapper<GTTInstanceMapping>{

		@Override
		public GTTInstanceMapping mapRow(ResultSet rs, int rowNum) throws SQLException {
			GTTInstanceMapping result = new GTTInstanceMapping();
			result.setId(rs.getString("ID"));
			result.setCloneInstanceId(rs.getString("CLONE_INSTANCE_ID"));
			result.setPlan(rs.getString("PLAN"));
			result.setSubaccountId(rs.getString("SUBACCOUNT_ID"));
			result.setSubdomain(rs.getString("SUBDOMAIN"));
			result.setInstanceId(rs.getString("GTT_INSTANCE_ID"));
			return result;
		}
		
	}
	
	public int deleteGTTInstanceMapping(String id){
		return jdbcTemplate.update(SQL_DELETE_GTT_INSTANCE_MAPPING, new Object[]{
				id
		});
	}
	
	public List<GTTInstanceMapping> getGTTInstanceMappings(){
		return jdbcTemplate.query(SQL_SELECT_ALL_GTT_INSTANCE_MAPPING, new GTTInstanceMappingRowMapper());
	}
	
	
	public GTTInstanceMapping getGTTInstanceMapping(String id){
		List<GTTInstanceMapping> result = jdbcTemplate.query(SQL_SELECT_SINGLE_GTT_INSTANCE_MAPPING,new Object[]{id}, new GTTInstanceMappingRowMapper());
		return result.isEmpty()? null : result.get(0);
	}
	
	
	public int insertGTTPhysicalStorage(GTTPhysicalStorage gttPhysicalStorage){
		return jdbcTemplate.update(SQL_INSERT_GTT_PHYSICAL_STORAGE, new Object[]{
				gttPhysicalStorage.getId(),
				gttPhysicalStorage.getPhysicalId(),
				gttPhysicalStorage.getPhysicalType(),
				gttPhysicalStorage.getGlobalAccountId(),
				gttPhysicalStorage.getGlobalAccountName(),
				gttPhysicalStorage.getOrgId(),
				gttPhysicalStorage.getOrgName(),
				gttPhysicalStorage.getSpaceId(),
				gttPhysicalStorage.getSpaceName()
				
		});
	}
	
	private static class GTTPhysicalStorageRowMapper implements RowMapper<GTTPhysicalStorage>{

		@Override
		public GTTPhysicalStorage mapRow(ResultSet rs, int rowNum) throws SQLException {
			GTTPhysicalStorage result = new GTTPhysicalStorage();
			result.setId(rs.getString("ID"));
			result.setPhysicalId(rs.getString("PHYSICAL_ID"));
			result.setPhysicalType(rs.getString("PHYSICAL_TYPE"));
			result.setGlobalAccountId(rs.getString("GLOBAL_ACCOUNT_ID"));
			result.setGlobalAccountName(rs.getString("GLOBAL_ACCOUNT_NAME"));
			result.setOrgId(rs.getString("ORG_ID"));
			result.setOrgName(rs.getString("ORG_NAME"));
			result.setSpaceId(rs.getString("SPACE_ID"));
			result.setSpaceName(rs.getString("SPACE_NAME"));
			return result;

		}
		
	}
	
	public int deleteGTTPhysicalStorage(String id){
		return jdbcTemplate.update(SQL_DELETE_GTT_PHYSICAL_STORAGE, 
				id
		);
	}
	
	public List<GTTPhysicalStorage> getGTTPhysicalStorages(){
		return jdbcTemplate.query(SQL_SELECT_ALL_GTT_PHYSICAL_STORAGE, new GTTPhysicalStorageRowMapper());
	}
	
	
	public GTTPhysicalStorage getGTTPhysicalStorage(String id){
		List<GTTPhysicalStorage> result = jdbcTemplate.query(SQL_SELECT_SINGLE_GTT_PHYSICAL_STORAGE,new Object[]{id}, new GTTPhysicalStorageRowMapper());
		return result.isEmpty()? null : result.get(0);
	}
	
	public int insertGTTTenantSettingParam(GTTTenantSettingParam gttTenantSettingParam){
		return jdbcTemplate.update(SQL_INSERT_GTT_TENANT_SETTING_PARAM, 
				gttTenantSettingParam.getId(),
				gttTenantSettingParam.getInstanceMappingId(),
				gttTenantSettingParam.getParamName(),
				gttTenantSettingParam.getParamValue()
				
		);
	}
	
	public int deleteGTTTenantSettingParams(String instanceMappingId){
		return jdbcTemplate.update(SQL_DELETE_GTT_TENANT_SETTING_PARAMS, 
				instanceMappingId
				
		);
	}
	
	private static class GTTTenantSettingParamRowMapper implements RowMapper<GTTTenantSettingParam>{

		@Override
		public GTTTenantSettingParam mapRow(ResultSet rs, int rowNum) throws SQLException {
			GTTTenantSettingParam result = new GTTTenantSettingParam();
			result.setId(rs.getString("ID"));
			result.setInstanceMappingId(rs.getString("INSTANCE_MAPPING_ID"));
			result.setParamName(rs.getString("PARAM_NAME"));
			result.setParamValue(rs.getString("PARAM_VALUE"));
			return result;

		}
		
	}
	
	public List<GTTTenantSettingParam> getGTTTenantSettingParams(String instanceMappingId){
		return jdbcTemplate.query(SQL_SELECT_GTT_TENANT_SETTING_PARAMS,new Object[]{instanceMappingId}, new GTTTenantSettingParamRowMapper());
	}
	
	
}
