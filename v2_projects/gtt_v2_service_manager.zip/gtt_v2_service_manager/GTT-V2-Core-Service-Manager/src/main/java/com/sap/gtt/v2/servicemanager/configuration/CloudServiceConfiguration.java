package com.sap.gtt.v2.servicemanager.configuration;

import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import com.sap.gtt.v2.configuration.EnvironmentsConfiguration.VcapServiceParser.JdbcEnabledDatabaseServiceInstance;
import com.sap.gtt.v2.configuration.ServiceInstancesMapping;

@Configuration
public class CloudServiceConfiguration {
	
    @Bean
    @Primary
    public DataSource serviceManagerDataSource(ServiceInstancesMapping serviceInstancesMapping) {
    	
    	/*we cannot use below approach, because there is a bug in HANAServiceInfoCreator 
    	 It will ignore the parameters in URL
    	 url": "jdbc:sap://zeus.hana.canary.eu-central-1.whitney.dbaas.ondemand.com:21960?encrypt=true&validateCertificate=true&currentschema=USR_EY9BYIWH564GWJPULOMA5UPG7", 
    	 when ignore "encrypt=true", the connection will be rejected by HANA
    	 */
    	//return connectionFactory().dataSource(securestoreServiceInstance.getInstanceName());
    	
    	// below is workaround by manually create datasource
    	return ((JdbcEnabledDatabaseServiceInstance)serviceInstancesMapping.getServiceManagerDBServiceInstance()).getDataSource();
    }

}