package com.sap.gtt.v2.servicemanager.controller;

import com.sap.gtt.v2.configuration.SystemConstants;
import com.sap.gtt.v2.servicemanager.upgrade.UpgradeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(UpgradeController.ROOT_URL)
public class UpgradeController {
    public static final String ROOT_URL = SystemConstants.SERVICE_MANAGER_ROOT_URL + "/upgrade-db";
    @Autowired
    private UpgradeService upgradeService;

    @PostMapping(value = "/upgradeAll", consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.OK)
    public String upgradeAllDb(@RequestBody String body) {
        return upgradeService.upgradeAllDb(body);
    }

    @PostMapping(value = "", consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.OK)
    public String upgradeTheDb(@RequestBody String body) {
        return upgradeService.upgradeTheDb(body);
    }
}
