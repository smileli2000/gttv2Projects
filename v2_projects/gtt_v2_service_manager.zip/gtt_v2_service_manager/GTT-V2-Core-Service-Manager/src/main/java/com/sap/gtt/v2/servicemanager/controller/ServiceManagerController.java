package com.sap.gtt.v2.servicemanager.controller;

import java.util.List;

import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.sap.gtt.v2.configuration.ServiceInstancesMapping;
import com.sap.gtt.v2.configuration.SystemConstants;
import com.sap.gtt.v2.controller.IBaseRestController;
import com.sap.gtt.v2.exception.MultiExceptionContainer;
import com.sap.gtt.v2.servicemanager.GTTInstance;
import com.sap.gtt.v2.servicemanager.GTTInstanceMapping;
import com.sap.gtt.v2.servicemanager.GTTPhysicalStorage;
import com.sap.gtt.v2.servicemanager.management.ServiceManagerException;
import com.sap.gtt.v2.servicemanager.management.ServiceManagerManagement;
import com.sap.gtt.v2.servicemanager.subscription.SubscriptionService;
import com.sap.gtt.v2.tenant.GTTTenantSetting;

@RestController
@RequestMapping(ServiceManagerController.ROOT_URL)
public class ServiceManagerController implements IBaseRestController{

	public static final String ROOT_URL = SystemConstants.SERVICE_MANAGER_ROOT_URL;
	private static final Logger logger = LoggerFactory.getLogger(ServiceManagerController.class);
	
	protected static final String DEPROVISION_MISSING_ClONEINSTANCE_ID = "Missing cloneInstanceId when deprovisioning";
	
	
	public static class ProvisionParams {
		@JsonInclude // mitigate fortify Mass Assignment: Insecure Binder Configuration
		private String cloneInstanceSubaccountId;
		@JsonInclude
		private String cloneInstanceSubdomain;
		@JsonInclude
		private String cloneInstanceId;
		@JsonInclude
		private String plan;
		@JsonInclude
		private String storageType;
		@JsonInclude
		private String instanceName;
		
		public String getCloneInstanceId() {
			return cloneInstanceId;
		}
		public void setCloneInstanceId(String cloneInstanceId) {
			this.cloneInstanceId = cloneInstanceId;
		}
		public String getPlan() {
			return plan;
		}
		public void setPlan(String plan) {
			this.plan = plan;
		}
		public String getStorageType() {
			return storageType;
		}
		public void setStorageType(String storageType) {
			this.storageType = storageType;
		}
		public String getInstanceName() {
			return instanceName;
		}
		public void setInstanceName(String instanceName) {
			this.instanceName = instanceName;
		}
		public String getCloneInstanceSubaccountId() {
			return cloneInstanceSubaccountId;
		}
		public void setCloneInstanceSubaccountId(String cloneInstanceSubaccountId) {
			this.cloneInstanceSubaccountId = cloneInstanceSubaccountId;
		}
		public String getCloneInstanceSubdomain() {
			return cloneInstanceSubdomain;
		}
		public void setCloneInstanceSubdomain(String cloneInstanceSubdomain) {
			this.cloneInstanceSubdomain = cloneInstanceSubdomain;
		}
		@Override
		public String toString() {
			return "ProvisionParams [cloneInstanceSubaccountId=" + cloneInstanceSubaccountId
					+ ", cloneInstanceSubdomain=" + cloneInstanceSubdomain + ", cloneInstanceId=" + cloneInstanceId
					+ ", plan=" + plan + ", storageType=" + storageType + ", instanceName=" + instanceName + "]";
		}
		
		
	}
	
    @Autowired
    private SubscriptionService subscriptionService;
    @Autowired
    private ServiceManagerManagement serviceManager;
    @Autowired
    private ServiceInstancesMapping serviceInstancesMapping;

    @RequestMapping(value = "/broker/onProvision", method = RequestMethod.POST, 
			consumes =MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.CREATED)
    public GTTInstanceMapping onProvision(@Valid @RequestBody ProvisionParams provisionParams,
    		@RequestParam(name = "autoSubscribe", defaultValue="false") boolean autoSubscribe) {

       logger.info("onProvision - {}", provisionParams);
    	GTTInstanceMapping gttInstanceMapping = new GTTInstanceMapping();
    	if(StringUtils.equals(provisionParams.getPlan(), GTTInstanceMapping.PLAN_SHARED)){
    		gttInstanceMapping.setCloneInstanceId(provisionParams.getCloneInstanceId());
    		gttInstanceMapping.setPlan(provisionParams.getPlan());
    		GTTInstance gttInstance = serviceManager.getGTTInstanceByName(provisionParams.getInstanceName());
    		gttInstanceMapping.setInstanceId(gttInstance.getId());
    		
    		serviceManager.provisionForSharedPlan(gttInstanceMapping);
    		
    	}
    	else {
    		throw new GTTInstanceMapping.PlanNotSupportException(provisionParams.getPlan());
    	}
    	
    	// subscribe clone instance for the owner subaccount
    	// the stack service call will trigger CIS, but since payload does not contain clone instance id, so we skip
    	if(autoSubscribe && !StringUtils.isBlank(provisionParams.getCloneInstanceSubaccountId())){
    		subscriptionService.createServiceSubscription(provisionParams.getCloneInstanceSubaccountId(), provisionParams.getCloneInstanceSubdomain(), provisionParams.getCloneInstanceId());
    	}
        
    	return gttInstanceMapping;
    }
    

    @DeleteMapping(value = "/broker/onDeprovision/{cloneInstanceId}",
			consumes =MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> onDeprovision(@PathVariable(name = "cloneInstanceId", required = true) String cloneInstanceId,
    		@RequestParam(name = "autoUnsubscribe", defaultValue="false") boolean autoUnsubscribe) {
    	if(StringUtils.isBlank(cloneInstanceId)){
			throw new ServiceManagerException(DEPROVISION_MISSING_ClONEINSTANCE_ID, null);
		}
    	List<GTTInstanceMapping> gttInstanceMappings =serviceManager.getGTTInstanceMappingsByCloneInstanceId(cloneInstanceId);
    	
    	MultiExceptionContainer multiExceptionContainer = new MultiExceptionContainer(HttpStatus.INTERNAL_SERVER_ERROR.value());
		for(GTTInstanceMapping gttInstanceMapping : gttInstanceMappings){
			logger.info("deprovision - {}",gttInstanceMapping);
			try{
				
				if(autoUnsubscribe){
					// this stack service call will trigger CIS,
					// but since payload do not contain clone instance id, so we skip the processing in CIS
					subscriptionService.deleteServiceSubscription(gttInstanceMapping.getSubaccountId(), gttInstanceMapping.getCloneInstanceId());
				}
				
				serviceManager.deprovision(gttInstanceMapping);
				
			}
			catch(Exception e){
				multiExceptionContainer.addException(e);
				logger.error("deprovision error : {}", e.getMessage());
			}
			
		}
		
		if(multiExceptionContainer.containsError()){
			throw multiExceptionContainer;
		}
		 
    	return new ResponseEntity<>("", HttpStatus.OK);
    }

    @GetMapping(value = "/getInstance",produces = MediaType.APPLICATION_JSON_VALUE)
    public GTTInstance getGTTInstance(@RequestParam("subaccountId") String subaccountId,@RequestParam("cloneInstanceId") String cloneInstanceId) {
    	cloneInstanceId = StringUtils.trimToEmpty(cloneInstanceId);
    	GTTInstanceMapping gttInstanceMapping = serviceManager.getGTTInstanceMappingBySubaccountIdAndCloneInstanceId(subaccountId, cloneInstanceId);
    	return serviceManager.getGTTInstance(gttInstanceMapping.getInstanceId());
    }
    
    @RequestMapping(value = "/initDB", method = RequestMethod.POST,produces = MediaType.APPLICATION_JSON_VALUE)
    public void initDB() {
    	serviceInstancesMapping.getServiceManagerDBServiceInstance().init();
    }
    
    @PostMapping(value = "/emptyDB",produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.CREATED)
    public void emptyDB() {
    	serviceInstancesMapping.getServiceManagerDBServiceInstance().empty();
    }
    
    @PostMapping(value = "/physicalStorages",consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.CREATED)
    public GTTPhysicalStorage createGTTPhysicalStorage(@RequestBody GTTPhysicalStorage gttPhysicalStorage) {
    	String id = serviceManager.createGTTPhysicalStorage(gttPhysicalStorage);
    	return serviceManager.getGTTPhysicalStorage(id);
    }
    
    @DeleteMapping(value = "/physicalStorages/{id}",produces = MediaType.APPLICATION_JSON_VALUE)
    public void deleteGTTPhysicalStorage(@PathVariable String id) {
    	serviceManager.deleteGTTPhysicalStorage(id);
    }
    
    @GetMapping(value = "/physicalStorages",produces = MediaType.APPLICATION_JSON_VALUE)
    public List<GTTPhysicalStorage> getGTTPhysicalStorages() {
    	return serviceManager.getGTTPhysicalStorages();
    }
    
    @GetMapping(value = "/instances",produces = MediaType.APPLICATION_JSON_VALUE)
    public List<GTTInstance> getGTTInstances() {
    	return serviceManager.getGTTInstances();
    }
    
    @GetMapping(value = "/instances/{id}",produces = MediaType.APPLICATION_JSON_VALUE)
    public GTTInstance getGTTInstance(@PathVariable String id) {
    	return serviceManager.getGTTInstance(id);
    }

    @PutMapping(value = "/instances/{id}",produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.OK)
    public GTTInstance updateGTTInstance(@PathVariable String id, 
    		@RequestParam(name = "plan", defaultValue = GTTInstanceMapping.PLAN_SHARED) String plan,
    		@RequestParam(name = "databaseServiceInstanceName", required=false) String databaseServiceInstanceName,
    		@RequestBody GTTInstance gttInstance) {
    	
    	gttInstance.setId(id);
    	
    	if(StringUtils.equals(plan, GTTInstanceMapping.PLAN_SHARED)){
    		serviceManager.updateGTTInstanceForSharedPlan(gttInstance, databaseServiceInstanceName);
    	}
    	else if(StringUtils.equals(plan, GTTInstanceMapping.PLAN_STANDALONE)){
    		throw new UnsupportedOperationException();
    	}
    	else{
    		throw new GTTInstanceMapping.PlanNotSupportException(plan);
    	}
    	return serviceManager.getGTTInstance(id);
    }
    
    @PostMapping(value = "/instances", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.CREATED)
    public GTTInstance createGTTInstance(@RequestBody GTTInstance gttInstance,
    		@RequestParam(name = "plan", defaultValue = GTTInstanceMapping.PLAN_SHARED) String plan,
    		@RequestParam(name = "subaccountId", required=false) String subaccountId,
    		@RequestParam(name = "subdomain", required=false) String subdomain,
    		@RequestParam(name = "cloneInstanceId", required=false) String cloneInstanceId,
    		@RequestParam(name = "physicalId", required=false) String physicalId,
    		@RequestParam(name = "databaseServiceInstanceName", required=false) String databaseServiceInstanceName) {
    	String id = null;
    	if(StringUtils.equals(plan, GTTInstanceMapping.PLAN_SHARED)){
    		id = serviceManager.createGTTInstanceForSharedPlan(gttInstance, databaseServiceInstanceName);
    	}
    	else if(StringUtils.equals(plan, GTTInstanceMapping.PLAN_STANDALONE)){
    		id = serviceManager.createGTTInstanceForStandalonePlan(gttInstance, subaccountId, subdomain, cloneInstanceId, physicalId);
    	}
    	else{
    		throw new GTTInstanceMapping.PlanNotSupportException(plan);
    	}
    	return serviceManager.getGTTInstance(id);
    }
    
    @DeleteMapping(value = "/instances/{id}")
    @ResponseStatus(HttpStatus.OK)
    public void deleteGTTInstance(@PathVariable String id) {
    	serviceManager.deleteGTTInstance(id);
    }
    
    
    @RequestMapping(value = "/instanceMappings", method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
    public List<GTTInstanceMapping> getGTTInstanceMappings() {
    	return serviceManager.getGTTInstanceMappings();
    }
    
    @RequestMapping(value = "/instanceMappings/{id}", method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
    public GTTInstanceMapping getGTTInstanceMapping(@PathVariable String id) {
    	return serviceManager.getGTTInstanceMapping(id);
    }
    
    @DeleteMapping(value = "/instanceMappings/{id}")
    public void deleteGTTInstanceMapping(@PathVariable String id) {
    	serviceManager.deleteGTTInstanceMapping(id);
    }

    @PostMapping(value = "/instanceMappings", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.CREATED)
    public GTTInstanceMapping createGTTInstanceMapping(@RequestBody GTTInstanceMapping gttInstanceMapping) {
    	String id =  serviceManager.createGTTInstanceMapping(gttInstanceMapping);
    	return serviceManager.getGTTInstanceMapping(id);
    }
    
    @PostMapping(value = "/storage/{instanceName}/init",
			 produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.OK)
    public void init(@PathVariable("instanceName") String instanceName) {
    	serviceManager.getGTTInstanceByName(instanceName).parseStorageConnectionInfo().init();
    }
    
    @PostMapping(value = "/storage/{instanceName}/empty",
			 produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.OK)
   public void empty(@PathVariable("instanceName") String instanceName) {
   	
    	serviceManager.getGTTInstanceByName(instanceName).parseStorageConnectionInfo().empty();
   	
   }
    
   
    @GetMapping(value = "/tenantSetting",produces = MediaType.APPLICATION_JSON_VALUE)
    public GTTTenantSetting getGTTTenantSetting(
    		@RequestParam("subaccountId") String subaccountId,
    		@RequestParam("cloneInstanceId") String cloneInstanceId) {
    	return serviceManager.getGTTTenantSetting(subaccountId, cloneInstanceId);
    }
    
    @PostMapping(value = "/tenantSetting",produces = MediaType.APPLICATION_JSON_VALUE,
    		consumes = MediaType.APPLICATION_JSON_VALUE)
    public GTTTenantSetting updateGTTTenantSetting(
    		@RequestParam("subaccountId") String subaccountId,
    		@RequestParam("cloneInstanceId") String cloneInstanceId,
    		@RequestBody GTTTenantSetting gttTenantSetting) {
    	GTTInstanceMapping instanceMapping = serviceManager.getGTTInstanceMappingBySubaccountIdAndCloneInstanceId(subaccountId, cloneInstanceId);
    	gttTenantSetting.setInstanceMappingId(instanceMapping.getId());
    	serviceManager.updateGTTTenantSetting(gttTenantSetting);
    	return serviceManager.getGTTTenantSetting(subaccountId, cloneInstanceId);
    }
}
