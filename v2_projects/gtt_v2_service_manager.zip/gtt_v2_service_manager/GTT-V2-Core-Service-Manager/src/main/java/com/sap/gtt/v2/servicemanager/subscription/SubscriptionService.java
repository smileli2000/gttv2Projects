/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.gtt.v2.servicemanager.subscription;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.sap.gtt.v2.configuration.EnvironmentsConfiguration.VcapServiceParser.SaasRegistryServiceInstance;
import com.sap.gtt.v2.configuration.EnvironmentsConfiguration.VcapServiceParser.SaasRegistryServiceInstance.APIWrapper;
import com.sap.gtt.v2.configuration.EnvironmentsConfiguration.VcapServiceParser.SaasRegistryServiceInstance.ReturnOfGetSubscriptions;
import com.sap.gtt.v2.configuration.EnvironmentsConfiguration.VcapServiceParser.SaasRegistryServiceInstance.Subscription;
import com.sap.gtt.v2.configuration.ServiceInstancesMapping;
import com.sap.gtt.v2.servicemanager.GTTInstance;
import com.sap.gtt.v2.servicemanager.GTTInstanceMapping;
import com.sap.gtt.v2.servicemanager.management.ServiceManagerManagement;
import com.sap.gtt.v2.util.GTTUtils;


/**
 *
 * @author I326335
 */
@Service
public class SubscriptionService {

   
    private static final Logger logger = LoggerFactory.getLogger(SubscriptionService.class);
  
    @Autowired
    private ServiceInstancesMapping serviceInstancesMapping;
    @Autowired
    private ServiceManagerManagement serviceManager;

    /**
     * Get clone instance id from payload
     * if null -> means subscribing on Master UAA -> standalone plan
     * if not null
     * 	get template mapping by clone instance id (with tenantId is empty)
     *  provision based on the plan of template mapping
     *  
     * @param subaccountId
     * @param subdomain
     * @param cloneInstanceId
     */
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    public void onSubscribe(String subaccountId, String subdomain, String cloneInstanceId) {
   
    	GTTInstanceMapping instanceMapping = null;
    	if(StringUtils.isBlank(cloneInstanceId)){
    		// No clone instance, means subscribe GTT v2 Master UAA, must be standalone
    		instanceMapping = new GTTInstanceMapping();
    		
    		instanceMapping.setPlan(GTTInstanceMapping.PLAN_STANDALONE);
    		
    	}
    	else if(serviceManager.gttInstanceMappingExists(StringUtils.EMPTY, cloneInstanceId)){
    		// Share Plan on Clone Instance
    		GTTInstanceMapping cloneInstanceGTTInstanceMapping = serviceManager.getGTTInstanceMappingBySubaccountIdAndCloneInstanceId(StringUtils.EMPTY, cloneInstanceId);
    		instanceMapping = GTTUtils.createAndCopyBean(cloneInstanceGTTInstanceMapping, GTTInstanceMapping.class, false);
    	}
    	else{
    		// Standalone Plan on Clone Instance
    		instanceMapping = new GTTInstanceMapping();
    		instanceMapping.setPlan(GTTInstanceMapping.PLAN_STANDALONE);
    		instanceMapping.setCloneInstanceId(cloneInstanceId);
    	}
    	
    	instanceMapping.setSubaccountId(subaccountId);
		instanceMapping.setSubdomain(subdomain);
		
    	if(StringUtils.equals(instanceMapping.getPlan(), GTTInstanceMapping.PLAN_SHARED)){
    		serviceManager.provisionForSharedPlan(instanceMapping);
    	}
    	else{
    		//TODO: need find a way to set storage type in runtime
    		serviceManager.provisionForStandalonePlan(instanceMapping, GTTInstance.STORAGE_TYPE_MANAGED_HANA);
    	}
    }

    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    public void onUnsubscribe(String subaccountId, String cloneInstanceId) {
    	if(!serviceManager.gttInstanceMappingExists(subaccountId, cloneInstanceId)){
    		return;
    	}
    	
    	GTTInstanceMapping instanceMapping = serviceManager.getGTTInstanceMappingBySubaccountIdAndCloneInstanceId(subaccountId, cloneInstanceId);
    	serviceManager.deprovision(instanceMapping);
    }
    
    
    public ReturnOfGetSubscriptions getApplicationSubscriptions(String subaccountId){
    	SaasRegistryServiceInstance saasRegistryServiceInstance = serviceInstancesMapping.getApplicationSaasRegistryServiceInstance();
    	return getSubscriptionsInternal(saasRegistryServiceInstance.getAPIWrapper(), subaccountId);
    }
    
    public ReturnOfGetSubscriptions getServiceSubscriptions(String subaccountId){
    	SaasRegistryServiceInstance saasRegistryServiceInstance = serviceInstancesMapping.getServiceSaasRegistryServiceInstance();
    	return getSubscriptionsInternal(saasRegistryServiceInstance.getAPIWrapper(),subaccountId);
    }
    
    protected ReturnOfGetSubscriptions getSubscriptionsInternal(APIWrapper apiWrapper, String subaccountId){
    	return apiWrapper.getSubscriptions(subaccountId);
    	
    }
    
    
    public void updateAllServiceSubscriptions(){
    	SaasRegistryServiceInstance saasRegistryServiceInstance = serviceInstancesMapping.getServiceSaasRegistryServiceInstance();
    	this.updateAllSubscriptionsInternal(saasRegistryServiceInstance.getAPIWrapper());
    }
    
    public void updateAllApplicationSubscriptions(){
    	SaasRegistryServiceInstance saasRegistryServiceInstance = serviceInstancesMapping.getApplicationSaasRegistryServiceInstance();
    	this.updateAllSubscriptionsInternal(saasRegistryServiceInstance.getAPIWrapper());
    }

    /**
     * will not trigger GTT instance creation
     * @param apiWrapper
     */
    protected void updateAllSubscriptionsInternal(APIWrapper apiWrapper){
    	for(Subscription subscription : apiWrapper.getSubscriptions(null).getSubscriptions()){
    		try{
    			apiWrapper.updateSubscription(subscription);
    		}
    		catch(Exception e){
    			logger.error("update Service Subscription Failed - serviceInstanceId:{} consumerTenantId:{}, message - {}", subscription.getServiceInstanceId(), subscription.getConsumerTenantId(), e.getMessage());
    		}
    		
    	}
    }
    
    public void createApplicationSubscription(String subaccountId){
    	SaasRegistryServiceInstance saasRegistryServiceInstance = serviceInstancesMapping.getApplicationSaasRegistryServiceInstance();
    	Subscription subscription = new Subscription();
    	subscription.setConsumerTenantId(subaccountId);
    	this.createSubscriptionInternal(saasRegistryServiceInstance.getAPIWrapper(), subscription);
    	
    }
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    public void createServiceSubscription(String subaccountId, String subdomain, String cloneInstanceId){
    	SaasRegistryServiceInstance saasRegistryServiceInstance = serviceInstancesMapping.getServiceSaasRegistryServiceInstance();
    	Subscription subscription = new Subscription();
    	subscription.setConsumerTenantId(subaccountId);
    	subscription.setServiceInstanceId(cloneInstanceId);
    	this.createSubscriptionInternal(saasRegistryServiceInstance.getAPIWrapper(), subscription);
    	
    	this.onSubscribe(subaccountId,subdomain, cloneInstanceId);
    }
    
    protected void createSubscriptionInternal(APIWrapper apiWrapper,Subscription subscription){
    	apiWrapper.createSubscription(subscription);
    }

    public void deleteApplicationSubscription(String subaccountId){
    	SaasRegistryServiceInstance saasRegistryServiceInstance = serviceInstancesMapping.getApplicationSaasRegistryServiceInstance();
    	Subscription subscription = new Subscription();
    	subscription.setConsumerTenantId(subaccountId);
    	this.deleteSubscriptionInternal(saasRegistryServiceInstance.getAPIWrapper(), subscription);
    	
    }
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    public void deleteServiceSubscription(String subaccountId, String cloneInstanceId){
    	SaasRegistryServiceInstance saasRegistryServiceInstance = serviceInstancesMapping.getServiceSaasRegistryServiceInstance();
    	Subscription subscription = new Subscription();
    	subscription.setConsumerTenantId(subaccountId);
    	subscription.setServiceInstanceId(cloneInstanceId);
    	this.deleteSubscriptionInternal(saasRegistryServiceInstance.getAPIWrapper(), subscription);
    	
    	this.onUnsubscribe(subaccountId, cloneInstanceId);
    }
    
    protected void deleteSubscriptionInternal(APIWrapper apiWrapper,Subscription subscription){
    	apiWrapper.deleteSubscription(subscription);
    }

    
    public void updateApplicationSubscription(String subaccountId){
    	SaasRegistryServiceInstance saasRegistryServiceInstance = serviceInstancesMapping.getApplicationSaasRegistryServiceInstance();
    	Subscription subscription = new Subscription();
    	subscription.setConsumerTenantId(subaccountId);
    	this.updateSubscriptionInternal(saasRegistryServiceInstance.getAPIWrapper(), subscription);
    	
    }
    
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    public void updateServiceSubscription(String subaccountId, String subdomain, String cloneInstanceId){
    	SaasRegistryServiceInstance saasRegistryServiceInstance = serviceInstancesMapping.getServiceSaasRegistryServiceInstance();
    	Subscription subscription = new Subscription();
    	subscription.setConsumerTenantId(subaccountId);
    	subscription.setServiceInstanceId(cloneInstanceId);
    	this.updateSubscriptionInternal(saasRegistryServiceInstance.getAPIWrapper(), subscription);
    	
    	this.onSubscribe(subaccountId, subdomain, cloneInstanceId);
    }
    
    protected void updateSubscriptionInternal(APIWrapper apiWrapper,Subscription subscription){
    	apiWrapper.updateSubscription(subscription);
    }
    
}
