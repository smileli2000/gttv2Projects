package com.sap.gtt.v2.servicemanager.upgrade;

import com.google.gson.JsonObject;
import com.sap.gtt.v2.servicemanager.GTTInstance;
import org.springframework.jdbc.core.JdbcTemplate;

public interface IDbUpgrade {
    JsonObject doUpgrade(GTTInstance gttInstance, String methodParamJson);
    void setJdbcTemplate(JdbcTemplate jdbcTemplate);
}
