package com.sap.gtt.v2.servicemanager.upgrade;

public class Constant {
    public static final String GTT_DB_UPGRADE_PROCEDURE_NAME_NOT_FOUND = " Upgrade procedure name '%s' is not configured";
    public static final String GTT_DB_UPGRADE_CLASS_NAME_NOT_FOUND = " Upgrade class name '%s' is not configured";
    public static final String GTT_DB_UPGRADE_CLASS_INVALID = " Upgrade class should impliment the IDbUpgrade interface.";
    public static final String GTT_DB_UPGRADE_CLASS_NOT_FOUND = "Upgrade class not found.";
}
