package com.sap.gtt.v2.servicemanager.upgrade.extension;

import com.google.gson.JsonObject;
import com.sap.gtt.v2.servicemanager.GTTInstance;
import com.sap.gtt.v2.servicemanager.GTTInstanceMapping;
import com.sap.gtt.v2.servicemanager.upgrade.AbstractCustomDbUpgrade;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class DBUpgradeForMMLAndVP extends AbstractCustomDbUpgrade {
    public static final String MESSAGE = "message";

    @Override
    public JsonObject doUpgrade(GTTInstance gttInstance, String methodParamJson) {
        JsonObject returnObj = new JsonObject();
        //update DB
        StringBuilder queryColumnSql = new StringBuilder();
        queryColumnSql.append("SELECT count(1) CNT FROM TABLE_COLUMNS where SCHEMA_NAME = CURRENT_SCHEMA AND TABLE_NAME = ? AND COLUMN_NAME=?");
        //cloneinstanceId and subaccountId
        Map<String, Object> map = jdbcTemplate.queryForMap(queryColumnSql.toString(), "REQUEST_PAYLOAD", "CLONEINSTANCEID");
        int cnt = Integer.parseInt(map.get("CNT").toString());
        if (cnt == 0) {
            StringBuilder alterSql = new StringBuilder();
            alterSql.append("ALTER TABLE REQUEST_PAYLOAD ADD (SUBACCOUNTID NVARCHAR(36), CLONEINSTANCEID NVARCHAR(36))");
            jdbcTemplate.execute(alterSql.toString());
        }
        //isProcessEvent
        map = jdbcTemplate.queryForMap(queryColumnSql.toString(), "EXECUTION_UNIT", "IS_PROCESS_EVENT");
        cnt = Integer.parseInt(map.get("CNT").toString());
        if (cnt == 0) {
            StringBuilder alterSql = new StringBuilder();
            alterSql.append("ALTER TABLE EXECUTION_UNIT ADD (IS_PROCESS_EVENT BOOLEAN)");
            jdbcTemplate.execute(alterSql.toString());
        }
        //init data for cloneinstanceId and subaccountId
        GTTInstance.StorageConnectionInfo storageConnectionInfo = gttInstance.parseStorageConnectionInfo();
        if (GTTInstanceMapping.PLAN_STANDALONE.equals(storageConnectionInfo.getPlan())) {
            GTTInstance.ManagedHanaStorageConnectionInfo standaloneStorageInfo = (GTTInstance.ManagedHanaStorageConnectionInfo) storageConnectionInfo;
            String subaccountId = standaloneStorageInfo.getSubaccountId();
            StringBuilder sql = new StringBuilder();
            sql.append("UPDATE REQUEST_PAYLOAD SET SUBACCOUNTID = ? WHERE SUBACCOUNTID IS NULL");
            jdbcTemplate.update(sql.toString(), subaccountId);
        }
        returnObj.addProperty(MESSAGE, "SUCCESS");
        return returnObj;
    }

    private void initData(GTTInstance gttInstance) {//init cloneinstanceId and subaccountId


    }
}
