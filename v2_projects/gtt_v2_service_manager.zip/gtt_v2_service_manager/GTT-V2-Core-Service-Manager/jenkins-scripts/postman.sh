#!/bin/bash
set -ex

echo " run postman testing"
#just add your script here

testscript='GTT_V2_Instance_Manager_Test.postman_collection.json';
testEnvfile='jenkins-scripts/GTT_V2_Instance_Manager_Test_INT.postman_environment.json';
newman run    jenkins-scripts/${testscript} -e  ${testEnvfile} --delay-request 30000 -r cli,junit \
  --env-var "mgm_hana_user=${mgm_hana_user}" --env-var "mgm_hana_password=${mgm_hana_password}" \
  --env-var "instanceName_managed_hana=${instanceName_managed_hana}" \
  --env-var "instanceId_managed_hana=${instanceId_managed_hana}" \
  --reporter-junit-export jenkins-scripts/postman-collection.xml \
  --reporter-html-export jenkins-scripts/postman-collection-index.html  \
  --reporter-html-export target/index.html --reporter-junit-export target/surefire-reports/junit_report.xml

echo " all testing are done!"
