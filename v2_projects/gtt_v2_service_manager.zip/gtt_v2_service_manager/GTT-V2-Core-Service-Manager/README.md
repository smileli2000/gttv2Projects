# GTT-V2-Core-Manager
Service instance management application. it handle the instance actions:
* provision
* unProvision
* update
* binding
* unbinding

GTT service broker callbacks forword requests to this micro service. the parameter will be validated
and stored/updated if applicable.

## create hana secure store

cf create-service hana securestore lbn-gtt-core-securestore -c '{"database_id": "384728f1-43bd-4a82-b96b-514b5c2e3671"}'



