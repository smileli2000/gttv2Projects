/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.gtt.v2.writeservice.utils;


import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;

/**
 *
 * @author I326335
 */
public class WriteServiceJsonUtil {
	
	/*
	 * TODO: We remove the usage of jackson,
	 * Need check how to do duplicate name check in GSON
	 */
    /*public static JsonNode checkDuplicatedFields(String json) throws IOException {
    	(new GsonBuilder()).
        ObjectMapper mapper = new ObjectMapper();
        mapper.enable(com.fasterxml.jackson.core.JsonParser.Feature.STRICT_DUPLICATE_DETECTION);
        JsonNode readTree = mapper.readTree(JsonSanitizer.sanitize(json));
        return readTree;
    }*/
    
    public static JSONObject getJSONObject(String entityString) throws JSONException {
        return new JSONObject(new JSONTokener(entityString));
    }
    
    public static JsonArray getJsonArray(JsonElement jsonElement) {
        JsonArray jsonArray = new JsonArray();
        if (jsonElement.isJsonArray()) {
            jsonArray.addAll(jsonElement.getAsJsonArray());
        } else {
            jsonArray.add(jsonElement);
        }
        return jsonArray;
    }
}
