/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.gtt.v2.writeservice.swagger;

import com.google.common.collect.ImmutableList;
import org.everit.json.schema.FormatValidator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoField;
import java.util.List;
import java.util.Optional;

/**
 *
 * @author I326335
 */
public class CustomTimeStampFormatValidator implements FormatValidator {
    private static final Logger logger = LoggerFactory.getLogger(CustomTimeStampFormatValidator.class);
    
    private static final List<String> FORMATS_ACCEPTED = ImmutableList.of(
            "yyyy-MM-dd'T'HH:mm:ssZ", "yyyy-MM-dd'T'HH:mm:ss.[0-9]{1,9}Z"
    );

    private static final String PARTIAL_DATETIME_PATTERN = "yyyy-MM-dd'T'HH:mm:ss";

    private static final String ZONE_OFFSET_PATTERN = "XXX";

    private static final DateTimeFormatter FORMATTER;

    static {
        final DateTimeFormatter secondsFractionFormatter = new DateTimeFormatterBuilder()
                .appendFraction(ChronoField.NANO_OF_SECOND, 1, 9, true)
                .toFormatter();
        
        final DateTimeFormatter zoneFractionFormatter = new DateTimeFormatterBuilder()
                .appendPattern(ZONE_OFFSET_PATTERN)
                .toFormatter();

        final DateTimeFormatterBuilder builder = new DateTimeFormatterBuilder()
                .appendPattern(PARTIAL_DATETIME_PATTERN)
                .appendOptional(secondsFractionFormatter)
                .appendOptional(zoneFractionFormatter);

        FORMATTER = builder.toFormatter();
    }
    
    @Override
    public Optional<String> validate(final String subject) {
        try {
            FORMATTER.parse(subject);
            return Optional.empty();
        } catch (DateTimeParseException e) {
            logger.warn(e.getLocalizedMessage(), e);
            return Optional.of(String.format("[%s] is not a valid timestamp. Expected %s", subject, FORMATS_ACCEPTED));
        }
    }

    @Override
    public String formatName() {
        return name;
    }
    private String name = "timestamp";
    
    public void setFormatName(String name) {
        this.name = name;
    }
}
