package com.sap.gtt.v2.writeservice.service;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.sap.gtt.v2.configuration.ISAPCloudPlatformAgent.ICurrentAccessContext;
import com.sap.gtt.v2.core.domain.metadata.CurrentMetadataEntity;
import com.sap.gtt.v2.core.domain.metadata.MetadataConstants.CdsDataType;
import com.sap.gtt.v2.core.domain.metadata.MetadataConstants.CoreModelEntity;
import com.sap.gtt.v2.core.domain.metadata.MetadataEntity;
import com.sap.gtt.v2.core.domain.metadata.MetadataEntityElement;
import com.sap.gtt.v2.core.entity.trackedprocess.Event;
import com.sap.gtt.v2.core.entity.trackedprocess.PlannedEventForEvent;
import com.sap.gtt.v2.core.entity.trackedprocess.Reference;
import com.sap.gtt.v2.core.management.metadata.IMetadataManagement;
import com.sap.gtt.v2.core.runtime.model.BooleanValue;
import com.sap.gtt.v2.core.runtime.model.DateValue;
import com.sap.gtt.v2.core.runtime.model.DecimalValue;
import com.sap.gtt.v2.core.runtime.model.IPropertyValue;
import com.sap.gtt.v2.core.runtime.model.IntegerValue;
import com.sap.gtt.v2.core.runtime.model.ListValue;
import com.sap.gtt.v2.core.runtime.model.NullValue;
import com.sap.gtt.v2.core.runtime.model.ObjectValue;
import com.sap.gtt.v2.core.runtime.model.StringValue;
import com.sap.gtt.v2.core.runtime.model.TimestampValue;
import com.sap.gtt.v2.core.runtime.model.UUIDValue;
import com.sap.gtt.v2.exception.TypeMismatchException;

@Component
public class PayloadToEventService {

    @Autowired
    private ICurrentAccessContext currentContext;

    public Event parseJsonObjectToEvent(String namespace, String entityName, JsonObject jsonObject) {
        Event event = new Event();
        CurrentMetadataEntity currentMetadataEntity = getMetadataService().findAllEntitiesRecursively(namespace, entityName);
        event.setMetadata(currentMetadataEntity);
        MetadataEntity currentEntity = currentMetadataEntity.getCurrentEntity();
        List<MetadataEntityElement> elements = currentEntity.getElements();
        for (MetadataEntityElement metadataElement : elements) {
            String name = metadataElement.getName();

            if(jsonObject.has(name)){
                JsonElement jsonElement = jsonObject.get(name);
                IPropertyValue value = parseJsonElement(namespace,name,jsonElement,currentMetadataEntity);
                event.setValue(name, value);
            }
        }
        return event;
    }

    private IPropertyValue parseJsonElement(String namespace, String key, JsonElement jsonElement, CurrentMetadataEntity currentMetadataEntity) {
    	IPropertyValue result;
        MetadataEntity currentEntity = currentMetadataEntity.getCurrentEntity();
        Map<String, MetadataEntityElement> elementMap = currentEntity.getElementMap();
        if(jsonElement.isJsonNull()) return NullValue.NULL;
        
        if (jsonElement.isJsonPrimitive()) {
            CdsDataType type = elementMap.get(key).getType();
            switch (type) {
                case CDS_BOOLEAN:
                    result = jsonElement.getAsBoolean()? BooleanValue.TRUE : BooleanValue.FALSE;
                    break;
                case CDS_INTEGER:
                    result = IntegerValue.valueOf(jsonElement.getAsInt());
                    break;
                case CDS_UUID:
                    result = UUIDValue.valueOf(jsonElement.getAsString());
                    break;
                case CDS_STRING:
                    result = StringValue.valueOf(jsonElement.getAsString());
                    break;
                case CDS_DECIMAL:
                    result = DecimalValue.valueOf(jsonElement.getAsBigDecimal());
                    break;
                case CDS_DATE:
                    result = DateValue.valueOf(jsonElement.getAsString());
                    break;
                case CDS_TIMESTAMP:
                    result = TimestampValue.valueOf(jsonElement.getAsString());

                    break;
                /*case CDS_ASSOCIATION:
                    //do nothing
                    result = null;
                    break;*/
                default:
                    throw new IllegalArgumentException("Type cannot be resolved." + key + ":" + type);
            }
        } else if (jsonElement.isJsonArray()) {
            String targetEntityName = elementMap.get(key).getTarget();
            CurrentMetadataEntity targetCurrentEntity = getCurrentMetadataEntity(currentMetadataEntity, targetEntityName);
           
            JsonArray jsonArray = jsonElement.getAsJsonArray();
            ListValue listValue = ListValue.valueOfEmpty();
          //TODO  listValue.
            for (JsonElement item : jsonArray) {
            	ObjectValue objectValue = parseJsonObject(namespace, item.getAsJsonObject(), targetCurrentEntity );
            	listValue.add(objectValue);
            }
            result = listValue;
        } else if (jsonElement.isJsonObject()) {
            String targetEntityName = elementMap.get(key).getTarget();
            CurrentMetadataEntity targetCurrentEntity = getCurrentMetadataEntity(currentMetadataEntity, targetEntityName);
            ObjectValue objectValue = parseJsonObject(namespace, jsonElement.getAsJsonObject(), targetCurrentEntity);
            result = objectValue;
        } else {
            throw new TypeMismatchException("Not a json value.");
        }
        return result;
    }

    private ObjectValue parseJsonObject(String namesapce, JsonObject jsonObject, CurrentMetadataEntity currentMetadataEntity) {
    	ObjectValue result = null;
    	if(StringUtils.equals(CoreModelEntity.PLANNED_EVENT_FOR_EVENT.getFullName(), currentMetadataEntity.getCurrentEntityName())){
    		result = new PlannedEventForEvent();
    	}
    	else if(StringUtils.equals(CoreModelEntity.REFERENCE.getFullName(), currentMetadataEntity.getCurrentEntityName())){
    		result = new Reference();
    	}
    	else{
    		result = ObjectValue.valueOfEmpty();
    	}
    	result.setMetadata(currentMetadataEntity);
    	MetadataEntity metadataEntity = currentMetadataEntity.getCurrentEntity();
    	for (MetadataEntityElement metadataElement : metadataEntity.getElements()) {
            String name = metadataElement.getName();
            if(jsonObject.has(name)){
                JsonElement jsonElement = jsonObject.get(name);
                IPropertyValue value = parseJsonElement(namesapce,name,jsonElement,currentMetadataEntity);
                result.setValue(name, value);
            }
        }
    	
        return result;
    }

    private CurrentMetadataEntity getCurrentMetadataEntity(CurrentMetadataEntity currentMetadataEntity, String targetEntityName) {
        CurrentMetadataEntity targetCurrentEntity = new CurrentMetadataEntity();
        targetCurrentEntity.setCurrentEntityName(targetEntityName);
        targetCurrentEntity.setAllRelatedEntityMap(currentMetadataEntity.getAllRelatedEntityMap());
        return targetCurrentEntity;
    }

    public IMetadataManagement getMetadataService() {
        return currentContext.createBusinessOperator().getMetadataManagement();
    }
}
