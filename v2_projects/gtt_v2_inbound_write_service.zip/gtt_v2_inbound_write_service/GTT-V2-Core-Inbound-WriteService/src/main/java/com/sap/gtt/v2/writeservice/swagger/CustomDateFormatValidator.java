/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.gtt.v2.writeservice.swagger;

import com.google.common.collect.ImmutableList;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Optional;
import org.everit.json.schema.FormatValidator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author I326335
 */
public class CustomDateFormatValidator implements FormatValidator {
    
    private static final Logger logger = LoggerFactory.getLogger(CustomDateFormatValidator.class);
    
    private static final List<String> FORMATS_ACCEPTED = ImmutableList.of(
            "yyyy-MM-dd"
    );

    private static final String PARTIAL_DATETIME_PATTERN = "yyyy-MM-dd";

    private static final DateTimeFormatter FORMATTER;

    static {
        final DateTimeFormatterBuilder builder = new DateTimeFormatterBuilder()
                .appendPattern(PARTIAL_DATETIME_PATTERN);

        FORMATTER = builder.toFormatter();
    }
    
    @Override
    public Optional<String> validate(final String subject) {
        try {
            FORMATTER.parse(subject);
            return Optional.empty();
        } catch (DateTimeParseException e) {
            logger.warn(e.getLocalizedMessage(), e);
            return Optional.of(String.format("[%s] is not a valid date. Expected %s", subject, FORMATS_ACCEPTED));
        }
    }

    @Override
    public String formatName() {
        return name;
    }
    private String name = "date";
    
    public void setFormatName(String name) {
        this.name = name;
    }
}
