/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.gtt.v2.writeservice.utils;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import com.sap.gtt.v2.core.domain.metadata.MetadataSwaggerInfo;
import static com.sap.gtt.v2.writeservice.constants.WriteServiceConstants.METADATA_EVENTTYPE;
import static com.sap.gtt.v2.writeservice.constants.WriteServiceConstants.SWAGGER_ADDITIONAL_PROPERTIES;
import static com.sap.gtt.v2.writeservice.constants.WriteServiceConstants.SWAGGER_AENUM;
import static com.sap.gtt.v2.writeservice.constants.WriteServiceConstants.SWAGGER_ARRAY;
import static com.sap.gtt.v2.writeservice.constants.WriteServiceConstants.SWAGGER_COMPONENTS;
import static com.sap.gtt.v2.writeservice.constants.WriteServiceConstants.SWAGGER_INFO;
import static com.sap.gtt.v2.writeservice.constants.WriteServiceConstants.SWAGGER_ITEMS;
import static com.sap.gtt.v2.writeservice.constants.WriteServiceConstants.SWAGGER_OBJECT;
import static com.sap.gtt.v2.writeservice.constants.WriteServiceConstants.SWAGGER_OPENAPI;
import static com.sap.gtt.v2.writeservice.constants.WriteServiceConstants.SWAGGER_PATHS;
import static com.sap.gtt.v2.writeservice.constants.WriteServiceConstants.SWAGGER_PROPERTIES;
import static com.sap.gtt.v2.writeservice.constants.WriteServiceConstants.SWAGGER_REF;
import static com.sap.gtt.v2.writeservice.constants.WriteServiceConstants.SWAGGER_REF_FORMAT;
import static com.sap.gtt.v2.writeservice.constants.WriteServiceConstants.SWAGGER_REQUIRED;
import static com.sap.gtt.v2.writeservice.constants.WriteServiceConstants.SWAGGER_SCHEMAS;
import static com.sap.gtt.v2.writeservice.constants.WriteServiceConstants.SWAGGER_TYPE;

import com.sap.gtt.v2.exception.MultiExceptionContainer;
import com.sap.gtt.v2.util.JsonUtils;
import static com.sap.gtt.v2.writeservice.constants.WriteServiceConstants.EXPECTED_NULL;
import static com.sap.gtt.v2.writeservice.constants.WriteServiceConstants.SWAGGER_NULL;
import com.sap.gtt.v2.writeservice.exception.WriteServiceException;
import com.sap.gtt.v2.writeservice.swagger.CustomDateFormatValidator;
import com.sap.gtt.v2.writeservice.swagger.CustomTimeStampFormatValidator;
import java.util.stream.Collectors;

import org.apache.http.HttpStatus;
import org.everit.json.schema.Schema;
import org.everit.json.schema.ValidationException;
import org.everit.json.schema.loader.SchemaLoader;
import org.everit.json.schema.loader.internal.DefaultSchemaClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 *
 * @author I326335
 */
public class WriteServiceSwaggerUtil {
    
    public static JsonObject processSwaggerSchema(MetadataSwaggerInfo metadataSwaggerInfo, String service, String resourceName, JsonElement schema, boolean isArray) {
        JsonObject schemasObject = schema.getAsJsonObject().get(SWAGGER_COMPONENTS).getAsJsonObject().get(SWAGGER_SCHEMAS).getAsJsonObject();
        //Only if TP comes, check the partyId and trackingIdType
        //String primaryPattern = String.format(SWAGGER_PATTERN_PRIMARY_ALTKEY, 
        //        (metadataSwaggerInfo.isTrackedProcess() ? partyId.replace(HYPHEN, HYPHEN_REPLACED) : SWAGGER_PATERN_ALTKEY_SEGMENT),
        //        (metadataSwaggerInfo.isTrackedProcess() ? metadataSwaggerInfo.getApplicationObjectType().replace(HYPHEN, HYPHEN_REPLACED) : SWAGGER_PATERN_ALTKEY_SEGMENT));
        //String pattern = SWAGGER_PATTERN_ALTKEY;
        JsonArray enumJsonArray = metadataSwaggerInfo.isTrackedProcess() ? JsonUtils.generateJsonArrayFromList(metadataSwaggerInfo.getPlannedEvents()) : null;
        schemasObject.entrySet().stream().forEach(entry -> {
            JsonObject entryObject = entry.getValue().getAsJsonObject();
            entryObject.add(SWAGGER_ADDITIONAL_PROPERTIES, new JsonPrimitive(false));
//            if (entryObject.get(SWAGGER_PROPERTIES).getAsJsonObject().has(METADATA_ALTKEY)) {
//                entryObject.get(SWAGGER_PROPERTIES).getAsJsonObject().get(METADATA_ALTKEY).getAsJsonObject().addProperty(SWAGGER_PATTERN, entry.getKey().equals(resourceName) ? primaryPattern : pattern);
//            }
            if (entryObject.get(SWAGGER_PROPERTIES).getAsJsonObject().has(METADATA_EVENTTYPE)) {
                entryObject.get(SWAGGER_PROPERTIES).getAsJsonObject().get(METADATA_EVENTTYPE).getAsJsonObject().add(SWAGGER_AENUM, enumJsonArray);
            }
            //allow null field for non-required fields
            addNullForProperties(entryObject);
        });

        // copy all children to main object
        if (isArray) {
            generateObjectArraySchema(schema, resourceName);
        } else {
            JsonElement propertiesObject = schemasObject.get(resourceName);
            generateSingleObjectSchema(schema, propertiesObject);
        }

        return schema.getAsJsonObject();
    }
    
    private static void generateObjectArraySchema(JsonElement schema, String resourceName) {
        
        schema.getAsJsonObject().add(SWAGGER_TYPE, new JsonPrimitive(SWAGGER_ARRAY));
        schema.getAsJsonObject().add(SWAGGER_ADDITIONAL_PROPERTIES, new JsonPrimitive(false));
        JsonObject itemsObject = new JsonObject();
        itemsObject.addProperty(SWAGGER_REF, String.format(SWAGGER_REF_FORMAT, resourceName));
        schema.getAsJsonObject().add(SWAGGER_ITEMS, itemsObject);
        schema.getAsJsonObject().remove(SWAGGER_PATHS);
        schema.getAsJsonObject().remove(SWAGGER_INFO);
        schema.getAsJsonObject().remove(SWAGGER_OPENAPI);
    }
    
    private static void generateSingleObjectSchema(JsonElement schema, JsonElement propertiesObject) {
        
        schema.getAsJsonObject().add(SWAGGER_TYPE, new JsonPrimitive(SWAGGER_OBJECT));
        schema.getAsJsonObject().add(SWAGGER_ADDITIONAL_PROPERTIES, new JsonPrimitive(false));
        schema.getAsJsonObject().add(SWAGGER_PROPERTIES, propertiesObject.getAsJsonObject().get(SWAGGER_PROPERTIES));
        if (propertiesObject.getAsJsonObject().has(SWAGGER_REQUIRED)) {
            schema.getAsJsonObject().add(SWAGGER_REQUIRED, propertiesObject.getAsJsonObject().get(SWAGGER_REQUIRED));
        }
        schema.getAsJsonObject().remove(SWAGGER_PATHS);
        schema.getAsJsonObject().remove(SWAGGER_INFO);
        schema.getAsJsonObject().remove(SWAGGER_OPENAPI);
    }
    
    private static void addNullForProperties(JsonObject entryObject) {
        JsonArray required = entryObject.has(SWAGGER_REQUIRED) ? entryObject.get(SWAGGER_REQUIRED).getAsJsonArray() : new JsonArray();
        entryObject.get(SWAGGER_PROPERTIES).getAsJsonObject().entrySet().stream().filter(property -> !required.contains(new JsonPrimitive(property.getKey())) 
            && !property.getValue().getAsJsonObject().get(SWAGGER_TYPE).isJsonArray()).forEach(property -> {
            JsonArray withNull = new JsonArray();
            withNull.add(property.getValue().getAsJsonObject().get(SWAGGER_TYPE));
            withNull.add(new JsonPrimitive(SWAGGER_NULL));
            property.getValue().getAsJsonObject().add(SWAGGER_TYPE, withNull);
        });
    }
    
    public static void validateJsonSchema(JSONObject schemaData, JsonElement jsonElement) throws JSONException {
        CustomDateFormatValidator dateValidator = new CustomDateFormatValidator();
        dateValidator.setFormatName(SWAGGER_TYPE_DATE);
        CustomTimeStampFormatValidator timestampValidator = new CustomTimeStampFormatValidator();
        timestampValidator.setFormatName(SWAGGER_TYPE_TIMESTAMP);
        SchemaLoader loader = SchemaLoader.builder()
                .addFormatValidator(dateValidator)
                .addFormatValidator(timestampValidator)
                .schemaJson(schemaData)
                .httpClient(new DefaultSchemaClient())
                .build();
        Schema schema = loader.load().build();
        schema.validate(jsonElement.isJsonArray() ? new JSONArray(jsonElement.getAsJsonArray().toString()) 
                : new JSONObject(jsonElement.getAsJsonObject().toString())); // throws a ValidationException if this object is invalid
    }
    private static final String SWAGGER_TYPE_TIMESTAMP = "timestamp";
    private static final String SWAGGER_TYPE_DATE = "date";
    
    /*public static JsonArray buildErrorArray(ValidationException exception) {
        JsonArray errorJsonArray = new JsonArray();
        JsonObject rootErrorObject = new JsonObject();
        rootErrorObject.addProperty("errorMessage", exception.getMessage());
        errorJsonArray.add(rootErrorObject);
        exception.getCausingExceptions().stream()
                .forEach(e -> {
                    errorJsonArray.addAll(buildErrorArray(e));
                });
        return errorJsonArray;
    }*/
    
    public static void throwValidationException(ValidationException exception) {
    	
       MultiExceptionContainer finalException = new MultiExceptionContainer(HttpStatus.SC_BAD_REQUEST);
       // duplicated exception. exclude the duplicated [excepted: null] exceptions
       for(String errorMsg : exception.getAllMessages().stream().filter(msg -> !msg.contains(EXPECTED_NULL)).collect(Collectors.toList())){
    	   finalException.addException(new WriteServiceException(WriteServiceException.MESSAGE_CODE_SWAGGER_VALIDATION_ERROR, new Object[]{errorMsg}));
       }
       
       if(!finalException.getContainedExceptions().isEmpty()) throw finalException;
    }
}
