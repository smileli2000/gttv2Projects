/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.gtt.v2.writeservice.constants;

/**
 *
 * @author I326335
 */
public class WriteServiceConstants {
    public static final String METADATA_ALTKEY = "altKey";
    public static final String METADATA_EVENTTYPE = "eventType";
    
    
    public static final String SWAGGER_AENUM = "enum";
    public static final String SWAGGER_PATTERN = "pattern";
    public static final String SWAGGER_OPENAPI = "openapi";
    public static final String SWAGGER_INFO = "info";
    public static final String SWAGGER_PATHS = "paths";
    public static final String SWAGGER_OBJECT = "object";
    public static final String SWAGGER_ARRAY = "array";
    public static final String SWAGGER_TYPE = "type";
    public static final String SWAGGER_TYPE_STRING = "string";
    public static final String SWAGGER_NULL = "null";
    public static final String SWAGGER_PROPERTIES = "properties";
    public static final String SWAGGER_ADDITIONAL_PROPERTIES = "additionalProperties";
    public static final String SWAGGER_SCHEMAS = "schemas";
    public static final String SWAGGER_COMPONENTS = "components";
    public static final String SWAGGER_ITEMS = "items";
    public static final String SWAGGER_REF = "$ref";
    public static final String SWAGGER_REF_FORMAT = "#/components/schemas/%s";
    public static final String SWAGGER_REQUIRED = "required";
    
    public static final String SWAGGER_PATTERN_NOT_EMPTY = "^(?!\\s*$).+";
    public static final String SWAGGER_PATTERN_ALTKEY = "^(?i)([^:]+):([^:]+):([^:]+):([^:]+):([^:]+):([^:]+)$";
    public static final String SWAGGER_PATTERN_PRIMARY_ALTKEY = "^(?i)([^:]+):([^:]+):%s:([^:]+):%s:([^:]+)$";
    public static final String SWAGGER_PATERN_ALTKEY_SEGMENT = "([^:]+)";
    
    public static final String KEY_ALTERNATIVE_ID_DELIMITER = ":";
    
    public static final String HYPHEN = "-";
    public static final String HYPHEN_REPLACED = "\\-";
    
    public static final String EXPECTED_NULL = "expected: null";
}
