/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.gtt.v2.writeservice.exception;

import org.apache.http.HttpStatus;

import com.sap.gtt.v2.exception.BaseRuntimeException;

/**
 *
 * @author I326335
 */
public class WriteServiceException extends BaseRuntimeException {

    public static final String MESSAGE_CODE_BAD_URL = WriteServiceException.class.getName() + ".BadUrl";
    public static final String MESSAGE_CODE_SWAGGER_NOT_FOUND = WriteServiceException.class.getName() + ".SwaggerNotFound";
    public static final String MESSAGE_CODE_SWAGGER_VALIDATION_ERROR = WriteServiceException.class.getName() + ".SwaggerValidationError";
    public static final String MESSAGE_CODE_SERVICE_NOT_FOUND = WriteServiceException.class.getName() + ".ServiceNotFound";

    public WriteServiceException(String messageCode) {
        this(messageCode, null);
    }

    public WriteServiceException(String messageCode, Object[] localizedMsgParams) {
        super(messageCode, localizedMsgParams);
    }

    /**
     *
     */
    private static final long serialVersionUID = -2125617623695612155L;

    @Override
    public int getHttpStatus() {
        return HttpStatus.SC_BAD_REQUEST;
    }

}
