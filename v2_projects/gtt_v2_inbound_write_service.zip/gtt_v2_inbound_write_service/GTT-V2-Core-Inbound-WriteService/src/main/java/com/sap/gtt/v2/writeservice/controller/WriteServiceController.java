/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.gtt.v2.writeservice.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.everit.json.schema.ValidationException;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.sap.gtt.v2.configuration.ISAPCloudPlatformAgent;
import com.sap.gtt.v2.core.domain.metadata.MetadataSwaggerInfo;
import com.sap.gtt.v2.core.entity.trackedprocess.Event;
import com.sap.gtt.v2.core.management.metadata.CsnParser;
import com.sap.gtt.v2.core.management.metadata.IMetadataManagement;
import com.sap.gtt.v2.core.service.MessageProcessingService;
import com.sap.gtt.v2.exception.InternalErrorException;
import com.sap.gtt.v2.util.JsonUtils;
import com.sap.gtt.v2.writeservice.service.PayloadToEventService;
import com.sap.gtt.v2.writeservice.utils.WriteServiceJsonUtil;
import com.sap.gtt.v2.writeservice.utils.WriteServiceSwaggerUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author I326335
 */
@RestController
@RequestMapping(WriteServiceController.ROOT_URL)
public class WriteServiceController {
	private static final Logger logger = LoggerFactory.getLogger(WriteServiceController.class);
	public static final String ROOT_URL = "/sap/logistics/gtt/inbound/rest/v1";
    @Autowired
    private PayloadToEventService payloadToEventService;
    @Autowired
    private MessageProcessingService messageProcessingService;
    @Autowired
    private ISAPCloudPlatformAgent.ICurrentAccessContext currentAccessContext;

    @PostMapping(path = "/{service:.+}/{name:.+}")
    public ResponseEntity<String> receive(@Valid @RequestBody String inputDataJson,
            @PathVariable String service, @PathVariable String name) {
        /* JsonNode checkedResult = null;
        try {
            checkedResult = WriteServiceJsonUtil.checkDuplicatedFields(objectListJson);
        } catch (IOException ex) {
            return new ResponseEntity<>(ex.getMessage(), headers, HttpStatus.BAD_REQUEST);
        }*/
        
        MetadataSwaggerInfo metadataSwaggerInfo = getMetadataManagement().getMetadataSwaggerInfo(service, name);
        JsonObject swaggerSchema = metadataSwaggerInfo.getSwaggerObj();

        JsonElement inputData = JsonUtils.generateJsonElementFromString(inputDataJson);
        swaggerSchema = WriteServiceSwaggerUtil.processSwaggerSchema(metadataSwaggerInfo, service, name, swaggerSchema, inputData.isJsonArray());
        try {
            JSONObject schemaData = WriteServiceJsonUtil.getJSONObject(swaggerSchema.getAsJsonObject().toString());
            logger.debug(schemaData.toString());
            WriteServiceSwaggerUtil.validateJsonSchema(schemaData, inputData);
        } catch (ValidationException ex) {
            WriteServiceSwaggerUtil.throwValidationException(ex);
        } catch (JSONException ex) {
            throw new InternalErrorException(ex.getMessage(), ex);
        }

        JsonArray jsonArray = WriteServiceJsonUtil.getJsonArray(inputData);
        return receiveEventMessage(jsonArray, metadataSwaggerInfo);
    }

    private ResponseEntity<String> receiveEventMessage(JsonElement jsonElement,
            MetadataSwaggerInfo metadataSwaggerInfo) {
    	//metadataService.setTenant(secureEntityFactory.getSecureTenant());
        //JsonElement hciObject = gson.toJsonTree(jsonElement.getAsJsonArray().toString());
        JsonArray eventMessageArray = jsonElement.getAsJsonArray();
        List<Event> messageList = new ArrayList<>();

        for (JsonElement eventMessage : eventMessageArray) {
            if (eventMessage.isJsonObject()) {
                processEventMessage(metadataSwaggerInfo.getTrackedProcessType(), metadataSwaggerInfo.getEventType(), eventMessage.getAsJsonObject(), messageList);
            }
        }

        messageProcessingService.processEvents(messageList);

        return new ResponseEntity<>(HttpStatus.OK);
    }

    private void processEventMessage(String trackedProcessType, String eventType, JsonObject eventMessage, List<Event> messageList) {
        List<Event> events = setEventMessage(trackedProcessType, eventType, eventMessage);
        if (!events.isEmpty()) {
            messageList.addAll(events);
        }
    }

    private List<Event> setEventMessage(String trackedProcessType, String eventType, JsonObject eventMessageJson) {

        List<Event> events = new ArrayList<>();
        Event eventMessage = setEvent(trackedProcessType, eventType, eventMessageJson);

        //eventMessage.setSenderPartyId(UUID.fromString(businessPartner.getId()));

        events.add(eventMessage);
        return events;
    }
    
    private Event setEvent(String trackedProcessType, String eventType, JsonObject singleProcessJson){

        String namespace = CsnParser.getProjectNamespace(trackedProcessType);
        Event event = payloadToEventService.parseJsonObjectToEvent(namespace,eventType,singleProcessJson);
        event.setEventType(eventType);
        return event;
    }
    
    private IMetadataManagement getMetadataManagement() {
        return currentAccessContext.createBusinessOperator().getMetadataManagement();
    }
}
