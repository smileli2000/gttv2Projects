/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.gtt.v2.writeservice.controller;

import com.sap.gtt.v2.configuration.ISAPCloudPlatformAgent;
import com.sap.gtt.v2.core.dao.metadata.IMetadataDao;
import com.sap.gtt.v2.core.entity.metadata.MetadataProjectFile;
import com.sap.gtt.v2.core.management.metadata.DefaultMetadataManagement;
import com.sap.gtt.v2.core.management.metadata.IMetadataManagement;
import com.sap.gtt.v2.core.service.MessageProcessingService;
import com.sap.gtt.v2.exception.MetadataException;
import com.sap.gtt.v2.exception.MultiExceptionContainer;
import com.sap.gtt.v2.log.TenantAwareLogService;
import com.sap.gtt.v2.util.GTTUtils;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

import com.sap.gtt.v2.writeservice.service.PayloadToEventService;
import org.apache.commons.io.IOUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.BDDMockito.given;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

/**
 *
 * @author I326335
 */
@RunWith(MockitoJUnitRunner.class)
public class WriteServiceControllerTest {

    @Spy
    private PayloadToEventService payloadToEventService;
    @Mock
    private MessageProcessingService messageProcessingService;
    @Mock
    private ISAPCloudPlatformAgent.ICurrentAccessContext currentAccessContext;
    @Mock
    private IMetadataManagement metadataRepository;
    @Mock
    private TenantAwareLogService tenantAwareLogService;
    @Mock
    private IMetadataDao metadataDao;
    @InjectMocks
    private WriteServiceController controller;
    
    class CustomMetadataManagement extends DefaultMetadataManagement {

        @Override
        public IMetadataDao getMetadataDao() {
            return mock(IMetadataDao.class);
        }
    }

    public WriteServiceControllerTest() {
    }

    @Before
    public void setup() throws IOException, NoSuchFieldException {

        String csn = readFile("com.sap.gtt.app.mim.MIMService_derived_csn.json");
        
        GTTUtils.BusinessOperator businessOperator = mock(GTTUtils.BusinessOperator.class);
        CustomMetadataManagement metadataManagement = spy(new CustomMetadataManagement());
        given(metadataManagement.getMetadataDao()).willReturn(metadataDao);
        given(metadataDao.getMetadataDerivedCsn(any())).willReturn(csn);
        
        given(businessOperator.getMetadataManagement()).willReturn(metadataManagement);
        given(currentAccessContext.createBusinessOperator()).willReturn(businessOperator);
        
        ReflectionTestUtils.setField(payloadToEventService, "currentContext", currentAccessContext);
        
    }

    @Test
    public void testReceiveTrackedProcess() throws IOException {

        String swagger = readFile("com.sap.gtt.app.mim.MIMWriteService_swagger.json");
        String csn = readFile("com.sap.gtt.app.mim.MIMService_derived_csn.json");
        
        MetadataProjectFile metadataProjectFile = new MetadataProjectFile();
        metadataProjectFile.setDerivedCsn(csn);
        metadataProjectFile.setSwagger(swagger);
        given(metadataDao.getMetadataSwaggerDerivedCsnInfo(anyString())).willReturn(metadataProjectFile);
        
        String inputTpJson = readFile("ValidProcurementOrderItemEvent.json");
        
        ResponseEntity<String> response = controller.receive(inputTpJson, "com.sap.gtt.app.mim.MIMWriteService", "ProcurementOrderItemEvent");

        Assert.assertEquals(HttpStatus.OK, response.getStatusCode());
    }
    
    @Test
    public void testReceiveTrackedProcessWithNullValue() throws IOException {

        String swagger = readFile("com.sap.gtt.app.mim.MIMWriteService_swagger.json");
        String csn = readFile("com.sap.gtt.app.mim.MIMService_derived_csn.json");
        
        MetadataProjectFile metadataProjectFile = new MetadataProjectFile();
        metadataProjectFile.setDerivedCsn(csn);
        metadataProjectFile.setSwagger(swagger);
        given(metadataDao.getMetadataSwaggerDerivedCsnInfo(anyString())).willReturn(metadataProjectFile);
        
        String inputTpJson = readFile("ValidProcurementOrderItemEvent1.json");
        
        ResponseEntity<String> response = controller.receive(inputTpJson, "com.sap.gtt.app.mim.MIMWriteService", "ProcurementOrderItemEvent");

        Assert.assertEquals(HttpStatus.OK, response.getStatusCode());
    }
    
    @Test(expected = MultiExceptionContainer.class)
    public void testReceiveTrackedProcessWithMandatoryNullValue() throws IOException {

        String swagger = readFile("com.sap.gtt.app.mim.MIMWriteService_swagger.json");
        String csn = readFile("com.sap.gtt.app.mim.MIMService_derived_csn.json");
        
        MetadataProjectFile metadataProjectFile = new MetadataProjectFile();
        metadataProjectFile.setDerivedCsn(csn);
        metadataProjectFile.setSwagger(swagger);
        given(metadataDao.getMetadataSwaggerDerivedCsnInfo(anyString())).willReturn(metadataProjectFile);
        
        String inputTpJson = readFile("ValidProcurementOrderItemEvent2.json");
        
        ResponseEntity<String> response = controller.receive(inputTpJson, "com.sap.gtt.app.mim.MIMWriteService", "ProcurementOrderItemEvent");

        Assert.assertEquals(HttpStatus.OK, response.getStatusCode());
    }
    
    /*@Test(expected = MultiExceptionContainer.class)
    public void testReceiveTrackedProcessWithMandatoryEmptyValue() throws IOException {

        String swagger = readFile("com.sap.gtt.app.mim.MIMWriteService_swagger.json");
        String csn = readFile("com.sap.gtt.app.mim.MIMService_derived_csn.json");
        
        MetadataProjectFile metadataProjectFile = new MetadataProjectFile();
        metadataProjectFile.setDerivedCsn(csn);
        metadataProjectFile.setSwagger(swagger);
        given(metadataDao.getMetadataSwaggerDerivedCsnInfo(anyString())).willReturn(metadataProjectFile);
        
        String inputTpJson = readFile("ValidProcurementOrderItemEvent3.json");
        
        ResponseEntity<String> response = controller.receive(inputTpJson, "com.sap.gtt.app.mim.MIMWriteService", "ProcurementOrderItemEvent");

        Assert.assertEquals(HttpStatus.OK, response.getStatusCode());
    }
    
    @Test(expected = MultiExceptionContainer.class)
    public void testReceiveTrackedProcessWithMandatorySpaceValue() throws IOException {

        String swagger = readFile("com.sap.gtt.app.mim.MIMWriteService_swagger.json");
        String csn = readFile("com.sap.gtt.app.mim.MIMService_derived_csn.json");
        
        MetadataProjectFile metadataProjectFile = new MetadataProjectFile();
        metadataProjectFile.setDerivedCsn(csn);
        metadataProjectFile.setSwagger(swagger);
        given(metadataDao.getMetadataSwaggerDerivedCsnInfo(anyString())).willReturn(metadataProjectFile);
        
        String inputTpJson = readFile("ValidProcurementOrderItemEvent4.json");
        
        ResponseEntity<String> response = controller.receive(inputTpJson, "com.sap.gtt.app.mim.MIMWriteService", "ProcurementOrderItemEvent");

        Assert.assertEquals(HttpStatus.OK, response.getStatusCode());
    }*/

    @Test(expected = MetadataException.class)
    public void testReceiveTrackedProcessWithInvalidNamespace() throws IOException {
        String inputTpJson = readFile("ValidProcurementOrderItemEvent.json");
        controller.receive(inputTpJson, "MIMWriteService", "ProcurementOrderItemEvent");
    }
    
    @Test(expected = MetadataException.class)
    public void testReceiveTrackedProcessWithoutSwagger() throws IOException {
        String csn = readFile("com.sap.gtt.app.mim.MIMService_derived_csn.json");
        
        MetadataProjectFile metadataProjectFile = new MetadataProjectFile();
        metadataProjectFile.setDerivedCsn(csn);
        metadataProjectFile.setSwagger(null);
        given(metadataDao.getMetadataSwaggerDerivedCsnInfo(anyString())).willReturn(metadataProjectFile);
        
        String inputTpJson = readFile("ValidProcurementOrderItemEvent.json");

        controller.receive(inputTpJson, "com.sap.gtt.app.mim.MIMWriteService", "ProcurementOrderItemEvent");
    }
    
    @Test(expected = MetadataException.class)
    public void testReceiveTrackedProcessWithInvalidEntityName() throws IOException {
        String swagger = readFile("com.sap.gtt.app.mim.MIMWriteService_swagger.json");
        String csn = readFile("com.sap.gtt.app.mim.MIMService_derived_csn.json");
        
        MetadataProjectFile metadataProjectFile = new MetadataProjectFile();
        metadataProjectFile.setDerivedCsn(csn);
        metadataProjectFile.setSwagger(swagger);
        given(metadataDao.getMetadataSwaggerDerivedCsnInfo(anyString())).willReturn(metadataProjectFile);
        
        String inputTpJson = readFile("ValidProcurementOrderItemEvent.json");

        controller.receive(inputTpJson, "com.sap.gtt.app.mim.MIMWriteService1", "ProcurementOrderItemEvent");
    }
    
    @Test(expected = MultiExceptionContainer.class)
    public void testReceiveTrackedProcessWithInvalidPlannedEvent() throws IOException {
        String swagger = readFile("com.sap.gtt.app.mim.MIMWriteService_swagger.json");
        String csn = readFile("com.sap.gtt.app.mim.MIMService_derived_csn.json");
        
        MetadataProjectFile metadataProjectFile = new MetadataProjectFile();
        metadataProjectFile.setDerivedCsn(csn);
        metadataProjectFile.setSwagger(swagger);
        given(metadataDao.getMetadataSwaggerDerivedCsnInfo(anyString())).willReturn(metadataProjectFile);
        
        
        String inputTpJson = readFile("InvalidProcurementOrderItemEvent.json");

        controller.receive(inputTpJson, "com.sap.gtt.app.mim.MIMWriteService", "ProcurementOrderItemEvent");
    }

    @Test
    public void testReceiveEvent() throws IOException {
        String swagger = readFile("com.sap.gtt.app.mim.MIMWriteService_swagger.json");
        String csn = readFile("com.sap.gtt.app.mim.MIMService_derived_csn.json");
        
        MetadataProjectFile metadataProjectFile = new MetadataProjectFile();
        metadataProjectFile.setDerivedCsn(csn);
        metadataProjectFile.setSwagger(swagger);
        given(metadataDao.getMetadataSwaggerDerivedCsnInfo(anyString())).willReturn(metadataProjectFile);
        
        String inputEventJson = readFile("ValidPOConfirmedEvent.json");

        ResponseEntity<String> response = controller.receive(inputEventJson, "com.sap.gtt.app.mim.MIMWriteService", "POConfirmedEvent");

        Assert.assertEquals(HttpStatus.OK, response.getStatusCode());
    }

    private String readFile(String file) throws IOException {
        return IOUtils.toString(WriteServiceControllerTest.class.getClassLoader().getResourceAsStream(file), StandardCharsets.UTF_8);
    }

}
