const express = require('express');
const bodyParser = require('body-parser');
const passport = require('passport');
const JWTStrategy = require('@sap/xssec').JWTStrategy;
const xsenv = require('@sap/xsenv');
const app = express();
const scope = JSON.parse(process.env.VCAP_SERVICES).xsuaa[0].credentials.xsappname + '.DeployUser.c';
const compile = require('./routes/compile.controller');
const validator = require('./routes/validateRequest').validator;
const compression = require('compression');

app.set('port', process.env.PORT || 8888);
app.use(compression());
app.use(bodyParser.urlencoded({
  limit: '50mb',
  extended: true,
}));
app.use(bodyParser.json({
  limit: '5mb'
}));
app.use(bodyParser.text());

app.use((error, req, res, next) => {
  if (error) {
    return res.status(400).json({
      message: error.message,
      status: 400,
      stack: error.stack
    });
  }
  next();
});

passport.use(new JWTStrategy(xsenv.getServices({
  uaa: {
    tag: 'xsuaa'
  }
}).uaa));
app.use(passport.initialize());
app.use(passport.authenticate('JWT', {
  session: false
}));

app.use((req, res, next) => {
  if (!req.authInfo.checkScope(scope)) {
    return res.status(403).json({
      status: 'error',
      message: 'user has not required permissions'
    });
  }
  next();
});

app.use(validator);
app.post('/compile', compile);


app.listen(app.get('port'), () => {
  console.log(`express server listening on port ${app.get('port')} ...`);
});