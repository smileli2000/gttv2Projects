const fs = require('fs-extra');
const path = require('path');
const chai = require('chai');
const httpMocks = require('node-mocks-http');
const cdsv = require('../lib/build');
const helper = require('../lib/testHelper')
const expect = chai.expect;
const cwd = path.join(__dirname, '..');
const paths = {
  src: 'testcase/mim',
  output: 'out',
  base: 'testcase/core',
  files: {
    csn: path.join(cwd, 'testcase/target/csn.json'),
    metadata: path.join(cwd, 'testcase/target/metadata.xml'),
    annotations: path.join(cwd, 'testcase/target/annotations.xml'),
    swagger: path.join(cwd, 'testcase/target/swagger.json'),
  }

};
const compiler = require('@sap/cds-compiler');

const compile = (req, res) => {
  return cdsv.compile(req.body, true).then(results => {
    res.setHeader('Content-Type', 'application/json');
    res.statusCode = 200;
    res.send(results, 'utf8');
    res.end();
    return res;
  });
};


const testPost = (body) => {
  const request = httpMocks.createRequest({
    method: 'POST',
    url: '/compile',
    body: body
  });

  const response = httpMocks.createResponse();
    return compile(request, response).then(res => res._getData());
};


// generate hashes
const hashPromise = Promise.all(Object.keys(paths.files).map((key) => {
  const filepath = paths.files[key];
  return helper.hashFile(filepath).then(hash => [key, hash]);
}));



describe('CDS Compiler Unit Test', function () {
  this.timeout(10000);
  before((done) => {
    fs.ensureDir(path.join(cwd, paths.output), done);
  });

  it('Test MIM Model', () => {
    // Act
    const compilePromise = helper.load(paths.src, paths.base).then(testPost);

    // Assert
    return Promise.all([compilePromise, hashPromise]).then(([results, hashes]) => {
      // save results
      helper.store(results, paths.output);

      // compare results
      const hashMap = new Map(hashes);
      Object.keys(results).forEach((key) => {
        if (key !== 'services' && key !== 'alerts' && key !== 'messages' && key !== '_augmentedCsn') {
          let value = results[key];
          if (typeof value === 'object') {
            value = JSON.stringify(value, null, '\t')
          }
          const hash = helper.hashString(value);
          expect(hash).to.be.equal(hashMap.get(key), `${key} file content should not be changed`);
        }
      });
    });
  });

  it('Test compile CompilationError 1', () => {
    // Act
    const compilePromise = helper.load('testcase/cds1', paths.base).then(testPost);

    // Assert
    return compilePromise.catch(result => {
      expect(result).to.be.instanceOf(compiler.CompilationError);
    });
  });

  it('Test compile CompilationError 2', () => {
    // Act
    const compilePromise = helper.load('testcase/cds2', paths.base).then(testPost);

    // Assert
    return compilePromise.catch(result => {
      expect(result).to.be.instanceOf(compiler.CompilationError);
    });
  });
});

