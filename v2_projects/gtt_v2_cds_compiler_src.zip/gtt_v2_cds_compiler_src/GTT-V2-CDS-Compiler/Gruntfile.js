"use strict";
module.exports = function(grunt) {
	var branch = grunt.option('branch');
	
    grunt.initConfig({
	    pkg: grunt.file.readJSON("package.json"),
	    sonarRunner: {
	        analysis: {
	            options: {
	                debug: true,
	                sonar: {
	                    host: {
	                       url: 'http://sonarci.wdf.sap.corp:8080/sonar'
	                    },
	                    projectKey: "gtt-cdm-parser:"+branch,
	                    projectName: "GTT-CDSParser "+branch,
	                    sources: "lib/,UT-test/",
	                    exclusions: "",
	                    javascript: {
	                        lcov: {
	                            reportPaths: "coverage/lcov.info"
	                        }
	                    },
	                    coverage: {
	                        exclusions: ""
	                    },
	                    language: "js",
	                    sourceEncoding: "UTF-8"
	                }
	            }
	        }
	    }
    });

   grunt.loadNpmTasks("grunt-sonar-runner");
   grunt.registerTask("default", ["sonarRunner:analysis"]);
}
