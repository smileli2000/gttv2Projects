const express = require('express');
let router = express.Router();
const cdsv = require('../lib/build');
const compilerVersion = require('../package.json').dependencies['@sap/cds-compiler'];

module.exports = router;

router.post('/compile', (req, res) => {

  let flag = false;
  let reqBody = req.body;
  Object.keys(reqBody).forEach(value => {
/*     if (value.endsWith('Service.cds') && !value.endsWith('WriteService.cds')) {
      if (!reqBody[value].includes('AllTrackedProcess')) {
        let index = reqBody[value].lastIndexOf('};');
        reqBody[value] = reqBody[value].slice(0, index) + '\nentity AllTrackedProcess as projection on CoreModel.AllTrackedProcess;\n};';
      }
    } */
    if (value.endsWith('WriteService.cds')) {
      flag = true;
    }
  });
  cdsv.compile(reqBody, flag)
    .then(results => {
/*      let swagger = results.swagger;
       if (swagger && swagger.hasOwnProperty('title') && Object.keys(swagger).length !== 0) {
        swagger = cdsv.modSwagger(swagger);
      } */
      res.send(Object.assign({}, {
        swagger: results.swagger,
        csn: results.csn,
        services: results.services,
        compiler_version: compilerVersion
      }));
    }).catch(error => {
      let err = cdsv.displayMessages(error);
      if (err instanceof Error) {
        console.log(err);
        res.status(500).send({
          "error": ['Internal ' + err.toString()]
        });
      } else {
        res.status(400).send({
          "error": err
        });
      }
    });
});