module.exports = {};
const validator = module.exports = {};

const validateReq = (reqestPlayload) => {
  let promise = new Promise((resolve, reject) => {
    let msg = [];
    if(typeof reqestPlayload !== 'object') {
      let error = `Request body is invalid.`
      msg.push(error);
      reject(msg);
    }
    Object.keys(reqestPlayload).forEach((key) => {
      // add validation conditions here
      if (typeof reqestPlayload[key] !== 'string') {
        let error = `Content of file ${key} is invalid.`
        msg.push(error)
      }
    })
    if (msg.length === 0) {
      resolve(reqestPlayload)
    } else {
      reject(msg)
    }
  })
  return promise
}

validator.validator = (req, res, next) =>{
  validateReq(req.body).then(body => next())
 .catch(err => {
   if (err instanceof Error) {
     res.status(500).send({
       "error": ['Internal ' + err.toString()]
     })
   } else {
     res.status(400).send({
       "error": err
     })
   }
 });
}