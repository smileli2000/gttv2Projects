const expect = require('chai').expect;
const request = require('request').defaults({
  'https_proxy': 'http://proxy.wdf.sap.corp:8080'
});
const helper = require('../lib/testHelper')
const path = require('path');
const cwd = path.join(__dirname, '..');
const paths = {
  src: 'testcase/mim',
  output: 'out',
  base: 'testcase/core',
  files: {
    csn: path.join(cwd, 'testcase/target/csn.json'),
    metadata: path.join(cwd, 'testcase/target/metadata.xml'),
    annotations: path.join(cwd, 'testcase/target/annotations.xml'),
    swagger: path.join(cwd, 'testcase/target/swagger.json'),
  }
};


var reqBody = {
  "uaaURL": "https://gtt-newdevsandbox.authentication.sap.hana.ondemand.com",
  "username": "8888888ATsap.com",
  "samlAttributes": {
    "Groups": ["TT_SOLUTION_ADMINS"]
  },
  "clientID": "",
  "clientSecret": "",
}

const authInfo = {
  'origin/master': {
    URL: 'https://TT-CDMParser-integration.cfapps.sap.hana.ondemand.com',
    clientid: 'sb-tt_integration!t3071',
    clientsecret: 'TCjBs5dcQpr7H5vKEhrAoB/OZTg=',
  },
  'origin/hotfix': {
    URL: 'https://TT-CDMParser-integrationhotfix.cfapps.sap.hana.ondemand.com',
    clientid: 'sb-tt_integrationhotfix!t3071',
    clientsecret: 'FGPg2+KmN0OdciGjLdw4NYmC6v4='
  }
}
const gitBranch = process.env.GIT_BRANCH;

reqBody.clientID = authInfo[gitBranch].clientid;
reqBody.clientSecret = authInfo[gitBranch].clientsecret;
var url = authInfo[gitBranch].URL + '/compile';
var token = '';

const hashPromise = Promise.all(Object.keys(paths.files).map((key) => {
  const filepath = paths.files[key];
  return helper.hashFile(filepath).then(hash => [key, hash]);
}));


describe('CDS Compiler Integration Test', function () {
  this.timeout(60000);
  before(function (done) {
    request({
      method: 'POST',
      uri: 'https://xsuaa-monitoring-idp.cfapps.sap.hana.ondemand.com/gettoken',
      body: reqBody,
      json: true
    }, (err, res, bd) => {
      if (!err) {
        //console.log(bd)
        token = bd.token.access_token
        done()
      }
    })
  });

  it('Integration Test MIM Model', (done) => {
    let wset = {}
    helper.load(paths.src, paths.base).then(ws => {
      wset = ws;
      request({
        method: 'POST',
        uri: url,
        headers: {
          'Authorization': 'Bearer ' + token
        },
        body: wset,
        json: true
      }, function (error, response, body) {
        //console.log(body)
        if (!error) {
          return hashPromise.then((hashes) => {
            const hashMap = new Map(hashes);
            Object.keys(body).forEach((key) => {
              if (key !== 'compilerVersion' && 　key !== 'services' && key !== 'alerts') {
                let value = body[key];
                if (typeof value === 'object') {
                  value = JSON.stringify(value, null, '\t')
                }
                const hash = helper.hashString(value);
                expect(hash).to.be.equal(hashMap.get(key), `${key} file content should not be changed`);
              }
            })
            done()
          }).catch(console.log)
        } else {
          console.log(error);
          return false;
        }
      })

    })
  });

  it('Integration Test Compile CompilationError 1', (done) => {
    let wset = {}
    helper.load('testcase/cds1', paths.base).then(ws => {
      wset = ws;
      request({
        method: 'POST',
        uri: url,
        headers: {
          'Authorization': 'Bearer ' + token
        },
        body: wset,
        json: true
      }, function (error, response, body) {
        //console.log(error)
        if (!error) {
          expect(body).to.have.property('error');
          done()
        } else {
          console.log(error);
          return false;
        }
      })
    })
  });

  it('Integration Test Compile CompilationError 2', (done) => {
    let wset = {}
    helper.load('testcase/cds2', paths.base).then(ws => {
      wset = ws;
      request({
        method: 'POST',
        uri: url,
        headers: {
          'Authorization': 'Bearer ' + token
        },
        body: wset,
        json: true
      }, function (error, response, body) {
        //console.log(body)
        if (!error) {
          //console.log(error);
          expect(body).to.have.property('error');
          done()
        } else {
          console.log(error)
          return false;
        }
      })
    });
  });
});
