package com.sap.gtt.v2.integration.idoc.domain.idoc;

/**
 * @author i311486
 */
public class E1evmref02 {
    private String appobjid;
    private String appsys;
    private String appobjtype;
    private String start;
    private String startDate;
    private String endDate;
    private String timzon;
    private String action;


    public String getAppobjid() {
        return appobjid;
    }

    public void setAppobjid(String appobjid) {
        this.appobjid = appobjid;
    }

    public String getAppsys() {
        return appsys;
    }

    public void setAppsys(String appsys) {
        this.appsys = appsys;
    }

    public String getAppobjtype() {
        return appobjtype;
    }

    public void setAppobjtype(String appobjtype) {
        this.appobjtype = appobjtype;
    }

    public String getStart() {
        return start;
    }

    public void setStart(String start) {
        this.start = start;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getTimzon() {
        return timzon;
    }

    public void setTimzon(String timzon) {
        this.timzon = timzon;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

}
