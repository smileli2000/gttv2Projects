
package com.sap.gtt.v2.integration.idoc.domain.idoc;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author i311486
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class E1evmlid {

    private String loccod;
    private String locid1;

    public void setLoccod(String loccod) {
         this.loccod = loccod;
     }
     public String getLoccod() {
         return loccod;
     }

    public void setLocid1(String locid1) {
         this.locid1 = locid1;
     }
     public String getLocid1() {
         return locid1;
     }

}