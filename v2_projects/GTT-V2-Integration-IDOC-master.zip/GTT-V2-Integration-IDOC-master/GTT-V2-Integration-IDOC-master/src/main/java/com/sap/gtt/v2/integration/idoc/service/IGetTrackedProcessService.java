package com.sap.gtt.v2.integration.idoc.service;

import com.sap.gtt.v2.core.entity.metadata.MetadataProcess;

import java.util.List;


/**
 * @author i311486
 */
public interface IGetTrackedProcessService {
    /**
     * getTrackedProcessFromAOT
     * @param applicationObjectType
     * @return
     */
    public List<MetadataProcess> getTrackedProcessFromAOT(String applicationObjectType);

    /**
     * getTrackedProcessFromTrackingIdType
     * @param trackingIdType
     * @return
     */
    public List<MetadataProcess> getTrackedProcessFromTrackingIdType(String trackingIdType);
}
