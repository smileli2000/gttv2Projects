package com.sap.gtt.v2.integration.idoc.controller;

import com.sap.gtt.v2.exception.BaseRuntimeException;
import com.sap.gtt.v2.integration.idoc.utils.Utils;

import com.sap.gtt.v2.log.TenantAwareLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

/**
 * @author i311486
 */
@ControllerAdvice
public class RestResponseEntityExceptionHandler extends ResponseEntityExceptionHandler {
    @Autowired
    private TenantAwareLogService logService;

    @ExceptionHandler(Exception.class)
    public ResponseEntity<String> handleException(BaseRuntimeException e) {
        logService.error(e.getMessageCode());
        logService.error(e.getMessage());
        String soapMsg = Utils.createSoapMessageError(e.getMessageCode(),e.getMessage());
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_XML);
        return new ResponseEntity<>(soapMsg, headers, HttpStatus.INTERNAL_SERVER_ERROR);
    }

}
