package com.sap.gtt.v2.integration.idoc.domain.idoc;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

/**
 * @author i311486
 */
public class SoapEnvBodyTP {

    @JacksonXmlProperty(localName = "ehpost01")
    private Ehpost01 ehpost01;

    public void setEhpost01(Ehpost01 ehpost01) {
        this.ehpost01 = ehpost01;
    }

    public Ehpost01 getEhpost01() {
        return ehpost01;
    }

}