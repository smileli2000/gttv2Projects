package com.sap.gtt.v2.integration.idoc.domain.idoc;


import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

/**
 * @author i311486
 */
public class Evmsta02 {

    @JacksonXmlProperty(localName = "idoc")
    private EventIDoc idoc;

    public void setIdoc(EventIDoc idoc) {
        this.idoc = idoc;
    }

    public EventIDoc getIdoc() {
        return idoc;
    }

}