package com.sap.gtt.v2.integration.idoc.service.impl;

import com.sap.gtt.v2.configuration.ISAPCloudPlatformAgent;
import com.sap.gtt.v2.core.domain.metadata.MetadataCriteria;
import com.sap.gtt.v2.core.entity.metadata.MetadataProcess;
import com.sap.gtt.v2.core.management.metadata.IMetadataManagement;
import com.sap.gtt.v2.integration.idoc.service.IGetTrackedProcessService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author i311486
 */
@Service
public class GetTrackedProcessServiceImpl implements IGetTrackedProcessService {
    @Autowired
    ISAPCloudPlatformAgent.ICurrentAccessContext currentAccessContext;

    IMetadataManagement getMetadataManagement() {
        return currentAccessContext.createBusinessOperator().getMetadataManagement();
    }

    @Override
    public List<MetadataProcess> getTrackedProcessFromAOT(String applicationObjectType) {
        MetadataCriteria metadataCriteria = new MetadataCriteria();
        metadataCriteria.setApplicationObjectType(applicationObjectType);
        return getMetadataManagement().findAllMetadataProcess(metadataCriteria);
    }

    @Override
    public List<MetadataProcess> getTrackedProcessFromTrackingIdType(String trackingIdType) {
        MetadataCriteria metadataCriteria = new MetadataCriteria();
        metadataCriteria.setTrackingIdType(trackingIdType);
        return getMetadataManagement().findAllMetadataProcess(metadataCriteria);
    }


}
