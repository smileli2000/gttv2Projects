package com.sap.gtt.v2.integration.idoc.domain.idoc;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

public class E1ehptid {

    private String segment;
    private String trxcod;
    private String trxid;
    private String startDate;
    private String endDate;
    private String timzon;
    private String action;

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }


    public String getTimzon() {
        return timzon;
    }

    public void setTimzon(String timzon) {
        this.timzon = timzon;
    }


    public void setSegment(String segment) {
         this.segment = segment;
     }
    @JacksonXmlProperty(localName = "SEGMENT",isAttribute = true)
    public String getSegment() {
         return segment;
     }

    public void setTrxcod(String trxcod) {
         this.trxcod = trxcod;
     }
     public String getTrxcod() {
         return trxcod;
     }

    public void setTrxid(String trxid) {
         this.trxid = trxid;
     }
     public String getTrxid() {
         return trxid;
     }

    public void setStartDate(String startDate) {
         this.startDate = startDate;
     }
    @JacksonXmlProperty(localName = "start_date")
    public String getStartDate() {
         return startDate;
     }

    public void setEndDate(String endDate) {
         this.endDate = endDate;
     }
    @JacksonXmlProperty(localName = "end_date")
    public String getEndDate() {
         return endDate;
     }

}