package com.sap.gtt.v2.integration.idoc.domain.idoc;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

/**
 * @author i311486
 */
@JacksonXmlRootElement(namespace = "soap-env",localName = "envelope")
public class SoapEnvEnvelopeEvent {

    @JacksonXmlProperty(namespace = "soap-env", localName = "header")
    private SoapEnvHeader soapenvheader;
    @JacksonXmlProperty(namespace = "soap-env", localName = "body")
    private SoapEnvBodyEvent soapenvbody;
    public void setSoapenvheader(SoapEnvHeader soapenvheader) {
        this.soapenvheader = soapenvheader;
    }
    public SoapEnvHeader getSoapenvheader() {
        return soapenvheader;
    }

    public void setSoapenvbody(SoapEnvBodyEvent soapenvbody) {
        this.soapenvbody = soapenvbody;
    }
    public SoapEnvBodyEvent getSoapenvbody() {
        return soapenvbody;
    }

}