package com.sap.gtt.v2.integration.idoc.service;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.sap.gtt.v2.integration.idoc.domain.gtt.ActualEvent;
import java.util.Map;

/**
 * @author i311486
 */
public interface ISendRequestService {

    /**
     * send TP to GTT
     * @param trackedProcess
     * @param requestId
     * @param writeServiceId
     * @return
     */
    public JsonArray sendTPToGTT(Map<String, JsonObject> trackedProcess, String requestId, String writeServiceId);

    /**
     * send event to GTT
     * @param actualEventObj
     */
    public String sendEventToGTT(JsonObject actualEventObj, String requestId, String writeServiceId);
}
