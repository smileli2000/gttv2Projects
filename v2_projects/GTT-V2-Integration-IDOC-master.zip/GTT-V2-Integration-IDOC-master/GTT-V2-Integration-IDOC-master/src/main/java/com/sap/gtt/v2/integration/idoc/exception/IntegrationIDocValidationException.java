package com.sap.gtt.v2.integration.idoc.exception;

import com.sap.gtt.v2.exception.BaseRuntimeException;
import org.apache.http.HttpStatus;

/**
 * @author i311486
 */
public class IntegrationIDocValidationException extends BaseRuntimeException {
    public static final String ERROR_CODE = "ERROR_CODE_IDOC_VALIDATION";

    public static final String MESSAGE_CODE_TRACKING_ID_TYPE_NOT_FOUND=IntegrationIDocValidationException.class.getName() + ".TrackingIdTypeNotFound";
    public static final String MESSAGE_CODE_EVENT_TYPE_NOT_FOUND=IntegrationIDocValidationException.class.getName() + ".EventTypeNotFound";
    public static final String MESSAGE_CODE_APPLICATION_OBJECT_TYPE_NOT_FOUND=IntegrationIDocValidationException.class.getName() + ".ApplicationObjectTypeNotFound";
    public static final String MESSAGE_CODE_FIELD_NOT_FOUND_IN_METADATA=IntegrationIDocValidationException.class.getName() + ".FieldNotFoundInMetadata";
    public IntegrationIDocValidationException(String messageCode, Object[] localizedMsgParams) {
        super(messageCode, localizedMsgParams);
    }

    public IntegrationIDocValidationException(String internalMessage, Throwable cause, String messageCode, Object[] localizedMsgParams) {
        super(internalMessage, cause, messageCode, localizedMsgParams);
    }

    @Override
    public int getHttpStatus() {
        return HttpStatus.SC_BAD_REQUEST;
    }


    @Override
    public String getErrorCode() {
        return ERROR_CODE;
    }
}
