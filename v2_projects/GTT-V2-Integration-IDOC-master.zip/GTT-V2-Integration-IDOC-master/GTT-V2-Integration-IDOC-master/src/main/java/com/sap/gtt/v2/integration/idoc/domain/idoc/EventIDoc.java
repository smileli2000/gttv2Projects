
package com.sap.gtt.v2.integration.idoc.domain.idoc;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

/**
 * @author i311486
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class EventIDoc {

    @JacksonXmlProperty(localName = "edi_dc40")
    private EdiDc40 ediDc40;
    @JacksonXmlProperty(localName = "e1evmhdr02")
    private E1evmhdr02 e1evmhdr02;

    public EdiDc40 getEdiDc40() {
        return ediDc40;
    }

    public void setEdiDc40(EdiDc40 ediDc40) {
        this.ediDc40 = ediDc40;
    }


    public void setE1evmhdr02(E1evmhdr02 e1evmhdr02) {
        this.e1evmhdr02 = e1evmhdr02;
    }

    public E1evmhdr02 getE1evmhdr02() {
        return e1evmhdr02;
    }

}