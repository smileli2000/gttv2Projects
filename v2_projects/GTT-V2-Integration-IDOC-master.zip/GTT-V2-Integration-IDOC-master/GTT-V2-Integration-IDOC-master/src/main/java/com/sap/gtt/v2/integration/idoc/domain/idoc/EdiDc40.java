package com.sap.gtt.v2.integration.idoc.domain.idoc;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author i311486
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class EdiDc40 {

    private String tabnam;
    private String mandt;
    private String docnum;
    private String docrel;
    private String status;
    private String direct;
    private String outmod;
    private String idoctyp;
    private String mestyp;
    private String sndpor;
    private String sndprt;
    private String sndprn;
    private String rcvpor;
    private String rcvprt;
    private String rcvprn;
    private String credat;
    private String cretim;
    private String arckey;
    private String serial;


    public void setTabnam(String tabnam) {
         this.tabnam = tabnam;
     }
     public String getTabnam() {
         return tabnam;
     }

    public void setMandt(String mandt) {
         this.mandt = mandt;
     }
     public String getMandt() {
         return mandt;
     }

    public void setDocnum(String docnum) {
         this.docnum = docnum;
     }
     public String getDocnum() {
         return docnum;
     }

    public void setDocrel(String docrel) {
         this.docrel = docrel;
     }
     public String getDocrel() {
         return docrel;
     }

    public void setStatus(String status) {
         this.status = status;
     }
     public String getStatus() {
         return status;
     }

    public void setDirect(String direct) {
         this.direct = direct;
     }
     public String getDirect() {
         return direct;
     }

    public void setOutmod(String outmod) {
         this.outmod = outmod;
     }
     public String getOutmod() {
         return outmod;
     }

    public void setIdoctyp(String idoctyp) {
         this.idoctyp = idoctyp;
     }
     public String getIdoctyp() {
         return idoctyp;
     }

    public void setMestyp(String mestyp) {
         this.mestyp = mestyp;
     }
     public String getMestyp() {
         return mestyp;
     }

    public void setSndpor(String sndpor) {
         this.sndpor = sndpor;
     }
     public String getSndpor() {
         return sndpor;
     }

    public void setSndprt(String sndprt) {
         this.sndprt = sndprt;
     }
     public String getSndprt() {
         return sndprt;
     }

    public void setSndprn(String sndprn) {
         this.sndprn = sndprn;
     }
     public String getSndprn() {
         return sndprn;
     }

    public void setRcvpor(String rcvpor) {
         this.rcvpor = rcvpor;
     }
     public String getRcvpor() {
         return rcvpor;
     }

    public void setRcvprt(String rcvprt) {
         this.rcvprt = rcvprt;
     }
     public String getRcvprt() {
         return rcvprt;
     }

    public void setRcvprn(String rcvprn) {
         this.rcvprn = rcvprn;
     }
     public String getRcvprn() {
         return rcvprn;
     }

    public void setCredat(String credat) {
         this.credat = credat;
     }
     public String getCredat() {
         return credat;
     }

    public void setCretim(String cretim) {
         this.cretim = cretim;
     }
     public String getCretim() {
         return cretim;
     }

    public void setArckey(String arckey) {
         this.arckey = arckey;
     }
     public String getArckey() {
         return arckey;
     }

    public void setSerial(String serial) {
         this.serial = serial;
     }
     public String getSerial() {
         return serial;
     }

}