package com.sap.gtt.v2.integration.idoc.domain.idoc;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
@JsonIgnoreProperties(ignoreUnknown = true)
public class E1ehpee {


    private String milestonenum;
    private String milestone;
    private String loctype;
    private String locid1;
    @JacksonXmlProperty(localName = "msg_exp_tzone")
    private String msgExpTzone;
    @JacksonXmlProperty(localName = "msg_exp_datetime")
    private String msgExpDatetime;
    @JacksonXmlProperty(localName = "msg_er_exp_dtime")
    private String msgErExpDtime;
    @JacksonXmlProperty(localName = "msg_lt_exp_dtime")
    private String msgLtExpDtime;
    @JacksonXmlProperty(localName = "evt_exp_datetime")
    private String evtExpDatetime;
    @JacksonXmlProperty(localName = "evt_er_exp_dtime")
    private String evtErExpDtime;
    @JacksonXmlProperty(localName = "evt_lt_exp_dtime")
    private String evtLtExpDtime;
    @JacksonXmlProperty(localName = "evt_exp_tzone")
    private String evtExpTzone;
    private String itemident;


    public String getMsgExpTzone() {
        return msgExpTzone;
    }

    public void setMsgExpTzone(String msgExpTzone) {
        this.msgExpTzone = msgExpTzone;
    }

    public void setMilestonenum(String milestonenum) {
         this.milestonenum = milestonenum;
     }
     public String getMilestonenum() {
         return milestonenum;
     }

    public void setMilestone(String milestone) {
         this.milestone = milestone;
     }
     public String getMilestone() {
         return milestone;
     }

    public void setLoctype(String loctype) {
         this.loctype = loctype;
     }
     public String getLoctype() {
         return loctype;
     }

    public void setLocid1(String locid1) {
         this.locid1 = locid1;
     }
     public String getLocid1() {
         return locid1;
     }

    public void setMsgExpDatetime(String msgExpDatetime) {
         this.msgExpDatetime = msgExpDatetime;
     }
     public String getMsgExpDatetime() {
         return msgExpDatetime;
     }

    public void setMsgErExpDtime(String msgErExpDtime) {
         this.msgErExpDtime = msgErExpDtime;
     }
     public String getMsgErExpDtime() {
         return msgErExpDtime;
     }

    public void setMsgLtExpDtime(String msgLtExpDtime) {
         this.msgLtExpDtime = msgLtExpDtime;
     }
     public String getMsgLtExpDtime() {
         return msgLtExpDtime;
     }

    public void setEvtExpDatetime(String evtExpDatetime) {
         this.evtExpDatetime = evtExpDatetime;
     }
     public String getEvtExpDatetime() {
         return evtExpDatetime;
     }

    public void setEvtErExpDtime(String evtErExpDtime) {
         this.evtErExpDtime = evtErExpDtime;
     }
     public String getEvtErExpDtime() {
         return evtErExpDtime;
     }

    public void setEvtLtExpDtime(String evtLtExpDtime) {
         this.evtLtExpDtime = evtLtExpDtime;
     }
     public String getEvtLtExpDtime() {
         return evtLtExpDtime;
     }

    public void setEvtExpTzone(String evtExpTzone) {
         this.evtExpTzone = evtExpTzone;
     }
     public String getEvtExpTzone() {
         return evtExpTzone;
     }

    public void setItemident(String itemident) {
         this.itemident = itemident;
     }
     public String getItemident() {
         return itemident;
     }

}