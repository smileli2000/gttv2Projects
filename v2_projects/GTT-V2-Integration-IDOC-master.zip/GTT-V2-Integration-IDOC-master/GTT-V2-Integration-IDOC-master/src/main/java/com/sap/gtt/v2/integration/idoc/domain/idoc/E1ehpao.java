package com.sap.gtt.v2.integration.idoc.domain.idoc;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class E1ehpao {


    private String appsys;
    private String appobjtype;
    private String appobjid;
    @JacksonXmlElementWrapper(useWrapping = false)
    @JacksonXmlProperty(localName = "E1EHPCP")
    private List<E1ehpcp> e1ehpcp;
    @JacksonXmlElementWrapper(useWrapping = false)
    @JacksonXmlProperty(localName = "E1EHPEE")
    private List<E1ehpee> e1ehpee;
    @JacksonXmlElementWrapper(useWrapping = false)
    @JacksonXmlProperty(localName = "E1EHPTID")
    private List<E1ehptid> e1ehptid;


    public void setAppsys(String appsys) {
         this.appsys = appsys;
     }
     public String getAppsys() {
         return appsys;
     }

    public void setAppobjtype(String appobjtype) {
         this.appobjtype = appobjtype;
     }
     public String getAppobjtype() {
         return appobjtype;
     }

    public void setAppobjid(String appobjid) {
         this.appobjid = appobjid;
     }
     public String getAppobjid() {
         return appobjid;
     }

    public void setE1ehpcp(List<E1ehpcp> e1ehpcp) {
         this.e1ehpcp = e1ehpcp;
     }
     public List<E1ehpcp> getE1ehpcp() {
         return e1ehpcp;
     }

    public void setE1ehpee(List<E1ehpee> e1ehpee) {
         this.e1ehpee = e1ehpee;
     }
     public List<E1ehpee> getE1ehpee() {
         return e1ehpee;
     }

    public void setE1ehptid(List<E1ehptid> e1ehptid) {
         this.e1ehptid = e1ehptid;
     }
     public List<E1ehptid> getE1ehptid() {
         return e1ehptid;
     }

}