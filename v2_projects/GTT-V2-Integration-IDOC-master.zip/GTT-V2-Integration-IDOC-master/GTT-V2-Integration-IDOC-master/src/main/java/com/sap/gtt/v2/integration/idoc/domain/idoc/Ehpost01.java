package com.sap.gtt.v2.integration.idoc.domain.idoc;


import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

public class Ehpost01 {

    @JacksonXmlProperty(localName = "idoc")
    private TPIDoc idoc;

    public void setIdoc(TPIDoc idoc) {
        this.idoc = idoc;
    }

    public TPIDoc getIdoc() {
        return idoc;
    }

}