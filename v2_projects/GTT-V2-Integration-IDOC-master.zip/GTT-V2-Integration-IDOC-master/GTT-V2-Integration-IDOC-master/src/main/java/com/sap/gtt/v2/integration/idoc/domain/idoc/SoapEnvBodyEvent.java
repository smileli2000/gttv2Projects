package com.sap.gtt.v2.integration.idoc.domain.idoc;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * @author i311486
 */
public class SoapEnvBodyEvent {

    @JacksonXmlProperty(localName = "evmsta02")
    private Evmsta02 evmsta02;
    public void setEvmsta02(Evmsta02 evmsta02) {
         this.evmsta02 = evmsta02;
     }
     public Evmsta02 getEvmsta02() {
         return evmsta02;
     }

}