package com.sap.gtt.v2.integration.idoc.domain.idoc;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * @author i311486
 */
public class SoapEnvHeader {

    private String msgidmessageid;

    @JacksonXmlProperty(namespace = "msgid", localName = "messageid")
    public void setMsgidmessageid(String msgidmessageid) {
         this.msgidmessageid = msgidmessageid;
     }
     public String getMsgidmessageid() {
         return msgidmessageid;
     }

}