package com.sap.gtt.v2.integration.idoc.exception;

import com.sap.gtt.v2.exception.BaseRuntimeException;
import org.apache.http.HttpStatus;

/**
 * @author i311486
 */
public class IntegrationIDocRuntimeException extends BaseRuntimeException {
    public static final String ERROR_CODE = "ERROR_CODE_IDOC_RUNTIME";

    public static final String MESSAGE_CODE_CDS_TYPE_NOT_FOUND=IntegrationIDocRuntimeException.class.getName() + ".CdsTypeNotFound";
    public IntegrationIDocRuntimeException(String internalMessage, Throwable cause, String messageCode, Object[] localizedMsgParams) {
        super(internalMessage, cause, messageCode, localizedMsgParams);
    }

    public IntegrationIDocRuntimeException(String messageCode, Object[] localizedMsgParams) {
        super(messageCode, localizedMsgParams);
    }


    @Override
    public int getHttpStatus() {
        return HttpStatus.SC_INTERNAL_SERVER_ERROR;
    }


    @Override
    public String getErrorCode() {
        return ERROR_CODE;
    }
}