package com.sap.gtt.v2.integration.idoc.service.impl;

import com.sap.gtt.v2.configuration.ISAPCloudPlatformAgent;
import com.sap.gtt.v2.core.domain.execution.*;
import com.sap.gtt.v2.core.management.execution.IMessageLogManagement;
import com.sap.gtt.v2.exception.BaseRuntimeException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.Arrays;
import java.util.List;

/**
 * @author i311486
 */
@Component
public class MessageLogService {
    @Autowired
    private ISAPCloudPlatformAgent.ICurrentAccessContext currentAccessContext;

    public void saveRequestPayload(String requestId, String parentId, String messageNumber, String payload, String path) {
        RequestPayloadDto requestPayloadDto = new RequestPayloadDto();
        requestPayloadDto.setId(requestId);
        requestPayloadDto.setParentId(parentId);
        requestPayloadDto.setMessageNumber(messageNumber);
        requestPayloadDto.setPayload(payload);
        requestPayloadDto.setRequestDataTime(Instant.now());
        requestPayloadDto.setSource(MessageSource.ERP.name());
        requestPayloadDto.setWriteServicePath(path);
        getMessageLogManagement().insertPayload(requestPayloadDto);
    }

    public void saveRequestTrackingId(String writeServiceId, List<String> trackingIds) {
        RequestTrackingIdDto trackingIdDto = new RequestTrackingIdDto();
        trackingIdDto.setRequestId(writeServiceId);
        trackingIdDto.setTrackingIds(trackingIds);
        getMessageLogManagement().insertTrackingIds(trackingIdDto);
    }

    public void saveErrorMessageLog(String requestId, String writeServiceId, BaseRuntimeException ex) {
        saveMessageLog(requestId, writeServiceId, ExecutionStatus.ERROR, ex.getErrorCode(), Arrays.toString(ex.getStackTrace()));
    }

    public void saveSuccessMessageLog(String requestId, String writeServiceId) {
        saveMessageLog(requestId, writeServiceId, ExecutionStatus.SUCCESS, null, null);
    }

    private void saveMessageLog(String requestId, String writeServiceId, ExecutionStatus status, String message, String detail) {
        MappingMessageDto messageDto = new MappingMessageDto();
        messageDto.setRootRequestId(requestId);
        messageDto.setObjectId(writeServiceId);
        messageDto.setStatus(status);
        messageDto.setMessage(message);
        messageDto.setDetail(detail);
        getMessageLogManagement().insertMappingMessage(messageDto);
    }

    private IMessageLogManagement getMessageLogManagement() {
        return currentAccessContext.createBusinessOperator().getMessageLogManagement();
    }
}

