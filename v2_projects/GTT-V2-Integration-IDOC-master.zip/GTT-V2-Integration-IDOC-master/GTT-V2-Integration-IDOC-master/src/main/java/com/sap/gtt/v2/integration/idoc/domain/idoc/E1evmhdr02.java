package com.sap.gtt.v2.integration.idoc.domain.idoc;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

import java.util.List;

/**
 * @author i311486
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class E1evmhdr02 {

    private String evtid;
    private String evtdat;
    private String evttim;
    private String evtzon;
    private E1evmtid e1evmtid;

    @JacksonXmlElementWrapper(useWrapping = false)
    @JacksonXmlProperty(localName = "E1EVMLID")
    private List<E1evmlid> e1evmlid;

    @JacksonXmlElementWrapper(useWrapping = false)
    @JacksonXmlProperty(localName = "E1EVMPAR")
    private List<E1evmpar> e1evmpar;

    private String srctx;
    private String srcid;
    @JacksonXmlElementWrapper(useWrapping = false)
    @JacksonXmlProperty(localName = "E1EVMREF02")
    private List<E1evmref02> e1evmref02;


    public List<E1evmpar> getE1evmpar() {
        return e1evmpar;
    }

    public void setE1evmpar(List<E1evmpar> e1evmpar) {
        this.e1evmpar = e1evmpar;
    }

    public List<E1evmref02> getE1evmref02() {
        return e1evmref02;
    }

    public void setE1evmref02(List<E1evmref02> e1evmref02) {
        this.e1evmref02 = e1evmref02;
    }


    public String getSrctx() {
        return srctx;
    }

    public void setSrctx(String srctx) {
        this.srctx = srctx;
    }

    public String getSrcid() {
        return srcid;
    }

    public void setSrcid(String srcid) {
        this.srcid = srcid;
    }
    public void setEvtid(String evtid) {
         this.evtid = evtid;
     }
     public String getEvtid() {
         return evtid;
     }

    public void setEvtdat(String evtdat) {
         this.evtdat = evtdat;
     }
     public String getEvtdat() {
         return evtdat;
     }

    public void setEvttim(String evttim) {
         this.evttim = evttim;
     }
     public String getEvttim() {
         return evttim;
     }

    public void setEvtzon(String evtzon) {
         this.evtzon = evtzon;
     }
     public String getEvtzon() {
         return evtzon;
     }

    public void setE1evmtid(E1evmtid e1evmtid) {
         this.e1evmtid = e1evmtid;
     }
     public E1evmtid getE1evmtid() {
         return e1evmtid;
     }

    public void setE1evmlid(List<E1evmlid> e1evmlid) {
         this.e1evmlid = e1evmlid;
     }
     public List<E1evmlid> getE1evmlid() {
         return e1evmlid;
     }

}