package com.sap.gtt.v2.integration.idoc.exception;

import com.sap.gtt.v2.exception.BaseRuntimeException;
import org.apache.http.HttpStatus;

/**
 * @author i311486
 */
public class TimeConvertException extends BaseRuntimeException {
    public static final String ERROR_CODE = "ERROR_CODE_TIME_CONVERSION";

    public static final String MESSAGE_CODE_TIMEZONE_CAN_NOT_MAP= TimeConvertException.class.getName() + ".TimezoneCanNotMap";
    public static final String MESSAGE_CODE_TIME_CAN_NOT_PARSER= TimeConvertException.class.getName() + ".DateTimeCanNotParse";
    public static final String MESSAGE_CODE_TIME_IS_NULL= TimeConvertException.class.getName() + ".DateTimeIsNull";

    public TimeConvertException(String messageCode, Object[] localizedMsgParams) {
        super(messageCode, localizedMsgParams);
    }

    @Override
    public int getHttpStatus() {
        return HttpStatus.SC_BAD_REQUEST;
    }

    @Override
    public String getErrorCode() {
        return ERROR_CODE;
    }
}
