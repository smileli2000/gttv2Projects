package com.sap.gtt.v2.integration.idoc.utils;

import com.sap.gtt.v2.integration.idoc.exception.IntegrationIDocRuntimeException;

import javax.xml.namespace.QName;
import javax.xml.soap.*;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;


/**
 * @author i311486
 */
public class Utils {
    private Utils() {
    }

    private static final String NS_PREFIX = "com.sap.gtt.app.";


    public static String convertToZoneDateTime(String zone, String datetime) {
        ZoneId zoneId = ZoneId.systemDefault();
        if (zone != null) {
            zoneId = ZoneId.of(zone);
        }
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("0yyyyMMddHHmmss").withZone(zoneId);
        DateTimeFormatter gttTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ssxxx");
        return ZonedDateTime.parse(datetime, formatter).format(gttTimeFormatter);
    }

    public static String getPath(String type, boolean isTP) {
        StringBuilder path = new StringBuilder("");
        String serviceName = type.replaceFirst(NS_PREFIX, "");
        serviceName = serviceName.substring(0, serviceName.indexOf('.'));
        path.append(NS_PREFIX).append(serviceName).append('.').append(serviceName).append("WriteService/");
        String event = "";
        if (isTP) {
            event = type.substring(type.lastIndexOf('.') + 1) + "Event";
        } else {
            event = type.substring(type.lastIndexOf('.') + 1);
        }
        path.append(event);
        return path.toString();
    }

    public static String createSoapMessage(String msg, String segment) {
        String result = null;
        try {
            MessageFactory factory = MessageFactory.newInstance();
            SOAPMessage message = factory.createMessage();
            SOAPPart part = message.getSOAPPart();
            SOAPEnvelope envelope = part.getEnvelope();
            SOAPBody body = envelope.getBody();
            QName qname = new QName("urn:sap-com:document:sap:idoc:soap:messages", segment+"Response");
            SOAPBodyElement ele = body.addBodyElement(qname);
            if(msg!=null) {
                ele.addChildElement("IdocAssign").setValue(msg);
            }else {
                ele.addChildElement("IdocAssign").setValue("null");
            }
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            message.writeTo(byteArrayOutputStream);
            result = byteArrayOutputStream.toString();
            byteArrayOutputStream.close();
        } catch (SOAPException | IOException e) {
            throw new IntegrationIDocRuntimeException("CreateSoapMessageError",new Object[]{});
        }
        return result;
    }

    public static String createSoapMessageError(String code, String msg) {
        String result = null;
        msg = msg==null ? "" : msg ;
        try {
            MessageFactory factory = MessageFactory.newInstance();
            SOAPMessage message = factory.createMessage();
            SOAPPart part = message.getSOAPPart();
            SOAPEnvelope envelope = part.getEnvelope();
            SOAPBody body = envelope.getBody();
            QName qname = new QName(code);
            body.addFault(qname, msg);
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            message.writeTo(byteArrayOutputStream);
            result = byteArrayOutputStream.toString();
            byteArrayOutputStream.close();
        } catch (SOAPException | IOException e) {
            throw new IntegrationIDocRuntimeException("CreateSoapMessageError",new Object[]{});
        }
        return result;
    }

}
