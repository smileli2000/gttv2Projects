package com.sap.gtt.v2.integration.idoc.utils;


import java.util.HashMap;
import java.util.Map;

/**
 * @author i311486
 */
public class Constants {
    public static final String TIMEZONE_MAPPING_FILE = "timeZoneMapping.properties";
    public static final String ALT_KEY_HEADER = "xri://sap.com/id:";
    public static final String TRACKING = "TRACKING";
    public static final String LOCATION = "Location";
    public static final String ACTUAL_BUSINESS_DATETIME = "ACTUAL_BUSINESS_DATETIME";
    public static final String ACTUAL_BUSINESS_TIMEZONE = "ACTUAL_BUSINESS_TIMEZONE";
    public static final String PROCESS_TYPES = "processTypes";
    public static final String EVENT_TYPES = "eventTypes";
    public static final String ERP_EVENT_CODE = "erpEventCode";
    public static final String NAME = "name";
    public static final String TYPE = "type";
    public static final String BODY = "body";
    public static final String IDOC_MAPPING = "idocMapping";
    public static final String FIELD_MAPPING = "fieldMapping";
    public static final String FIELD = "field";
    public static final String IDOC_FIELD = "idocField";
    public static final String IDOC_SEGMENT = "idocSegment";
    public static final String STRING = "string";
    public static final String INTEGER = "integer";
    public static final String DECIMAL = "decimal";
    public static final String BOOLEAN = "boolean";
    public static final String CDS_COMPOSITION = "cds.Composition";
    public static final String E1EHPCP = "E1EHPCP";
    public static final String E1EVMPAR = "E1EVMPAR";
    public static final String PARAM_INDEX_0 = "0000000000";
    public static final String COMPOSITION = "composition";
    public static final String ASSOCIATION = "association";
    public static final String ALT_KEY = "AltKey";

    private Constants(){

    }

    public static final Map<String, String> CDS_TYPE_MAP;
    static {
        CDS_TYPE_MAP = new HashMap<>();
        CDS_TYPE_MAP.put("cds.String", STRING);
        CDS_TYPE_MAP.put("cds.DateTime", STRING);
        CDS_TYPE_MAP.put("cds.Timestamp", STRING);
        CDS_TYPE_MAP.put("cds.Date", STRING);
        CDS_TYPE_MAP.put("cds.UUID", STRING);
        CDS_TYPE_MAP.put("cds.Boolean", BOOLEAN);
        CDS_TYPE_MAP.put("cds.Integer", INTEGER);
        CDS_TYPE_MAP.put("cds.Decimal", DECIMAL);
        CDS_TYPE_MAP.put(CDS_COMPOSITION, COMPOSITION);
        CDS_TYPE_MAP.put("cds.Association", ASSOCIATION);
    }
}
