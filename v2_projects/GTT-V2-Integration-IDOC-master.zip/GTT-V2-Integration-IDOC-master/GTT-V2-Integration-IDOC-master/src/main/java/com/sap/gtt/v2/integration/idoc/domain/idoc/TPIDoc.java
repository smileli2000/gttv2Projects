package com.sap.gtt.v2.integration.idoc.domain.idoc;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class TPIDoc {

    @JacksonXmlProperty(localName = "edi_dc40")
    private EdiDc40 ediDc40;
    @JacksonXmlProperty(localName = "e1ehpao")
    private E1ehpao e1ehpao;


    public void setEdiDc40(EdiDc40 ediDc40) {
         this.ediDc40 = ediDc40;
     }
     public EdiDc40 getEdiDc40() {
         return ediDc40;
     }

    public void setE1ehpao(E1ehpao e1ehpao) {
         this.e1ehpao = e1ehpao;
     }
     public E1ehpao getE1ehpao() {
         return e1ehpao;
     }

}