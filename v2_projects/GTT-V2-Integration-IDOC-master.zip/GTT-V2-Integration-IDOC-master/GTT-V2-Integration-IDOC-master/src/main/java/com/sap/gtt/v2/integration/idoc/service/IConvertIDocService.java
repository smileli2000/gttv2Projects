package com.sap.gtt.v2.integration.idoc.service;

import com.google.gson.JsonObject;
import com.sap.gtt.v2.core.domain.metadata.CurrentMetadataEntity;
import com.sap.gtt.v2.integration.idoc.domain.gtt.ActualEvent;
import com.sap.gtt.v2.integration.idoc.domain.idoc.SoapEnvEnvelopeEvent;
import com.sap.gtt.v2.integration.idoc.domain.idoc.SoapEnvEnvelopeTP;


import java.util.Map;

/**
 * @author i311486
 */
public interface IConvertIDocService {
    /**
     * convert IDoc to tracked process
     * @param soapEnvEnvelopeTP
     * @return
     */
    public Map<String, JsonObject> convertTrackedProcess(SoapEnvEnvelopeTP soapEnvEnvelopeTP);

    /**
     * convert IDoc to actual event
     * @param soapEnvEnvelopeEvent
     * @return
     */
    public JsonObject convertActualEvent(SoapEnvEnvelopeEvent soapEnvEnvelopeEvent);

    /**
     * get IDoc config by namespace
     * @param modelNamespace
     * @return
     */
    public String getIDocConfig(String modelNamespace);

    /**
     * convert erp time to ZoneDateTime
     * @param timezone
     * @param datetime
     * @return {String} timestamp
     */
    public String convertToZoneDateTime(String timezone, String datetime);

    /**
     * Find all the fields of an entity
     *
     *
     * @param trackedProcessType entity name such as com.sap.gtt.app.mim.DeliveryModel.DeliveryProcess
     * @return all the fields of the entity
     */
    CurrentMetadataEntity getTrackedProcessEventEntity(String trackedProcessType);


    /**
     * Find all the fields of an entity
     *
     *
     * @param eventType entity name such as com.sap.gtt.app.mim.DeliveryModel.DeliveryProcess
     * @return all the fields of the entity
     */
    CurrentMetadataEntity getEventForWriteEntity(String eventType);

    /**
     * Get LBN id
     * @param tenantId
     * @return BP
     */
    String getLbnIdByTenantId(String tenantId);
}
