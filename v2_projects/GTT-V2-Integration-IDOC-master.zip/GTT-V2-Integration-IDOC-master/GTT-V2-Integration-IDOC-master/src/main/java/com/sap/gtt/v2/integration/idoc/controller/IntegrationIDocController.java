package com.sap.gtt.v2.integration.idoc.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.sap.gtt.v2.integration.idoc.domain.idoc.EventIDoc;
import com.sap.gtt.v2.integration.idoc.domain.idoc.SoapEnvEnvelopeEvent;
import com.sap.gtt.v2.integration.idoc.domain.idoc.SoapEnvEnvelopeTP;
import com.sap.gtt.v2.integration.idoc.domain.idoc.TPIDoc;
import com.sap.gtt.v2.integration.idoc.exception.IntegrationIDocRuntimeException;
import com.sap.gtt.v2.integration.idoc.exception.IntegrationIDocValidationException;
import com.sap.gtt.v2.integration.idoc.exception.TimeConvertException;
import com.sap.gtt.v2.integration.idoc.service.impl.ConvertIDocServiceImpl;
import com.sap.gtt.v2.integration.idoc.service.impl.MessageLogService;
import com.sap.gtt.v2.integration.idoc.service.impl.SendRequestServiceImpl;
import com.sap.gtt.v2.integration.idoc.utils.Utils;
import com.sap.gtt.v2.log.TenantAwareLogService;
import com.sap.gtt.v2.util.GTTUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.xml.soap.SOAPException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author i311486
 */
@RestController
@RequestMapping(IntegrationIDocController.ROOT_URL)
public class IntegrationIDocController {
    @Autowired
    public ConvertIDocServiceImpl convertIDocService;

    @Autowired
    public SendRequestServiceImpl sendToGTT;

    @Autowired
    private MessageLogService messageLogService;

    @Autowired
    private TenantAwareLogService logService;

    public static final String ROOT_URL = "/sap/logistics/gtt/integration/em-idoc/v1";

    @PostMapping(value = "/TrackedProcess")
    public ResponseEntity<String> handleTrackedProcess(@RequestBody String trackedProcessXML) {
        logService.info(trackedProcessXML);
        String requestId = GTTUtils.UUIDUtils.generateTimeBasedUUID().toString();
        String writeServiceId = GTTUtils.UUIDUtils.generateTimeBasedUUID().toString();
        String messageNumber = null;
        XmlMapper xmlMapper = new XmlMapper();
        xmlMapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES,true);
        SoapEnvEnvelopeTP trackedProcessIDoc = null;
        try {
            trackedProcessIDoc  = xmlMapper.readValue(trackedProcessXML, SoapEnvEnvelopeTP.class);
            messageNumber = trackedProcessIDoc.getSoapenvbody().getEhpost01().getIdoc().getEdiDc40().getDocnum();
            messageLogService.saveRequestPayload(requestId, null, messageNumber, trackedProcessXML, null);
        }catch (JsonProcessingException e){
            IntegrationIDocValidationException newEx =  new IntegrationIDocValidationException(e.getMessage(),e.getCause(),null,null);
            messageLogService.saveRequestPayload(requestId, null,null, trackedProcessXML, null);
            messageLogService.saveErrorMessageLog(requestId, writeServiceId, newEx);
            throw  newEx;
        }
        Map<String,JsonObject> trackedProcessMap = new HashMap<>();
        try{
            TPIDoc idoc = trackedProcessIDoc.getSoapenvbody().getEhpost01().getIdoc();
            String id = idoc.getE1ehpao().getAppobjid();
            List<String> trackingIds = new ArrayList<>();
            trackingIds.add(id);
            messageLogService.saveRequestTrackingId(writeServiceId, trackingIds);
            trackedProcessMap = convertIDocService.convertTrackedProcess(trackedProcessIDoc);
        } catch (IntegrationIDocRuntimeException | IntegrationIDocValidationException | TimeConvertException e){
            messageLogService.saveErrorMessageLog(requestId, writeServiceId, e);
            throw e;
        }
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_XML);
        JsonArray responses = null;
        try{
            responses = sendToGTT.sendTPToGTT(trackedProcessMap, requestId, writeServiceId);
        }catch (IntegrationIDocRuntimeException | IntegrationIDocValidationException e){
            messageLogService.saveErrorMessageLog(requestId, writeServiceId, e);
            throw e;
        }
        String soapMsg = Utils.createSoapMessage(responses.toString(), "EHPOST01");
        return new ResponseEntity<>(soapMsg, headers,HttpStatus.OK);
    }

    @PostMapping(value = "/Event")
    public ResponseEntity<String> handleActualEvent(@RequestBody String eventXML ) throws SOAPException {
        logService.info(eventXML);
        String requestId = GTTUtils.UUIDUtils.generateTimeBasedUUID().toString();
        String writeServiceId = GTTUtils.UUIDUtils.generateTimeBasedUUID().toString();
        String messageNumber = null;
        XmlMapper xmlMapper = new XmlMapper();
        xmlMapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES,true);
        SoapEnvEnvelopeEvent actualEventIDoc = null;
        try {
            actualEventIDoc  = xmlMapper.readValue(eventXML, SoapEnvEnvelopeEvent.class);
            messageNumber = actualEventIDoc.getSoapenvbody().getEvmsta02().getIdoc().getEdiDc40().getDocnum();
            messageLogService.saveRequestPayload(requestId, null, messageNumber, eventXML, null);
        }catch (JsonProcessingException e){
            IntegrationIDocValidationException newEx =  new IntegrationIDocValidationException(e.getMessage(),e.getCause(),null,null);
            messageLogService.saveRequestPayload(requestId, null, null, eventXML, null);
            messageLogService.saveErrorMessageLog(requestId, writeServiceId, newEx);
            throw  newEx;
        }
        JsonObject actualEventObj = null;
        try{
            EventIDoc idoc = actualEventIDoc.getSoapenvbody().getEvmsta02().getIdoc();
            String id = idoc.getE1evmhdr02().getE1evmtid().getTrxid();
            List<String> trackingIds = new ArrayList<>();
            trackingIds.add(id);
            messageLogService.saveRequestTrackingId(writeServiceId, trackingIds);
            actualEventObj = convertIDocService.convertActualEvent(actualEventIDoc);
        } catch (IntegrationIDocRuntimeException | IntegrationIDocValidationException | TimeConvertException e){
            messageLogService.saveErrorMessageLog(requestId, writeServiceId, e);
            throw e;
        }
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_XML);
        String response = null;
        try{
            response = sendToGTT.sendEventToGTT(actualEventObj, requestId, writeServiceId);
        }catch (IntegrationIDocRuntimeException | IntegrationIDocValidationException e){
            messageLogService.saveErrorMessageLog(requestId, writeServiceId, e);
            throw e;
        }
        String soapMsg = Utils.createSoapMessage(response,"EVMSTA02");
        return new ResponseEntity<>(soapMsg, headers,HttpStatus.OK);
    }
}
