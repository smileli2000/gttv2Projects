package com.sap.gtt.v2.integration.idoc.domain.idoc;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class E1ehpcp {

    private String paramname;
    private String paramindex;
    private String value;

    public void setParamname(String paramname) {
        this.paramname = paramname;
    }
    public String getParamname() {
        return paramname;
    }

    public void setParamindex(String paramindex) {
        this.paramindex = paramindex;
    }
    public String getParamindex() {
        return paramindex;
    }

    public void setValue(String value) {
        this.value = value;
    }
    public String getValue() {
        return value;
    }

}