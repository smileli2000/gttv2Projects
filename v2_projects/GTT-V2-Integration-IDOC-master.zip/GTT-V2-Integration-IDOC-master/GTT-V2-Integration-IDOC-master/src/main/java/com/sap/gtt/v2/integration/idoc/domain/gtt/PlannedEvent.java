package com.sap.gtt.v2.integration.idoc.domain.gtt;

import java.io.Serializable;

/**
 * @author i311486
 */
public class PlannedEvent implements Serializable {
    private String eventType;
    private String locationAltKey;
    private String eventMatchKey;
    private String plannedTechnicalTimestamp;
    private String plannedTechTsEarliest;
    private String plannedTechTsLatest;
    private String plannedBusinessTimestamp;
    private String plannedBizTsEarliest;
    private String plannedBizTsLatest;
    private String plannedBusinessTimeZone;


    public PlannedEvent(String eventType, String locationAltKey, String eventMatchKey,String plannedTechnicalTimestamp,
                        String plannedTechTsEarliest, String plannedTechTsLatest, String plannedBusinessTimestamp,
                        String plannedBizTsEarliest, String plannedBizTsLatest, String plannedBusinessTimeZone) {
        this.eventType = eventType;
        this.locationAltKey = locationAltKey;
        this.eventMatchKey = eventMatchKey;
        this.plannedTechnicalTimestamp = plannedTechnicalTimestamp;
        this.plannedTechTsEarliest = plannedTechTsEarliest;
        this.plannedTechTsLatest = plannedTechTsLatest;
        this.plannedBusinessTimestamp = plannedBusinessTimestamp;
        this.plannedBizTsEarliest = plannedBizTsEarliest;
        this.plannedBizTsLatest = plannedBizTsLatest;
        this.plannedBusinessTimeZone = plannedBusinessTimeZone;
    }

    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    public String getLocationAltKey() {
        return locationAltKey;
    }

    public void setLocationAltKey(String locationAltKey) {
        this.locationAltKey = locationAltKey;
    }

    public String getPlannedTechnicalTimestamp() {
        return plannedTechnicalTimestamp;
    }

    public void setPlannedTechnicalTimestamp(String plannedTechnicalTimestamp) {
        this.plannedTechnicalTimestamp = plannedTechnicalTimestamp;
    }

    public String getPlannedTechTsEarliest() {
        return plannedTechTsEarliest;
    }

    public void setPlannedTechTsEarliest(String plannedTechTsEarliest) {
        this.plannedTechTsEarliest = plannedTechTsEarliest;
    }

    public String getPlannedTechTsLatest() {
        return plannedTechTsLatest;
    }

    public void setPlannedTechTsLatest(String plannedTechTsLatest) {
        this.plannedTechTsLatest = plannedTechTsLatest;
    }

    public String getPlannedBusinessTimestamp() {
        return plannedBusinessTimestamp;
    }

    public void setPlannedBusinessTimestamp(String plannedBusinessTimestamp) {
        this.plannedBusinessTimestamp = plannedBusinessTimestamp;
    }

    public String getPlannedBizTsEarliest() {
        return plannedBizTsEarliest;
    }

    public void setPlannedBizTsEarliest(String plannedBizTsEarliest) {
        this.plannedBizTsEarliest = plannedBizTsEarliest;
    }

    public String getPlannedBizTsLatest() {
        return plannedBizTsLatest;
    }

    public void setPlannedBizTsLatest(String plannedBizTsLatest) {
        this.plannedBizTsLatest = plannedBizTsLatest;
    }

    public String getPlannedBusinessTimeZone() {
        return plannedBusinessTimeZone;
    }

    public void setPlannedBusinessTimeZone(String plannedBusinessTimeZone) {
        this.plannedBusinessTimeZone = plannedBusinessTimeZone;
    }

    public String getEventMatchKey() {
        return eventMatchKey;
    }

    public void setEventMatchKey(String eventMatchKey) {
        this.eventMatchKey = eventMatchKey;
    }

}
