package com.sap.gtt.v2.integration.idoc.domain.gtt;

import java.io.Serializable;
import java.util.List;


/**
 * @author i311486
 */
public class TrackedProcess implements Serializable {
    private String altKey;
    private String actualBusinessTimestamp;
    private String actualBusinessTimeZone;
    private List<PlannedEvent> plannedEvents;
    private List<Reference> references;
    private transient String trackedProcessType;

    public List<Reference> getReferences() {
        return references;
    }

    public void setReferences(List<Reference> references) {
        this.references = references;
    }

    public String getTrackedProcessType() {
        return trackedProcessType;
    }

    public void setTrackedProcessType(String trackedProcessType) {
        this.trackedProcessType = trackedProcessType;
    }


    public TrackedProcess(String altKey,String trackedProcessType, String actualBusinessTimestamp, String actualBusinessTimeZone, List<PlannedEvent> plannedEvents, List<Reference> references) {
        this.altKey = altKey;
        this.actualBusinessTimestamp = actualBusinessTimestamp;
        this.actualBusinessTimeZone = actualBusinessTimeZone;
        this.plannedEvents = plannedEvents;
        this.trackedProcessType =trackedProcessType;
        this.references = references;
    }

    public String getAltKey() {
        return altKey;
    }

    public void setAltKey(String altKey) {
        this.altKey = altKey;
    }

    public List<PlannedEvent> getPlannedEvents() {
        return plannedEvents;
    }

    public void setPlannedEvents(List<PlannedEvent> plannedEvents) {
        this.plannedEvents = plannedEvents;
    }

    public String getActualBusinessTimestamp() {
        return actualBusinessTimestamp;
    }

    public void setActualBusinessTimestamp(String actualBusinessTimestamp) {
        this.actualBusinessTimestamp = actualBusinessTimestamp;
    }

    public String getActualBusinessTimeZone() {
        return actualBusinessTimeZone;
    }

    public void setActualBusinessTimeZone(String actualBusinessTimeZone) {
        this.actualBusinessTimeZone = actualBusinessTimeZone;
    }
}

