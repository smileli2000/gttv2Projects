package com.sap.gtt.v2.integration.idoc.service.impl;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.sap.gtt.v2.bp.BusinessPartner;
import com.sap.gtt.v2.bp.BusinessPartnerService;
import com.sap.gtt.v2.configuration.ISAPCloudPlatformAgent;
import com.sap.gtt.v2.core.domain.metadata.CurrentMetadataEntity;
import com.sap.gtt.v2.core.domain.metadata.MetadataConstants;
import com.sap.gtt.v2.core.domain.metadata.MetadataEntity;
import com.sap.gtt.v2.core.domain.metadata.MetadataEntityElement;
import com.sap.gtt.v2.core.entity.metadata.MetadataProcess;
import com.sap.gtt.v2.core.management.metadata.CsnParser;
import com.sap.gtt.v2.core.management.metadata.IMetadataManagement;
import com.sap.gtt.v2.integration.idoc.domain.gtt.ActualEvent;
import com.sap.gtt.v2.integration.idoc.domain.gtt.PlannedEvent;
import com.sap.gtt.v2.integration.idoc.domain.gtt.Reference;
import com.sap.gtt.v2.integration.idoc.domain.gtt.TrackedProcess;
import com.sap.gtt.v2.integration.idoc.domain.idoc.*;
import com.sap.gtt.v2.integration.idoc.exception.IntegrationIDocRuntimeException;
import com.sap.gtt.v2.integration.idoc.exception.IntegrationIDocValidationException;
import com.sap.gtt.v2.integration.idoc.exception.TimeConvertException;
import com.sap.gtt.v2.integration.idoc.service.IConvertIDocService;
import com.sap.gtt.v2.log.TenantAwareLogService;
import com.sap.gtt.v2.util.JsonUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import javax.annotation.PostConstruct;
import java.io.IOException;
import java.io.InputStream;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.zone.ZoneRulesException;
import java.util.*;
import java.util.stream.Collectors;

import static com.sap.gtt.v2.integration.idoc.exception.IntegrationIDocRuntimeException.MESSAGE_CODE_CDS_TYPE_NOT_FOUND;
import static com.sap.gtt.v2.integration.idoc.utils.Constants.*;
import static com.sap.gtt.v2.integration.idoc.exception.IntegrationIDocValidationException.*;
import static com.sap.gtt.v2.integration.idoc.exception.TimeConvertException.*;

/**
 * @author i311486
 */
@Service
public class ConvertIDocServiceImpl implements IConvertIDocService {
    private static Properties properties = new Properties();

    @Autowired
    ISAPCloudPlatformAgent.ICurrentAccessContext iCurrentAccessContext;

    @Autowired
    BusinessPartnerService bpService;

    @Autowired
    GetTrackedProcessServiceImpl getTrackedProcessService;

    @Autowired
    IMetadataManagement metadataManagement;

    @Autowired
    private TenantAwareLogService logService;

    @Override
    public Map<String,JsonObject> convertTrackedProcess(SoapEnvEnvelopeTP soapEnvEnvelopeTP) {
        TPIDoc idoc = soapEnvEnvelopeTP.getSoapenvbody().getEhpost01().getIdoc();
        String party = iCurrentAccessContext.getBusinessPartner().getLbnId();
        String system = idoc.getE1ehpao().getAppsys();
        String applicationObjectType = idoc.getE1ehpao().getAppobjtype();
        String id = idoc.getE1ehpao().getAppobjid();
        List<MetadataProcess> metadataProcessesList = getTrackedProcessService.getTrackedProcessFromAOT(applicationObjectType);

        if (metadataProcessesList.isEmpty()) {
            throw new IntegrationIDocValidationException(MESSAGE_CODE_APPLICATION_OBJECT_TYPE_NOT_FOUND, new Object[]{});
        }

        Map<String,JsonObject> trackedProcessesMap = new HashMap<>();
        metadataProcessesList.forEach(metadataProcess -> {
            String type = metadataProcess.getTrackingIdType();
            List<Reference> references = new ArrayList<>();
            if (idoc.getE1ehpao().getE1ehptid() != null) {
                String refSys = idoc.getE1ehpao().getAppsys();
                idoc.getE1ehpao().getE1ehptid().forEach(e1ehptid -> {
                    String refType = e1ehptid.getTrxcod();
                    String refId = e1ehptid.getTrxid();
                    if(refType.isEmpty()){
                        throw new IntegrationIDocValidationException("REF_TYPE_IS_NULL", new Object[]{});
                    }else if(refId.isEmpty()){
                        throw new IntegrationIDocValidationException("REF_ID_IS_NULL", new Object[]{});
                    }else if(refType.equals(type) && refId.equals(id)){
                        return;
                    }
                    Reference reference = new Reference();
                    reference.setReferenceType(TRACKING);
                    String refAltKey = ALT_KEY_HEADER + party + ":" + refSys + ":" + refType + ":" + refId;
                    reference.setAltKey(refAltKey);
                    reference.setValidFrom(this.convertToZoneDateTime(e1ehptid.getTimzon(), e1ehptid.getStartDate()));
                    reference.setValidTo(this.convertToZoneDateTime(e1ehptid.getTimzon(), e1ehptid.getEndDate()));
                    if(e1ehptid.getAction() == null || ActionType.fromValue(e1ehptid.getAction()) == null){
                        throw new IntegrationIDocValidationException("ACTION_IS_NULL", new Object[]{});
                    }
                    reference.setAction(ActionType.fromValue(e1ehptid.getAction()).name());
                    references.add(reference);
                });
            }

            String trackedProcessType = metadataProcess.getTrackedProcessType();
            CurrentMetadataEntity tpForWrite = this.getTrackedProcessEventEntity(trackedProcessType);
            String iDocConfigJsonString = this.getIDocConfig(getNamespaceFromType(trackedProcessType));
            JsonObject configJson = null;
            JsonObject iDocMapping = null;
            if (iDocConfigJsonString != null) {
                configJson = JsonUtils.generateJsonObjectFromJsonString(iDocConfigJsonString);
                iDocMapping = getIDocMappingByType(configJson, trackedProcessType, true);
            }
            String altKey = ALT_KEY_HEADER + party + ":" + system + ":" + type + ":" + id;
            List<E1ehpcp> actualBusinessTimeStampE1epcp = idoc.getE1ehpao().getE1ehpcp().stream()
                    .filter(e1ehpcp -> e1ehpcp.getParamname().equals(ACTUAL_BUSINESS_DATETIME))
                    .collect(Collectors.toList());
            List<E1ehpcp> actualBusinessTimeZoneE1epcp = idoc.getE1ehpao().getE1ehpcp().stream()
                    .filter(e1ehpcp -> e1ehpcp.getParamname().equals(ACTUAL_BUSINESS_TIMEZONE))
                    .collect(Collectors.toList());

            String actualBusinessTimeStamp = actualBusinessTimeStampE1epcp.isEmpty() ? null : actualBusinessTimeStampE1epcp.get(0).getValue();
            String actualBusinessTimeZone = actualBusinessTimeZoneE1epcp.isEmpty() ? null : actualBusinessTimeZoneE1epcp.get(0).getValue();
            actualBusinessTimeStamp = this.convertToZoneDateTime(actualBusinessTimeZone, actualBusinessTimeStamp);
            List<PlannedEvent> plannedEventList = new ArrayList<>();
            if (idoc.getE1ehpao().getE1ehpee() != null) {
                JsonObject finalConfigJson = configJson;
                idoc.getE1ehpao().getE1ehpee().forEach(e1ehpee -> {
                    String eventCode = e1ehpee.getMilestone();
                    String eventType = mappingEventCodeToEventType(eventCode, finalConfigJson);
                    if(eventType != null){
                        String plannedBusinessTimeZone = e1ehpee.getEvtExpTzone();
                        String plannedTechnicalTimeZone = e1ehpee.getMsgExpTzone();
                        String eventMatchKey = null;
                        String plannedTechnicalTimestamp = null;
                        try {
                            plannedTechnicalTimestamp = this.convertToZoneDateTime(plannedTechnicalTimeZone, e1ehpee.getMsgExpDatetime());
                        }catch (TimeConvertException e){
                            logService.warn(e.getMessage());
                        }
                        String plannedTechTsEarliest = null;
                        try {
                            plannedTechTsEarliest = this.convertToZoneDateTime(plannedTechnicalTimeZone, e1ehpee.getMsgErExpDtime());
                        }catch (TimeConvertException e) {
                            logService.warn(e.getMessage());
                        }
                        String plannedTechTsLatest = null;
                        try{
                            plannedTechTsLatest = this.convertToZoneDateTime(plannedTechnicalTimeZone, e1ehpee.getMsgLtExpDtime());
                        }catch (TimeConvertException e){
                            logService.warn(e.getMessage());
                        }
                        String plannedBusinessTimestamp = null;
                        try {
                            plannedBusinessTimestamp = this.convertToZoneDateTime(plannedBusinessTimeZone, e1ehpee.getEvtExpDatetime());
                        }catch (TimeConvertException e){
                            logService.warn(e.getMessage());
                        }
                        String plannedBizTsEarliest = null;
                        try {
                            plannedBizTsEarliest = this.convertToZoneDateTime(plannedBusinessTimeZone, e1ehpee.getEvtErExpDtime());
                        }catch (TimeConvertException e){
                            logService.warn(e.getMessage());
                        }
                        String plannedBizTsLatest = null;
                        try {
                            plannedBizTsLatest = this.convertToZoneDateTime(plannedBusinessTimeZone, e1ehpee.getEvtLtExpDtime());
                        }catch (TimeConvertException e){
                            logService.warn(e.getMessage());
                        }

                        plannedEventList.add(new PlannedEvent(eventType, null, eventMatchKey, plannedTechnicalTimestamp,
                                plannedTechTsEarliest, plannedTechTsLatest, plannedBusinessTimestamp,
                                plannedBizTsEarliest, plannedBizTsLatest, plannedBusinessTimeZone));
                    }
                });
            }
            TrackedProcess tp = new TrackedProcess(altKey, trackedProcessType, actualBusinessTimeStamp,
                    actualBusinessTimeZone, plannedEventList.isEmpty() ? null : plannedEventList, references.isEmpty() ? null : references);
            JsonObject tpJson = JsonUtils.generateJsonElementFromBean(tp).getAsJsonObject();
            tpJson = mappingUserFields(idoc, null, tpJson, iDocMapping, tpForWrite);
            trackedProcessesMap.put(tp.getTrackedProcessType(), tpJson);
        });
        return trackedProcessesMap;
    }

    private String mappingEventCodeToEventType(String eventCode, JsonObject configJson ){
        if(eventCode == null){
            return null;
        }
        JsonArray eventTypeConfigs = configJson.getAsJsonArray(EVENT_TYPES);
        ArrayList<String> resultList = new ArrayList<>();
        eventTypeConfigs.forEach(config -> {
            JsonObject element = config.getAsJsonObject();
            if(eventCode.equals(element.getAsJsonObject(IDOC_MAPPING).get(ERP_EVENT_CODE).getAsString())){
                resultList.add(element.get(NAME).getAsString());
            }
        });
        return resultList.isEmpty()? null:resultList.get(0);
    }

    /**
     * Mapping user fields
     * @param tpiDoc IDoc object
     * @param json Event or TP JSON
     * @param iDocMapping IDocMapping config
     * @param forWriteEntity forWrite Metadata Entity
     * @return Mapped Event or TP
     */
    private JsonObject mappingUserFields(TPIDoc tpiDoc, EventIDoc eventIDoc, JsonObject json, JsonObject iDocMapping, CurrentMetadataEntity forWriteEntity) {
        MetadataEntity currentEntity = forWriteEntity.getCurrentEntity();
        if(iDocMapping == null || !iDocMapping.has(FIELD_MAPPING)){
            return json;
        }
        iDocMapping.get(FIELD_MAPPING).getAsJsonArray().forEach(jsonElement -> {
            JsonObject obj = jsonElement.getAsJsonObject();
            String fieldName = obj.get(FIELD).getAsString();
            List<MetadataEntityElement> elemList = currentEntity.getElements().stream()
                    .filter(metadataEntityElement -> metadataEntityElement.getName().equals(fieldName))
                    .collect(Collectors.toList());
            if (elemList.isEmpty()) {
                logService.info(currentEntity.getElements().toString());
                logService.error("FIELD_NOT_FOUND_IN_METADATA:" + fieldName);
                throw new IntegrationIDocValidationException(MESSAGE_CODE_FIELD_NOT_FOUND_IN_METADATA, new Object[]{fieldName});
            }
            MetadataEntityElement element = elemList.get(0);
            String fieldType = element.getType().getValue();
            if (fieldType.equals(CDS_COMPOSITION)) {
                String target = element.getTarget();
                MetadataEntity targetEntity = forWriteEntity.getAllRelatedEntityMap().get(target);
                JsonArray composition = obj.get(COMPOSITION).getAsJsonArray();
                JsonArray itemLevel = handleCompositionMapping(composition,targetEntity,tpiDoc,eventIDoc);
                json.add(fieldName, itemLevel);

            } else {
                String idocField = obj.get(IDOC_FIELD).getAsString();
                String idocSegment = obj.get(IDOC_SEGMENT).getAsString();
                if (idocSegment.equals(E1EHPCP)) {
                    List<E1ehpcp> e1ehpcpList = tpiDoc.getE1ehpao().getE1ehpcp();
                    List<E1ehpcp> fieldList = e1ehpcpList.stream().filter(e1ehpcp -> e1ehpcp.getParamname().equals(idocField)
                            && e1ehpcp.getParamindex().equals(PARAM_INDEX_0)).collect(Collectors.toList());
                    if (!fieldList.isEmpty()) {
                        E1ehpcp matchedE1ehpcp = fieldList.get(0);
                        switch (CDS_TYPE_MAP.get(fieldType)) {
                            case STRING:
                                json.addProperty(fieldName, matchedE1ehpcp.getValue());
                                break;
                            case INTEGER:
                                json.addProperty(fieldName, Integer.valueOf(matchedE1ehpcp.getValue()));
                                break;
                            case DECIMAL:
                                json.addProperty(fieldName, Double.valueOf(matchedE1ehpcp.getValue()));
                                break;
                            case BOOLEAN:
                                json.addProperty(fieldName, Boolean.valueOf(matchedE1ehpcp.getValue()));
                                break;
                            case ASSOCIATION:
                                json.addProperty(fieldName + ALT_KEY, matchedE1ehpcp.getValue());
                                break;
                            default:
                                throw new IntegrationIDocRuntimeException(MESSAGE_CODE_CDS_TYPE_NOT_FOUND, new Object[]{});

                        }
                    }
                }
                if(idocSegment.equals(E1EVMPAR)){
                    List<E1evmpar> e1evmparList = eventIDoc.getE1evmhdr02().getE1evmpar();
                    List<E1evmpar> fieldList = e1evmparList.stream().filter(e1evmpar -> e1evmpar.getParamname().equals(idocField)
                            && e1evmpar.getParamindex().equals(PARAM_INDEX_0)).collect(Collectors.toList());
                    if (!fieldList.isEmpty()) {
                        E1evmpar matchedE1evmpar = fieldList.get(0);
                        switch (CDS_TYPE_MAP.get(fieldType)) {
                            case STRING:
                                json.addProperty(fieldName, matchedE1evmpar.getValue());
                                break;
                            case INTEGER:
                                json.addProperty(fieldName, Integer.valueOf(matchedE1evmpar.getValue()));
                                break;
                            case DECIMAL:
                                json.addProperty(fieldName, Double.valueOf(matchedE1evmpar.getValue()));
                                break;
                            case BOOLEAN:
                                json.addProperty(fieldName, Boolean.valueOf(matchedE1evmpar.getValue()));
                                break;
                            case ASSOCIATION:
                                json.addProperty(fieldName + ALT_KEY, matchedE1evmpar.getValue());
                                break;
                            default:
                                throw new IntegrationIDocRuntimeException(MESSAGE_CODE_CDS_TYPE_NOT_FOUND, new Object[]{});

                        }
                    }
                }
            }
        });
        return json;
    }

    private JsonArray handleCompositionMapping(JsonArray composition, MetadataEntity targetEntity, TPIDoc tpiDoc, EventIDoc eventIDoc) {
        JsonArray result = new JsonArray();
        Map<JsonObject, List<E1ehpcp>> tpItemLevelFieldListMap = new HashMap<>();
        Map<JsonObject, List<E1evmpar>> eventItemLevelFieldListMap = new HashMap<>();
        composition.forEach(jsonElement -> {
            JsonObject obj = jsonElement.getAsJsonObject();
            String fieldName = obj.get(FIELD).getAsString();
            String idocField = obj.get(IDOC_FIELD).getAsString();
            String idocSegment = obj.get(IDOC_SEGMENT).getAsString();
            List<MetadataEntityElement> elemList = targetEntity.getElements().stream()
                    .filter(metadataEntityElement -> metadataEntityElement.getName().equals(fieldName))
                    .collect(Collectors.toList());
            if (elemList.isEmpty()) {
                logService.info(targetEntity.getElements().toString());
                logService.error("FIELD_NOT_FOUND_IN_METADATA:" + fieldName);
                throw new IntegrationIDocValidationException(MESSAGE_CODE_FIELD_NOT_FOUND_IN_METADATA, new Object[]{fieldName});
            }
            MetadataEntityElement element = elemList.get(0);
            String fieldType = element.getType().getValue();
            if (!fieldType.equals(CDS_COMPOSITION)) {
                if (idocSegment.equals(E1EHPCP)) {
                    List<E1ehpcp> e1ehpcpList = tpiDoc.getE1ehpao().getE1ehpcp();
                    List<E1ehpcp> fieldList = e1ehpcpList.stream().filter(e1ehpcp -> e1ehpcp.getParamname().equals(idocField)
                            && !e1ehpcp.getParamindex().equals(PARAM_INDEX_0)).sorted(Comparator.comparing(E1ehpcp::getParamindex))
                            .collect(Collectors.toList());
                    if (!fieldList.isEmpty()) {
                        JsonObject fieldTypeObj = new JsonObject();
                        fieldTypeObj.addProperty(NAME,fieldName);
                        fieldTypeObj.addProperty(TYPE,fieldType);
                        tpItemLevelFieldListMap.put(fieldTypeObj, fieldList);
                    }
                }
                if (idocSegment.equals(E1EVMPAR)) {
                    List<E1evmpar> e1evmparList = eventIDoc.getE1evmhdr02().getE1evmpar();
                    List<E1evmpar> fieldList = e1evmparList.stream().filter(e1evmpar -> e1evmpar.getParamname().equals(idocField)
                            && !e1evmpar.getParamindex().equals(PARAM_INDEX_0)).sorted(Comparator.comparing(E1evmpar::getParamindex))
                            .collect(Collectors.toList());
                    if (!fieldList.isEmpty()) {
                        JsonObject fieldTypeObj = new JsonObject();
                        fieldTypeObj.addProperty(NAME,fieldName);
                        fieldTypeObj.addProperty(TYPE,fieldType);
                        eventItemLevelFieldListMap.put(fieldTypeObj, fieldList);
                    }
                }
            }
        });
        if(!tpItemLevelFieldListMap.isEmpty()){
            addE1ehpcpItems(result, tpItemLevelFieldListMap);
        }
        if(!eventItemLevelFieldListMap.isEmpty()){
            addE1evmparItems(result, eventItemLevelFieldListMap);
        }
        return result;
    }

    private void addE1ehpcpItems(JsonArray result,  Map<JsonObject, List<E1ehpcp>> itemLevelFieldListMap){
        int i = 0;
        while (true) {
            JsonObject newObj = new JsonObject();
            JsonObject fieldTypeObj;
            List<E1ehpcp> value;
            int count = 0;
            for (Map.Entry<JsonObject, List<E1ehpcp>> entry : itemLevelFieldListMap.entrySet()) {
                fieldTypeObj = entry.getKey();
                value = entry.getValue();
                if (i < value.size()) {
                    String newFieldType = fieldTypeObj.get(TYPE).getAsString();
                    String newFieldName = fieldTypeObj.get(NAME).getAsString();
                    switch (CDS_TYPE_MAP.get(newFieldType)) {
                        case STRING:
                            newObj.addProperty(newFieldName, value.get(i).getValue());
                            break;
                        case INTEGER:
                            newObj.addProperty(newFieldName, Integer.valueOf(value.get(i).getValue()));
                            break;
                        case DECIMAL:
                            newObj.addProperty(newFieldName, Double.valueOf(value.get(i).getValue()));
                            break;
                        case BOOLEAN:
                            newObj.addProperty(newFieldName, Boolean.valueOf(value.get(i).getValue()));
                            break;
                        case ASSOCIATION:
                            newObj.addProperty(newFieldName + ALT_KEY, value.get(i).getValue());
                            break;
                        default:
                            throw new IntegrationIDocRuntimeException(MESSAGE_CODE_CDS_TYPE_NOT_FOUND, new Object[]{});
                    }
                } else {
                    count++;
                }
            }
            if (count >= itemLevelFieldListMap.size()) {
                break;
            }
            result.add(newObj);
            i++;
        }
    }
    private void addE1evmparItems(JsonArray result,  Map<JsonObject, List<E1evmpar>> itemLevelFieldListMap){
        int i = 0;
        while (true) {
            JsonObject newObj = new JsonObject();
            JsonObject fieldTypeObj;
            List<E1evmpar> value;
            int count = 0;
            for (Map.Entry<JsonObject, List<E1evmpar>> entry : itemLevelFieldListMap.entrySet()) {
                fieldTypeObj = entry.getKey();
                value = entry.getValue();
                if (i < value.size()) {
                    String newFieldType = fieldTypeObj.get(TYPE).getAsString();
                    String newFieldName = fieldTypeObj.get(NAME).getAsString();
                    switch (CDS_TYPE_MAP.get(newFieldType)) {
                        case STRING:
                            newObj.addProperty(newFieldName, value.get(i).getValue());
                            break;
                        case INTEGER:
                            newObj.addProperty(newFieldName, Integer.valueOf(value.get(i).getValue()));
                            break;
                        case DECIMAL:
                            newObj.addProperty(newFieldName, Double.valueOf(value.get(i).getValue()));
                            break;
                        case BOOLEAN:
                            newObj.addProperty(newFieldName, Boolean.valueOf(value.get(i).getValue()));
                            break;
                        case ASSOCIATION:
                            newObj.addProperty(newFieldName + ALT_KEY, value.get(i).getValue());
                            break;
                        default:
                            throw new IntegrationIDocRuntimeException(MESSAGE_CODE_CDS_TYPE_NOT_FOUND, new Object[]{});
                    }
                } else {
                    count++;
                }
            }
            if (count >= itemLevelFieldListMap.size()) {
                break;
            }
            result.add(newObj);
            i++;
        }
    }
    private JsonObject getIDocMappingByType(JsonObject config, String type, boolean isTP) {
        String TYPES = isTP ? PROCESS_TYPES : EVENT_TYPES;
        if (!config.has(TYPES)) {
            return null;
        }
        ArrayList<JsonObject> resultList = new ArrayList<>();
        config.get(TYPES).getAsJsonArray().forEach(jsonElement -> {
            JsonObject element = jsonElement.getAsJsonObject();
            if (element.has(NAME) && element.get(NAME).getAsString().equals(type)) {
                resultList.add(element.get(IDOC_MAPPING).getAsJsonObject());
            }
        });
        return resultList.isEmpty()? null : resultList.get(0);
    }

    private String getNamespaceFromType(String type) {
        String namespaceWithContext = CsnParser.cutStringFromLastDot(type);
        return CsnParser.cutStringFromLastDot(namespaceWithContext);
    }

    @Override
    public JsonObject convertActualEvent(SoapEnvEnvelopeEvent soapEnvEnvelopeEvent) {
        EventIDoc iDoc = soapEnvEnvelopeEvent.getSoapenvbody().getEvmsta02().getIdoc();
        ActualEvent actualEvent = new ActualEvent();
        actualEvent.setEventReasonText(iDoc.getE1evmhdr02().getSrctx());
        actualEvent.setEventReasonCode(iDoc.getE1evmhdr02().getSrcid());
        String party = iCurrentAccessContext.getBusinessPartner().getLbnId();
        String system = iDoc.getEdiDc40().getSndprn();
        String trackingIdType = iDoc.getE1evmhdr02().getE1evmtid().getTrxcod();
        List<MetadataProcess> tpList = getTrackedProcessService.getTrackedProcessFromTrackingIdType(trackingIdType);
        if(tpList.isEmpty()){
            throw new IntegrationIDocValidationException(MESSAGE_CODE_TRACKING_ID_TYPE_NOT_FOUND, new Object[]{});
        }
        String eventCode = iDoc.getE1evmhdr02().getEvtid();
        String iDocConfigJsonString = this.getIDocConfig(getNamespaceFromType(tpList.get(0).getTrackedProcessType()));
        JsonObject configJson = null;
        JsonObject iDocMapping = null;
        String eventType = null;
        if (iDocConfigJsonString != null) {
            configJson = JsonUtils.generateJsonObjectFromJsonString(iDocConfigJsonString);
            eventType = mappingEventCodeToEventType(eventCode, configJson);
            iDocMapping = getIDocMappingByType(configJson, eventType, false);
        }
        if (eventType == null) {
            throw new IntegrationIDocValidationException(MESSAGE_CODE_EVENT_TYPE_NOT_FOUND, new Object[]{});
        }
        actualEvent.setEventType(eventType);
        String id = iDoc.getE1evmhdr02().getE1evmtid().getTrxid();
        String altKey = ALT_KEY_HEADER + party + ":" + system + ":" + trackingIdType + ":" + id;
        actualEvent.setAltKey(altKey);
        String objectType = iDoc.getE1evmhdr02().getE1evmlid().get(0).getLoccod();
        String locationId = iDoc.getE1evmhdr02().getE1evmlid().get(0).getLocid1();
        //TODO: LOCATION ALT KEY ?
        String locationAltKey = ALT_KEY_HEADER + party + ":" + system + ":" + LOCATION + ":" + objectType + ":" + locationId;
        actualEvent.setLocationAltKey(locationAltKey);
        String actualBusinessTimeZone = iDoc.getE1evmhdr02().getEvtzon();
        String datetime = "0" + iDoc.getE1evmhdr02().getEvtdat() + iDoc.getE1evmhdr02().getEvttim();
        String actualBusinessTimestamp = this.convertToZoneDateTime(actualBusinessTimeZone, datetime);
        actualEvent.setActualBusinessTimestamp(actualBusinessTimestamp);
        actualEvent.setActualBusinessTimeZone(actualBusinessTimeZone);
        if (iDoc.getE1evmhdr02().getE1evmref02() != null) {
            List<Reference> references = new ArrayList<>();
            iDoc.getE1evmhdr02().getE1evmref02().forEach(e1evmref02 -> {
                String refSys = e1evmref02.getAppsys();
                String refId = e1evmref02.getAppobjid();
                String refAppObjType = e1evmref02.getAppobjtype();
                List<MetadataProcess> metadataProcessesList = getTrackedProcessService.getTrackedProcessFromAOT(refAppObjType);
                metadataProcessesList.forEach(metadataProcess -> {
                    Reference reference = new Reference();
                    reference.setReferenceType(TRACKING);
                    String refType = metadataProcess.getTrackingIdType();
                    String refAltKey = ALT_KEY_HEADER + party + ":" + refSys + ":" + refType + ":" + refId;
                    reference.setAltKey(refAltKey);
                    reference.setValidFrom(this.convertToZoneDateTime(e1evmref02.getTimzon(), e1evmref02.getStartDate()));
                    reference.setValidTo(this.convertToZoneDateTime(e1evmref02.getTimzon(), e1evmref02.getEndDate()));
                    reference.setAction(ActionType.fromValue(e1evmref02.getAction()).name());
                    references.add(reference);
                });
            });
            if (references.isEmpty()) {
                throw new IntegrationIDocValidationException(MESSAGE_CODE_APPLICATION_OBJECT_TYPE_NOT_FOUND, new Object[]{});
            }
            actualEvent.setReferences(references);
        }
        CurrentMetadataEntity eventForWrite = this.getEventForWriteEntity(eventType);
        JsonObject eventJson = JsonUtils.generateJsonElementFromBean(actualEvent).getAsJsonObject();
        mappingUserFields(null, iDoc, eventJson, iDocMapping, eventForWrite);
        JsonObject res = new JsonObject();
        res.addProperty(TYPE, eventType);
        res.add(BODY, eventJson);
        return res;
    }

    @Override
    public String getIDocConfig(String modelNamespace) {
        return metadataManagement.getMetadataProjectFileFieldInfo(modelNamespace,
                MetadataConstants.MetadataProjectFileField.IDOC_CONFIG);
    }


    private void loadTimeZoneMapping() throws IOException {
        ClassLoader classLoader = getClass().getClassLoader();
        if (classLoader != null) {
            try (InputStream input = classLoader.getResourceAsStream(TIMEZONE_MAPPING_FILE)) {
                if (input != null) {
                    properties.load(input);
                }
            }
        }
    }

    @PostConstruct
    public void init() {
        try {
            this.loadTimeZoneMapping();
        } catch (IOException e) {
            throw new IntegrationIDocRuntimeException("TimeZone Mapping File could not be loaded", new Object[]{});
        }
    }

    private ZoneId getZoneId(String abapTimeZone) {

        ZoneId zoneId;

        // First try to find an entry in Mapping property file
        // Second try maybe it was an existing Java timeZone sent

        String tz = properties.getProperty(abapTimeZone);

        if (tz == null) {
            tz = abapTimeZone;
        }

        try {
            zoneId = ZoneId.of(tz);
        } catch (ZoneRulesException e) {
            throw new TimeConvertException(MESSAGE_CODE_TIMEZONE_CAN_NOT_MAP, new Object[]{tz});
        }

        return zoneId;
    }

    @Override
    public String convertToZoneDateTime(String timezone, String datetime) {
        if (datetime == null) {
            throw new TimeConvertException(MESSAGE_CODE_TIME_IS_NULL, new Object[]{});
        }
        ZoneId zoneId = ZoneId.systemDefault();
        String time;
        if (timezone != null) {
            zoneId = getZoneId(timezone);
        }
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("0yyyyMMddHHmmss").withZone(zoneId);
        DateTimeFormatter gttTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ssxxx");
        try {
            time = ZonedDateTime.parse(datetime, formatter).format(gttTimeFormatter);
        } catch (DateTimeParseException e) {
            throw new TimeConvertException(MESSAGE_CODE_TIME_CAN_NOT_PARSER, new Object[]{datetime});
        }
        return time;
    }

    @Override
    public CurrentMetadataEntity getTrackedProcessEventEntity(String trackedProcessType) {
        return metadataManagement.getProcessEventForWriteEntity(trackedProcessType);
    }

    @Override
    public CurrentMetadataEntity getEventForWriteEntity(String eventType) {
        return metadataManagement.getEventForWriteEntity(eventType);
    }

    @Override
    public String getLbnIdByTenantId(String tenantId) {
        BusinessPartner bp = bpService.getBPByTenantId(tenantId);
        if(bp == null) {
            throw new IntegrationIDocRuntimeException("LBN_ID_NOT_FOUND", new Object[]{});
        }
        return bp.getLbnId();
    }


    public enum ActionType {
        ADD, DELETE, NOCHANGE;

        @Override
        public String toString() {
            switch (this) {
                case ADD:
                    return "A";
                case DELETE:
                    return "D";
                case NOCHANGE:
                    return "";
            }
            return "";
        }

        public static ActionType fromValue(String value) {
            switch (value) {
                case "A":
                    return ADD;
                case "D":
                    return DELETE;
                case "":
                    return NOCHANGE;
                default:
                    return null;
            }
        }
    }

}
