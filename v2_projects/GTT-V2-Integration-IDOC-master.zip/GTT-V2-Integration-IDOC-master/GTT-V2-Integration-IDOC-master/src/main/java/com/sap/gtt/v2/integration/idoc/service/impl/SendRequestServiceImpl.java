package com.sap.gtt.v2.integration.idoc.service.impl;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.sap.gtt.v2.configuration.GTTRestTemplate;
import com.sap.gtt.v2.core.management.metadata.IMetadataManagement;
import com.sap.gtt.v2.integration.idoc.exception.IntegrationIDocRuntimeException;
import com.sap.gtt.v2.integration.idoc.exception.IntegrationIDocValidationException;
import com.sap.gtt.v2.integration.idoc.service.ISendRequestService;
import com.sap.gtt.v2.integration.idoc.utils.Utils;
import com.sap.gtt.v2.log.TenantAwareLogService;
import com.sap.gtt.v2.util.GTTUtils;
import com.sap.gtt.v2.util.JsonUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static com.sap.gtt.v2.integration.idoc.utils.Constants.BODY;
import static com.sap.gtt.v2.integration.idoc.utils.Constants.TYPE;

/**
 * @author i311486
 */
@Service
public class SendRequestServiceImpl implements ISendRequestService {
    private static final String SUCCESS = "Success";
    private static final String WRITE_SERVICE_PATH = "/sap/logistics/gtt/inbound/rest/v1/";
    private static final String REQUEST_ID = "requestId";
    private static final String WRITE_SERVICE_ID = "writeServiceId";
    @Autowired
    private GTTRestTemplate restTemplate;

    @Autowired
    private TenantAwareLogService logService;

    @Autowired
    IMetadataManagement metadataManagement;

    @Autowired
    private MessageLogService messageLogService;

    @Value("${GTT_V2_WRITE_SERVICE_URL}")
    private String writeServiceUrl;

    @Override
    public JsonArray sendTPToGTT(Map<String, JsonObject> trackedProcessMap, String requestId, String writeServiceId) {
        logService.info("Send TP to GTT");

        List<String> responseEntityList = new ArrayList<>();
        trackedProcessMap.entrySet().parallelStream().forEach(entry -> {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.set(REQUEST_ID, requestId);
            headers.set(WRITE_SERVICE_ID, writeServiceId);
            ResponseEntity<String> response;
            String body = entry.getValue().toString();
            String url = genTPUrl(entry.getKey());
            String newReqId = GTTUtils.UUIDUtils.generateTimeBasedUUID().toString();
            messageLogService.saveRequestPayload(newReqId, requestId, null, body, url);
            try {
                headers.setContentType(MediaType.APPLICATION_JSON);
                logService.info(body);
                response = restTemplate.exchange(url, HttpMethod.POST, headers, body, String.class);
                if (response.getBody() == null && response.getStatusCode().is2xxSuccessful()) {
                    responseEntityList.add(SUCCESS);
                } else {
                    responseEntityList.add(response.getBody());
                }
            } catch (HttpClientErrorException e) {
                logService.error(e.getLocalizedMessage());
                if (!e.getStatusCode().is4xxClientError()) {
                    throw new IntegrationIDocRuntimeException(e.getResponseBodyAsString(), e.getCause(), null, null);
                } else {
                    throw new IntegrationIDocValidationException(e.getResponseBodyAsString(), e.getCause(), null, null);
                }
            }
        });
        return JsonUtils.generateJsonArrayFromList(responseEntityList);
    }

    private String genTPUrl(String TPType) {
        StringBuilder url = new StringBuilder(writeServiceUrl);
        url.append(WRITE_SERVICE_PATH);
        String path = Utils.getPath(TPType, true);
        url.append(path);
        return url.toString();
    }

    private String getEventUrl(String eventType) {
        StringBuilder url = new StringBuilder(writeServiceUrl);
        url.append(WRITE_SERVICE_PATH);
        String path = Utils.getPath(eventType, false);
        url.append(path);
        return url.toString();
    }

    @Override
    public String sendEventToGTT(JsonObject actualEventObj, String requestId, String writeServiceId) {
        logService.info("Send Event to GTT");
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set(REQUEST_ID, requestId);
        headers.set(WRITE_SERVICE_ID, writeServiceId);
        String responseBody = null;
        String body = actualEventObj.get(BODY).toString();
        logService.info(body);
        String url = getEventUrl(actualEventObj.get(TYPE).getAsString());
        String newReqId = GTTUtils.UUIDUtils.generateTimeBasedUUID().toString();
        messageLogService.saveRequestPayload(newReqId, requestId, null, body, url);
        try {
            responseBody = restTemplate.exchange(url, HttpMethod.POST, headers, body, String.class).getBody();
        } catch (HttpClientErrorException e) {
            throw new IntegrationIDocRuntimeException(e.getResponseBodyAsString(), e.getCause(), null, null);
        }
        return responseBody;

    }
}
