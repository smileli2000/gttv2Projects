
package com.sap.gtt.v2.integration.idoc.domain.idoc;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author i311486
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class E1evmtid {


    private String trxcod;
    private String trxid;


    public void setTrxcod(String trxcod) {
         this.trxcod = trxcod;
     }
     public String getTrxcod() {
         return trxcod;
     }

    public void setTrxid(String trxid) {
         this.trxid = trxid;
     }
     public String getTrxid() {
         return trxid;
     }

}