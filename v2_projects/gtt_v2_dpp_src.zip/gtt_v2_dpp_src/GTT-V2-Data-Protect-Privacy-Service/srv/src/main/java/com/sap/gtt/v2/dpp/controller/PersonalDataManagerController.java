/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.gtt.v2.dpp.controller;

import com.google.gson.JsonElement;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.sap.gtt.v2.configuration.ISAPCloudPlatformAgent;
import com.sap.gtt.v2.core.management.metadata.IMetadataManagement;
import com.sap.gtt.v2.util.JsonUtils;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.WebRequest;

/**
 * @author I326335
 */
@RestController
@RequestMapping(PersonalDataManagerController.URL_ROOT)
public class PersonalDataManagerController {

    public static final String URL_ROOT = "/dpp/service/v1";
    public static final String URL_METADATA = "/metadata";
    public static final String URL_DATA_SUBJECT_ID = "/data_subject_identity";
    public static final String URL_ENTITY = "/{entityType}";
    
    public static final String PARAM_EVENT_TYPE = "entityType";
    public static final String PARAM_DATA_SUBJECT_ID = "dataSubjectId";
    
    @Autowired
    private ISAPCloudPlatformAgent.ICurrentAccessContext currentContext;

    @GetMapping(path = URL_METADATA, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<String> generateMetadata(WebRequest request) {
        IMetadataManagement metadataManagement = getMetadataService();
        String pdmSchema = metadataManagement.getPdmSchema();
        if (StringUtils.isAllBlank(pdmSchema)) {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            return new ResponseEntity<>("pdmSchema is empty", headers, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity(pdmSchema, HttpStatus.OK);
    }

    @GetMapping(path = URL_DATA_SUBJECT_ID, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<String> getDataSubjectId(@RequestParam(value = PARAM_DATA_SUBJECT_ID) String dataSubjectId) {
        IMetadataManagement metadataManagement = getMetadataService();
        boolean isDataSubjectIdValueExistsInDB = metadataManagement.isDataSubjectIdValueExistsInDB(dataSubjectId);
        JsonArray resultList = new JsonArray();
        if (isDataSubjectIdValueExistsInDB) {
            JsonObject jsonOrg = new JsonObject();
            jsonOrg.addProperty(PARAM_DATA_SUBJECT_ID, dataSubjectId);
            resultList.add(jsonOrg);
        }
        return new ResponseEntity<>(resultList.toString(), HttpStatus.OK);
    }

    @GetMapping(path = URL_ENTITY, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<String> getEntityData(@PathVariable(PARAM_EVENT_TYPE) String entityType,
        @RequestParam(value = PARAM_DATA_SUBJECT_ID) String dataSubjectId) {
        List<Map<String, Object>> dataInfo = getMetadataService().getPdmDataInfo(entityType, dataSubjectId);
        JsonElement results = JsonUtils.generateJsonElementFromBean(dataInfo);
        return new ResponseEntity<>(results.toString(), HttpStatus.OK);
    }

    private IMetadataManagement getMetadataService() {
        return currentContext.createBusinessOperator().getMetadataManagement();
    }
}
