package com.sap.gtt.v2.dpp.configuration;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.ExpressionUrlAuthorizationConfigurer;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer;

import com.sap.gtt.v2.configuration.AbstractCloudSecurityConfiguration;
import com.sap.gtt.v2.dpp.controller.PersonalDataManagerController;

/**
 *
 * @author I053866
 *
 */
@Configuration
@EnableWebSecurity
@EnableResourceServer
@EnableGlobalMethodSecurity(prePostEnabled = true)
@Profile("cloud")
public class CloudSecurityConfiguration extends AbstractCloudSecurityConfiguration {

    private static final String SCOPE_PERSONAL_DATA_MANAGER = "PersonalDataManagerUser";
    private static final String URL_APPENDIX = "**/**";

    @Override
    public ExpressionUrlAuthorizationConfigurer<HttpSecurity>.ExpressionInterceptUrlRegistry setProtectedExpressionInterceptUrlRegistry(
        ExpressionUrlAuthorizationConfigurer<HttpSecurity>.ExpressionInterceptUrlRegistry expressionInterceptUrlRegistry) {

        ExpressionUrlAuthorizationConfigurer<HttpSecurity>.ExpressionInterceptUrlRegistry registry = super.setProtectedExpressionInterceptUrlRegistry(expressionInterceptUrlRegistry);
        registry.antMatchers(HttpMethod.GET, PersonalDataManagerController.URL_ROOT + URL_APPENDIX).access(getScopeCheckExpress(SCOPE_PERSONAL_DATA_MANAGER));

        return registry;
    }

}
