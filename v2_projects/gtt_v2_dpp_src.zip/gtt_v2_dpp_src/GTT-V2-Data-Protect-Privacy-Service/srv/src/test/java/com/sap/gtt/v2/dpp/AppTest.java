/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.gtt.v2.dpp;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author I326335
 */
public class AppTest {
    
    public AppTest() {
    }

    /**
     * Test of main method, of class App.
     */
    @Test(expected = Exception.class)
    public void testMain() {
        String[] args = new String[]{};
        App.main(args);
    }
    
    @Test
    public void testGetMessageSourceBasenamesTobeAdded() {
        App app = new App();
        String[] names = app.getMessageSourceBasenamesTobeAdded();
        assertNotNull(names);
    }
}
