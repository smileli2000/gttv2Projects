/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.gtt.v2.dpp.controller;

import com.sap.gtt.v2.configuration.ISAPCloudPlatformAgent;
import com.sap.gtt.v2.core.management.metadata.IMetadataManagement;
import com.sap.gtt.v2.util.GTTUtils;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.runner.RunWith;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.BDDMockito.given;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

/**
 *
 * @author I326335
 */
@RunWith(MockitoJUnitRunner.class)
public class PersonalDataManagerControllerTest {
    @InjectMocks
    private PersonalDataManagerController personalDataManagerController;
    @Mock
    private ISAPCloudPlatformAgent.ICurrentAccessContext currentContext;
    
    public PersonalDataManagerControllerTest() {
    }

    @Before
    public void setup() {
        GTTUtils.BusinessOperator businessOperator = mock(GTTUtils.BusinessOperator.class);
        IMetadataManagement metadataManage = mock(IMetadataManagement.class);
        given(metadataManage.getPdmSchema()).willReturn("{}");
        Map<String, Object> entity = new HashMap<String, Object>(){{
            put("integer", new Integer(1));
            put("string", "1");
            put("float", new Float(1.1));
            put("date", new Date());
        }};
        ArrayList<Map<String, Object>> resultList = new ArrayList<>();
        resultList.add(entity);
        
        given(metadataManage.getPdmDataInfo(anyString(), anyString())).willReturn(resultList);
        given(metadataManage.isDataSubjectIdValueExistsInDB(anyString())).willReturn(true);
        given(businessOperator.getMetadataManagement()).willReturn(metadataManage);
        given(currentContext.createBusinessOperator()).willReturn(businessOperator);
    }

    /**
     * Test of generateMetadata method, of class PersonalDataManagerController.
     */
    @Test
    public void testGenerateMetadata() {
        ResponseEntity<String> response = personalDataManagerController.generateMetadata(null);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
    }

    /**
     * Test of getDataSubjectId method, of class PersonalDataManagerController.
     */
    @Test
    public void testGetDataSubjectId() {
        ResponseEntity<String> response = personalDataManagerController.getDataSubjectId("a@sap.com");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
    }

    /**
     * Test of getEntityData method, of class PersonalDataManagerController.
     */
    @Test
    public void testGetEntityData() {
        ResponseEntity<String> response = personalDataManagerController.getEntityData("com.gtt.model.trackedprocess", "a@sap.com");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
    }
    
}
