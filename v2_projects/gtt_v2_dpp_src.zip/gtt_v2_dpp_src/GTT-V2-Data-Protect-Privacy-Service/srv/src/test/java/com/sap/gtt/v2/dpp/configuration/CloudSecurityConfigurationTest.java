/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.gtt.v2.dpp.configuration;

import com.sap.gtt.v2.configuration.EnvironmentsConfiguration;
import com.sap.gtt.v2.configuration.ServiceInstancesMapping;
import java.util.HashMap;
import org.junit.Test;
import static org.junit.Assert.*;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;
import org.springframework.security.config.annotation.ObjectPostProcessor;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configurers.ExpressionUrlAuthorizationConfigurer;
import org.springframework.test.util.ReflectionTestUtils;

/**
 *
 * @author I326335
 */
public class CloudSecurityConfigurationTest {
    
    public CloudSecurityConfigurationTest() {
    }

    /**
     * Test of setProtectedExpressionInterceptUrlRegistry method, of class CloudSecurityConfiguration.
     */
    @Test
    public void testSetProtectedExpressionInterceptUrlRegistry() throws Exception {
        ServiceInstancesMapping serviceInstanceMapping = mock(ServiceInstancesMapping.class);
        given(serviceInstanceMapping.getUaaServiceInstance()).willReturn(mock(EnvironmentsConfiguration.VcapServiceParser.UaaServiceInstance.class));
        CloudSecurityConfiguration configuration = new CloudSecurityConfiguration();
        ReflectionTestUtils.setField(configuration, "serviceInstanceMapping", serviceInstanceMapping);
        HttpSecurity http = new HttpSecurity(mock(ObjectPostProcessor.class), mock(AuthenticationManagerBuilder.class), new HashMap<Class<? extends Object>, Object>());
        configuration.configure(http);
    }
    
}
