package com.sap.gtt.v2.metadataservice.configuration;

import com.sap.gtt.v2.configuration.ISAPCloudPlatformAgent;
import com.sap.gtt.v2.tenant.GTTTenantSetting;
import com.sap.gtt.v2.tenant.TenantService;
import com.sap.gtt.v2.util.SpringContextUtils;
import org.springframework.util.unit.DataSize;
import org.springframework.util.unit.DataUnit;

import javax.servlet.MultipartConfigElement;

public class GTTMultipartConfigElement extends MultipartConfigElement {

    public GTTMultipartConfigElement(String location) {
        super(location);
    }

    @Override
    public long getMaxFileSize() {
        ISAPCloudPlatformAgent.ICurrentAccessContext currentAccessContext = SpringContextUtils.getBean(ISAPCloudPlatformAgent.ICurrentAccessContext.class);
        TenantService tenantService = SpringContextUtils.getBean(TenantService.class);
        GTTTenantSetting setting = tenantService.get(currentAccessContext.getSubaccountId(), currentAccessContext.getCloneServiceInstanceId());
        int size = setting.getMMRateLimitMaxImportSize();
        return DataSize.of(size, DataUnit.MEGABYTES).toBytes();
    }
}