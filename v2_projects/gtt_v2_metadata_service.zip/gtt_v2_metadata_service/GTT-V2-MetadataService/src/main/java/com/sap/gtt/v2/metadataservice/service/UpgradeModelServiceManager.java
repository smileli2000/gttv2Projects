package com.sap.gtt.v2.metadataservice.service;

import com.sap.gtt.v2.configuration.ISAPCloudPlatformAgent;
import com.sap.gtt.v2.log.TenantAwareLogService;
import com.sap.gtt.v2.servicemanager.GTTInstance;
import com.sap.gtt.v2.tenant.TenantService;
import com.sap.gtt.v2.util.SpringContextUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UpgradeModelServiceManager {
    @Autowired
    private TenantService tenantService;

    @Autowired
    private TenantAwareLogService logService;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    public ISAPCloudPlatformAgent.ICurrentAccessContext currentAccessContext;

    public void upgradeAll() {
        List<GTTInstance> gttInstances = tenantService.getGTTInstances();
        logService.info(" in UpgradeModelServiceManager.upgradeAll, gttInstances is {} ", gttInstances.toString());
        for (GTTInstance gttInstance : gttInstances) {
            logService.info("begin upgrade for gttInstance of {}", gttInstance.getInstanceName());
            upgradeModel(gttInstance);
            logService.info("end upgrade for gttInstance of {}", gttInstance.getInstanceName());
        }
    }

    public void upgrade(String instance, String model) {
        GTTInstance gttInstance = tenantService.getGTTInstanceByName(instance);
        if (gttInstance != null) {
            if (StringUtils.isNotBlank(model)) {
                upgradeModel(gttInstance, model);
            } else {
                upgradeModel(gttInstance);
            }
        }
    }

    public void upgradeRetryAll(byte[] metadataByte) {
        List<GTTInstance> gttInstances = tenantService.getGTTInstances();
        logService.info(" in UpgradeModelServiceManager.upgradeAll, gttInstances is {} ", gttInstances.toString());
        for (GTTInstance gttInstance : gttInstances) {
            retryUpgradeModel(gttInstance, metadataByte);
        }
    }

    public void upgradeRetry(String instance, String model, byte[] metadataByte) {
        GTTInstance gttInstance = tenantService.getGTTInstanceByName(instance);
        if (gttInstance != null) {
            if (StringUtils.isNotBlank(model)) {
                retryUpgradeModel(gttInstance, model, metadataByte);
            } else {
                retryUpgradeModel(gttInstance, metadataByte);
            }
        }
    }


    private void retryUpgradeModel(GTTInstance gttInstance, String namespace, byte[] metadataByte) {
        UpgradeModelService upgradeModelService = getUpgradeInstance(gttInstance);
        if (upgradeModelService != null) {
            upgradeModelService.executeRetry(metadataByte, namespace);
        }
    }

    private void retryUpgradeModel(GTTInstance gttInstance, byte[] metadataByte) {
        UpgradeModelService upgradeModelService = getUpgradeInstance(gttInstance);
        if (upgradeModelService != null) {
            upgradeModelService.executeRetry(metadataByte, null);
        }
    }

    private void upgradeModel(GTTInstance gttInstance, String namespace) {
        UpgradeModelService upgradeModelService = getUpgradeInstance(gttInstance);
        if (upgradeModelService != null) {
            upgradeModelService.execute(namespace);
        }
    }

    private void upgradeModel(GTTInstance gttInstance) {
        UpgradeModelService upgradeModelService = getUpgradeInstance(gttInstance);
        if (upgradeModelService != null) {
            upgradeModelService.execute(null);
        }
    }

    private UpgradeModelService getUpgradeInstance(GTTInstance gttInstance) {
        String instanceName = gttInstance.getInstanceName();
        String beanName = getBeanName(instanceName);
        if (SpringContextUtils.containsBean(beanName)) {
            return (UpgradeModelService) SpringContextUtils.getBean(beanName);
        } else {
            return SpringContextUtils.createSingletonBean(UpgradeModelService.class, beanName, new Object[]{gttInstance});
        }
    }

    private String getBeanName(String instanceName) {
        return instanceName + "UpgradeService";
    }


}
