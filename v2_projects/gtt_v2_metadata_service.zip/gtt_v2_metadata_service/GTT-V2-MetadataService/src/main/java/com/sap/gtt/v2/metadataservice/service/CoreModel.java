package com.sap.gtt.v2.metadataservice.service;

import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import com.sap.gtt.v2.exception.InternalErrorException;
import com.sap.gtt.v2.util.JsonUtils;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.Iterator;

/**
 * {@code CoreModel} loading core model file info from resource package
 *
 * @author I301346
 * @date 2019/4/11
 */
@Component
public class CoreModel {
    private static final String TYPE_FILES_LOCATION = "classpath:core";
    private JsonObject i18n = new JsonObject();
    private JsonObject cds = new JsonObject();
    private String coreModelVersion = "";

    @Autowired
    private ResourceLoader resourceLoader;

    @PostConstruct
    public void setup() {
        try {
            Iterator<File> fi = FileUtils.iterateFiles(resourceLoader.getResource(TYPE_FILES_LOCATION).getFile(), null,
                    true);
            while (fi.hasNext()) {
                File f = fi.next();
                String fileName = f.getName();
                String fileContent = FileUtils.readFileToString(f, Charset.defaultCharset());
                setFileInfo(fileName, fileContent);
            }
        } catch (IOException e) {
            throw new InternalErrorException("Failed to Loading core model", e);
        }
    }

    public void setFileInfo(String fileName, String fileContent) {
        if ("package_core.json".equals(fileName)) {
            JsonObject versionJson = JsonUtils.generateJsonObjectFromJsonString(fileContent);
            this.coreModelVersion = versionJson.get("version").getAsString();
        } else if (fileName.endsWith(".properties")) {
            this.i18n.add(fileName, new JsonPrimitive(fileContent));
        } else if (fileName.endsWith(".cds")) {
            this.cds.add(fileName, new JsonPrimitive(fileContent));
        }

    }


    public JsonObject getI18n() {
        return i18n;
    }

    public JsonObject getCds() {
        return cds;
    }

    public String getCoreModelVersion() {
        return coreModelVersion;
    }

}
