package com.sap.gtt.v2.metadataservice.domain;

public class ProcessUnplannedEvent {
    private String eventType;

    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    @Override
    public String toString() {
        return "{" +
                "eventType: " + eventType  +
                '}';
    }
}
