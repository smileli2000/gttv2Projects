package com.sap.gtt.v2.metadataservice.domain;

import com.google.gson.annotations.SerializedName;
import com.sap.gtt.v2.core.entity.metadata.MetadataDraftModel;

import javax.validation.Valid;
import java.io.Serializable;
import java.util.Objects;

/**
 * @author i311486
 */
@Valid
public class DraftModelBody extends DraftModelHeaderInfo implements Serializable {

    private static final long serialVersionUID = -1L;

    public DraftModelBody() {
        super();
    }
    public DraftModelBody(MetadataDraftModel model) {
        super(model);
        this.customModel = model.getJsonModel();
    }

    public DraftModelBody(String namespace, String version, String descr, CoreModel coreModel, String customModel) {
        super(namespace, version, descr);
        this.coreModel = coreModel;
        this.customModel = customModel;
    }

    @SerializedName("coreModel")
    private CoreModel coreModel;

    @SerializedName("customModel")
    private String customModel;

    public CoreModel getCoreModel() {
        return coreModel;
    }

    public void setCoreModel(CoreModel coreModel) {
        this.coreModel = coreModel;
    }

    public String getCustomModel() {
        return customModel;
    }

    public void setCustomModel(String customModel) {
        this.customModel = customModel;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        if (!super.equals(o)) {
            return false;
        }
        DraftModelBody that = (DraftModelBody) o;
        return coreModel.equals(that.coreModel) &&
                Objects.equals(customModel, that.customModel);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), coreModel, customModel);
    }

}
