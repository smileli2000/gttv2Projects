/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.gtt.v2.metadataservice.utils;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 *
 * @author I326335
 */
public class ZipFileGenerator {

    private ZipFileGenerator() {
        throw new IllegalStateException("Utility class");
    }

    public static ByteArrayOutputStream zip(Map<String, String> cdsMap) throws IOException {
        ByteArrayOutputStream baosZip = new ByteArrayOutputStream();
        ZipOutputStream zosZip = new ZipOutputStream(baosZip);
        byte[] bytes = new byte[2048];
        boolean isAdded = false;
        try {
            for (Map.Entry<String, String> cdsEntry : cdsMap.entrySet()) {
                try (ByteArrayInputStream fis = new ByteArrayInputStream(cdsEntry.getValue().getBytes(UTF8)); BufferedInputStream bis = new BufferedInputStream(fis)) {
                    String file = cdsEntry.getKey();
                    if (file.endsWith(PROPERTIES)) {
                        if (!isAdded) {
                            isAdded = true;
                            zosZip.putNextEntry(new ZipEntry(I18N));
                        }
                        file = I18N.concat(file);
                    }
                    zosZip.putNextEntry(new ZipEntry(file));

                    int bytesRead;
                    while ((bytesRead = bis.read(bytes)) != -1) {
                        zosZip.write(bytes, 0, bytesRead);
                    }

                    zosZip.closeEntry();
                }
            }
        } finally {
            zosZip.flush();
            baosZip.flush();
            zosZip.close();
            baosZip.close();
        }

        return baosZip;
    }

    private static final String I18N = "i18n/";
    private static final String PROPERTIES = ".properties";
    private static final String UTF8 = "UTF-8";
}
