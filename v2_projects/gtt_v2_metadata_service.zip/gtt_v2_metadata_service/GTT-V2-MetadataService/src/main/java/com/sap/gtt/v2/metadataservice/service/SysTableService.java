package com.sap.gtt.v2.metadataservice.service;

import com.sap.gtt.v2.core.domain.metadata.CodeList;
import com.sap.gtt.v2.core.domain.metadata.MetadataEntity;

/**
 * {@code SysTableService} define system table service create and update interface
 *
 * @author I301346
 * @date 2019/4/11
 */
public interface SysTableService {

    /**
     * Generate Generic Model Tables for PO items; Inbound Delivery; Events Generation
     * @param newDerivedCsn
     */
    void createModelTables(String newDerivedCsn);

    /**
     * Add new entities, new fields and alter fields
     * @param newDerivedCsn
     * @param oldDerivedCsn
     *
     */
    void updateModelTables(String newDerivedCsn, String oldDerivedCsn);

    /**
     * drop user entity model related tables
     * @param currentCsn
     */
    void dropUserEntityTables(String currentCsn);

    /**
     * count table rows
     * @param metadataEntity
     * @return
     */
    long countTableRows(MetadataEntity metadataEntity);

    /**
     * delete from code list table
     * @param tableName
     */
    void emptyCodeListTable(String tableName);

    /**
     * insert from code list table
     * @param codeList
     */
    void insertCodeListTable(CodeList codeList);

    /**
     * insert from code list Texts table
     * @param codeList
     */
    void insertCodeListTextsTable(CodeList codeList);
}
