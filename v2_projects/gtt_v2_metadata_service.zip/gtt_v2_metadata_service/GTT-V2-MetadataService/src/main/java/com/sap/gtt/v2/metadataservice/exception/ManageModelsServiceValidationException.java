package com.sap.gtt.v2.metadataservice.exception;

import com.sap.gtt.v2.exception.BaseRuntimeException;
import org.apache.http.HttpStatus;

/**
 * {@code MetadataServiceValidationException} can be thrown during validating metadata project
 *
 * @author I301346
 * @date 2019/4/11
 */
public class ManageModelsServiceValidationException extends BaseRuntimeException {
    private static final long serialVersionUID = 1L;

    public static final String MESSAGE_CODE_ERROR_SUB_MODEL_NAME_NOT_UNIQUE = ManageModelsServiceValidationException.class.getName() + ".SubModelNameNotUnique";
    public static final String MESSAGE_CODE_ERROR_NAME_NOT_UNIQUE = ManageModelsServiceValidationException.class.getName() + ".NameNotUnique";
    public static final String MESSAGE_CODE_ERROR_FIELD_NOT_EXISTED_IN_PARENT = ManageModelsServiceValidationException.class.getName() + ".FieldNotExistedInParent";
    public static final String MESSAGE_CODE_ERROR_FIELD_VALUE_DUPLICATED = ManageModelsServiceValidationException.class.getName() + ".FieldValueDuplicated";
    public static final String MESSAGE_CODE_ERROR_FIELD_READABLE_WRITABLE_REQUIRED_NOT_TRUE = ManageModelsServiceValidationException.class.getName() + ".FieldValueReadableWritableRequiredNotTrue";
    public static final String MESSAGE_CODE_ERROR_NAME_NOT_EXISTED = ManageModelsServiceValidationException.class.getName() + ".NameNotExisted";
    public static final String MESSAGE_CODE_ERROR_DPP_DEFINITION_ERROR = ManageModelsServiceValidationException.class.getName() + ".DPPDefinitionError";
    public static final String MESSAGE_CODE_ERROR_TRACKING_ID_TYPE_NOT_UNIQUE = ManageModelsServiceValidationException.class.getName() + ".TrackingIdTypeNotUnique";
    public static final String MESSAGE_CODE_ERROR_FIELD_KEY_NOT_EXISTED = ManageModelsServiceValidationException.class.getName() + ".FieldKeyNotExisted";
    public static final String MESSAGE_CODE_ERROR_FIELD_KEY_EXISTED = ManageModelsServiceValidationException.class.getName() + ".FieldKeyExisted";
    public static final String MESSAGE_CODE_ERROR_APPLICATION_OBJECT_TYPE_DUPLICATED_ERROR = ManageModelsServiceValidationException.class.getName() + ".ApplicatonObjectTypeDupliatedInSubModel";
    public static final String MESSAGE_CODE_ERROR_APPLICATION_OBJECT_TYPE_DUPLICATED_GLOBALLY_ERROR = ManageModelsServiceValidationException.class.getName() + ".ApplicatonObjectTypeDupliatedInModel";
    public static final String MESSAGE_CODE_ERROR_MODEL_ALREADY_EXISTED_ERROR = ManageModelsServiceValidationException.class.getName() + ".ModelAlreadyExisted";
    public static final String MESSAGE_CODE_ERROR_MODEL_NOT_DEPLOYED_ERROR = ManageModelsServiceValidationException.class.getName() + ".ModelNotDeployed";
    public static final String MESSAGE_CODE_ERROR_STATUS_INCORRECT_ERROR = ManageModelsServiceValidationException.class.getName() + ".StatusIncorrect";
    public ManageModelsServiceValidationException(String internalMessage, String messageCode, Object[] localizedMsgParams) {
        super(internalMessage, null, messageCode, localizedMsgParams);
    }
    
    @Override
    public int getHttpStatus() {
        return HttpStatus.SC_BAD_REQUEST;
    }
}
