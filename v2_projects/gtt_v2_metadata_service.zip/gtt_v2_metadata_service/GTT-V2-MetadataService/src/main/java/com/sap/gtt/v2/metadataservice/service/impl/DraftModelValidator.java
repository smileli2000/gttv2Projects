/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.gtt.v2.metadataservice.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.json.JsonSanitizer;
import com.sap.gtt.v2.exception.InternalErrorException;
import com.sap.gtt.v2.metadataservice.exception.ManageModelsServiceValidationException;
import com.sap.gtt.v2.util.JsonUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.everit.json.schema.Schema;
import org.everit.json.schema.ValidationException;
import org.everit.json.schema.loader.SchemaLoader;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.*;

import static com.sap.gtt.v2.metadataservice.exception.ManageModelsServiceValidationException.*;
import static com.sap.gtt.v2.metadataservice.exception.MetadataServiceValidationException.MESSAGE_CODE_ERROR_PROCESS_TYPE_NOT_UNIQUE;
import java.util.stream.Collectors;

/**
 * @author I326335
 */
@Component
public class DraftModelValidator {

    public static final String JSON_CORE_CORE_MODEL = "core/CoreModel.json";
    private static final String YAML_SCHEMA = "schema/draft-model-schema.yaml";

    public String validate(String body) {
        JsonElement coreJson = JsonUtils.generateJsonElementFromString(getSchemaJson(JSON_CORE_CORE_MODEL));
        JsonElement bodyJson = JsonUtils.generateJsonElementFromString(JsonSanitizer.sanitize(body));
        try {
            validateJsonSchema(bodyJson);
        } catch (JSONException ex) {
            throw new InternalErrorException(ex.getMessage(), ex);
        } catch (ValidationException ex) {
            throw new ManageModelsServiceValidationException(JsonUtils.generateJsonStringFromBean(buildErrorArray(ex)), null, new Object[]{});
        }
        validateFields(coreJson, bodyJson);
        String customModel = bodyJson.getAsJsonObject().get(ELEMENT_CUSTOM_MODEL).toString();
        bodyJson.getAsJsonObject().remove(ELEMENT_CUSTOM_MODEL);
        bodyJson.getAsJsonObject().addProperty(ELEMENT_CUSTOM_MODEL, customModel);
        return bodyJson.toString();
    }

    private void validateJsonSchema(JsonElement jsonElement) throws JSONException {
        JSONObject schemaData = new JSONObject(getSchemaYaml(YAML_SCHEMA));
        processSchema(schemaData);
        SchemaLoader loader = SchemaLoader.builder()
                .draftV7Support()
                .schemaJson(schemaData)
                .build();
        Schema schema = loader.load().build();
        schema.validate(new JSONObject(jsonElement.getAsJsonObject().toString())); // throws a ValidationException if this object is invalid
    }

    private void processSchema(JSONObject schemaData) throws JSONException {
        JSONObject ref = new JSONObject();
        ref.put(REF, COMPONENTSSCHEMAS_MODEL);
        schemaData.append(ALL_OF, ref);
    }

    private String getSchemaJson(String jsonPath) {
        ClassPathResource resource = new ClassPathResource(jsonPath);
        try (InputStream inputStream = resource.getInputStream()) {
            return IOUtils.toString(inputStream, StandardCharsets.UTF_8);
        } catch (IOException ex) {
            throw new InternalErrorException(ex.getMessage(), ex);
        }
    }

    private String getSchemaYaml(String yamlPath) {
        ClassPathResource resource = new ClassPathResource(yamlPath);
        try (InputStream inputStream = resource.getInputStream()) {
            ObjectMapper mapper = new ObjectMapper(new YAMLFactory());
            return mapper.readTree(inputStream).toString();
        } catch (IOException ex) {
            throw new InternalErrorException(ex.getMessage(), ex);
        }
    }

    private Set<String> buildErrorArray(ValidationException exception) {
        Set<String> errorSet = new HashSet<>();
        if (exception.getCausingExceptions().isEmpty()) {
            errorSet.add(exception.getMessage());
        } else {
            exception.getCausingExceptions().stream()
                    .forEach(e -> errorSet.addAll(buildErrorArray(e)));
        }
        return errorSet;
    }

    /**
     * validate core and user model
     *
     * @param coreJson
     * @param bodyJson
     * @return
     */
    private void validateFields(JsonElement coreJson, JsonElement bodyJson) {
        Set<String> allNameSet = new HashSet<>();
        Set<String> eventTypeSet = new HashSet<>();
        //check if core model name is unique
        checkSubModelUnique(ELEMENT_CORE_MODEL, coreJson, allNameSet, eventTypeSet);

        //check if user defined model name is unique
        JsonObject jsonModel = bodyJson.getAsJsonObject().getAsJsonObject(ELEMENT_CUSTOM_MODEL);
        checkSubModelUnique(jsonModel, allNameSet, eventTypeSet);

        //check if core model field duplicates
        checkSubModelEntities(ELEMENT_CORE_MODEL, coreJson, allNameSet, eventTypeSet);
        //check if user defined model field duplicates
        checkSubModel(jsonModel, allNameSet, eventTypeSet);
    }

    /**
     * check if sub model's name is unique in whole model
     *
     * @param element
     * @param allNameSet
     * @param eventTypeSet
     */
    private void checkSubModelUnique(JsonElement element, Set<String> allNameSet, Set<String> eventTypeSet) {
        if (!element.getAsJsonObject().has(ELEMENT_SUB_MODELS)) {
            return;
        }

        JsonArray subModels = element.getAsJsonObject().getAsJsonArray(ELEMENT_SUB_MODELS);
        Iterator<JsonElement> iterator = subModels.iterator();
        Set<String> subModelNames = new HashSet<>();
        while (iterator.hasNext()) {
            JsonObject subModel = iterator.next().getAsJsonObject();
            String name = subModel.get(ELEMENT_NAME).getAsString();
            if (!subModelNames.add(name.toLowerCase(Locale.ENGLISH))) {
                //sub model name existed
                throw new ManageModelsServiceValidationException(String.format("Sub model name: %s should be unique.", name), MESSAGE_CODE_ERROR_SUB_MODEL_NAME_NOT_UNIQUE, new Object[]{name});
            }
            checkSubModelUnique(name, subModel, allNameSet, eventTypeSet);
        }
    }

    private void checkSubModelUnique(String name, JsonElement subModel, Set<String> allNameSet, Set<String> eventTypeSet) {
        checkNameUnique(name, subModel, ELEMENT_PROCESS_TYPES, ELEMENT_NAME, allNameSet, new HashSet<>());
        checkEntityKeyExisted(subModel, ELEMENT_PROCESS_TYPES, true);

        Set<String> nameSet = new HashSet<>();
        checkNameUnique(name, subModel, ELEMENT_EVENT_TYPES, ELEMENT_NAME, allNameSet, nameSet);
        eventTypeSet.addAll(nameSet);
        checkEntityKeyExisted(subModel, ELEMENT_EVENT_TYPES, true);

        checkNameUnique(name, subModel, ELEMENT_ITEM_TYPES, ELEMENT_NAME, allNameSet, new HashSet<>());
        checkEntityKeyExisted(subModel, ELEMENT_ITEM_TYPES, false);

        checkNameUnique(name, subModel, ELEMENT_CODE_LISTS, ELEMENT_NAME, allNameSet, new HashSet<>());
    }

    /**
     * check if process/event/item's name is unique in whole model
     *
     * @param element
     * @param eleName
     * @param checkName
     * @param allNameSet
     */
    private void checkNameUnique(String parentName, JsonElement element, String eleName, String checkName, Set<String> allNameSet, Set<String> nameSet) {
        if (!element.getAsJsonObject().has(eleName)) {
            return;
        }

        JsonArray subModels = element.getAsJsonObject().getAsJsonArray(eleName);
        Iterator<JsonElement> iterator = subModels.iterator();
        Set<String> ignoreCaseSet = allNameSet.stream().filter(n -> !n.contains(DOT)).map(n -> n.toLowerCase(Locale.ENGLISH)).collect(Collectors.toSet());
        while (iterator.hasNext()) {
            JsonObject entity = iterator.next().getAsJsonObject();
            String name = entity.get(checkName).getAsString();
            if (!allNameSet.add(name) || !ignoreCaseSet.add(name.toLowerCase(Locale.ENGLISH))) {
                //entity name existed
                throw new ManageModelsServiceValidationException(String.format("Name: %s should be unique.", name), MESSAGE_CODE_ERROR_NAME_NOT_UNIQUE, new Object[]{name});
            }
            allNameSet.add(parentName.concat(DOT).concat(name));
            nameSet.add(parentName.concat(DOT).concat(name));
            HashSet<String> fields = new HashSet<>();
            checkFieldPropertyUnique(entity, ELEMENT_ELEMENTS, ELEMENT_NAME, fields);
            checkEntityParentNameUnique(entity, fields, allNameSet);
            fields.stream().forEach(field -> allNameSet.add(parentName.concat(DOT).concat(name).concat(DOT).concat(field)));
            //check value unique in codelist's values
            HashSet<String> values = new HashSet<>();
            checkFieldPropertyUnique(entity, ELEMENT_VALUES, ELEMENT_CODE, values);
            values.stream().forEach(value -> allNameSet.add(parentName.concat(DOT).concat(name).concat(DOT).concat(value)));
            values.stream().forEach(value -> allNameSet.add(name.concat(DOT).concat(value)));

            Set<String> eventTypeSet = new HashSet<>();
            checkFieldPropertyUnique(entity, ELEMENT_ADMISSIBLE_PLANNED_EVENTS, ELEMENT_EVENT_TYPE, ELEMENT_TARGET, eventTypeSet);
            eventTypeSet = new HashSet<>();
            checkFieldPropertyUnique(entity, ELEMENT_ADMISSIBLE_UNPLANNED_EVENTS, ELEMENT_EVENT_TYPE, ELEMENT_TARGET, eventTypeSet);

            //for key field, readable and writable must be true
            checkKeyFieldProperty(entity, ELEMENT_ELEMENTS, parentName);
        }
    }

    private void checkEntityParentNameUnique(JsonObject entity, HashSet<String> fields, Set<String> allNameSet) {
        if (!entity.has(ELEMENT_PARENT)) {
            return;
        }

        JsonObject parentEle = entity.getAsJsonObject(ELEMENT_PARENT);
        String parentContext = parentEle.has(ELEMENT_NAME) ? parentEle.get(ELEMENT_NAME).getAsString() : parentEle.get(ELEMENT_TARGET).getAsString();
        Set<String> ignoreCaseSet = allNameSet.stream().filter(n -> n.startsWith(parentContext.concat(DOT))).map(n -> n.toLowerCase(Locale.ENGLISH)).collect(Collectors.toSet());
        Iterator<String> elementIterator = fields.iterator();
        while (elementIterator.hasNext()) {
            String fieldName = elementIterator.next();
            if (allNameSet.contains(parentContext.concat(DOT).concat(fieldName))
                    || ignoreCaseSet.contains(parentContext.concat(DOT).concat(fieldName).toLowerCase(Locale.ENGLISH))) {
                //element existed in parent context
                throw new ManageModelsServiceValidationException(String.format("Field: %s cannot be overwrited.", fieldName), MESSAGE_CODE_ERROR_NAME_NOT_UNIQUE, new Object[]{fieldName});
            }
        }
        HashSet<String> overwriteEleSet = new HashSet<>();
        checkFieldPropertyUnique(parentEle, ELEMENT_ELEMENTS, ELEMENT_NAME, overwriteEleSet);
        Iterator<String> overwriteEleIterator = overwriteEleSet.iterator();
        while (overwriteEleIterator.hasNext()) {
            String fieldName = overwriteEleIterator.next();
            if (!allNameSet.contains(parentContext.concat(DOT).concat(fieldName))) {
                //element is not existed in parent context
                throw new ManageModelsServiceValidationException(String.format("Field: %s is not defined in parent.", fieldName), MESSAGE_CODE_ERROR_FIELD_NOT_EXISTED_IN_PARENT, new Object[]{fieldName});
            }
        }
    }

    /**
     * check if field's name is unique in this entity
     *
     * @param element
     * @param eleName
     * @param checkName
     */
    private void checkFieldPropertyUnique(JsonElement element, String eleName, String checkName, Set<String> nameSet) {
        checkFieldPropertyUnique(element, eleName, checkName, null, nameSet);
    }

    private void checkFieldPropertyUnique(JsonElement element, String eleName, String checkName, String checkSubName, Set<String> nameSet) {
        if (!element.getAsJsonObject().has(eleName)) {
            return;
        }

        JsonArray subModels = element.getAsJsonObject().getAsJsonArray(eleName);
        Iterator<JsonElement> iterator = subModels.iterator();
        Set<String> ignoreCaseNameSet = nameSet.stream().map(n -> n.toLowerCase(Locale.ENGLISH)).collect(Collectors.toSet());
        while (iterator.hasNext()) {
            JsonObject field = iterator.next().getAsJsonObject();
            if (!field.has(checkName)) {
                continue;
            }
            String name = getElementValue(field, checkName, checkSubName);
            if (!nameSet.add(name) || !ignoreCaseNameSet.add(name.toLowerCase(Locale.ENGLISH))) {
                //element duplicated
                throw new ManageModelsServiceValidationException(String.format("Field %s: %s is duplicated.", checkName, name), MESSAGE_CODE_ERROR_FIELD_VALUE_DUPLICATED, new Object[]{checkName, name});
            }
        }
    }

    private void checkEntityKeyExisted(JsonElement element, String eleName, Boolean checkKeyNotExisted) {
        if (!element.getAsJsonObject().has(eleName)) {
            return;
        }

        JsonArray subModels = element.getAsJsonObject().getAsJsonArray(eleName);
        Iterator<JsonElement> iterator = subModels.iterator();
        while (iterator.hasNext()) {
            JsonObject entity = iterator.next().getAsJsonObject();
            String parent = entity.has(ELEMENT_PARENT) ? getElementValue(entity, ELEMENT_PARENT, ELEMENT_TARGET) : null;
            boolean keyExisted = checkKeyFieldPropertyExisted(entity, ELEMENT_ELEMENTS, ELEMENT_KEY);
            boolean checkExistedOrNot = StringUtils.isEmpty(parent);
            if (checkExistedOrNot && !keyExisted) {
                String name = entity.getAsJsonPrimitive(ELEMENT_NAME).getAsString();
                throw new ManageModelsServiceValidationException(
                        String.format("Key field does not exist in entity %s.",
                                name),
                        MESSAGE_CODE_ERROR_FIELD_KEY_NOT_EXISTED, new Object[]{name});
            }
            if (!checkExistedOrNot && checkKeyNotExisted && keyExisted) {
                String name = entity.getAsJsonPrimitive(ELEMENT_NAME).getAsString();
                throw new ManageModelsServiceValidationException(
                        String.format("Key field cannot be defined in entity %s.",
                                name),
                        MESSAGE_CODE_ERROR_FIELD_KEY_EXISTED, new Object[]{name});
            }
        }
    }

    private boolean checkKeyFieldPropertyExisted(JsonElement parentEl, String eleName, String checkName) {
        if (!parentEl.getAsJsonObject().has(eleName)) {
            return false;
        }

        JsonArray elements = parentEl.getAsJsonObject().getAsJsonArray(eleName);
        Iterator<JsonElement> iterator = elements.iterator();
        while (iterator.hasNext()) {
            JsonObject field = iterator.next().getAsJsonObject();
            if (field.has(checkName) && field.getAsJsonPrimitive(checkName).getAsBoolean()) {
                return true;
            }
        }
        return false;
    }

    /**
     * Check key field if readable and writable is true
     *
     * @param element
     * @param eleName
     * @param parentName
     */
    private void checkKeyFieldProperty(JsonElement element, String eleName, String parentName) {
        if (!element.getAsJsonObject().has(eleName)) {
            return;
        }
        JsonArray elements = element.getAsJsonObject().getAsJsonArray(eleName);
        Iterator<JsonElement> iterator = elements.iterator();
        while (iterator.hasNext()) {
            JsonObject field = iterator.next().getAsJsonObject();
            if (field.has(ELEMENT_KEY) && field.getAsJsonPrimitive(ELEMENT_KEY).getAsBoolean()
                    && (!field.has(ELEMENT_READABLE)
                    || !field.getAsJsonPrimitive(ELEMENT_READABLE).getAsBoolean()
                    || !field.has(ELEMENT_WRITABLE)
                    || (!ELEMENT_CORE_MODEL.equals(parentName)
                    && !field.getAsJsonPrimitive(ELEMENT_WRITABLE).getAsBoolean())
                    || !field.has(ELEMENT_REQUIRED))
            ) {
                String name = field.getAsJsonPrimitive(ELEMENT_NAME).getAsString();
                throw new ManageModelsServiceValidationException(
                        String.format("Field %s: key field. Readable, writable and required property must be true.",
                                name),
                        MESSAGE_CODE_ERROR_FIELD_READABLE_WRITABLE_REQUIRED_NOT_TRUE, new Object[]{name});
            }
        }
    }

    /**
     * check if sub model exists, or eventType exists
     *
     * @param element
     * @param allNameSet
     */
    private void checkSubModel(JsonElement element, Set<String> allNameSet, Set<String> eventTypeSet) {
        if (!element.getAsJsonObject().has(ELEMENT_SUB_MODELS)) {
            return;
        }

        JsonArray subModels = element.getAsJsonObject().getAsJsonArray(ELEMENT_SUB_MODELS);
        Iterator<JsonElement> iterator = subModels.iterator();
        while (iterator.hasNext()) {
            JsonObject subModel = iterator.next().getAsJsonObject();
            String parentName = subModel.get(ELEMENT_NAME).getAsString();
            checkSubModelEntities(parentName, subModel, allNameSet, eventTypeSet);
        }
    }

    private void checkSubModelEntities(String parentName, JsonElement subModel, Set<String> allNameSet, Set<String> eventTypeSet) {
        boolean hasProcessDefined = false;
        hasProcessDefined = checkEntity(parentName, subModel, ELEMENT_PROCESS_TYPES, allNameSet, eventTypeSet, hasProcessDefined);
        hasProcessDefined = checkEntity(parentName, subModel, ELEMENT_EVENT_TYPES, allNameSet, eventTypeSet, hasProcessDefined);
        checkEntity(parentName, subModel, ELEMENT_ITEM_TYPES, allNameSet, eventTypeSet, hasProcessDefined);
    }

    private boolean checkEntity(String parentName, JsonElement element, String eleName, Set<String> allNameSet, Set<String> eventTypeSet, Boolean hasProcessDefined) {
        boolean isProcessDefined = hasProcessDefined;
        if (!element.getAsJsonObject().has(eleName)) {
            return isProcessDefined;
        }

        JsonArray subModels = element.getAsJsonObject().getAsJsonArray(eleName);
        Iterator<JsonElement> iterator = subModels.iterator();
        while (iterator.hasNext()) {
            JsonObject entity = iterator.next().getAsJsonObject();
            boolean isProcess = checkProcessExist(entity, isProcessDefined);
            if (isProcess) {
                isProcessDefined = true;
            }
            checkFieldPropertyExist(entity, ELEMENT_ELEMENTS, ELEMENT_TARGET, allNameSet);
            checkFieldDefault(entity, ELEMENT_ELEMENTS, ELEMENT_TARGET, ELEMENT_DEFAULT, allNameSet);
            checkFieldPropertyDpp(entity, ELEMENT_ELEMENTS, ELEMENT_DPP);
            checkFieldPropertyIdocMapping(parentName, entity, ELEMENT_IDOC_MAPPING, ELEMENT_FIELD_MAPPING, allNameSet);
            if (isProcess) {
                checkFieldPropertyExist(entity, ELEMENT_ADMISSIBLE_PLANNED_EVENTS, ELEMENT_EVENT_TYPE, ELEMENT_TARGET, eventTypeSet);
                checkFieldPropertyExist(entity, ELEMENT_ADMISSIBLE_UNPLANNED_EVENTS, ELEMENT_EVENT_TYPE, ELEMENT_TARGET, eventTypeSet);
            }
        }
        return isProcessDefined;
    }

    private boolean checkProcessExist(JsonObject entity, boolean isProcessDefined) {
        if (entity.has(ELEMENT_PARENT)) {
            JsonObject parentEle = entity.getAsJsonObject(ELEMENT_PARENT);
            String parentContext = parentEle.has(ELEMENT_NAME) ? parentEle.get(ELEMENT_NAME).getAsString() : parentEle.get(ELEMENT_TARGET).getAsString();
            if (isProcessDefined && parentContext.equals(CORE_MODEL_TRACKED_PROCESS)) {
                //process has been defined
                String name = entity.getAsJsonObject().get(ELEMENT_NAME).getAsString();
                throw new ManageModelsServiceValidationException(String.format("Process type: %s cannot be defined in sub model. Process type should be unique in sub model.", name), MESSAGE_CODE_ERROR_PROCESS_TYPE_NOT_UNIQUE, new Object[]{name});
            } else if (parentContext.equals(CORE_MODEL_TRACKED_PROCESS)) {
                return true;
            }
        }
        return false;
    }

    private void checkFieldPropertyExist(JsonElement element, String eleName, String checkName, Set<String> nameSet) {
        checkFieldPropertyExist(element, eleName, checkName, null, nameSet);
    }

    private void checkFieldPropertyExist(JsonElement element, String eleName, String checkName, String checkSubName, Set<String> nameSet) {
        if (!element.getAsJsonObject().has(eleName)) {
            return;
        }

        JsonArray subModels = element.getAsJsonObject().getAsJsonArray(eleName);
        Iterator<JsonElement> iterator = subModels.iterator();
        while (iterator.hasNext()) {
            JsonObject field = iterator.next().getAsJsonObject();
            if (!field.has(checkName)) {
                continue;
            }
            String name = getElementValue(field, checkName, checkSubName);
            if (!nameSet.contains(name)) {
                //eventType/submodel is not defined
                throw new ManageModelsServiceValidationException(String.format("Field %s: %s is not defined.", checkName, name), MESSAGE_CODE_ERROR_NAME_NOT_EXISTED, new Object[]{checkName, name});
            }
        }
    }

    private void checkFieldDefault(JsonElement element, String eleName, String checkPrefixName, String checkName, Set<String> nameSet) {
        if (!element.getAsJsonObject().has(eleName)) {
            return;
        }

        JsonArray subModels = element.getAsJsonObject().getAsJsonArray(eleName);
        Iterator<JsonElement> iterator = subModels.iterator();
        while (iterator.hasNext()) {
            JsonObject field = iterator.next().getAsJsonObject();
            if (!field.has(checkPrefixName) || !field.has(checkName)) {
                continue;
            }
            String prefix = getElementValue(field, checkPrefixName, null);
            String name = getElementValue(field, checkName, null);
            if (!nameSet.contains(prefix.concat(DOT).concat(name))) {
                //eventType/submodel is not defined
                throw new ManageModelsServiceValidationException(String.format("Field %s: %s is not defined.", prefix, name), MESSAGE_CODE_ERROR_NAME_NOT_EXISTED, new Object[]{prefix, name});
            }
        }
    }


    private void checkFieldPropertyDpp(JsonElement element, String eleName, String checkName) {
        if (!element.getAsJsonObject().has(eleName)) {
            return;
        }

        JsonArray subModels = element.getAsJsonObject().getAsJsonArray(eleName);
        Iterator<JsonElement> iterator = subModels.iterator();
        while (iterator.hasNext()) {
            JsonObject field = iterator.next().getAsJsonObject();
            if (!field.has(checkName)) {
                continue;
            }
            JsonArray dpps = field.getAsJsonArray(checkName);
            List<String> dppList = new ArrayList<>();
            dpps.forEach(dpp -> dppList.add(dpp.getAsString()));
            if (dppList.contains(PII) && dppList.contains(SPI)) {
                //pii and spi cannot be defined at the same
                throw new ManageModelsServiceValidationException("DPP annotation PII and SPI cannot be defined at the same time.", MESSAGE_CODE_ERROR_DPP_DEFINITION_ERROR, new Object[]{});
            }
        }
    }

    private void checkFieldPropertyIdocMapping(String parentName, JsonElement element, String eleName, String checkName, Set<String> nameSet) {
        if (!element.getAsJsonObject().has(eleName) || !element.getAsJsonObject().getAsJsonObject(eleName).has(checkName)) {
            return;
        }
        
        checkFieldPropertyExist(element.getAsJsonObject().getAsJsonObject(eleName), ELEMENT_FIELD_MAPPING, ELEMENT_TARGET, nameSet);
        
        String parentNamePrefix = parentName.concat(DOT).concat(element.getAsJsonObject().get(ELEMENT_NAME).getAsString()).concat(DOT);
        
        JsonArray fieldMappings = element.getAsJsonObject().getAsJsonObject(eleName).getAsJsonArray(checkName);
        checkFieldPropertyExistInIdocMapping(fieldMappings, nameSet, parentNamePrefix);
    }

    private void checkFieldPropertyExistInIdocMapping(JsonArray fieldMappings, Set<String> nameSet, String parentNamePrefix) throws ManageModelsServiceValidationException {
        Iterator<JsonElement> iterator = fieldMappings.iterator();
        while (iterator.hasNext()) {
            JsonObject fieldMapping = iterator.next().getAsJsonObject();
            if (!fieldMapping.has(ELEMENT_FIELD)) {
                continue;
            }
            String fieldName = fieldMapping.get(ELEMENT_FIELD).getAsString();
            if (!nameSet.contains(parentNamePrefix.concat(fieldName))) {
                //field name is not defined in idoc mapping
                throw new ManageModelsServiceValidationException(String.format("Field %s: %s is not defined.", ELEMENT_FIELD, fieldName), MESSAGE_CODE_ERROR_NAME_NOT_EXISTED, new Object[]{ELEMENT_FIELD, fieldName});
            }
            
            if (fieldMapping.has(ELEMENT_COMPOSITION) && fieldMapping.get(ELEMENT_COMPOSITION).isJsonArray()) {
                JsonArray itemFieldMappings = fieldMapping.getAsJsonArray(ELEMENT_COMPOSITION);
                String itemNamePrefix = fieldMapping.get(ELEMENT_TARGET).getAsString().concat(DOT);
                checkFieldPropertyExistInIdocMapping(itemFieldMappings, nameSet, itemNamePrefix);
                checkFieldPropertyExist(fieldMapping, ELEMENT_COMPOSITION, ELEMENT_TARGET, nameSet);
            }
        }
    }
    
    private String getElementValue(JsonObject field, String checkName, String checkSubName) {
        String name = null;
        if (field.get(checkName).isJsonObject()) {
            name = field.getAsJsonObject(checkName).get(checkSubName).getAsString();
        } else {
            name = field.get(checkName).getAsString();
        }
        return name;
    }

    private static final String CORE_MODEL_TRACKED_PROCESS = "CoreModel.TrackedProcess";

    private static final String SPI = "SPI";
    private static final String PII = "PII";
    private static final String DOT = ".";

    private static final String ALL_OF = "allOf";
    private static final String COMPONENTSSCHEMAS_MODEL = "#/components/schemas/ModelPayload";
    private static final String REF = "$ref";

    private static final String ELEMENT_CORE_MODEL = "CoreModel";
    private static final String ELEMENT_SUB_MODELS = "subModels";
    public static final String ELEMENT_CUSTOM_MODEL = "customModel";
    private static final String ELEMENT_ITEM_TYPES = "itemTypes";
    private static final String ELEMENT_EVENT_TYPES = "eventTypes";
    private static final String ELEMENT_PROCESS_TYPES = "processTypes";
    private static final String ELEMENT_ADMISSIBLE_UNPLANNED_EVENTS = "admissibleUnplannedEvents";
    private static final String ELEMENT_ADMISSIBLE_PLANNED_EVENTS = "admissiblePlannedEvents";
    private static final String ELEMENT_CODE_LISTS = "codeLists";
    private static final String ELEMENT_PARENT = "parent";
    private static final String ELEMENT_ELEMENTS = "elements";
    private static final String ELEMENT_CODE = "code";
    private static final String ELEMENT_VALUES = "values";
    private static final String ELEMENT_DPP = "dpp";
    private static final String ELEMENT_EVENT_TYPE = "eventType";
    private static final String ELEMENT_NAME = "name";
    private static final String ELEMENT_TARGET = "target";
    private static final String ELEMENT_WRITABLE = "writable";
    private static final String ELEMENT_READABLE = "readable";
    private static final String ELEMENT_REQUIRED = "required";
    private static final String ELEMENT_KEY = "key";
    private static final String ELEMENT_FIELD = "field";
    private static final String ELEMENT_FIELD_MAPPING = "fieldMapping";
    private static final String ELEMENT_DEFAULT = "default";

    private static final String ELEMENT_COMPOSITION = "composition";
    private static final String ELEMENT_IDOC_MAPPING = "idocMapping";
}
