package com.sap.gtt.v2.metadataservice.domain;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.Objects;

/**
 * @author i311486
 */
public class CoreModel implements Serializable {
    private static final long serialVersionUID = -1L;
    @SerializedName("version")
    private String version = null;

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        CoreModel coreModel = (CoreModel) o;
        return version.equals(coreModel.version);
    }

    @Override
    public int hashCode() {
        return Objects.hash(version);
    }

}
