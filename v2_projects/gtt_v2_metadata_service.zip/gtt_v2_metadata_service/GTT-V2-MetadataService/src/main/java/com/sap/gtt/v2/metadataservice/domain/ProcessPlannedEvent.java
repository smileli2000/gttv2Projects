package com.sap.gtt.v2.metadataservice.domain;

import java.util.ArrayList;
import java.util.List;

public class ProcessPlannedEvent {
    private String eventType;
    private boolean matchLocation;
    private String businessToleranceValue;
    private String technicalToleranceValue;
    private String periodicOverdueDetection;
    private int maxOverdueDetection;

    public List<MatchExtensionField> getMatchExtensionFields() {
        return matchExtensionFields;
    }

    public void setMatchExtensionFields(List<MatchExtensionField> matchExtensionFields) {
        this.matchExtensionFields = matchExtensionFields;
    }

    private List<MatchExtensionField> matchExtensionFields = new ArrayList();

    public String getEventType() {
        return eventType;
    }



    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    public boolean isMatchLocation() {
        return matchLocation;
    }

    public void setMatchLocation(boolean matchLocation) {
        this.matchLocation = matchLocation;
    }

    public String getBusinessToleranceValue() {
        return businessToleranceValue;
    }

    public void setBusinessToleranceValue(String businessToleranceValue) {
        this.businessToleranceValue = businessToleranceValue;
    }

    public String getTechnicalToleranceValue() {
        return technicalToleranceValue;
    }

    public void setTechnicalToleranceValue(String technicalToleranceValue) {
        this.technicalToleranceValue = technicalToleranceValue;
    }

    public String getPeriodicOverdueDetection() {
        return periodicOverdueDetection;
    }

    public void setPeriodicOverdueDetection(String periodicOverdueDetection) {
        this.periodicOverdueDetection = periodicOverdueDetection;
    }

    public int getMaxOverdueDetection() {
        return maxOverdueDetection;
    }

    public void setMaxOverdueDetection(int maxOverdueDetection) {
        this.maxOverdueDetection = maxOverdueDetection;
    }

    @Override
    public String toString() {
        return "{" +
                "eventType: " + eventType  +
                ", matchLocation: " + matchLocation +
                ", businessToleranceValue: '" + businessToleranceValue + '\'' +
                ", technicalToleranceValue: '" + technicalToleranceValue + '\'' +
                ", periodicOverdueDetection: '" + periodicOverdueDetection + '\'' +
                ", maxOverdueDetection: " + maxOverdueDetection +
                '}';
    }
}
