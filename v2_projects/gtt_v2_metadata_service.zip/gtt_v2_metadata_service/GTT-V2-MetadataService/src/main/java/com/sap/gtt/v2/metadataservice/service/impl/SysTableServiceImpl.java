package com.sap.gtt.v2.metadataservice.service.impl;

import com.sap.gtt.v2.configuration.ISAPCloudPlatformAgent.ICurrentAccessContext;
import com.sap.gtt.v2.core.domain.metadata.CodeList;
import com.sap.gtt.v2.core.domain.metadata.MetadataEntity;
import com.sap.gtt.v2.core.domain.metadata.MetadataEntityElement;
import com.sap.gtt.v2.core.management.metadata.CsnParser;
import com.sap.gtt.v2.core.management.metadata.IMetadataManagement;
import com.sap.gtt.v2.log.TenantAwareLogService;
import com.sap.gtt.v2.metadataservice.service.SysTableService;
import com.sap.gtt.v2.metadataservice.utils.Constant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * {@code SysTableServiceImpl} implement system table service
 * <p>
 *     <pre>
 *         1.create model tables according to the new derived csn
 *         2.do classify and update model tables according to the new derived csn
 *         3.drop user entities related tables
 *     </pre>
 * </p>
 *
 * @author I301346
 * @date 2019/4/11
 */
@Component
public class SysTableServiceImpl implements SysTableService {

    @Autowired
    private ICurrentAccessContext currentAccessContext;
    @Autowired
    private TenantAwareLogService logService;

    @Autowired
    private DerivedCsnValidation derivedCSNValidation;

    private IMetadataManagement getMetadataManagement() {
        return currentAccessContext.createBusinessOperator().getMetadataManagement();
    }

    @Override
    public void createModelTables(String newDerivedCsn) {
        List<MetadataEntity> newEntities = CsnParser.parseToEntities(newDerivedCsn);
        //create table
        getMetadataManagement().createTable(newEntities);
    }

    @Override
    public void updateModelTables(String newDerivedCsn, String oldDerivedCsn) {
        logService.info("Update Model tables.");
        Map<String,List<MetadataEntity>> entitiesChanges
                = derivedCSNValidation.updateCSNCheck(newDerivedCsn, oldDerivedCsn);
        getMetadataManagement().dropTable(entitiesChanges.get(Constant.DROP));
        getMetadataManagement().dropTable(entitiesChanges.get(Constant.DROP_AND_NEW));
        getMetadataManagement().createTable(entitiesChanges.get(Constant.NEW));
        getMetadataManagement().createTable(entitiesChanges.get(Constant.DROP_AND_NEW));
        getMetadataManagement().modifyTableField(entitiesChanges.get(Constant.MODIFY));
        getMetadataManagement().deleteTableField(entitiesChanges.get(Constant.DELETE));
        getMetadataManagement().addTableField(entitiesChanges.get(Constant.ADD));
    }


    @Override
    public void dropUserEntityTables(String currentCsn) {
        List<MetadataEntity> currentEntities = CsnParser.parseToEntities(currentCsn);
        //drop user entity related tables
        getMetadataManagement().dropTable(currentEntities);
    }

    @Override
    public long countTableRows(MetadataEntity metadataEntity) {
        return getMetadataManagement().countTableRows(metadataEntity);
    }

    @Override
    public void emptyCodeListTable(String tableName) {
        getMetadataManagement().emptyTable(tableName);
    }

    @Override
    public void insertCodeListTable(CodeList codeList) {
        getMetadataManagement().insertCodeList(codeList);
    }

    @Override
    public void insertCodeListTextsTable(CodeList codeList) {
        getMetadataManagement().insertCodeListTexts(codeList);
    }
}
