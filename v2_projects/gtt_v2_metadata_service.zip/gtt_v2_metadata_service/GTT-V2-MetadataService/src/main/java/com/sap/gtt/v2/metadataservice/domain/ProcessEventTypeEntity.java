package com.sap.gtt.v2.metadataservice.domain;

public class ProcessEventTypeEntity extends EventTypeEntity {
    public final static String ENTITY_TYPE = "PROCESS_EVENT_TYPE";
    @Override
    public String getEntityType() {
        return ENTITY_TYPE;
    }
}
