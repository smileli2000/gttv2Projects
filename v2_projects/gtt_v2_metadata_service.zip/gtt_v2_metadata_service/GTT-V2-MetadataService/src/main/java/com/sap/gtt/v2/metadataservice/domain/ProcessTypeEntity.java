package com.sap.gtt.v2.metadataservice.domain;

import org.apache.commons.collections.CollectionUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ProcessTypeEntity extends BaseEntity {
    private static final String ENTITY_TYPE = "PROCESS_TYPE";
    private String trackingIdType;
    private List<ProcessPlannedEvent> plannedEvents;
    private List<ProcessUnplannedEvent> admissibleUnplannedEvents;
    private Map<String, List<String>> authScopesMap = new HashMap<>();

    @Override
    public String getEntityType() {
        return ENTITY_TYPE;
    }

    public List<ProcessPlannedEvent> getPlannedEvents() {
        return new ArrayList<>(plannedEvents);
    }

    public void setPlannedEvents(List<ProcessPlannedEvent> plannedEvents) {
        this.plannedEvents = plannedEvents;
    }

    public List<ProcessUnplannedEvent> getAdmissibleUnplannedEvents() {
        return new ArrayList<>(admissibleUnplannedEvents);
    }

    public void setAdmissibleUnplannedEvents(List<ProcessUnplannedEvent> admissibleUnplannedEvents) {
        this.admissibleUnplannedEvents = admissibleUnplannedEvents;
    }

    public String getTrackingIdType() {
        return trackingIdType;
    }

    public void setTrackingIdType(String trackingIdType) {
        this.trackingIdType = trackingIdType;
    }

    public Map<String, List<String>> getAuthScopesMap() {
        List<EntityElement> elements = getElements();
        if (authScopesMap.isEmpty() && !CollectionUtils.isEmpty(elements)) {
            elements.forEach(e -> {
                List<String> authScopes = e.getAuthScopes();
                if (!authScopes.isEmpty()) {
                    authScopesMap.put(e.getName(), authScopes);
                }
            });
        }
        return authScopesMap;
    }

    @Override
    public String toString() {
        return "ProcessTypeEntity{" +
                "plannedEvents=" + plannedEvents +
                ", admissibleUnplannedEvents=" + admissibleUnplannedEvents +
                ", trackingIdType=" + trackingIdType +
                '}';
    }
}
