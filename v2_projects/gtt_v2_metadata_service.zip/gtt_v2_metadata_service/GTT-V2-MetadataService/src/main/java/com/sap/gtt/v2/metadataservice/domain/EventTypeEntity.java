package com.sap.gtt.v2.metadataservice.domain;

public class EventTypeEntity extends BaseEntity {
    public static final String ENTITY_TYPE = "EVENT_TYPE";

    @Override
    public String getEntityType() {
        return ENTITY_TYPE;
    }

    boolean isGttDelayedEvent = false;

    public boolean isGttDelayedEvent() {
        return isGttDelayedEvent;
    }

    public void setGttDelayedEvent(boolean gttDelayedEvent) {
        isGttDelayedEvent = gttDelayedEvent;
    }


}
