/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.gtt.v2.metadataservice.utils;

import com.google.gson.JsonObject;

/**
 *
 * @author I326335
 */
public class ValidatorUtil {

    public static final String MSG = "message";
    public static final String CODE = "code";
    public static final String ERROR = "error";
    public static final String ERR_NAMESPACE_EXIST = "This model namespace already exists.";
    public static final String ERR_DEPLOY_FAILED = "This model failed to deploy.";
    public static final String ERR_NOT_DEPLOYED = "This model is not deployed.";
    public static final String ERR_STATUS_INCORRECT = "Status value is incorrect.";
    public static final String ERR_NAMESPACE_INCORRECT = "The model namespace should be %s.";
    
    public static final String NAMESPACE = "namespace";
    
    private ValidatorUtil() {
        throw new IllegalStateException("Utility class");
    }
    
    public static JsonObject generateResultWithNamespace(String namespace) {
        JsonObject result = new JsonObject();
        result.addProperty(NAMESPACE, namespace);
        return result;
    }
}
