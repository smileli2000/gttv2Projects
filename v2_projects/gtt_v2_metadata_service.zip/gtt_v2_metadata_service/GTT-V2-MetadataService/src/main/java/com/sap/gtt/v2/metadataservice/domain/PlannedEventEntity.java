package com.sap.gtt.v2.metadataservice.domain;

public class PlannedEventEntity extends BaseEntity {

    public EntityElement getEntityElement(String entityElementName) {
        for (EntityElement entityElement : getElements()) {
            if (entityElement.getName().equalsIgnoreCase(entityElementName)) {
                return entityElement;
            }
        }
        return null;
    }

}
