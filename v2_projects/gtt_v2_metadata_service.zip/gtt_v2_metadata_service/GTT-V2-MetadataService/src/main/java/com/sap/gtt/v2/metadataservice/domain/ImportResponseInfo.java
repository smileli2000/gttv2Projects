package com.sap.gtt.v2.metadataservice.domain;

import com.sap.gtt.v2.core.entity.metadata.MetadataDraftModel;
import com.sap.gtt.v2.util.JsonUtils;

public class ImportResponseInfo extends DraftModelHeaderInfo{

    private String modifiedBy;

    public String getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(String modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public ImportResponseInfo(MetadataDraftModel model) {
        super(model);
    }

    public ImportResponseInfo(DraftModelBody draftModelBody, String modifiedBy) {
        super(draftModelBody.getNamespace(), draftModelBody.getVersion(), draftModelBody.getDescr());
        this.modifiedBy = modifiedBy;
        this.setStatus(draftModelBody.getStatus());
        this.setDraftStatus(draftModelBody.getDraftStatus());
        this.setUpdatedAt(draftModelBody.getUpdatedAt());
    }
    public String toJsonString() {
        return JsonUtils.generateJsonStringFromBean(this);
    }
}
