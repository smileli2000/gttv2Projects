package com.sap.gtt.v2.metadataservice.utils;

import com.sap.gtt.v2.exception.InternalErrorException;
import com.sap.gtt.v2.metadataservice.exception.FileException;
import org.apache.commons.io.IOUtils;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.util.ResourceUtils;
import org.springframework.web.util.UriUtils;

import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.nio.charset.StandardCharsets;

import static com.sap.gtt.v2.metadataservice.exception.FileException.MESSAGE_CODE_FILE_NOT_FOUND;

/**
 * @Author: Sarah
 * @Date: 4/30/2020 5:37 PM
 */
public class FileHelper {
    private static final String APPLICATION_FORCE_DOWNLOAD = "application/force-download";
    private static final String CONTENT_DISPOSITION = "Content-Disposition";
    private static final String ATTACHMENT_FILE_NAME = "attachment;fileName=";
    private static final String JSON = ".json";
    private static final String UTF_8 = "utf-8";

    private FileHelper() {
    }

    public static boolean download(HttpServletResponse response, String fileMessage, String namespace) {
        response.setCharacterEncoding(UTF_8);
        response.setContentType(APPLICATION_FORCE_DOWNLOAD);
        String encodedNamespace = UriUtils.encode(namespace, UTF_8);
        response.addHeader(CONTENT_DISPOSITION, ATTACHMENT_FILE_NAME + encodedNamespace + JSON);
        try (PrintWriter pw = response.getWriter()) {
            pw.write(fileMessage);
            return true;
        } catch (IOException e) {
            throw new InternalErrorException(e.getMessage(), e);
        }
    }

    public static void saveStringAsResourceFile(String fileMessage, String resourceFilePath) {

        try{
            String path = ResourceUtils.getURL("classpath:").getPath();
            File save = new File(path, resourceFilePath);
            if(!save.exists()){
                save.createNewFile();
            }
            try(FileWriter fileWritter = new FileWriter(save.getAbsolutePath(), false)) {
                fileWritter.write(fileMessage);
            }
        } catch (IOException e) {
            throw new FileException(e, MESSAGE_CODE_FILE_NOT_FOUND, new Object[]{resourceFilePath});
        }
    }

    public static String loadResourceFileAsString(String resourceFilePath) {
        Resource resource = new ClassPathResource(resourceFilePath);
        try (InputStream inputStream = resource.getInputStream()) {
            return IOUtils.toString(inputStream, StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new FileException(e, MESSAGE_CODE_FILE_NOT_FOUND, new Object[]{resourceFilePath});
        }
    }
}
