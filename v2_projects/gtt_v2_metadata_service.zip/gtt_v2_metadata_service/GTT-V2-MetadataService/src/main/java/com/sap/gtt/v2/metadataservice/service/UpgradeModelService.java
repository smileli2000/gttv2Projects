package com.sap.gtt.v2.metadataservice.service;

import com.sap.gtt.v2.configuration.AccessContextHolder;
import com.sap.gtt.v2.configuration.ISAPCloudPlatformAgent.ICurrentAccessContext;
import com.sap.gtt.v2.core.entity.metadata.MetadataProject;
import com.sap.gtt.v2.core.management.metadata.IMetadataManagement;
import com.sap.gtt.v2.log.TenantAwareLogService;
import com.sap.gtt.v2.metadataservice.service.impl.MetadataProjectExtractor;
import com.sap.gtt.v2.servicemanager.GTTInstance;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;


public class UpgradeModelService {
    @Autowired
    private TenantAwareLogService logService;
    private GTTInstance gttInstance;
    @Autowired
    private CoreModel coreModel;

    @Autowired
    private MetadataProjectExtractor extractor;
    @Autowired
    private ICurrentAccessContext currentAccessContext;

    @Autowired
    private MetadataProjectService metadataProjectService;


    protected UpgradeModelService(GTTInstance gttInstance) {
        this.gttInstance = gttInstance;
    }

    //upgrade model:
    public void execute(String namespace) {
        beforeRun();
        run(namespace);
        afterRun();
    }

    //retry model
    public void executeRetry(byte[] metadataByte, String namespace) {
        beforeRun();
        runRetry(metadataByte, namespace);
        afterRun();
    }


    protected void runRetry(byte[] metadataByte, String namespace) {
        IMetadataManagement metadataManagement = currentAccessContext.createBusinessOperator().getMetadataManagement();
        List<MetadataProject> metadataProjects;
        if (StringUtils.isBlank(namespace)) {
            metadataProjects = metadataManagement.findAllMetadataProject();
        } else {
            metadataProjects = metadataManagement.findMetadataProjectInfoByNamespace(namespace);
        }
        for (MetadataProject metadataProject : metadataProjects) {
            extractor.extractMetadataProjectInfoFromDb(metadataProject, metadataManagement);
            CoreModel coreModelFromZip = extractor.extractCoreModelFromZip(metadataByte);
            metadataProjectService.deployModelAndSave(metadataProject, coreModelFromZip, true);
        }
    }


    //upgrade run
    private void run(String namespace) {
        logService.info("in run method, the namespace is {}",namespace);
        IMetadataManagement metadataManagement = currentAccessContext.createBusinessOperator().getMetadataManagement();
        List<MetadataProject> metadataProjects;
        if (StringUtils.isBlank(namespace)) {
            metadataProjects = metadataManagement.findAllMetadataProject();
        } else {
            metadataProjects = metadataManagement.findMetadataProjectInfoByNamespace(namespace);
        }
        for (MetadataProject metadataProject : metadataProjects) {
            logService.info("in run method before extractMetadataProjectInfoFromDb, the metadataProject is {}",metadataProject.toString());
            extractor.extractMetadataProjectInfoFromDb(metadataProject, metadataManagement);
            metadataProjectService.deployModelAndSave(metadataProject, null, false);
        }
    }

    private void beforeRun() {
        // set access context in context holder
        AccessContextHolder.AccessContext accessContext = new AccessContextHolder.AccessContext
                (null, null, null, null,
                        ICurrentAccessContext.getLocale(),
                        gttInstance,
                        false,
                        false,
                        false,
                        true);
        AccessContextHolder.set(accessContext);
    }

    private void afterRun() {
        AccessContextHolder.clear();
    }

}
