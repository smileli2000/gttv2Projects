package com.sap.gtt.v2.metadataservice.domain;

import java.util.Objects;

public class ItemTypeEntity extends BaseEntity {
    private static final String ENTITY_TYPE = "ITEM_TYPE";

    public String getSubModelBeanName() {
        return subModelBeanName;
    }

    public void setSubModelBeanName(String subModelBeanName) {
        this.subModelBeanName = subModelBeanName;
    }

    private String subModelBeanName;

    public boolean isHasCompositionAttribute() {
        return hasCompositionAttribute;
    }

    public void setHasCompositionAttribute(boolean hasCompositionAttribute) {
        this.hasCompositionAttribute = hasCompositionAttribute;
    }

    private boolean hasCompositionAttribute = false;

    @Override
    public String getEntityType() {
        return ENTITY_TYPE;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ItemTypeEntity that = (ItemTypeEntity) o;
        return Objects.equals(getName(), that.getName()) &&
                Objects.equals(getSubModelBeanName(), that.getSubModelBeanName());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getName(), getSubModelBeanName());
    }

}
