package com.sap.gtt.v2.metadataservice.service;


import com.sap.gtt.v2.core.entity.metadata.MetadataChangeHistory;
import com.sap.gtt.v2.core.entity.metadata.MetadataDraftModel;
import com.sap.gtt.v2.core.entity.metadata.MetadataProject;
import com.sap.gtt.v2.metadataservice.domain.DeploymentHistory;
import com.sap.gtt.v2.metadataservice.domain.DraftModelBody;
import com.sap.gtt.v2.metadataservice.domain.DraftModelHeaderInfo;

import java.util.List;

/**
 * @author i311486
 */
public interface MetadataManageModelsService {
    /**
     * Find model change histories by namespace
     * @param namespace
     * @return List of Metadata change history
     */
    
    List<DeploymentHistory> findMetadataChangeHistoriesByNamespace(String namespace);
    /**
     * Find model project info by namespace
     * @param namespace
     * @return List of Metadata project info
     */
    List<MetadataProject> findMetadataProjectInfoByNamespace(String namespace);

    /**
     * Save model change history
     * @param metadataChangeHistory
     */
    void saveMetadataChangeHistory(MetadataChangeHistory metadataChangeHistory);

    /**
     * Get all draft model header information
     * @return
     */
    List<DraftModelHeaderInfo> getAllMetadataDraftModelHeaderInfo();
    
    /**
     * Get draft model header information by namespace
     * @param namespace
     * @return
     */
    public DraftModelHeaderInfo getMetadataDraftModelHeaderInfoByNamespace(String namespace);
    

    /**
     * Get all the draft model including jsonModel information
     * @return all the draft models with jsonModel
     */
    List<MetadataDraftModel> getAllMetadataDraftModelsInfo();

    /**
     * Create a draft model
     * @param draftModelBody
     */
    void createMetadataDraftModel(DraftModelBody draftModelBody);

    /**
     * Update a draft model information
     *
     * @param metadataDraftModel
     */
    void updateMetadataDraftModelInfo(MetadataDraftModel metadataDraftModel);

    /**
     * Update a draft model
     * @param namespace
     * @param draftModelBody
     */
    void updateMetadataDraftModel(String namespace, DraftModelBody draftModelBody);

    /**
     * Delete a draft model
     * @param namespace
     */
    void deleteMetadataDraftModel(String namespace);

    /**
     * Get draft model by namespace
     * @param namespace
     * @return
     */
    MetadataDraftModel getMetadataDraftModelInfoByNamespace(String namespace);

    /**
     * Get draft model by namespace
     * @param namespace
     * @return
     */
    DraftModelBody getMetadataDraftModelByNamespace(String namespace);

}
