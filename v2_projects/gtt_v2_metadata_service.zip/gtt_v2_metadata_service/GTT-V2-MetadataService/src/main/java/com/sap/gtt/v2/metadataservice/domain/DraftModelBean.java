package com.sap.gtt.v2.metadataservice.domain;

import java.util.*;

public class DraftModelBean {
    private String name;
    private String namespace;
    private String schemaVersion;
    private String description;
    private boolean enableInstanceBasedAuthorization;
    private int eventCorrelationLevel = 1;
    private PlannedEventEntity plannedEventEntity;
    private List<SubModelsBean> subModels;
    private Map<String, Map<String, String>> i18nFileInfo = new HashMap();
    private Map<String, Set<CodeListValue>> codeListValueInfoMap = new HashMap();
    private Map<String, ItemTypeEntity> originalItemTypeEntityMap = new HashMap();
    private Map<String, Set<ItemTypeEntity>> itemTypeEntityInfoMap = new HashMap();
    private Set<String> processEntitiesNameSet = new HashSet();

    public PlannedEventEntity getPlannedEventEntity() {
        return plannedEventEntity;
    }

    public void setPlannedEventEntity(PlannedEventEntity plannedEventEntity) {
        this.plannedEventEntity = plannedEventEntity;
    }

    public Set<String> getProcessEntitiesNameSet() {
        return processEntitiesNameSet;
    }

    public void setProcessEntitiesNameSet(Set<String> processEntitiesNameSet) {
        this.processEntitiesNameSet = processEntitiesNameSet;
    }

    public Map<String, Set<String>> getUsingEntityNameMap() {
        return usingEntityNameMap;
    }

    public void setUsingEntityNameMap(Map<String, Set<String>> usingEntityNameMap) {
        this.usingEntityNameMap = usingEntityNameMap;
    }

    private Map<String, Set<String>> usingEntityNameMap = new HashMap();


    public Map<String, Set<ItemTypeEntity>> getItemTypeEntityInfoMap() {
        return itemTypeEntityInfoMap;
    }

    public void setItemTypeEntityInfoMap(Map<String, Set<ItemTypeEntity>> itemTypeEntityInfoMap) {
        this.itemTypeEntityInfoMap = itemTypeEntityInfoMap;
    }

    public Map<String, ItemTypeEntity> getOriginalItemTypeEntityMap() {
        return originalItemTypeEntityMap;
    }

    public void setOriginalItemTypeEntityMap(Map<String, ItemTypeEntity> originalItemTypeEntityMap) {
        this.originalItemTypeEntityMap = originalItemTypeEntityMap;
    }

    public Map<String, Set<CodeListValue>> getCodeListValueInfoMap() {
        return codeListValueInfoMap;
    }

    public void setCodeListValueInfoMap(Map<String, Set<CodeListValue>> codeListValueInfoMap) {
        this.codeListValueInfoMap = codeListValueInfoMap;
    }

    public Map<String, Map<String, String>> getI18nFileInfo() {
        return i18nFileInfo;
    }

    public void setI18nFileInfo(Map<String, Map<String, String>> i18nFileInfo) {
        this.i18nFileInfo = i18nFileInfo;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNamespace() {
        return namespace;
    }

    public void setNamespace(String namespace) {
        this.namespace = namespace;
    }

    public String getSchemaVersion() {
        return schemaVersion;
    }

    public void setSchemaVersion(String schemaVersion) {
        this.schemaVersion = schemaVersion;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public boolean isEnableInstanceBasedAuthorization() {
        return enableInstanceBasedAuthorization;
    }

    public void setEnableInstanceBasedAuthorization(boolean enableInstanceBasedAuthorization) {
        this.enableInstanceBasedAuthorization = enableInstanceBasedAuthorization;
    }

    public int getEventCorrelationLevel() {
        return eventCorrelationLevel;
    }

    public void setEventCorrelationLevel(int eventCorrelationLevel) {
        this.eventCorrelationLevel = eventCorrelationLevel;
    }

    public List<SubModelsBean> getSubModels() {
        return subModels;
    }

    public void setSubModels(List<SubModelsBean> subModels) {
        this.subModels = subModels;
    }

    @Override
    public String toString() {
        return "DraftModelBean{" +
                "name='" + name + '\'' +
                ", namespace='" + namespace + '\'' +
                ", schemaVersion='" + schemaVersion + '\'' +
                ", subModels=" + subModels +
                ", i18nFileInfo=" + i18nFileInfo +
                ", codeListValueInfoMap=" + codeListValueInfoMap +
                ", processEntitiesNameSet =" + processEntitiesNameSet +
                '}';
    }
}
