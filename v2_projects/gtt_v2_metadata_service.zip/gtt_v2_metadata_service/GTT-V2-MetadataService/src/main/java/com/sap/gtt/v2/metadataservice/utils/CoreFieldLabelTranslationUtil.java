package com.sap.gtt.v2.metadataservice.utils;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.sap.gtt.v2.core.domain.metadata.MetadataConstants;
import com.sap.gtt.v2.util.JsonUtils;
import org.springframework.context.MessageSource;

import java.util.*;

import static com.sap.gtt.v2.metadataservice.utils.Constant.*;


/**
 * @author I324402
 */
public class CoreFieldLabelTranslationUtil {

    private static final List<String> coreModelTypes = new ArrayList<>();
    private static final List<String> basePlanTypeList = new ArrayList<>();
    private static final List<String> baseGTTDelayedEventTypeList = new ArrayList<>();
    private static final List<String> baseGTTOnTimeEventTypeList = new ArrayList<>();
    private static final List<String> basePlanFieldLabelList = new ArrayList<>();
    private static final List<String> baseGTTDelayedEventFieldLabelList = new ArrayList<>();
    private static final List<String> baseGTTOnTimeFieldLabelList = new ArrayList<>();
    private static final Map<String, List<String>> baseFieldMap = new HashMap<>(DEFAULT_COLLECTION_SIZE);

    static {
        coreModelTypes.add(PROCESS_TYPES);
        coreModelTypes.add(ITEM_TYPES);
        coreModelTypes.add(EVENT_TYPES);

        basePlanTypeList.add(PLANNED_EVENT_FOR_UPDATE_PALNEVENT);
        basePlanTypeList.add(PLANNED_EVENT);

        baseGTTDelayedEventTypeList.add(GTT_DELAYED_EVENT);
        baseGTTOnTimeEventTypeList.add(GTT_ONTIME_EVENT);

        for (MetadataConstants.BasePlanField value : MetadataConstants.BasePlanField.values()) {
            basePlanFieldLabelList.add(value.getValue());
        }

        baseGTTDelayedEventFieldLabelList.add(REF_PLANNED_EVENT_TYPE);
        baseGTTDelayedEventFieldLabelList.add(REF_PLANNED_EVENT_MATCH_KEY);
        baseGTTDelayedEventFieldLabelList.add(REF_PLANNED_EVENT_LOCATION_ALT_KEY);

        baseGTTOnTimeFieldLabelList.add(REF_PLANNED_EVENT_TYPE);
        baseGTTOnTimeFieldLabelList.add(REF_PLANNED_EVENT_MATCH_KEY);
        baseGTTOnTimeFieldLabelList.add(REF_PLANNED_EVENT_LOCATION_ALT_KEY);

        baseFieldMap.put(BASE_PLAN_FIELD_LABEL_LIST, basePlanFieldLabelList);
        baseFieldMap.put(BASE_GTT_DELAYED_EVENT_FIELD_LABEL_LIST, baseGTTDelayedEventFieldLabelList);
        baseFieldMap.put(BASE_GTT_ONTIME_FIELD_LABEL_LIST, baseGTTOnTimeFieldLabelList);
    }


    private CoreFieldLabelTranslationUtil() {
        throw new IllegalStateException("Utility class");
    }

    public static String generateCoreFieldLabelTranslation(String coreModelSting, MessageSource messageSource) {

        JsonObject coreModelObj = JsonUtils.generateJsonObjectFromJsonString(coreModelSting);
        for (String types : coreModelTypes) {
            JsonArray typeArr = coreModelObj.get(types).getAsJsonArray();
            handelType(basePlanTypeList, baseGTTDelayedEventTypeList, baseGTTOnTimeEventTypeList, baseFieldMap, typeArr, messageSource);
        }
        return coreModelObj.toString();
    }

    private static void handelType(List<String> basePlanTypeList, List<String> baseGTTDelayedEventTypeList, List<String> baseGTTOnTimeEventTypeList, Map<String, List<String>> baseFieldMap, JsonArray typeArr, MessageSource messageSource) {
        for (JsonElement type : typeArr) {
            String typeName = type.getAsJsonObject().get(NAME).getAsString();
            JsonArray typeElementArr = type.getAsJsonObject().get(ELEMENTS).getAsJsonArray();
            handelElements(basePlanTypeList, baseGTTDelayedEventTypeList, baseGTTOnTimeEventTypeList, baseFieldMap, typeName, typeElementArr, messageSource);
        }
    }

    private static void handelElements(List<String> basePlanTypeList, List<String> baseGTTDelayedEventTypeList, List<String> baseGTTOnTimeEventTypeList, Map<String, List<String>> baseFieldMap, String typeName, JsonArray typeElementArr, MessageSource messageSource) {
        for (JsonElement typeElement : typeElementArr) {
            //element
            StringBuilder elementCode = new StringBuilder("EL_");
            String elementName = typeElement.getAsJsonObject().get(NAME).getAsString();
            handleBaseField(basePlanTypeList, baseGTTDelayedEventTypeList, baseGTTOnTimeEventTypeList, baseFieldMap, typeName, elementCode, elementName);
            elementCode.append(UNDERLINE).append(elementName).append(UNDERLINE).append(LABEL_UPPER);
            List<Locale> localeList = LocaleUtils.getLocales();
            JsonObject localeTextObj = LocaleUtils.handleLocale(elementCode, localeList, messageSource);
            JsonObject lableObj = new JsonObject();
            lableObj.addProperty(TEXT_TYPE, LABEL_UPPER);
            lableObj.add(TRANSLATION, localeTextObj);
            JsonObject translationLableObj = new JsonObject();
            translationLableObj.add(LABEL, lableObj);
            typeElement.getAsJsonObject().add(TRANSLATION, translationLableObj);
        }
    }

    private static void handleBaseField(List<String> basePlanTypeList, List<String> baseGTTDelayedEventTypeList, List<String> baseGTTOnTimeEventTypeList, Map<String, List<String>> baseFieldMap, String typeName, StringBuilder elementCode, String elementName) {
        if (basePlanTypeList.contains(typeName) && baseFieldMap.get(BASE_PLAN_FIELD_LABEL_LIST).contains(elementName)) {
            elementCode.append(BASE_PLAN);
        } else if (baseGTTDelayedEventTypeList.contains(typeName) && baseFieldMap.get(BASE_GTT_DELAYED_EVENT_FIELD_LABEL_LIST).contains(elementName)) {
            elementCode.append(BASE_GTT_DELAYED_EVENT);
        } else if (baseGTTOnTimeEventTypeList.contains(typeName) && baseFieldMap.get(BASE_GTT_ONTIME_FIELD_LABEL_LIST).contains(elementName)) {
            elementCode.append(BASE_GTT_ONTIME_EVENT);
        } else {
            elementCode.append(typeName);
        }
    }
}
