package com.sap.gtt.v2.metadataservice.domain;

public class MatchExtensionField {
    private String plannedEventField;

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }

    public String getActualEventField() {
        return actualEventField;
    }

    public void setActualEventField(String actualEventField) {
        this.actualEventField = actualEventField;
    }

    private String operator;
    private String actualEventField;

    public String getPlannedEventField() {
        return plannedEventField;
    }

    public void setPlannedEventField(String plannedEventField) {
        this.plannedEventField = plannedEventField;
    }

    @Override
    public String toString() {
        return "MatchExtensionField{" +
                "plannedEventField='" + plannedEventField + '\'' +
                ", operator='" + operator + '\'' +
                ", actualEventField='" + actualEventField + '\'' +
                '}';
    }
}
