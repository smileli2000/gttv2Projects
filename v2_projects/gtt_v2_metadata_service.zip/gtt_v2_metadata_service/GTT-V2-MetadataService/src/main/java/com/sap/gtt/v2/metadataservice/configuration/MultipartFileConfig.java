package com.sap.gtt.v2.metadataservice.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.servlet.MultipartConfigElement;

@Configuration
public class MultipartFileConfig {
    @Bean(name = "multipartConfigElement")
    public MultipartConfigElement getMultipartConfigElement() {
        return new GTTMultipartConfigElement("");
    }
}