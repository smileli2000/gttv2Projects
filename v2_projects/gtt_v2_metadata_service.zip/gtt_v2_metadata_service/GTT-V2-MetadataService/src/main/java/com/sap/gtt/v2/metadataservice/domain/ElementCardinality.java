package com.sap.gtt.v2.metadataservice.domain;

public class ElementCardinality {
    private String max;

    public String getMax() {
        return max;
    }

    public void setMax(String max) {
        this.max = max;
    }

    @Override
    public String toString() {
        return "ElementCardinality{" +
                "max='" + max + '\'' +
                '}';
    }
}
