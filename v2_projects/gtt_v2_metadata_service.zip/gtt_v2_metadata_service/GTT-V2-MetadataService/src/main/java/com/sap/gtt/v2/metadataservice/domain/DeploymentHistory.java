package com.sap.gtt.v2.metadataservice.domain;

import com.sap.gtt.v2.core.entity.metadata.MetadataChangeHistory;

import java.io.Serializable;
import java.util.Objects;

public class DeploymentHistory implements Serializable {

    private static final long serialVersionUID = 4349241515508803714L;
    private String id;
    private String changedAt;
    private String comment;
    private String namespace;
    private String changedBy;
    private String action;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getChangedAt() {
        return changedAt;
    }

    public void setChangedAt(String changedAt) {
        this.changedAt = changedAt;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getNamespace() {
        return namespace;
    }

    public void setNamespace(String namespace) {
        this.namespace = namespace;
    }

    public String getChangedBy() {
        return changedBy;
    }

    public void setChangedBy(String changedBy) {
        this.changedBy = changedBy;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        DeploymentHistory that = (DeploymentHistory) o;
        return Objects.equals(id, that.id) &&
                Objects.equals(changedAt, that.changedAt) &&
                Objects.equals(comment, that.comment) &&
                Objects.equals(namespace, that.namespace) &&
                Objects.equals(changedBy, that.changedBy) &&
                Objects.equals(action, that.action);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, changedAt, comment, namespace, changedBy, action);
    }

    public static DeploymentHistory convertFrom(MetadataChangeHistory metadataChangeHistory) {
        DeploymentHistory deploymentHistory = new DeploymentHistory();
        deploymentHistory.setId(metadataChangeHistory.getId());
        deploymentHistory.setNamespace(metadataChangeHistory.getNamespace());
        deploymentHistory.setComment(metadataChangeHistory.getComment());
        deploymentHistory.setChangedAt(metadataChangeHistory.getChangeTime().toString());
        deploymentHistory.setChangedBy(metadataChangeHistory.getUserEmail());
        deploymentHistory.setAction(metadataChangeHistory.getAction());
        return deploymentHistory;
    }
}
