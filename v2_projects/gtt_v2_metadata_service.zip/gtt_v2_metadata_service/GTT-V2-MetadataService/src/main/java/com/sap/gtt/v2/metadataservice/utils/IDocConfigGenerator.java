package com.sap.gtt.v2.metadataservice.utils;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.sap.gtt.v2.util.JsonUtils;
import org.apache.commons.lang3.StringUtils;

import static com.sap.gtt.v2.metadataservice.utils.Constant.*;

/**
 * @author i311486
 */
public class IDocConfigGenerator {
    private IDocConfigGenerator() {
        throw new IllegalStateException();
    }

    public static String genIDocConfiguration(String jsonModelString, String namespace) {
        if (!StringUtils.isNotBlank(jsonModelString)) {
            return null;
        }
        JsonObject iDocConfig = new JsonObject();
        JsonArray processTypes = new JsonArray();
        JsonArray eventTypes = new JsonArray();
        JsonObject jsonModel = JsonUtils.generateJsonObjectFromJsonString(jsonModelString);
        JsonArray subModels = jsonModel.get(SUB_MODELS).getAsJsonArray();
        subModels.forEach(subModel -> {
            JsonObject subModelObject = subModel.getAsJsonObject();
            JsonArray itemTypes = null;
            if (subModelObject.has(ITEM_TYPES)) {
                itemTypes = subModelObject.get(ITEM_TYPES).getAsJsonArray();
            }
            String subModelName = subModelObject.get(NAME).getAsString();
            String finalSubModelName = namespace + "." + subModelName;
            handleTypeObject(true, subModelObject, itemTypes, finalSubModelName, processTypes);
            handleTypeObject(false, subModelObject, itemTypes, finalSubModelName, eventTypes);
        });
        iDocConfig.add(PROCESS_TYPES, processTypes);
        iDocConfig.add(EVENT_TYPES, eventTypes);
        return iDocConfig.toString();
    }

    private static void handleTypeObject(boolean isProcess, JsonObject subModelObject, JsonArray itemTypes, String finalSubModelName, JsonArray typesArray) {
        String type = isProcess ? PROCESS_TYPES : EVENT_TYPES;
        boolean enableIDoc = false;
        if (subModelObject.has(IDOC_ENABLED)) {
            enableIDoc = subModelObject.get(IDOC_ENABLED).getAsBoolean();
        }
        if (!subModelObject.has(type)) {
            return;
        }
        JsonArray objectArray = subModelObject.get(type).getAsJsonArray();
        for (JsonElement objectType : objectArray) {
            JsonObject objectTypeObj = objectType.getAsJsonObject();
            if (objectTypeObj.has(IDOC_MAPPING)) {
                String objectTypeName = new StringBuilder(finalSubModelName)
                        .append(".")
                        .append(objectTypeObj.get(NAME).getAsString()).toString();
                JsonObject idocMapping = objectTypeObj.get(IDOC_MAPPING).getAsJsonObject();
                if (idocMapping.has(FIELD_MAPPING)) {
                    JsonArray fieldMappingArray = idocMapping.get(FIELD_MAPPING).getAsJsonArray();
                    handleCodeListFields(objectTypeObj, fieldMappingArray, itemTypes);
                }
                JsonObject mappingObj = new JsonObject();
                mappingObj.addProperty(NAME, objectTypeName);
                mappingObj.addProperty(IDOC_ENABLED, enableIDoc);
                mappingObj.add(IDOC_MAPPING, idocMapping);
                typesArray.add(mappingObj);
            }
        }

    }


    private static void handleCodeListFields(JsonObject typeObject, JsonArray fieldMappingArray, JsonArray itemTypes) {
        fieldMappingArray.forEach(field -> {
            JsonObject fieldMapping = field.getAsJsonObject();
            String fieldName = fieldMapping.get(FIELD).getAsString();
            if (fieldMapping.has(COMPOSITION)) {
                String target = fieldMapping.get(TARGET).getAsString();
                target = StringUtils.substring(target, target.lastIndexOf('.') + 1);
                JsonArray composition = fieldMapping.get(COMPOSITION).getAsJsonArray();
                handleCompositionFields(target, composition, itemTypes);
            } else {
                JsonArray elements = typeObject.get(ELEMENTS).getAsJsonArray();
                elements.forEach(elem -> {
                    JsonObject element = elem.getAsJsonObject();
                    if (element.get(NAME).getAsString().equals(fieldName) && element.get(TYPE).getAsString().equals(CODE_LIST)) {
                        fieldMapping.addProperty(TYPE, CODE_LIST);
                    }
                });
            }
        });
    }

    private static void handleCompositionFields(String target, JsonArray composition, JsonArray itemTypes) {
        if (itemTypes == null) {
            return;
        }
        itemTypes.forEach(item -> {
            JsonObject itemType = item.getAsJsonObject();
            if (itemType.get(NAME).getAsString().equals(target)) {
                handleCodeListFields(itemType, composition, itemTypes);
            }
        });
    }

}
