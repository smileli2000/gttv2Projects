package com.sap.gtt.v2.metadataservice.utils;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.sap.gtt.v2.util.JsonUtils;
import org.springframework.context.MessageSource;

import java.util.*;

import static com.sap.gtt.v2.metadataservice.utils.Constant.*;

/**
 * @author I324402
 */
public class EventTypeDescriptionUtils {

    private EventTypeDescriptionUtils() {
    }

    //Generate translation node to coreModel from i18n
    public static String generateCoreEventTypeDescrTranslation(String coreModel, MessageSource messageSource) {
        JsonObject coreModelObj = JsonUtils.generateJsonObjectFromJsonString(coreModel);

        JsonArray typeArr = coreModelObj.get(EVENT_TYPES).getAsJsonArray();
        for (JsonElement eventType : typeArr) {
            JsonObject eventTypeObj = eventType.getAsJsonObject();
            String name = eventTypeObj.get(NAME).getAsString();
            String descr = eventTypeObj.get(DESCR).getAsString();
            StringBuilder eventTypeCode = new StringBuilder(ET);
            eventTypeCode.append(UNDERLINE);
            eventTypeCode.append(name);
            eventTypeCode.append(UNDERLINE);
            eventTypeCode.append(DESCR_UPPER);
            List<Locale> localeList = LocaleUtils.getLocales();
            JsonObject localeTextsObj = LocaleUtils.handleLocale(eventTypeCode, localeList, messageSource);
            JsonObject lableObj = new JsonObject();
            lableObj.addProperty(TEXT_TYPE, DESCR_UPPER);
            lableObj.add(TRANSLATION, localeTextsObj);
            JsonObject translationLableObj = new JsonObject();
            translationLableObj.add(DESCR, lableObj);
            eventType.getAsJsonObject().add(TRANSLATION, translationLableObj);
        }
        return coreModelObj.toString();
    }

    //Add custom eventType description from customModel to i18n
    public static String addCustomEventTypeDescrI18n(String i18n, String customJsonModel) {

        JsonObject i18nObj = JsonUtils.generateJsonObjectFromJsonString(i18n);
        Map<String, String> localeDescrsMap = new HashMap<>();
        for (String localeProp : i18nObj.keySet()) {
            localeDescrsMap.put(localeProp, i18nObj.get(localeProp).getAsString());
        }
        if (customJsonModel != null) {
            JsonObject customJsonModelObj = JsonUtils.generateJsonObjectFromJsonString(customJsonModel);
            handleSubModels(localeDescrsMap, customJsonModelObj);
        }

        for (Map.Entry<String, String> entry : localeDescrsMap.entrySet()) {
            i18nObj.addProperty(entry.getKey(), entry.getValue());
        }
        return i18nObj.toString();
    }

    private static void handleSubModels(Map<String, String> localeDescrsMap, JsonObject customJsonModelObj) {
        if (customJsonModelObj.has(SUBMODELS)) {
            JsonArray subModelsArr = customJsonModelObj.get(SUBMODELS).getAsJsonArray();
            for (JsonElement subModel : subModelsArr) {
                handleEventTypeArr(localeDescrsMap, subModel);
            }
        }
    }

    private static void handleEventTypeArr(Map<String, String> localeDescrsMap, JsonElement subModel) {
        if (subModel.getAsJsonObject().has(EVENT_TYPES)) {
            JsonArray subModelEventTypeArr = subModel.getAsJsonObject().get(EVENT_TYPES).getAsJsonArray();
            for (JsonElement subModelEventType : subModelEventTypeArr) {
                if (subModelEventType.getAsJsonObject().has(NAME) && subModelEventType.getAsJsonObject().has(DESCR)) {
                    String name = subModelEventType.getAsJsonObject().get(NAME).getAsString();
                    String descr = subModelEventType.getAsJsonObject().get(DESCR).getAsString();
                    handleTranslation(localeDescrsMap, subModelEventType, name, descr);
                }
            }
        }
    }

    private static void handleTranslation(Map<String, String> localeDescrsMap, JsonElement subModelEventType, String name, String descr) {
        if (subModelEventType.getAsJsonObject().has(TRANSLATION)) {
            JsonObject eventTypeTransObj = subModelEventType.getAsJsonObject().get(TRANSLATION).getAsJsonObject();
            JsonObject eventTypeTextsObj = eventTypeTransObj.get(DESCR).getAsJsonObject().get(TRANSLATION).getAsJsonObject();

            StringBuilder defaultDescrs = localeDescrsMap.keySet().contains(I18NDOTPROPS) ? new StringBuilder(localeDescrsMap.get(I18NDOTPROPS)) : new StringBuilder("");
            handleDescrKey(name, defaultDescrs);
            defaultDescrs.append(descr);
            defaultDescrs.append("\n");
            localeDescrsMap.put(I18NDOTPROPS, defaultDescrs.toString());

            handleEventTypeDescrTexts(localeDescrsMap, name, eventTypeTextsObj);
        }
    }

    private static void handleEventTypeDescrTexts(Map<String, String> localeDescrsMap, String name, JsonObject eventTypeTextsObj) {
        for (String lang : eventTypeTextsObj.keySet()) {
            String localeProp = I18N_UNDERLINE + lang + DOTPROPS;
            StringBuilder descrs = localeDescrsMap.keySet().contains(localeProp) ? new StringBuilder(localeDescrsMap.get(localeProp)) : new StringBuilder("");
            handleDescrKey(name, descrs);
            descrs.append(eventTypeTextsObj.get(lang).getAsString());
            descrs.append("\n");
            localeDescrsMap.put(localeProp, descrs.toString());
        }
    }

    private static void handleDescrKey(String name, StringBuilder descrs) {
        descrs.append(ET);
        descrs.append(UNDERLINE);
        descrs.append(name);
        descrs.append(UNDERLINE);
        descrs.append(DESCR_UPPER);
        descrs.append(EQUAL);
    }
}