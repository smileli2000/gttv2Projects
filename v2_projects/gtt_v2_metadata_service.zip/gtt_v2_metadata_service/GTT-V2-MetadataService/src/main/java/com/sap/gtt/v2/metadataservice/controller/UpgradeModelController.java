package com.sap.gtt.v2.metadataservice.controller;

import com.sap.gtt.v2.metadataservice.service.UpgradeModelServiceManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(UpgradeModelController.ROOT_URL)
public class UpgradeModelController {
    public static final String ROOT_URL = "/sap/logistics/gtt/metadata/v1/upgrade-model";

    @Autowired
    private UpgradeModelServiceManager upgradeModelServiceManager;

    @PostMapping(value = "/upgradeAll")
    public ResponseEntity<String> upgradeAllModel() {
        upgradeModelServiceManager.upgradeAll();
        return new ResponseEntity<>(HttpStatus.OK);
    }
    @PostMapping(value = "/upgrade")
    public ResponseEntity<String> upgradeTheModel(@RequestParam(value = "instance",required = true) String instance,@RequestParam(value = "model",required = false) String model) {
        upgradeModelServiceManager.upgrade(instance,model);
        return new ResponseEntity<>(HttpStatus.OK);
    }


    @PostMapping(value = "/tryUpgradeAll", consumes = "application/x-zip-compressed")
    public ResponseEntity<String> upgradeRetryAllModel(@RequestBody byte[] metadataByte) {
        upgradeModelServiceManager.upgradeRetryAll(metadataByte);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @PostMapping(value = "/tryUpgrade", consumes = "application/x-zip-compressed")
    public ResponseEntity<String> upgradeRetryTheModel(@RequestParam(value = "instance",required = true) String instance,@RequestParam(value = "model",required = false) String model, @RequestBody byte[] metadataByte) {
        upgradeModelServiceManager.upgradeRetry(instance,model,metadataByte);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
