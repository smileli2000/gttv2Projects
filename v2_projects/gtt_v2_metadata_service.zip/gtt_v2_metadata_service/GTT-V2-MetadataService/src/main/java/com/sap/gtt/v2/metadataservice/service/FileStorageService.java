package com.sap.gtt.v2.metadataservice.service;

import com.sap.gtt.v2.log.TenantAwareLogService;
import com.sap.gtt.v2.metadataservice.exception.FileException;
import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.UUID;

import static com.sap.gtt.v2.metadataservice.exception.FileException.*;
import static com.sap.gtt.v2.metadataservice.utils.Constant.JAVA_IO_TEMP_DIR;
import static com.sap.gtt.v2.util.GTTUtils.UUIDUtils.generateTimeBasedUUID;

/**
 * @author I324402
 */
@Service
public class FileStorageService {

    private Path fileStorageLocation;

    @Autowired
    private TenantAwareLogService logService;

    @Autowired
    public FileStorageService() {
        this.fileStorageLocation = Paths.get(System.getProperty(JAVA_IO_TEMP_DIR))
                .toAbsolutePath().normalize();
    }

    public String storeFile(MultipartFile file) {
        UUID uuid = generateTimeBasedUUID();
        String fileName = StringUtils.cleanPath(uuid.toString());
        Path targetLocation = this.fileStorageLocation.resolve(fileName);
        try (InputStream fileInputStream = file.getInputStream()) {
            Files.copy(fileInputStream, targetLocation, StandardCopyOption.REPLACE_EXISTING);
            return fileName;
        } catch (IOException ex) {
            throw new FileException(ex, MESSAGE_CODE_CREATE_FILE_FAILED, new Object[]{fileName});
        }
    }

    public void deleteFile(String fileName) {
        Path filePath = this.fileStorageLocation.resolve(fileName).normalize();
        File file = new File(filePath.toString());
        if (file.isFile() && file.exists()) {
            try {
                Files.delete(filePath);
            } catch (IOException e) {
                logService.debug(e.getMessage());
            }
        }
    }

    public Resource loadFileAsResource(String fileName) {
        try {
            Path filePath = this.fileStorageLocation.resolve(fileName).normalize();
            Resource resource = new UrlResource(filePath.toUri());
            if (resource.exists()) {
                return resource;
            } else {
                throw new FileException(MESSAGE_CODE_FILE_NOT_FOUND, new Object[]{fileName});
            }
        } catch (MalformedURLException ex) {
            throw new FileException(MESSAGE_CODE_FILE_NOT_FOUND, new Object[]{fileName});
        }
    }

    public String loadFileAsString(String fileName) {
        Resource resource = loadFileAsResource(fileName);
        try (InputStream inputStream = resource.getInputStream()) {
            return IOUtils.toString(inputStream, StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new FileException(e, MESSAGE_CODE_FILE_NOT_FOUND, new Object[]{fileName});
        }
    }

    public String loadFileAsString(MultipartFile file) {
        try (InputStream inputStream = file.getInputStream()) {
            return IOUtils.toString(inputStream, StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new FileException(e, MESSAGE_CODE_FILE_NOT_FOUND, null);
        }
    }
}
