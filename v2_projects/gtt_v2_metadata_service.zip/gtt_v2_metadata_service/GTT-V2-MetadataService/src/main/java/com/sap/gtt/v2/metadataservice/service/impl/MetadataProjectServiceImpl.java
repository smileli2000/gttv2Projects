package com.sap.gtt.v2.metadataservice.service.impl;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.sap.gtt.v2.configuration.GTTRestTemplate;
import com.sap.gtt.v2.configuration.ISAPCloudPlatformAgent.ICurrentAccessContext;
import com.sap.gtt.v2.core.dao.metadata.DefaultSysTableDao;
import com.sap.gtt.v2.core.domain.metadata.*;
import com.sap.gtt.v2.core.domain.metadata.MetadataConstants.MetadataProjectStatus;
import com.sap.gtt.v2.core.entity.metadata.*;
import com.sap.gtt.v2.core.management.metadata.CsnParser;
import com.sap.gtt.v2.core.management.metadata.IMetadataManagement;
import com.sap.gtt.v2.core.management.tracking.ITrackedProcessManagement;
import com.sap.gtt.v2.exception.InternalErrorException;
import com.sap.gtt.v2.log.TenantAwareLogService;
import com.sap.gtt.v2.metadataservice.exception.MetadataServiceValidationException;
import com.sap.gtt.v2.metadataservice.service.CoreModel;
import com.sap.gtt.v2.metadataservice.service.MetadataProjectService;
import com.sap.gtt.v2.metadataservice.service.SysTableService;
import com.sap.gtt.v2.metadataservice.utils.Constant;
import com.sap.gtt.v2.metadataservice.utils.LocaleUtils;
import com.sap.gtt.v2.util.GTTUtils;
import com.sap.gtt.v2.util.JsonUtils;
import org.apache.commons.lang3.RegExUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.HttpStatusCodeException;

import java.time.Instant;
import java.util.*;
import java.util.regex.Pattern;

import static com.sap.gtt.v2.metadataservice.exception.MetadataServiceValidationException.*;
import static com.sap.gtt.v2.metadataservice.utils.Constant.*;
import static com.sap.gtt.v2.util.DBUtils.getPhysicalName;

/**
 * {@code MetadataProjectServiceImpl} implement metadata project service
 *
 * @author I301346
 * @date 2019/4/11
 */
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
@Component
public class MetadataProjectServiceImpl implements MetadataProjectService {
    private static final String DOT = ".";
    private static final String NAME = "/name";
    private static final String TEXTS = "_texts";
    private static final int AOT_MAX_LENGTH = 20;
    public static final String BLANK_JSON_OBJ_STR = "{}";
    private static final String SWAGGER_SERVICE_PRIFIX = "\"/";
    private static final String SLASH = "/";
    private static final String DATE_EXAMPLE_REGEX = "Date\\(";
    private static final Pattern AOT_REG_PATTERN = Pattern.compile("^[a-zA-Z]+[a-zA-Z0-9_]*$");
    private static final String NEWLINE = "\n";


    @Autowired
    private MetadataProjectExtractor extractor;

    @Autowired
    private ICurrentAccessContext currentAccessContext;

    @Autowired
    private GTTRestTemplate restTemplate;

    @Autowired
    private DerivedCsnValidation derivedCSNValidation;

    @Autowired
    private SysTableService sysTableService;

    @Autowired
    private CoreModel coreModel;

    @Autowired
    private TenantAwareLogService logService;

    @Autowired
    MessageSource messageSource;

    @Autowired
    DefaultSysTableDao defaultSysTableDao;

    @Value("${TT_CDM_PARSER_URL}")
    private String cdmParserUrl;

    IMetadataManagement getMetadataManagement() {
        return currentAccessContext.createBusinessOperator().getMetadataManagement();
    }

    ITrackedProcessManagement getTrackedProcessManagement() {
        return currentAccessContext.createBusinessOperator().getTrackedProcessManagement();
    }

    private String getCdmParserUrlForCompile() {
        return cdmParserUrl + "/" + "compile";
    }

    @Override
    public MetadataProject extractMetadataProjectFromZip(byte[] metadataByte) {
        return extractor.extractFromZip(metadataByte);
    }

    @Override
    public String combineCDSWithCore(MetadataProject metadataProject, CoreModel retryCoreModel, boolean isRetry) {
        logService.info("Combine CDS with core model.");
        String coreModelVersion;
        JsonObject coreCdsJson;
        if (isRetry) {
            coreModelVersion = retryCoreModel.getCoreModelVersion();
            coreCdsJson = retryCoreModel.getCds();
        } else {
            coreModelVersion = coreModel.getCoreModelVersion();
            coreCdsJson = coreModel.getCds();
        }
        //set core model version
        metadataProject.setCoreModelVersion(coreModelVersion);
        String cds = metadataProject.getMetadataProjectFile().getCds();
        JsonObject cdsJson = JsonUtils.generateJsonObjectFromJsonString(cds);
        for (Map.Entry<String, JsonElement> entry : coreCdsJson.entrySet()) {
            cdsJson.add(entry.getKey(), entry.getValue());
        }
        String combineCDS = cdsJson.toString();
        metadataProject.getMetadataProjectFile().setCds(combineCDS);
        return combineCDS;
    }

    @Override
    public void combineI18nWithCore(MetadataProject metadataProject, CoreModel retryCoreModel, boolean isRetry) {
        logService.info("Combine i18n with core model.");
        JsonObject coreModelI18n;
        if (isRetry) {
            coreModelI18n = retryCoreModel.getI18n();
        } else {
            coreModelI18n = coreModel.getI18n();
        }
        MetadataProjectFile metadataProjectFile = metadataProject.getMetadataProjectFile();
        String customI18nStr = metadataProjectFile.getI18n();
        JsonObject ret;
        if (StringUtils.isBlank(customI18nStr) || BLANK_JSON_OBJ_STR.equals(customI18nStr)) {
            ret = coreModelI18n;
        } else {
            ret = new JsonObject();
            JsonObject customI18n = JsonUtils.generateJsonObjectFromJsonString(customI18nStr);
            customI18n.keySet().forEach(k -> {
                JsonElement coreI18nElement = coreModelI18n.get(k);
                StringBuilder sb = new StringBuilder();
                if (coreI18nElement != null && !coreI18nElement.isJsonNull()) {
                    sb.append(coreI18nElement.getAsString());
                    sb.append(NEWLINE);
                }
                sb.append(customI18n.get(k).getAsString());
                ret.addProperty(k, sb.toString());
            });
        }
        metadataProjectFile.setI18n(ret.toString());
    }

    @Override
    public JsonObject compileCDS(String cds) {
        //url in sandbox : https://gtt-cds-compiler-sandbox.cfapps.sap.hana.ondemand.com/compile
        logService.info("Compile CDS files.");
        String url = this.getCdmParserUrlForCompile();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        ResponseEntity<String> response;

        try {
            headers.setContentType(MediaType.APPLICATION_JSON);
            response = restTemplate.exchange(url, HttpMethod.POST, headers, cds, String.class);
        } catch (HttpStatusCodeException e) {
            if (e.getStatusCode().is4xxClientError()) {
                throw new MetadataServiceValidationException(e, MESSAGE_CODE_METADATA_PROJECT_FILE_ERROR_INFO,
                        new Object[]{e.getResponseBodyAsString()});
            } else {
                throw e;
            }
        }
        return JsonUtils.generateJsonObjectFromJsonString(response.getBody());
    }

    @Override
    public void handleCompileResponse(MetadataProject metadataProject, JsonObject response) {
        logService.info("Handle compile response.");
        //set swagger
        String swagger = response.get("swagger").getAsJsonObject().get("services").toString();
        metadataProject.getMetadataProjectFile().setSwagger(swagger);
        //set compiler version
        String compilerVersion = response.get("compiler_version").getAsString();
        metadataProject.setCompilerVersion(compilerVersion);
        //set csn
        String csn = response.get("csn").toString();
        metadataProject.getMetadataProjectFile().setCsn(csn);
        //get derived csn and set derived csn
        ModelConfiguration configuration = new ModelConfiguration();
        configuration.setEnableInstanceBasedAuthorization(metadataProject.isEnableInstanceBasedAuthorization());
        configuration.setEventCorrelationLevel(metadataProject.getEventCorrelationLevel());
        String derivedCSN = CsnParser.deriveCsn(csn, configuration);
        metadataProject.getMetadataProjectFile().setDerivedCsn(derivedCSN);
        //set services
        JsonObject services = response.get("services").getAsJsonObject();
        //always only one service in services
        JsonObject servicesObj;
        String servicesName;
        JsonObject annotationsObj = new JsonObject();
        JsonObject edmxObj = new JsonObject();
        for (Map.Entry<String, JsonElement> entry : services.entrySet()) {
            servicesName = entry.getKey();
            servicesObj = entry.getValue().getAsJsonObject();
            //get annotations and set annotations
            String annotations = servicesObj.get("annotations").getAsString();
            annotationsObj.addProperty(servicesName, annotations);
            String edmx = GTTUtils.convertSpecialString(servicesObj.get("metadata").getAsString());
            edmxObj.addProperty(servicesName, edmx);
            /**
             * TODO will write read swagger information in an async way
             if (StringUtils.isNotBlank(edmx)) {
             //get read swager by calling the util:
             String swaggerOfTheEdmx = null;
             try {
             swaggerOfTheEdmx = TransformUtil.transfromEdmxToSwagger(annotations, edmx);
             } catch (IOException e) {
             throw new SwagerTransformException(e.getMessage(), e, MESSAGE_CODE_ERROR_FILE_TRSFORM_FAILED,
             new Object[]{});
             }
             String convertedSwaggerOfTheEdmx = getConvertedSwaggerOfEdxm(servicesName, swaggerOfTheEdmx);
             JsonObject readSwagerObj = new JsonObject();
             readSwagerObj.addProperty(servicesName, convertedSwaggerOfTheEdmx);
             metadataProject.getMetadataProjectFile().setReadSwagger(readSwagerObj.toString());
             }
             **/
        }

        if (!annotationsObj.isJsonNull()) {
            metadataProject.getMetadataProjectFile().setAnnotation(annotationsObj.toString());
        }

        if (!edmxObj.isJsonNull()) {
            metadataProject.getMetadataProjectFile().setEdmx(edmxObj.toString());
        }
    }

    private String getConvertedSwaggerOfEdxm(String serviceName, String swaggerOfTheEdmx) {
        String convertedSwagger = swaggerOfTheEdmx;
        String converServiceNameTo = SWAGGER_SERVICE_PRIFIX + serviceName + SLASH;
        String dateExample = SWAGGER_SERVICE_PRIFIX + serviceName + SLASH + DATE_EXAMPLE_REGEX;
        String convertDateExampleTo = SWAGGER_SERVICE_PRIFIX + DATE_EXAMPLE_REGEX;
        if (StringUtils.isNotBlank(swaggerOfTheEdmx) && StringUtils.isNotBlank(serviceName)) {
            convertedSwagger = RegExUtils.replaceAll(swaggerOfTheEdmx, SWAGGER_SERVICE_PRIFIX, converServiceNameTo);
            convertedSwagger = RegExUtils.replaceAll(convertedSwagger, dateExample, convertDateExampleTo);
            return convertedSwagger;
        }
        return convertedSwagger;
    }


    @Override
    public void saveMetadataProject(MetadataProject metadataProject, boolean isRetry) {
        //get namespace
        logService.info("Save metadata project.");
        String namespace = metadataProject.getNamespace();

        //find namespace exists or not
        List<MetadataProject> metadataProjects = getMetadataManagement().findMetadataProjectInfoByNamespace(namespace);
        if (metadataProjects.size() > 1) {
            //throw exception, if namespace is not unique
            logService.error("ERROR_NAMESPACE_NOT_UNIQUE");
            throw new InternalErrorException("ERROR_NAMESPACE_NOT_UNIQUE");
        }

        //Model namespace cannot contain any deployed model namespace, and cannot be contained by any deployed model
        // namespace
        namespaceContainCheck(namespace);

        //model deployment check
        derivedCSNValidation.modelDeploymentCheck(metadataProject);

        //get metadata entities
        String derivedCsn = metadataProject.getMetadataProjectFile().getDerivedCsn();
        List<MetadataEntity> metadataEntitiesByTP = CsnParser.getAllTheMetadataEntitiesOf(derivedCsn,
                MetadataConstants.EntityBaseType.TRACKED_PROCESS);

        checkApplicationObjectType(metadataProject, metadataEntitiesByTP);
        if (!isRetry) {
            saveProjectInfo(metadataProjects, metadataProject, metadataEntitiesByTP, derivedCsn, namespace);
        }
    }

    private void saveProjectInfo(List<MetadataProject> metadataProjects, MetadataProject metadataProject, List<MetadataEntity> metadataEntitiesByTP, String derivedCsn, String namespace) {
        //save metadataProject info
        if (metadataProjects.isEmpty()) {
            logService.info("Save new metadata project");
            //namespace does not exist, then do insert
            insertMetadataProject(metadataProject, metadataEntitiesByTP);
            //create tables
            sysTableService.createModelTables(derivedCsn);
            MetadataChangeHistory metadataChangeHistory = new MetadataChangeHistory(UUID.randomUUID().toString(),
                    Instant.now(),
                    null, metadataProject.getNamespace(), null, MetadataConstants.MetadataChangeActions.DEPLOY.name());
            getMetadataManagement().insertMetadataChangeHistory(metadataChangeHistory);
            upsertPdmSchema(namespace);
            logService.info("Deploy success.");
        } else if (metadataProjects.size() == 1) {
            //namespace exists, then do check and update
            logService.info("Update metadata project");
            //namespace exist, then do update
            updateMetadataProject(metadataProject, metadataEntitiesByTP, metadataProjects.get(0));
            //update tables
            sysTableService.updateModelTables(derivedCsn,
                    metadataProjects.get(0).getMetadataProjectFile().getDerivedCsn());
            MetadataChangeHistory metadataChangeHistory = new MetadataChangeHistory(UUID.randomUUID().toString(),
                    Instant.now(),
                    null, metadataProject.getNamespace(), null,
                    MetadataConstants.MetadataChangeActions.REDEPLOY.name());
            getMetadataManagement().insertMetadataChangeHistory(metadataChangeHistory);
            upsertPdmSchema(namespace);
            logService.info("Redeploy success.");
        }
        MetadataProjectFile metadataProjectFile = metadataProject.getMetadataProjectFile();
        String jsonModelString = metadataProjectFile.getJsonModel();
        if (StringUtils.isNotBlank(jsonModelString)) {
            //save code list
            saveCodeList(namespace, jsonModelString, derivedCsn);
        }
    }

    /**
     * Model namespace cannot contain any deployed model namespace,
     * and cannot be contained by any deployed model namespace,
     * e.g. com.sap.gtt.app.tfo is existed, then com.sap.gtt.app.tfo1 is allowed, but com.sap.gtt.app.tfo.test1 is
     * not allowed, com.sap.gtt.app is also not allowed
     *
     * @param currentNamespace current deploying namespace
     * @throws MetadataServiceValidationException
     */
    private void namespaceContainCheck(String currentNamespace) {
        logService.info("Check namespace.");
        String currentNamespaceWithDot = currentNamespace + ".";
        //get all the namespace
        List<String> allNamespacesWithDot = new ArrayList<>();
        getAllMetadataProject().stream().forEach(metadataProject -> {
            String namespaceWithDot = metadataProject.getNamespace() + ".";
            if (!currentNamespaceWithDot.equals(namespaceWithDot)) {
                allNamespacesWithDot.add(namespaceWithDot);
            }
        });

        //find namespace contains existed or not
        Optional<String> namespaceOptional =
                allNamespacesWithDot.stream().filter(namespaceWithDot -> namespaceWithDot.contains(currentNamespaceWithDot) || currentNamespaceWithDot.contains(namespaceWithDot)).findFirst();
        if (namespaceOptional.isPresent()) {
            throw new MetadataServiceValidationException(MESSAGE_CODE_ERROR_NAMESPACE_CONTATIN,
                    new Object[]{currentNamespace});
        }
    }

    private void insertMetadataProject(MetadataProject metadataProject, List<MetadataEntity> metadataEntities) {
        //insert metadata project into DB
        getMetadataManagement().insertMetadataProject(metadataProject);
        Map<String, MetadataProcess> metadataPRocessDescInfos = getMetadataProcessDescInfo(metadataProject);
        Map<String, List<MetadataEvent>> eventsInfoOfProcess = getMetadataEventsInfoOfProcess(metadataProject);
        //insert process metadata into DB
        String metadataProjectId = metadataProject.getId();
        metadataEntities.stream().forEach(metadataEntity -> {
            MetadataProcess metadataProcess = new MetadataProcess();
            String id = UUID.randomUUID().toString();
            String trackedProcessType = metadataEntity.getName();
            String applicationObjectType = metadataEntity.getApplicationObjectType();
            if (applicationObjectType == null) {
                String iDocConfig = metadataProject.getMetadataProjectFile().getIdocConfig();
                applicationObjectType = getApplicationObjectTypeFromIDocConfig(iDocConfig, trackedProcessType);
            }
            metadataProcess.setId(id);
            metadataProcess.setMetadataProjectId(metadataProjectId);
            metadataProcess.setTrackedProcessType(trackedProcessType);
            metadataProcess.setTrackingIdType(metadataEntity.getTrackingIdType());
            metadataProcess.setApplicationObjectType(applicationObjectType);
            List<MetadataEvent> events = eventsInfoOfProcess.get(trackedProcessType);
            if (events != null && !events.isEmpty()) {
                events.forEach(metadataProcess::addMetadataEvent);
            }
            String entityAbbrName = CsnParser.getEntityAbbrName(trackedProcessType);
            MetadataProcess metadataProcessOfProject = metadataPRocessDescInfos.get(entityAbbrName);
            //insert metadataProcess text info into db:
            saveMetadataProcessDesc(metadataProcess, metadataProcessOfProject);
            getMetadataManagement().insertMetadataProcess(metadataProcess);
        });
    }


    private void checkApplicationObjectType(MetadataProject metadataProject, List<MetadataEntity> metadataEntities) {
        List<MetadataProcess> metadataProcesses = this.findAllMetadataProcess();
        for (MetadataEntity metadataEntity : metadataEntities) {
            String applicationObjectType = metadataEntity.getApplicationObjectType();
            String trackedProcessType = metadataEntity.getName();
            if (applicationObjectType == null) {
                String iDocConfig = metadataProject.getMetadataProjectFile().getIdocConfig();
                applicationObjectType = getApplicationObjectTypeFromIDocConfig(iDocConfig, trackedProcessType);
            }
            if (applicationObjectType == null) {
                continue;
            }
            if (applicationObjectType.length() > AOT_MAX_LENGTH) {
                throw new MetadataServiceValidationException(MESSAGE_CODE_TOO_LONG_APPLICATION_OBJECT_TYPE,
                        new Object[]{applicationObjectType, AOT_MAX_LENGTH});
            }

            if (!AOT_REG_PATTERN.matcher(applicationObjectType).matches()) {
                throw new MetadataServiceValidationException(MESSAGE_CODE_INVALID_APPLICATION_OBJECT_TYPE,
                        new Object[]{applicationObjectType});
            }

            for (MetadataProcess metadataProcess : metadataProcesses) {
                if (applicationObjectType.equals(metadataProcess.getApplicationObjectType())
                        && !metadataProcess.getTrackedProcessType().equals(trackedProcessType)) {
                    throw new MetadataServiceValidationException(MESSAGE_CODE_DUPLICATE_APPLICATION_OBJECT_TYPE,
                            new Object[]{applicationObjectType, trackedProcessType});
                }
            }
        }

    }

    private String getApplicationObjectTypeFromIDocConfig(String iDocConfig, String trackedProcessType) {
        if (iDocConfig == null) {
            return null;
        }
        JsonObject config = JsonUtils.generateJsonObjectFromJsonString(iDocConfig);
        if (!config.has(PROCESS_TYPES)) {
            return null;
        }
        ArrayList<String> resultList = new ArrayList<>();
        config.get(PROCESS_TYPES).getAsJsonArray().forEach(jsonElement -> {
            JsonObject element = jsonElement.getAsJsonObject();
            if (element.has(IDOC_MAPPING) && element.has(Constant.NAME) && element.get(Constant.NAME).getAsString().equals(trackedProcessType)
                    && element.has(IDOC_ENABLED) && element.get(IDOC_ENABLED).getAsBoolean()) {
                resultList.add(element.get(IDOC_MAPPING).getAsJsonObject().get(APPLICATION_OBJECT_TYPE).getAsString());
            }
        });
        return resultList.isEmpty() ? null : resultList.get(0);
    }

    private Map<String, MetadataProcess> getMetadataProcessDescInfo(MetadataProject metadataProject) {
        List<MetadataProcess> metadataProcessList = metadataProject.getMetadataProcessList();
        Map<String, MetadataProcess> metaDataProcessDescMap = new HashMap<>();
        if (!metadataProcessList.isEmpty()) {
            for (MetadataProcess metadataProcess : metadataProcessList) {
                String processName = metadataProcess.getTrackedProcessType();
                metaDataProcessDescMap.put(processName, metadataProcess);
            }
        }
        return metaDataProcessDescMap;
    }

    private Map<String, List<MetadataEvent>> getMetadataEventsInfoOfProcess(MetadataProject metadataProject) {
        List<MetadataProcess> metadataProcessList = metadataProject.getMetadataProcessList();
        String namespace = metadataProject.getNamespace();
        Map<String, List<MetadataEvent>> processEventsMap = new HashMap<>();
        if (metadataProcessList.isEmpty()) {
            return processEventsMap;
        }
        for (MetadataProcess metadataProcess : metadataProcessList) {
            String processName = metadataProcess.getTrackedProcessType();
            if (!StringUtils.startsWith(processName, namespace)) {
                processName = namespace + DOT + processName + DOT + processName;
            }
            List<MetadataEvent> events = metadataProcess.getMetadataEvents();
            for (MetadataEvent event : events) {
                String abbrEventType = event.getEventType();
                if (!StringUtils.startsWith(abbrEventType, processName)) {
                    event.setEventType(processName + DOT + abbrEventType);
                }
            }
            processEventsMap.put(processName, events);
        }
        return processEventsMap;
    }


    private void updateMetadataProject(MetadataProject metadataProject, List<MetadataEntity> metadataEntities,
                                       MetadataProject existedMetadataProject) {
        Map<String, MetadataProcess> metadataPRocessDescInfos = getMetadataProcessDescInfo(metadataProject);
        //get all the tracked process type which belongs to current namespace in process metadata
        Map<String, String> preTrackedProcessTypeIdMap = new HashMap<>();
        existedMetadataProject.getMetadataProcessList().stream().forEach(e -> {
            String trackedProcessType = e.getTrackedProcessType();
            preTrackedProcessTypeIdMap.put(trackedProcessType, e.getId());
        });

        //update metadata project into DB
        String preMetadataProjectId = existedMetadataProject.getId();
        metadataProject.setId(preMetadataProjectId);
        metadataProject.getMetadataProjectFile().setId(preMetadataProjectId);
        getMetadataManagement().updateMetadataProject(metadataProject);

        Map<String, List<MetadataEvent>> eventsInfoOfProcess = getMetadataEventsInfoOfProcess(metadataProject);

        //update process metadata
        metadataEntities.stream().forEach(e -> {
            String applicationObjectType = e.getApplicationObjectType();
            MetadataProcess metadataProcess = new MetadataProcess();

            String trackedProcessType = e.getName();
            String preTpId = preTrackedProcessTypeIdMap.get(trackedProcessType);
            String id = preTpId == null ? UUID.randomUUID().toString() : preTpId;
            if (applicationObjectType == null) {
                String iDocConfig = metadataProject.getMetadataProjectFile().getIdocConfig();
                applicationObjectType = getApplicationObjectTypeFromIDocConfig(iDocConfig, trackedProcessType);
            }
            metadataProcess.setId(id);
            metadataProcess.setMetadataProjectId(preMetadataProjectId);
            metadataProcess.setTrackedProcessType(trackedProcessType);
            metadataProcess.setApplicationObjectType(applicationObjectType);
            metadataProcess.setTrackingIdType(e.getTrackingIdType());
            String entityAbbrName = CsnParser.getEntityAbbrName(trackedProcessType);
            MetadataProcess metadataProcessOfProject = metadataPRocessDescInfos.get(entityAbbrName);
            saveMetadataProcessDesc(metadataProcess, metadataProcessOfProject);

            List<MetadataEvent> events = eventsInfoOfProcess.get(trackedProcessType);
            if (events != null && !events.isEmpty()) {
                events.forEach(me -> {
                    me.setMetadataProcessId(id);
                    metadataProcess.addMetadataEvent(me);
                });
            }

            if (preTpId != null) {
                //if existed, do update
                getMetadataManagement().updateMetadataProcess(metadataProcess);
            } else {
                //if not existed, do insert
                getMetadataManagement().insertMetadataProcess(metadataProcess);
            }
        });
    }

    private void saveMetadataProcessDesc(MetadataProcess metadataProcess, MetadataProcess metadataProcessInfo) {
        if (metadataProcessInfo != null) {
            String processDesc = metadataProcessInfo.getDescription();
            metadataProcess.setDescription(processDesc);
            List<MetadataProcessText> metadataProcessTexts = metadataProcessInfo.getMetadataProcessTexts();
            if (!metadataProcessTexts.isEmpty()) {
                setProcessIdForProcessText(metadataProcess.getId(), metadataProcessTexts);
                metadataProcess.addAllMetadataProcesTexts(metadataProcessTexts);
                getMetadataManagement().upsertMetadataProcessText(metadataProcess);
            }
        }
    }

    private void setProcessIdForProcessText(String metadataProcessId, List<MetadataProcessText> metadataProcessTexts) {
        metadataProcessTexts.stream().forEach(metadataProcessText ->
                metadataProcessText.setMetadataProcessId(metadataProcessId));
    }

    /**
     * save code and name into corresponding status table
     * 1) find table
     * 2) delete table
     * 3) insert code list from jsonModel
     *
     * @param namespace       namespace
     * @param jsonModelString jsonModel String in zip
     */
    private void saveCodeList(String namespace, String jsonModelString, String derivedCsn) {
        JsonObject jsonModel = JsonUtils.generateJsonObjectFromJsonString(jsonModelString);
        JsonElement subModels = JsonUtils.getByPath(SUB_MODEL_PATH, jsonModel);
        Map<String, MetadataEntity> metadataEntitiesMap = CsnParser.parseToEntityMap(derivedCsn);
        subModels.getAsJsonArray().forEach(subModel -> processCodeListForEachSubModel(namespace, subModel,
                metadataEntitiesMap));
    }

    private void processCodeListForEachSubModel(String namespace, JsonElement subModel,
                                                Map<String, MetadataEntity> metadataEntitiesMap) {
        String name = JsonUtils.getByPath(NAME, subModel).getAsString();
        JsonElement codeLists = JsonUtils.getByPath("/codeLists", subModel);
        if (JsonUtils.isNull(codeLists) || !codeLists.isJsonArray()) {
            return;
        }
        logService.info(String.format("start to save code list for sub model: %s", name));
        codeLists.getAsJsonArray().forEach(codeListJson -> {
            String codeListName = JsonUtils.getByPath(NAME, codeListJson).getAsString();
            String fullEntityModelName = namespace + DOT + name + DOT + codeListName;
            String fullEntityModelNameForTexts = fullEntityModelName + TEXTS;

            //check code list table is existed or not, if not, do not insert data
            if (metadataEntitiesMap.get(fullEntityModelName) == null) {
                return;
            }
            CodeList codeList = new CodeList();
            convertCodeListFromJson(codeListJson, codeList, fullEntityModelName);
            //get physicalName for code list
            PhysicalName physicalName = getPhysicalName(fullEntityModelName, null, true);
            //delete code list table
            sysTableService.emptyCodeListTable(physicalName.getName());
            //insert code list table
            sysTableService.insertCodeListTable(codeList);
            if (metadataEntitiesMap.get(fullEntityModelNameForTexts) != null) {
                //get physicalName for code list texts
                PhysicalName physicalNameForTexts = getPhysicalName(fullEntityModelNameForTexts, null, true);
                //delete code list texts table
                sysTableService.emptyCodeListTable(physicalNameForTexts.getName());
                //insert code list texts table
                sysTableService.insertCodeListTextsTable(codeList);
            }
        });
        logService.info(String.format("save code list for sub model: %s successfully", name));
    }

    private void convertCodeListFromJson(JsonElement codeListJson, CodeList codeList, String fullEntityName) {
        codeList.setFullEntityName(fullEntityName);
        JsonElement values = JsonUtils.getByPath("/values", codeListJson);
        values.getAsJsonArray().forEach(value -> {
            CodeListValue codeListValue = new CodeListValue();
            String code = JsonUtils.getByPath("/code", value).getAsString();
            String name = JsonUtils.getByPath(NAME, value).getAsString();
            JsonElement translation = JsonUtils.getByPath("/translation/name/translation", value);
            if (translation != null && !translation.isJsonNull()) {
                Set<Map.Entry<String, JsonElement>> entries = translation.getAsJsonObject().entrySet();
                for (Map.Entry<String, JsonElement> entry : entries) {
                    CodeListText codeListText = new CodeListText();
                    codeListText.setCode(code);
                    codeListText.setLanguage(entry.getKey());
                    codeListText.setName(entry.getValue().getAsString());
                    codeListValue.addCodeListTexts(codeListText);
                }
            }
            codeListValue.setCode(code);
            codeListValue.setName(name);
            codeList.addCodeListValue(codeListValue);
        });
    }

    @Override
    public String downloadMetadataFileByField(String namespace, MetadataConstants.MetadataProjectFileField fieldName) {
        return getMetadataManagement().getMetadataProjectFileFieldInfo(namespace, fieldName);
    }

    @Override
    public List<MetadataProject> getAllMetadataProject() {
        return getMetadataManagement().findAllMetadataProject();
    }

    @Override
    public void dropModelByNamespace(String namespace) {
        //check namespace existed or not
        List<MetadataProject> metadataProjects = getMetadataManagement().findMetadataProjectInfoByNamespace(namespace);
        if (metadataProjects.isEmpty()) {
            throw new MetadataServiceValidationException(MESSAGE_CODE_ERROR_NAMESPACE_NOT_EXIST,
                    new Object[]{namespace});
        }

        //delete model related data in core tables
        deleteCoremodelEntityDataByNamespace(namespace);
        logService.info("Have deleted all core model entity data for model with namespace {}", namespace);

        //drop model related data in user tables and namespace is unique, so there is only one exited metadata project
        dropUserEntityTablesByCsn(metadataProjects.get(0).getMetadataProjectFile().getDerivedCsn());
        logService.info("Have dropped all user entity tables for model with namespace {}", namespace);

        //delete model related data in metadata tables
        deleteMetadataDataByNamespace(namespace);
        logService.info("Have deleted metadata info for model with namespace {}", namespace);
    }

    @Override
    public void upsertPdmSchema(String namespace) {
        if (currentAccessContext.isStandalonePlan()) {
            getMetadataManagement().upsertPdmSchema(namespace);
        }
    }

    @Override
    public void deletePdmSchema(String namespace) {
        getMetadataManagement().deletePdmSchema(namespace);
    }

    @Override
    public List<MetadataProcess> findAllMetadataProcess() {
        return getMetadataManagement().findAllMetadataProcess(null);
    }

    public void deleteMetadataDataByNamespace(String namespace) {
        getMetadataManagement().deleteMetadata(namespace);
    }

    public void deleteCoremodelEntityDataByNamespace(String namespace) {
        getTrackedProcessManagement().deleteAllTheTrackedProcessByNamespace(namespace);
    }

    public void dropUserEntityTablesByCsn(String csn) {
        sysTableService.dropUserEntityTables(csn);
    }

    @Override
    public void deployModelAndSave(byte[] metadataByte) {
        //parse zipper file, then get cds file, i18n file and so on
        MetadataProject metadataProject = extractMetadataProjectFromZip(metadataByte);
        deployModelAndSave(metadataProject, null, false);
    }

    @Override
    public void deployModelAndSave(MetadataProject metadataProject, CoreModel retryCoreModel, boolean isRetry) {
        //generate all CDS files into a new CDS file
        String cds = combineCDSWithCore(metadataProject, retryCoreModel, isRetry);
        //generate the combined i18n file
        combineI18nWithCore(metadataProject, retryCoreModel, isRetry);
        //compile CDS file
        JsonObject response = compileCDS(cds);
        //handle compile response and do validation
        logService.info("in deployModelAndSave, before handleCompileResponse, metadataProject namespace is {}", metadataProject.getNamespace());
        handleCompileResponse(metadataProject, response);
        logService.info("in deployModelAndSave, end handleCompileResponse, metadataProject namespace is {}", metadataProject.getNamespace());
        saveMetadataProject(metadataProject, isRetry);
        logService.info("in deployModelAndSave, after saveMetadataProject, metadataProject namespace is {}", metadataProject.getNamespace());
    }

    @Override
    public void dropModelAndDeletePdmSchema(String namespace) {
        //drop model related through namespace
        dropModelByNamespace(namespace);
        deletePdmSchema(namespace);
    }

    private void insertMetadataChangeHistory(MetadataProject metadataProject, String action) {
        MetadataChangeHistory metadataChangeHistory = new MetadataChangeHistory(UUID.randomUUID().toString(),
                Instant.now(),
                null, metadataProject.getNamespace(), null, action);
        getMetadataManagement().insertMetadataChangeHistory(metadataChangeHistory);
    }

    @Override
    public void updateMetadataProjectStatus(String namespace, MetadataProjectStatus status) {
        MetadataProject metadataProject = new MetadataProject();
        metadataProject.setNamespace(namespace);
        metadataProject.setStatus(status.name());
        metadataProject.setUploadAt(new Date().toInstant());
        getMetadataManagement().updateMetadataProjectStatus(metadataProject);
        if (MetadataProjectStatus.ACTIVE.equals(status)) {
            upsertPdmSchema(namespace);
            insertMetadataChangeHistory(metadataProject, MetadataConstants.MetadataChangeActions.ACTIVATE.name());
        } else if (MetadataProjectStatus.INACTIVE.equals(status)) {
            deletePdmSchema(namespace);
            insertMetadataChangeHistory(metadataProject, MetadataConstants.MetadataChangeActions.DEACTIVATE.name());
        }
    }

    @Override
    public long countTrackedProcessByType(String trackedProcessType) {
        return getMetadataManagement().countTrackedProcessByType(trackedProcessType);
    }

    @Override
    public String getI18nInfo(String namespace, String fileName) {
        return getMetadataManagement().getI18nInfo(namespace, fileName);
    }

    @Override
    public void saveCoreCodeListsTexts(String coreModel) {

        JsonObject coreModelObject = JsonUtils.generateJsonObjectFromJsonString(coreModel);
        JsonArray codeListsArray = coreModelObject.getAsJsonArray(CODE_LISTS);
        Map<String, Map<String, String>> codeListsMap = new HashMap<>(DEFAULT_COLLECTION_SIZE);
        for (JsonElement codeListObj : codeListsArray) {
            Map<String, String> codeValueMap = new HashMap<>();
            String entityName = codeListObj.getAsJsonObject().get(Constant.NAME).getAsString();
            JsonArray codeValueArray = codeListObj.getAsJsonObject().get(VALUES).getAsJsonArray();
            for (JsonElement codeValue : codeValueArray) {
                codeValueMap.put(codeValue.getAsJsonObject().get(CODE).getAsString(), codeValue.getAsJsonObject().get(Constant.NAME).getAsString());
            }
            codeListsMap.put(entityName, codeValueMap);
        }
        for (Map.Entry<String, Map<String, String>> entry : codeListsMap.entrySet()) {
            saveCoreCodeListTexts(LocaleUtils.getLocales(), entry.getKey(), entry.getValue());
        }
    }

    private void saveCoreCodeListTexts(List<Locale> localeList, String entityName, Map<String, String> codeValues) {
        String fullEntityName = MetadataConstants.getCoreModelEntityFullName(entityName);
        String fullEntityTextName = fullEntityName + DOT_TEXTS;
        defaultSysTableDao.emptyTable(fullEntityTextName);
        CodeList codeList = new CodeList();
        codeList.setFullEntityName(fullEntityName);

        for (Map.Entry<String, String> codeValue : codeValues.entrySet()) {
            CodeListValue codeListValue = new CodeListValue();
            for (Locale locale : localeList) {
                if (!locale.getVariant().isEmpty() && SAPPSD.equals(locale.getVariant())) {
                    continue;
                }
                String i18nCode = "CO_" + entityName + UNDERLINE + codeValue.getKey() + "_NAME";
                String message = messageSource.getMessage(i18nCode, null, locale);
                CodeListText codeListText = new CodeListText();
                codeListText.setCode(codeValue.getKey());
                codeListText.setLanguage(LocaleUtils.getLang(locale));
                codeListText.setName(message);
                codeListValue.addCodeListTexts(codeListText);
            }
            codeListValue.setCode(codeValue.getKey());
            codeList.addCodeListValue(codeListValue);
        }
        defaultSysTableDao.insertCodeListTexts(codeList);
    }
}
