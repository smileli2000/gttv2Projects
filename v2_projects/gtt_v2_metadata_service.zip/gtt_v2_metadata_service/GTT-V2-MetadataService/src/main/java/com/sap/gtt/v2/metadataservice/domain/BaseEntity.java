package com.sap.gtt.v2.metadataservice.domain;

import java.util.ArrayList;
import java.util.List;

public class BaseEntity {
    private String name;
    private List<BaseEntity> parents = new ArrayList();
    private List<EntityElement> elements = new ArrayList();
    private List<String> annotations = new ArrayList();

    public String getModelName() {
        return modelName;
    }

    public void setModelName(String modelName) {
        this.modelName = modelName;
    }

    private String modelName;
    private String entityType;

    public String getEntityType() {
        return entityType;
    }

    public List<String> getAnnotations() {
        return new ArrayList<>(annotations);
    }

    public void setAnnotations(List<String> annotations) {
        this.annotations = annotations;
    }

    public List<BaseEntity> getParent() {
        return parents;
    }

    public void setParents(List<BaseEntity> parents) {
        this.parents = parents;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<EntityElement> getElements() {
        return new ArrayList<>(elements);
    }

    public void setElements(List<EntityElement> elements) {
        this.elements = elements;
    }

    @Override
    public String toString() {
        return "BaseEntity{" +
                "name='" + name + '\'' +
                ", parents=" + parents +
                ", elements=" + elements +
                ", annotations=" + annotations +
                ", entityType=" + entityType +
                '}';
    }
}