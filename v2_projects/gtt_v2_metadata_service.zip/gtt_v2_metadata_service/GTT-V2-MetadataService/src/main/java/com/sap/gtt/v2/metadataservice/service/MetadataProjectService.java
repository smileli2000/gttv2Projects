package com.sap.gtt.v2.metadataservice.service;

import com.google.gson.JsonObject;
import com.sap.gtt.v2.core.domain.metadata.MetadataConstants;
import com.sap.gtt.v2.core.domain.metadata.MetadataConstants.MetadataProjectStatus;
import com.sap.gtt.v2.core.entity.metadata.MetadataProcess;
import com.sap.gtt.v2.core.entity.metadata.MetadataProject;

import java.util.List;

/**
 * {@code MetadataProjectService} define metadata project service interface
 *
 * @author I301346
 * @date 2019/4/11
 */
public interface MetadataProjectService {
    /**
     * Extract metadata project information from zipper file
     *
     * @param metadataByte
     * @return metadata project
     */
    MetadataProject extractMetadataProjectFromZip(byte[] metadataByte);

    /**
     * Combine core cds with metadata project cds
     *
     * @param metadataProject
     * @return CDS String
     */
    String combineCDSWithCore(MetadataProject metadataProject, CoreModel retryCoreModel, boolean isRetry);

    /**
     * Combine core i18n with metadata project i18n
     *
     * @param metadataProject
     */
    void combineI18nWithCore(MetadataProject metadataProject, CoreModel retryCoreModel, boolean isRetry);

    /**
     * Send CDS to compiler and get response
     *
     * @param cds
     * @return response JsonObject
     */
    JsonObject compileCDS(String cds);

    /**
     * Handle compile response and save derived csn into metadata project
     *
     * @param metadataProject
     * @param response
     */
    void handleCompileResponse(MetadataProject metadataProject, JsonObject response);

    /**
     * Save metadata info into metadata tables
     *
     * @param metadataProject
     */
    void saveMetadataProject(MetadataProject metadataProject, boolean isRetry);

    /**
     * Download metadata file by field name
     *
     * @param namespace
     * @param fieldName
     * @return
     */
    String downloadMetadataFileByField(String namespace, MetadataConstants.MetadataProjectFileField fieldName);

    /**
     * get all metadata project list
     *
     * @return metadata project lists
     */
    List<MetadataProject> getAllMetadataProject();

    /**
     * drop model related data
     *
     * @param namespace
     */
    void dropModelByNamespace(String namespace);

    /**
     * upsert pdm schema
     *
     * @param namespace
     */
    void upsertPdmSchema(String namespace);

    /**
     * delete pdm schema
     *
     * @param namespace
     */
    void deletePdmSchema(String namespace);

    /**
     * find all process
     *
     * @return list of process entities
     */
    List<MetadataProcess> findAllMetadataProcess();

    /**
     * deploy model and save as metadata project
     */
    void deployModelAndSave(byte[] metadataByte);

    /**
     * deploy model and save as metadata project
     */
    void deployModelAndSave(MetadataProject metadataProject, CoreModel retryCoreModel, boolean isRetry);

    /**
     * drop model and delete pdm schema
     */
    void dropModelAndDeletePdmSchema(String namespace);

    /**
     * update metadata project status
     *
     * @param namespace
     * @param status
     */
    void updateMetadataProjectStatus(String namespace, MetadataProjectStatus status);

    /**
     * count tracked process
     *
     * @param trackedProcessType
     * @return
     */
    long countTrackedProcessByType(String trackedProcessType);

    /**
     * Get the specified I18N information of a namespace
     *
     * @param namespace namespace
     * @param fileName  i18n file name
     * @return specified i18n file content
     */
    String getI18nInfo(String namespace, String fileName);

    /**
     * Save CoreModel CodeLists Texts
     *
     * @param coreModel coreModel
     */
    void saveCoreCodeListsTexts(String coreModel);

}
