package com.sap.gtt.v2.metadataservice.controller;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.json.JsonSanitizer;
import com.sap.gtt.v2.configuration.ISAPCloudPlatformAgent;
import com.sap.gtt.v2.core.dao.metadata.IMetadataDao;
import com.sap.gtt.v2.core.domain.metadata.MetadataConstants;
import com.sap.gtt.v2.core.domain.metadata.MetadataConstants.MetadataDraftModelStatus;
import com.sap.gtt.v2.core.domain.metadata.MetadataConstants.MetadataProjectStatus;
import com.sap.gtt.v2.core.entity.metadata.MetadataDraftModel;
import com.sap.gtt.v2.core.entity.metadata.MetadataProject;
import com.sap.gtt.v2.core.rule.impl.GTTEmbededRuleScriptLauncher;
import com.sap.gtt.v2.exception.InternalErrorException;
import com.sap.gtt.v2.exception.MetadataException;
import com.sap.gtt.v2.exception.MultiExceptionContainer;
import com.sap.gtt.v2.log.TenantAwareLogService;
import com.sap.gtt.v2.metadataservice.domain.*;
import com.sap.gtt.v2.metadataservice.exception.FileException;
import com.sap.gtt.v2.metadataservice.exception.ManageModelsServiceValidationException;
import com.sap.gtt.v2.metadataservice.service.FileStorageService;
import com.sap.gtt.v2.metadataservice.service.MetadataManageModelsService;
import com.sap.gtt.v2.metadataservice.service.MetadataProjectService;
import com.sap.gtt.v2.metadataservice.service.impl.DraftModelValidator;
import com.sap.gtt.v2.metadataservice.utils.*;
import com.sap.gtt.v2.util.JsonUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.validator.constraints.Length;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.*;

import static com.sap.gtt.v2.core.domain.metadata.MetadataConstants.DOT;
import static com.sap.gtt.v2.metadataservice.exception.FileException.MESSAGE_CODE_INVALID_FILE_EXTENSION;
import static com.sap.gtt.v2.metadataservice.exception.ManageModelsServiceValidationException.*;
import static com.sap.gtt.v2.metadataservice.exception.MetadataServiceValidationException.MESSAGE_CODE_INVALID_NAMESPACE_PREFIX;
import static com.sap.gtt.v2.metadataservice.service.impl.DraftModelValidator.ELEMENT_CUSTOM_MODEL;
import static com.sap.gtt.v2.metadataservice.utils.Constant.CODE;
import static com.sap.gtt.v2.metadataservice.utils.Constant.MESSAGE;
import static com.sap.gtt.v2.metadataservice.utils.Constant.*;
import static com.sap.gtt.v2.metadataservice.utils.FileHelper.download;
import static com.sap.gtt.v2.metadataservice.utils.ScriptValidatorUtil.*;

/**
 * @author i311486
 */
@RestController
@RequestMapping(MetadataManageModelsController.ROOT_URL)
public class MetadataManageModelsController {
    public static final String ROOT_URL = "/sap/logistics/gtt/manage-models/v1";
    public static final String VALUE = "value";
    public static final int MAX_NAMESPACE_LENGTH = 255;
    public static final String CORE_MODEL = "coreModel";
    private static final String CUSTOM_MODEL = "customModel";
    private static final String MEDIA_TYPE_ZIP = "application/x-zip-compressed";
    private static final String STATUS = "status";
    private static final String NAME = "name";
    private static final String NAMESPACE = "namespace";
    private static final String PREFIX = "prefix";

    @Autowired
    MetadataManageModelsService metadataManageModelsService;
    @Autowired
    private DraftModelValidator draftModelValidator;
    @Autowired
    private TenantAwareLogService logService;
    @Autowired
    private MetadataProjectService metaDataProjectService;

    @Autowired
    private GTTEmbededRuleScriptLauncher scriptLauncher;
    @Autowired
    private IMetadataDao metadataDao;

    @Autowired
    private FileStorageService fileStorageService;
    @Autowired
    private ISAPCloudPlatformAgent.ICurrentAccessContext currentAccessContext;
    @Autowired
    MessageSource messageSource;

    @GetMapping(value = "/models/{namespace}/deployments/history")
    @Valid
    public ResponseEntity<String> getChangeHistory(@NotBlank @Length(max = 255) @PathVariable(NAMESPACE) String namespace) {
        List<DeploymentHistory> histories = metadataManageModelsService.findMetadataChangeHistoriesByNamespace(namespace);
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        JsonObject result = new JsonObject();
        result.add(VALUE, JsonUtils.generateJsonElementFromBean(histories));
        return new ResponseEntity<>(result.toString(), headers, HttpStatus.OK);
    }

    @GetMapping(value = "/models")
    public ResponseEntity<String> getModels() {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        JsonObject result = new JsonObject();
        List<DraftModelHeaderInfo> models = metadataManageModelsService.getAllMetadataDraftModelHeaderInfo();
        result.add(VALUE, JsonUtils.generateJsonElementFromBean(models));
        return new ResponseEntity<>(result.toString(), headers, HttpStatus.OK);
    }

    @GetMapping(value = "/models/{namespace}/deployments/current/info", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> getModel(@NotBlank @Length(max = MAX_NAMESPACE_LENGTH) @PathVariable(NAMESPACE) String namespace) {
        DraftModelHeaderInfo modelHeaderInfo = metadataManageModelsService.getMetadataDraftModelHeaderInfoByNamespace(namespace);
        return new ResponseEntity<>(JsonUtils.generateJsonStringFromBean(modelHeaderInfo), HttpStatus.OK);
    }

    @GetMapping(value = "/system/namespace", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> getGTTInstanceNamespaceInfo() {
        String nameSpacePrefix = currentAccessContext.getInstance().getNamespace();
        JsonObject result = new JsonObject();
        result.addProperty(PREFIX, nameSpacePrefix);
        return new ResponseEntity<>(JsonUtils.generateJsonStringFromJsonElement(result), HttpStatus.OK);
    }

    @PostMapping(value = "/models")
    public ResponseEntity<String> createModel(
            HttpServletRequest request,
            @RequestParam(name = "deploy", required = false) Boolean deploy, @RequestBody String body) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        DraftModelBody draftModelBody = new DraftModelBody();
        boolean createFlag = createDraft(body, draftModelBody, false);
        if (!createFlag) {
            throw new ManageModelsServiceValidationException(ValidatorUtil.ERR_NAMESPACE_EXIST, MESSAGE_CODE_ERROR_MODEL_ALREADY_EXISTED_ERROR, new Object[]{});
        }
        if (deploy != null && deploy) {
            return activiate(draftModelBody.getNamespace(), changeFromDraftModelBody(draftModelBody));
        } else {
            JsonObject result = ValidatorUtil.generateResultWithNamespace(draftModelBody.getNamespace());
            return new ResponseEntity<>(result.toString(), headers, HttpStatus.CREATED);
        }
    }

    @PutMapping(value = "/models/{namespace}/deployments/current/status", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> changeStatus(@PathVariable(NAMESPACE) String namespace, @RequestParam(name =
            "status", required = false) String status, @RequestBody String body) {
        MetadataProjectStatus metadataProjectStatus = MetadataProjectStatus.fromValue(status);
        JsonObject postBody = (metadataProjectStatus == null ? JsonUtils.generateJsonObjectFromJsonString(body) : null);
        metadataProjectStatus = ((postBody != null && postBody.has(STATUS)) ? MetadataProjectStatus.fromValue(postBody.get(STATUS).getAsString()) : metadataProjectStatus);
        if (metadataProjectStatus == null || (!MetadataProjectStatus.ACTIVE.equals(metadataProjectStatus) && !MetadataProjectStatus.INACTIVE.equals(metadataProjectStatus))) {
            throw new ManageModelsServiceValidationException(ValidatorUtil.ERR_STATUS_INCORRECT, MESSAGE_CODE_ERROR_STATUS_INCORRECT_ERROR, new Object[]{});
        }
        List<MetadataProject> metadataProjects = metadataManageModelsService.findMetadataProjectInfoByNamespace(namespace);
        if (metadataProjects == null || metadataProjects.isEmpty()) {
            throw new ManageModelsServiceValidationException(ValidatorUtil.ERR_NOT_DEPLOYED, MESSAGE_CODE_ERROR_MODEL_NOT_DEPLOYED_ERROR, new Object[]{});
        }
        metaDataProjectService.updateMetadataProjectStatus(namespace, metadataProjectStatus);
        DraftModelHeaderInfo modelHeaderInfo = metadataManageModelsService.getMetadataDraftModelHeaderInfoByNamespace(namespace);
        return new ResponseEntity<>(JsonUtils.generateJsonStringFromBean(modelHeaderInfo), HttpStatus.OK);
    }

    @GetMapping(value = "/models/coremodel", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> getCoreModel() {
        String coreModelJson = getCoreModelJson();
        return new ResponseEntity<>(JsonUtils.generateJsonElementFromString(coreModelJson).toString(), HttpStatus.OK);
    }

    private String getCoreModelJson() {
        ClassPathResource resource = new ClassPathResource(DraftModelValidator.JSON_CORE_CORE_MODEL);
        try (InputStream inputStream = resource.getInputStream()) {
            String coreWithFieldLabelTrans = CoreFieldLabelTranslationUtil.generateCoreFieldLabelTranslation(IOUtils.toString(inputStream, StandardCharsets.UTF_8), messageSource);
            return EventTypeDescriptionUtils.generateCoreEventTypeDescrTranslation(coreWithFieldLabelTrans, messageSource);
        } catch (IOException ex) {
            throw new InternalErrorException(ex.getMessage(), ex);
        }
    }

    @GetMapping(value = "/models/{namespace}/draft")
    public ResponseEntity<String> getDraftModel(@NotBlank @Length(max = MAX_NAMESPACE_LENGTH) @PathVariable(NAMESPACE) String namespace) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        return new ResponseEntity<>(getDraft(namespace, false), headers, HttpStatus.OK);
    }

    private String getDraft(String namespace, boolean onlyCoreModelVersion) {
        String coreModelJson = getCoreModelJson();
        DraftModelBody draftModelBody = metadataManageModelsService.getMetadataDraftModelByNamespace(namespace);
        if (draftModelBody == null) {
            throw new MetadataException(MetadataException.MESSAGE_CODE_NOT_FOUND, new Object[]{namespace});
        }
        JsonObject result = generateDraftModelResult(draftModelBody, coreModelJson, onlyCoreModelVersion);
        return result.toString();
    }

    @GetMapping(value = "/idoc/presets")
    public ResponseEntity<String> getIdocPresets() {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        String poItemIdocMapping = FileHelper.loadResourceFileAsString(POITEM_PATH);
        JsonObject poItemObject = JsonUtils.generateJsonObjectFromJsonString(poItemIdocMapping);
        JsonArray idocMappingArray = new JsonArray();
        idocMappingArray.add(poItemObject);
        JsonObject idocMappingObject = new JsonObject();
        idocMappingObject.add(VALUE, idocMappingArray);
        return new ResponseEntity<>(idocMappingObject.toString(), headers, HttpStatus.OK);
    }

    @PostMapping(value = "/models/import")
    public ResponseEntity<String> modelsImport(@RequestParam("model") MultipartFile file) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        String originFileName = file.getOriginalFilename();
        if (!isValidFileSuffix(originFileName)) {
            throw new FileException(MESSAGE_CODE_INVALID_FILE_EXTENSION, null);
        }
        String fileContent = fileStorageService.loadFileAsString(file);
        DraftModelBody draftModelBody = new DraftModelBody();
        boolean createFlag = createDraft(fileContent, draftModelBody, true);
        String fileName = fileStorageService.storeFile(file);
        if (!createFlag) {
            Map<String, String> respMap = new HashMap<>(Constant.DEFAULT_COLLECTION_SIZE);
            respMap.put(CODE, MODEL_ALREADY_EXISTS);
            respMap.put(NAME, draftModelBody.getName());
            respMap.put(NAMESPACE, draftModelBody.getNamespace());
            respMap.put(STAGING_ID, fileName);
            FormattedResponseMessage formattedResponseMessage = new FormattedResponseMessage(respMap);
            return new ResponseEntity<>(formattedResponseMessage.toJsonString(), headers, HttpStatus.CONFLICT);
        }
        ImportResponseInfo importResponseInfo = new ImportResponseInfo(draftModelBody, "");
        fileStorageService.deleteFile(fileName);
        return new ResponseEntity<>(importResponseInfo.toJsonString(), headers, HttpStatus.CREATED);
    }

    private boolean isValidFileSuffix(String originalFileName) {
        boolean validSuffix = false;
        if (StringUtils.isNotBlank(originalFileName)) {
            String[] strArray = originalFileName.split("\\.");
            int arrLen = strArray.length;
            if (arrLen > 1 && JSON.equals(strArray[arrLen - 1])) {
                validSuffix = true;
            }
        }
        return validSuffix;
    }

    private boolean createDraft(String fileContent, DraftModelBody draftModelBody, boolean refreshNamespace) {
        boolean ret = false;
        String convertedBody = draftModelValidator.validate(fileContent);
        JsonObject convertedBodyObject = JsonUtils.generateJsonObjectFromJsonString(convertedBody);
        DraftModelBody draftModelBodyInner = JsonUtils.generateBeanFromJsonElement(convertedBodyObject, DraftModelBody.class);
        draftModelBodyInner.setTranslation(JsonUtils.getValueAsJsonObject(convertedBodyObject, TRANSLATION));
        draftModelBody.setDescr(draftModelBodyInner.getDescr());
        draftModelBody.setTranslation(draftModelBodyInner.getTranslation());
        draftModelBody.setDraftStatus(draftModelBodyInner.getDraftStatus());
        String nameSpacePrefix = currentAccessContext.getInstance().getNamespace();
        //replace with namespace prefix of current gtt instance
        if (refreshNamespace) {
            draftModelBodyInner.setNamespace(nameSpacePrefix.concat(DOT).concat(draftModelBodyInner.getName()));
        } else if (draftModelBodyInner.getNamespace().startsWith(nameSpacePrefix)) {
            draftModelBodyInner.setNamespace(draftModelBodyInner.getNamespace());
        } else {
            throw new ManageModelsServiceValidationException(String.format(ValidatorUtil.ERR_NAMESPACE_INCORRECT, nameSpacePrefix), MESSAGE_CODE_INVALID_NAMESPACE_PREFIX, new Object[]{nameSpacePrefix});
        }
        draftModelBody.setNamespace(draftModelBodyInner.getNamespace());
        draftModelBody.setName(draftModelBodyInner.getName());
        draftModelBody.setStatus(draftModelBodyInner.getStatus());
        draftModelBody.setVersion(draftModelBodyInner.getVersion());
        draftModelBody.setUpdatedAt(draftModelBodyInner.getUpdatedAt());
        draftModelBody.setCoreModel(draftModelBodyInner.getCoreModel());
        draftModelBody.setCustomModel(draftModelBodyInner.getCustomModel());
        String namespace = draftModelBody.getNamespace();
        List<MetadataProject> metadataProjects = metadataManageModelsService.findMetadataProjectInfoByNamespace(namespace);
        if (metadataManageModelsService.getMetadataDraftModelInfoByNamespace(namespace) == null && (metadataProjects == null || metadataProjects.isEmpty())) {
            metadataManageModelsService.createMetadataDraftModel(draftModelBodyInner);
            ret = true;
        }
        return ret;
    }

    @PutMapping(value = "/models/{namespace}/draft/import")
    public ResponseEntity<String> updateModelDraftByStaging(
            HttpServletRequest request,
            @NotBlank @Length(max = MAX_NAMESPACE_LENGTH) @PathVariable("namespace") String namespace, @RequestBody String body) {

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        JsonObject requestBody = JsonUtils.generateJsonObjectFromJsonString(body);
        boolean overwrite = requestBody.get(OVERWRITE).getAsBoolean();
        String stagingId = "";
        DraftModelBody draftModelBody = null;
        if (overwrite) {
            stagingId = requestBody.get(STAGING_ID).getAsString();
            String fileContent = fileStorageService.loadFileAsString(stagingId);
            String convertedBody = draftModelValidator.validate(fileContent);
            draftModelBody = JsonUtils.generateBeanFromJson(convertedBody, DraftModelBody.class);
            //replace with namespace prefix of current gtt instance
            String nameSpacePrefix = currentAccessContext.getInstance().getNamespace();
            String updatedNamespace = nameSpacePrefix.concat(DOT).concat(draftModelBody.getName());
            draftModelBody.setNamespace(updatedNamespace);
            ResponseEntity<String> resp = updateDraftModel(headers, draftModelBody, updatedNamespace);
            if (resp != null) {
                return resp;
            }
        }
        ImportResponseInfo importResponseInfo = new ImportResponseInfo(draftModelBody, "");
        if (!stagingId.isEmpty()) {
            fileStorageService.deleteFile(stagingId);
        }
        return new ResponseEntity<>(importResponseInfo.toJsonString(), headers, HttpStatus.OK);
    }

    private ResponseEntity<String> updateDraftModel(HttpHeaders headers, DraftModelBody draftModelBody, String namespace) {
        String ns = draftModelBody.getNamespace();
        if (metadataManageModelsService.getMetadataDraftModelInfoByNamespace(namespace) == null) {
            return new ResponseEntity<>(headers, HttpStatus.NOT_FOUND);
        } else if (!namespace.equals(ns) && metadataManageModelsService.getMetadataDraftModelInfoByNamespace(ns) != null) {
            throw new ManageModelsServiceValidationException(ValidatorUtil.ERR_NAMESPACE_EXIST, MESSAGE_CODE_ERROR_MODEL_ALREADY_EXISTED_ERROR, new Object[]{});
        } else {
            metadataManageModelsService.updateMetadataDraftModel(namespace, draftModelBody);
        }
        return null;
    }

    @GetMapping(value = "/models/{namespace}/draft/export")
    public void exportDraftModel(@NotBlank @Length(max = MAX_NAMESPACE_LENGTH) @PathVariable(
            NAMESPACE) String namespace, HttpServletResponse response) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        String draft = getDraft(namespace, true);
        download(response, draft, namespace);
    }

    @GetMapping(value = "/models/{namespace}/deployments/current/export")
    public void exportCurrentModel(@NotBlank @Length(max = MAX_NAMESPACE_LENGTH) @PathVariable(
            NAMESPACE) String namespace, HttpServletResponse response) {
        List<String> namespaces = new ArrayList<>();
        namespaces.add(namespace);
        String deployedModel = metadataDao.getMetadataProjectFileFieldInfo(namespaces,
                MetadataConstants.MetadataProjectFileField.JSON_MODEL);
        JsonObject currentModel = generateCurrentModelResult(deployedModel);
        download(response, currentModel.toString(), namespace);
    }

    private JsonObject generateDraftModelResult(DraftModelBody draftModelBody, String coreModelJson, boolean onlyCoreModelVersion) {
        JsonObject result = JsonUtils.generateJsonElementFromBean(draftModelBody).getAsJsonObject();
        if (onlyCoreModelVersion) {
            JsonObject coreObj = JsonUtils.generateJsonObjectFromJsonString(coreModelJson);
            Set<String> coreKeySet = new HashSet<>();
            coreKeySet.addAll(coreObj.keySet());
            for (String key : coreKeySet) {
                if (!key.equals(VERSION)) {
                    coreObj.remove(key);
                }
            }
            coreModelJson = coreObj.toString();
        }
        result.add(CORE_MODEL, JsonUtils.generateJsonElementFromString(coreModelJson));
        result.remove(CUSTOM_MODEL);
        result.add(CUSTOM_MODEL, JsonUtils.generateJsonElementFromString(draftModelBody.getCustomModel()));
        return result;
    }

    private JsonObject generateCurrentModelResult(String customModel) {
        JsonObject result = new JsonObject();
        if (StringUtils.isNotBlank(customModel)) {
            return JsonUtils.generateJsonObjectFromJsonString(customModel);
        }
        return result;
    }

    @GetMapping(value = "/models/{namespace}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> getDeployedModelDraft(
            HttpServletRequest request,
            @NotBlank @Length(max = MAX_NAMESPACE_LENGTH) @PathVariable(NAMESPACE) String namespace) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        List<MetadataProject> metadataProjects = metadataManageModelsService.findMetadataProjectInfoByNamespace(namespace);
        if (metadataProjects.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
        MetadataProject metadataProject = metadataProjects.get(0);
        String jsondraftModel = metadataProject.getMetadataProjectFile().getJsonModel();
        String coreModelJson = getCoreModelJson();
        JsonObject result = generateDraftModelResult(changeToDraftModelBody(jsondraftModel), coreModelJson, false);
        return new ResponseEntity<>(result.toString(), headers, HttpStatus.OK);
    }
    
    @PutMapping(value = "/models/{namespace}")
    public ResponseEntity<String> updateModelDraft(
            HttpServletRequest request,
            @NotBlank @Length(max = MAX_NAMESPACE_LENGTH) @PathVariable(NAMESPACE) String namespace,
            @RequestParam(name = "deploy", required = false) Boolean deploy, @RequestBody String body) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        String convertedBody = draftModelValidator.validate(body);
        DraftModelBody draftModelBody = JsonUtils.generateBeanFromJson(convertedBody, DraftModelBody.class);
        String nameSpacePrefix = currentAccessContext.getInstance().getNamespace();
        if (!draftModelBody.getNamespace().startsWith(nameSpacePrefix)) {
            throw new ManageModelsServiceValidationException(String.format(ValidatorUtil.ERR_NAMESPACE_INCORRECT, nameSpacePrefix), MESSAGE_CODE_INVALID_NAMESPACE_PREFIX, new Object[]{nameSpacePrefix});
        }
        ResponseEntity<String> resp = updateDraftModel(headers, draftModelBody, namespace);
        if (resp != null) {
            return resp;
        }
        if (deploy != null && deploy) {
            return activiate(namespace, changeFromDraftModelBody(draftModelBody));
        } else {
            return new ResponseEntity<>(headers, HttpStatus.NO_CONTENT);
        }
    }

    @DeleteMapping(value = "/models/{namespace}")
    @Valid
    public ResponseEntity<String> deleteModel(
            HttpServletRequest request,
            @NotBlank @Length(max = MAX_NAMESPACE_LENGTH) @PathVariable(NAMESPACE) String namespace) {
        HttpHeaders headers = new HttpHeaders();
        MetadataDraftModel draftModel = metadataManageModelsService.getMetadataDraftModelInfoByNamespace(namespace);
        if (draftModel == null) {
            return new ResponseEntity<>(headers, HttpStatus.NOT_FOUND);
        }
        metadataManageModelsService.deleteMetadataDraftModel(namespace);
        List<MetadataProject> metadataProjects = metadataManageModelsService.findMetadataProjectInfoByNamespace(namespace);
        if (metadataProjects != null && !metadataProjects.isEmpty()) {
            return drop(namespace);
        } else {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
    }

    @PostMapping(value = "/models/{namespace}/deployments")
    public ResponseEntity<String> deploy(
            HttpServletRequest request,
            @NotBlank @Length(max = MAX_NAMESPACE_LENGTH) @PathVariable(NAMESPACE) String namespace,
            @RequestBody String body) {
        String draftModelBody;
        DraftModelBody draftModel = metadataManageModelsService.getMetadataDraftModelByNamespace(namespace);
        if (draftModel == null) {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            return new ResponseEntity<>(headers, HttpStatus.NOT_FOUND);
        }
        draftModelBody = changeFromDraftModelBody(draftModel);
        return activiate(namespace, draftModelBody);
    }

    @PostMapping(value = "/eventToAction/validate", consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> validateScript(@RequestBody String jsonString) {
        JsonObject postBody = JsonUtils.generateJsonObjectFromJsonString(jsonString);
        if (!postBody.has(CONTENT)) {
            JsonObject res = new JsonObject();
            res.addProperty(RESULT, FAIL);
            res.addProperty(CODE, ERROR_CODE_SCRIPT_CONTENT_NOT_FOUND);
            return new ResponseEntity<>(res.toString(), HttpStatus.BAD_REQUEST);
        }
        String script = postBody.get(CONTENT).getAsString();
        try {
            scriptLauncher.parse(script);
        } catch (MultiExceptionContainer e) {
            JsonObject failObj = new JsonObject();
            failObj.addProperty(RESULT, FAIL);
            failObj.addProperty(MESSAGE, "");
            JsonArray errMsg = generateErrorMessage(e.getMessage());
            failObj.add(DETAILS, errMsg);
            return new ResponseEntity<>(failObj.toString(), HttpStatus.OK);
        } catch (StringIndexOutOfBoundsException e) {
            JsonObject res = new JsonObject();
            res.addProperty(RESULT, FAIL);
            res.addProperty(CODE, ERROR_CODE_ILLEGAL_SCRIPT);
            return new ResponseEntity<>(res.toString(), HttpStatus.BAD_REQUEST);
        }
        JsonObject successObj = new JsonObject();
        successObj.addProperty(RESULT, PASS);
        successObj.addProperty(MESSAGE, "");
        return new ResponseEntity<>(successObj.toString(), HttpStatus.OK);
    }

    private ResponseEntity<String> activiate(String namespace, String draftModelBody) {

        Map<String, String> cdsMap = CdsInfoGenerator.generateCdsModelInfo(draftModelBody);
        logService.info("deploy - cdsMap: {}", new Gson().toJson(cdsMap.keySet()));
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.parseMediaType(MEDIA_TYPE_ZIP));

        try {
            ByteArrayOutputStream zip = ZipFileGenerator.zip(cdsMap);
            metaDataProjectService.deployModelAndSave(zip.toByteArray());
        } catch (IOException ex) {
            throw new InternalErrorException(ex.getMessage(), ex);
        }
        logService.info("deploy - end");
        DraftModelBody draftModel = changeToDraftModelBody(draftModelBody);
        MetadataDraftModel metadataDraftModel = new MetadataDraftModel(null, namespace, draftModel.getVersion(), draftModel.getDescr(), MetadataDraftModelStatus.DEPLOYED.getValue(), null, draftModel.getCustomModel(), Instant.now());
        metadataManageModelsService.updateMetadataDraftModelInfo(metadataDraftModel);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    private ResponseEntity<String> drop(String namespace) {
        logService.info("drop - namespace: {}", namespace);
        metaDataProjectService.dropModelAndDeletePdmSchema(namespace);
        logService.info("drop - end");
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    private DraftModelBody changeToDraftModelBody(String body) {
        JsonElement bodyJson = JsonUtils.generateJsonElementFromString(JsonSanitizer.sanitize(body));
        String customModel = bodyJson.getAsJsonObject().get(ELEMENT_CUSTOM_MODEL).toString();
        bodyJson.getAsJsonObject().remove(ELEMENT_CUSTOM_MODEL);
        bodyJson.getAsJsonObject().addProperty(ELEMENT_CUSTOM_MODEL, customModel);
        return JsonUtils.generateBeanFromJsonElement(bodyJson, DraftModelBody.class);
    }

    private String changeFromDraftModelBody(DraftModelBody body) {
        JsonObject result = JsonUtils.generateJsonElementFromBean(body).getAsJsonObject();
        result.remove(CUSTOM_MODEL);
        result.add(CUSTOM_MODEL, JsonUtils.generateJsonElementFromString(body.getCustomModel()));
        return result.toString();
    }
}
