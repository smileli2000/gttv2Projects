package com.sap.gtt.v2.metadataservice.domain;

import java.util.ArrayList;
import java.util.List;

public class CodeListEntity extends BaseEntity {
    private final static String ENTITY_TYPE = "CODE_LIST_TYPE";
    private String type;
    private List<CodeListValue> values = new ArrayList();

    public List<CodeListValue> getValues() {
        return values;
    }

    public void setValues(List<CodeListValue> values) {
        this.values = values;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getEntityType() {
        return ENTITY_TYPE;
    }

    @Override
    public String toString() {
        return "CodeListEntity2{" +
                "type='" + type + '\'' +
                ", values=" + values +
                '}';
    }
}
