package com.sap.gtt.v2.metadataservice.domain;

import com.sap.gtt.v2.util.JsonUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static com.sap.gtt.v2.metadataservice.utils.Constant.NAMESPACE;

/**
 * @author I324402
 */
public class FormattedResponseMessage {

    private Error error;

    public Error getError() {
        return error;
    }

    public static class Error {
        private String code;
        private String message;
        private List<Detail> details;

        public String getCode() {
            return code;
        }

        public String getMessage() {
            return message;
        }

        public List<Detail> getDetails() {
            return details;
        }

        public static class Detail {
            private String code;
            private String message;
            private String name;
            private String namespace;
            private String stagingId;
        }
    }

    public FormattedResponseMessage(Map<String, String> messagemap) {
        this.error = new Error();
        this.error.code = messagemap.get("code");
        this.error.message = messagemap.get("message");
        List<Error.Detail> detailList = new ArrayList<>();
        Error.Detail detail = new Error.Detail();
        detail.code = messagemap.get("code");
        detail.message = messagemap.get("message");
        detail.name = messagemap.get("name");
        detail.namespace = messagemap.get(NAMESPACE);
        detail.stagingId = messagemap.get("stagingId");
        detailList.add(detail);
        this.error.details = detailList;
    }

    public String toJsonString() {
        return JsonUtils.generateJsonStringFromBean(this);
    }
}
