package com.sap.gtt.v2.metadataservice.exception;

import com.sap.gtt.v2.exception.BaseRuntimeException;
import org.apache.http.HttpStatus;

public class FileException extends BaseRuntimeException {
    private static final long serialVersionUID = 1L;

    public static final String MESSAGE_CODE_CREATE_FILE_FAILED = FileException.class.getName() + ".CreateFileFailed";
    public static final String MESSAGE_CODE_FILE_NOT_FOUND = FileException.class.getName() + ".FileNotFound";
    public static final String MESSAGE_CODE_INVALID_FILE_EXTENSION = FileException.class.getName() + ".InvalidFileExtension";

    public FileException(String messageCode, Object[] localizedMsgParams) {
        super(messageCode, localizedMsgParams);
    }

    public FileException(Throwable cause, String messageCode, Object[] localizedMsgParams) {
        super(cause.getMessage(), cause, messageCode, localizedMsgParams);
    }

    @Override
    public int getHttpStatus() {
        return HttpStatus.SC_BAD_REQUEST;
    }
}
