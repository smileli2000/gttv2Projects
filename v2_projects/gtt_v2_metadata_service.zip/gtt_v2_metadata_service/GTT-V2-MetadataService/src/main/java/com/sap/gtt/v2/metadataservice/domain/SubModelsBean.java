package com.sap.gtt.v2.metadataservice.domain;

import java.util.ArrayList;
import java.util.List;

public class SubModelsBean {
    private String name;
    private List<ProcessTypeEntity> processTypes = new ArrayList();
    private List<EventTypeEntity> eventTypes = new ArrayList();
    private List<String> annotations = new ArrayList();
    private List<BaseEntity> forWriteEntities = new ArrayList();
    List<MatchExtensionField> matchExtensionFields = new ArrayList();

    public List<MatchExtensionField> getMatchExtensionFields() {
        return matchExtensionFields;
    }

    public void addAllMatchExtensionFields(List<MatchExtensionField> matchExtensionFields) {
        this.matchExtensionFields.addAll(matchExtensionFields);
    }

    public void addMatchExtensionFields(MatchExtensionField matchExtensionField) {
        this.matchExtensionFields.add(matchExtensionField);
    }

    public void clearMatchExtensionFields() {
        matchExtensionFields.clear();
    }

    public List<CodeListEntity> getCodeLists() {
        return codeLists;
    }

    public void setCodeLists(List<CodeListEntity> codeLists) {
        this.codeLists = codeLists;
    }

    private List<CodeListEntity> codeLists = new ArrayList();

    public void setAnnotations(List<String> annotations) {
        this.annotations = annotations;
    }

    public void setForWriteEntities(List<BaseEntity> forWriteEntities) {
        this.forWriteEntities = forWriteEntities;
    }

    public List<BaseEntity> getForWriteEntities() {
        return forWriteEntities;
    }

    public List<String> getAnnotations() {
        return annotations;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<ProcessTypeEntity> getProcessTypes() {
        return processTypes;
    }

    public void setProcessTypes(List<ProcessTypeEntity> processTypes) {
        this.processTypes = processTypes;
    }

    public List<EventTypeEntity> getEventTypes() {
        return eventTypes;
    }

    public void setEventTypes(List<EventTypeEntity> eventTypes) {
        this.eventTypes = eventTypes;
    }

    @Override
    public String toString() {
        return "SubModelsBean{" +
                "name='" + name + '\'' +
                ", processTypes=" + processTypes +
                ", eventTypes=" + eventTypes +
                ", annotations=" + annotations +
                ", forWriteEntities=" + forWriteEntities +
                ", codeLists=" + codeLists +
                '}';
    }
}
