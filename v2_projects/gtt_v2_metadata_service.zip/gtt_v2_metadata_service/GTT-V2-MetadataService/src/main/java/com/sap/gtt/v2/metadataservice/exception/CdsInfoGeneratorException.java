package com.sap.gtt.v2.metadataservice.exception;

import com.sap.gtt.v2.exception.BaseRuntimeException;
import com.sap.gtt.v2.metadataservice.utils.CdsInfoGenerator;
import org.apache.http.HttpStatus;

public class CdsInfoGeneratorException extends BaseRuntimeException {
    private static final long serialVersionUID = 1L;
    public static final String MESSAGE_CODE_ERROR_FIND_TEMPLATE_FILE_FAILED = CdsInfoGenerator.class.getName() + ".FindTemplateFileFailed";
    public static final String MESSAGE_CODE_ERROR_JSON_MODEL_CONVERT_FAILED = CdsInfoGenerator.class.getName() + ".JsonModelConvertFailed";


    public CdsInfoGeneratorException(String messageCode, Object[] localizedMsgParams) {
        super(messageCode, localizedMsgParams);
    }

    public CdsInfoGeneratorException(String internalMessage, Throwable cause, String messageCode, Object[] localizedMsgParams) {
        super(internalMessage, cause, messageCode, localizedMsgParams);
    }

    @Override
    public int getHttpStatus() {
        return HttpStatus.SC_BAD_REQUEST;
    }
}
