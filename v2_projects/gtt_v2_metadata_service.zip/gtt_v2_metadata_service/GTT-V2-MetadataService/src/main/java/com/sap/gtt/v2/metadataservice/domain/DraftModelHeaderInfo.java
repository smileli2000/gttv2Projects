package com.sap.gtt.v2.metadataservice.domain;

import com.google.gson.JsonObject;
import com.google.gson.annotations.SerializedName;
import com.sap.gtt.v2.core.domain.metadata.MetadataConstants.MetadataDraftModelStatus;
import com.sap.gtt.v2.core.domain.metadata.MetadataConstants.MetadataProjectStatus;
import com.sap.gtt.v2.core.entity.metadata.MetadataDraftModel;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.Objects;

/**
 * @author i311486
 */
@Valid
public class DraftModelHeaderInfo implements Serializable {

    private static final long serialVersionUID = -1L;

    @SerializedName("name")
    private String name = null;
    @SerializedName("namespace")
    @Size(max = 255, message = "[namespace] is too long.")
    @NotBlank(message = "[namespace] should not be blank.")
    private String namespace;
    @SerializedName("version")
    @Size(max = 10, message = "[version] is too long.")
    private String version = null;
    @SerializedName("descr")
    @Size(max = 255, message = "[description] is too long.")
    private String descr;
    private transient JsonObject translation;
    private int eventCorrelationLevel;
    @SerializedName("draftStatus")
    private MetadataDraftModelStatus draftStatus = MetadataDraftModelStatus.DRAFT;
    @SerializedName("status")
    private MetadataProjectStatus status = null;
    @SerializedName("modifiedAt")
    private String updatedAt;

    public DraftModelHeaderInfo() {
    }

    public DraftModelHeaderInfo(MetadataDraftModel model) {
        this.namespace = model.getNamespace();
        this.version = model.getVersion();
        this.descr = model.getDescription();
        this.draftStatus = MetadataDraftModelStatus.fromValue(model.getDraftStatus());
        this.status = MetadataProjectStatus.fromValue(model.getStatus());
        this.updatedAt = model.getUpdatedAt().toString();
        this.name = namespace == null ? null : namespace.substring(namespace.lastIndexOf('.') + 1);
    }

    public JsonObject getTranslation() {
        return translation;
    }

    public void setTranslation(JsonObject translation) {
        this.translation = translation;
    }

    public DraftModelHeaderInfo(String namespace, String version, String descr) {
        this.namespace = namespace;
        this.version = version;
        this.descr = descr;
        this.name = namespace == null ? null : namespace.substring(namespace.lastIndexOf('.') + 1);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNamespace() {
        return namespace;
    }

    public void setNamespace(String namespace) {
        this.namespace = namespace;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getDescr() {
        return descr;
    }

    public void setDescr(String descr) {
        this.descr = descr;
    }

    public int getEventCorrelationLevel() {
        return eventCorrelationLevel;
    }

    public void setEventCorrelationLevel(int eventCorrelationLevel) {
        this.eventCorrelationLevel = eventCorrelationLevel;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    public MetadataDraftModelStatus getDraftStatus() {
        return draftStatus;
    }

    public MetadataProjectStatus getStatus() {
        return status;
    }

    public void setDraftStatus(MetadataDraftModelStatus draftStatus) {
        this.draftStatus = draftStatus;
    }

    public void setStatus(MetadataProjectStatus status) {
        this.status = status;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        DraftModelHeaderInfo that = (DraftModelHeaderInfo) o;
        return name.equals(that.name) &&
                namespace.equals(that.namespace) &&
                Objects.equals(version, that.version) &&
                Objects.equals(descr, that.descr) &&
                draftStatus.equals(that.draftStatus) &&
                status.equals(that.status) &&
                updatedAt.equals(that.updatedAt) &&
                eventCorrelationLevel == that.eventCorrelationLevel;
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, namespace, version, descr, draftStatus, status, updatedAt, eventCorrelationLevel);
    }


}
