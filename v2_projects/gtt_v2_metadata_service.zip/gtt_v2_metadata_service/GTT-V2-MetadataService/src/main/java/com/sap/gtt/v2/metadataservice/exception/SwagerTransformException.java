package com.sap.gtt.v2.metadataservice.exception;

import com.sap.gtt.v2.exception.BaseRuntimeException;
import com.sap.gtt.v2.metadataservice.utils.CdsInfoGenerator;
import org.apache.http.HttpStatus;

public class SwagerTransformException extends BaseRuntimeException {
    private static final long serialVersionUID = 1L;
    public static final String MESSAGE_CODE_ERROR_FILE_TRSFORM_FAILED = SwagerTransformException.class.getName() + ".FileTransformFailed";

    public SwagerTransformException(String messageCode, Object[] localizedMsgParams) {
        super(messageCode, localizedMsgParams);
    }

    public SwagerTransformException(String internalMessage, Throwable cause, String messageCode, Object[] localizedMsgParams) {
        super(internalMessage, cause, messageCode, localizedMsgParams);
    }

    @Override
    public int getHttpStatus() {
        return HttpStatus.SC_BAD_REQUEST;
    }
}
