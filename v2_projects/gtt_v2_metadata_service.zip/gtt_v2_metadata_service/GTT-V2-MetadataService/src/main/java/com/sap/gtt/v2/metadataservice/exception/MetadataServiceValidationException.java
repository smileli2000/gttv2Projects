package com.sap.gtt.v2.metadataservice.exception;

import com.sap.gtt.v2.exception.BaseRuntimeException;
import org.apache.http.HttpStatus;

/**
 * {@code MetadataServiceValidationException} can be thrown during validating metadata project
 *
 * @author I301346
 * @date 2019/4/11
 */
public class MetadataServiceValidationException extends BaseRuntimeException {
    private static final long serialVersionUID = 1L;

    public static final String MESSAGE_CODE_ERROR_METADATA_FIELD = MetadataServiceValidationException.class.getName() + ".ErrorMetadataField";
    public static final String MESSAGE_CODE_CDS_FILE_CONFLICT = MetadataServiceValidationException.class.getName() + ".CDSFileConflict";
    public static final String MESSAGE_CODE_CDS_FILE_CONFLICT_WITH_CORE = MetadataServiceValidationException.class.getName() + ".CDSFileConflictWithCore";
    public static final String MESSAGE_CODE_METADATA_PROJECT_FILE_ERROR_INFO = MetadataServiceValidationException.class.getName() + ".MetadataProjectFileErrorInfo";
    public static final String MESSAGE_CODE_ERROR_ENTITY_TYPE_FULLNAME_INVALID = MetadataServiceValidationException.class.getName() + ".ErrorEntityTypeFullNameInvalid";
    public static final String MESSAGE_CODE_ERROR_PROCESS_TYPE_NOT_UNIQUE = MetadataServiceValidationException.class.getName() + ".ErrorProcessTypeNOTUniqueInOneContextName";
    public static final String MESSAGE_CODE_ERROR_REDUCE_SCALE_IN_NEW_CDS = MetadataServiceValidationException.class.getName() + ".ErrorReduceScaleInNewCDS";
    public static final String MESSAGE_CODE_ERROR_REDUCE_PS_IN_NEW_CDS = MetadataServiceValidationException.class.getName() + ".ErrorReducePSInNewCDS";
    public static final String MESSAGE_CODE_DUPLICATE_ENTITY_NAME = MetadataServiceValidationException.class.getName() + ".ErrorDuplicateEntityName";
    public static final String MESSAGE_CODE_DUPLICATE_ELEMENT_FIELD_NAME = MetadataServiceValidationException.class.getName() + ".ErrorDuplicateElementFieldName";
    public static final String MESSAGE_CODE_ERROR_USR_DEFINED_TYPE_START_WITH_GTT = MetadataServiceValidationException.class.getName() + ".ErrorUserDefinedTypeStartWithGTT";
    public static final String MESSAGE_CODE_ERROR_USR_DEFINED_PROPERTY_START_WITH_GTT = MetadataServiceValidationException.class.getName() + ".ErrorUserDefinedPropertyStartWithGTT";
    public static final String MESSAGE_CODE_UNDEFINED_EVENT_TYPE = MetadataServiceValidationException.class.getName() + ".ErrorUndefinedEventType";
    public static final String MESSAGE_CODE_ERROR_NAMESPACE_CONTATIN = MetadataServiceValidationException.class.getName() + ".ErrorNamespaceContain";
    public static final String MESSAGE_CODE_ERROR_NAMESPACE_NOT_EXIST = MetadataServiceValidationException.class.getName() + ".ErrorNamespaceNotExist";
    public static final String MESSAGE_CODE_DUPLICATE_EVENT_NAME_IN_EVENT_LIST = MetadataServiceValidationException.class.getName() + ".DuplicateEventNameInEventList";
    public static final String MESSAGE_CODE_ADD_KEY_FIELD = MetadataServiceValidationException.class.getName() + ".AddKeyField";
    public static final String MESSAGE_CODE_CHANGE_KEY_FIELD = MetadataServiceValidationException.class.getName() + ".ChangeKeyField";
    public static final String MESSAGE_CODE_DELETE_KEY_FIELD = MetadataServiceValidationException.class.getName() + ".DeleteKeyField";
    public static final String MESSAGE_CODE_CHANGE_FIELD_TYPE = MetadataServiceValidationException.class.getName() + ".ChangeFieldType";
    public static final String MESSAGE_CODE_REDUCE_FIELD_LENGTH = MetadataServiceValidationException.class.getName() + ".ReduceFieldLength";
    public static final String MESSAGE_CODE_EMPTY_TRACKING_ID_TYPE = MetadataServiceValidationException.class.getName() + ".EmptyTackingIdType";
    public static final String MESSAGE_CODE_TOO_LONG_TRACKING_ID_TYPE = MetadataServiceValidationException.class.getName() + ".TooLongTackingIdType";
    public static final String MESSAGE_CODE_DUPLICATE_TRACKING_ID_TYPE = MetadataServiceValidationException.class.getName() + ".DuplicatedTackingIdType";
    public static final String MESSAGE_CODE_CAN_NOT_CHANGE_TRACKING_ID_TYPE = MetadataServiceValidationException.class.getName() + ".CanNotChangeTackingIdType";
    public static final String MESSAGE_CODE_TOO_LONG_APPLICATION_OBJECT_TYPE = MetadataServiceValidationException.class.getName() + ".TooLongApplicationObjectType";
    public static final String MESSAGE_CODE_DUPLICATE_APPLICATION_OBJECT_TYPE = MetadataServiceValidationException.class.getName() + ".DuplicatedApplicationObjectType";
    public static final String MESSAGE_CODE_INVALID_APPLICATION_OBJECT_TYPE = MetadataServiceValidationException.class.getName() + ".InvalidApplicationObjectType";
    public static final String MESSAGE_CODE_INVALID_MATCH_ENTITY_OR_FIELD = MetadataServiceValidationException.class.getName() + ".InvalidMatchEntityOrField";
    public static final String MESSAGE_CODE_CAN_NOT_CHANGE_MATCH_EXTENSION = MetadataServiceValidationException.class.getName() + ".CanNotChangeMatchExtension";
    public static final String MESSAGE_CODE_MATCH_EXTENSION_FIELD_TYPE_NOT_SAME = MetadataServiceValidationException.class.getName() + ".MatchExtensionFieldTypeNotSame";
    public static final String MESSAGE_CODE_INVALID_NAMESPACE_PREFIX = MetadataServiceValidationException.class.getName() + ".InvalidNamespacePrefix";
    public static final String MESSAGE_CODE_INVALID_MODEL_NAME = MetadataServiceValidationException.class.getName() + ".InvalidModelName";
    public static final String MESSAGE_CODE_INVALID_EVENT_CORRELATION_LEVEL = MetadataServiceValidationException.class.getName() + ".InvalidEventCorrelationLevel";

    public MetadataServiceValidationException(String messageCode, Object[] localizedMsgParams) {
        super(messageCode, localizedMsgParams);
    }

    public MetadataServiceValidationException(Throwable cause, String messageCode, Object[] localizedMsgParams) {
        super(cause.getMessage(), cause, messageCode, localizedMsgParams);
    }

    @Override
    public int getHttpStatus() {
        return HttpStatus.SC_BAD_REQUEST;
    }
}
