package com.sap.gtt.v2.metadataservice.utils;

import com.google.gson.JsonObject;
import org.springframework.context.MessageSource;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import static com.sap.gtt.v2.metadataservice.utils.Constant.*;

/**
 * @author I324402
 */
public class LocaleUtils {

    private LocaleUtils() {
        throw new IllegalStateException("Utility class");
    }

    public static String getLang(Locale locale) {
        String lang = locale.getLanguage();
        if (!locale.getCountry().isEmpty()) {
            lang = lang.concat("_").concat(locale.getCountry());
            if (!locale.getVariant().isEmpty()) {
                lang = lang.concat("_".concat(locale.getVariant()));
            }
        }
        return lang;
    }

    public static List<Locale> getLocales() {

        List<String> localeStringList = new ArrayList<>();
        localeStringList.add(DE);
        localeStringList.add(ES);
        localeStringList.add(FR);
        localeStringList.add(NL);
        localeStringList.add(PL);
        localeStringList.add(PT_BR);
        localeStringList.add(RU);
        localeStringList.add(TR);
        localeStringList.add(ZH_CN);
        List<Locale> localeList = new ArrayList<>();
        for (String localeString : localeStringList) {
            String[] localePrams = localeString.split(UNDERLINE);
            Locale locale = getLocale(localePrams);
            localeList.add(locale);
        }
        return localeList;
    }

    private static Locale getLocale(String[] localePrams) {
        Locale locale = null;
        if (localePrams.length == 1) {
            locale = new Locale(localePrams[0]);
        }
        if (localePrams.length == 2) {
            locale = new Locale(localePrams[0], localePrams[1]);
        }
        if (localePrams.length == 3) {
            locale = new Locale(localePrams[0], localePrams[1], localePrams[2]);
        }
        return locale;
    }

    public static JsonObject handleLocale(StringBuilder code, List<Locale> localeList, MessageSource messageSource) {
        JsonObject localeTextObj = new JsonObject();
        for (Locale locale : localeList) {
            if (!locale.getVariant().isEmpty() && SAPPSD.equals(locale.getVariant())) {
                continue;
            }
            localeTextObj.addProperty(LocaleUtils.getLang(locale), messageSource.getMessage(code.toString(), null, locale));
        }
        return localeTextObj;
    }

}
