package com.sap.gtt.v2.metadataservice.service.impl;

import com.sap.gtt.v2.configuration.ISAPCloudPlatformAgent;
import com.sap.gtt.v2.core.domain.metadata.*;
import com.sap.gtt.v2.core.entity.metadata.MetadataProcess;
import com.sap.gtt.v2.core.entity.metadata.MetadataProject;
import com.sap.gtt.v2.core.management.metadata.CsnParser;
import com.sap.gtt.v2.exception.MultiExceptionContainer;
import com.sap.gtt.v2.log.TenantAwareLogService;
import com.sap.gtt.v2.metadataservice.exception.MetadataServiceValidationException;
import com.sap.gtt.v2.metadataservice.service.SysTableService;
import com.sap.gtt.v2.metadataservice.utils.Constant;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpStatus;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.stream.Collectors;

import static com.sap.gtt.v2.core.management.metadata.CsnParser.parseToEntityMap;
import static com.sap.gtt.v2.metadataservice.exception.MetadataServiceValidationException.*;

/**
 * {@code DerivedCSNValidation} check CSN is valid or not when deploy and update
 * <p>
 * <pre>
 *         1.Process and event entities and their recursively referenced entities cannot be removed when updated
 *         2.Fields in one entity cannot be removed when updated
 *         3.Field type in one entity cannot be modified, with some exception:
 *           1) String(n), n can be increased
 *           2) Decimal(p, s), p-s or s can be increased
 *         4.Process type and event type are with scheme modelNamespace.contextName.entityName
 *           e.g. com.sap.gtt.app.mim.DeliveryModel.GoodsDamageEvent:
 * 	              modelNamespace is com.sap.gtt.app.mim
 * 	              contextName is DeliveryModel
 * 	              entityName is GoodsDamageEvent
 * 	       5.In one contextName, there should be at most one process type
 * 	       6.In one modelNamespace all process names and event names should be different
 * 	       7.All fields in one entity are different without respect to case
 * 	       8.Event types referenced in @CoreModel.PlannedEvents and @CoreModel.AdmissibleUnplannedEvents should be defined in the model
 * 	       9.Event type in @CoreModel.PlannedEvents and @CoreModel.AdmissibleUnplannedEvents cannot be removed
 * 	       10.Predefined event entity's name always begin with "GTT" (e.g. "GTTOverdueEvent"). Disallow user defined event entity to have this name pattern
 *     </pre>
 * </p>
 *
 * @author I301346
 * @date 2019/4/11
 */
@Component
public class DerivedCsnValidation {
    private enum EventCategory {
        /**
         * "PLANNEDEVENTS": @CoreModel.PlannedEvents
         */
        PLANNEDEVENTS("@CoreModel.PlannedEvents"),
        /**
         * "UNPLANNEDEVENTS": @CoreModel.AdmissibleUnplannedEvents
         */
        UNPLANNEDEVENTS("@CoreModel.AdmissibleUnplannedEvents");

        private String value;

        EventCategory(String value) {
            this.value = value;
        }

        public String getValue() {
            return this.value;
        }

    }

    private static final int TRACKING_ID_TYPE_MAX_LENGTH = 40;

    @Autowired
    SysTableService sysTableService;
    @Autowired
    private TenantAwareLogService logService;
    @Autowired
    MetadataProjectServiceImpl metadataProjectService;

    @Autowired
    private ISAPCloudPlatformAgent.ICurrentAccessContext currentAccessContext;

    /**
     * @param metadataEntity
     * @return 0-> no data -1->no table
     */
    private long hasData(MetadataEntity metadataEntity) {
        return sysTableService.countTableRows(metadataEntity);
    }

    private void plannedEventsMatchExtensionCheck(Map<String, MetadataEntity> oldMetadataEntitiesMap,
                                                  Map<String, MetadataEntity> newMetadataEntitiesMap) {
        for (Map.Entry<String, MetadataEntity> entityEntry : oldMetadataEntitiesMap.entrySet()) {
            String entityName = entityEntry.getKey();
            MetadataEntity entity = entityEntry.getValue();
            if (!entity.getPlannedEvents().isEmpty() && newMetadataEntitiesMap.containsKey(entityName)) {
                if (metadataProjectService.countTrackedProcessByType(entityName) == 0) {
                    continue;
                }
                List<MetadataEntityEvent> oldPlannedEventList = entity.getPlannedEvents();
                List<MetadataEntityEvent> newPlannedEventList = newMetadataEntitiesMap.get(entityName).getPlannedEvents();
                for (MetadataEntityEvent oldPlannedEvent : oldPlannedEventList) {
                    Optional<MetadataEntityEvent> newPlannedEvent = newPlannedEventList.stream()
                            .filter(metadataEntityEvent -> metadataEntityEvent.getEventType().equals(oldPlannedEvent.getEventType())).findFirst();
                    if (newPlannedEvent.isPresent() &&
                            !newPlannedEvent.get().getMatchExtensionFields().equals(oldPlannedEvent.getMatchExtensionFields())) {
                        throw new MetadataServiceValidationException(MESSAGE_CODE_CAN_NOT_CHANGE_MATCH_EXTENSION, new Object[]{newPlannedEvent.get().getEventType()});
                    }
                }
            }
        }
    }

    public Map<String, List<MetadataEntity>> updateCSNCheck(String newDerivedCSN, String oldDerivedCSN) {
        logService.info("Update check.");
        Map<String, MetadataEntity> oldMetadataEntitiesMap = parseToEntityMap(oldDerivedCSN);
        Map<String, MetadataEntity> newMetadataEntitiesMap = parseToEntityMap(newDerivedCSN);
        plannedEventsMatchExtensionCheck(oldMetadataEntitiesMap, newMetadataEntitiesMap);
        List<MetadataEntity> dropEntitiesList = new ArrayList<>();
        List<MetadataEntity> newEntitiesList = new ArrayList<>();
        List<MetadataEntity> addFieldsEntitiesList = new ArrayList<>();
        List<MetadataEntity> deleteFieldsEntitiesList = new ArrayList<>();
        List<MetadataEntity> modifyFieldsEntitiesList = new ArrayList<>();
        List<MetadataEntity> dropAndNewEntitiesList = new ArrayList<>();
        Map<String, List<MetadataEntity>> resultMap = new HashMap<>(6);
        resultMap.put(Constant.DROP, dropEntitiesList);
        resultMap.put(Constant.NEW, newEntitiesList);
        resultMap.put(Constant.DROP_AND_NEW, dropAndNewEntitiesList);
        resultMap.put(Constant.ADD, addFieldsEntitiesList);
        resultMap.put(Constant.DELETE, deleteFieldsEntitiesList);
        resultMap.put(Constant.MODIFY, modifyFieldsEntitiesList);
        oldMetadataEntitiesMap.forEach((entityName, metadataEntity) -> {
            if (CsnParser.isForWriteEntity(entityName)) {
                return;
            }
            if (!newMetadataEntitiesMap.containsKey(entityName)) {
                resultMap.get(Constant.DROP).add(metadataEntity);
            }
        });

        newMetadataEntitiesMap.forEach((entityName, metadataEntity) -> {
            if (CsnParser.isForWriteEntity(entityName)) {
                return;
            }
            if (!oldMetadataEntitiesMap.containsKey(entityName)) {
                resultMap.get(Constant.NEW).add(metadataEntity);
            } else if (!metadataEntity.getElements().equals(oldMetadataEntitiesMap.get(entityName).getElements())) {
                handleMetadataEntity(oldMetadataEntitiesMap, resultMap, entityName, metadataEntity);
            }
        });
        return resultMap;
    }

    private void handleMetadataEntity(Map<String, MetadataEntity> oldMetadataEntitiesMap, Map<String, List<MetadataEntity>> resultMap,
                                      String entityName, MetadataEntity metadataEntity) {
        long countRow = hasData(metadataEntity);
        if (countRow > 0) {
            Map<String, List<MetadataEntityElement>> fields =
                    getEntityFieldsDiff(oldMetadataEntitiesMap.get(entityName), metadataEntity);

            MetadataEntity addFieldsEntity = new MetadataEntity();
            BeanUtils.copyProperties(metadataEntity, addFieldsEntity);
            addFieldsEntity.clearElements();
            MetadataEntity deleteFieldsEntity = new MetadataEntity();
            BeanUtils.copyProperties(metadataEntity, deleteFieldsEntity);
            deleteFieldsEntity.clearElements();
            MetadataEntity modifyFieldsEntity = new MetadataEntity();
            BeanUtils.copyProperties(metadataEntity, modifyFieldsEntity);
            modifyFieldsEntity.clearElements();

            if (!fields.get(Constant.ADD).isEmpty()) {
                fields.get(Constant.ADD).forEach(addFieldsEntity::addElement);
                resultMap.get(Constant.ADD).add(addFieldsEntity);
            }
            if (!fields.get(Constant.DELETE).isEmpty()) {
                fields.get(Constant.DELETE).forEach(deleteFieldsEntity::addElement);
                resultMap.get(Constant.DELETE).add(deleteFieldsEntity);
            }
            if (!fields.get(Constant.MODIFY).isEmpty()) {
                fields.get(Constant.MODIFY).forEach(modifyFieldsEntity::addElement);
                resultMap.get(Constant.MODIFY).add(modifyFieldsEntity);
            }
        } else if (countRow == 0) {
            resultMap.get(Constant.DROP_AND_NEW).add(metadataEntity);
        } else if (countRow == -1) {
            resultMap.get(Constant.NEW).add(metadataEntity);
        }
    }

    private Map<String, List<MetadataEntityElement>> getEntityFieldsDiff(MetadataEntity oldEntity, MetadataEntity newEntity) {
        Map<String, List<MetadataEntityElement>> result = new HashMap<>();
        List<MetadataEntityElement> addFields = new ArrayList<>();
        List<MetadataEntityElement> deleteFields = new ArrayList<>();
        List<MetadataEntityElement> modifyFields = new ArrayList<>();
        /**
         *
         * NOT ALLOWED ACTION:
         * 1.Add or delete a key field
         *
         * 2.Update field type
         *
         * 3.Reduce field length
         *
         * 4.Change key fields
         */
        newEntity.getElements().forEach(metadataEntityElement -> {
            String elemName = metadataEntityElement.getName();
            if (!oldEntity.containsProperty(elemName)) {
                //add
                if (metadataEntityElement.isKey()) {
                    throw new MetadataServiceValidationException(MESSAGE_CODE_ADD_KEY_FIELD, new Object[]{elemName, newEntity});
                } else {
                    addFields.add(metadataEntityElement);
                }
            } else {
                MetadataEntityElement oldElem = oldEntity.getElementMap().get(elemName);
                if (!oldElem.equals(metadataEntityElement)) {
                    //modify
                    modifyPrimaryKeyCheck(newEntity, metadataEntityElement, elemName, oldElem);
                    modifyTypeCheck(oldEntity, newEntity, metadataEntityElement, elemName, oldElem);
                    modifyLengthCheck(newEntity, metadataEntityElement, elemName, oldElem);
                    modifyFields.add(metadataEntityElement);
                }
            }

        });
        oldEntity.getElements().forEach(metadataEntityElement -> {
            if (!newEntity.containsProperty(metadataEntityElement.getName())) {
                //delete
                if (metadataEntityElement.isKey()) {
                    throw new MetadataServiceValidationException(MESSAGE_CODE_DELETE_KEY_FIELD,
                            new Object[]{metadataEntityElement.getName(), newEntity});
                }
                deleteFields.add(metadataEntityElement);
            }
        });
        result.put(Constant.ADD, addFields);
        result.put(Constant.MODIFY, modifyFields);
        result.put(Constant.DELETE, deleteFields);
        return result;
    }

    private void modifyLengthCheck(MetadataEntity newEntity, MetadataEntityElement metadataEntityElement, String elemName, MetadataEntityElement oldElem) {
        int oldElemLength = oldElem.getLength();
        int newElemLength = metadataEntityElement.getLength();
        if (oldElemLength > newElemLength) {
            throw new MetadataServiceValidationException(MESSAGE_CODE_REDUCE_FIELD_LENGTH, new Object[]{elemName, oldElemLength, newElemLength, newEntity});
        }
    }

    private void modifyTypeCheck(MetadataEntity oldEntity, MetadataEntity newEntity, MetadataEntityElement metadataEntityElement, String elemName, MetadataEntityElement oldElem) {
        MetadataConstants.CdsDataType oldElemType = oldElem.getType();
        MetadataConstants.CdsDataType newElemType = metadataEntityElement.getType();
        if (!oldElemType.equals(newElemType)) {
            throw new MetadataServiceValidationException(MESSAGE_CODE_CHANGE_FIELD_TYPE, new Object[]{elemName, oldElemType.getValue(), newElemType.getValue(), newEntity});
        }
        if (oldElemType.equals(MetadataConstants.CdsDataType.CDS_DECIMAL)) {
            validateDecimal(oldElem, metadataEntityElement, elemName, oldEntity.getName());
        }
    }

    private void modifyPrimaryKeyCheck(MetadataEntity newEntity, MetadataEntityElement metadataEntityElement, String elemName, MetadataEntityElement oldElem) {
        if (oldElem.isKey() != metadataEntityElement.isKey()) {
            throw new MetadataServiceValidationException(MESSAGE_CODE_CHANGE_KEY_FIELD, new Object[]{oldElem.getName(), elemName, newEntity});
        }
    }

    private void validateDecimal(MetadataEntityElement metadataEntityElement, MetadataEntityElement newElement, String elementName, String entityName) {
        int oldPrecision = metadataEntityElement.getPrecision();
        int oldScale = metadataEntityElement.getScale();
        int oldPS = oldPrecision - oldScale;
        int newPrecision = newElement.getPrecision();
        int newScale = newElement.getScale();
        int newPS = newPrecision - newScale;
        if (oldScale > newScale) {
            throw new MetadataServiceValidationException(MESSAGE_CODE_ERROR_REDUCE_SCALE_IN_NEW_CDS, new Object[]{elementName, oldScale, newScale, entityName});
        }
        if (oldPS > newPS) {
            throw new MetadataServiceValidationException(MESSAGE_CODE_ERROR_REDUCE_PS_IN_NEW_CDS, new Object[]{elementName, oldPrecision, oldScale, newPrecision, newScale, entityName});
        }
    }

    public void modelDeploymentCheck(MetadataProject metadataProject) {
        logService.info("Model deployment check.");
        //get namespace
        String namespace = metadataProject.getNamespace();

        //namespace validation : lower-case & correct namespace prefix
        namespaceCheck(namespace);

        //get derived csn
        String derivedCsn = metadataProject.getMetadataProjectFile().getDerivedCsn();

        List<MetadataEntity> metadataEntities = CsnParser.parseToEntities(derivedCsn);
        Map<String, MetadataEntity> metadataEntitiesMap = CsnParser.parseToEntityMap(derivedCsn);

        //check all fields in one entity are different without respect to case
        uniqueElementFieldCheck(metadataEntities);

        List<MetadataEntity> metadataEntitiesByTP = CsnParser.getAllTheMetadataEntitiesOf(derivedCsn, MetadataConstants.EntityBaseType.TRACKED_PROCESS);

        //check trackingIdType
        trackingIdTypeCheck(metadataEntitiesByTP);

        //check all the entity type is with scheme modelNamespace.contextName.entityName
        allTheEntityTypeSchemeCheck(namespace, metadataEntities);

        //In one contextName, there should be at most one process type
        processTypeUniqueCheck(metadataEntitiesByTP);

        //disallow all the user defined entity to have "GTT" pattern (ignore case)
        disallowAllTheUserDefinedEntityStartWithGTTCheck(metadataEntities);

        //disallow all the user defined property in user defined entity to have "GTT" pattern (ignore case)
        disallowAllTheUserDefinedPropertyStartWithGTTCheck(metadataEntities);

        //check all user defined entity name is unique or not
        entityNameUniqueCheck(metadataEntities);

        //check Event types referenced in @CoreModel.PlannedEvents and @CoreModel.AdmissibleUnplannedEvents should be defined in the model, and only process type has such annotations
        plannedAndUnplannedEventTypeDefinedAndUniqueAndValueCheck(metadataEntitiesByTP, metadataEntitiesMap);
    }

    private void namespaceCheck(String namespace) {
        String instanceNameSpace = getNameSpacePrefix();
        String instanceNameSpaceDot = instanceNameSpace + ".";
        if(!namespace.startsWith(instanceNameSpaceDot)) {
            throw new MetadataServiceValidationException(MESSAGE_CODE_INVALID_NAMESPACE_PREFIX, new Object[]{instanceNameSpace});
        }
        String modelName = namespace.substring(namespace.lastIndexOf('.') + 1);

        if((namespace.split("\\.").length - instanceNameSpace.split("\\.").length !=1) || !modelName.matches("[a-z0-9]+")) {
            throw new MetadataServiceValidationException(MESSAGE_CODE_INVALID_MODEL_NAME, new Object[]{});
        }
    }

    private String getNameSpacePrefix() {
        return currentAccessContext.getInstance().getNamespace();
    }

    private void trackingIdTypeCheck(List<MetadataEntity> metadataEntitiesByTP) {
        List<MetadataProcess> metadataProcesses = metadataProjectService.findAllMetadataProcess();
        Map<String, String> trackingIdTypeMap = new HashMap<>();
        metadataProcesses.forEach(metadataProcess -> trackingIdTypeMap.put(metadataProcess.getTrackedProcessType(), metadataProcess.getTrackingIdType()));

        metadataEntitiesByTP.forEach(metadataEntityTP -> {
            if (metadataEntityTP.getTrackingIdType() == null) {
                throw new MetadataServiceValidationException(MESSAGE_CODE_EMPTY_TRACKING_ID_TYPE, new Object[]{metadataEntityTP.getName()});
            } else if (metadataEntityTP.getTrackingIdType().length() > TRACKING_ID_TYPE_MAX_LENGTH) {
                throw new MetadataServiceValidationException(MESSAGE_CODE_TOO_LONG_TRACKING_ID_TYPE,
                        new Object[]{metadataEntityTP.getTrackingIdType(),
                                TRACKING_ID_TYPE_MAX_LENGTH});
            }
            trackingTdTypeChangeCheck(trackingIdTypeMap, metadataEntityTP);
        });

    }

    private void trackingTdTypeChangeCheck(Map<String, String> trackingIdTypeMap, MetadataEntity metadataEntityTP) {
        if (trackingIdTypeMap.containsKey(metadataEntityTP.getName())) {
            // update
            if (!trackingIdTypeMap.get(metadataEntityTP.getName()).equals(metadataEntityTP.getTrackingIdType())) {
                //Change trackingIdType
                if (hasData(metadataEntityTP) > 0) {
                    throw new MetadataServiceValidationException(MESSAGE_CODE_CAN_NOT_CHANGE_TRACKING_ID_TYPE,
                            new Object[]{metadataEntityTP.getName()});
                } else if (trackingIdTypeMap.containsValue(metadataEntityTP.getTrackingIdType())) {
                    throw new MetadataServiceValidationException(MESSAGE_CODE_DUPLICATE_TRACKING_ID_TYPE,
                            new Object[]{metadataEntityTP.getName(), metadataEntityTP.getTrackingIdType()});
                }
            }
        } else if (trackingIdTypeMap.containsValue(metadataEntityTP.getTrackingIdType())) {
            //new
            throw new MetadataServiceValidationException(MESSAGE_CODE_DUPLICATE_TRACKING_ID_TYPE,
                    new Object[]{metadataEntityTP.getName(), metadataEntityTP.getTrackingIdType()});
        }

    }

    private void uniqueElementFieldCheck(List<MetadataEntity> metadataEntities) {
        MultiExceptionContainer exceptionContainer = new MultiExceptionContainer(HttpStatus.SC_BAD_REQUEST);

        metadataEntities.forEach(metadataEntity -> {
            String entityName = metadataEntity.getName();
            List<String> elementNames = new ArrayList<>();
            List<String> duplicateElementNames = new ArrayList<>();
            metadataEntity.getElements().forEach(element -> {
                String elementName = element.getName();
                String elementNameLowerCase = elementName.toLowerCase(Locale.getDefault());
                if (elementNames.contains(elementNameLowerCase)) {
                    duplicateElementNames.add(elementName);
                } else {
                    elementNames.add(elementNameLowerCase);
                }
            });
            if (!duplicateElementNames.isEmpty()) {
                exceptionContainer.addException(
                        new MetadataServiceValidationException(MESSAGE_CODE_DUPLICATE_ELEMENT_FIELD_NAME,
                                new Object[]{duplicateElementNames, entityName})
                );
            }

        });

        if (!exceptionContainer.getContainedExceptions().isEmpty()) {
            throw exceptionContainer;
        }
    }

    private void allTheEntityTypeSchemeCheck(String namespace, List<MetadataEntity> metadataEntities) {
        List<String> invalidSchemeList = entityTypeSchemeCheck(namespace, metadataEntities);
        if (!invalidSchemeList.isEmpty()) {
            throw new MetadataServiceValidationException(MESSAGE_CODE_ERROR_ENTITY_TYPE_FULLNAME_INVALID, new Object[]{invalidSchemeList});
        }

    }

    private void processTypeUniqueCheck(List<MetadataEntity> metadataEntitiesByTP) {
        List<String> invalidTPUniqueList = uniqueProcessTypeCheck(metadataEntitiesByTP);
        if (!invalidTPUniqueList.isEmpty()) {
            throw new MetadataServiceValidationException(MESSAGE_CODE_ERROR_PROCESS_TYPE_NOT_UNIQUE, new Object[]{invalidTPUniqueList});
        }
    }

    /**
     * Predefined event entity's name always begin with "GTT", but disalled all the user defined entity to have this name pattern (ignore case)
     *
     * @param metadataEntities event type entities
     */
    private void disallowAllTheUserDefinedEntityStartWithGTTCheck(List<MetadataEntity> metadataEntities) {
        List<String> invalidNameList = new ArrayList<>();
        metadataEntities.stream().forEach(metadataEntity -> {
            String metadataEntityName = metadataEntity.getName();
            if (!CsnParser.isCoreModelEntity(metadataEntityName)) {
                String entityName = CsnParser.getEntityAbbrName(metadataEntityName);
                if (StringUtils.startsWithIgnoreCase(entityName, "GTT")) {
                    invalidNameList.add(metadataEntityName);
                }
            }

        });
        if (!invalidNameList.isEmpty()) {
            throw new MetadataServiceValidationException(MESSAGE_CODE_ERROR_USR_DEFINED_TYPE_START_WITH_GTT, new Object[]{invalidNameList});
        }
    }

    /**
     * Disalled all the user defined property to have "GTT" pattern (ignore case)
     * MetadataEntityElement has two fields : fromCoreModel and customizedField
     * e.g. entity VPDelayedEvent : CoreModel.GTTDelayedEvent
     * 1) customizedField : compare VPDelayedEvent’ elements with elements of  “Event” or “TrackedProcess”
     * 2) fromCoreModel : compare VPDelayedEvent' elements with elements of GTTDelayedEvent
     * In order to find user defined property, here use fromCoreModel
     *
     * @param metadataEntities event type entities
     */
    private void disallowAllTheUserDefinedPropertyStartWithGTTCheck(List<MetadataEntity> metadataEntities) {
        List<String> invalidNameList = new ArrayList<>();
        metadataEntities.stream().forEach(metadataEntity -> {
            String metadataEntityName = metadataEntity.getName();
            if (!CsnParser.isCoreModelEntity(metadataEntityName)) {
                List<MetadataEntityElement> elements = metadataEntity.getElements();
                elements.stream().forEach(element -> {
                    if (!element.isFromCoreModel()) {
                        String elementName = element.getName();
                        if (StringUtils.startsWithIgnoreCase(elementName, "GTT")) {
                            invalidNameList.add(elementName);
                        }
                    }
                });
                if (!invalidNameList.isEmpty()) {
                    throw new MetadataServiceValidationException(MESSAGE_CODE_ERROR_USR_DEFINED_PROPERTY_START_WITH_GTT, new Object[]{invalidNameList, metadataEntityName});
                }
            }
        });
    }

    /**
     * Process type and event type are with scheme : modelNamespace.contextName.entityName
     *
     * @param namespace        user model namespace
     * @param metadataEntities process type entities or event type entities
     * @return invalid entity name list
     */
    private List<String> entityTypeSchemeCheck(String namespace, List<MetadataEntity> metadataEntities) {
        List<String> invalidNameList = new ArrayList<>();
        metadataEntities.stream().forEach(metadataEntity -> {
            String entityName = metadataEntity.getName();
            if (!CsnParser.isCoreModelEntity(entityName)) {
                Boolean addFlag = (!entityName.startsWith(namespace + ".") || (entityName.startsWith(namespace + ".") && (entityName.split("\\.").length - namespace.split("\\.").length != 2))) && !entityName.endsWith("_extension");
                if (addFlag) {
                    //entity name not start with namespace or entity name not modelNamespace.contextName.entityName
                    invalidNameList.add(entityName);
                }
            }
        });
        return invalidNameList;
    }

    /**
     * In one contextName, there should be at most one process type
     *
     * @param metadataEntitiesByTP valid scheme TP entity
     * @return {@code true} when one process type in one contextName
     */
    private List<String> uniqueProcessTypeCheck(List<MetadataEntity> metadataEntitiesByTP) {
        List<String> contextNames = new ArrayList<>();
        List<String> inValidEntityNames = new ArrayList<>();
        metadataEntitiesByTP.stream().forEach(metadataEntity -> {
            String metadataEntityName = metadataEntity.getName();
            String contextName = CsnParser.getContextName(metadataEntityName);
            if (contextNames.contains(contextName)) {
                inValidEntityNames.add(metadataEntityName);
            } else {
                contextNames.add(contextName);
            }
        });

        return inValidEntityNames;
    }

    /**
     * In one model, all entities' name should be unique case ignore.
     */
    private void entityNameUniqueCheck(List<MetadataEntity> metadataEntities) {
        Set<String> coreEntityNames = Arrays.stream(MetadataConstants.CoreModelEntity.values()).map(e -> e.getValue().toLowerCase(Locale.getDefault())).collect(Collectors.toSet());
        Set<String> entityNames = new HashSet<>();
        Set<String> duplicateEntityNames = new HashSet<>();
        metadataEntities.forEach(metadataEntity -> {
            String metadataEntityName = metadataEntity.getName();
            String entityName = CsnParser.getEntityAbbrName(metadataEntityName).toLowerCase();
            if (!CsnParser.isCoreModelEntity(metadataEntityName)) {
                if (entityNames.contains(entityName) || coreEntityNames.contains(entityName)) {
                    duplicateEntityNames.add(metadataEntityName);
                } else {
                    entityNames.add(entityName);
                }
            }
        });

        if (!duplicateEntityNames.isEmpty()) {
            throw new MetadataServiceValidationException(MESSAGE_CODE_DUPLICATE_ENTITY_NAME, new Object[]{duplicateEntityNames});
        }
    }

    private void plannedAndUnplannedEventTypeDefinedAndUniqueAndValueCheck(List<MetadataEntity> metadataEntitiesByTP, Map<String, MetadataEntity> metadataEntitiesMap) {
        List<String> undefinedEventTypeList = new ArrayList<>();

        metadataEntitiesByTP.stream().forEach(metadataEntity -> {
            //check unplanned events
            if (!metadataEntity.getUnplannedEvents().isEmpty()) {
                List<MetadataEntityEvent> unplannedEvents = metadataEntity.getUnplannedEvents();
                eventTypeDefinedCheck(unplannedEvents, metadataEntitiesMap, undefinedEventTypeList);
                eventTypeUniqueCheck(unplannedEvents, EventCategory.UNPLANNEDEVENTS.getValue());
            }
            //check planned events
            if (!metadataEntity.getPlannedEvents().isEmpty()) {
                List<MetadataEntityEvent> plannedEvents = metadataEntity.getPlannedEvents();
                eventTypeDefinedCheck(plannedEvents, metadataEntitiesMap, undefinedEventTypeList);
                eventTypeUniqueCheck(plannedEvents, EventCategory.PLANNEDEVENTS.getValue());
                matchExtensionFieldsCheck(plannedEvents, metadataEntitiesMap);
            }

        });

        if (!undefinedEventTypeList.isEmpty()) {
            throw new MetadataServiceValidationException(MESSAGE_CODE_UNDEFINED_EVENT_TYPE, new Object[]{undefinedEventTypeList});
        }
    }

    /**
     * check events in @CoreModel.PlannedEvents and @CoreModel.AdmissibleUnplannedEvents unique or not
     *
     * @param events plannedEvents or UnplannedEvents
     */
    private void eventTypeUniqueCheck(List<MetadataEntityEvent> events, String category) {
        Set<String> entityNames = new HashSet<>();
        Set<String> duplicateEntityNames = new HashSet<>();

        events.forEach(event -> {
            String entityName = event.getEventType();
            if (entityNames.contains(entityName)) {
                duplicateEntityNames.add(entityName);
            } else {
                entityNames.add(entityName);
            }
        });

        if (!duplicateEntityNames.isEmpty()) {
            throw new MetadataServiceValidationException(MESSAGE_CODE_DUPLICATE_EVENT_NAME_IN_EVENT_LIST, new Object[]{duplicateEntityNames, category});
        }
    }

    private void eventTypeDefinedCheck(List<MetadataEntityEvent> eventEntities, Map<String, MetadataEntity> metadataEntitiesMap, List<String> undefinedEventTypeList) {
        eventEntities.forEach(eventEntity -> {
            String entityName = eventEntity.getEventType();
            if (!metadataEntitiesMap.containsKey(entityName)) {
                undefinedEventTypeList.add(entityName);
            }
        });
    }

    private void matchExtensionFieldsCheck(List<MetadataEntityEvent> eventEntities, Map<String, MetadataEntity> metadataEntitiesMap) {
        eventEntities.forEach(plannedEvent -> {
            List<MatchExtensionField> matchExtensionFields = plannedEvent.getMatchExtensionFields();
            if (!matchExtensionFields.isEmpty()) {
                matchExtensionFields.forEach(matchExtensionField -> matchEntityAndFieldCheck(matchExtensionField, metadataEntitiesMap));
            }
        });
    }

    private void matchEntityAndFieldCheck(MatchExtensionField matchExtensionField, Map<String, MetadataEntity> metadataEntitiesMap) {
        String sourceEntity = matchExtensionField.getSourceObject();
        String sourceField = matchExtensionField.getSourceField();
        String targetEntity = matchExtensionField.getTargetObject();
        String targetField = matchExtensionField.getTargetField();
        boolean sourceIsFound = false;
        boolean targetIsFound = false;
        String sourceType = null;
        String targetType = null;

        for (Map.Entry<String, MetadataEntity> entry : metadataEntitiesMap.entrySet()) {
            String name = entry.getKey();
            MetadataEntity entity = entry.getValue();
            if (name.endsWith("." + sourceEntity)) {
                Optional<MetadataEntityElement> entityElement = entity.getElements().stream()
                        .filter(element -> element.getName().equals(sourceField)).findFirst();
                if (entityElement.isPresent()) {
                    sourceIsFound = true;
                    sourceType = entityElement.get().getType().getValue();
                }
            }
            if (name.endsWith("." + targetEntity)) {
                Optional<MetadataEntityElement> entityElement = entity.getElements().stream()
                        .filter(element -> element.getName().equals(targetField)).findFirst();
                if (entityElement.isPresent()) {
                    targetIsFound = true;
                    targetType = entityElement.get().getType().getValue();
                }
            }
        }
        if (!sourceIsFound) {
            throw new MetadataServiceValidationException(MESSAGE_CODE_INVALID_MATCH_ENTITY_OR_FIELD,
                    new Object[]{sourceEntity + "." + sourceField});
        }
        if (!targetIsFound) {
            throw new MetadataServiceValidationException(MESSAGE_CODE_INVALID_MATCH_ENTITY_OR_FIELD,
                    new Object[]{targetEntity + "." + targetField});
        }
        if (!StringUtils.equalsIgnoreCase(targetType, sourceType)) {
            throw new MetadataServiceValidationException(MESSAGE_CODE_MATCH_EXTENSION_FIELD_TYPE_NOT_SAME, new Object[]{sourceType, targetType});
        }
    }
}
