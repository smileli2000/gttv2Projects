package com.sap.gtt.v2.metadataservice.utils;

/**
 * @author i311486
 */
public class Constant {
    private Constant() {
        throw new IllegalStateException();
    }

    public static final String DROP = "DROP";
    public static final String NEW = "NEW";
    public static final String ALTER = "ALTER";
    public static final String DROP_AND_NEW = "DROP_AND_NEW";
    public static final String ADD = "ADD";
    public static final String DELETE = "DELETE";
    public static final String MODIFY = "MODIFY";
    public static final String NAMESPACE = "namespace";
    public static final String CUSTOM_MODEL = "customModel";
    public static final String CORE_MODEL = "coreModel";
    public static final String SUB_MODELS = "subModels";
    public static final String PROCESS_TYPES = "processTypes";
    public static final String EVENT_TYPES = "eventTypes";
    public static final String IDOC_MAPPING = "idocMapping";
    public static final String NAME = "name";
    public static final String DESCR = "descr";
    public static final String APPLICATION_OBJECT_TYPE = "applicationObjectType";
    public static final String FIELD_MAPPING = "fieldMapping";
    public static final String FIELD = "field";
    public static final String COMPOSITION = "composition";
    public static final String ELEMENTS = "elements";
    public static final String TYPE = "type";
    public static final String TARGET = "target";
    public static final String CODE_LIST = "codelist";
    public static final String CODE_LISTS = "codeLists";
    public static final String ITEM_TYPES = "itemTypes";
    public static final String STAGING_ID = "stagingId";
    public static final String VERSION = "version";
    public static final String OVERWRITE = "overwrite";
    public static final String CODE = "code";
    public static final String MESSAGE = "message";
    public static final String MODEL_ALREADY_EXISTS = "MODEL_ALREADY_EXISTS";
    public static final String JAVA_IO_TEMP_DIR = "java.io.tmpdir";
    public static final int DEFAULT_COLLECTION_SIZE = 16;
    public static final String SUB_MODEL_PATH = "/customModel/subModels";
    public static final String TRANSLATION = "translation";
    public static final String IDOC_ENABLED = "enableIDoc";
    public static final String JSON = "json";
    public static final String VALUE = "value";
    public static final String VALUES = "values";
    public static final String SHIPMENT_PATH = "idoc/Shipment.json";
    public static final String DELIVERY_PATH = "idoc/OutboundDelivery.json";
    public static final String POITEM_PATH = "idoc/PurchaseOrderItem.json";
    public static final String PROCESS_STATUS = "ProcessStatus";
    public static final String LIFE_CYCLE_STATUS = "LifeCycleStatus";
    public static final String EVENT_STATUS = "EventStatus";
    public static final String CORRELATION_TYPE = "CorrelationType";
    public static final String REFERENCE_TYPE = "ReferenceType";
    public static final String ACTION = "Action";
    public static final String UPDATED_PLAN_ACTION = "UpdatePlanAction";
    public static final String COM_SAP_GTT_CORE_COREMODEL = "COM_SAP_GTT_CORE_COREMODEL_";
    public static final String UNDERLINETEXT = "_TEXT";
    public static final String DOT_TEXTS = ".texts";
    public static final String UNDERLINE = "_";
    public static final String I18N_UNDERLINE = "i18n_";
    public static final String SAPPSD = "sappsd";
    public static final String DE = "de";
    public static final String ES = "es";
    public static final String FR = "fr";
    public static final String NL = "nl";
    public static final String PL = "pl";
    public static final String PT_BR = "pt_BR";
    public static final String RU = "ru";
    public static final String TR = "tr";
    public static final String ZH_CN = "zh_CN";
    public static final String PLANNED_EVENT_FOR_UPDATE_PALNEVENT = "PlannedEventForUpdatePlanEvent";
    public static final String PLANNED_EVENT = "PlannedEvent";
    public static final String GTT_DELAYED_EVENT = "GTTDelayedEvent";
    public static final String GTT_ONTIME_EVENT = "GTTOnTimeEvent";
    public static final String REF_PLANNED_EVENT_TYPE = "refPlannedEventType";
    public static final String REF_PLANNED_EVENT_MATCH_KEY = "refPlannedEventMatchKey";
    public static final String REF_PLANNED_EVENT_LOCATION_ALT_KEY = "refPlannedEventLocationAltKey";
    public static final String BASE_PLAN_FIELD_LABEL_LIST = "basePlanFieldLabelList";
    public static final String BASE_GTT_DELAYED_EVENT_FIELD_LABEL_LIST = "baseGTTDelayedEventFieldLabelList";
    public static final String BASE_GTT_ONTIME_FIELD_LABEL_LIST = "baseGTTOnTimeFieldLabelList";
    public static final String BASE_PLAN = "BasePlan";
    public static final String BASE_GTT_DELAYED_EVENT = "BaseGTTDelayedEvent";
    public static final String BASE_GTT_ONTIME_EVENT = "BaseGTTOnTimeEvent";
    public static final String LABEL = "label";
    public static final String LABEL_UPPER = "LABEL";
    public static final String TEXT_TYPE = "textType";
    public static final String SUBMODELS = "subModels";
    public static final String I18NDOTPROPS = "i18n.properties";
    public static final String DESCR_UPPER = "DESCR";
    public static final String EQUAL = "=";
    public static final String ET = "ET";
    public static final String DOTPROPS = ".properties";

}
