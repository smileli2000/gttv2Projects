package com.sap.gtt.v2.metadataservice.utils;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.sap.gtt.v2.util.JsonUtils;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author i311486
 */
public class ScriptValidatorUtil {
    public static final String CONTENT = "content";
    public static final String ERROR_CODE_SCRIPT_CONTENT_NOT_FOUND = "SCRIPT_CONTENT_NOT_FOUND";
    public static final String ERROR_CODE_ILLEGAL_SCRIPT = "ILLEGAL_SCRIPT";
    public static final String RESULT = "result";
    public static final String MESSAGE = "message";
    public static final String DETAILS = "details";
    public static final String FAIL = "fail";
    public static final String PASS = "pass";
    public static final String CODE = "code";

    private ScriptValidatorUtil(){
        throw new IllegalStateException();
    }

    public static JsonArray generateErrorMessage(String error) {
        List<String> errList = Arrays.asList(error.split("\n"));
        List<JsonObject> errorList = errList.stream().map(err -> {
            JsonObject obj = new JsonObject();
            obj.addProperty(MESSAGE, err);
            return obj;
        }).collect(Collectors.toList());
        return JsonUtils.generateJsonElementFromString(errorList.toString()).getAsJsonArray();
    }
}
