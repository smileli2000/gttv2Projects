package com.sap.gtt.v2.metadataservice.domain;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class EntityElement {
    private String name;
    private String type;
    private boolean key;
    private int length;
    private boolean notNull;
    private boolean hidden;
    private boolean localized;
    private ElementCardinality cardinality;
    private String target;
    private String entityName;
    private String compositionTargetPropertyName;
    private String targetModelName;
    private String targetEntityName;
    private String context;
    private Set<String> targetOnInfo = new HashSet();
    private String defaultValue;
    private boolean writable;
    private boolean readable;
    private int precision;
    private int scale;
    private List<String> annotations = new ArrayList();

    private List<String> authScopes = new ArrayList<>();

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public boolean isKey() {
        return key;
    }

    public void setKey(boolean key) {
        this.key = key;
    }

    public int getLength() {
        return length;
    }

    public void setLength(int length) {
        this.length = length;
    }

    public boolean isNotNull() {
        return notNull;
    }

    public void setNotNull(boolean notNull) {
        this.notNull = notNull;
    }

    public boolean isHidden() {
        return hidden;
    }

    public void setHidden(boolean hidden) {
        this.hidden = hidden;
    }

    public boolean isLocalized() {
        return localized;
    }

    public void setLocalized(boolean localized) {
        this.localized = localized;
    }

    public ElementCardinality getCardinality() {
        return cardinality;
    }

    public void setCardinality(ElementCardinality cardinality) {
        this.cardinality = cardinality;
    }

    public String getTarget() {
        return target;
    }

    public void setTarget(String target) {
        this.target = target;
    }

    public String getEntityName() {
        return entityName;
    }

    public void setEntityName(String entityName) {
        this.entityName = entityName;
    }

    public String getCompositionTargetPropertyName() {
        return compositionTargetPropertyName;
    }

    public void setCompositionTargetPropertyName(String compositionTargetPropertyName) {
        this.compositionTargetPropertyName = compositionTargetPropertyName;
    }

    public String getTargetModelName() {
        return targetModelName;
    }

    public void setTargetModelName(String targetModelName) {
        this.targetModelName = targetModelName;
    }

    public String getTargetEntityName() {
        return targetEntityName;
    }

    public void setTargetEntityName(String targetEntityName) {
        this.targetEntityName = targetEntityName;
    }

    public String getContext() {
        return context;
    }

    public void setContext(String context) {
        this.context = context;
    }

    public Set<String> getTargetOnInfo() {
        return targetOnInfo;
    }

    public void setTargetOnInfo(Set<String> targetOnInfo) {
        this.targetOnInfo = targetOnInfo;
    }

    public String getDefaultValue() {
        return defaultValue;
    }

    public void setDefaultValue(String defaultValue) {
        this.defaultValue = defaultValue;
    }

    public boolean isWritable() {
        return writable;
    }

    public void setWritable(boolean writable) {
        this.writable = writable;
    }

    public boolean isReadable() {
        return readable;
    }

    public void setReadable(boolean readable) {
        this.readable = readable;
    }

    public int getPrecision() {
        return precision;
    }

    public void setPrecision(int precision) {
        this.precision = precision;
    }

    public int getScale() {
        return scale;
    }

    public void setScale(int scale) {
        this.scale = scale;
    }

    public List<String> getAnnotations() {
        return annotations;
    }

    public void setAnnotations(List<String> annotations) {
        this.annotations = annotations;
    }

    public List<String> getAuthScopes() {
        return new ArrayList<>(authScopes);
    }

    public void addAuthScope(String authScope) {
        this.authScopes.add(authScope);
    }

    public void clearAuthScopes() {
        this.authScopes.clear();
    }

    @Override
    public String toString() {
        return "EntityElement{" +
                "name='" + name + '\'' +
                ", type='" + type + '\'' +
                ", key=" + key +
                ", length=" + length +
                ", notNull=" + notNull +
                ", cardinality=" + cardinality +
                ", target='" + target + '\'' +
                ", entityName='" + entityName + '\'' +
                ", compositionTargetPropertyName='" + compositionTargetPropertyName + '\'' +
                ", writable=" + writable +
                ", annotations=" + annotations +
                ", readable=" + readable +
                ", precision=" + precision +
                ", scale=" + scale +
                ", context=" + context +
                ", defaultValue=" + defaultValue +
                ", targetModelName=" + targetModelName +
                ", targetEntityName=" + targetEntityName +
                ", targetOnInfo=" + targetOnInfo +
                '}';
    }
}