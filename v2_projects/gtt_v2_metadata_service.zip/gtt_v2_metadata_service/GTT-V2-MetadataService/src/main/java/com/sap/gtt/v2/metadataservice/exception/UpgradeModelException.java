package com.sap.gtt.v2.metadataservice.exception;

import com.sap.gtt.v2.exception.BaseRuntimeException;
import com.sap.gtt.v2.metadataservice.service.UpgradeModelServiceManager;
import org.apache.http.HttpStatus;

public class UpgradeModelException extends BaseRuntimeException {
    private static final long serialVersionUID = 1L;
    public static final String MESSAGE_CODE_ERROR_INPUT_PARAM_INVALID = UpgradeModelServiceManager.class.getName() + ".InputParamInvalid";


    public UpgradeModelException(String messageCode, Object[] localizedMsgParams) {
        super(messageCode, localizedMsgParams);
    }

    public UpgradeModelException(String internalMessage, Throwable cause, String messageCode, Object[] localizedMsgParams) {
        super(internalMessage, cause, messageCode, localizedMsgParams);
    }

    @Override
    public int getHttpStatus() {
        return HttpStatus.SC_BAD_REQUEST;
    }
}
