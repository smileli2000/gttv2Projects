package com.sap.gtt.v2.metadataservice.controller;

import com.google.gson.JsonObject;
import com.sap.gtt.v2.core.domain.metadata.MetadataConstants;
import com.sap.gtt.v2.core.entity.metadata.MetadataProject;
import com.sap.gtt.v2.log.TenantAwareLogService;
import com.sap.gtt.v2.metadataservice.exception.MetadataServiceValidationException;
import com.sap.gtt.v2.metadataservice.service.MetadataProjectService;
import com.sap.gtt.v2.util.JsonUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static com.sap.gtt.v2.metadataservice.exception.MetadataServiceValidationException.MESSAGE_CODE_ERROR_METADATA_FIELD;

/**
 * {@Code MetadataProjectController} provides generic model deploy
 * and metadata project files (EDMX|CDS|CSN|ANNOTATION|SWAGGER|DERIVED_CSN) download
 *
 * @author I301346
 * @date 2019/4/11
 */
@RestController
@RequestMapping(MetadataProjectController.ROOT_URL)
public class MetadataProjectController {
    public static final String ROOT_URL = "/sap/logistics/gtt/metadata/v1/model";

    @Autowired
    private TenantAwareLogService logService;

    @Autowired
    private MetadataProjectService metaDataProjectService;

    /**
     * Deploy generic model
     *
     * @param metadataByte cds files
     * @return {@code HttpStatus.OK} or throw runtime exception\410
     */
    @PostMapping(value = "/deploy", consumes = "application/x-zip-compressed")
    public ResponseEntity<String> deploy(@RequestBody byte[] metadataByte) {
        metaDataProjectService.deployModelAndSave(metadataByte);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    /**
     * download the latest metadata project files
     *
     * @param namespace generic model namespace
     * @param field     EDMX|CDS|CSN|ANNOTATION|SWAGGER|DERIVED_CSN|RULES
     * @return metadata project files
     */
    @GetMapping(value = "/{namespace}/{field}")
    public ResponseEntity<String> download(@PathVariable("namespace") String namespace,
                                           @PathVariable("field") String field) {
        MetadataConstants.MetadataProjectFileField fieldName;
        try {
            fieldName = MetadataConstants.MetadataProjectFileField.valueOf(field);
        } catch (IllegalArgumentException e) {
            logService.error("Wrong field: {} in namespace: {}", field, namespace, e);
            throw new MetadataServiceValidationException(MESSAGE_CODE_ERROR_METADATA_FIELD, new Object[]{field});
        }
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.TEXT_PLAIN);
        return new ResponseEntity<>(metaDataProjectService.downloadMetadataFileByField(namespace, fieldName), headers, HttpStatus.OK);
    }

    @GetMapping(path = "/{namespace}/i18n/{properties}", produces = MediaType.TEXT_PLAIN_VALUE + ";charset=UTF-8")
    public @ResponseBody
    String getI18n(@PathVariable("namespace") String namespace, @PathVariable("properties") String properties) {
        return metaDataProjectService.getI18nInfo(namespace, properties);
    }

    @GetMapping(value = "/{namespace}/spec/write")
    public ResponseEntity<String> downloadWriteSwagger(@PathVariable("namespace") String namespace) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        String swagger = metaDataProjectService.downloadMetadataFileByField(namespace, MetadataConstants.MetadataProjectFileField.SWAGGER);
        if (!StringUtils.isEmpty(swagger)) {
            JsonObject swaggerObj = JsonUtils.generateJsonElementFromString(swagger).getAsJsonObject();
            String service = swaggerObj.keySet().iterator().next();
            swagger = swaggerObj.getAsJsonObject(service).toString();
        }
        return new ResponseEntity<>(swagger, headers, HttpStatus.OK);
    }

    @GetMapping(value = "/{namespace}/spec/read")
    public ResponseEntity<String> downloadReadSwagger(@PathVariable("namespace") String namespace) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        String swagger = metaDataProjectService.downloadMetadataFileByField(namespace, MetadataConstants.MetadataProjectFileField.READ_SWAGGER);
        if (!StringUtils.isEmpty(swagger)) {
            JsonObject swaggerObj = JsonUtils.generateJsonElementFromString(swagger).getAsJsonObject();
            String service = swaggerObj.keySet().iterator().next();
            swagger = swaggerObj.get(service).getAsString();
        }
        return new ResponseEntity<>(swagger, headers, HttpStatus.OK);
    }

    /**
     * fetch all the metadata projects
     *
     * @return all the metadata projects in metadata project table
     */
    @GetMapping(value = "/projects")
    public ResponseEntity<String> fetchAllMetadataProject() {
        List<MetadataProject> projects = metaDataProjectService.getAllMetadataProject();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.TEXT_PLAIN);
        return new ResponseEntity<>(JsonUtils.generateJsonStringFromBean(projects), headers, HttpStatus.OK);
    }

    /**
     * 1) delete model related data in core tables
     * 2) drop model related data in user tables
     * 3) delete model related data in metadata tables
     *
     * @param namespace
     * @return {@code HttpStatus.OK} or throw runtime exception\410
     */
    @DeleteMapping(value = "/{namespace}")
    public ResponseEntity<String> dropModel(@PathVariable("namespace") String namespace) {
        metaDataProjectService.dropModelAndDeletePdmSchema(namespace);

        return new ResponseEntity<>(HttpStatus.OK);
    }
}
