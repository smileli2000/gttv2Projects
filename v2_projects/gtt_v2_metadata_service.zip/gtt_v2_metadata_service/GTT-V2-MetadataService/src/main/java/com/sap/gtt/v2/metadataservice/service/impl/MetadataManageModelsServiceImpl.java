package com.sap.gtt.v2.metadataservice.service.impl;

import com.sap.gtt.v2.configuration.ISAPCloudPlatformAgent;
import com.sap.gtt.v2.core.domain.metadata.MetadataConstants.MetadataDraftModelStatus;
import com.sap.gtt.v2.core.entity.metadata.MetadataChangeHistory;
import com.sap.gtt.v2.core.entity.metadata.MetadataDraftModel;
import com.sap.gtt.v2.core.entity.metadata.MetadataProject;
import com.sap.gtt.v2.core.management.metadata.IMetadataManagement;
import com.sap.gtt.v2.metadataservice.domain.DeploymentHistory;
import com.sap.gtt.v2.metadataservice.domain.DraftModelBody;
import com.sap.gtt.v2.metadataservice.domain.DraftModelHeaderInfo;
import com.sap.gtt.v2.metadataservice.service.MetadataManageModelsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * @author i311486
 */
@Component
public class MetadataManageModelsServiceImpl implements MetadataManageModelsService {

    @Autowired
    private ISAPCloudPlatformAgent.ICurrentAccessContext currentAccessContext;

    IMetadataManagement getMetadataManagement() {
        return currentAccessContext.createBusinessOperator().getMetadataManagement();
    }

    @Override
    public List<DeploymentHistory> findMetadataChangeHistoriesByNamespace(String namespace) {
        List<MetadataChangeHistory> histories = getMetadataManagement().findMetadataChangeHistoryByNamespace(namespace);
        List<DeploymentHistory> ret = new ArrayList<>();
        histories.forEach(h -> ret.add(DeploymentHistory.convertFrom(h)));
        return ret;
    }

    @Override
    public List<MetadataProject> findMetadataProjectInfoByNamespace(String namespace) {
        return getMetadataManagement().findMetadataProjectInfoByNamespace(namespace);
    }

    @Override
    public void saveMetadataChangeHistory(MetadataChangeHistory metadataChangeHistory) {
        getMetadataManagement().insertMetadataChangeHistory(metadataChangeHistory);
    }

    @Override
    public List<DraftModelHeaderInfo> getAllMetadataDraftModelHeaderInfo() {
        List<MetadataDraftModel> models = getMetadataManagement().getAllMetadataDraftModelsInfo(false);
        List<DraftModelHeaderInfo> result = new ArrayList<>();
        models.forEach(model -> result.add(new DraftModelHeaderInfo(model)));
        return result;
    }

    @Override
    public DraftModelHeaderInfo getMetadataDraftModelHeaderInfoByNamespace(String namespace) {
        MetadataDraftModel draftModel = getMetadataManagement().getMetadataDraftModelInfoByNamespace(namespace);
        return draftModel == null ? null : new DraftModelHeaderInfo(draftModel);
    }

    @Override
    public List<MetadataDraftModel> getAllMetadataDraftModelsInfo() {
        return getMetadataManagement().getAllMetadataDraftModelsInfo(true);
    }

    @Override
    public void createMetadataDraftModel(DraftModelBody draftModelBody) {
        UUID uuid = UUID.randomUUID();
        MetadataDraftModel metadataDraftModel = new MetadataDraftModel(uuid.toString(), draftModelBody.getNamespace(),
                draftModelBody.getVersion(), draftModelBody.getDescr(), MetadataDraftModelStatus.DRAFT.getValue(), null,
                draftModelBody.getCustomModel(), Instant.now());
        getMetadataManagement().createMetadataDraftModel(metadataDraftModel);
    }

    @Override
    public void updateMetadataDraftModelInfo(MetadataDraftModel metadataDraftModel) {
        getMetadataManagement().updateMetadataDraftModelInfo(metadataDraftModel);
    }

    @Override
    public void updateMetadataDraftModel(String namespace, DraftModelBody draftModelBody) {
        MetadataDraftModel metadataDraftModel = new MetadataDraftModel(null, draftModelBody.getNamespace(),
                draftModelBody.getVersion(), draftModelBody.getDescr(), MetadataDraftModelStatus.DRAFT.getValue(), null,
                draftModelBody.getCustomModel(), Instant.now());
        getMetadataManagement().updateMetadataDraftModel(namespace, metadataDraftModel);
    }

    @Override
    public void deleteMetadataDraftModel(String namespace) {
        getMetadataManagement().deleteMetadataDraftModel(namespace);
    }

    @Override
    public MetadataDraftModel getMetadataDraftModelInfoByNamespace(String namespace) {
        return getMetadataManagement().getMetadataDraftModelInfoByNamespace(namespace);
    }

    @Override
    public DraftModelBody getMetadataDraftModelByNamespace(String namespace) {
        MetadataDraftModel metadataDraftModel = getMetadataManagement().getMetadataDraftModelByNamespace(namespace);
        if (metadataDraftModel == null) {
            return null;
        }
        return new DraftModelBody(metadataDraftModel);
    }
}
