package com.sap.gtt.v2.metadataservice.service.impl;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import com.sap.gtt.v2.core.domain.metadata.MetadataConstants;
import com.sap.gtt.v2.core.entity.metadata.*;
import com.sap.gtt.v2.core.management.metadata.IMetadataManagement;
import com.sap.gtt.v2.core.rule.impl.GTTEmbededRuleScriptLauncher;
import com.sap.gtt.v2.exception.InternalErrorException;
import com.sap.gtt.v2.metadataservice.exception.MetadataServiceValidationException;
import com.sap.gtt.v2.metadataservice.service.CoreModel;
import com.sap.gtt.v2.metadataservice.utils.Constant;
import com.sap.gtt.v2.metadataservice.utils.EventTypeDescriptionUtils;
import com.sap.gtt.v2.metadataservice.utils.IDocConfigGenerator;
import com.sap.gtt.v2.util.JsonUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.*;
import java.util.Map.Entry;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import static com.sap.gtt.v2.metadataservice.exception.MetadataServiceValidationException.*;
import static com.sap.gtt.v2.metadataservice.utils.Constant.SUB_MODEL_PATH;

/**
 * {@code MetadataProjectExtractor} extract zip file, then get cds info and parse package.json
 *
 * @author I301346
 * @date 2019/4/11
 */
@Component
public class MetadataProjectExtractor {
    private static final String EVENT_TO_ACTION_SCRIPT = "eventToAction.script";
    private static final String JSON_MODEL = "jsonModel.json";
    private static final String PACKAGE_JSON = "package.json";
    private static final String CUSTOMMODEL = "customModel";
    public static final String CDS = "CDS";
    public static final String I18N = "I18N";
    public static final String JSON_MODEL1 = "JSON_MODEL";
    public static final String RULES = "RULES";
    public static final String TRANSLATION_DESCR_TRANSLATION = "translation/descr/translation";


    @Autowired
    private GTTEmbededRuleScriptLauncher ruleScriptLauncher;

    @Autowired
    private CoreModel coreModel;

    public MetadataProject extractFromZip(byte[] metadataByte) {
        MetadataProject project = new MetadataProject();
        //create & set metadata project id
        String id = UUID.randomUUID().toString();
        project.setId(id);

        //set status: "ACTIVE"
        project.setStatus(MetadataConstants.MetadataProjectStatus.ACTIVE.name());

        //set mode: "Standard"
        project.setMode(MetadataConstants.MetadataProjectMode.STANDARD.getValue());

        //create & set uploaded at
        project.setUploadAt(new Date().toInstant());

        ZipInputStream zipStream = new ZipInputStream(new ByteArrayInputStream(metadataByte));
        ZipEntry zipEntry;
        JsonObject cds = new JsonObject();
        JsonObject i18n = new JsonObject();
        try {
            MetadataProjectFile projectFile = new MetadataProjectFile();
            //create & set metadata project file id
            while ((zipEntry = zipStream.getNextEntry()) != null) {
                if (zipEntry.isDirectory()) {
                    continue;
                }
                handleZipFileInfo(zipEntry, zipStream, cds, i18n, project, projectFile);
            }
            setProjectFileInfo(project, projectFile, id, i18n.toString(), cds.toString());
            zipStream.close();
        } catch (IOException e) {
            throw new InternalErrorException("Failed to zip", e);
        }
        return project;
    }

    private void setProjectFileInfo(MetadataProject project, MetadataProjectFile projectFile, String id, String i18n, String cds) {
        projectFile.setId(id);
        projectFile.setCds(cds);
        String customJsonModel = getCusomJsonModel(projectFile.getJsonModel());
        projectFile.setI18n(EventTypeDescriptionUtils.addCustomEventTypeDescrI18n(i18n, customJsonModel));
        String iDocConfig = IDocConfigGenerator.genIDocConfiguration(customJsonModel, project.getNamespace());
        projectFile.setIdocConfig(iDocConfig);
        project.setMetadataProjectFile(projectFile);
        extractDescription(project, projectFile.getJsonModel());
    }

    private static String getCusomJsonModel(String jsonModel) {
        if (StringUtils.isNotBlank(jsonModel)) {
            JsonObject tempModelBean = JsonUtils.generateJsonObjectFromJsonString(jsonModel);
            return tempModelBean.get(CUSTOMMODEL).toString();
        } else {
            return jsonModel;
        }
    }

    public void extractMetadataProjectInfoFromDb(MetadataProject metadataProject, IMetadataManagement metadataManagement) {
        String namespace = metadataProject.getNamespace();
        String[] selectedFields = {CDS, I18N, JSON_MODEL1, RULES};
        if (metadataManagement != null) {
            MetadataProjectFile metadataProjectFile = metadataManagement.getMetadataProjectFileInfo(selectedFields, namespace);
            if (metadataProjectFile != null) {
                String cds = metadataProjectFile.getCds();
                String i18n = metadataProjectFile.getI18n();
                String draftModel = metadataProjectFile.getJsonModel();
                String rules = metadataProjectFile.getRules();
                MetadataProjectFile projectFile = new MetadataProjectFile();
                projectFile.setJsonModel(draftModel);
                projectFile.setRules(rules);
                setProjectFileInfo(metadataProject, projectFile, metadataProject.getId(), i18n, cds);
            }
        }
    }

    public CoreModel extractCoreModelFromZip(byte[] metadataByte) {
        CoreModel coreModelFromZip = new CoreModel();
        ZipInputStream zipStream = new ZipInputStream(new ByteArrayInputStream(metadataByte));
        ZipEntry zipEntry;
        try {
            while ((zipEntry = zipStream.getNextEntry()) != null) {
                if (zipEntry.isDirectory()) {
                    continue;
                }
                String fileName = FilenameUtils.getName(zipEntry.getName());
                String fileContent = IOUtils.toString(zipStream, Charset.defaultCharset());
                coreModelFromZip.setFileInfo(fileName, fileContent);
            }
            zipStream.close();
        } catch (IOException e) {
            throw new InternalErrorException("Failed to zip", e);
        }
        return coreModelFromZip;
    }

    private void handleZipFileInfo(ZipEntry zipEntry, ZipInputStream zipStream, JsonObject cds, JsonObject i18n, MetadataProject project, MetadataProjectFile projectFile) throws IOException {
        List<String> fileNames = new ArrayList<>();
        String fileName = FilenameUtils.getName(zipEntry.getName());
        if (checkFileNameConflict(fileName, fileNames)) {
            //Duplicated file name
            throw new MetadataServiceValidationException(MESSAGE_CODE_CDS_FILE_CONFLICT, new Object[]{fileName});
        }

        if (conflictWithCoreTypes(fileName)) {
            //Conflict with core model
            throw new MetadataServiceValidationException(MESSAGE_CODE_CDS_FILE_CONFLICT_WITH_CORE, new Object[]{fileName});
        }

        String content = IOUtils.toString(zipStream, Charset.defaultCharset());

        //i18n file
        if (fileName.startsWith("i18n") && fileName.endsWith(".properties")) {
            i18n.add(fileName, new JsonPrimitive(content));
        }

        //cds file
        if (fileName.endsWith(".cds")) {
            cds.add(fileName, new JsonPrimitive(content));
        }

        //package.json
        if (PACKAGE_JSON.equals(fileName)) {
            extractPackage(project, content);
        }

        //eventToAction.script
        if (EVENT_TO_ACTION_SCRIPT.equals(fileName) && StringUtils.isNotBlank(content)) {
            projectFile.setRules(content);
            ruleScriptLauncher.parse(content);
        }

        //jsonModel.json
        if (JSON_MODEL.equals(fileName) && !StringUtils.isBlank(content)) {
            projectFile.setJsonModel(content);
        }
    }

    private void extractPackage(MetadataProject metadataProject, String content) {
        JsonObject packageJson = JsonUtils.generateJsonObjectFromJsonString(content);
        String namespace = packageJson.get("name").getAsString();
        String version = packageJson.get("version").getAsString();
        String description = packageJson.get("Description").getAsString();
        metadataProject.setNamespace(namespace);
        metadataProject.setVersion(version);
        metadataProject.setDescription(description);
        JsonElement enableAuthorization = packageJson.get(MetadataConstants.ENABLE_INSTANCE_BASED_AUTHORIZATION);
        if (!JsonUtils.isNull(enableAuthorization)) {
            metadataProject.setEnableInstanceBasedAuthorization(enableAuthorization.getAsBoolean());
        }
        JsonElement level = packageJson.get(MetadataConstants.EVENT_CORRELATION_LEVEL);
        if (!JsonUtils.isNull(level)) {
            int levelVal = level.getAsInt();
            if (levelVal < 1 || levelVal > 5) {
                throw new MetadataServiceValidationException(MESSAGE_CODE_INVALID_EVENT_CORRELATION_LEVEL, new Object[]{levelVal});
            }
            metadataProject.setEventCorrelationLevel(levelVal);
        }
    }

    private void extractDescription(MetadataProject metadataProject, String jsonModelStr) {
        if (StringUtils.isBlank(jsonModelStr)) {
            return;
        }
        JsonObject jsonModel = JsonUtils.generateJsonObjectFromJsonString(jsonModelStr);
        extractProjectDesc(jsonModel, metadataProject);
        JsonArray subModels = JsonUtils.getByPath(SUB_MODEL_PATH, jsonModel).getAsJsonArray();
        subModels.forEach(subModel -> {
            JsonObject subModelObject = subModel.getAsJsonObject();
            if (subModelObject.has(Constant.PROCESS_TYPES)) {
                subModelObject.get(Constant.PROCESS_TYPES).getAsJsonArray().forEach(processType -> {
                    MetadataProcess metadataProcess = new MetadataProcess();
                    metadataProcess.setId(UUID.randomUUID().toString());
                    metadataProject.addProcessMetadata(metadataProcess);
                    JsonObject processTypeObject = processType.getAsJsonObject();
                    if (processTypeObject.has(Constant.DESCR)) {
                        String processDesc = processTypeObject.get(Constant.DESCR).getAsString();
                        metadataProcess.setDescription(processDesc);
                    }
                    if (processTypeObject.has(Constant.NAME)) {
                        String processName = processTypeObject.get(Constant.NAME).getAsString();
                        metadataProcess.setTrackedProcessType(processName);
                    }
                    if (processTypeObject.has(Constant.TRANSLATION)) {
                        JsonElement translationJsonElement = JsonUtils.getByPath(TRANSLATION_DESCR_TRANSLATION, processTypeObject);
                        extractTPMultiLanguageDescription(metadataProcess, translationJsonElement);
                    }
                    //handle metadata event
                    extractMetadataEventInformation(metadataProcess, subModelObject);
                });
            }
        });
    }

    private void extractProjectDesc(JsonObject jsonModel, MetadataProject metadataProject) {
        if (jsonModel.has(Constant.TRANSLATION)) {
            JsonElement translationJsonElement = JsonUtils.getByPath(TRANSLATION_DESCR_TRANSLATION, jsonModel);
            List<MetadataProjectText> metadataProjectTexts = metadataProject.getMetadataProjectTexts();
            if (translationJsonElement != null) {
                translationJsonElement.getAsJsonObject().entrySet().forEach(entry -> {
                    String key = entry.getKey();
                    String value = entry.getValue().getAsString();
                    MetadataProjectText metadataProjectText = new MetadataProjectText();
                    metadataProjectText.setLocale(key);
                    metadataProjectText.setMetadataProjectId(metadataProject.getId());
                    metadataProjectText.setDescr(value);
                    metadataProjectTexts.add(metadataProjectText);
                });
            }
        }
    }

    private void extractTPMultiLanguageDescription(MetadataProcess metadataProcess, JsonElement translationJsonElement) {
        List<MetadataProcessText> metadataProcessTexts = metadataProcess.getMetadataProcessTexts();
        if (translationJsonElement != null) {
            translationJsonElement.getAsJsonObject().entrySet().forEach(entry -> {
                String key = entry.getKey();
                String value = entry.getValue().getAsString();
                MetadataProcessText metadataProcessText = new MetadataProcessText();
                metadataProcessText.setLocale(key);
                metadataProcessText.setDescr(value);
                metadataProcessTexts.add(metadataProcessText);
            });
        }
    }

    private void extractMetadataEventInformation(final MetadataProcess metadataProcess, JsonObject subModelObject) {
        if (!subModelObject.has(Constant.EVENT_TYPES)) {
            return;
        }
        subModelObject.get(Constant.EVENT_TYPES).getAsJsonArray().forEach(eventType -> {
            MetadataEvent metadataEvent = new MetadataEvent();
            metadataEvent.setId(UUID.randomUUID().toString());
            metadataProcess.addMetadataEvent(metadataEvent);
            JsonObject eventTypeObject = eventType.getAsJsonObject();
            if (eventTypeObject.has(Constant.DESCR)) {
                String processDesc = eventTypeObject.get(Constant.DESCR).getAsString();
                metadataEvent.setDescription(processDesc);
            }
            if (eventTypeObject.has(Constant.NAME)) {
                String eventName = eventTypeObject.get(Constant.NAME).getAsString();
                metadataEvent.setEventType(eventName);
            }
            if (eventTypeObject.has(Constant.TRANSLATION)) {
                JsonElement translationJsonElement = JsonUtils.getByPath(TRANSLATION_DESCR_TRANSLATION, eventTypeObject);
                extractEventMultiLanguageDescription(metadataEvent, translationJsonElement);
            }
        });
    }

    private void extractEventMultiLanguageDescription(MetadataEvent metadataEvent, JsonElement translationJsonElement) {
        if (JsonUtils.isNull(translationJsonElement)) {
            return;
        }
        translationJsonElement.getAsJsonObject().entrySet().forEach(entry -> {
            String key = entry.getKey();
            String value = entry.getValue().getAsString();
            MetadataEventText metadataEventText = new MetadataEventText();
            metadataEventText.setMetadataEventId(metadataEvent.getId());
            metadataEventText.setLocale(key);
            metadataEventText.setDescr(value);
            metadataEvent.addMetadataEventText(metadataEventText);
        });
    }


    private boolean conflictWithCoreTypes(String fileName) {
        JsonObject typeFiles = coreModel.getCds();
        for (Entry<String, JsonElement> entry : typeFiles.entrySet()) {
            String key = entry.getKey();
            if (key.equalsIgnoreCase(fileName)) {
                return true;
            }
        }
        return false;
    }

    private boolean checkFileNameConflict(String fileName, List<String> fileNames) {
        String lowerName = fileName.toLowerCase(Locale.ENGLISH);
        if (fileNames.contains(lowerName)) {
            return true;
        }
        fileNames.add(lowerName);
        return false;
    }
}
