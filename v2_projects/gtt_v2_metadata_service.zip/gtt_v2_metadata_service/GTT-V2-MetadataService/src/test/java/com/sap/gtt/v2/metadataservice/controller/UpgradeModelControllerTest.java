/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.gtt.v2.metadataservice.controller;

import com.sap.gtt.v2.metadataservice.service.UpgradeModelServiceManager;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.junit.Assert.assertEquals;

@RunWith(MockitoJUnitRunner.class)
public class UpgradeModelControllerTest {
    @InjectMocks
    private UpgradeModelController controller;
    @Mock
    private UpgradeModelServiceManager upgradeModelServiceManager;

    public UpgradeModelControllerTest() {
    }

    @Test
    public void testUpgradeAll() {
        ResponseEntity<String> result = controller.upgradeAllModel();
        assertEquals(HttpStatus.OK, result.getStatusCode());
    }

    @Test
    public void testUpgradeTheModel() {
        String instance = "lbn-gtt-core-storage-hana2";
        String model = "com.sap.gtt.app2.test2";
        ResponseEntity<String> result = controller.upgradeTheModel(instance,model);
        assertEquals(HttpStatus.OK, result.getStatusCode());
    }

    @Test
    public void testUpgradeRetryAllModel() {
        byte[] coreModelByte = "coreModel".getBytes();
        ResponseEntity<String> result = controller.upgradeRetryAllModel(coreModelByte);
        assertEquals(HttpStatus.OK, result.getStatusCode());
    }

    @Test
    public void testUpgradeRetryTheModel() {
        String instance = "lbn-gtt-core-storage-hana2";
        String model = "com.sap.gtt.app2.test2";
        byte[] coreModelByte = "coreModel".getBytes();
        ResponseEntity<String> result = controller.upgradeRetryTheModel(instance,model, coreModelByte);
        assertEquals(HttpStatus.OK, result.getStatusCode());
    }


}
