package com.sap.gtt.v2.metadataservice.service.impl;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.sap.gtt.v2.configuration.GTTRestTemplate;
import com.sap.gtt.v2.configuration.ISAPCloudPlatformAgent;
import com.sap.gtt.v2.core.dao.metadata.DefaultSysTableDao;
import com.sap.gtt.v2.core.domain.metadata.MetadataConstants;
import com.sap.gtt.v2.core.domain.metadata.MetadataConstants.MetadataProjectStatus;
import com.sap.gtt.v2.core.entity.metadata.MetadataProject;
import com.sap.gtt.v2.core.entity.metadata.MetadataProjectFile;
import com.sap.gtt.v2.core.management.metadata.IMetadataManagement;
import com.sap.gtt.v2.core.management.tracking.ITrackedProcessManagement;
import com.sap.gtt.v2.log.TenantAwareLogService;
import com.sap.gtt.v2.metadataservice.exception.MetadataServiceValidationException;
import com.sap.gtt.v2.metadataservice.service.CoreModel;
import com.sap.gtt.v2.metadataservice.service.SysTableService;
import com.sap.gtt.v2.metadataservice.utils.JsonModelConverter;
import com.sap.gtt.v2.util.GTTUtils;
import com.sap.gtt.v2.util.JsonUtils;
import org.apache.commons.io.IOUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;

@RunWith(SpringJUnit4ClassRunner.class)
public class MetadataProjectServiceImplTest {
    @InjectMocks
    private MetadataProjectServiceImpl metadataProjectService;

    @Mock
    private GTTRestTemplate restTemplate;

    @Mock
    private ResponseEntity<String> response;

    @Mock
    private DerivedCsnValidation derivedCSNValidation;

    @Mock
    private SysTableService sysTableService;

    @Mock
    private ISAPCloudPlatformAgent.ICurrentAccessContext currentAccessContext;

    @Mock
    private IMetadataManagement metadataManagement;

    @Mock
    private ITrackedProcessManagement trackedProcessManagement;

    @Mock
    private CoreModel coreModel;

    @Mock
    private TenantAwareLogService logService;

    @Mock
    private MetadataProjectExtractor extractor;
    @Mock
    DefaultSysTableDao defaultSysTableDao;

    @Mock
    MessageSource messageSource;


    @Before

    public void setup() {
        GTTUtils.BusinessOperator businessOperator = mock(GTTUtils.BusinessOperator.class);
        given(businessOperator.getMetadataManagement()).willReturn(metadataManagement);
        given(businessOperator.getTrackedProcessManagement()).willReturn(trackedProcessManagement);
        given(currentAccessContext.createBusinessOperator()).willReturn(businessOperator);
        JsonObject cds = new JsonObject();
        given(coreModel.getCds()).willReturn(cds);
        given(coreModel.getCoreModelVersion()).willReturn("1.0.0");
        String coreModelI18n = "{\"i18n.properties\": \"EL_TrackedProcess_altKey_LABEL=Alt Key\n\"}";
        given(coreModel.getI18n()).willReturn(JsonUtils.generateJsonObjectFromJsonString(coreModelI18n));
        Mockito.when(messageSource.getMessage(ArgumentMatchers.anyString(), ArgumentMatchers.isNull(), ArgumentMatchers.any(Locale.class))).thenReturn("test");
    }

    @Test
    public void testCompileCDS() {
        String cds = "";
        Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(HttpMethod.class), Mockito.any(HttpHeaders.class), Mockito.anyString(), eq(String.class))).thenReturn(response);
        String body = "{\"DeliveryModel.cds\":\"namespace com.sap.gtt.app.deliverysample\"}";
        Mockito.when(response.getBody()).thenReturn(body);
        metadataProjectService.compileCDS(cds);
    }

    @Test
    public void testHandleCompileResponse() {
        MetadataProject metadataProject = new MetadataProject();
        MetadataProjectFile metadataProjectFile = new MetadataProjectFile();
        metadataProject.setMetadataProjectFile(metadataProjectFile);
        JsonObject responseObject = new JsonObject();
        JsonObject swagger = new JsonObject();
        swagger.addProperty("services", "services");
        responseObject.add("swagger", swagger);
        responseObject.addProperty("compiler_version", "compiler_version");
        String csn = "{\"definitions\":{\"com.sap.gtt.app.deliverysample.DeliveryModel.ShippingStatus\":{\"kind\":\"entity\",\"elements\":{\"Code\":{\"key\":true,\"indexNo\":1,\"type\":\"cds.String\",\"@Common.Text\":{\"=\":\"Text\"},\"@Common.TextArrangement\":{\"#\":\"TextOnly\"},\"length\":10,\"@Common.Label\":\"Status Code\"},\"Text\":{\"indexNo\":2,\"type\":\"cds.String\",\"length\":50,\"@Common.Label\":\"Status Name\"}}}}}";
        responseObject.add("csn", new JsonParser().parse(csn));
        JsonObject service = new JsonObject();
        service.addProperty("annotations", "annotations");
        service.addProperty("metadata", "metadata");
        JsonObject services = new JsonObject();
        services.add("service", service);
        responseObject.add("services", services);
        metadataProjectService.handleCompileResponse(metadataProject, responseObject);
    }

    @Test
    public void testHandleCompileResponseWithEdmx() {
        MetadataProject metadataProject = new MetadataProject();
        MetadataProjectFile metadataProjectFile = new MetadataProjectFile();
        metadataProject.setMetadataProjectFile(metadataProjectFile);
        JsonObject responseObject = new JsonObject();
        JsonObject swagger = new JsonObject();
        swagger.addProperty("services", "services");
        responseObject.add("swagger", swagger);
        responseObject.addProperty("compiler_version", "compiler_version");
        String csn = "{\"definitions\":{\"com.sap.gtt.app.deliverysample.DeliveryModel.ShippingStatus\":{\"kind\":\"entity\",\"elements\":{\"Code\":{\"key\":true,\"indexNo\":1,\"type\":\"cds.String\",\"@Common.Text\":{\"=\":\"Text\"},\"@Common.TextArrangement\":{\"#\":\"TextOnly\"},\"length\":10,\"@Common.Label\":\"Status Code\"},\"Text\":{\"indexNo\":2,\"type\":\"cds.String\",\"length\":50,\"@Common.Label\":\"Status Name\"}}}}}";
        responseObject.add("csn", new JsonParser().parse(csn));
        JsonObject service = new JsonObject();
        service.addProperty("annotations", "annotations");
        String edmxFileName = "com.sap.gtt.app.tfo.TFOService_metadata_1.xml";
        String edmxFileContent = getEdmx(edmxFileName);
        service.addProperty("metadata", edmxFileContent);
        JsonObject services = new JsonObject();
        services.add("service", service);
        responseObject.add("services", services);
        metadataProjectService.handleCompileResponse(metadataProject, responseObject);
    }

    private String getEdmx(String edmxFileName) {
        String edmxFile = "";
        try {
            edmxFile = IOUtils.toString(JsonModelConverter.class.getClassLoader()
                    .getResourceAsStream(edmxFileName), Charset.defaultCharset());
        } catch (IOException e) {
            fail("JsonModel load failed !");
        }
        return edmxFile;
    }

    @Test
    public void testCombineCDSWithCore() {
        MetadataProject metadataProject = new MetadataProject();
        MetadataProjectFile metadataProjectFile = new MetadataProjectFile();
        metadataProject.setMetadataProjectFile(metadataProjectFile);
        String csn = "{\"definitions\":{\"com.sap.gtt.app.deliverysample.DeliveryModel.ShippingStatus\":{\"kind\":\"entity\",\"elements\":{\"Code\":{\"key\":true,\"indexNo\":1,\"type\":\"cds.String\",\"@Common.Text\":{\"=\":\"Text\"},\"@Common.TextArrangement\":{\"#\":\"TextOnly\"},\"length\":10,\"@Common.Label\":\"Status Code\"},\"Text\":{\"indexNo\":2,\"type\":\"cds.String\",\"length\":50,\"@Common.Label\":\"Status Name\"}}}}}";
        metadataProjectFile.setCds(csn);
        Assert.assertNotNull(metadataProjectService.combineCDSWithCore(metadataProject, null, false));
    }

    @Test
    public void combineI18nWithCore() {
        MetadataProject metadataProject = new MetadataProject();
        MetadataProjectFile metadataProjectFile = new MetadataProjectFile();
        metadataProject.setMetadataProjectFile(metadataProjectFile);
        String customI18n = "{\"i18n.properties\": \"EL_Shipment_tpString_LABEL=TP String\nEL_ShipmentEvent_tpString_LABEL=String\n\"}";
        metadataProjectFile.setI18n(customI18n);
        metadataProjectService.combineI18nWithCore(metadataProject, null, false);
        Assert.assertTrue(metadataProjectFile.getI18n().indexOf("EL_TrackedProcess_altKey_LABEL") > 0);

        metadataProjectFile.setI18n(null);
        metadataProjectService.combineI18nWithCore(metadataProject, null, false);
        Assert.assertTrue(metadataProjectFile.getI18n().indexOf("EL_TrackedProcess_altKey_LABEL") > 0);
    }

    @Test
    public void testSaveMetadataProject() throws IOException {
        MetadataProject metadataProject = new MetadataProject();
        MetadataProjectFile metadataProjectFile = new MetadataProjectFile();
        metadataProject.setMetadataProjectFile(metadataProjectFile);
        String devivedCsn = readFile("DerivedCSN.json");
        metadataProjectFile.setDerivedCsn(devivedCsn);
        metadataProjectService.saveMetadataProject(metadataProject, false);
    }

    @Test
    public void testSaveMetadataProjectForUpdating() throws IOException {
        MetadataProject metadataProject = new MetadataProject();
        MetadataProjectFile metadataProjectFile = new MetadataProjectFile();
        metadataProject.setMetadataProjectFile(metadataProjectFile);
        String devivedCsn = readFile("DerivedCSN.json");
        metadataProjectFile.setDerivedCsn(devivedCsn);

        List<MetadataProject> existed = new ArrayList<>();
        existed.add(metadataProject);
        given(metadataManagement.findMetadataProjectInfoByNamespace(ArgumentMatchers.any())).willReturn(existed);

        metadataProjectService.saveMetadataProject(metadataProject, false);
    }

    @Test
    public void testSaveMetadataProjectForSavingCodeList() throws IOException {
        MetadataProject metadataProject = new MetadataProject();
        MetadataProjectFile metadataProjectFile = new MetadataProjectFile();
        String devivedCsn = readFile("DerivedCSN.json");
        metadataProjectFile.setDerivedCsn(devivedCsn);
        String jsonModelForCodeList = readFile("JsonModelForCodeList.json");
        metadataProjectFile.setJsonModel(jsonModelForCodeList);
        metadataProject.setMetadataProjectFile(metadataProjectFile);

        List<MetadataProject> existed = new ArrayList<>();
        existed.add(metadataProject);
        given(metadataManagement.findMetadataProjectInfoByNamespace(ArgumentMatchers.any())).willReturn(existed);
        doNothing().when(sysTableService).emptyCodeListTable(anyString());
        doNothing().when(sysTableService).insertCodeListTable(ArgumentMatchers.any());
        doNothing().when(sysTableService).insertCodeListTextsTable(ArgumentMatchers.any());
        doNothing().when(defaultSysTableDao).emptyTable(anyString());
        doNothing().when(defaultSysTableDao).insertCodeListTexts(ArgumentMatchers.any());

        metadataProjectService.saveMetadataProject(metadataProject, false);
    }

    @Test
    public void testDownloadMetadataFileByField() {
        metadataProjectService.downloadMetadataFileByField("", MetadataConstants.MetadataProjectFileField.EDMX);
    }

    @Test
    public void testDetAllMetadataProject() {
        metadataProjectService.getAllMetadataProject();
    }

    private String readFile(String file) throws IOException {
        return IOUtils.toString(MetadataProjectServiceImplTest.class.getClassLoader().getResourceAsStream(file), StandardCharsets.UTF_8);
    }

    @Test(expected = MetadataServiceValidationException.class)
    public void testDropModelByNamespaceWithNamespaceNOTExist() {
        List<MetadataProject> existed = new ArrayList<>();
        given(metadataManagement.findMetadataProjectInfoByNamespace(ArgumentMatchers.any())).willReturn(existed);
        metadataProjectService.dropModelByNamespace("com.sap.gtt.app.mim");
    }

    @Test
    public void testDropModelByNamespaceWithNamespaceExists() throws IOException {
        MetadataProject metadataProject = new MetadataProject();
        MetadataProjectFile metadataProjectFile = new MetadataProjectFile();
        metadataProject.setMetadataProjectFile(metadataProjectFile);
        String devivedCsn = readFile("DerivedCSN.json");
        metadataProjectFile.setDerivedCsn(devivedCsn);

        List<MetadataProject> existed = new ArrayList<>();
        existed.add(metadataProject);
        given(metadataManagement.findMetadataProjectInfoByNamespace(ArgumentMatchers.any())).willReturn(existed);
        doNothing().when(metadataManagement).deleteMetadata(ArgumentMatchers.any());
        doNothing().when(trackedProcessManagement).deleteAllTheTrackedProcessByNamespace(ArgumentMatchers.any());
        doNothing().when(sysTableService).dropUserEntityTables(ArgumentMatchers.any());
        metadataProjectService.dropModelByNamespace("com.sap.gtt.app.mim");
    }

    @Test
    public void testDeployModelAndSave() throws IOException {
        byte[] zipByte = new byte[]{};
        MetadataProject metadataProject = new MetadataProject();
        MetadataProjectFile metadataProjectFile = new MetadataProjectFile();
        metadataProject.setMetadataProjectFile(metadataProjectFile);
        String devivedCsn = readFile("DerivedCSN.json");
        metadataProjectFile.setDerivedCsn(devivedCsn);

        metadataProject.setMetadataProjectFile(metadataProjectFile);
        String cds = "{\"definitions\":{\"com.sap.gtt.app.deliverysample.DeliveryModel.ShippingStatus\":{\"kind\":\"entity\",\"elements\":{\"Code\":{\"key\":true,\"indexNo\":1,\"type\":\"cds.String\",\"@Common.Text\":{\"=\":\"Text\"},\"@Common.TextArrangement\":{\"#\":\"TextOnly\"},\"length\":10,\"@Common.Label\":\"Status Code\"},\"Text\":{\"indexNo\":2,\"type\":\"cds.String\",\"length\":50,\"@Common.Label\":\"Status Name\"}}}}}";
        metadataProjectFile.setCds(cds);

        metadataProject.setMetadataProjectFile(metadataProjectFile);
        String customI18n = "{\"i18n.properties\": \"EL_Shipment_tpString_LABEL=TP String\nEL_ShipmentEvent_tpString_LABEL=String\n\"}";
        metadataProjectFile.setI18n(customI18n);

        given(extractor.extractFromZip(zipByte)).willReturn(metadataProject);

        Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(HttpMethod.class), Mockito.any(HttpHeaders.class), Mockito.anyString(), eq(String.class))).thenReturn(response);

        JsonObject responseObject = new JsonObject();
        JsonObject swagger = new JsonObject();
        swagger.addProperty("services", "services");
        responseObject.add("swagger", swagger);
        responseObject.addProperty("compiler_version", "compiler_version");
        String originalCsn = readFile("MIMService_csn.json");
        responseObject.add("csn", new JsonParser().parse(originalCsn));
        JsonObject service = new JsonObject();
        String annotationContent = getAnnotations();
        service.addProperty("annotations", annotationContent);
        String metadata = getMetaData();
        service.addProperty("metadata", metadata);
        JsonObject services = new JsonObject();
        services.add("service", service);
        responseObject.add("services", services);
        Mockito.when(response.getBody()).thenReturn(responseObject.toString());

        metadataProjectService.deployModelAndSave(zipByte);
    }

    private String getAnnotations() {
        String annotationFileName = "annotation.xml";
        String annotationFileContent = getFileContent(annotationFileName);
        return annotationFileContent;
    }

    private String getMetaData() {
        String annotationFileName = "edmxWithoutAnnotation.xml";
        String annotationFileContent = getFileContent(annotationFileName);
        return annotationFileContent;
    }

    @Test
    public void testDropModelAndDeletePdmSchema() throws IOException {
        MetadataProject metadataProject = new MetadataProject();
        MetadataProjectFile metadataProjectFile = new MetadataProjectFile();
        metadataProject.setMetadataProjectFile(metadataProjectFile);
        String devivedCsn = readFile("DerivedCSN.json");
        metadataProjectFile.setDerivedCsn(devivedCsn);

        List<MetadataProject> existed = new ArrayList<>();
        existed.add(metadataProject);
        given(metadataManagement.findMetadataProjectInfoByNamespace(ArgumentMatchers.any())).willReturn(existed);
        doNothing().when(metadataManagement).deleteMetadata(ArgumentMatchers.any());
        doNothing().when(trackedProcessManagement).deleteAllTheTrackedProcessByNamespace(ArgumentMatchers.any());
        doNothing().when(sysTableService).dropUserEntityTables(ArgumentMatchers.any());

        metadataProjectService.dropModelAndDeletePdmSchema("com.sap.gtt.app.mim");
    }

    @Test
    public void testUpdateMetadataProjectStatus() {
        metadataProjectService.updateMetadataProjectStatus("com.sap.gtt.app.mim", MetadataProjectStatus.ACTIVE);
    }

    private String getFileContent(String edmxFileName) {
        String edmxFile = "";
        try {
            edmxFile = IOUtils.toString(JsonModelConverter.class.getClassLoader()
                    .getResourceAsStream(edmxFileName), Charset.defaultCharset());
        } catch (IOException e) {
            fail("JsonModel load failed !");
        }
        return edmxFile;
    }

    @Test
    public void testGetI18nInfo() {
        String namespace = "com.sap.gtt.app.mim";
        String fileName = "i18n.properties";
        String customI18n = "EL_Shipment_tpString_LABEL=TP String\nEL_ShipmentEvent_tpString_LABEL=String";
        given(metadataManagement.getI18nInfo(namespace, fileName)).willReturn(customI18n);
        String i18nInfo = metadataProjectService.getI18nInfo(namespace, fileName);
        assertNotNull(i18nInfo);

        fileName = "i18n_en.properties";
        given(metadataManagement.getI18nInfo(namespace, fileName)).willReturn("");
        i18nInfo = metadataProjectService.getI18nInfo(namespace, fileName);
        assertEquals("", i18nInfo);
    }
}
