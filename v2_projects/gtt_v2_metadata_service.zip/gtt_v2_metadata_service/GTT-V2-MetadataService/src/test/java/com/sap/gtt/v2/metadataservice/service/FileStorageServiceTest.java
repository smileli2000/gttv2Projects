package com.sap.gtt.v2.metadataservice.service;

import com.sap.gtt.v2.metadataservice.exception.ManageModelsServiceValidationException;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Path;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
public class FileStorageServiceTest {

    @Mock
    MultipartFile multipartFile;

    @InjectMocks
    FileStorageService fileStorageService;

    @Test
    public void testStoreFile() throws IOException {
        InputStream inputStream = mock(InputStream.class);
        Mockito.when(multipartFile.getInputStream()).thenReturn(inputStream);
        fileStorageService.storeFile(multipartFile);
        Assert.assertTrue(true);
    }

    @Test
    public void testDeleteFile(){
        String fileName = "testFileDelete.json";
        fileStorageService.deleteFile(fileName);
    }

}
