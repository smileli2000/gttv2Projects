/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.gtt.v2.metadataservice.utils;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.io.IOUtils;
import org.junit.Test;
import static org.junit.Assert.*;
import org.springframework.core.io.ClassPathResource;

/**
 *
 * @author I326335
 */
public class ZipFileGeneratorTest {
    
    public ZipFileGeneratorTest() {
    }

    /**
     * Test of zip method, of class ZipFileGenerator.
     * @throws java.lang.Exception
     */
    @Test
    public void testZip() throws Exception {
        Map<String, String> cdsMap = new HashMap<String, String>(){{
            put("tfo.cds", "aaaa");
            put("tfo.properties", "111");
            put("tfo1.properties", "222");
        }};
        ClassPathResource resource = new ClassPathResource("test.zip");
        InputStream fis = resource.getInputStream();
        ByteArrayOutputStream expBAOS = new ByteArrayOutputStream();
        IOUtils.copy(fis, expBAOS);
        ByteArrayOutputStream result = ZipFileGenerator.zip(cdsMap);
        assertNotNull(result);
        //assertEquals(expBAOS, result);
    }
    
}
