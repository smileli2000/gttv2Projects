package com.sap.gtt.v2.metadataservice.utils;

import com.sap.gtt.v2.metadataservice.domain.DraftModelBean;
import com.sap.gtt.v2.metadataservice.exception.CdsInfoGeneratorException;
import org.apache.commons.io.IOUtils;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.nio.charset.Charset;

import static org.junit.Assert.assertNotNull;


public class JsonModelConverterTest {
    private static final String JSON_MODEL_CONVERTER = "draftModel.json";

    @Before
    public void setup() {
    }

    @Test
    public void testConvertJsonToModelBean() {
        try {
            String jsonModel = IOUtils.toString(JsonModelConverter.class.getClassLoader()
                    .getResourceAsStream(JSON_MODEL_CONVERTER), Charset.defaultCharset());
            DraftModelBean draftModelBean = JsonModelConverter.convertJsonToModelBean(jsonModel);
            assertNotNull(draftModelBean);
        } catch (
                IOException e) {
            throw new CdsInfoGeneratorException(e.getMessage(), e, CdsInfoGeneratorException.MESSAGE_CODE_ERROR_FIND_TEMPLATE_FILE_FAILED, new Object[]{});
        }


    }


}
