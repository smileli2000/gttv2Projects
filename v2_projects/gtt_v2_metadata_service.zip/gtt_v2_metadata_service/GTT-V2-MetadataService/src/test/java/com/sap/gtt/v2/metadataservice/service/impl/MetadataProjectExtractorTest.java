package com.sap.gtt.v2.metadataservice.service.impl;

import com.google.gson.JsonObject;
import com.sap.gtt.v2.core.entity.metadata.MetadataProcess;
import com.sap.gtt.v2.core.entity.metadata.MetadataProject;
import com.sap.gtt.v2.core.entity.metadata.MetadataProjectFile;
import com.sap.gtt.v2.core.management.metadata.DefaultMetadataManagement;
import com.sap.gtt.v2.core.management.metadata.IMetadataManagement;
import com.sap.gtt.v2.core.rule.impl.GTTEmbededRuleScriptLauncher;
import com.sap.gtt.v2.metadataservice.service.CoreModel;
import org.apache.commons.io.IOUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ResourceLoader;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.io.IOException;
import java.util.List;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;

@RunWith(SpringJUnit4ClassRunner.class)
public class MetadataProjectExtractorTest {
    @Autowired
    private ResourceLoader resourceLoader;

    @InjectMocks
    private MetadataProjectExtractor metadataProjectExtractor;

    @Mock
    private GTTEmbededRuleScriptLauncher gttEmbededRuleScriptLauncher;

    @Mock
    private CoreModel coreModel;

    @Before
    public void setup() {
        Mockito.when(coreModel.getCoreModelVersion()).thenReturn("1.0.0");
        Mockito.when(coreModel.getCds()).thenReturn(new JsonObject());
        Mockito.when(coreModel.getI18n()).thenReturn(new JsonObject());
        Mockito.when(gttEmbededRuleScriptLauncher.parse(anyString())).thenReturn(mock(GTTEmbededRuleScriptLauncher.ParseResult.class));
    }

    @Test
    public void testMetadataProjectExtractorWithRightZip() throws IOException {
        byte[] zipByte = IOUtils.toByteArray(resourceLoader.getResource("zip/tfo.zip").getInputStream());
        metadataProjectExtractor.extractFromZip(zipByte);
    }

    @Test
    public void testMetadataProjectExtractorDescription() throws IOException {
        byte[] zipByte = IOUtils.toByteArray(resourceLoader.getResource("zip/sof.zip").getInputStream());
        MetadataProject metadataProject = metadataProjectExtractor.extractFromZip(zipByte);
        String namespace = metadataProject.getNamespace();
        assertEquals("com.gttsampleso01.gtt.app.sof", namespace);

        List<MetadataProcess> metadataProcessList = metadataProject.getMetadataProcessList();
        for (MetadataProcess metadataProcess : metadataProcessList) {
            assertNotNull(metadataProcess.getDescription());
            assertTrue(metadataProcess.getMetadataProcessTexts().size() > 0);
        }
    }

    @Test
    public void testextractMetadataProjectInfoFromDb() {
        MetadataProjectFile metadataProjectFile = new MetadataProjectFile();
        metadataProjectFile.setCds("cds");
        metadataProjectFile.setJsonModel("jsonmodel");
        metadataProjectFile.setRules("rules");
        metadataProjectFile.setI18n("i18n");
        MetadataProject metadataProject = new MetadataProject();
        IMetadataManagement mockMetadataManagement = Mockito.mock(DefaultMetadataManagement.class);
        Mockito.when(mockMetadataManagement.getMetadataProjectFileInfo(any(),anyString())).thenReturn(metadataProjectFile);
        metadataProjectExtractor.extractMetadataProjectInfoFromDb(metadataProject,mockMetadataManagement);

    }
}
