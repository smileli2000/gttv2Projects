package com.sap.gtt.v2.metadataservice.service;

import com.sap.gtt.v2.configuration.GTTRestTemplate;
import com.sap.gtt.v2.configuration.ISAPCloudPlatformAgent;
import com.sap.gtt.v2.core.entity.metadata.MetadataProject;
import com.sap.gtt.v2.core.management.metadata.IMetadataManagement;
import com.sap.gtt.v2.core.management.tracking.DefaultTrackedProcessManagement;
import com.sap.gtt.v2.core.management.tracking.ITrackedProcessManagement;
import com.sap.gtt.v2.core.service.MessageProcessingService;
import com.sap.gtt.v2.log.TenantAwareLogService;
import com.sap.gtt.v2.metadataservice.service.impl.DerivedCsnValidation;
import com.sap.gtt.v2.metadataservice.service.impl.MetadataProjectExtractor;
import com.sap.gtt.v2.servicemanager.GTTInstance;
import com.sap.gtt.v2.tenant.TenantService;
import com.sap.gtt.v2.util.GTTUtils;
import com.sap.gtt.v2.util.SpringContextUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.io.ResourceLoader;
import org.springframework.http.ResponseEntity;
import org.powermock.api.mockito.PowerMockito;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;


@RunWith(PowerMockRunner.class)
@PrepareForTest({SpringContextUtils.class})
public class UpgradeModelServiceManagerTest {
    @InjectMocks
    private UpgradeModelServiceManager upgradeModelServiceManager = new UpgradeModelServiceManager();
    @Mock
    private TenantService tenantService;

    @Mock
    private TenantAwareLogService logService;

    @Before
    public void setup() {
        PowerMockito.mockStatic(SpringContextUtils.class);
    }

    @Test
    public void testUpgradeAll() {
           upgradeModelServiceManager.upgradeAll();
    }

    @Test
    public void testUpgradeAllWithInstance() {
        PowerMockito.when(SpringContextUtils.containsBean(Mockito.anyString())).thenReturn(false);
        PowerMockito.when(SpringContextUtils.containsBean(Mockito.anyString())).thenReturn(true);
        List<GTTInstance> gttInstances = new ArrayList();
        GTTInstance gttInstance = new GTTInstance();
        gttInstances.add(gttInstance);
        given(tenantService.getGTTInstances()).willReturn(gttInstances);
        upgradeModelServiceManager.upgradeAll();
    }

    @Test
    public void testUpgradeWithInstancesAndNamespaces() {
        String instance = "instance1_com.sap.gtt.app.test1";
        String model = "instance2_namespace2";
        upgradeModelServiceManager.upgrade(instance,model);
    }

    @Test
    public void testUpgradeWithInstancesAndNamespacesWithInstance() {
        String instance = "instance1_com.sap.gtt.app.test1";
        String model = "instance2_namespace2";
        PowerMockito.when(SpringContextUtils.containsBean(Mockito.anyString())).thenReturn(false);
        PowerMockito.when(SpringContextUtils.containsBean(Mockito.anyString())).thenReturn(true);
        GTTInstance gttInstance = new GTTInstance();
        given(tenantService.getGTTInstanceByName(anyString())).willReturn(gttInstance);
        upgradeModelServiceManager.upgrade(instance,model);
    }


    @Test
    public void testUpgradeRetryAll() {
        byte[] metadataByte = "test".getBytes();
        upgradeModelServiceManager.upgradeRetryAll(metadataByte);
    }

    @Test
    public void testUpgradeRetryAllWithInstance() {
        byte[] metadataByte = "test".getBytes();
        PowerMockito.when(SpringContextUtils.containsBean(Mockito.anyString())).thenReturn(false);
        PowerMockito.when(SpringContextUtils.containsBean(Mockito.anyString())).thenReturn(true);
        List<GTTInstance> gttInstances = new ArrayList();
        GTTInstance gttInstance = new GTTInstance();
        gttInstances.add(gttInstance);
        given(tenantService.getGTTInstances()).willReturn(gttInstances);
        upgradeModelServiceManager.upgradeRetryAll(metadataByte);
    }


}
