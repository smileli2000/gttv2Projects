package com.sap.gtt.v2.metadataservice.utils;

import com.google.gson.JsonObject;
import com.sap.gtt.v2.util.JsonUtils;
import org.junit.Assert;
import org.junit.Test;

import static com.sap.gtt.v2.metadataservice.utils.Constant.NAME;

public class FileHelperTest {
    String filePath = "idoc/OutboundDelivery.json";

    @Test
    public void loadResourceFileAsStringTest() {
        String fileContent = FileHelper.loadResourceFileAsString(filePath);
        JsonObject fileObject = JsonUtils.generateJsonObjectFromJsonString(fileContent);
        Assert.assertEquals("OutboundDelivery", fileObject.get(NAME).getAsString());
    }
}
