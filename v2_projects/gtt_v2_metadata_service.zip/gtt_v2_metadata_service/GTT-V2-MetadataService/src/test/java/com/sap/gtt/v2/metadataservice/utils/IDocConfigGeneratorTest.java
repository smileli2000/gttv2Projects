package com.sap.gtt.v2.metadataservice.utils;

import org.apache.commons.io.IOUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.io.IOException;
import java.nio.charset.Charset;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

@RunWith(SpringJUnit4ClassRunner.class)
public class IDocConfigGeneratorTest {

    @Test
    public void testGenIDocConfiguration(){
        String fileName = "draftModelForIdoc.json";
        String namespace = "com.sap.gtt.app.cgtest5";
        String model = getDraftModel(fileName);
        String result = "{\"processTypes\":[{\"name\":\"com.sap.gtt.app.cgtest5.shipment.shipment\",\"enableIDoc\":true,\"idocMapping\":{\"eventType\":\"shipmentEvent\",\"erpObjectType\":\"OTHERS\",\"fieldMapping\":[{\"field\":\"FORWARDING_AGENT\",\"idocSegment\":\"E1EHPCP\",\"idocField\":\"FORWARDING_AGENT\"},{\"field\":\"delivery\",\"target\":\"shipment.deliveryInfo\",\"composition\":[{\"field\":\"DEL_NO\",\"idocSegment\":\"E1EHPCP\",\"idocField\":\"DEL_NO\"},{\"field\":\"NO_OF_PACKAGES\",\"idocSegment\":\"E1EHPCP\",\"idocField\":\"NO_OF_PACKAGES\"},{\"field\":\"SHIPMENT_TYPE\",\"idocSegment\":\"E1EHPCP\",\"idocField\":\"SHIPMENT_TYPE\",\"type\":\"codelist\"}]},{\"field\":\"SHIPMENT_WEIGHT\",\"idocSegment\":\"E1EHPCP\",\"idocField\":\"SHIPMENT_WEIGHT\"},{\"field\":\"SHIPMENT_WEIGHT_UNIT\",\"idocSegment\":\"E1EHPCP\",\"idocField\":\"SHIPMENT_WEIGHT_UNIT\"},{\"field\":\"SHIPMENT_TYPE\",\"idocSegment\":\"E1EHPCP\",\"idocField\":\"SHIPMENT_TYPE\",\"type\":\"codelist\"}],\"applicationObjectType\":\"YSHIPMENT_ACC\",\"idoc\":\"EHPOST01\"}}],\"eventTypes\":[{\"name\":\"com.sap.gtt.app.cgtest5.shipment.CheckInEvent\",\"enableIDoc\":true,\"idocMapping\":{\"idoc\":\"EVMSTA02\",\"erpEventCode\":\"ARRIV_CARR\",\"fieldMapping\":[]}},{\"name\":\"com.sap.gtt.app.cgtest5.shipment.LoadingStartEvent\",\"enableIDoc\":true,\"idocMapping\":{\"idoc\":\"EVMSTA02\",\"erpEventCode\":\"LOAD_BEGIN\"}},{\"name\":\"com.sap.gtt.app.cgtest5.shipment.LoadingEndEvent\",\"enableIDoc\":true,\"idocMapping\":{\"idoc\":\"EVMSTA02\",\"erpEventCode\":\"LOAD_END\"}}]}";
        assertEquals(result, IDocConfigGenerator.genIDocConfiguration(model, namespace));

    }


    private String getDraftModel(String draftModelName) {
        String jsonModel = "";
        try {
            jsonModel = IOUtils.toString(JsonModelConverter.class.getClassLoader()
                    .getResourceAsStream(draftModelName), Charset.defaultCharset());
        } catch (IOException e) {
            fail("JsonModel load failed !");
        }

        return jsonModel;
    }

}
