/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.gtt.v2.metadataservice.controller;

import com.sap.gtt.v2.log.TenantAwareLogService;
import com.sap.gtt.v2.metadataservice.exception.MetadataServiceValidationException;
import com.sap.gtt.v2.metadataservice.service.MetadataProjectService;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.runner.RunWith;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.BDDMockito.given;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

/**
 *
 * @author I326335
 */
@RunWith(MockitoJUnitRunner.class)
public class MetadataProjectControllerTest {
    @InjectMocks
    private MetadataProjectController controller;
    @Mock
    private TenantAwareLogService tenantAwareLogService;
    @Mock
    private MetadataProjectService metaDataProjectService;
    
    public MetadataProjectControllerTest() {
    }

    /**
     * Test of deploy method, of class MetadataProjectController.
     */
    @Test
    public void testDeploy() {
        byte[] metadataByte = null;
        ResponseEntity<String> result = controller.deploy(metadataByte);
        assertEquals(HttpStatus.OK, result.getStatusCode());
    }

    /**
     * Test of download method, of class MetadataProjectController.
     */
    @Test
    public void testDownload() {
        ResponseEntity<String> result = controller.download("", "CDS");
        assertEquals(HttpStatus.OK, result.getStatusCode());
    }
    
    @Test(expected = MetadataServiceValidationException.class)
    public void testDownloadException() {
        controller.download("", "CDS1");
    }

    @Test
    public void testDownloadWriteSwagger() {
        given(metaDataProjectService.downloadMetadataFileByField(anyString(), any())).willReturn("{\"service\":{}}");
        ResponseEntity<String> result = controller.downloadWriteSwagger("");
        assertEquals(HttpStatus.OK, result.getStatusCode());
    }

    @Test
    public void testDownloadReadSwagger() {
        given(metaDataProjectService.downloadMetadataFileByField(anyString(), any())).willReturn("{\"service\": \"\"}");
        ResponseEntity<String> result = controller.downloadReadSwagger("");
        assertEquals(HttpStatus.OK, result.getStatusCode());
    }


    
    /**
     * Test of fetchAllMetadataProject method, of class MetadataProjectController.
     */
    @Test
    public void testFetchAllMetadataProject() {
        ResponseEntity<String> result = controller.fetchAllMetadataProject();
        assertEquals(HttpStatus.OK, result.getStatusCode());
    }


    @Test
    public void testDropModel() {
        ResponseEntity<String> result = controller.dropModel("com.sap.gtt.app.mim");
        assertEquals(HttpStatus.OK, result.getStatusCode());
    }
    
}
