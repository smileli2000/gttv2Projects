package com.sap.gtt.v2.metadataservice.controller;

import com.google.gson.JsonObject;
import com.sap.gtt.v2.configuration.ISAPCloudPlatformAgent;
import com.sap.gtt.v2.core.entity.metadata.MetadataDraftModel;
import com.sap.gtt.v2.core.entity.metadata.MetadataProject;
import com.sap.gtt.v2.exception.MetadataException;
import com.sap.gtt.v2.core.entity.metadata.MetadataProjectFile;
import com.sap.gtt.v2.log.TenantAwareLogService;
import com.sap.gtt.v2.metadataservice.domain.DraftModelBody;
import com.sap.gtt.v2.metadataservice.domain.DraftModelHeaderInfo;
import com.sap.gtt.v2.metadataservice.exception.ManageModelsServiceValidationException;
import com.sap.gtt.v2.metadataservice.service.MetadataManageModelsService;
import com.sap.gtt.v2.metadataservice.service.MetadataProjectService;
import com.sap.gtt.v2.metadataservice.service.impl.DraftModelValidator;
import com.sap.gtt.v2.servicemanager.GTTInstance;
import com.sap.gtt.v2.util.JsonUtils;
import org.apache.commons.io.IOUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.web.servlet.MockMvc;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Locale;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;

@RunWith(MockitoJUnitRunner.class)
public class MetadataManageModelsControllerTest {
    @InjectMocks
    MetadataManageModelsController metadataManageModelsController;

    @Mock
    MetadataManageModelsService metadataManageModelsService;

    @Mock
    DraftModelValidator draftModelValidator;

    @Mock
    MetadataProjectService metaDataProjectService;
    
    @Mock
    private TenantAwareLogService tenantAwareLogService;
    
    @Mock
    private ISAPCloudPlatformAgent.ICurrentAccessContext currentAccessContext;

    @Autowired
    private MockMvc mvc ;

    @Mock
    MessageSource messageSource;

    @Before
    public void setup() {
        Mockito.when(messageSource.getMessage(ArgumentMatchers.anyString(), ArgumentMatchers.isNull(), ArgumentMatchers.any(Locale.class))).thenReturn("test");
    }

    @Test
    public void testGetChangeHistory(){
        ResponseEntity<String> result = metadataManageModelsController.getChangeHistory("ns");
        assertEquals(HttpStatus.OK,result.getStatusCode());
        JsonObject json = new JsonObject();
        json.add("value", JsonUtils.generateJsonElementFromString("[]"));
        assertEquals(json.toString(),result.getBody());
    }

    @Test
    public void testGetModels(){
        ResponseEntity<String> result = metadataManageModelsController.getModels();
        assertEquals(HttpStatus.OK,result.getStatusCode());
        JsonObject json = new JsonObject();
        json.add("value", JsonUtils.generateJsonElementFromString("[]"));
        assertEquals(json.toString(),result.getBody());
    }

    @Test
    public void testGetIdocPresets(){
        ResponseEntity<String> result = metadataManageModelsController.getIdocPresets();
        String idocMapping = result.getBody();
        assertNotNull(idocMapping);
    }

    @Test(expected = MetadataException.class)
    public void testGetDraftModel(){
        ResponseEntity<String> result = metadataManageModelsController.getDraftModel("ns");
        assertEquals(HttpStatus.NOT_FOUND,result.getStatusCode());
        given(metadataManageModelsService.getMetadataDraftModelByNamespace("n")).willReturn(new DraftModelBody("xx","","",null,"{}"));
        result = metadataManageModelsController.getDraftModel("n");
        assertEquals(HttpStatus.OK,result.getStatusCode());
    }
    
    @Test
    public void testGetModel(){
        given(metadataManageModelsService.getMetadataDraftModelHeaderInfoByNamespace("n")).willReturn(new DraftModelHeaderInfo("", "", ""));
        ResponseEntity<String> result = metadataManageModelsController.getModel("n");
        assertEquals(HttpStatus.OK,result.getStatusCode());
    }

    @Test
    public void testCreateModel() throws IOException {
        given(metadataManageModelsService.getMetadataDraftModelInfoByNamespace("com.sap.gtt")).willReturn(new MetadataDraftModel());
        DraftModelBody draftModel = new DraftModelBody(new MetadataDraftModel("ns","com.sap.gtt1","","","","", "{}", Instant.now()));
        String draftModelBody = JsonUtils.generateJsonStringFromBean(draftModel);
        
        given(draftModelValidator.validate(anyString())).willReturn(draftModelBody);
        GTTInstance gttInstance = mock(GTTInstance.class);
        given(gttInstance.getNamespace()).willReturn("com.sap.gtt");
        given(currentAccessContext.getInstance()).willReturn(gttInstance);
        ResponseEntity<String> result = metadataManageModelsController.createModel(new MockHttpServletRequest(), null, draftModelBody);
        assertEquals(HttpStatus.CREATED,result.getStatusCode());
        draftModel.setNamespace("com.sap.gtt");
        draftModelBody = JsonUtils.generateJsonStringFromBean(draftModel);
        
        try {
            given(draftModelValidator.validate(anyString())).willReturn(draftModelBody);
            result = metadataManageModelsController.createModel(new MockHttpServletRequest(), null, draftModelBody);
            Assert.fail("Exception is not thrown.");
        } catch (Exception e) {
            System.out.println(e.getMessage());
            Assert.assertTrue(true);
        }
        
        draftModelBody = getJson("mmpayloads/DraftModel.json");
        
        given(draftModelValidator.validate(anyString())).willReturn(new DraftModelValidator().validate(draftModelBody));
        result = metadataManageModelsController.createModel(new MockHttpServletRequest(),null, draftModelBody);
        assertEquals(HttpStatus.CREATED,result.getStatusCode());
        
        result = metadataManageModelsController.createModel(new MockHttpServletRequest(),true, draftModelBody);
        assertEquals(HttpStatus.OK,result.getStatusCode());
    }
    
    @Test
    public void testUpdateModel() throws IOException{
        given(metadataManageModelsService.getMetadataDraftModelInfoByNamespace("com.sap.gtt")).willReturn(new MetadataDraftModel());
        given(metadataManageModelsService.getMetadataDraftModelInfoByNamespace("com.sap.gtt1")).willReturn(new MetadataDraftModel());
        DraftModelBody draftModel = new DraftModelBody(new MetadataDraftModel("ns","com.sap.gtt","","","", "", "{}", Instant.now()));
        String draftModelBody = JsonUtils.generateJsonStringFromBean(draftModel);
        
        given(draftModelValidator.validate(anyString())).willReturn(draftModelBody);
        GTTInstance gttInstance = mock(GTTInstance.class);
        given(gttInstance.getNamespace()).willReturn("com.sap.gtt");
        given(currentAccessContext.getInstance()).willReturn(gttInstance);
        ResponseEntity<String> result = metadataManageModelsController.updateModelDraft(new MockHttpServletRequest(),"com.sap.gtt", null, draftModelBody);
        assertEquals(HttpStatus.NO_CONTENT,result.getStatusCode());
        draftModel.setNamespace("com.sap.gtt");
        draftModelBody = JsonUtils.generateJsonStringFromBean(draftModel);
        
        try {
            given(draftModelValidator.validate(anyString())).willReturn(draftModelBody);
            result = metadataManageModelsController.updateModelDraft(new MockHttpServletRequest(), "com.sap.gtt1", null, draftModelBody);
            Assert.fail("Exception is not thrown.");
        } catch (Exception e) {
            System.out.println(e.getMessage());
            Assert.assertTrue(true);
        }
        
        draftModelBody = getJson("mmpayloads/DraftModel.json");
        String converted = new DraftModelValidator().validate(draftModelBody);
        given(draftModelValidator.validate(anyString())).willReturn(converted);
        result = metadataManageModelsController.updateModelDraft(new MockHttpServletRequest(),"com.sap.gtt", true, draftModelBody);
        assertEquals(HttpStatus.OK,result.getStatusCode());
    }

    @Test
    public void testGetCoreModel(){
        ResponseEntity<String> result = metadataManageModelsController.getCoreModel();
        assertEquals(HttpStatus.OK,result.getStatusCode());
    }

    @Test
    public void testDeleteModel(){
        given(metadataManageModelsService.getMetadataDraftModelInfoByNamespace("ns")).willReturn(null);
        given(metadataManageModelsService.getMetadataDraftModelInfoByNamespace("com.sap.gtt")).willReturn(new MetadataDraftModel());
        ResponseEntity<String> result = metadataManageModelsController.deleteModel(new MockHttpServletRequest(),"ns");
        assertEquals(HttpStatus.NOT_FOUND,result.getStatusCode());
        given(metadataManageModelsService.findMetadataProjectInfoByNamespace("com.sap.gtt")).willReturn(new ArrayList<MetadataProject>(){{add(new MetadataProject());}});
        result = metadataManageModelsController.deleteModel(new MockHttpServletRequest(),"com.sap.gtt");
        assertEquals(HttpStatus.NO_CONTENT,result.getStatusCode());
    }

    @Test
    public void testDeploy() throws IOException{
        String draftModelBody = getJson("mmpayloads/DraftModel.json");
        String converted = new DraftModelValidator().validate(draftModelBody);
        ResponseEntity<String> result = metadataManageModelsController.deploy(new MockHttpServletRequest(),"com.sap.gtt.tfo", draftModelBody);
        assertEquals(HttpStatus.NOT_FOUND,result.getStatusCode());
        given(metadataManageModelsService.getMetadataDraftModelByNamespace("com.sap.gtt.tfo")).willReturn(JsonUtils.generateBeanFromJson(converted, DraftModelBody.class));
        result = metadataManageModelsController.deploy(new MockHttpServletRequest(),"com.sap.gtt.tfo", draftModelBody);
        assertEquals(HttpStatus.OK,result.getStatusCode());
    }
    
    
    @Test
    public void testChangeStatus() throws IOException{
        String namespace = "com.sap.gtt.tfo";
        given(metadataManageModelsService.findMetadataProjectInfoByNamespace(namespace)).willReturn(new ArrayList<MetadataProject>(){{add(new MetadataProject());}});
        given(metadataManageModelsService.getMetadataDraftModelHeaderInfoByNamespace(namespace)).willReturn(new DraftModelHeaderInfo("", "", ""));
        ResponseEntity<String> result = metadataManageModelsController.changeStatus(namespace, "Active", null);
        assertEquals(HttpStatus.OK,result.getStatusCode());
        result = metadataManageModelsController.changeStatus(namespace, null, "{\"status\":\"Active\"}");
        assertEquals(HttpStatus.OK,result.getStatusCode());
    }
    
    @Test
    public void testGetGTTInstanceNamespaceInfo() throws IOException{
        String namespace = "com.sap.gtt.tfo";
        given(currentAccessContext.getInstance()).willReturn(mock(GTTInstance.class));
        ResponseEntity<String> result = metadataManageModelsController.getGTTInstanceNamespaceInfo();
        assertEquals(HttpStatus.OK,result.getStatusCode());
    }
    
    @Test
    public void testGetDeployedModelDraft() throws IOException{
        String namespace = "com.sap.gtt.tfo";
        String draftModelBody = getJson("mmpayloads/DraftModel.json");
        ResponseEntity<String> result = metadataManageModelsController.getDeployedModelDraft(new MockHttpServletRequest(),namespace);
        assertEquals(HttpStatus.NO_CONTENT,result.getStatusCode());
        MetadataProject metadataProject = new MetadataProject();
        MetadataProjectFile metadataProjectFile = new MetadataProjectFile();
        metadataProjectFile.setJsonModel(draftModelBody);
        metadataProject.setMetadataProjectFile(metadataProjectFile);
        given(metadataManageModelsService.findMetadataProjectInfoByNamespace(namespace)).willReturn(new ArrayList<MetadataProject>(){{add(metadataProject);}});
        result = metadataManageModelsController.getDeployedModelDraft(new MockHttpServletRequest(),namespace);
        assertEquals(HttpStatus.OK,result.getStatusCode());
    }

    private String getJson(String jsonPath) throws IOException {
        ClassPathResource resource = new ClassPathResource(jsonPath);
        try (InputStream inputStream = resource.getInputStream()) {
            return IOUtils.toString(inputStream, StandardCharsets.UTF_8);
        } catch (IOException ex) {
            throw ex;
        }
    }
}
