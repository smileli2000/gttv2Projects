package com.sap.gtt.v2.metadataservice.service.impl;

import com.sap.gtt.v2.configuration.ISAPCloudPlatformAgent;
import com.sap.gtt.v2.core.domain.metadata.MetadataConstants;
import com.sap.gtt.v2.core.entity.metadata.MetadataChangeHistory;
import com.sap.gtt.v2.core.entity.metadata.MetadataDraftModel;
import com.sap.gtt.v2.core.management.metadata.IMetadataManagement;
import com.sap.gtt.v2.metadataservice.domain.DeploymentHistory;
import com.sap.gtt.v2.metadataservice.domain.DraftModelBody;
import com.sap.gtt.v2.util.GTTUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
public class MetadataManageModelsServiceTest {
    @Mock
    private ISAPCloudPlatformAgent.ICurrentAccessContext currentAccessContext;

    @Mock
    private IMetadataManagement metadataManagement;

    @InjectMocks
    private MetadataManageModelsServiceImpl metadataManageModelsService;

    MetadataDraftModel metadataDraftModel = new MetadataDraftModel("","","","","", "", "{}", Instant.now());

    @Before
    public void setup() {
        GTTUtils.BusinessOperator businessOperator = mock(GTTUtils.BusinessOperator.class);
        given(businessOperator.getMetadataManagement()).willReturn(metadataManagement);
        given(currentAccessContext.createBusinessOperator()).willReturn(businessOperator);
    }

    @Test
    public void testFindMetadataChangeHistoriesByNamespace(){
        List<DeploymentHistory> histories = metadataManageModelsService.findMetadataChangeHistoriesByNamespace("");
        assertTrue(histories.isEmpty());

        List<MetadataChangeHistory> mockHistories = new ArrayList<>();
        MetadataChangeHistory his = new MetadataChangeHistory();
        his.setChangeTime(Instant.now());
        his.setAction(MetadataConstants.MetadataChangeActions.DEPLOY.getValue());
        his.setNamespace("hana");
        mockHistories.add(his);

        when(metadataManagement.findMetadataChangeHistoryByNamespace(anyString())).thenReturn(mockHistories);

        histories = metadataManageModelsService.findMetadataChangeHistoriesByNamespace("hana");
        assertTrue(histories.size() > 0);
        assertNotNull(histories.get(0).getChangedAt());
        assertEquals(MetadataConstants.MetadataChangeActions.DEPLOY.getValue(), histories.get(0).getAction());
        assertEquals("hana", histories.get(0).getNamespace());
        assertNull(histories.get(0).getChangedBy());
    }

    @Test
    public void testSaveChangeHistory(){
        MetadataChangeHistory metadataChangeHistory = new MetadataChangeHistory();
        metadataManageModelsService.saveMetadataChangeHistory(metadataChangeHistory);
        assertTrue(true);
    }
    @Test
    public void getAllMetadataDraftModelHeaderInfo(){
        metadataManageModelsService.getAllMetadataDraftModelHeaderInfo();
        assertTrue(true);
    }

    @Test
    public void testGetAllMetadataDraftModelsInfo(){
        metadataManageModelsService.getAllMetadataDraftModelsInfo();
        assertTrue(true);
    }

    @Test
    public void testCreateMetadataDraftModel(){
        metadataManageModelsService.createMetadataDraftModel(new DraftModelBody(metadataDraftModel));
        assertTrue(true);
    }
    @Test
    public void testUpdateMetadataDraftModelInfo(){
        metadataManageModelsService.updateMetadataDraftModelInfo(metadataDraftModel);
        assertTrue(true);
    }
    @Test
    public void testDeleteMetadataDraftModel(){
        metadataManageModelsService.deleteMetadataDraftModel("ns");
        assertTrue(true);
    }
    @Test
    public void testGetMetadataDraftModelInfoByNamespace(){
        metadataManageModelsService.getMetadataDraftModelInfoByNamespace("ns");
        assertTrue(true);
    }
    @Test
    public void testGetMetadataDraftModelByNamespace(){
        metadataManageModelsService.getMetadataDraftModelByNamespace("ns");
        assertTrue(true);
    }
    @Test
    public void testUpdateMetadataDraftModel(){
        metadataManageModelsService.updateMetadataDraftModel("ns", new DraftModelBody(metadataDraftModel));
        assertTrue(true);
    }
}


