package com.sap.gtt.v2.metadataservice.utils;


import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.List;
import java.util.Locale;

@RunWith(SpringJUnit4ClassRunner.class)
public class LocaleUtilsTest {

    @Test
    public void getLangTest(){
        String lang = LocaleUtils.getLang(new Locale("zh","CN", "simplify"));
        Assert.assertEquals("zh_CN_simplify", lang);
    }

    @Test
    public void getLocalesTest(){
        List<Locale> locales= LocaleUtils.getLocales();
        Assert.assertNotNull(locales);
    }
}
