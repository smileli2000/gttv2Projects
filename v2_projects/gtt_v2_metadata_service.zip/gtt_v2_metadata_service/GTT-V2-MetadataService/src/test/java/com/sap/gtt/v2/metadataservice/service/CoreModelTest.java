package com.sap.gtt.v2.metadataservice.service;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ResourceLoader;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.lang.reflect.Field;

import static org.junit.Assert.assertEquals;

@RunWith(SpringJUnit4ClassRunner.class)
public class CoreModelTest {
    @InjectMocks
    private CoreModel coreModel;
    @Autowired
    private ResourceLoader resourceLoader;

    @Before
    public void setup() throws Exception {
        MockitoAnnotations.initMocks(this);
        Field field = CoreModel.class.getDeclaredField("resourceLoader");
        field.setAccessible(true);
        field.set(coreModel, resourceLoader);
    }

    @Test
    public void testSetupMethod() {
        coreModel.setup();
        assertEquals("1.0.0", coreModel.getCoreModelVersion());
    }

    @Test
    public void testGetI18n() {
        coreModel.setup();
        coreModel.getI18n();
    }

    @Test
    public void testGetCDS() {
        coreModel.setup();
        coreModel.getCds();
    }

    @Test
    public void testGetCoreModelVersion() {
        coreModel.setup();
        coreModel.getCoreModelVersion();
    }
}
