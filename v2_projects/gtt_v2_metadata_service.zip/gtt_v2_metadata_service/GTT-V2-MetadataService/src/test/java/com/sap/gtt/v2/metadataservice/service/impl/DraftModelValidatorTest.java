/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.gtt.v2.metadataservice.service.impl;

import com.sap.gtt.v2.metadataservice.exception.ManageModelsServiceValidationException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

import com.sap.gtt.v2.metadataservice.service.MetadataManageModelsService;
import org.apache.commons.io.IOUtils;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.core.io.ClassPathResource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 *
 * @author I326335
 */
@RunWith(SpringJUnit4ClassRunner.class)
public class DraftModelValidatorTest {

    @Mock
    private MetadataManageModelsService metadataManageModelsService;

    public DraftModelValidatorTest() {
    }

    @Test
    public void testValidate() throws IOException {
        String modelJson = getJson("DraftModel.json");
        DraftModelValidator validator = new DraftModelValidator();
        validator.validate(modelJson);
    }

    @Test
    public void testValidateWithWrongEventTypeSwitchOff() throws IOException {
        String modelJson = getJson("draftWrongEventTypeSwitchOff.json");
        DraftModelValidator validator = new DraftModelValidator();
        validator.validate(modelJson);
    }

    @Test
    public void testValidateWithWrongEventTypeSwitchOn() throws IOException {
        String modelJson = getJson("draftWrongEventTypeSwitchOn.json");
        DraftModelValidator validator = new DraftModelValidator();
        validateException(validator, modelJson, "[\"#/customModel/subModels/0/processTypes/0/admissiblePlannedEvents/0/idocMapping/idoc: expected type: String, found: Boolean\",\"#/customModel/subModels/0/eventTypes/0/idocMapping/idoc: expected type: String, found: Boolean\"]");
    }

    @Test
    public void testValidateWithWrongDPPException() throws IOException {
        String modelJson = getJson("InvalidDraftModel.json");
        DraftModelValidator validator = new DraftModelValidator();
        validateException(validator, modelJson, "[\"#/customModel/subModels/0/processTypes/0/admissiblePlannedEvents/0/businessToleranceValue: expected type: Number, found: String\",\"#/customModel/subModels/0/processTypes/0/elements/1/dpp/0: datasubjectid1 is not a valid enum value\",\"#/customModel/subModels/0/processTypes/0/name: string [TrackedProcess] does not match pattern ^(?!(?i)(TrackedProcess$)(?-i))[a-zA-Z]+[a-zA-Z0-9]*$\"]");
    }


    @Test
    public void testValidateWithWrongDPPException1() throws IOException {
        String modelJson = getJson("InvalidDraftModel1.json");
        DraftModelValidator validator = new DraftModelValidator();
        validateException(validator, modelJson, "[\"#/customModel/subModels/0/processTypes/0/elements/1/dpp: expected maximum item count: 2, found: 3\"]");
    }

    @Test
    public void testValidateWithProcessNotUniqueException() throws IOException {
        String modelJson = getJson("InvalidDraftModel2.json");
        DraftModelValidator validator = new DraftModelValidator();
        validateException(validator, modelJson, "Process type: FreightOrderProcess1 cannot be defined in sub model. Process type should be unique in sub model.");
    }

    @Test
    public void testValidateWithCompositionException() throws IOException {
        String modelJson = getJson("InvalidDraftModel3.json");
        DraftModelValidator validator = new DraftModelValidator();
        validateException(validator, modelJson, "[\"#/customModel/subModels/0/processTypes/0/elements/2: required key [target] not found\"]");
    }

    @Test
    public void testValidateWithWrongTypeException() throws IOException {
        String modelJson = getJson("InvalidDraftModel4.json");
        DraftModelValidator validator = new DraftModelValidator();
        validateException(validator, modelJson, "[\"#/customModel/subModels/0/processTypes/0/elements/2/type: composition1 is not a valid enum value\"]");
    }

    @Test
    public void testValidateWithDuplicatedEntityName() throws IOException {
        String modelJson = getJson("InvalidDraftModel5.json");
        DraftModelValidator validator = new DraftModelValidator();
        validateException(validator, modelJson, "Name: OriginalDocument should be unique.");
    }

    @Test
    public void testValidateWithDuplicatedSubModelName() throws IOException {
        String modelJson = getJson("InvalidDraftModel6.json");
        DraftModelValidator validator = new DraftModelValidator();
        validateException(validator, modelJson, "Sub model name: FreightOrderModel should be unique.");
    }

    @Test
    public void testValidateWithDuplicatedFieldName() throws IOException {
        String modelJson = getJson("InvalidDraftModel7.json");
        DraftModelValidator validator = new DraftModelValidator();
        validateException(validator, modelJson, "Field name: freightOrderId is duplicated.");
    }
    @Test
    public void testIdocValidateSwitchOff() throws IOException {
        String modelJson = getJson("InvaliddraftModelWithIdocSwitchOff.json");
        DraftModelValidator validator = new DraftModelValidator();
        validator.validate(modelJson);
    }
    @Test
    public void testIdocValidateSwitchOn() throws IOException {
        String modelJson = getJson("InvaliddraftModelWithIdocSwitchOn.json");
        DraftModelValidator validator = new DraftModelValidator();
        validateException(validator, modelJson, "[\"#/customModel/subModels/0/processTypes/0/idocMapping/applicationObjectType: string [123] does not match pattern ^[a-zA-Z]+[a-zA-Z0-9_]*$\"]");
    }
    @Test
    public void testIdocValidateSwitchOnWithWrongField() throws IOException {
        String modelJson = getJson("InvalidDraftModel18.json");
        DraftModelValidator validator = new DraftModelValidator();
        validateException(validator, modelJson, "Field field: originalDocuments1 is not defined.");
    }
    @Test
    public void testIdocValidateSwitchOnWithWrongField2() throws IOException {
        String modelJson = getJson("InvalidDraftModel16.json");
        DraftModelValidator validator = new DraftModelValidator();
        validateException(validator, modelJson, "Field field: number1 is not defined.");
    }
    @Test
    public void testIdocValidateSwitchOnWithWrongTarget() throws IOException {
        String modelJson = getJson("InvalidDraftModel17.json");
        DraftModelValidator validator = new DraftModelValidator();
        validateException(validator, modelJson, "Field target: FreightOrderModel.OriginalDocument1 is not defined.");
    }

    @Test
    public void testValidateWithWrongTarget() throws IOException {
        String modelJson = getJson("InvalidDraftModel8.json");
        DraftModelValidator validator = new DraftModelValidator();
        validateException(validator, modelJson, "Field target: FreightOrderModel.OriginalDocument1 is not defined.");
    }

    @Test
    public void testValidateWithConflictDPP() throws IOException {
        String modelJson = getJson("InvalidDraftModel9.json");
        DraftModelValidator validator = new DraftModelValidator();
        validateException(validator, modelJson, "DPP annotation PII and SPI cannot be defined at the same time.");
    }

    @Test
    public void testValidateWithWrongKey() throws IOException {
        String modelJson = getJson("InvalidDraftModel10.json");
        DraftModelValidator validator = new DraftModelValidator();
        validateException(validator, modelJson, "Field number: key field. Readable, writable and required property must be true.");
    }

    @Test
    public void testValidateWithNotExistedKey() throws IOException {
        String modelJson = getJson("InvalidDraftModel13.json");
        DraftModelValidator validator = new DraftModelValidator();
        validateException(validator, modelJson, "Key field does not exist in entity Stops.");
    }

    @Test
    public void testValidateWithExistedKey() throws IOException {
        String modelJson = getJson("InvalidDraftModel14.json");
        DraftModelValidator validator = new DraftModelValidator();
        validateException(validator, modelJson, "Key field cannot be defined in entity FreightOrderProcess.");
    }

    private void validateException(DraftModelValidator validator, String modelJson, String message) {
        try {
            validator.validate(modelJson);
            fail("validation failed.");
        } catch (ManageModelsServiceValidationException e) {
            System.out.println(e.getMessage());
            assertEquals(message, e.getMessage());
        }
    }

    private String getJson(String jsonPath) throws IOException {
        ClassPathResource resource = new ClassPathResource("mmpayloads/" + jsonPath);
        try (InputStream inputStream = resource.getInputStream()) {
            return IOUtils.toString(inputStream, StandardCharsets.UTF_8);
        } catch (IOException ex) {
            throw ex;
        }
    }
}
