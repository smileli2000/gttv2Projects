package com.sap.gtt.v2.metadataservice.utils;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.context.MessageSource;
import org.springframework.context.MessageSourceResolvable;
import org.springframework.context.NoSuchMessageException;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import java.util.Locale;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ActiveProfiles("test")
public class CoreFieldLabelTranslationUtilTest {


    MessageSource messageSource = new MessageSource() {
        @Override
        public String getMessage(String s, Object[] objects, String s1, Locale locale) {
            return null;
        }

        @Override
        public String getMessage(String s, Object[] objects, Locale locale) throws NoSuchMessageException {
            return "test";
        }

        @Override
        public String getMessage(MessageSourceResolvable messageSourceResolvable, Locale locale) throws NoSuchMessageException {
            return null;
        }
    };

    @Test
    public void generateCoreFieldLabelTranslationTest(){

        String coreModelString = FileHelper.loadResourceFileAsString("CoreModelTest.json");
        CoreFieldLabelTranslationUtil.generateCoreFieldLabelTranslation(coreModelString,messageSource);
    }

}
