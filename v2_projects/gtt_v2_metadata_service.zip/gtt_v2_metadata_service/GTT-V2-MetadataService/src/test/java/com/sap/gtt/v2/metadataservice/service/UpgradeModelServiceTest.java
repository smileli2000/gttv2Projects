package com.sap.gtt.v2.metadataservice.service;

import com.sap.gtt.v2.configuration.ISAPCloudPlatformAgent;
import com.sap.gtt.v2.core.entity.metadata.MetadataProject;
import com.sap.gtt.v2.core.management.metadata.IMetadataManagement;
import com.sap.gtt.v2.log.TenantAwareLogService;
import com.sap.gtt.v2.metadataservice.service.impl.MetadataProjectExtractor;
import com.sap.gtt.v2.servicemanager.GTTInstance;
import com.sap.gtt.v2.util.GTTUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ResourceLoader;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;

@RunWith(MockitoJUnitRunner.class)
public class UpgradeModelServiceTest {
    @InjectMocks
    private UpgradeModelService upgradeModelService = new UpgradeModelService(mock(GTTInstance.class));

    @Mock
    private ISAPCloudPlatformAgent.ICurrentAccessContext currentAccessContext;
    @Mock
    private IMetadataManagement metadataManagement;
    @Mock
    GTTUtils.BusinessOperator businessOperator;
    @Mock
    private TenantAwareLogService logService;
    @Mock
    private GTTInstance gttInstance;
    @Mock
    private CoreModel coreModel;
    @Mock
    private MetadataProjectExtractor extractor;
    @Mock
    private MetadataProjectService metadataProjectService;
    @Autowired
    private ResourceLoader resourceLoader;


    @Before
    public void setup() {
        given(currentAccessContext.createBusinessOperator()).willReturn(businessOperator);
        given(currentAccessContext.createBusinessOperator().getMetadataManagement()).willReturn(metadataManagement);

    }

    @Test
    public void testExecute() {
        upgradeModelService.execute(null);
    }

    @Test
    public void testExecuteWithMetadataProjectInfo() {
        List<MetadataProject> metadataProjects = new ArrayList();
        MetadataProject metadataProject = new MetadataProject();
        metadataProjects.add(metadataProject);
        Mockito.when(metadataManagement.findAllMetadataProject()).thenReturn(metadataProjects);
        upgradeModelService.execute(null);
    }

    @Test
    public void testExecuteWithNamespace() {
        String namespace = "com.sap.app.test1";
        upgradeModelService.execute(namespace);
    }

    @Test
    public void testExecuteWithNamespaceWithMedataProjectInfo() {
        String namespace = "com.sap.app.test1";
        List<MetadataProject> metadataProjects = new ArrayList();
        MetadataProject metadataProject = new MetadataProject();
        metadataProjects.add(metadataProject);
        Mockito.when(metadataManagement.findMetadataProjectInfoByNamespace(anyString())).thenReturn(metadataProjects);
        upgradeModelService.execute(namespace);
    }

    @Test
    public void testExecuteWithMetadataByte() throws IOException {
        byte[] zipByte = "test".getBytes();
        upgradeModelService.executeRetry(zipByte, null);
    }

}
