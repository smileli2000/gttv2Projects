package com.sap.gtt.v2.metadataservice.utils;

import org.apache.commons.io.IOUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.io.IOException;
import java.nio.charset.Charset;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;


@RunWith(SpringJUnit4ClassRunner.class)
public class SwagerTransformUtilTest {

    @Before
    public void setup() {

    }

    @Test
    public void testSwaggerConvert() throws IOException {
        String edmxFileName = "edmxWithoutAnnotation.xml";
        String annotationFileName = "annotation.xml";
        String edmxFileContent = getFileContent(edmxFileName);
        String annotationFileContent = getFileContent(annotationFileName);
        String test = TransformUtil.transfromEdmxToSwagger(annotationFileContent, edmxFileContent);
        assertNotNull(test);
    }

//    @Test
//    public void testSwaggerConvertWithConvertedEdxm() throws IOException {
//        String edmxFileName = "edmxWithAnnotation.xml";
//        String edmxFileContent = getFileContent(edmxFileName);
//        String test = TransformUtil.transfromEdmxToSwagger(edmxFileContent);
//        assertNotNull(test);
//    }


    @Test
    public void testSwaggerConvertWithOriginalEdxm() throws IOException {
        String edmxFileName = "edmxWithoutAnnotation.xml";
        String edmxFileContent = getFileContent(edmxFileName);
        String test = TransformUtil.transfromEdmxToSwagger(edmxFileContent);
        assertNotNull(test);
    }

    private String getFileContent(String edmxFileName) {
        String edmxFile = "";
        try {
            edmxFile = IOUtils.toString(JsonModelConverter.class.getClassLoader()
                    .getResourceAsStream(edmxFileName), Charset.defaultCharset());
        } catch (IOException e) {
            fail("JsonModel load failed !");
        }
        return edmxFile;
    }


}
