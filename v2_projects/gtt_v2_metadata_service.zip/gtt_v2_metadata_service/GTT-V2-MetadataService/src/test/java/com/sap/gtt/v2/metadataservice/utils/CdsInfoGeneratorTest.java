package com.sap.gtt.v2.metadataservice.utils;

import org.apache.commons.io.IOUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.Map;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

@RunWith(SpringJUnit4ClassRunner.class)
public class CdsInfoGeneratorTest {

    @Before
    public void setup() {

    }

    @Test
    public void testGenerateCdsWithoutCodeList() {
//        DraftModelValidator draftModelValidator = new DraftModelValidator();
//        draftModelValidator.validate(jsonModel);
        String JSON_MODEL_CONVERTER = "draftModel.json";
        String jsonModel = getDraftModel(JSON_MODEL_CONVERTER);
        Map<String, String> cdsInfo = CdsInfoGenerator.generateCdsModelInfo(jsonModel);
        assertNotNull(cdsInfo);
    }

    @Test
    public void testGenerateCdsWithCodeList() {
        String JSON_MODEL_CONVERTER = "draftModel2.json";
        String jsonModel = getDraftModel(JSON_MODEL_CONVERTER);
        Map<String, String> cdsInfo = CdsInfoGenerator.generateCdsModelInfo(jsonModel);
        assertNotNull(cdsInfo);

    }

    @Test
    public void testAssociation() {
        String JSON_MODEL_CONVERTER = "draftModel3.json";
        String jsonModel = getDraftModel(JSON_MODEL_CONVERTER);
        Map<String, String> cdsInfo = CdsInfoGenerator.generateCdsModelInfo(jsonModel);
        assertNotNull(cdsInfo);
    }

    @Test
    public void testGenerateCdsWithTwoModelsItemTypes() {
        String JSON_MODEL_CONVERTER = "draftModel4.json";
        String jsonModel = getDraftModel(JSON_MODEL_CONVERTER);
        Map<String, String> cdsInfo = CdsInfoGenerator.generateCdsModelInfo(jsonModel);
        assertNotNull(cdsInfo);

    }


    @Test
    public void testGenerateCdsWithEmptyElements() {
        String JSON_MODEL_CONVERTER = "draftModel5.json";
        String jsonModel = getDraftModel(JSON_MODEL_CONVERTER);
        Map<String, String> cdsInfo = CdsInfoGenerator.generateCdsModelInfo(jsonModel);
        assertNotNull(cdsInfo);
    }


    @Test
    public void testGenerateCdsWithTwoSubModels() {
        String JSON_MODEL_CONVERTER = "draftModel6.json";
        String jsonModel = getDraftModel(JSON_MODEL_CONVERTER);
        Map<String, String> cdsInfo = CdsInfoGenerator.generateCdsModelInfo(jsonModel);
        /*ByteArrayOutputStream zip = ZipFileGenerator.zip(cdsInfo);
        FileOutputStream fileOutputStream = new FileOutputStream("C:/Users/I069899/Desktop/tmp/ttw.zip");
        fileOutputStream.write(zip.toByteArray());
        fileOutputStream.close();
         */
        assertNotNull(cdsInfo);

    }


    
    @Test
    public void testGenerateCdsWithPlannedEventExtesion()  {
        String JSON_MODEL_CONVERTER = "draftModel7.json";
        String jsonModel = getDraftModel(JSON_MODEL_CONVERTER);
        Map<String, String> cdsInfo = CdsInfoGenerator.generateCdsModelInfo(jsonModel);
        assertNotNull(cdsInfo);

    }

    @Test
    public void testGenerateCdsWithPlannedEventExtesion2()  {
        String JSON_MODEL_CONVERTER = "draftModel8.json";
        String jsonModel = getDraftModel(JSON_MODEL_CONVERTER);
        Map<String, String> cdsInfo = CdsInfoGenerator.generateCdsModelInfo(jsonModel);
        assertNotNull(cdsInfo);

    }

    @Test
    public void testModelDescAndProcessDesc()  {
        String JSON_MODEL_CONVERTER = "draftModel9.json";
        String jsonModel = getDraftModel(JSON_MODEL_CONVERTER);
        Map<String, String> cdsInfo = CdsInfoGenerator.generateCdsModelInfo(jsonModel);
        assertNotNull(cdsInfo);
    }

    @Test
    public void testAuthScope()  {
        String JSON_MODEL_CONVERTER = "draftModel9.json";
        String jsonModel = getDraftModel(JSON_MODEL_CONVERTER);
        Map<String, String> cdsInfo = CdsInfoGenerator.generateCdsModelInfo(jsonModel);
        assertNotNull(cdsInfo);
    }

    private String getDraftModel(String draftModelName) {
        String jsonModel = "";
        try {
            jsonModel = IOUtils.toString(JsonModelConverter.class.getClassLoader()
                    .getResourceAsStream(draftModelName), Charset.defaultCharset());
        } catch (IOException e) {
            fail("JsonModel load failed !");
        }

        return jsonModel;
    }

}
