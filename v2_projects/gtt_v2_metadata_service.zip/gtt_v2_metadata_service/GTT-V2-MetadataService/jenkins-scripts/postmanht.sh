#!/bin/bash
set -ex

echo " run postman testing"
#just add your script here

testscript_01='GTT_V2_Model_CleanUp.postman_collection.json';
testEnvfile_01='GTT_V2_Model_CleanUp_Hotfix.postman_environment.json';

testscript_02='GTT_V2_Model_Deployment.postman_collection.json';
testEnvfile_02='GTT_V2_Model_Deployment_Hotfix.postman_environment.json';

testscript_03='GTT_V2_MetaData_Service_Integration_Test.postman_collection.json';
testEnvfile_03='GTT_V2_MetaData_Service_Integration_Test_Hotfix.postman_environment.json';

newman run jenkins-scripts/${testscript_01} -e  jenkins-scripts/${testEnvfile_01} --delay-request 5000 -r cli,junit  --reporter-junit-export jenkins-scripts/postman-collection.xml --reporter-html-export jenkins-scripts/postman-collection-index.html   --reporter-html-export target/index.html --reporter-junit-export target/surefire-reports/junit_report.xml

newman run jenkins-scripts/${testscript_02} -e  jenkins-scripts/${testEnvfile_02} --delay-request 5000 -r cli,junit  --reporter-junit-export jenkins-scripts/postman-collection.xml --reporter-html-export jenkins-scripts/postman-collection-index.html   --reporter-html-export target/index.html --reporter-junit-export target/surefire-reports/junit_report.xml

newman run jenkins-scripts/${testscript_03} -e  jenkins-scripts/${testEnvfile_03} --delay-request 5000 -r cli,junit  --reporter-junit-export jenkins-scripts/postman-collection.xml --reporter-html-export jenkins-scripts/postman-collection-index.html   --reporter-html-export target/index.html --reporter-junit-export target/surefire-reports/junit_report.xml
echo " all testing are done!"



