/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.iot.gtt.metering.exception;

import java.io.IOException;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author I326335
 */
public class GTTMeteringExceptionTest {
    
    public GTTMeteringExceptionTest() {
    }

    @Test
    public void testSomeMethod() {
        GTTMeteringException exception = new GTTMeteringException("test");
        assertNotNull(exception);
        exception = new GTTMeteringException("test", new IOException());
        assertNotNull(exception);
    }
    
}
