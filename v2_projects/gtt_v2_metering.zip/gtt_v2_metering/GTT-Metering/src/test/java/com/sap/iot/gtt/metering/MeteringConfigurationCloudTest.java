/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.iot.gtt.metering;

import com.google.gson.JsonPrimitive;
import com.sap.iot.gtt.metering.service.util.Util;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

import com.sap.iot.gtt.metering.util.KafkaUtils;
import org.apache.commons.io.IOUtils;
import org.junit.Assert;
import org.junit.Test;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

/**
 *
 * @author I326335
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest(KafkaUtils.class)
public class MeteringConfigurationCloudTest {

    private String jsonVCAPServices;
    private String jsonVCAPApplication;
    private String organizationId;
    private String opsAppUrl;
    private MeteringConfiguration config;

    @Before
    public void setUp() throws IOException {
        jsonVCAPServices = IOUtils.toString(Util.readClassPathResourceAsStream("json/vcap_services.json"), StandardCharsets.UTF_8);
        jsonVCAPApplication = IOUtils.toString(Util.readClassPathResourceAsStream("json/vcap_application.json"), StandardCharsets.UTF_8);
        config = new MeteringConfigurationCloud(jsonVCAPServices, jsonVCAPApplication, organizationId, opsAppUrl);
        organizationId = "testOrg";
        opsAppUrl = "https://ops-app-url.cfapps.sap.hana.ondemand.com";

        PowerMockito.mockStatic(KafkaUtils.class);

        String token = "Abcd1234";
        String username = "sbss_vfd5lrl7byi+di9oieyuylxqcxcq3do9fav9pm1njmmafirleaebzqpb5fsrto4exvm=";
        String jaasConfigString = String.format(KafkaUtils.JAAS_CONFIG_TEMPLATE, username, token);
        Mockito.when(KafkaUtils.getToken(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(token);
        Mockito.when(KafkaUtils.buildJaasConfigString(Mockito.anyString(), Mockito.anyString())).thenReturn(jaasConfigString);

    }

    public MeteringConfigurationCloudTest() {
    }

    @Test
    public void testConfigurationCloudNewWhithoutParam() throws IOException {
        MeteringConfiguration config = new MeteringConfigurationCloud();
        assertEquals(config.getCassandraUser(), null);
    }

    @Test
    public void testConfigurationCassandra() throws IOException {
        MeteringConfiguration config = new MeteringConfigurationCloud(jsonVCAPServices, jsonVCAPApplication, organizationId, opsAppUrl);
        assertEquals(config.getCassandraUser(), "sbss_username");
        assertEquals(config.getCassandraPassword(), "pwd");
        assertEquals(5, config.getCassandraHosts().split(",").length);
        assertEquals("9876", config.getCassandraPort().toString());
        assertEquals(true, config.isCassandraSslEnabled());
    }

    @Test
    public void testConfigurationKafka() throws IOException {
        MeteringConfiguration config = new MeteringConfigurationCloud(jsonVCAPServices, jsonVCAPApplication, organizationId, opsAppUrl);
        assertNotNull(config.getKafkaProducerConfig());
        assertNotNull(config.getKafkaConsumerConfig());
        assertNotNull(config.getKafkaConfig());
        assertNotNull(config.getZooKeeperConfig());
        assertEquals("sbss_username", config.getKafkaUsername());
        assertEquals("pwd", config.getKafkaPassword());
        assertEquals("https://kafka-service.cf.eu10.hana.ondemand.com/v1/12345678-7fbb-4b33-9564-83004241a1d7", config.getKafkaServieUrl());
    }

    @Test
    public void testConfigurationElasticSearch() throws IOException {
        MeteringConfiguration config = new MeteringConfigurationCloud(jsonVCAPServices, jsonVCAPApplication, organizationId, opsAppUrl);
        assertNotNull(config.getAccessKeyID());
        assertNotNull(config.getSecretAccessKey());
        assertNull(config.getProxyHost());
        assertEquals(0, config.getProxyPort());
        assertNull(config.getElasticSearchHost());
        assertNotNull(config.getAwsEndPoint());
        assertNotNull(config.getAwsSignerRegion());
        assertNotNull(config.getRoleArn());
        assertNotNull(config.getESPortForRest());
        assertNotNull(config.getNeedAWSSign());
        assertNotNull(config.getKafkaNrOfReplication());
        assertNotNull(config.getCf_api());
        assertNotNull(config.getSecureTenant());
        assertNotNull(config.getScheduleCron());
        assertNotNull(config.getHanaDataSource());
        assertNotNull(config.getHanaSchema());

    }

    @Test
    public void testConfigurationMisc() throws IOException {
        assertEquals("5c853c6d-4b10-4f65-a414-1719d429f418", config.getSpace_id());
        assertEquals("TnT_Integration", config.getSpace_name());
        assertEquals("tt_integration!t1", config.getXSAppname());
        assertEquals("https://sap-iotas.authentication.sap.hana.ondemand.com", config.getPaasAuthUrl());
        assertEquals("sb-tt_integration!t1", config.getClientid());
        assertEquals("client-secret", config.getClientsecret());
    }
    
    @Test
    public void testConfiguration4MeteringService() throws IOException {
        assertEquals("sb-12345678-1d3a-40ad-9b38-a41d9a65e9cb!b6660|metering!b4066", config.getMeteringServiceClientId());
        assertEquals("abcdefgoZQeoBxw6IX5oWFOy/sE=", config.getMeteringServiceClientSecret());
        assertEquals("cf-eu10-canary", config.getMeteringServiceRegion());
        assertEquals("https://lbn-platform-test.authentication.sap.hana.ondemand.com", config.getMeteringServiceTokenUrl());
        assertEquals("https://maas-metering.cfapps.sap.hana.ondemand.com/usage/v2/usage/documents", config.getMeteringServiceUrl());
    }

}
