/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.iot.gtt.metering.service.impl;

import com.datastax.driver.core.*;
import com.datastax.driver.core.querybuilder.Select;
import com.sap.iot.gtt.metering.MeteringConfiguration;
import com.sap.iot.gtt.metering.MeteringConnection;
import com.sap.iot.gtt.metering.util.OAuthToken;
import com.sap.iot.gtt.metering.util.WebClientUtil;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import javax.ws.rs.core.Response.ResponseBuilder;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Answers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 *
 * @author I326335
 */
@RunWith(SpringJUnit4ClassRunner.class)
public class CassandraImplTest {
    @MockBean
    private MeteringConnection connection;
    @MockBean
    private MeteringConfiguration configuration;
    
    @Mock
    private OAuthToken oauthToken;
    @Mock
    private WebClientUtil webClientUtil;
    @Mock
    private Cluster cluster;
    @Mock
    private Session session;
    @Mock
    private Row row;
    @Mock(answer=Answers.RETURNS_DEEP_STUBS)
    private ResultSet resultSet;
    @Mock
    private PreparedStatement prepareStatement;
    @Mock
    private BoundStatement boundStatement;
    @InjectMocks
    private CassandraImpl cassandra;
    
    private ResponseBuilder responseBuilder;
    
    @Before
    public void setup() throws Exception {
    	MockitoAnnotations.initMocks(this);
    	when(configuration.getClientid()).thenReturn("client-id");
    	when(configuration.getClientsecret()).thenReturn("client-secret");
    	when(configuration.getOpsAppUrl()).thenReturn("https://ops-app-base-url");
    	when(configuration.getXSAppname()).thenReturn("tt_integration!t1234");
    	when(configuration.getPaasAuthUrl()).thenReturn("https://pass-auth-base-url");
    	when(configuration.getCassandraHosts()).thenReturn("ip1,ip2,ip3,ip4,ip5");
    	when(configuration.getCassandraUser()).thenReturn("c*-user");
    	when(configuration.getCassandraPassword()).thenReturn("c*-pwd");
    	when(configuration.getCassandraPort()).thenReturn(1234);
    	when(oauthToken.getToken(any(), any(), any(), any(), any())).thenReturn("Bearer token");
    	
		String okResponse = "{\"tenantShortID\": \"tenant-short-id\"}";
		responseBuilder = javax.ws.rs.core.Response.status(200);
		javax.ws.rs.core.Response resp = responseBuilder.entity(okResponse).build();
    	when(webClientUtil.get(any(), any())).thenReturn(resp);
    	
        //Row mockRow = Mockito.mock(Row.class);
        //ResultSet mockResultSet = Mockito.mock(ResultSet.class);
        //PreparedStatement mockPreparedStatement = Mockito.mock(PreparedStatement.class);
        //BoundStatement mockBoundStatement = Mockito.mock(BoundStatement.class);


        when(row.getString(anyInt())).thenReturn("111");
        when(row.getString(anyString())).thenReturn("UfGU53RvEv8ff2y7");
        when(row.getLong(anyInt())).thenReturn(Long.valueOf(1024*1024));
        
        when(resultSet.isExhausted()).thenReturn(false);
        when(resultSet.one()).thenReturn(row);
        
        when(prepareStatement.setConsistencyLevel(ConsistencyLevel.LOCAL_ONE)).thenReturn(prepareStatement);
        when(prepareStatement.bind()).thenReturn(boundStatement);
        when(boundStatement.setString(anyInt(), anyString())).thenReturn(boundStatement);
        
        when(connection.createCassandraCluster()).thenReturn(cluster);
        when(cluster.connect()).thenReturn(session);
        when(session.prepare(any(Select.class))).thenReturn(prepareStatement);
        when(session.execute(boundStatement)).thenReturn(resultSet);
    }

    @Test
    public void testGetSpaceSize() throws Exception {
        assertEquals("1048576", cassandra.getSpaceSize("devsandbox"));
    }

}
