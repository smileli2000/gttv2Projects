/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.iot.gtt.metering.util;

import com.sap.iot.gtt.metering.MeteringConfiguration;
import com.sap.iot.gtt.metering.MeteringConnection;
import com.sap.iot.gtt.metering.exception.GTTMeteringException;
import kafka.admin.AdminUtils;
import kafka.javaapi.TopicMetadata;
import kafka.utils.ZkUtils;
import org.I0Itec.zkclient.ZkClient;
import org.I0Itec.zkclient.ZkConnection;
import org.apache.kafka.common.requests.MetadataResponse;

/**
 *
 * @author I326335
 */
public class KafkaTopicHelper {

    ZkClient zkClient;
    MeteringConfiguration configuration;

    public KafkaTopicHelper(MeteringConnection connection, MeteringConfiguration configuration) throws GTTMeteringException {
        try {
            this.configuration = configuration;
            zkClient = connection.createZooKeeperClient();
        } catch (GTTMeteringException ex) {
            throw new GTTMeteringException("ZooKeeperClient creating failed.", ex);
        }
    }

    public boolean checkAndDeleteTopic(String topic) {
        boolean isSecureKafkaCluster = false;

        // https://kafka.apache.org/documentation.html#topic-config
        ZkUtils zkUtils = new ZkUtils(zkClient, new ZkConnection(configuration.getZooKeeperConfig()), isSecureKafkaCluster);

        if (AdminUtils.topicExists(zkUtils, topic)) {
            //MetadataResponse.TopicMetadata topicMetadata = AdminUtils.fetchTopicMetadataFromZk(topic, zkUtils);
            //System.out.println(topicMetadata.partitionMetadata());
//            AdminUtils.deleteTopic(zkUtils, topic);
            zkClient.deleteRecursive(ZkUtils.getTopicPath(topic));
            return true;
        }

        return false;
    }

    public void close() {
        zkClient.close();
    }

}
