package com.sap.iot.gtt.metering.util;

import com.google.common.collect.Lists;
import com.google.common.io.Files;
import kafka.server.KafkaConfig;
import kafka.server.KafkaServerStartable;
import org.apache.curator.test.InstanceSpec;
import org.apache.curator.test.TestingServer;
import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.AdminClientConfig;
import org.apache.kafka.clients.admin.CreateTopicsResult;
import org.apache.kafka.clients.admin.NewTopic;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.config.SaslConfigs;
import org.apache.kafka.common.config.SslConfigs;
import org.junit.rules.ExternalResource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.TimeUnit;


public class KafkaUnitRule extends ExternalResource {

    private Logger logger = LoggerFactory.getLogger(KafkaUnitRule.class);

    private static final String PROPERTY_KAFKA_CLIENT_TRUSTSTORE_FILE_NAME = "kafka.client.truststore.file.name";

    private static final String PROPERTY_KAFKA_CLIENT_TRUSTSTORE_PASSWORD = "kafka.client.truststore.password";

    private static final String PROPERTY_KAFKA_CLIENT_USERNAME = "kafka.client.username";
    private static final String PROPERTY_KAFKA_CLIENT_PASSWORD = "kafka.client.password";

    private static KafkaServerStartable kafkaServer;
    private static TestingServer zkServer;
    private static int kafkaPort;

    private File kafkaLogDirectory;
    private AdminClient adminClient;
    private KafkaProducer<byte[], byte[]> kafkaProducer;

    private Map<String, String> kafkaConnectConfig = new HashMap<>();

    public KafkaUnitRule(){

    }

    public String getZkUrl() {
        return zkServer.getConnectString();
    }

    @Override
    protected void before() throws Throwable {

        Properties props = loadProperties();

        String kafkaJaasPath = copyToTempFile("kafka_jaas.conf", "temp_kafka_jaas",
            ".conf").toAbsolutePath().toString();

        System.setProperty("java.security.auth.login.config", kafkaJaasPath);

        // Set up Zookeeper to require SASL
        Map<String,Object> zookeeperProperties = new HashMap<>();

        zookeeperProperties.put("authProvider.1", "org.apache.zookeeper.server.auth.SASLAuthenticationProvider");
        zookeeperProperties.put("requireClientAuthScheme", "sasl");
        zookeeperProperties.put("jaasLoginRenew", "3600000");

        InstanceSpec instanceSpec = new InstanceSpec(null, -1, -1, -1,
            true, 1,-1, -1, zookeeperProperties);

        zkServer = new TestingServer(instanceSpec, true);

        logger.info("Zookeeper server started");

        // Get a random kafkaPort
        kafkaPort = TestUtils.randomTCPPort(1025, 60535);

        final Properties brokerProps = new Properties();
        brokerProps.put("broker.id", 1);
        brokerProps.put("host.name", "localhost");
        brokerProps.put("kafkaPort", kafkaPort);
        kafkaLogDirectory = Files.createTempDir();
        brokerProps.put("log.dir", kafkaLogDirectory.getAbsolutePath());
        brokerProps.put("zookeeper.connect", zkServer.getConnectString());
        brokerProps.put("replica.socket.timeout.ms", "1500");
        brokerProps.put("request.timeout.ms", 3000);
        brokerProps.put("controlled.shutdown.enable", Boolean.TRUE.toString());
        // Enable SASL_PLAINTEXT
        brokerProps.put("listeners", "SASL_SSL://localhost:" + kafkaPort);
        brokerProps.put("security.inter.broker.protocol", "SASL_SSL");

        brokerProps.put(SaslConfigs.SASL_ENABLED_MECHANISMS, "PLAIN");
        brokerProps.put("sasl.mechanism.inter.broker.protocol", "PLAIN");
        brokerProps.put("advertised.listeners", "SASL_SSL://localhost:" + kafkaPort);
        brokerProps.put("offsets.topic.replication.factor", "1");
        brokerProps.put("log.segment.delete.delay.ms", 2000);
        brokerProps.put("log.retention.check.interval.ms", 2000);
        brokerProps.put("log.roll.ms", 2000);

        String brokerKeystorePath = copyToTempFile("kafka-broker-keystore.jks", "temp-kafka-broker-keystore",
            ".jks").toAbsolutePath().toString();
        String brokerTruststorePath = copyToTempFile("kafka-broker-truststore.jks", "temp-kafka-broker-turststore",
                ".jks").toAbsolutePath().toString();
        brokerProps.put(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG, brokerKeystorePath);
        brokerProps.put(SslConfigs.SSL_KEY_PASSWORD_CONFIG, "Broker1234");
        brokerProps.put(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG, "Broker1234");

        brokerProps.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, brokerTruststorePath);
        brokerProps.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, "Broker1234");
        //props.put("auto.create.topics.enable", "true");

        // Plug in Apache Ranger authorizer
        //props.put("authorizer.class.name", "kafka.security.auth.SimpleAclAuthorizer");
        brokerProps.put(" allow.everyone.if.no.acl.found", "true");

        KafkaConfig config = new KafkaConfig(brokerProps);
        kafkaServer = new KafkaServerStartable(config);
        kafkaServer.startup();

        logger.info("Kafka server started at {}", kafkaPort);

        Properties adminClientProps = new Properties();
        adminClientProps.put(AdminClientConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:" + kafkaPort);
        adminClientProps.put(SaslConfigs.SASL_MECHANISM, "PLAIN");
        adminClientProps.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, "SASL_SSL");

        String clientTrustStorePath = copyToTempFile("kafka-client-truststore-local.jks", "temp-" + PROPERTY_KAFKA_CLIENT_TRUSTSTORE_FILE_NAME,
            ".jks").toAbsolutePath().toString();

        adminClientProps.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, clientTrustStorePath);
        adminClientProps.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG,
            props.getProperty(PROPERTY_KAFKA_CLIENT_TRUSTSTORE_PASSWORD));

        adminClientProps.put("sasl.jaas.config", KafkaUtils.buildJaasConfigString(
            props.getProperty(PROPERTY_KAFKA_CLIENT_USERNAME),
            props.getProperty(PROPERTY_KAFKA_CLIENT_PASSWORD)));

        adminClient = AdminClient.create(adminClientProps);

        logger.info("Admin client created");

        adminClientProps.forEach(
            (k, v) -> {
                kafkaConnectConfig.put((String)k, (String)v);
            }
        );

        // Create the Producer
        Properties producerProps = new Properties();
        producerProps.put("acks", "all");
        producerProps.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,
            "org.apache.kafka.common.serialization.ByteArraySerializer");
        producerProps.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,
            "org.apache.kafka.common.serialization.ByteArraySerializer");
        producerProps.put(SaslConfigs.SASL_MECHANISM, "PLAIN");
        producerProps.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, "SASL_SSL");
        producerProps.putAll(this.getKafkaConnectConfig());

        kafkaProducer = new KafkaProducer<>(producerProps);
    }

    @Override
    protected void after() {

        if (kafkaServer != null) {

            try {
                kafkaProducer.close(1, TimeUnit.SECONDS);
                logger.info("Kafka producer closed");
            } catch (Exception ex) {
                logger.info("Failed to close kafka producer", ex);
            }

            try {
                kafkaServer.shutdown();
                logger.info("Kafka server shutdown");
            } catch (Exception ex) {
                logger.info("Failed to shutdown Kafka server", ex);
            }
        }

        if (kafkaLogDirectory != null){
            try {
                TestUtils.delete(kafkaLogDirectory);
                logger.info("Kafka log directory deleted");
            } catch (Exception ex) {
                logger.error("Failed to delete Kafka log directory", ex);
            }
        }


        if (zkServer != null) {

            try {
                adminClient.close(1, TimeUnit.SECONDS);
                logger.info("Admin client closed");
            } catch (Exception ex) {
                logger.error("Failed to close admin client", ex);
            }

            File tempDirectory = zkServer.getTempDirectory();

            try {
                zkServer.stop();
                logger.info("Zookeeper server stopped");
            } catch (Exception ex) {
                logger.error("Failed to stop zookeeper server", ex);
            }
            try {
                TestUtils.delete(tempDirectory);
                logger.info("Temp directory created for Zookeeper server deleted");
            } catch (Exception ex) {
                logger.error("Failed to delete temp directory of Zookeeper server", ex);
            }
        }
    }

    public void createTopic(String name, int numPartitions, Map<String, String> topicConfig) throws Exception {
        // There is just one broker node. So replication factor is fixed to 1
        NewTopic newTopic = new NewTopic(name, numPartitions, (short)1);
        newTopic.configs(topicConfig);
        CreateTopicsResult result = adminClient.createTopics(Lists.newArrayList(newTopic));

        result.all().get();
    }

    public void sendMessage(String topic, byte[] key, byte[] message) throws Exception {
        kafkaProducer.send(new ProducerRecord<byte[], byte[]>(topic, key, message));
        kafkaProducer.flush();
    }

    public void sendMessage(String topic, int partition, byte[] key, byte[] message) throws Exception {
        kafkaProducer.send(new ProducerRecord<byte[], byte[]>(topic, partition, key, message));
        kafkaProducer.flush();
    }

    public int getKafkaPort(){
        return this.kafkaPort;
    }

    public AdminClient getAdminClient(){
        return this.adminClient;
    }

    public Map<String, String> getKafkaConnectConfig(){
        return kafkaConnectConfig;
    }

    public Properties loadProperties() throws IOException {
        Properties props = new Properties();
        try (InputStream input = getClass().getClassLoader().getResourceAsStream("config.properties")){
            props.load(input);
        }

        return props;
    }

    public Path copyToTempFile(String classpathResource, String name, String extension) throws IOException {

        Path tempFilePath = java.nio.file.Files.createTempFile(name, extension);

        java.nio.file.Files.copy(KafkaUnitRule.class.getClassLoader().getResource(classpathResource).openStream(),
            tempFilePath, StandardCopyOption.REPLACE_EXISTING);

        Runtime.getRuntime().addShutdownHook(
            new Thread(
                () -> {
                    try {
                        java.nio.file.Files.delete(tempFilePath);
                    } catch (IOException e) {
                        logger.error("Failed to delete temp file", e);
                    }
                }
            )
        );

        return tempFilePath;
    }
}