/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.iot.gtt.metering.service.impl;

import com.sap.iot.gtt.metering.MeteringConfiguration;
import com.sap.iot.gtt.metering.MeteringConfigurationCloud;
import com.sap.iot.gtt.metering.MeteringConnection;
import com.sap.iot.gtt.metering.service.KafkaReceiver;
import com.sap.iot.gtt.metering.service.util.Util;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;
import javax.ws.rs.core.MediaType;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.cxf.jaxrs.client.WebClient;
import org.apache.cxf.transport.http.HTTPConduit;
import org.apache.cxf.transports.http.configuration.HTTPClientPolicy;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;
import org.mockito.Mockito;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

/**
 *
 * @author I326335
 */
public class KafkaReceiverImplTest {

    private String jsonVCAPServices;
    private String jsonVCAPApplication;
    private String organizationId;
    private String opsAppUrl;

    @Before
    public void setUp() throws IOException {
        jsonVCAPServices = IOUtils.toString(Util.readClassPathResourceAsStream("json/vcap_services.json"), StandardCharsets.UTF_8);
        jsonVCAPApplication = IOUtils.toString(Util.readClassPathResourceAsStream("json/vcap_application.json"), StandardCharsets.UTF_8);
        organizationId = "testOrg";
    }

    public KafkaReceiverImplTest() {
    }

    //for local test
    //@Test
    public void testReceive() throws Exception {
        MeteringConfiguration configuration = new MeteringConfigurationCloud(jsonVCAPServices, jsonVCAPApplication, organizationId, opsAppUrl);
        //Mockito.spy(new MeteringConfigurationCloud(jsonVCAPServices, jsonVCAPApplication, organizationId));
        MeteringConnection connection = Mockito.spy(new MeteringConnection(configuration));

        String topic = Util.generateFullTopicName("gtt-devsandbox", configuration.getXSAppname());

        Map<String, Object> kafkaConsumerConfig = configuration.getKafkaConsumerConfig();
        kafkaConsumerConfig.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        kafkaConsumerConfig.put(ConsumerConfig.GROUP_ID_CONFIG, "gtt_metering_".concat(topic).concat("_1"));
        //10.18.166.97
        //Mockito.when(configuration.getKafkaConsumerConfig()).thenReturn(kafkaConsumerConfig);
        
        KafkaConsumer<String, String> kafkaConsumer = new KafkaConsumer<>(kafkaConsumerConfig);
        Mockito.when(connection.createKafkaConsumer(Mockito.anyString())).thenReturn(kafkaConsumer);

        KafkaReceiver receiver = new KafkaReceiverImpl(connection);
        receiver.start(topic);
        List<String> messages = receiver.receive(topic, 2000);
        System.out.println("Done!");
    }

}
