/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.iot.gtt.metering.util;

import com.sap.iot.gtt.metering.service.util.PropertyFileUtil;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.Resource;
import org.springframework.http.*;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.io.InputStream;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.util.Map;

/**
 *
 * @author I326335
 */
public class ClientUtils {

    private static final Logger LOG = LoggerFactory.getLogger(ClientUtils.class);

    private ClientUtils() {
        throw new IllegalStateException("Utility class");
    }

    private static RestTemplate restTemplate = initializeRestTemplate();

    /**
     * Get data from a RESTful service
     *
     * @param url The service url
     * @param authorization The authorization
     * @return The response input stream
     * @throws IOException The IO exception
     */
    public static InputStream getRestData(String url, String authorization, Map<String, String> uriVariables) throws IOException {
        return execute(url, authorization, HttpMethod.GET, null, null, uriVariables);
    }

    /**
     * Post data to a RESTful service
     *
     * @param url The service url
     * @param contentType The content type
     * @param authorization The authorization
     * @param postData The data to post
     * @return The response input stream
     * @throws IOException The IO exception
     */
    public static InputStream postRestData(String url, String authorization, String contentType, String postData, Map<String, String> uriVariables) throws IOException {
        return execute(url, authorization, HttpMethod.POST, contentType, postData, uriVariables);
    }

    private static InputStream execute(String url, String authorization, HttpMethod httpMethod, String contentType, String data, Map<String, String> uriVariables) throws IOException {
//		LOG.debug("Call external service at: " + url);
        HttpEntity<String> requestEntity = createRequestEntity(authorization, contentType, data);

        ResponseEntity<Resource> responseEntity;
        if (uriVariables == null) {
            responseEntity = restTemplate.exchange(url, httpMethod, requestEntity, Resource.class);
        } else {
            responseEntity = restTemplate.exchange(url, httpMethod, requestEntity, Resource.class, uriVariables);
        }

        return responseEntity.getBody().getInputStream();
    }

    private static HttpEntity<String> createRequestEntity(String authorization, String contentType, String data) {
        HttpHeaders headers = new HttpHeaders();
        if (StringUtils.isNotEmpty(authorization)) {
            headers.add(HttpHeaders.AUTHORIZATION, authorization);
        }
        if (contentType != null) {
            headers.setContentType(MediaType.parseMediaType(contentType));
        }
        return new HttpEntity<>(data, headers);
    }

    private static RestTemplate initializeRestTemplate() {
        String host = PropertyFileUtil.getProperty("Proxy_Host");
        String port = PropertyFileUtil.getProperty("Proxy_Port");
        LOG.debug("proxy:" + host + ":" + port);
        RestTemplate restTemplate = new RestTemplate();
        if (StringUtils.isNotEmpty(host) && StringUtils.isNotEmpty(port)) {
            addProxy(restTemplate, host, port);
        }
        return restTemplate;
    }

    /**
     * The proxy is only used for local development, in production the
     * application will not call proxy
     *
     * @param restTemplate The REST client
     * @param host The proxy host
     * @param port The proxy port
     */
    private static void addProxy(RestTemplate restTemplate, String host, String port) {
        SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
        InetSocketAddress address = new InetSocketAddress(host, Integer.valueOf(port));
        Proxy proxy = new Proxy(Proxy.Type.HTTP, address);
        factory.setProxy(proxy);
        restTemplate.setRequestFactory(factory);
    }
}
