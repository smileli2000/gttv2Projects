/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.iot.gtt.metering.util;

import com.google.gson.JsonObject;
import com.sap.iot.gtt.metering.service.util.PropertyFileUtil;
import com.sap.iot.gtt.metering.service.util.Util;
import org.apache.commons.io.IOUtils;
import org.springframework.http.MediaType;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Properties;

/**
 *
 * @author I326335
 */
public class AuthTokenHelper {

    public static String JWT_TOKEN_REQUEST_URL = "https://muenchhausen.internal.cfapps.sap.hana.ondemand.com/gettoken";
    public static String ABUCUS_COLLECTOR_URL = "https://abacus-usage-collector.cf.sap.hana.ondemand.com/v1/metering/collected/usage";
    public static String JWT_TOKEN_REQUEST_BODY_JSON = "jwt_token_request.json";

    public static String PROPERTY_FILE = "pipeline_config/pipeline_IT.properties";
    public static String PROPERTY_FILE_AT = "pipeline_config/pipeline_AT.properties";

    public static String requestJWTToken(String filePath) throws IOException {
        String requestBody = getRequestBody(filePath);
        System.out.println(requestBody);

        try (InputStream response = ClientUtils.postRestData(JWT_TOKEN_REQUEST_URL, null, MediaType.APPLICATION_JSON_UTF8_VALUE, requestBody, null)) {
            String jwtResponse = IOUtils.toString(response, StandardCharsets.UTF_8);
            JsonObject jwtResponseJSON = Util.getJSONObject(jwtResponse);
            String jwtToken = String.format("Bearer %s", jwtResponseJSON.getAsJsonObject("token").get("access_token").getAsString());
            return jwtToken;
        }
    }

    private static String getRequestBody(String filePath) throws IOException {
        String jsonTextPattern = IOUtils.toString(Util.readClassPathResourceAsStream(JWT_TOKEN_REQUEST_BODY_JSON), StandardCharsets.UTF_8);
        Properties props = PropertyFileUtil.readPropertyFile(filePath);
        return replaceTemplate(jsonTextPattern, props);
    }

    private static String replaceTemplate(String template, Properties props) {
        String result = template;

        if (props != null) {
            result = props.stringPropertyNames().stream()
                    .reduce(template, (templ, key) -> {
                        String replaceStr = String.format("${%s}", key);
                        return templ.replace(replaceStr, props.getProperty(key));
                    });
        }

        return result;
    }

}
