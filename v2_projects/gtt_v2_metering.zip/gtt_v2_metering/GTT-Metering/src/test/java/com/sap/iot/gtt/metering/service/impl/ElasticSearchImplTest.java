/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.iot.gtt.metering.service.impl;

import com.sap.iot.gtt.metering.MeteringConfiguration;
import com.sap.iot.gtt.metering.MeteringConnection;
import com.sap.iot.gtt.metering.util.OAuthToken;
import com.sap.iot.gtt.metering.util.WebClientUtil;

import java.io.InputStream;
import javax.ws.rs.core.Response.ResponseBuilder;

import org.apache.http.HttpEntity;
import org.apache.http.entity.ContentType;
import org.apache.http.nio.entity.NStringEntity;
import org.elasticsearch.client.Response;
import org.elasticsearch.client.RestClient;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.*;
import static org.mockito.Mockito.when;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.any;

import org.mockito.Answers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 *
 * @author I326335
 */
@RunWith(SpringJUnit4ClassRunner.class)
public class ElasticSearchImplTest {
    @MockBean
    private MeteringConnection connection;
    @MockBean
    private MeteringConfiguration configuration;
    @MockBean
    private HanaServiceImpl hanaService;
    
    @Mock
    private RestClient restClient;
    @Mock(answer=Answers.RETURNS_DEEP_STUBS)
    private Response response;
    @Mock
    private OAuthToken oauthToken;
    @Mock
    private WebClientUtil webClientUtil;
    @InjectMocks
    private ElasticSearchImpl elasticSearch;
    
    private ResponseBuilder responseBuilder;
    
    @Before
    public void setup() throws Exception {
    	MockitoAnnotations.initMocks(this);
    	when(configuration.getClientid()).thenReturn("client-id");
    	when(configuration.getClientsecret()).thenReturn("client-secret");
    	when(configuration.getOpsAppUrl()).thenReturn("https://ops-app-base-url");
    	when(configuration.getPaasAuthUrl()).thenReturn("https://pass-auth-base-url");
    	when(oauthToken.getToken(any(), any(), any(), any(), any())).thenReturn("Bearer token");
    	
		String okResponse = "{\"indexing\": {\"es\": {\"index\": {},\"connect\": {\"url\": \"https://search-tenant-id-hash.aws.com\", \"accessKeyId\": \"access-key-id\",\"secretAccessKey\": \"secret-access-key\"}}}}";
		responseBuilder = javax.ws.rs.core.Response.status(200);
		javax.ws.rs.core.Response resp = responseBuilder.entity(okResponse).build();
    	when(webClientUtil.get(any(), any())).thenReturn(resp);
    }

    @Test
    public void testGetConsumedIndexes() throws Exception {
        when(connection.createESRestClient()).thenReturn(restClient); 
        when(restClient.performRequest(anyString(), anyString())).thenReturn(response);
        String index = "green open tt_demot1_dev-sandbox_com.sap.gtt.app.poitem.poitemmodel.poitemprocess_t1                                              f17nGTr_TAeMbvCGQzkkDA 5 1      23       4    1.2mb  645.8kb";
        HttpEntity entity = new NStringEntity(
                index, 
                ContentType.DEFAULT_TEXT);
        InputStream content = entity.getContent();
        Mockito.when(response.getEntity().getContent()).thenReturn(content);
        
        assertEquals(index, elasticSearch.getConsumedIndexes().get(0));
    }    
    
    @Test
    public void testGetConsumedIndexesWithTenantId() throws Exception {
        when(connection.createESRestClient("tenant-id", "https://search-tenant-id-hash.aws.com", "access-key-id", "secret-access-key")).thenReturn(restClient);
        when(restClient.performRequest(anyString(), anyString())).thenReturn(response);
        
        String index = "green open tt_demot1_dev-sandbox_com.sap.gtt.app.poitem.poitemmodel.poitemprocess_t1                                              f17nGTr_TAeMbvCGQzkkDA 5 1      23       4    1.2mb  645.8kb";
        HttpEntity entity = new NStringEntity(
                index, 
                ContentType.DEFAULT_TEXT);
        InputStream content = entity.getContent();
        Mockito.when(response.getEntity().getContent()).thenReturn(content);
        
        assertEquals(index, elasticSearch.getConsumedIndexes("tenant-id").get(0));
    }
    
}
