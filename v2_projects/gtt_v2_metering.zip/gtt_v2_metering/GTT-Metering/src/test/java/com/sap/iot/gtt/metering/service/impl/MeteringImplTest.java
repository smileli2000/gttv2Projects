/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.iot.gtt.metering.service.impl;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.sap.iot.gtt.metering.MeteringAppConfiguration;
import com.sap.iot.gtt.metering.MeteringConfiguration;
import com.sap.iot.gtt.metering.MeteringConnection;
import com.sap.iot.gtt.metering.controller.GTTMeteringController;
import com.sap.iot.gtt.metering.exception.GTTMeteringException;
import com.sap.iot.gtt.metering.schedule.impl.CAndESTaskSchedulerImpl;
import com.sap.iot.gtt.metering.schedule.impl.TaskSchedulerImpl;
import com.sap.iot.gtt.metering.service.HanaService;
import com.sap.iot.gtt.metering.service.KafkaTopic;
import com.sap.iot.gtt.metering.service.util.InputStreamUtil;
import com.sap.iot.gtt.metering.service.util.Util;
import com.sap.iot.gtt.metering.usage.Usage;
import com.sap.iot.gtt.metering.util.EmbeddedZookeeper;
import com.sap.iot.gtt.metering.util.KafkaTopicHelper;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.HttpHeaders;
import kafka.server.KafkaConfig;
import kafka.server.KafkaServer;
import kafka.utils.MockTime;
import kafka.utils.TestUtils;
import kafka.utils.ZkUtils;
import org.I0Itec.zkclient.ZkClient;
import org.apache.commons.io.IOUtils;
import org.apache.kafka.common.security.JaasUtils;
import org.json.JSONException;
import org.junit.*;
import org.junit.runner.RunWith;
import org.mockserver.integration.ClientAndServer;
import org.mockserver.model.Delay;
import org.mockserver.model.Header;
import org.mockserver.model.HttpRequest;
import org.mockserver.model.HttpResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import scala.Option;
import scala.Option$;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

/**
 *
 * @author I326335
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = MeteringAppConfiguration.class)
@ActiveProfiles("dev")
public class MeteringImplTest {

    private static final Logger logger = LoggerFactory.getLogger(MeteringImplTest.class);

    private static final String JSONCONNECTIVITY_JSONJSON = "json/connectivity_json.json";
    private static final String JSONCONNECTIVITY_OBJECT_JSONJSON = "json/connectivity_json_object.json";
    private static final String JSONODATA_JSONJSON = "json/odata_json.json";

    private static int zkConnectionTimeout = 6000;
    private static int zkSessionTimeout = 6000;

    @MockBean
    private Usage usage;
    @MockBean
    private CassandraImpl cassandra;
    @MockBean
    private ElasticSearchImpl es;
    @MockBean
    private HanaService hanaService;
   
    @Autowired
    private MeteringImpl metering;
    @Autowired
    private MeteringConfiguration configuration;
    @Autowired
    MeteringConnection connection;
    @Autowired
    private GTTMeteringController meteringController;
    @Autowired
    private KafkaTopic kafkaTopic;
    
    @Autowired
    private TaskSchedulerImpl taskScheduler;
    @Autowired
    private CAndESTaskSchedulerImpl caAndESScheduler;

    private static ClientAndServer mockServer;
    private static EmbeddedZookeeper zookeeper;
    private static ZkClient zkClient;
    private static KafkaServer kafkaServer;

    public MeteringImplTest() throws GTTMeteringException {
    }

    @Before
    public void setUp() throws GTTMeteringException, JSONException {
    	List<String> esConsumedIndices = new ArrayList<String>();
    	esConsumedIndices.add("green open tt_integrationt1_7777bbe6-eeee-4444-bbbb-d845fe113333_process_event_directory-000001                                                                              Fb9a-PMyRQSuYaHgzqU5qg 5 1  137572 10817 182.2mb  91.1mb");
    	
        when(cassandra.getSpaceSize(anyString())).thenReturn("88");
        when(es.getConsumedIndexes("tenant-id")).thenReturn(esConsumedIndices);
    }

    @BeforeClass
    public static void startKafkaServer() throws Exception {
        mockServer = ClientAndServer.startClientAndServer(1080);

        setMockServerReqAndRep();

        int zookeeperPort = 3181;
        int kafkaPort = 9192;
        zookeeper = new EmbeddedZookeeper(zookeeperPort);
        zookeeper.startup();
        String zkConnect = String.format("localhost:%d", zookeeperPort);
        ZkUtils zkUtils = ZkUtils.apply(
                zkConnect, zkSessionTimeout, zkConnectionTimeout,
                JaasUtils.isZkSecurityEnabled());
        zkClient = zkUtils.zkClient();

        Properties brokerConfigProperties = TestUtils.createBrokerConfig(
                0,
                zkConnect,
                false,
                false,
                kafkaPort,
                scala.Option.apply(null),
                scala.Option.apply(null),
                Option$.MODULE$.<Properties>empty(),
                true,
                false,
                kafkaPort,
                false,
                kafkaPort,
                false,
                kafkaPort,
                Option.<String>empty());
        brokerConfigProperties.setProperty("replica.socket.timeout.ms", "1000");
        brokerConfigProperties.setProperty("controller.socket.timeout.ms", "1000");
        brokerConfigProperties.setProperty("offsets.topic.replication.factor", "1");

        MockTime mockTime = new MockTime();
        kafkaServer = TestUtils.createServer(new KafkaConfig(brokerConfigProperties), mockTime);
    }

    private static void setMockServerReqAndRep() {
        mockServer
                .when(
                        HttpRequest.request()
                        .withMethod(HttpMethod.GET.name())
                        .withPath("/v2/info")
                )
                .respond(
                        HttpResponse.response()
                        .withStatusCode(HttpServletResponse.SC_OK)
                        .withHeader(new Header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_UTF8_VALUE))
                        .withBody("{\"token_endpoint\":\"http://localhost:1080\"}")
                        .withDelay(new Delay(TimeUnit.SECONDS, 1))
                );
        mockServer
                .when(
                        HttpRequest.request()
                        .withMethod(HttpMethod.POST.name())
                        .withPath("/oauth/token")
                )
                .respond(
                        HttpResponse.response()
                        .withStatusCode(HttpServletResponse.SC_OK)
                        .withHeader(new Header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_UTF8_VALUE))
                        .withBody("{\"token_type\":\"\",\"access_token\":\"\",\"expires_in\":\"\"}")
                        .withDelay(new Delay(TimeUnit.SECONDS, 1))
                );
        mockServer.when(
                HttpRequest.request()
                .withMethod(HttpMethod.POST.name())
                .withPath("/v1/metering/collected/usage")
        )
                .respond(
                        HttpResponse.response()
                        .withStatusCode(HttpServletResponse.SC_OK)
                        .withHeader(new Header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_UTF8_VALUE))
                        .withBody("Usage OK.")
                        .withDelay(new Delay(TimeUnit.SECONDS, 1))
                );
        mockServer.when(
                HttpRequest.request()
                .withMethod(HttpMethod.POST.name())
                .withPath("/batch")
        )
                .respond(
                        HttpResponse.response()
                        .withStatusCode(HttpServletResponse.SC_OK)
                        .withHeader(new Header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_UTF8_VALUE))
                        .withBody("[{\"statusCode\":201,\"header\":{\"X-Process-Id\":72,\"X-Uptime\":584968.425,\"X-App-Name\":\"abacus-usage-collector\",\"X-App-Version\":\"1.0.0\",\"X-App-Index\":\"1\",\"X-Instance-Id\":\"5840dec7-e247-4ae0-746f-bd49\",\"X-Instance-Index\":\"0\",\"Location\":\"https://abacus-usage-collector.cf.sap.hana.ondemand.com/v1/metering/collected/usage/t/0001514355678740-1-0-0-0/k/abacus\"}},{\"statusCode\":201,\"header\":{\"X-Process-Id\":72,\"X-Uptime\":584968.426,\"X-App-Name\":\"abacus-usage-collector\",\"X-App-Version\":\"1.0.0\",\"X-App-Index\":\"1\",\"X-Instance-Id\":\"5840dec7-e247-4ae0-746f-bd49\",\"X-Instance-Index\":\"0\",\"Location\":\"https://abacus-usage-collector.cf.sap.hana.ondemand.com/v1/metering/collected/usage/t/0001514355678741-1-0-0-0/k/abacus\"}}]")
                        .withDelay(new Delay(TimeUnit.SECONDS, 1))
                );
        mockServer.when(
                HttpRequest.request()
                .withMethod(HttpMethod.GET.name())
                .withPath("/api/datasources/proxy/1/query")
        )
                .respond(
                        HttpResponse.response()
                        .withStatusCode(HttpServletResponse.SC_OK)
                        .withHeader(new Header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_UTF8_VALUE))
                        .withBody("{\"results\":[{\"statement_id\":0,\"series\":[{\"name\":\"jumpbox.tat.Keyspace.tt_integrationt1_gttdevsandbox.Live.value\",\"columns\":[\"time\",\"mean\"],\"values\":[[1514435750,1.140321125e+06]]}]}]}")
                        .withDelay(new Delay(TimeUnit.SECONDS, 1))
                );
        mockServer.when(
                HttpRequest.request()
                .withMethod(HttpMethod.POST.name())
                .withPath("/v1/kafkaId-1234-56789/topics")
        		).respond(
                        HttpResponse.response()
                        .withStatusCode(HttpServletResponse.SC_CREATED)
                        .withHeader("Authorizatioin","Basic a2Fma2FVc2VybmFtZTprYWZrYVBhc3N3b3Jk")
                        .withHeader("Slug","tt_integration_t1_gtt-devsandbox_usage")
                        .withHeader("Content-Type","application/json")
                        .withBody("{\"partitions\": 5, \"replicationFactor\": 1}")
                        .withDelay(new Delay(TimeUnit.SECONDS, 1))
                );
    }

    @AfterClass
    public static void shutdown() {

        mockServer.stop();

        if (kafkaServer != null) {
            kafkaServer.shutdown();
        }

        if (zkClient != null) {
            zkClient.close();
        }

        if (zookeeper != null) {
            zookeeper.shutdown();
        }
    }

    @Test
    public void testGetCassandraSpaceSize() throws GTTMeteringException {
        String size = cassandra.getSpaceSize(anyString());
        assertEquals("88", size);
        logger.debug("testGetCassandraSpaceSize: {}", size);
    }

    @Test
    public void testCheckAndCreateTopicForNew() throws GTTMeteringException, InterruptedException {
        String topic = "Ivang_Test";
        KafkaTopicHelper helper = new KafkaTopicHelper(connection, configuration);
        meteringController.createTopicAndConsumer(new HashMap<String, String>() {
            {
                put("topic_name", topic);
            }
        });
        meteringController.createTopicAndConsumer(new HashMap<String, String>() {
            {
                put("topic_name", topic);
            }
        });

        tryDeleteTopic(helper, topic, 0);
        assertEquals(false, helper.checkAndDeleteTopic(topic));
        Thread.sleep(300);
        Assert.assertEquals(false, helper.checkAndDeleteTopic(topic));
        kafkaTopic.checkAndCreateTopic(topic);
        Thread.sleep(300);
        helper.close();
    }

    @Test
    public void testSendInfoToKafkaThenGetAndSendToMeteringService() throws Exception {
    	Map<String, Object> response = new HashMap<String, Object>();
        String connectivityJson = getJson(JSONCONNECTIVITY_JSONJSON);
        
        String odataJson = getJson(JSONODATA_JSONJSON);
        meteringController.sendUsageDocument2GTTMetering("connectivity", Util.getMap(connectivityJson));
        Thread.sleep(1000);
    	response.put("statusCode", "200");
    	when(usage.sendBatchToMeteringService(anyString())).thenReturn(response);
    	metering.getAndSendToMeteringService("tt_integration_t1_gtt-devsandbox_usage_MaaS");
        
        meteringController.sendUsageDocument2GTTMetering("odata", Util.getMap(odataJson));
        Thread.sleep(1000);
        response.put("statusCode", "400");
    	when(usage.sendBatchToMeteringService(anyString())).thenReturn(response);
    	metering.getAndSendToMeteringService("tt_integration_t1_gtt-devsandbox_usage_MaaS");
    	
        connectivityJson = getJson(JSONCONNECTIVITY_OBJECT_JSONJSON);
        meteringController.sendUsageDocument2GTTMetering("connectivity", Util.getMap(connectivityJson));
        Thread.sleep(1000);
        response.put("statusCode", "429");
    	when(usage.sendBatchToMeteringService(anyString())).thenReturn(response);
    	metering.getAndSendToMeteringService("tt_integration_t1_gtt-devsandbox_usage_MaaS");

        meteringController.sendUsageDocument2GTTMetering("connectivity", Util.getMap(connectivityJson));
        Thread.sleep(1000);
        response.put("statusCode", "400");
    	List<String> tenants = new ArrayList<String>();
    	tenants.add("gtt-devsandbox");
        when(hanaService.getTenants()).thenReturn(tenants);
    	when(usage.sendBatchToMeteringService(anyString())).thenReturn(response);
    	taskScheduler.triggerUsagesSending();
    	
    	meteringController.sendUsageDocument2GTTMetering("cassandra", Util.getMap(connectivityJson));
        Thread.sleep(1000);
        
    	meteringController.sendUsageDocument2GTTMetering("elasticsearch", Util.getMap(connectivityJson));
        Thread.sleep(1000);
    	   	
        //Assert.assertEquals(1, response.getBody().size());
        String xsappname = configuration.getXSAppname();
        String tenant = configuration.getSecureTenant();
        String topic = Util.generateFullTopicName(tenant, xsappname);

        metering.close("tt_integration_t1_gtt-devsandbox_usage_MaaS");
    }

    private void assertUsage(JsonObject jsonObject, MeteringConfiguration configuration,
            String measure, String quantity) {
        assertEquals("idz:"+configuration.getSecureTenant(), jsonObject.get("organization_id").getAsString());
        assertEquals("na", jsonObject.get("space_id").getAsString());
        assertEquals("na", jsonObject.get("consumer_id").getAsString());
        assertEquals("standard", jsonObject.get("plan_id").getAsString());
        assertEquals("na", jsonObject.get("resource_instance_id").getAsString());
        assertEquals(true, jsonObject.get("measured_usage").getAsJsonArray().size() > 0);
        JsonArray jsonArray = jsonObject.get("measured_usage").getAsJsonArray();
        JsonObject usage = null;
        for(int i = 0; i < jsonArray.size(); i++) {
            if (jsonArray.get(i).getAsJsonObject().get("measure").getAsString().equals("measure")) {
                usage = jsonArray.get(i).getAsJsonObject();
                logger.info("usage found: {}", usage);
                break;
            }

        }
        if (usage != null) {
            assertEquals(measure, usage.get("measure").getAsString());
            assertEquals(quantity, usage.get("quantity").getAsString());
        } else {
            logger.error("no corresponding measure found: {}", measure);
        }
    }

    @Test
    public void testMeteringControllerSendUsage() throws Exception {

        String odataJson = getJson(JSONODATA_JSONJSON);
        JsonObject inputJson = Util.getJSONObject(odataJson);
        String consumerId = configuration.getXSAppname();//Util.getJSONString(inputJson, "consumer_id");
        JsonObject inputObject = Util.getJSONObject(inputJson, "input");

        Map<String, String> measured = new HashMap<>();
        inputObject.entrySet().stream().forEach(entry -> {
            measured.put(entry.getKey(), entry.getValue().getAsString());
        });
    }
    
    @Test
    public void testTaskSchedulerImpl() throws Exception {
    	Map<String, Object> response = new HashMap<String, Object>();
    	List<String> tenants = new ArrayList<String>();
    	tenants.add("gtt-devsandbox");
    	when(hanaService.getTenants()).thenReturn(tenants);
    	
    	String odataJson = getJson(JSONODATA_JSONJSON);
        meteringController.sendUsageDocument2GTTMetering("odata", Util.getMap(odataJson));
        Thread.sleep(1000);
        response.put("statusCode", "400");
    	when(usage.sendBatchToMeteringService(anyString())).thenReturn(response);
    	metering.getAndSendToMeteringService("tt_integration_t1_gtt-devsandbox_usage_MaaS");
    	
    	taskScheduler.triggerUsagesSending();
    	
    	metering.close("tt_integration_t1_gtt-devsandbox_usage_MaaS");
    }
    
    @Test
    public void testTaskSchedulerImplForCAandES() throws Exception {
    	Map<String, Object> response = new HashMap<String, Object>();
    	List<String> tenants = new ArrayList<String>();
    	tenants.add("gtt-devsandbox");
    	when(hanaService.getTenants()).thenReturn(tenants);
    	
    	String odataJson = getJson(JSONODATA_JSONJSON);
        meteringController.sendUsageDocument2GTTMetering("cassandra", Util.getMap(odataJson));
        Thread.sleep(1000);
        response.put("statusCode", "200");
    	when(usage.sendBatchToMeteringService(anyString())).thenReturn(response);
    	
        meteringController.sendUsageDocument2GTTMetering("elasticsearch", Util.getMap(odataJson));
        Thread.sleep(1000);
        response.put("statusCode", "200");
    	when(usage.sendBatchToMeteringService(anyString())).thenReturn(response);
    	
    	caAndESScheduler.triggerStorageUsagesSending();
    	
    	metering.close("tt_integration_t1_gtt-devsandbox_usage_MaaS");
    }

    private int tryDeleteTopic(KafkaTopicHelper helper, String topic, int start) throws InterruptedException {
        int index = start;
        Thread.sleep(300);
        try {
            index++;
            helper.checkAndDeleteTopic(topic);
        } catch (Exception e) {
            e.printStackTrace();
            if (index <= 3) {
                index = tryDeleteTopic(helper, topic, index);
            }
        }
        return index;
    }

    private static String getJson(String path) throws IOException {
        InputStream jsonTemplate = null;
        String json = "";
        try {
            jsonTemplate = Util.readClassPathResourceAsStream(path);
            json = IOUtils.toString(jsonTemplate, StandardCharsets.UTF_8);
        } finally {
            if (jsonTemplate != null) {
                InputStreamUtil.safeClose(jsonTemplate);
            }
        }

        return json;
    }

}
