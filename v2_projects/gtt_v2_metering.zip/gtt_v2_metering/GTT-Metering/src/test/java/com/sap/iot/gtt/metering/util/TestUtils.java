package com.sap.iot.gtt.metering.util;

import java.io.File;
import java.io.IOException;
import java.net.ServerSocket;


/**
 * Created by vagrant on 9/15/17.
 */
public class TestUtils {

    private static final int DEFAULT_MIN_PORT = 1025;
    private static final int DEFAULT_MAX_PORT = 65535;

    public static int randomTCPPort() {
        return randomTCPPort(DEFAULT_MIN_PORT, DEFAULT_MAX_PORT);
    }

    public static int randomPort(int minPort) {
        return randomTCPPort(minPort, DEFAULT_MAX_PORT);
    }

    public static int randomTCPPort(int minPort, int maxPort) {
        int port = minPort;

        while (port <= maxPort) {
            if (isTCPPortAvailable(port)) {
                return port;
            }
            port += 1;
        }
        throw new RuntimeException(String.format("No port is available between %d and %d",minPort, maxPort));
    }

    private static boolean isTCPPortAvailable(int port) {

        ServerSocket ss = null;

        boolean available = false;

        try {
            ss = new ServerSocket(port);
            ss.setReuseAddress(true);
            available = true;
        } catch (Exception ex) {
            // Already bound
        } finally {
            if (ss != null)
                try {
                    ss.close();
                } catch (IOException e) {

                }
        }

        return available;
    }

    public static void delete(File file) {
        if (file == null) {
            return;
        }

        if (file.isDirectory()){
            File[] children = file.listFiles();
            if (children != null && children.length > 0){
                for (int i = 0; i < children.length; i++){
                    delete(children[i]);
                }
            }
            file.delete();
        } else {
            file.delete();
        }
    }
}