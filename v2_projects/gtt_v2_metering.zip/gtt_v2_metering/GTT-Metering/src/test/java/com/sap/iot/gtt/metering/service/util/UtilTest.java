/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.iot.gtt.metering.service.util;

import com.sap.iot.gtt.metering.exception.GTTMeteringException;
import org.junit.Test;
import static org.junit.Assert.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;

/**
 *
 * @author I326335
 */
public class UtilTest {

    private Logger logger = LoggerFactory.getLogger(UtilTest.class);

    public UtilTest() {
    }

    @Test
    public void testConvertToByte() {
        assertEquals(Long.valueOf(1L), Util.convertToByte("1b"));
        assertEquals(Long.valueOf(1025L), Util.convertToByte("1.001kb"));
        assertEquals(Long.valueOf(1049624L), Util.convertToByte("1.001mb"));
        assertEquals(Long.valueOf(1074815616L), Util.convertToByte("1.001gb"));
        assertEquals(Long.valueOf(1100611190784L), Util.convertToByte("1.001tb"));
    }

    @Test
    public void testConvertFromByte_Long() {
        assertEquals("1b", Util.convertFromByte(1L));
        assertEquals("1.001kb", Util.convertFromByte(1025L));
        assertEquals("1.001mb", Util.convertFromByte(1048577L));
        assertEquals("1.001gb", Util.convertFromByte(1073741825L));
        assertEquals("1.001tb", Util.convertFromByte(1099511627777L));
    }

    @Test
    public void testGetHttpStatus() throws GTTMeteringException {
        assertEquals(HttpStatus.CONFLICT, Util.getHttpStatus("409"));
        assertEquals(HttpStatus.BAD_REQUEST, Util.getHttpStatus("400"));
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, Util.getHttpStatus("500"));
        assertEquals(HttpStatus.FORBIDDEN, Util.getHttpStatus("403"));
        assertEquals(HttpStatus.EXPECTATION_FAILED, Util.getHttpStatus("aa"));
        assertEquals(HttpStatus.EXPECTATION_FAILED, Util.getHttpStatus(""));
        assertEquals(HttpStatus.EXPECTATION_FAILED, Util.getHttpStatus("aa401"));
    }
    
    @Test
    public void testLogger() {
        Util util = new Util();
        Util.error(logger, "test error.");
        Util.error(logger, "test error.", new Exception("testException"));
        Util.warn(logger, "test warn.");
        Util.warn(logger, "test warn.{}", new Object[]{"test warn."});
        Util.warn(logger, "test warn.", new Exception("testException"));
        Util.debug(logger, "test debug.");
        Util.debug(logger, "test debug.", "test debug1.");
        Util.debug(logger, "test debug.{}", new Object[]{"test debug1."});
    }
}
