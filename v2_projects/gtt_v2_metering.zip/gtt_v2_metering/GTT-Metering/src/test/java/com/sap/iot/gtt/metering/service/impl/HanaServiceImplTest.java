/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.iot.gtt.metering.service.impl;

import com.sap.db.jdbc.exceptions.JDBCDriverException;
import com.sap.iot.gtt.metering.MeteringConfiguration;
import com.sap.iot.gtt.metering.MeteringConfigurationLocal;
import com.sap.iot.gtt.metering.MeteringConnection;
import com.sap.iot.gtt.metering.service.HanaService;
import java.sql.SQLException;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import org.junit.Assert;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.jdbc.BadSqlGrammarException;
import org.springframework.jdbc.core.JdbcTemplate;

/**
 *
 * @author I326335
 */
public class HanaServiceImplTest {

    private final String TENANT = "UT_tenant";

    public HanaServiceImplTest() {
    }

    @Test
    public void testGetTenants() throws Exception {
        MeteringConfiguration configuration = new MeteringConfigurationLocal();
        MeteringConnection connection = Mockito.spy(new MeteringConnection(configuration));
        JdbcTemplate mockJdbcTemplate = Mockito.mock(JdbcTemplate.class);

        // first simulate missing table, then return result
        // exceptions
        SQLException sqlException = JDBCDriverException.generateSQLException("", "HY000", 259, 0, new int[0],
                null);
        JDBCDriverException jdbcDriverException = (JDBCDriverException) sqlException;
        BadSqlGrammarException tableMissingException = new BadSqlGrammarException("task", "SELECT...",
                jdbcDriverException);

        // results
        List<Map<String, Object>> queryResult = new LinkedList<>();
        Map<String, Object> dbLine = new HashMap<>();
        dbLine.put("TENANT", this.TENANT);
        queryResult.add(dbLine);

        HanaService hanaService = new HanaServiceImpl(mockJdbcTemplate, connection);

        Mockito.when(mockJdbcTemplate.queryForList(Mockito.startsWith("SELECT TENANT"))).thenThrow(tableMissingException).thenReturn(queryResult);

        // Test with missing table
        Collection<String> tenants = hanaService.getTenants();
        Assert.assertNotNull(tenants);
        Assert.assertEquals(0, tenants.size());

        // Straight forward test
        tenants = hanaService.getTenants();
        Assert.assertNotNull(tenants);
        Assert.assertEquals(1, tenants.size());
    }

}
