/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.iot.gtt.metering.usage;

import com.google.gson.JsonObject;
import com.sap.iot.gtt.metering.MeteringConfiguration;
import com.sap.iot.gtt.metering.MeteringConfigurationCloud;
import com.sap.iot.gtt.metering.MeteringConnection;
import com.sap.iot.gtt.metering.service.json.UsageJsonHelper;
import com.sap.iot.gtt.metering.service.util.InputStreamUtil;
import com.sap.iot.gtt.metering.service.util.Util;
import com.sap.iot.gtt.metering.util.OAuthToken;
import com.sap.iot.gtt.metering.util.WebClientUtil;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.text.ParseException;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.cxf.jaxrs.client.WebClient;
import org.apache.cxf.transport.http.HTTPConduit;
import org.apache.cxf.transports.http.configuration.HTTPClientPolicy;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.Before;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.invocation.InvocationOnMock;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 *
 * @author I326335
 */
@RunWith(SpringJUnit4ClassRunner.class)
public class UsageTest {

    private static final String JSONODATA_JSONJSON = "json/odata_json.json";
    
    private String jsonVCAPServices;
    private String jsonVCAPApplication;
    private String organizationId;
    private String opsAppUrl;
    
    @Mock
    private MeteringConfiguration configuration;
    @Mock
    private MeteringConnection connection;
    @Mock
    private WebClient webClient;
    @Mock
    private OAuthToken oauthToken;
    @Mock
    private WebClientUtil webClientUtil;
    @InjectMocks
    private Usage usage = new Usage();

    @Before
    public void setUp() throws IOException {
    	when(configuration.getMeteringServiceUrl()).thenReturn("https://localhost:8080");
    	webClient = WebClient.create("https://localhost:8080").accept(MediaType.APPLICATION_JSON_TYPE);
    	when(connection.createWebClient(any())).thenReturn(webClient);
    	when(oauthToken.getToken(any(), any(), any(), any(), any())).thenReturn("token-string");
    	
    	ResponseBuilder responseBuilder = Response.ok();
    	Response resp = responseBuilder.entity("OK").build();
    	when(webClientUtil.put(any(), any(), any())).thenReturn(resp);
    }

    //for local test
    @Test
    public void testSendBatch() throws IOException, ParseException {
        organizationId = "gtt-devsandbox";
        MeteringConfiguration configuration = Mockito.spy(new MeteringConfigurationCloud(jsonVCAPServices, jsonVCAPApplication, organizationId, opsAppUrl));
        MeteringConnection connection = Mockito.spy(new MeteringConnection(configuration));

        Mockito.when(connection.createWebClient(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenAnswer((InvocationOnMock invocation) -> {
            Object[] args = invocation.getArguments();
            WebClient webClient = WebClient.create((String)args[0], (String)args[1], (String)args[2], null).accept(MediaType.APPLICATION_JSON_TYPE);
            if (StringUtils.isNotEmpty(configuration.getProxyHost()) && configuration.getProxyPort() > 0) {
                HTTPConduit conduit = WebClient.getConfig(webClient).getHttpConduit();
                HTTPClientPolicy policy = new HTTPClientPolicy();
                policy.setProxyServer(configuration.getProxyHost());
                policy.setProxyServerPort(configuration.getProxyPort());
                conduit.setClient(policy);
            }
            return webClient;
        });
        Mockito.when(connection.createWebClient(Mockito.anyString())).thenAnswer((InvocationOnMock invocation) -> {
            Object[] args = invocation.getArguments();
            WebClient webClient = WebClient.create((String)args[0]).accept(MediaType.APPLICATION_JSON_TYPE);
            if (StringUtils.isNotEmpty(configuration.getProxyHost()) && configuration.getProxyPort() > 0) {
                HTTPConduit conduit = WebClient.getConfig(webClient).getHttpConduit();
                HTTPClientPolicy policy = new HTTPClientPolicy();
                policy.setProxyServer(configuration.getProxyHost());
                policy.setProxyServerPort(configuration.getProxyPort());
                conduit.setClient(policy);
            }
            return webClient;
        });

        //Usage usage = Mockito.spy(new Usage());
        //Whitebox.setInternalState(usage, "configuration", configuration);
        //Whitebox.setInternalState(usage, "connection", connection);
        
        String odataJson = getJson(JSONODATA_JSONJSON);
        JsonObject inputJson = Util.getJSONObject(odataJson);
        JsonObject inputObject = Util.getJSONObject(inputJson, "input");

        Map<String, String> measured = new HashMap<>();
        inputObject.entrySet().stream().forEach(entry -> {
            measured.put(entry.getKey(), entry.getValue().getAsString());
        });
        
        String batchUsages = UsageJsonHelper.generateBatchUsageJson("/v1/metering/collected/usage",
                        Arrays.asList(UsageJsonHelper.generateMeteringServiceUsageJson(
                                "2099-12-31T00:00:00.000",
                                "cf-eu10-canary",
                                "subaccount",
                                "space",
                                measured)));
        System.out.println(batchUsages);
        Map<String, Object> batchResults = usage.sendBatchToMeteringService(batchUsages);
        System.out.println(Util.getJSONObject(batchResults).toString());
    }

    private static String getJson(String path) throws IOException {
        InputStream jsonTemplate = null;
        String json = "";
        try {
            jsonTemplate = Util.readClassPathResourceAsStream(path);
            json = IOUtils.toString(jsonTemplate, StandardCharsets.UTF_8);
        } finally {
            if (jsonTemplate != null) {
                InputStreamUtil.safeClose(jsonTemplate);
            }
        }

        return json;
    }
}
