/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.iot.gtt.metering.service.impl;

import com.google.gson.JsonObject;
import com.sap.iot.gtt.metering.MeteringConfiguration;
import com.sap.iot.gtt.metering.MeteringConfigurationLocal;
import com.sap.iot.gtt.metering.MeteringConnection;
import com.sap.iot.gtt.metering.exception.GTTMeteringException;
import com.sap.iot.gtt.metering.service.Cassandra;
import com.sap.iot.gtt.metering.service.ElasticSearch;
import com.sap.iot.gtt.metering.service.KafkaReceiver;
import com.sap.iot.gtt.metering.service.KafkaSender;
import com.sap.iot.gtt.metering.service.KafkaTopic;
import com.sap.iot.gtt.metering.service.Metering;
import com.sap.iot.gtt.metering.service.util.Util;
import com.sap.iot.gtt.metering.util.EmbeddedZookeeper;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import kafka.server.KafkaConfig;
import kafka.server.KafkaServer;
import kafka.utils.MockTime;
import kafka.utils.TestUtils;
import kafka.utils.ZkUtils;
import org.I0Itec.zkclient.ZkClient;
import org.apache.kafka.common.security.JaasUtils;
import org.junit.*;
import scala.Option;
import scala.Option$;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.anyString;

import org.mockito.Mockito;

/**
 *
 * @author I326335
 */
@Ignore
public class MeteringImplForCAndESTest {

    //private final String TENANT = "UT_tenant";
    private static int zkConnectionTimeout = 6000;
    private static int zkSessionTimeout = 6000;

    private static EmbeddedZookeeper zookeeper;
    private static ZkClient zkClient;
    private static KafkaServer kafkaServer;

    public MeteringImplForCAndESTest() throws GTTMeteringException {
    }

    @BeforeClass
    public static void startKafkaServer() throws Exception {

        int zookeeperPort = 3181;
        int kafkaPort = 9192;
        zookeeper = new EmbeddedZookeeper(zookeeperPort);
        zookeeper.startup();
        String zkConnect = String.format("localhost:%d", zookeeperPort);
        ZkUtils zkUtils = ZkUtils.apply(
                zkConnect, zkSessionTimeout, zkConnectionTimeout,
                JaasUtils.isZkSecurityEnabled());
        zkClient = zkUtils.zkClient();

        Properties brokerConfigProperties = TestUtils.createBrokerConfig(
                0,
                zkConnect,
                false,
                false,
                kafkaPort,
                scala.Option.apply(null),
                scala.Option.apply(null),
                Option$.MODULE$.<Properties>empty(),
                true,
                false,
                kafkaPort,
                false,
                kafkaPort,
                false,
                kafkaPort,
                Option.<String>empty());
        brokerConfigProperties.setProperty("replica.socket.timeout.ms", "1000");
        brokerConfigProperties.setProperty("controller.socket.timeout.ms", "1000");
        brokerConfigProperties.setProperty("offsets.topic.replication.factor", "1");
        MockTime mockTime = new MockTime();
        kafkaServer = TestUtils.createServer(new KafkaConfig(brokerConfigProperties), mockTime);
    }

    @AfterClass
    public static void shutdown() {

        if (kafkaServer != null) {
            kafkaServer.shutdown();
        }

        if (zkClient != null) {
            zkClient.close();
        }

        if (zookeeper != null) {
            zookeeper.shutdown();
        }
    }

    @Test
    public void testSendInfoToKafka() throws Exception {

        MeteringConfiguration configuration = new MeteringConfigurationLocal();
        MeteringConnection connection = new MeteringConnection(configuration);

        KafkaTopic kafkaTopic = new KafkaTopicImpl(configuration, connection);
        KafkaSender kafkaSender = new KafkaSenderImpl(connection);
        KafkaReceiver kafkaReceiver = new KafkaReceiverImpl(connection);

        Metering metering = Mockito.spy(new MeteringImpl(configuration, kafkaSender, kafkaReceiver, kafkaTopic));
        Cassandra cassandra = Mockito.mock(Cassandra.class);
        Mockito.when(cassandra.getSpaceSize(anyString())).thenReturn("1");
        //Whitebox.setInternalState(metering, "cassandra", cassandra);
        ElasticSearch elasticSearch = Mockito.mock(ElasticSearch.class);
        Mockito.when(elasticSearch.getConsumedIndexes()).thenReturn(
                Arrays.asList(
                        "green open tt_integrationt1_test-sandbox_com.sap.gtt.app.shipment.event.shipmentmodel.unloadingevent-000001                       c5XOPzQyQCCQCK8kAzPcMA 5 1       0       0    1.2kb     650b",
                        "green open tt_integrationt1_gtt-devsandbox_com.sap.gtt.app.deliverysample.deliverymodel.goodsissuedevent-000001                   eaDgGAqJS4eU36oyODGf9w 5 1       0       0    1.2kb     650b",
                        "green open tt_integrationt1                   eaDgGAqJS4eU36oyODGf9w 5 1       0       0    1.2kb     650b"
                ));
        //Whitebox.setInternalState(metering, "elasticSearch", elasticSearch);

        String xsappname = configuration.getXSAppname();
        String tenant = configuration.getSecureTenant();

        String topic = Util.generateFullTopicName(tenant, xsappname);
        metering.start(topic);
        Thread.sleep(700);
        String region = "EU10";
        String subaccount = "sub-account";
        String cfSpaceName = "integration";

        metering.sendCassandraInfoToKafka(topic, region, subaccount, cfSpaceName);
        Thread.sleep(100);
        metering.sendElasticSearchInfoToKafka(topic, region, subaccount, cfSpaceName, xsappname);
        Thread.sleep(100);
        List<String> messages = kafkaReceiver.receive(topic, 100);
        assertEquals(2, messages.size());
        metering.close(topic);

    }

    private void assertUsage(JsonObject jsonObject, Long startTime, Long endTime, String orgId, String spaceId,
            String consumerId, String resourceId, String planId, String resourceInstanceId,
            String measure, String quantity) {
        assertEquals(startTime, Long.valueOf(jsonObject.get("start").getAsLong()));
        assertEquals(endTime, Long.valueOf(jsonObject.get("end").getAsLong()));
        assertEquals(orgId, jsonObject.get("organization_id").getAsString());
        assertEquals(spaceId, jsonObject.get("space_id").getAsString());
        assertEquals(consumerId, jsonObject.get("consumer_id").getAsString());
        assertEquals(resourceId, jsonObject.get("resource_id").getAsString());
        assertEquals(planId, jsonObject.get("plan_id").getAsString());
        assertEquals(resourceInstanceId, jsonObject.get("resource_instance_id").getAsString());
        assertEquals(true, jsonObject.get("measured_usage").getAsJsonArray().size() > 0);
        JsonObject usage = jsonObject.get("measured_usage").getAsJsonArray().get(0).getAsJsonObject();
        assertEquals(measure, usage.get("measure").getAsString());
        assertEquals(quantity, usage.get("quantity").getAsString());
    }

    /**
     * Test for multi topic vs multi tenant vs multi space
     *
     * @throws IOException
     * @throws GTTMeteringException
     */
    @Test
    public void testMultiKafkaReceiver() throws IOException, GTTMeteringException, InterruptedException {
        MeteringConfiguration configuration = new MeteringConfigurationLocal();
        MeteringConnection connection = new MeteringConnection(configuration);

        KafkaTopic kafkaTopic = new KafkaTopicImpl(configuration, connection);
        KafkaSender kafkaSender = new KafkaSenderImpl(connection);
        KafkaReceiverImpl kafkaReceiver = new KafkaReceiverImpl(connection);
        int count = 4;
        for (int i = 0; i < count; i++) {
            String topic = String.format("test_topic_%d", i);
            kafkaTopic.checkAndCreateTopic(topic);
            Thread.sleep(10);
        }
        for (int i = 0; i < count; i++) {
            String topic = String.format("test_topic_%d", i);
            kafkaReceiver.start(topic);
            Thread.sleep(800);
        }

        for (int i = 0; i < count; i++) {
            String topic = String.format("test_topic_%d", i);
            kafkaSender.send(topic, "test1-" + i);
            kafkaSender.send(topic, "test2-" + i);
            Thread.sleep(10);
        }

        for (int i = 0; i < count; i++) {
            String topic = String.format("test_topic_%d", i);
            List<String> messages = kafkaReceiver.receive(topic, 100);
            assertEquals("firstly to obtain. topic:" + topic, 2, messages.size());
            messages = kafkaReceiver.receive(topic, 100);
            assertEquals("secondly to obtain. topic:" + topic, 2, messages.size());
            kafkaReceiver.commit(topic, 0);
            messages = kafkaReceiver.receive(topic, 100);
            assertEquals("thirdly to obtain after committed. topic:" + topic, 1, messages.size());
            kafkaReceiver.commit(topic, 0);
            messages = kafkaReceiver.receive(topic, 100);
            assertEquals("thirdly to obtain after committed. topic:" + topic, 0, messages.size());
            Thread.sleep(10);
            kafkaReceiver.setToNextOffset(1, new ArrayList<>(), topic, 100);
        }
    }

//    @Test
//    public void testKafkaReceiverWithoutMessages() throws IOException, GTTMeteringException, InterruptedException, NoSuchMethodException {
//        MeteringConfiguration configuration = new MeteringConfigurationLocal();
//        MeteringConnection connection = new MeteringConnection(configuration);
//
//        KafkaTopic kafkaTopic = new KafkaTopicImpl(configuration, connection);
//        KafkaSender kafkaSender = new KafkaSenderImpl(connection);
//        KafkaReceiverImpl kafkaReceiver = new KafkaReceiverImpl(connection);
//        
//        int i = 0;
//        String topic = String.format("test_topic_%d", i);
//        kafkaTopic.checkAndCreateTopic(topic);
//        Thread.sleep(10);
//
//        topic = String.format("test_topic_%d", i);
//        kafkaReceiver.start(topic);
//        Thread.sleep(800);
//
//        topic = String.format("test_topic_%d", i);
//        kafkaSender.send(topic, "test1-" + i);
//        kafkaSender.send(topic, "test2-" + i);
//        Thread.sleep(10);
//
//        topic = String.format("test_topic_%d", i);
//        kafkaReceiver.setToNextOffset(1, new ArrayList<>(), topic, 100);
//    }
}
