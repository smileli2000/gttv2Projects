package com.sap.iot.gtt.metering.util;

import kafka.utils.TestUtils;
import org.apache.zookeeper.server.NIOServerCnxnFactory;
import org.apache.zookeeper.server.ZooKeeperServer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.InetSocketAddress;

public class EmbeddedZookeeper {

    private Logger logger = LoggerFactory.getLogger(EmbeddedZookeeper.class);
    private String connectString = null;
    private int port = -1;
    private File snapshotDir;
    private File logDir;

    private ZooKeeperServer zookeeper;
    private NIOServerCnxnFactory factory;

    public EmbeddedZookeeper(int port) {
        this.port = port;
        connectString = "localhost:" + port;
    }

    public void startup() throws IOException, Exception {
        snapshotDir = TestUtils.tempDir();
        logDir = TestUtils.tempDir();

//        try {
//            delete(logDir);
//            delete(snapshotDir);
//        } catch (Exception ex) {
//            logger.error("Failed to delete temp directories", ex);
//        }
        
        zookeeper = new ZooKeeperServer(snapshotDir, logDir, 3000);
        factory = new NIOServerCnxnFactory();

        logger.info("Trying to start zookeeper at port {}", port);

        factory.configure(new InetSocketAddress("localhost", port), 10);
        factory.startup(zookeeper);
        logger.info("Zookeeper started");
    }

    public String getConnectString() {
        return connectString;
    }

    public void shutdown() {

        try {
            factory.shutdown();
        } catch (Exception ex) {
            logger.error("Failed to shutdown server connection factory", ex);
        }

        try {
            delete(logDir);
            delete(snapshotDir);
        } catch (Exception ex) {
            logger.error("Failed to delete temp directories", ex);
        }
    }

    public static void delete(File f) throws IOException {
        if (!f.exists()) {
            return;
        }
        if (f.isDirectory()) {
            for (File c : f.listFiles()) {
                delete(c);
            }
        }
        if (!f.delete()) {
            throw new FileNotFoundException("Failed to delete file: " + f);
        }
    }
}
