/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.iot.gtt.metering;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.sap.iot.gtt.metering.service.json.UsageJsonHelper;
import com.sap.iot.gtt.metering.service.util.PropertyFileUtil;
import com.sap.iot.gtt.metering.service.util.Util;
import com.sap.iot.gtt.metering.util.AuthTokenHelper;
import com.sap.iot.gtt.metering.util.ClientUtils;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;
import java.text.ParseException;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import javax.ws.rs.core.MediaType;
import org.apache.commons.io.IOUtils;
import org.junit.Assert;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import org.junit.Test;

/**
 *
 * @author I326335
 */
public class MeteringServiceAT {

    private static final String JSONCONNECTIVITY_JSONJSON = "json/connectivity_json.json";
    private static final String JSONODATA_JSONJSON = "json/odata_json.json";
    
    //@Test
    public void testSendUsageDocument2GTTMeteringForOData() throws IOException {
        String jsonTextPattern = IOUtils.toString(Util.readClassPathResourceAsStream(JSONODATA_JSONJSON), StandardCharsets.UTF_8);
        String jwtResponse = callMeteringService("usageDocument/odata", jsonTextPattern);
        System.out.println("odata jwtResponse:" + jwtResponse);
        
        jwtResponse = callMeteringService("sendAll2Abacus", "{}");
        System.out.println("sendAll2Abacus jwtResponse:" + jwtResponse);
        JsonArray resultArray = getJSONObject(jwtResponse);
        assertEquals(true, resultArray.size() > 0);
        JsonObject resultObject = resultArray.get(0).getAsJsonObject();
        assertEquals("201", resultObject.get("status").getAsString());
    }

    //@Test
    public void testSendUsageDocument2GTTMeteringForConnectivity() throws IOException {
        String jsonTextPattern = IOUtils.toString(Util.readClassPathResourceAsStream(JSONCONNECTIVITY_JSONJSON), StandardCharsets.UTF_8);
        String jwtResponse = callMeteringService("usageDocument/connectivity", jsonTextPattern);
        System.out.println("connectivity jwtResponse:" + jwtResponse);
        
        jwtResponse = callMeteringService("sendAll2Abacus", "{}");
        System.out.println("sendAll2Abacus jwtResponse:" + jwtResponse);
        JsonArray resultArray = getJSONObject(jwtResponse);
        assertEquals(true, resultArray.size() > 0);
        JsonObject resultObject = resultArray.get(0).getAsJsonObject();
        assertEquals("201", resultObject.get("status").getAsString());
    }
    
    //@Test
    public void testSendUsageDocument2GTTMeteringForCassandra() throws IOException {
        String jwtResponse = callMeteringService("usageDocument/cassandra", "{\"withProxy\":true,\"proxyHost\":\"proxy.wdf.sap.corp\",\"proxyPort\":\"8080\"}");
        System.out.println("cassandra jwtResponse:" + jwtResponse);
    }
    
    //@Test
    public void testSendUsage() throws ParseException, IOException {
        String odataJson = IOUtils.toString(Util.readClassPathResourceAsStream(JSONODATA_JSONJSON), StandardCharsets.UTF_8);
        JsonObject inputJson = Util.getJSONObject(odataJson);
        // change consumer id from app id to tenant id
        String consumerId = PropertyFileUtil.getProperty("XSUAA_TenantName"); //Util.getJSONString(inputJson, "consumer_id");
        JsonObject inputObject = Util.getJSONObject(inputJson, "input");

        Map<String, String> measured = new HashMap<>();
        inputObject.entrySet().stream().forEach(entry -> {
            measured.put(entry.getKey(), entry.getValue().getAsString());
        });
        
        String usageJson = UsageJsonHelper.generateMeteringServiceUsageJson(Util.getUTCTimeString(), 
															        		"cf-eu10-canary", 
															        		"tenant-id", 
															        		PropertyFileUtil.getProperty("SPACE_ID"), 
															        		measured);
        
        System.out.println("odata usageJson:" + usageJson);
        String jwtResponse = callMeteringService("send2Abacus", usageJson);
        System.out.println("odata jwtResponse:" + jwtResponse);
        JsonObject resultObject = Util.getJSONObject(jwtResponse);
        assertNotNull(resultObject);
        assertEquals("201", resultObject.get("status").getAsString());
    }
    
    //@Test
    public void testCreateTopicAndConsumer() {
        try {
            String topic = Util.generateFullTopicName(PropertyFileUtil.getProperty("XSUAA_TenantName"), PropertyFileUtil.getProperty("XSUAA_Name"));
            String jwtResponse = callMeteringService("usageTopic", "{\"topic_name\":\"" + topic + "\"}");
            System.out.println("odata jwtResponse:" + jwtResponse);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
    private String callMeteringService(String relativePath, String jsonTextPattern) throws IOException {
        String token = AuthTokenHelper.requestJWTToken(AuthTokenHelper.PROPERTY_FILE_AT);
        String url = String.format("%s/%s", getMeteringUrl(), relativePath);
        InputStream response = ClientUtils.postRestData(url, token, MediaType.APPLICATION_JSON_TYPE.toString(), jsonTextPattern, null);
        String jwtResponse = IOUtils.toString(response, StandardCharsets.UTF_8);
        Assert.assertNotNull(jwtResponse);
        return jwtResponse;
    }
    
    protected String getMeteringUrl() throws IOException {
        Properties props = PropertyFileUtil.readPropertyFile(AuthTokenHelper.PROPERTY_FILE_AT);
        return props.getProperty("metering.url");//"http://localhost:8080";//
    }
    
    private JsonArray getJSONObject(String json) {
        GsonBuilder gsonBuilder = new GsonBuilder();
        Gson gson = gsonBuilder.create();
        StringReader reader = new StringReader(json);
        return gson.fromJson(reader, JsonArray.class);
    }
}
