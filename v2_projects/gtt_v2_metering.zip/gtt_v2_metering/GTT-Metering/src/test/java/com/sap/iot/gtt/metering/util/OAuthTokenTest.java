package com.sap.iot.gtt.metering.util;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import org.apache.commons.io.IOUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.sap.iot.gtt.metering.MeteringConfiguration;
import com.sap.iot.gtt.metering.MeteringConfigurationCloud;
import com.sap.iot.gtt.metering.MeteringConnection;
import com.sap.iot.gtt.metering.service.util.Util;

@RunWith(SpringJUnit4ClassRunner.class)
public class OAuthTokenTest {
    private String jsonVCAPServices;
    private String jsonVCAPApplication;
    private String organizationId;
    private String opsAppUrl;
    
    @Mock
    private WebClientUtil webClientUtil;
    @Mock
    MeteringConfiguration meteringConfiguration;
    @InjectMocks
    private OAuthToken oauthToken = new OAuthToken();
    private ResponseBuilder responseBuilder;
    private MeteringConnection meteringConnection;
    
	@Before
	public void setup() throws IOException {
        jsonVCAPServices = IOUtils.toString(Util.readClassPathResourceAsStream("json/vcap_services.json"), StandardCharsets.UTF_8);
        jsonVCAPApplication = IOUtils.toString(Util.readClassPathResourceAsStream("json/vcap_application.json"), StandardCharsets.UTF_8);
        
        when(meteringConfiguration.getPaasAuthUrl()).thenReturn("https://paas-auth-url.com");
        when(meteringConfiguration.getMeteringServiceTokenUrl()).thenReturn("https://metering-service-token-url.com");
	}
	
	@Test
	public void testGetToken() throws IOException {
		MeteringConfiguration configuration = spy(new MeteringConfigurationCloud(jsonVCAPServices, jsonVCAPApplication, organizationId, opsAppUrl));
		MeteringConnection connection = spy(new MeteringConnection(configuration));
		
    	responseBuilder = Response.status(401);
    	Response resp = responseBuilder.entity("{\"error\": \"unauthorized\",\"error_description\": \"Bad credentials\"}").build();
        when(webClientUtil.postWithBasicAuth(any(), any(), any())).thenReturn(resp);
		oauthToken.getToken(meteringConfiguration, meteringConnection, "XSUAA_ClientCredentials", "user", "pwd");
		
		String okResponse = "{\"access_token\": \"eyJhbGciOiJSUzI1N\", \"token_type\": \"bearer\", \"expires_in\": 43199}";
		responseBuilder = Response.status(200);
		resp = responseBuilder.entity(okResponse).build();
		when(webClientUtil.postWithBasicAuth(any(), any(), any())).thenReturn(resp);
		oauthToken.getToken(meteringConfiguration, meteringConnection, "Metering_Service_ClientCredentials", "user", "pwd");
		
		responseBuilder = Response.status(200);
		resp = responseBuilder.entity("{\"other\": \"response\"}").build();
		when(webClientUtil.postWithBasicAuth(any(), any(), any())).thenReturn(resp);
		oauthToken.getToken(meteringConfiguration, meteringConnection, "Metering_Service_ClientCredentials", "user", "pwd");
	}
}
