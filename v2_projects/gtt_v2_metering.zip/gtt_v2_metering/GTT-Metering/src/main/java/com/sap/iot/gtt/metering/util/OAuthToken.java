package com.sap.iot.gtt.metering.util;

import javax.ws.rs.core.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sap.iot.gtt.metering.MeteringConfiguration;
import com.sap.iot.gtt.metering.MeteringConnection;
import com.sap.iot.gtt.metering.service.util.Util;
import java.io.IOException;

public class OAuthToken {
    private static String tokenString = "";
    private static final Logger LOGGER = LoggerFactory.getLogger(OAuthToken.class);
    private WebClientUtil webClientUtil = new WebClientUtil();

    public String getToken(MeteringConfiguration configuration, MeteringConnection connection, String type, String user, String password) {   	
    	String tokenUrl = "";
    	if (type.equals("XSUAA_ClientCredentials")) {
        	tokenUrl = configuration.getPaasAuthUrl()+"/oauth/token";
        } else if (type.equals("Metering_Service_ClientCredentials")) {
        	tokenUrl = configuration.getMeteringServiceTokenUrl()+"/oauth/token";
        }
   
    	Util.debug(LOGGER,">>> TokenUrl is "+tokenUrl);
        if (!tokenUrl.equals("")) {
            try {
                Response response = webClientUtil.postWithBasicAuth(tokenUrl, user, password);
                String responseString = response.readEntity(String.class);
                JsonNode responseJson = (new ObjectMapper()).readTree(responseString);
                if (responseJson.has("error")) {
                    String errorMsg = responseJson.get("error").toString();
                    if (responseJson.has("error_description")) {
                        errorMsg += " - " + responseJson.get("error_description").toString();
                    }
                    if (errorMsg.length() < 1) {
                        errorMsg = responseString;
                    }
                    Util.debug(LOGGER, "Something went wrong getting new OAuth access token for user '" + user + "' from token URL '" + tokenUrl + "': " + errorMsg);                    
                } else if (responseJson.has("token_type") && responseJson.has("access_token") && responseJson.has("expires_in")) {
                    tokenString = "Bearer " + responseJson.get("access_token").asText();
                } else {
                    Util.debug(LOGGER, "Something went wrong getting new OAuth access token for user '" + user + "' from token URL '" + tokenUrl + "'. Received unexpected response content: '" + responseString + "'");                    
                }
            } catch (IOException e) {
                Util.debug(LOGGER, "Something went wrong getting new OAuth access token for user '" + user + "' from token URL '" + tokenUrl + "': " + e.getMessage());
            }
        }
        return tokenString;
    }
}
