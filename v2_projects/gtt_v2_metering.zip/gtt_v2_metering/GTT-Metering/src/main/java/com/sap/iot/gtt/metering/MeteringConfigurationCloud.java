/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.iot.gtt.metering;

import com.google.gson.*;
import com.sap.iot.gtt.metering.service.util.Util;
import com.sap.iot.gtt.metering.util.KafkaUtils;
import com.sap.xs2.security.container.SecurityContext;
import com.sap.xs2.security.container.UserInfoException;
import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.config.SaslConfigs;
import org.apache.kafka.common.config.SslConfigs;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Profile;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.UnknownHostException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.PosixFilePermissions;
import java.util.*;

@Component
@Profile("cloud")
public class MeteringConfigurationCloud implements MeteringConfiguration {

    private JsonObject kafkaServiceJson;
    private Map<String, String> kafkaConnectConfig;

    private String cassandraHosts;
    private String cassandraUser;
    private String cassandraPassword;
    private Boolean cassandra = false;
    private String zookeeperURL;
    private String kafkaURL;
    private Map<String, Object> kafkaProducerProperties;
    private Map<String, Object> kafkaConsumerProperties;
    private Boolean kafka = false;
    private InetSocketAddress elasticSearchHost;
    private int elasticSearchPortForRest;
    private String awsEndPoint;
    private String roleArn;
    private String accessKeyID;
    private String secretAccessKey;
    private String proxyHost;
    private int proxyPort;
    private boolean needAWSSign = false;
    private String awsSignerRegion;

    private String cf_api = "";
    private String space_id = "";
    private String space_name = "";

    private String xsappname = "";
    private String clientid= "";
    private String clientsecret = "";
    private String paasAuthUrl = "";
    private String userIdentityZone = "";
    private String email = "";
    private String opsAppUrl = "";
    private String scheduleCron = "";
    
    private String meteringServiceUrl = "";
    private String meteringServiceTokenUrl = "";
    private String meteringServiceClientId = "";
    private String meteringServiceClientSecret = "";
    private String meteringServiceRegion = "";
    
    private String kafkaUsername = "";
    private String kafkaPassword = "";
    private String kafkaServieUrl = "";

    private DriverManagerDataSource hanaDatasource;
    private Boolean hana = false;
    private String hanaSchema;

    private static Logger logger;

    @Override
    public String getCassandraHosts() {
        return cassandraHosts == null ? null : cassandraHosts;
    }

    @Override
    public String getCassandraUser() {
        return cassandraUser;
    }

    @Override
    public String getCassandraPassword() {
        return cassandraPassword;
    }

    @Override
    public Map<String, Object> getKafkaProducerConfig() {
        return kafkaProducerProperties;
    }

    @Override
    public Map<String, Object> getKafkaConsumerConfig() {
        return kafkaConsumerProperties;
    }

    @Override
    public String getZooKeeperConfig() {
        return this.zookeeperURL;
    }

    @Override
    public String getKafkaConfig() {
        return this.kafkaURL;
    }

    @Override
    public InetSocketAddress getElasticSearchHost() {
        return this.elasticSearchHost;
    }

    @Override
    public int getESPortForRest() {
        return this.elasticSearchPortForRest;
    }

    @Override
    public String getAwsEndPoint() {
        return this.awsEndPoint;
    }

    @Override
    public String getRoleArn() {
        return this.roleArn;
    }

    @Override
    public String getAccessKeyID() {
        return this.accessKeyID;
    }

    @Override
    public String getSecretAccessKey() {
        return this.secretAccessKey;
    }

    @Override
    public String getProxyHost() {
        return this.proxyHost;
    }

    @Override
    public int getProxyPort() {
        return this.proxyPort;
    }

    @Override
    public boolean getNeedAWSSign() {
        return this.needAWSSign;
    }

    @Override
    public String getAwsSignerRegion() {
        return this.awsSignerRegion;
    }

    @Override
    public int getKafkaNrOfReplication() {
        return 3;
    }

    @Override
    public String getCf_api() {
        return cf_api;
    }

    @Override
    public String getSpace_id() {
        return space_id;
    }
    
    @Override
    public String getSpace_name() {
        return space_name;
    }

    @Override
    public String getXSAppname() {
        return xsappname;
    }
    
    @Override
    public String getMeteringServiceUrl() {
        return meteringServiceUrl;
    }
    
    @Override
    public String getMeteringServiceTokenUrl() {
        return meteringServiceTokenUrl;
    }
    
    @Override
    public String getMeteringServiceClientId() {
        return meteringServiceClientId;
    }
    
    @Override
    public String getMeteringServiceClientSecret() {
        return meteringServiceClientSecret;
    }
    
    @Override
    public String getMeteringServiceRegion() {
		return meteringServiceRegion;
	}

    @Override
	public String getKafkaUsername() {
		return kafkaUsername;
	}

    @Override
	public String getKafkaPassword() {
		return kafkaPassword;
	}

    @Override
	public String getKafkaServieUrl() {
		return kafkaServieUrl;
	}

	public String getClientid() {
		return clientid;
	}

	public String getClientsecret() {
		return clientsecret;
	}

	public String getPaasAuthUrl() {
		return paasAuthUrl;
	}

	@Override
    public String getSecureTenant() {
        try {
            setSecureTenant(SecurityContext.getUserInfo().getIdentityZone());
        } catch (UserInfoException ex) {
            Util.warn(logger, "getSecureTenant - Fail to obtain the tenant.", ex);
        }
        Util.debug(logger, String.format("getSecureTenant - tenant:%s", userIdentityZone));
        return userIdentityZone;
    }
    
    @Override
    public String getOpsAppUrl() {
        return opsAppUrl;
    }

    @Override
    public String getScheduleCron() {
        return scheduleCron;
    }

    @Override
    public DriverManagerDataSource getHanaDataSource() {
        return hanaDatasource;
    }

    @Override
    public String getHanaSchema() {
        return hanaSchema;
    }

    private synchronized void setSecureTenant(final String tenant) {
        this.userIdentityZone = tenant;
    }

    /**
     * General Constructor - VCAP through System.getEnv()
     *
     * @throws IOException
     */
    public MeteringConfigurationCloud() throws IOException {
        String envVCAPServices = Environment.getEnvironmentServices("VCAP_SERVICES");
        String envVCAPApplication = Environment.getEnvironmentServices("VCAP_APPLICATION");
        String envOrgainzationId = Environment.getEnvironmentServices("organization_id");
        String envOpsAppUrl = Environment.getEnvironmentServices("OPS_APP_ROUTE");
        logger = LoggerFactory.getLogger(MeteringConfigurationCloud.class);
        Util.debug(logger, "Building from VCAP.");
        generateConfigurationFromJSON(envVCAPServices, envVCAPApplication, envOrgainzationId, envOpsAppUrl);
    }

    /**
     * Constructor for Spark - VCAP services through parameters.
     *
     * @param envVCAPServices The VCAP JSON in string
     * @param envVCAPApplication The VCAP JSON in string
     * @param envOrgainzationId The organizationId
     * @throws IOException
     */
    public MeteringConfigurationCloud(String envVCAPServices, String envVCAPApplication, String envOrgainzationId, String envOpsAppUrl) throws IOException {
        logger = LoggerFactory.getLogger(MeteringConfigurationCloud.class);
        Util.debug(logger, "Building from VCAP.");
        generateConfigurationFromJSON(envVCAPServices, envVCAPApplication, envOrgainzationId, envOpsAppUrl);
    }

    /**
     * Try to parse the JSON into Configuration. VCAP Structure example
     * src/main/resources/validVCAP.json
     *
     * @param envVCAPServices The VCAP JSON in string
     * @param envVCAPApplication The VCAP JSON in string
     * @param envOrgainzationId The organizationId
     * @throws UnknownHostException
     */
    private void generateConfigurationFromJSON(String envVCAPServices, String envVCAPApplication, String envOrgainzationId, String envOpsAppUrl) throws UnknownHostException {

        if (envVCAPServices != null) {
            Util.debug(logger, String.format("Length of VCAP_SERVICES is %d characters", envVCAPServices.length()));

            JsonObject vcapServicesObject = convertToJson(envVCAPServices);

            generateConfigurationFromUserPrivided(vcapServicesObject);
            generateConfigurationFromMeteringService(vcapServicesObject);
            generateConfigurationFromXSUAA(vcapServicesObject, envOrgainzationId, envOpsAppUrl);
            generateConfigurationFromHANA(vcapServicesObject);
            generateConfigurationFromKafka(vcapServicesObject);

            JsonArray cassandraObjects = vcapServicesObject.getAsJsonArray("cassandra");
            if (cassandraObjects != null) {
                for (int i = 0; i < cassandraObjects.size(); i++) {
                    JsonObject cassandraObject = cassandraObjects.get(i).getAsJsonObject();
                    if (cassandraObject.getAsJsonObject().get("instance_name").getAsString().
                            equals("cassandra-dedicated-instance") || i == cassandraObjects.size() - 1) {
                        setCassandraPropertiesVcapServices(cassandraObject.get("credentials").getAsJsonObject());
                    }
                }
            }
        }

        if (envVCAPApplication != null) {
            Util.debug(logger, String.format("Length of VCAP_APPLICATION is %s characters", envVCAPApplication.length()));
            JsonObject vcapApplicationObject = convertToJson(envVCAPApplication);
            generateConfigurationFromVCAPApp(vcapApplicationObject);
        }

        Util.debug(logger, (this.cassandra || this.kafka || this.hana) ? this.toString()
                : "No Valid VCAPConfig or C*, Kafka, Hana Service found!");
    }

    @Override
    public Boolean isCassandraSslEnabled() {
        return isCassandraSslEnabled;
    }

    @Override
    public Integer getCassandraPort() {
        return cassandraPort;
    }

    private Boolean isCassandraSslEnabled = false;
    private Integer cassandraPort = 9042;
    private void setCassandraPropertiesVcapServices(JsonObject cassandraCredentials) throws UnknownHostException {
        JsonArray seeds = cassandraCredentials.get("seeds").getAsJsonArray();
        if (Objects.nonNull(seeds)) {
            this.cassandraHosts = new String();
            for(JsonElement seed : seeds) {
                this.cassandraHosts += seed.getAsString() + ",";
            }

            cassandraHosts = StringUtils.trimTrailingCharacter(cassandraHosts, ',');
        }

        JsonArray protocols = cassandraCredentials.getAsJsonArray("protocols");
        if (Objects.nonNull(protocols)) {
            for (JsonElement protocol : protocols) {
                if (protocol.getAsString().equals("ssl")) {
                    this.isCassandraSslEnabled = true;
                    break;
                }
            }
        }

        this.cassandra = true;
        this.cassandraUser = cassandraCredentials.get("username") == null ? ""
                : cassandraCredentials.get("username").getAsString();
        this.cassandraPassword = cassandraCredentials.get("password") == null ? ""
                : cassandraCredentials.get("password").getAsString();
        this.cassandraPort = cassandraCredentials.get("port") == null ? 9042
                : cassandraCredentials.get("port").getAsInt();

    }

    private void generateConfigurationFromKafka(JsonObject vcapServiceObject) {
        JsonElement kafkaObject = vcapServiceObject.get("kafka");
        if (kafkaObject != null) {
            JsonObject kafkaCredentials = kafkaObject.getAsJsonArray().get(0).getAsJsonObject().get("credentials").getAsJsonObject();
            if (kafkaCredentials != null) {
                setKafkaProperties(kafkaCredentials);
                setKafkaRESTProperties(kafkaCredentials);
                this.kafkaServiceJson = kafkaCredentials;
                try {
                    buildKafkaConnectConfig(kafkaCredentials);
                } catch (IOException e) {
                    logger.error("call buildKafkaConnectConfig failed. {}", kafkaCredentials, e);
                }
            }
        }
    }

    private void generateConfigurationFromUserPrivided(JsonObject vcapServiceObject) throws UnknownHostException {
        JsonElement userElement = vcapServiceObject.get("user-provided");
        if (userElement != null) {

            for (JsonElement service : userElement.getAsJsonArray()) {
                if (service instanceof JsonObject) {
                    JsonObject serviceObject = (JsonObject) service;
                    if (serviceObject.get("name").getAsString().contains("cassandra")) {
                        JsonObject cassandraCredentials = serviceObject.get("credentials").getAsJsonObject();
                        setCassandraProperties(cassandraCredentials);
//                    }  else if (serviceObject.get("name").getAsString().equals("kafka-dedicated-instance")) {
//                        this.kafkaServiceJson = serviceObject;
//                        logger.info("Kafka service config found");
//                        //
//                        JsonObject kafkaCredentials = serviceObject.get("credentials").getAsJsonObject();
//                        setKafkaProperties(kafkaCredentials);

                    } else if (serviceObject.get("name").getAsString().contains("es-aws")) {
                        JsonObject elasticsearchCredentials = serviceObject.get("credentials").getAsJsonObject();
                        setAwsEndPoint(elasticsearchCredentials);
                        setRoleArn(elasticsearchCredentials);
                        setAccessKeyID(elasticsearchCredentials);
                        setSecretAccessKey(elasticsearchCredentials);
                        setNeedAWSSign(elasticsearchCredentials);
                        setAwsSignerRegion(elasticsearchCredentials);
                    }
                }
            }
        }
    }

    private void generateConfigurationFromHANA(JsonObject vcapServiceObject) throws UnknownHostException {

        JsonElement hanaObject = vcapServiceObject.get("hana");
        if (hanaObject != null) {
            JsonObject hanaCredentials = hanaObject.getAsJsonArray().get(0).getAsJsonObject().get("credentials").getAsJsonObject();
            if (hanaCredentials != null) {
                setHanaProperties(hanaCredentials);
            }
        }
    }
    
    private void generateConfigurationFromMeteringService(JsonObject envVCAPServicesObject) throws UnknownHostException {
        JsonElement meteringServiceElement = envVCAPServicesObject.get("metering-service");
        if (meteringServiceElement != null) {
            JsonObject credentials = meteringServiceElement.getAsJsonArray().get(0).getAsJsonObject().get("credentials").getAsJsonObject();
            setMeteringServiceValues(credentials);
        }
    }

    private void generateConfigurationFromXSUAA(JsonObject envVCAPServicesObject, String envOrgainzationId, String envOpsAppUrl) throws UnknownHostException {
        JsonElement xsuaaElement = envVCAPServicesObject.get("xsuaa");
        if (xsuaaElement != null) {
            JsonObject credentials = xsuaaElement.getAsJsonArray().get(0).getAsJsonObject().get("credentials").getAsJsonObject();
            setXSUAAInfos(credentials, envOrgainzationId, envOpsAppUrl);
        }
    }

    private void generateConfigurationFromVCAPApp(JsonObject vcapApplicationObject) throws UnknownHostException {
//        JsonElement vcapApplicationElement = vcapApplicationObject.get("VCAP_APPLICATION");
//        if (vcapApplicationElement != null) {
//            setVCAPApplicationValues(vcapApplicationElement.getAsJsonObject());
//        }
        if (vcapApplicationObject != null) {
            setVCAPApplicationValues(vcapApplicationObject);
        }
    }

    private void setXSUAAInfos(JsonObject xsuaaObject, String envOrgainzationId, String envOpsAppUrl) {
        this.xsappname = setValueFrom(xsuaaObject, "xsappname");
        this.clientid = setValueFrom(xsuaaObject, "clientid");
        this.clientsecret = setValueFrom(xsuaaObject, "clientsecret");
        this.paasAuthUrl = setValueFrom(xsuaaObject, "url");
        this.opsAppUrl = envOpsAppUrl;
    }

    private void setVCAPApplicationValues(JsonObject vcapApplicationObject) {
        this.cf_api = setValueFrom(vcapApplicationObject, "cf_api");
        this.space_id = setValueFrom(vcapApplicationObject, "space_id");
        this.space_name = setValueFrom(vcapApplicationObject, "space_name");
    }
    
    private void setMeteringServiceValues(JsonObject meteringServiceObject) {
        this.meteringServiceClientId = setValueFrom(meteringServiceObject, "clientid");
        this.meteringServiceClientSecret = setValueFrom(meteringServiceObject, "clientsecret");
        this.meteringServiceUrl = setValueFrom(meteringServiceObject, "metering_url")+"/usage/v2/usage/documents";
        this.meteringServiceTokenUrl = setValueFrom(meteringServiceObject, "token_url");
        this.meteringServiceRegion = setValueFrom(meteringServiceObject, "region");
    }

    private String setValueFrom(JsonObject meteringObject, String key) {
        return setValueFrom(meteringObject, key, null);
    }

    private String setValueFrom(JsonObject meteringObject, String key, String defaultValue) {
        if (meteringObject.has(key)) {
            return meteringObject.get(key).getAsString();
        }
        return defaultValue;
    }

    /**
     * Convert string into json
     *
     * @param jsonString
     * @return
     * @throws JsonSyntaxException
     */
    private JsonObject convertToJson(String jsonString) throws JsonSyntaxException {
        JsonObject jsonObject;
        try {
            jsonObject = new Gson().fromJson(jsonString, JsonObject.class);
        } catch (JsonSyntaxException | ClassCastException e) { // as a fallback if either it's malformed or not json object
            Util.warn(logger, "environment is not an object: ", e);
            JsonPrimitive jsonPrimitive = new Gson().fromJson(jsonString, JsonPrimitive.class);
            String jsonPrimitiveString = jsonPrimitive.getAsString();
            jsonObject = new Gson().fromJson(jsonPrimitiveString, JsonObject.class);
        }
        return jsonObject;
    }

    /**
     * Set the JSON C* Properties to the configuration.
     *
     * @param cassandraCredentials JsonObject with C* Properties
     */
    private void setCassandraProperties(JsonObject cassandraCredentials) throws UnknownHostException {
        Util.debug(logger, "Building Cassandra Properties.");
        JsonElement hostname = cassandraCredentials.get("hostname");
        if (hostname == null) {
            return;
        }

        this.cassandraHosts = hostname.getAsString();
        this.cassandra = true;
        this.cassandraUser = cassandraCredentials.get("username") == null ? ""
                : cassandraCredentials.get("username").getAsString();
        this.cassandraPassword = cassandraCredentials.get("password") == null ? ""
                : cassandraCredentials.get("password").getAsString();
    }

    /**
     * Set the JSON Kafka Properties to the configuration. Creates a Consumer
     * and Producer config. In the Kafka Credentials Host and Port are divided,
     * so they get concatenated together
     *
     * @param kafkaCredentials JsonObject with Kafka Properties
     */
    private void setKafkaProperties(JsonObject kafkaCredentials) {
//        Map<String, String> properties = this.getKafkaConnectConfig();

        if (kafkaCredentials.get("cluster") != null
                && kafkaCredentials.get("cluster").getAsJsonObject().get("brokers") != null) {
            Util.debug(logger, kafkaCredentials.get("cluster").getAsJsonObject().toString());
            this.kafkaProducerProperties = new HashMap<>();
            this.kafkaURL = kafkaCredentials.get("cluster").getAsJsonObject().get("brokers.auth_ssl").getAsString();
            this.kafkaProducerProperties.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, this.kafkaURL);

            this.kafkaProducerProperties.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,
                    "org.apache.kafka.common.serialization.StringSerializer");
            this.kafkaProducerProperties.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,
                    "org.apache.kafka.common.serialization.StringSerializer");
            this.kafkaProducerProperties.put("retries", 3);
            this.kafkaConsumerProperties = new HashMap<>();
            this.kafkaConsumerProperties.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, this.kafkaURL);

            this.kafkaConsumerProperties.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG,
                    "org.apache.kafka.common.serialization.StringDeserializer");
            this.kafkaConsumerProperties.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG,
                    "org.apache.kafka.common.serialization.StringDeserializer");
            //this.kafkaConsumerProperties.put(ConsumerConfig.GROUP_ID_CONFIG, "gtt_metering");
            this.kafkaConsumerProperties.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "false");
            this.kafkaConsumerProperties.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, 100);
            this.kafkaConsumerProperties.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "latest");
            //this.kafkaConsumerProperties.put(ConsumerConfig.AUTO_COMMIT_INTERVAL_MS_CONFIG, "1000");

//            properties.forEach((k, v) -> {
//                this.kafkaConsumerProperties.put(k, v);
//                this.kafkaProducerProperties.put(k, v);
//            });
            this.kafka = true;
        }

        if (kafkaCredentials.get("cluster") != null) {
            this.zookeeperURL = kafkaCredentials.get("cluster").getAsJsonObject().get("zk").getAsString();
            //System.out.println(">>>>>>> "+this.zookeeperURL);
            this.kafka = true;
        }
    }
    
    private void setKafkaRESTProperties(JsonObject kafkaCredentials) {
    	this.kafkaUsername = kafkaCredentials.get("username").getAsString();
    	this.kafkaPassword = kafkaCredentials.get("password").getAsString();
    	this.kafkaServieUrl = kafkaCredentials.getAsJsonObject("urls").get("service").getAsString();
    }

    /*
	 * Elastic search configuration
     */
    private void setAwsEndPoint(JsonObject config) {
        if (config.has("url")) {
            this.awsEndPoint = config.get("url").getAsString();
        }
        Util.debug(logger, this.awsEndPoint);

        if (config.has("restPort")) {
            this.elasticSearchPortForRest = config.get("restPort").getAsInt();
        } else {
            this.elasticSearchPortForRest = 443;
        }
    }

    private void setRoleArn(JsonObject config) {
        if (config.has("roleArn")) {
            this.roleArn = config.get("roleArn").getAsString();
        } else {
            roleArn = "arn:aws:iam::696472741845:role/delegate_es_account";
        }
        Util.debug(logger, this.roleArn);
    }

    private void setAccessKeyID(JsonObject config) {
        if (config.has("accessKeyId")) {
            this.accessKeyID = config.get("accessKeyId").getAsString();
        }
        Util.debug(logger, this.accessKeyID);
    }

    private void setSecretAccessKey(JsonObject config) {
        if (config.has("secretAccessKey")) {
            this.secretAccessKey = config.get("secretAccessKey").getAsString();
        }
        //logging of keys is usually prohibited
        //logger.debug(this.secretAccessKey);
    }

    private void setNeedAWSSign(JsonObject config) {
        if (config.has("needAWSSign")) {
            this.needAWSSign = config.get("needAWSSign").getAsBoolean();
        }
        Util.debug(logger, Boolean.toString(this.needAWSSign));

    }

    private void setAwsSignerRegion(JsonObject config) {
        if (config.has("awsSigner_region")) {
            this.awsSignerRegion = config.get("awsSigner_region").getAsString();
        } else {
            // default AWS region:
            this.awsSignerRegion = "eu-central-1";
        }
        Util.debug(logger, this.awsSignerRegion);
    }

    /**
     * Set the JSON Hana Properties to the configuration. Has two different
     * versions.
     *
     * @param hanaCredentials JsonObject with Hana Properties
     */
    private void setHanaProperties(JsonObject hanaCredentials) {
        final String url;
        String encryptParameter = "";
        try {
            Class.forName("com.sap.db.jdbc.Driver");
        } catch (final ClassNotFoundException e) {
            Util.error(logger, "No valid jdbc class found! \n" + Arrays.toString(e.getStackTrace()));
            return;
        }
        if (!(hanaCredentials.has("host") | hanaCredentials.has("hostname"))) {
            return;
        }
        
		if(hanaCredentials.has("url")) {
			encryptParameter = hanaCredentials.get("url").getAsString().contains("encrypt") ? "?encrypt=true&validateCertificate=false" : "";
		}
		
        if (hanaCredentials.has("host")) {
            url = "jdbc:sap://" + hanaCredentials.get("host").getAsString() + ":"
                    + hanaCredentials.get("port").getAsInt() + encryptParameter;;
        } else {
            url = "jdbc:sap://" + hanaCredentials.get("hostname").getAsString() + ":"
                    + hanaCredentials.get("port").getAsInt() + encryptParameter;;
        }

        final String username;
        if (hanaCredentials.has("username")) {
            username = hanaCredentials.get("username").getAsString();
        } else if (hanaCredentials.has("user")) {
            username = hanaCredentials.get("user").getAsString();
        } else {
            return;
        }

        this.hanaSchema = hanaCredentials.has("schema") ? hanaCredentials.get("schema").getAsString() : username;
        this.hanaDatasource = new DriverManagerDataSource(url, username, hanaCredentials.get("password").getAsString());
        this.hana = true;
    }

    @Override
    public synchronized  Map<String, String> getKafkaConnectConfig(){
        if (kafkaConnectConfig == null){
            try {
                this.kafkaConnectConfig = buildKafkaConnectConfig(this.kafkaServiceJson);
            } catch (IOException ex){
                throw new RuntimeException("Failed to build kafka connect config", ex);
            }
        }
        return this.kafkaConnectConfig;
    }

    private Map<String, String> buildKafkaConnectConfig(JsonObject credentials) throws IOException {

        logger.info("Building Kafka connection config");

        Map<String, String> config = new HashMap<>();

//        JsonObject credentials = jsonObject.getAsJsonObject("credentials");
        String brokers = credentials.getAsJsonObject("cluster").getAsJsonPrimitive("brokers.auth_ssl").getAsString();
        String username = credentials.getAsJsonPrimitive("username").getAsString();
        String password = credentials.getAsJsonPrimitive("password").getAsString();
        String tokenUrl = credentials.getAsJsonObject("urls").getAsJsonPrimitive("token").getAsString();

        logger.info("Trying to get token");
        String token = KafkaUtils.getToken(tokenUrl, username, password);
        logger.info("Token got");

        config.put(CommonClientConfigs.BOOTSTRAP_SERVERS_CONFIG, brokers);
        config.put(SaslConfigs.SASL_JAAS_CONFIG, KafkaUtils.buildJaasConfigString(username, token));

        logger.info("Copying truststore to temp file");
        // To-do: Make these things configurable, but configuration file or system environment variables for example
        Path tempFilePath;
        String os = System.getProperty("os.name");
        if (os != null && os.startsWith("Windows")) {
            tempFilePath = Files.createTempFile("temp-kafka-client-truststore", ".jks");
        } else {
            tempFilePath = Files.createTempFile("temp-kafka-client-truststore", ".jks", PosixFilePermissions
                    .asFileAttribute(PosixFilePermissions.fromString("rw-rw-r--")));
        }

        Files.copy(MeteringConfiguration.class.getClassLoader().getResource("kafka-client-truststore.jks").openStream(),
                tempFilePath, StandardCopyOption.REPLACE_EXISTING);

        logger.info("Temp truststore file {} copied", tempFilePath.toString());

        String kafkaTrustStorePath = tempFilePath.toAbsolutePath().toString();

        Runtime.getRuntime().addShutdownHook(
                new Thread(
                        () -> {
                            try {
                                Files.delete(tempFilePath);
                            } catch (IOException e) {
                                logger.error("Failed to delete temp file", e);
                            }
                        }
                )
        );

        config.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, kafkaTrustStorePath);
        config.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, "GTTCoreEngine1234");
        config.put(SaslConfigs.SASL_MECHANISM, "PLAIN");
        config.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, "SASL_SSL");

        return config;
    }

    @Override
    public String toString() {
        return "ConfigurationCloud [cassandraHosts=" + cassandraHosts + ", cassandra=" + cassandra
                + ", zookeeperURL=" + zookeeperURL + ", kafkaURL=" + kafkaURL + ", kafkaProducerProperties="
                + kafkaProducerProperties + ", kafka=" + kafka + ", elasticSearchHost=" + elasticSearchHost
                + ", elasticSearchPortForRest=" + elasticSearchPortForRest + ", awsEndPoint=" + awsEndPoint
                + ", roleArn=" + roleArn + ", needAWSSign=" + needAWSSign
                + ", awsSignerRegion=" + awsSignerRegion + ", cf_api=" + cf_api + ", space_id=" + space_id
                + ", xsappname=" + xsappname
                + ", tenant=" + userIdentityZone + ", email=" + email
                + ", hanaSchema=" + hanaSchema + "]";
    }

}
