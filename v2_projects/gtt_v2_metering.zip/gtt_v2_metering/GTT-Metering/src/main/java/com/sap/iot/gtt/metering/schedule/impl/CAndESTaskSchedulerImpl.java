/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.iot.gtt.metering.schedule.impl;

import com.sap.iot.gtt.metering.MeteringConfiguration;
import com.sap.iot.gtt.metering.exception.GTTMeteringException;
import com.sap.iot.gtt.metering.schedule.CAndESTaskScheduler;
import com.sap.iot.gtt.metering.service.HanaService;
import com.sap.iot.gtt.metering.service.Metering;
import com.sap.iot.gtt.metering.service.util.Util;
import java.util.Collection;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 *
 * @author I326335
 */
@Component
public class CAndESTaskSchedulerImpl implements CAndESTaskScheduler {

    private Logger logger = LoggerFactory.getLogger(CAndESTaskSchedulerImpl.class);

    @Autowired
    private Metering metering;
    @Autowired
    private Metering meteringService;
    @Autowired
    private HanaService hanaService;
    private MeteringConfiguration configuration;

    public CAndESTaskSchedulerImpl(MeteringConfiguration configuration) {
        this.configuration = configuration;
    }
    
    @Override
    @Scheduled(cron = "0 5 0 ? * *", zone = "UTC")
    public void triggerStorageUsagesSending() {
        Util.debug(logger, ">>> triggerStorageUsagesSending - start!");
        String xsappname = configuration.getXSAppname();
        String region = configuration.getMeteringServiceRegion();
        String cfSpaceName = configuration.getSpace_name();

        try {
            Collection<String> tenants = hanaService.getTenants();
            logger.debug(">>> tenants: {}", tenants);

            tenants.stream().forEach(tenant -> {
                try {
                    String topic = Util.generateFullTopicName(tenant, xsappname, "MaaS");
                    meteringService.start(topic);

                    logger.debug(">>> going to sendCassandraInfoToKafka to topic {}, for tenant {}", topic, tenant);
                    meteringService.sendCassandraInfoToKafka(topic, region, tenant, cfSpaceName);

                    logger.debug(">>> going to sendElasticSearchInfoToKafka to topic {}, for tenant {}", topic, tenant);
                    meteringService.sendElasticSearchInfoToKafka(topic, region, tenant, cfSpaceName, xsappname);
                } catch (GTTMeteringException ex) {
                    Util.warn(logger, ">>> Fail to send messages to Kafka.", ex);
                }
            });
        } catch (Exception ex) {
            Util.warn(logger, ">>> Fail to send messages to Kafka.", ex);
        }
        Util.debug(logger, ">>> triggerStorageUsagesSending - end!");
    }

}
