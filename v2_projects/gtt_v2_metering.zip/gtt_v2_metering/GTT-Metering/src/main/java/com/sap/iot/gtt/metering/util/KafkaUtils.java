package com.sap.iot.gtt.metering.util;

import com.google.gson.JsonParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.stream.Collectors;

/**
 * Kafka utils
 */
public class KafkaUtils {

    private static Logger logger = LoggerFactory.getLogger(KafkaUtils.class);

    public static final String JAAS_CONFIG_TEMPLATE = "org.apache.kafka.common.security.plain.PlainLoginModule required " +
            "username=\"%s\" password=\"%s\";";

    public static String buildJaasConfigString(String kUser, String kPwd){
        return String.format(JAAS_CONFIG_TEMPLATE, kUser, kPwd);
    }

    public static String getToken(String tokenUrl, String kUser, String kPwd) throws IOException {
        String authHeaderValue = "Basic " + Base64.getEncoder().encodeToString((kUser + ":" + kPwd).getBytes(StandardCharsets.UTF_8));
        String bodyParams = "grant_type=client_credentials";
        byte[] postData = bodyParams.getBytes(StandardCharsets.UTF_8);

        HttpURLConnection conn = (HttpURLConnection) new URL(tokenUrl).openConnection();
        DataOutputStream os = null;
        String resp = null;
        BufferedReader br = null;
        try {
            conn.setRequestProperty("Authorization", authHeaderValue);
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            conn.setRequestProperty("charset", "utf-8");
            conn.setRequestProperty("Content-Length", "" + postData.length);
            conn.setUseCaches(false);
            conn.setDoInput(true);
            conn.setDoOutput(true);
            os = new DataOutputStream(conn.getOutputStream());
            os.write(postData);
            br = new BufferedReader(new InputStreamReader(new DataInputStream(conn.getInputStream())));
            resp = br.lines().collect(Collectors.joining("\n"));

        } finally {
            if (os != null){
                try {
                    os.close();
                } catch (IOException ex) {
                    // Ignore the exception
                    logger.warn("Failed to close output stream", ex);
                }
            }

            if (br != null) {
                try {
                    br.close();
                } catch (IOException ex) {
                    // Ignore the exception
                    logger.warn("Failed to close bufferred reader", ex);
                }
            }
            try {
                conn.disconnect();
            } catch (Exception ex) {
                // Ignore the exception
                logger.warn("Failed to close connection", ex);
            }
        }

        return new JsonParser().parse(resp).getAsJsonObject().getAsJsonPrimitive("access_token").getAsString();
    }
}
