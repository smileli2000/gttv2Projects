/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.iot.gtt.metering.service.impl;

import com.sap.iot.gtt.metering.MeteringConfiguration;
import com.sap.iot.gtt.metering.MeteringConnection;
import com.sap.iot.gtt.metering.exception.GTTMeteringException;
import com.sap.iot.gtt.metering.service.KafkaTopic;
import com.sap.iot.gtt.metering.service.util.Util;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Properties;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import kafka.admin.AdminUtils;
import kafka.admin.RackAwareMode;
import kafka.utils.ZkUtils;
import org.I0Itec.zkclient.ZkClient;
import org.I0Itec.zkclient.ZkConnection;
import org.apache.cxf.jaxrs.client.WebClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

/**
 *
 * @author I326335
 */
@Component
public class KafkaTopicImpl implements KafkaTopic {

    private int noOfPartitions = 5;
    private final int RETENTION_IN_DAYS = 14;
    private Logger logger = LoggerFactory.getLogger(KafkaTopicImpl.class);
    private ZkClient zkClient;

    private MeteringConfiguration configuration;
    private MeteringConnection connection;
    
    @Autowired
    public KafkaTopicImpl(MeteringConfiguration configuration, MeteringConnection connection) throws GTTMeteringException {
        this.configuration = configuration;
        this.connection = connection;
        start();
    }

    /**
     * Start a ZooKeeper client
     *
     * @throws GTTMeteringException
     */
    //@Override
    private void start() throws GTTMeteringException {
        Util.debug(logger, "start - start! zkClient != null:{}", zkClient != null);
        if (zkClient != null) {
            Util.debug(logger, "start - end!");
            return;
        }

        try {
            setZKClient(connection.createZooKeeperClient());
        } catch (GTTMeteringException ex) {
            Util.error(logger, "start - end. ZooKeeperClient creating failed.");
            throw new GTTMeteringException("ZooKeeperClient creating failed.", ex);
        }
        Util.debug(logger, "start - end!");
    }

    /**
     * Check whether topic exists. When not, create it.
     *
     * @param topic
     * @return
     */
    @Override
    public boolean checkAndCreateTopic(String topic) throws GTTMeteringException {
        Util.debug(logger, "checkAndCreateTopic - start! topic:{}", topic);
        boolean isSecureKafkaCluster = true;
        boolean isExisted = true;

        // https://kafka.apache.org/documentation.html#topic-config
        Properties topicConfiguration = new Properties();
        int retentionHours = RETENTION_IN_DAYS * 24;

        try {
            topicConfiguration.setProperty("retention.ms", String.valueOf(retentionHours * 60 * 60 * 1000));
            ZkUtils zkUtils = new ZkUtils(zkClient, new ZkConnection(configuration.getZooKeeperConfig()), isSecureKafkaCluster);

            if (!AdminUtils.topicExists(zkUtils, topic)) {
                Util.debug(logger,
                        "Creating Kafka with {} partitions, {} replications, and configuration = {}",
                        new Object[]{noOfPartitions, configuration.getKafkaNrOfReplication(), topicConfiguration});
                AdminUtils.createTopic(zkUtils, topic, noOfPartitions, configuration.getKafkaNrOfReplication(), topicConfiguration, RackAwareMode.Enforced$.MODULE$);
                isExisted = false;
            }
        } catch (Exception e) {
            Util.error(logger, "checkAndCreateTopic - end! Failed to check and create topic.");
//            throw new GTTMeteringException("Failed to check and create topic.", e);
        }
        Util.debug(logger, "checkAndCreateTopic - end!");
        return isExisted;
    }
    
    @Override
    @Cacheable("createdFlag")
    public boolean createTopic(String topic){
        boolean created = false;
        int status = 0;
        String kafkaUsername = configuration.getKafkaUsername();
        String kafkaPwd = configuration.getKafkaPassword();
        String kafkaServiceUrl = configuration.getKafkaServieUrl();
        String usagePayload = "{\"partitions\": 5, \"replicationFactor\": 1}";
        String usageErrorPayload = "{\"partitions\": 1, \"replicationFactor\": 1}";
        
        WebClient webClient = WebClient.create(kafkaServiceUrl+"/topics");
        webClient.header("Authorization", "Basic "+Base64.getEncoder().encodeToString((kafkaUsername + ":" + kafkaPwd).getBytes(StandardCharsets.UTF_8)))
        		 .header("Slug", topic)
        		 .header("Content-Type", MediaType.APPLICATION_JSON);
        if(topic.contains("Error")){
        	Response response = webClient.post(usageErrorPayload);
        	status = response.getStatus();
        }else{
        	Response response = webClient.post(usagePayload);
        	status = response.getStatus();
        }

        if(status == 201 || status == 409){	// NOTE: need to add retry logic later, if it's not 201 or 409
        	created = true;
        	logger.debug(">>> Created topic via Kafka service OK. (Or it's already existed)");
        }
        webClient.close();

        return created;
    }

    private synchronized void setZKClient(final ZkClient zkClient) {
        this.zkClient = zkClient;
    }
}
