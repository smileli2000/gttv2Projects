/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.iot.gtt.metering.service.util;

import java.io.IOException;
import java.io.InputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author I326335
 */
public class InputStreamUtil {

    private static final Logger LOG = LoggerFactory.getLogger(InputStreamUtil.class);

    protected InputStreamUtil() {
        throw new IllegalStateException("Utility class");
    }

    /**
     * Safely close the input stream
     *
     * @param is The input stream
     */
    public static void safeClose(InputStream is) {
        if (is != null) {
            try {
                is.close();
            } catch (IOException e) {
                LOG.error("InputStream close error!", e);
            }
        }
    }
}
