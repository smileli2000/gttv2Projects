/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.iot.gtt.metering.service.impl;

import com.google.common.collect.Lists;
import com.sap.iot.gtt.metering.MeteringConnection;
import com.sap.iot.gtt.metering.exception.GTTMeteringException;
import com.sap.iot.gtt.metering.service.KafkaReceiver;
import com.sap.iot.gtt.metering.service.util.Util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.OffsetAndMetadata;
import org.apache.kafka.common.TopicPartition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 *
 * @author I326335
 */
@Component
public class KafkaReceiverImpl implements KafkaReceiver {

    private Logger logger = LoggerFactory.getLogger(KafkaReceiverImpl.class);

    private final static int FETCH_BATCH_SIZE = 100;

    private MeteringConnection connection;

    protected Map<String, Consumer<String, String>> consumers;
    private Map<String, List<ConsumerRecord<String, String>>> recordLists;
    private Map<String, Integer> isChangeds;

    @Autowired
    public KafkaReceiverImpl(MeteringConnection connection) {
        this.connection = connection;
        consumers = new HashMap<>();
        recordLists = new HashMap<>();
        isChangeds = new HashMap<>();
    }

    /**
     * Start kafka consumer for specific topic
     *
     * @param topic
     * @throws GTTMeteringException
     */
    @Override
    public void start(String topic) throws GTTMeteringException {
        Util.debug(logger, String.format("start - start! topic:%s consumers.containsKey(topic):%s", topic, consumers.containsKey(topic)));

        //if existed, clear
        if (recordLists.containsKey(topic)) {
            recordLists.get(topic).clear();
            recordLists.put(topic, new ArrayList<>());
        }

        //clear the changed number
        isChangeds.put(topic, 0);

        //if existed, return
        if (!isClose(topic)) {
            Util.debug(logger, "start - end! consumers.containsKey(topic):{}", consumers.containsKey(topic));
            return;
        }

        Util.debug(logger, "start - connection.createKafkaConsumer()");
        Consumer<String, String> consumer = connection.createKafkaConsumer(topic);
        Util.debug(logger, "start - consumer.subscribe()");
        consumer.subscribe(Arrays.asList(topic));

        try {
            //if kafka server is down, connection refused error offten happens here
            Util.debug(logger, "start - consumer.poll()");
            consumer.poll(0);
        } catch (Exception e) {
            Util.warn(logger, "start - fail to start the heart health check.", e);
            //throw new GTTMeteringException("Consumer creation and subscribe failed.", e);
        }
        consumers.put(topic, consumer);
        checkAndCommitToEnd(topic);
        Util.debug(logger, "start - end!");
    }

    /**
     * Receive usages from specific topic
     *
     * @param topic
     * @param minBatchSize
     * @return
     * @throws GTTMeteringException
     */
    @Override
    public List<String> receive(String topic, int minBatchSize) throws GTTMeteringException {
        Util.debug(logger, String.format("receive - start! topic:%s consumers.containsKey(topic):%s", topic, consumers.containsKey(topic)));

        List<String> buffer = new ArrayList<>();

        //if no consumer, return
        if (isClose(topic)) {
            Util.debug(logger, "receive - end!");
            return buffer;
        }

        //if existed, clear
        if (recordLists.containsKey(topic)) {
            recordLists.get(topic).clear();
        }

        //intialize these two variables
        recordLists.put(topic, new ArrayList<>());
        isChangeds.put(topic, 0);

        int loop = 0;
        try {
            long totalCount = seekToCommittedEnd(topic, false);

            while (true) {
                ConsumerRecords<String, String> records = consumers.get(topic).poll(FETCH_BATCH_SIZE);
                Util.debug(logger, String.format("receive - poll index:%d count:%d topic:%s", loop, records.count(), topic));
                if (loop > 5 && records.count() == 0) {
                    break;
                }
                loop++;
                //logger.debug(String.format("receive - poll 2 index:%d count:%d", loop, records.count()));
                if (records.count() > 0) {
                    int existedSize = recordLists.get(topic).size();
                    int newSize = records.count();
                    //only obtain data of size [minBatchSize]
                    recordLists.get(topic).addAll(Lists.newArrayList(records).subList(0, existedSize + newSize <= minBatchSize ? newSize : minBatchSize - existedSize));
                }
                isChangeds.put(topic, recordLists.get(topic).size());
                if (recordLists.get(topic).size() >= minBatchSize) {
                    break;
                }
            }
            //Sort by partition and offset
            Collections.sort(recordLists.get(topic), (ConsumerRecord<String, String> a, ConsumerRecord<String, String> b) -> {
                if (a.partition() == b.partition()) {
                    return Integer.valueOf(String.valueOf(a.offset() - b.offset()));
                } else {
                    return a.partition() - b.partition();
                }
            });
            buffer = recordLists.get(topic).stream().map(ConsumerRecord<String, String>::value).collect(Collectors.toList());
            
            buffer = setToNextOffset(totalCount, buffer, topic, minBatchSize);
        } catch (Exception e) {
            Util.error(logger, "receive - end! Fail to receive the messages from kafka.");
            throw new GTTMeteringException("Consumer failed to poll messages.", e);
        }
        Util.debug(logger, String.format("receive - recordList.size:%s buffer.size:%s topic:%s", recordLists.get(topic).size(), buffer.size(), topic));
        Util.debug(logger, "receive - end! topic:{}", topic);
        return buffer;
    }

    /**
     * Commit kafka offset of sended usage
     *
     * @param topic
     * @param index
     */
    @Override
    public void commit(final String topic, final Integer index) {
        Util.debug(logger, String.format("commit - start! topic:%s isChanged:%s index:%s", topic, isChangeds.get(topic), index));
        if (isChangeds.get(topic) > 0) {
            //consumer.commitAsync();
            if (index < recordLists.get(topic).size()) {
                ConsumerRecord<String, String> record = recordLists.get(topic).get(index);
                Util.debug(logger, String.format("commit - topic:%s partition:%s offset:%s value:%s", topic, record.partition(), record.offset(), record.value().replace("\n", "")));
                long lastOffset = record.offset();
                consumers.get(topic).commitSync(Collections.singletonMap(new TopicPartition(topic, record.partition()), new OffsetAndMetadata(lastOffset + 1)));
                isChangeds.put(topic, isChangeds.get(topic) - 1);
            }
        }
        Util.debug(logger, "commit - end! topic:%s", topic);
    }

    /**
     * Check if consumer for specific topic exists
     *
     * @param topic
     * @return
     */
    @Override
    public boolean isClose(String topic) {
        Util.debug(logger, String.format("isClose - topic:%s isClose:%s", topic, !consumers.containsKey(topic)));
        return !consumers.containsKey(topic);
    }

    /**
     * Close specific topic consumer
     *
     * @param topic
     */
    @Override
    public void close(String topic) {
        Util.debug(logger, String.format("close - start! topic:%s consumers.containsKey(topic):%s", topic, consumers.containsKey(topic)));
        if (consumers.containsKey(topic)) {
            consumers.get(topic).close();
            consumers.remove(topic);
        }
        Util.debug(logger, "close - end!");
    }

    /**
     * Commit to the beginning without committed offset.
     *
     * @param topic
     */
    private void checkAndCommitToEnd(final String topic) {
        Set<TopicPartition> topicPartitions = consumers.get(topic).assignment();
        Map<TopicPartition, Long> beginningOffsets = consumers.get(topic).beginningOffsets(topicPartitions);
        Map<TopicPartition, Long> endOffsets = consumers.get(topic).endOffsets(topicPartitions);
        topicPartitions.stream().forEach(topicPartition -> {
            if (consumers.get(topic).committed(topicPartition) == null) {
                Util.debug(logger, String.format("checkAndCommitToEnd - uncommitted! topic:%s partition:%d offset:%d beginningOffset:%d endOffset:%d",
                        topic, topicPartition.partition(), 0, beginningOffsets.get(topicPartition), endOffsets.get(topicPartition)));
                consumers.get(topic).commitSync(Collections.singletonMap(topicPartition, new OffsetAndMetadata(beginningOffsets.get(topicPartition))));
            } else {
                Util.debug(logger, String.format("checkAndCommitToEnd - topic:%s partition:%d offset:%d beginningOffset:%d endOffset:%d",
                        topic, topicPartition.partition(), consumers.get(topic).committed(topicPartition).offset(), beginningOffsets.get(topicPartition), endOffsets.get(topicPartition)));
            }
        });
    }

    /**
     * Seek from last committed offset.
     *
     * @param topic
     * @param skipToNext
     */
    protected long seekToCommittedEnd(final String topic, final Boolean skipToNext) {
        Set<TopicPartition> topicPartitions = consumers.get(topic).assignment();
        Map<TopicPartition, Long> beginningOffsets = consumers.get(topic).beginningOffsets(topicPartitions);
        Map<TopicPartition, Long> endOffsets = consumers.get(topic).endOffsets(topicPartitions);
        final long[] totalCount = {0L};
        topicPartitions.stream().forEach(topicPartition -> {
            if (consumers.get(topic).committed(topicPartition) != null ) {
                totalCount[0] += setWithCommitedOffset(topic, skipToNext, consumers.get(topic).committed(topicPartition).offset(), 
                        beginningOffsets.get(topicPartition), endOffsets.get(topicPartition), topicPartition);
            } else {
                totalCount[0] += setWithCommitedOffset(topic, skipToNext, 0, beginningOffsets.get(topicPartition), endOffsets.get(topicPartition), topicPartition);
            }
        });
        return totalCount[0];
    }

    protected long setWithCommitedOffset(final String topic, final Boolean skipToNext, long commitedOffset, long beginningOffset, long endOffset, TopicPartition topicPartition) {

        if (commitedOffset < beginningOffset) {

            Util.debug(logger, String.format("committed offSet is illegal:" + commitedOffset));
            commitedOffset = beginningOffset;
        }

        long offset = (skipToNext && commitedOffset < endOffset) ?
                commitedOffset + 1 : commitedOffset;
        Util.debug(logger, String.format("seekToCommittedEnd - topic:%s partition:%d offset:%d beginningOffset:%d endOffset:%d",
                topic, topicPartition.partition(), offset, beginningOffset, endOffset));
        consumers.get(topic).seek(topicPartition, offset);
        if (skipToNext) {
            consumers.get(topic).commitSync(Collections.singletonMap(topicPartition, new OffsetAndMetadata(offset)));
        }
        return endOffset - offset;
    }
    
    protected List<String> setToNextOffset(long totalCount, List<String> buffer, String topic, int minBatchSize) throws GTTMeteringException {
        //Cannot receive any message while having messages,then set offset to next point
        if (totalCount > 0 && buffer.isEmpty()) {
            seekToCommittedEnd(topic, true);
            buffer = receive(topic, minBatchSize);
        }
        return buffer;
    }
}
