/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.iot.gtt.metering.service.json;

import com.sap.iot.gtt.metering.service.util.InputStreamUtil;
import com.sap.iot.gtt.metering.service.util.Util;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author I326335
 */
public class UsageJsonHelper {

    private static final Logger LOG = LoggerFactory.getLogger(UsageJsonHelper.class);

    private static final String PATH = "json_template/metering_template";
    private static final String PATH_USAGE = "json_template/measured_usage_template";
    private static final String PATH_BATCH_USAGE = "json_template/metering_batch_template";
    
    private static final String METERING_SERVICE_MEASURE_TEMPLATE = "json_template/metering_service_measure_template";
    private static final String METERING_SERVICE_USAGE_TEMPLATE = "json_template/metering_service_usage_template";
    private static final String METERING_SERVICE_BATCH_USAGE_TEMPLATE = "json_template/metering_service_batch_template";
    private static final String[] CONVERT_BYTE2GIGABYTE_MEASURES = {"JSON_insert_size", "tracked_process_read_search_size", "storage_consumption_elasticsearch", "storage_consumption_cassandra"};
    private static final String[] DOCUMENT_MEASURES = {"tracked_process_insert_count", "event_insert_count"};
    
    public static String generateMeteringServiceUsageJson(String start, String region, String subAccount, String cfSpaceName, Map<String, String> measured) throws IOException {
        List<String> usages = new ArrayList<>();
        measured.entrySet().stream().forEach(usage -> {
            try {
            	String measureKey = usage.getKey();
            	String measureValue = usage.getValue();
            	// Transform bytes to giga-bytes for storage measures
            	if(Arrays.stream(CONVERT_BYTE2GIGABYTE_MEASURES).anyMatch(measureKey::equals)){
            		measureValue =  String.format("%.10f", Double.valueOf(measureValue)/1073741824);
            	}
            	// Put either tracked-processes or events usage to document_insert_count measure as well
            	if(Arrays.stream(DOCUMENT_MEASURES).anyMatch(measureKey::equals)){
            		usages.add(String.format("%s", getJson(METERING_SERVICE_MEASURE_TEMPLATE, createUsageProperties("document_insert_count", measureValue))));
            	}
                usages.add(String.format("%s", getJson(METERING_SERVICE_MEASURE_TEMPLATE, createUsageProperties(measureKey, measureValue))));
            } catch (IOException ex) {
                LOG.error("Generate Usage Json with property failed.", ex);
            }
        });
        return getJson(METERING_SERVICE_USAGE_TEMPLATE, createProperties(start, region, subAccount, cfSpaceName, String.join(",", usages)));
    }
    
    public static String generateBatchUsageJson(String collectorUrl, List<String> usages) throws IOException {
        List<String> batchUsages = new ArrayList<>();
        usages.stream().forEach(usage -> {
            try {
                batchUsages.add(String.format("%s", getJson(PATH_BATCH_USAGE, createBatchUsageProperties(collectorUrl, usage))));
            } catch (IOException ex) {
                LOG.error("Generate Usage Json with property failed.", ex);
            }
        });
        return Util.getJSONArray(batchUsages).toString().replace("\\/", "/");
    }
    
    public static String generateBatchMeteringServiceUsageJson(List<String> usages) throws IOException {
        String batchUsages = "";
        try {
            batchUsages = String.format("%s", getJson(METERING_SERVICE_BATCH_USAGE_TEMPLATE, createMeteringServiceBatchUsageProperties(usages.toString())));
        } catch (IOException ex) {
            LOG.error(">>> Generate Usage Json with property failed, MaaS", ex);
        }

        return batchUsages.replace("\\/", "/");
    }
    
    private static String getJson(String path, Properties props) throws IOException {
        InputStream jsonTemplate = null;
        String pattern = "";
        try {
            jsonTemplate = Util.readClassPathResourceAsStream(path);
            pattern = IOUtils.toString(jsonTemplate, StandardCharsets.UTF_8);
        } finally {
            if (jsonTemplate != null) {
                InputStreamUtil.safeClose(jsonTemplate);
            }
        }

        return Util.replace(pattern, props);
    }
    
    private static Properties createProperties(String start, String region, String subAccount, String cfSpaceName, String usages) {
        Properties props = new Properties();
        setPropertyValue(props, "start", start);
        setPropertyValue(props, "region", region);
        setPropertyValue(props, "subAccount", subAccount);
        setPropertyValue(props, "cfSpaceName", cfSpaceName);
        setPropertyValue(props, "metering_service_usages", usages);
        return props;
    }

    private static void setPropertyValue(Properties props, String key, String value) {
        props.put(key, value != null ? value : "");
    }
    
    private static Properties createUsageProperties(String measure, String quantity) {
        Properties props = new Properties();
        props.put("measure", measure);
        props.put("quantity", quantity);
        return props;
    }
    
    private static Properties createBatchUsageProperties(String collectorUrl, String usage) {
        Properties props = new Properties();
        props.put("colllector_url", collectorUrl);
        props.put("usage_json", usage);
        return props;
    }
    
    private static Properties createMeteringServiceBatchUsageProperties(String usage) {
        Properties props = new Properties();
        props.put("usage_json", usage);
        return props;
    }
}
