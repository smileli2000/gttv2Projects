/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.iot.gtt.metering.service.impl;

import com.datastax.driver.core.*;
import com.datastax.driver.core.querybuilder.QueryBuilder;
import com.datastax.driver.core.querybuilder.Select;
import com.sap.iot.gtt.metering.MeteringConfiguration;
import com.sap.iot.gtt.metering.MeteringConnection;
import com.sap.iot.gtt.metering.exception.GTTMeteringException;
import com.sap.iot.gtt.metering.service.Cassandra;
import com.sap.iot.gtt.metering.util.OAuthToken;
import com.sap.iot.gtt.metering.util.WebClientUtil;

import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import static com.datastax.driver.core.querybuilder.QueryBuilder.desc;
import static com.datastax.driver.core.querybuilder.QueryBuilder.eq;

import javax.ws.rs.core.Response;

/**
 *
 * @author I326335
 */
@Component
public class CassandraImpl implements Cassandra {

    private static Logger logger = LoggerFactory.getLogger(CassandraImpl.class);
    private OAuthToken oauthToken = new OAuthToken();
    private WebClientUtil webClientUtil = new WebClientUtil();
    
    @Autowired
    private MeteringConnection connection;

    @Autowired
    public CassandraImpl(MeteringConnection connection) {
        this.connection = connection;
    }
    
    @Autowired
    private MeteringConfiguration configuration;

    private static final String KEYSPACE_SYSTEM_LOG_STATS = "system_log_stats";
    private static final String TABLE_KEYSPACE_SIZES = "keyspaces_sizes";

    @Override
    public String getSpaceSize(String tenant) throws GTTMeteringException {
        try (Cluster cluster = connection.createCassandraCluster()) {
            String keySpaceName = getKeyspaceName(configuration.getXSAppname(), tenant);
            logger.debug("keySpaceName: {}", keySpaceName);
            //"tt_integrationt1_testsandbox";
            String keySpaceNameEx = "Keyspace." + keySpaceName + ".Live";
            logger.debug("keySpaceNameEx: {}", keySpaceNameEx);

            Session session = cluster.connect();
            PreparedStatement selectKeyspaceSizeStatement = prepareSelectKeyspaceSizeStatement(session);

            BoundStatement boundSelect = selectKeyspaceSizeStatement.bind()
                    .setString(0, keySpaceNameEx);
            
            Row row = session.execute(boundSelect).one();
            Long size = -1L;
            if (row == null) {
                keySpaceNameEx = "Keyspace." + keySpaceName + ".Total";
                boundSelect = selectKeyspaceSizeStatement.bind()
                        .setString(0, keySpaceNameEx);
                row = session.execute(boundSelect).one();
                if (row != null) {
                    size = row.getLong(0);
                }

            } else {
                size = row.getLong(0);
            }

            Long sizeInMb = size/1024/1024;
            logger.debug("size of keyspace {}: {}MB", keySpaceName, sizeInMb);

            return size.toString();

        } catch (Exception e) {
            logger.error("getSpaceSize() failed. ", e);
            throw new GTTMeteringException("getSpaceSize() failed.", e);
        }

    }

    private static PreparedStatement prepareSelectKeyspaceSizeStatement(final Session session) {
        logger.info("entering prepareSelectKeyspaceSizeStatement.");
        final Select selectStatement = QueryBuilder.select()
                .column("size_byte")
                .from(KEYSPACE_SYSTEM_LOG_STATS, TABLE_KEYSPACE_SIZES) //Define keyspace explicitly!
                .where(eq("keyspace_name", QueryBuilder.bindMarker()))
                .limit(1)
                .orderBy(desc("timestamp_sec"));

        logger.info("selectStatement: {}", selectStatement);

        return session.prepare(selectStatement)
                .setConsistencyLevel(ConsistencyLevel.LOCAL_ONE);
    }

    private String getKeyspaceName(String xsappname, String tenantId) throws GTTMeteringException, JSONException {       
        String keyspaceName = "";
        String tenantShortID = getTenantShortID(tenantId);
        keyspaceName = xsappname.replace("!", "") + "_" + tenantShortID.replace("-", "").toLowerCase();
        logger.info(">>>>>>> KeyspaceName for xsappname:{}, tenantId:{} is {}", xsappname, tenantId, keyspaceName);
        return keyspaceName;
    }
    
    private String getTenantShortID(String tenantUUID) throws GTTMeteringException, JSONException {
    	String clientId = configuration.getClientid();
    	String clientSecret = configuration.getClientsecret();
    	String opsAppUrl = configuration.getOpsAppUrl()+"/ops/tenantConfig/"+tenantUUID+"/tenantShortID";
    	String accessToken = oauthToken.getToken(configuration, connection, "XSUAA_ClientCredentials", clientId, clientSecret);
        
        Response response = webClientUtil.get(opsAppUrl, accessToken);
        
        String responseString = response.readEntity(String.class);
        JSONObject jsonResponse = new JSONObject(responseString);
    	
        return jsonResponse.getString("tenantShortID");
    }

}
