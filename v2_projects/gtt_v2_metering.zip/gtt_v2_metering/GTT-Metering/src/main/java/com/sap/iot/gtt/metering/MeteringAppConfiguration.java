/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.iot.gtt.metering;

import com.sap.iot.gtt.metering.exception.GTTMeteringException;
import com.sap.iot.gtt.metering.service.Metering;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

/**
 *
 * @author I326335
 */
@Configuration
@ComponentScan(basePackageClasses = {MeteringConnection.class})
public class MeteringAppConfiguration {

    @Autowired
    MeteringConfiguration configuration;

    @Autowired
    MeteringConnection connection;

    @Autowired
    Metering metering;

    @Bean
    public JdbcTemplate getJdbc() throws GTTMeteringException {
        return connection.createHanaJdbcTemplate();
    }

}
