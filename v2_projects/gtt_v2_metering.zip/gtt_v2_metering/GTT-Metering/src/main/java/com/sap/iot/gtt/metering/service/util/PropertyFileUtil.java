/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.iot.gtt.metering.service.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * @author I326335
 */
public class PropertyFileUtil {
	private static final Logger LOG = LoggerFactory.getLogger(PropertyFileUtil.class);

	private static final String SETTINGS_PROPERTY_FILE = "setting.properties";
	private static Properties settings;

	static {
		try {
			settings = readPropertyFile(SETTINGS_PROPERTY_FILE);
		} catch (IOException e) {
			LOG.error("Cannot open settings properties.", e);
		}
	}

	public static String getProperty(String key) {
		return settings.containsKey(key) ? settings.getProperty(key) : "";
	}

	/**
	 * Read property from a file
	 * @param filePath The file path
	 * @return The properties
	 * @throws IOException
	 *     The IO exception
	 */
	public static Properties readPropertyFile(String filePath) throws IOException {
		Properties prop = new Properties();
		InputStream in = null;
		try {
			in = Thread.currentThread().getContextClassLoader().getResourceAsStream(filePath);
			if (in != null) {
				prop.load(in);
			}
		} finally {
			if (in != null) {
				InputStreamUtil.safeClose(in);
			}
		}

		return prop;
	}

}
