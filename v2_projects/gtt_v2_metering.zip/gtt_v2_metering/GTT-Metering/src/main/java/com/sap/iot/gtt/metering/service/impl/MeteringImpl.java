/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.iot.gtt.metering.service.impl;

import com.sap.iot.gtt.metering.MeteringConfiguration;
import com.sap.iot.gtt.metering.exception.GTTMeteringException;
import com.sap.iot.gtt.metering.service.Cassandra;
import com.sap.iot.gtt.metering.service.ElasticSearch;
import com.sap.iot.gtt.metering.service.KafkaReceiver;
import com.sap.iot.gtt.metering.service.KafkaSender;
import com.sap.iot.gtt.metering.service.KafkaTopic;
import com.sap.iot.gtt.metering.service.Metering;
import com.sap.iot.gtt.metering.service.json.UsageJsonHelper;
import com.sap.iot.gtt.metering.service.util.Util;
import com.sap.iot.gtt.metering.usage.Usage;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

/**
 *
 * @author I326335
 */
@Component
public class MeteringImpl implements Metering {

    private Logger logger = LoggerFactory.getLogger(MeteringImpl.class);

    @Autowired
    private Cassandra cassandra;
    @Autowired
    private ElasticSearch elasticSearch;
    @Autowired
    private Usage usage;

    private MeteringConfiguration configuration;

    private KafkaSender sender;
    private KafkaReceiver receiver;
    @Autowired
    private KafkaTopic kafkaTopic;

    private Map<String, Boolean> isSendings;
    private List<String> topics;

    @Autowired
    protected MeteringImpl(MeteringConfiguration configuration, KafkaSender sender, KafkaReceiver receiver, KafkaTopic kafkaTopic) throws GTTMeteringException {
        this.configuration = configuration;
        this.sender = sender;
        this.receiver = receiver;
        this.kafkaTopic = kafkaTopic;
        this.isSendings = new HashMap<>();
        this.topics = new ArrayList<>();
    }
    
    @Override
    public Boolean sendConnectivityInfoToKafka(String topic, String region, String subAccount, String cfSpaceName, Map<String, Object> jsonMap) throws GTTMeteringException {
        Util.debug(logger, ">>> sendConnectivityInfoToKafka, MaaS - start! region:{} subAccount:{} cfSapceName:{} json:{}",
                new Object[]{region,  subAccount, cfSpaceName, jsonMap});
        try {
            Map<String, String> measured = Util.addUsageInfoToMap(jsonMap.get("input"));
            
            String timeStamp = Util.getUTCTimeString();
            String usageJsonString = UsageJsonHelper.generateMeteringServiceUsageJson(timeStamp, region, subAccount, cfSpaceName, measured);
            Util.debug(logger, ">>> usageJsonString: {}", usageJsonString);
            sender.send(topic, usageJsonString);
            Util.debug(logger, ">>> sendConnectivityInfoToKafka, MaaS - end!");
            return true;
        } catch (Exception ex) {
            Util.error(logger, ">>> Sending connectivity usage information to kafka failed, MaaS");
            throw new GTTMeteringException(">>> Sending connectivity usage information to kafka failed, MaaS", ex);
        }
    }
    
    @Override
    public Boolean sendODataInfoToKafka(String topic, String region, String subAccount, String cfSpaceName, Map<String, Object> jsonMap) throws GTTMeteringException {
        Util.debug(logger, ">>> sendODataInfoToKafka, MaaS - start! region:{} subAccount:{} cfSpaceName:{} json:{}",
                new Object[]{region, subAccount, cfSpaceName, jsonMap});
        try {
            Map<String, Object> inputJsonMap = jsonMap.get("input") instanceof Map ? (Map<String, Object>) jsonMap.get("input") : new HashMap<>();
            Map<String, String> measured = new HashMap<>();
            inputJsonMap.entrySet().stream().forEach(entry -> {
                String quantity = String.valueOf(entry.getValue());
                measured.put(entry.getKey(), quantity.indexOf(".") > 0 ? quantity.substring(0, quantity.indexOf(".")) : quantity);
            });

            String timeStamp = Util.getUTCTimeString();
            sender.send(topic, UsageJsonHelper.generateMeteringServiceUsageJson(timeStamp, region, subAccount, cfSpaceName, measured));
            Util.debug(logger, ">>> sendODataInfoToKafka, MaaS - end!");
            return true;
        } catch (Exception ex) {
            Util.error(logger, ">>> Sending odata usage information to kafka failed, MaaS");
            throw new GTTMeteringException(">>> Sending odata usage information to kafka failed, MaaS", ex);
        }
    }
    
    @Override
    public Boolean sendCassandraInfoToKafka(String topic, String region, String subAccount, String cfSpaceName) throws GTTMeteringException {
        Util.debug(logger, ">>> sendCassandraInfoToKafka, MaaS - start! region:{} subAccount:{} cfSpaceName:{}",
                new Object[]{region, subAccount, cfSpaceName});
        try {
            String size = cassandra.getSpaceSize(subAccount);
            Map<String, String> measured = new HashMap<String, String>();
            measured.put("storage_consumption_cassandra", size);

            String timeStamp = Util.getUTCTimeString();
            sender.send(topic, UsageJsonHelper.generateMeteringServiceUsageJson(timeStamp, region, subAccount, cfSpaceName, measured));
            Util.debug(logger, ">>> sendCassandraInfoToKafka - end!");
            return true;
        } catch (Exception ex) {
            Util.error(logger, ">>> Sending cassandra usage information to kafka failed.");
            throw new GTTMeteringException(">>> Sending cassandra usage information to kafka failed.", ex);
        }
    }
    
    @Override
    public Boolean sendElasticSearchInfoToKafka(String topic, String region, String subAccount, String cfSpaceName, String xsappName) throws GTTMeteringException {
        Util.debug(logger, ">>> sendElasticSearchInfoToKafka, MaaS - start! region:{} subAccount:{} cfSpaceName:{} xsappName:{}",
                new Object[]{region, subAccount, cfSpaceName, xsappName});
        try {
            Map<String, Long> indexes = Util.convertToIndexMap(elasticSearch.getConsumedIndexes(subAccount), xsappName, subAccount);

            long total = 0L;
            total = indexes.values().stream().map((value) -> value).reduce(total, (accumulator, _item) -> accumulator + _item);
            Map<String, String> measured = new HashMap<>();
            measured.put("storage_consumption_elasticsearch", String.valueOf(total));
            String timeStamp = Util.getUTCTimeString();
            sender.send(topic, UsageJsonHelper.generateMeteringServiceUsageJson(timeStamp, region, subAccount, cfSpaceName, measured));
            Util.debug(logger, ">>> sendElasticSearchInfoToKafka - end!");
            return true;
        } catch (Exception ex) {
            Util.error(logger, ">>> Sending elasticsearch usage information to kafka failed.");
            throw new GTTMeteringException(">>> Sending elasticsearch usage information to kafka failed.", ex);
        }
    }
    
    @Override
    public List<Map<String, Object>> getAndSendToMeteringService(String topic) {
        Util.debug(logger, ">>> getAndSendToMeteringService - start! topic:{} isSending:{}", new Object[]{topic, isSendings.containsKey(topic) ? isSendings.get(topic) : false});
        List<Map<String, Object>> resultList = new ArrayList<>();
        if (!isSendings.containsKey(topic) || !isSendings.get(topic)) {
            //return when sending to abucus.
            isSendings.put(topic, Boolean.TRUE);
            try {
                List<String> messages = receiver.receive(topic, 1000);
                logger.debug(">>> getAndSendToMeteringService received messages: {}", messages);
                List<List<String>> batchMessages = Util.convertToFixedSize(messages, 10);
                for (int index = 0; index < batchMessages.size(); index++) {
                	Map<String, Object> result = sendToMeteringService(topic, index * 10,
                            UsageJsonHelper.generateBatchMeteringServiceUsageJson(batchMessages.get(index)), batchMessages.get(index).size());
                	result.put("input", batchMessages.get(index));
                	resultList.add(result);
                }
            } catch (Exception ex) {
                Util.error(logger, ">>> Failed to send to Metering Service.");
            }
            isSendings.put(topic, Boolean.FALSE);
        }
        Util.debug(logger, ">>> getAndSendToMeteringService - end! resultList: {}", resultList.toString());
        return resultList;
    }
    
    private Map<String, Object> sendToMeteringService(String topic, int index, String message, int batchSize) {
        Map<String, Object> result = usage.sendBatchToMeteringService(message);
        Util.debug(logger, ">>> sendBatchToMeteringService - message : {}", message.replace("\n", ""));
        Util.debug(logger, ">>> sendBatchToMeteringService - result : {}", result);

        if(checkStatus(String.valueOf(result.get("statusCode")))){
            for (int indexJ = 0; indexJ < batchSize; indexJ++) {
            	receiver.commit(topic, index + indexJ);
            }
        }
        return result;
    }


    private boolean checkStatus(String status) {
        HttpStatus httpStatus = Util.getHttpStatus(status);
        return httpStatus.equals(HttpStatus.OK)
                || httpStatus.equals(HttpStatus.BAD_REQUEST)
                || httpStatus.equals(HttpStatus.INTERNAL_SERVER_ERROR);
    }

    /**
     * Start the metering for specific topic
     *
     * @param topic
     * @throws GTTMeteringException
     */
    @Override
    public void start(String topic) throws GTTMeteringException {
        Util.debug(logger, ">>> start - start! topic:{}", topic);

        if (topics.contains(topic)) {
            Util.debug(logger, ">>> start - end! topics.contains(topic):{}", topics.contains(topic));
            return;
        }
        kafkaTopic.createTopic(topic);

        //sender.start();
        receiver.start(topic);
        topics.add(topic);
        Util.debug(logger, ">>> start - end!");
    }

    /**
     * Close the metering
     *
     * @param topic
     */
    @Override
    public void close(String topic) {
        Util.debug(logger, "close - start!");
        //sender.close();
        receiver.close(topic);
        if (topics.contains(topic)) {
            topics.remove(topic);
        }
        Util.debug(logger, "close - end!");
    }
}
