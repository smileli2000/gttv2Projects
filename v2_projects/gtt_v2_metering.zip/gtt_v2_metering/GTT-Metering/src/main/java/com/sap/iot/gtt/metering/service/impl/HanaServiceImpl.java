/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.iot.gtt.metering.service.impl;

import com.sap.db.jdbc.exceptions.JDBCDriverException;
import com.sap.iot.gtt.metering.MeteringConnection;
import com.sap.iot.gtt.metering.exception.GTTMeteringException;
import com.sap.iot.gtt.metering.service.HanaService;
import com.sap.iot.gtt.metering.service.util.Util;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.BadSqlGrammarException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

/**
 *
 * @author I326335
 */
@Repository
public class HanaServiceImpl implements HanaService {

    private Logger logger = LoggerFactory.getLogger(HanaServiceImpl.class);

    public final static String TABLENAMETENANTS = "TENANTS";
    public final static String TABLENAMETENANT_CONFIGS = "TENANT_CONFIGS";
    private final int HANA_ERROR_INVALID_TABLE_NAME = 259;

    private MeteringConnection meteringConnection;
    private JdbcTemplate hanaDB;

    @Autowired
    public HanaServiceImpl(JdbcTemplate hanaDB, MeteringConnection meteringConnection) {
        this.hanaDB = hanaDB;
        this.meteringConnection = meteringConnection;
    }

    /**
     * Obtain all tenants
     *
     * @return Collection<String>
     * @throws GTTMeteringException
     */
    @Override
    public Collection<String> getTenants() throws GTTMeteringException {
        Util.debug(logger, "getTenants - start!");
        final String sqlSelectTemplate = "SELECT TENANT FROM %s.%s";
        String sqlInsert = String.format(sqlSelectTemplate, this.getSchema(), TABLENAMETENANTS);

        Collection<String> tenants = null;

        try {
            List<Map<String, Object>> result = hanaDB.queryForList(sqlInsert);

            tenants = new HashSet<>(result.size());

            for (Map<String, Object> resultField : result) {
                tenants.add(resultField.get("TENANT").toString());
            }
        } catch (BadSqlGrammarException e) {
            JDBCDriverException driverException = (JDBCDriverException) e.getCause();
            if (driverException != null && driverException.getErrorCode() == HANA_ERROR_INVALID_TABLE_NAME) {
                // Table doesn't exist. That means no tenants have been
                // onboarded yet.
                tenants = new HashSet<>();
                Util.debug(logger, "getTenants - end! Table doesn't exist.");
            } else {
                Util.error(logger, "getTenants - end! Error.");
                throw e;
            }
        }
        Util.debug(logger, "getTenants - end! tenants:{}", tenants);
        return tenants;
    }
   
    private String getSchema() throws GTTMeteringException {

        String schema = meteringConnection.getHanaSchema();

        // check for invalid characters; see hana sql reference
        // (<cesu8_restricted_characters> in BNF)
        if (schema.matches(".*(?:;|\"|').*")) {
            final String invalidSchemaMsg = "Invalid hana schema %s";
            throw new GTTMeteringException(String.format(invalidSchemaMsg, schema));
        }

        return schema;
    }
}
