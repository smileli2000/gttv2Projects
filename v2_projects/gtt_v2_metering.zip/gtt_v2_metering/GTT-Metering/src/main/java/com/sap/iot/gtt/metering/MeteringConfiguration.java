/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.iot.gtt.metering;

import java.net.InetSocketAddress;
import java.util.Map;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

public interface MeteringConfiguration {

    public String getCassandraHosts();

    public String getCassandraUser();

    public String getCassandraPassword();

    public Map<String, Object> getKafkaProducerConfig();

    public Map<String, Object> getKafkaConsumerConfig();

    public String getZooKeeperConfig();

    public String getKafkaConfig();

    public InetSocketAddress getElasticSearchHost();

    public int getESPortForRest();

    public String getAwsEndPoint();

    public String getRoleArn();

    public String getAccessKeyID();

    public String getSecretAccessKey();

    public String getProxyHost();

    public int getProxyPort();

    public String getAwsSignerRegion();

    public boolean getNeedAWSSign();

    public int getKafkaNrOfReplication();

    public String getCf_api();

    public String getSpace_id();
    
    public String getSpace_name();

    public String getXSAppname();
    
    public String getClientid();
    
    public String getClientsecret();
    
    public String getMeteringServiceUrl();
    
    public String getMeteringServiceTokenUrl();
    
    public String getMeteringServiceClientId();
    
    public String getMeteringServiceClientSecret();
    
    public String getMeteringServiceRegion();
    
	public String getKafkaUsername();

	public String getKafkaPassword();

	public String getKafkaServieUrl();
    
    public String getPaasAuthUrl();

    public String getSecureTenant();
    
    public String getOpsAppUrl();

    public String getScheduleCron();

    public DriverManagerDataSource getHanaDataSource();

    public String getHanaSchema();

    Boolean isCassandraSslEnabled();

    Integer getCassandraPort();

    Map<String, String> getKafkaConnectConfig();
}
