package com.sap.iot.gtt.metering;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpMethod;
import org.springframework.security.access.AccessDecisionVoter;
import org.springframework.security.access.vote.AuthenticatedVoter;
import org.springframework.security.access.vote.UnanimousBased;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer;
import org.springframework.security.oauth2.config.annotation.web.configuration.ResourceServerConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configurers.ResourceServerSecurityConfigurer;
import org.springframework.security.oauth2.provider.expression.OAuth2WebSecurityExpressionHandler;
import org.springframework.security.web.access.expression.WebExpressionVoter;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.sap.iot.gtt.metering.service.util.Util;
import com.sap.xs2.security.commons.SAPOfflineTokenServices;
import com.sap.xs2.security.commons.SAPPropertyPlaceholderConfigurer;

@Configuration
@EnableWebSecurity
@EnableResourceServer
@Profile("cloud")
public class WebSecurityConfig extends ResourceServerConfigurerAdapter{
private static final Logger logger = LoggerFactory.getLogger(WebSecurityConfig.class);
	
	@Autowired
	private SAPPropertyPlaceholderConfigurer vcapParser;
	
	@Override
	public void configure(ResourceServerSecurityConfigurer resources) throws JsonProcessingException {
		resources.tokenServices(offlineTokenServicesBean());
	}
	
	@Override
	public void configure(HttpSecurity http) {
		String XSAPPNAME=vcapParser.readVcapServices("xs.appname");
		String scope_prefix="xs_authorization";
		try {
			http.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.NEVER).and()
					.authorizeRequests().accessDecisionManager(accessDecisionManagerBean())
					.antMatchers(HttpMethod.POST, "/usageDocument/**")
					.access("#oauth2.hasScope('" + scope_prefix + ".write') or #oauth2.hasScope('" + XSAPPNAME + ".access')")
					.antMatchers(HttpMethod.POST, "/usageTopic/**")
					.access("#oauth2.hasScope('" + scope_prefix + ".write') or #oauth2.hasScope('" + XSAPPNAME + ".access')")
					.antMatchers(HttpMethod.GET, "/health").permitAll()
					.and().headers()
					.frameOptions().disable();
		} catch (Exception e) {
			Util.error(logger, "Error initilizing security context.", e);
		}

	}
	
	@Bean(name = "offlineTokenServices")
	protected SAPOfflineTokenServices offlineTokenServicesBean() throws JsonProcessingException {
		SAPOfflineTokenServices olTokenServices = new SAPOfflineTokenServices();
		olTokenServices.setVerificationKey(vcapParser.readVcapServices("xs.uaa.verificationkey"));
		olTokenServices.setTrustedClientId(vcapParser.readVcapServices("xs.uaa.clientid"));
		olTokenServices.setTrustedIdentityZone(vcapParser.readVcapServices("xs.uaa.identityzone"));
		return olTokenServices;
	}
	
	@Bean(name = "accessDecisionManager")
	protected UnanimousBased accessDecisionManagerBean() {
		List<AccessDecisionVoter<? extends Object>> voterList = new ArrayList<>();
		WebExpressionVoter expressionVoter = new WebExpressionVoter();
		expressionVoter.setExpressionHandler(new OAuth2WebSecurityExpressionHandler());
		voterList.add(expressionVoter);
		voterList.add(new AuthenticatedVoter());
		return new UnanimousBased(voterList);
	}
}
