/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.iot.gtt.metering.service;

import com.sap.iot.gtt.metering.exception.GTTMeteringException;

/**
 *
 * @author I326335
 */
public interface KafkaSender {
    //public void start() throws GTTMeteringException;
    public void send(String topic, String json) throws GTTMeteringException;
    //public boolean isClose();
    //public void close();
}