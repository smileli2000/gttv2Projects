/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.iot.gtt.metering.service;

import com.sap.iot.gtt.metering.exception.GTTMeteringException;
import java.io.IOException;
import java.util.List;

import org.json.JSONException;
import org.json.JSONObject;

/**
 *
 * @author I326335
 */
public interface ElasticSearch {
    public List<String> getConsumedIndexes() throws GTTMeteringException, IOException;
    public List<String> getConsumedIndexes(String tenantUUID) throws GTTMeteringException, IOException, JSONException;;
    //public JSONObject getESConnectInfo(String tenantUUID) throws GTTMeteringException, JSONException;
}
