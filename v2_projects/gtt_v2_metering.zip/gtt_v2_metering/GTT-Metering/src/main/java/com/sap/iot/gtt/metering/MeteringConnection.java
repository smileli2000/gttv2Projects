/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.iot.gtt.metering;

import com.amazonaws.auth.AWSCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.internal.StaticCredentialsProvider;
import com.datastax.driver.core.Cluster;

import com.datastax.driver.core.JdkSSLOptions;
import org.I0Itec.zkclient.ZkClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

import com.sap.iot.gtt.metering.exception.GTTMeteringException;
import com.sap.iot.gtt.metering.service.util.Util;

import java.io.IOException;
import java.io.InputStream;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Map;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.ws.rs.core.MediaType;

import kafka.utils.ZKStringSerializer$;
import org.apache.cxf.jaxrs.client.WebClient;
import org.apache.http.HttpHost;
import org.apache.http.impl.nio.client.HttpAsyncClientBuilder;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestClientBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.client.RestTemplate;
import vc.inreach.aws.request.AWSSigner;
import vc.inreach.aws.request.AWSSigningRequestInterceptor;

/**
 *
 * @author I326335
 */
@Component
public class MeteringConnection {

    private static final Logger logger = LoggerFactory.getLogger(MeteringConnection.class);

    private MeteringConfiguration config;

    @Autowired
    public MeteringConnection(MeteringConfiguration config) {
        this.config = config;

    }

    public MeteringConfiguration getConfig() {
        return this.config;
    }

    /**
     * Returns a ready to use C* Cluster Object
     *
     * @return Cluster
     * @throws GTTMeteringException
     */
    public Cluster createCassandraCluster() throws GTTMeteringException {
        if (config.getCassandraHosts() == null) {
            throw new GTTMeteringException("No Cassandra present in either VCAP, or local config.");
        }
        Util.debug(logger, "createCassandraCluster - CassandraHosts:{}", config.getCassandraHosts());
        Cluster.Builder builder = Cluster.builder().addContactPoints(config.getCassandraHosts().split(","))
                .withMaxSchemaAgreementWaitSeconds(120) // To-do: make this configurable
                .withCredentials(config.getCassandraUser(), config.getCassandraPassword())
                .withPort(config.getCassandraPort());

        if (config.isCassandraSslEnabled()) {
            builder.withSSL(getSslOptions());
        }

        return builder.build();
    }

    public static JdkSSLOptions getSslOptions() {
        SSLContext sslcontext = null;

        try {
            InputStream is = new ClassPathResource("conf/client-truststore.jks").getInputStream();
            KeyStore keystore = KeyStore.getInstance("jks");
            String dummy = "truststorePass";
            char[] pwd = dummy.toCharArray();
            keystore.load(is, pwd);

            TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
            tmf.init(keystore);
            TrustManager[] tm = tmf.getTrustManagers();

            sslcontext = SSLContext.getInstance("TLS");
            sslcontext.init(null, tm, null);
        } catch (KeyStoreException kse) {
            logger.error(kse.getMessage(), kse);
        } catch (CertificateException e) {
            logger.error(e.getMessage(), e);
        } catch (NoSuchAlgorithmException e) {
            logger.error(e.getMessage(), e);
        } catch (KeyManagementException e) {
            logger.error(e.getMessage(), e);
        } catch (IOException e) {
            logger.error(e.getMessage(), e);
        }


        JdkSSLOptions sslOptions = JdkSSLOptions.builder()
                .withSSLContext(sslcontext)
                .build();

        return sslOptions;
    }
    /**
     * Returns a String, String KafkaConsumer
     *
     * @param topic
     * @return KafkaConsumer&lt;String, String&gt;
     * @throws GTTMeteringException
     */
    public KafkaConsumer<String, String> createKafkaConsumer(String topic) throws GTTMeteringException {
        if (config.getKafkaProducerConfig() == null) {
            throw new GTTMeteringException("No Kafka available.");
        }
        //System.out.println(">>>>>>> Going to create consumer with config "+config.getKafkaConsumerConfig());
        Map<String, Object> configProperties = Util.copyByTopic(config.getKafkaConsumerConfig(), topic);
        Util.debug(logger, "createKafkaConsumer - topic:{} KafkaConsumerConfig:{}", new Object[]{topic, configProperties});
        configProperties.putAll(config.getKafkaConnectConfig());
        return new KafkaConsumer<>(configProperties);
    }

    /**
     * Returns a String, String KafkaProducer
     *
     * @return KafkaProducer&lt;String, String&gt;
     * @throws GTTMeteringException
     */
    public KafkaProducer<String, String> createKafkaProducer() throws GTTMeteringException {
        if (config.getKafkaProducerConfig() == null) {
            throw new GTTMeteringException("No Kafka available.");
        }
        Map<String, Object> configProperties = config.getKafkaProducerConfig();
        Util.debug(logger, "createKafkaProducer - KafkaProducerConfig:{}", configProperties);
        configProperties.putAll(config.getKafkaConnectConfig());
        return new KafkaProducer<>(configProperties);
    }

    /**
     * Returns a ZKClient for Topic Generation <a href=
     * "http://stackoverflow.com/questions/16946778/how-can-we-create-a-topic-in-kafka-from-the-ide-using-api">stackoverflow</a>
     *
     * @return KafkaProducer&lt;String, String&gt;
     * @throws GTTMeteringException if mimimi
     */
    public ZkClient createZooKeeperClient() throws GTTMeteringException {
        if (config.getZooKeeperConfig() == null) {
            throw new GTTMeteringException("No Zookeeper configuration available.");
        }
        Util.debug(logger, "createZooKeeperClient - ZooKeeperConfig:{}", config.getZooKeeperConfig());
        return new ZkClient(config.getZooKeeperConfig(), 10000, 10000, ZKStringSerializer$.MODULE$);
    }

    public RestClient createESRestClient() throws GTTMeteringException {
        String ES_HOST = config.getAwsEndPoint().replace("https://", "");
        RestClientBuilder clientBuilder;
        clientBuilder = RestClient.builder(new HttpHost(ES_HOST, 443, "https"));

        boolean needAWSSign = config.getNeedAWSSign();
        if (needAWSSign) {
            final AWSSigningRequestInterceptor requestInterceptor = getRequestInterceptor();
            clientBuilder.setHttpClientConfigCallback(new RestClientBuilder.HttpClientConfigCallback() {
                @Override
                public HttpAsyncClientBuilder customizeHttpClient(HttpAsyncClientBuilder httpClientBuilder) {
                    RequestConfig requestConfig = RequestConfig.custom()
                            .setConnectTimeout(60000)
                            .setSocketTimeout(60000)
                            .build();
                    httpClientBuilder.setMaxConnPerRoute(30).setDefaultRequestConfig(requestConfig);

                    return httpClientBuilder.addInterceptorLast(requestInterceptor);
                }
            }).setMaxRetryTimeoutMillis(60000);
        }

        return clientBuilder.build();
    }
    
    public RestClient createESRestClient(String tenantUUID, String ES_HOST, String esClusterAccessKeyId, String esClusterSecretAccessKey) throws GTTMeteringException {
        RestClientBuilder clientBuilder;
        clientBuilder = RestClient.builder(new HttpHost(ES_HOST.replace("https://", ""), 443, "https"));

        boolean needAWSSign = config.getNeedAWSSign();
        if (needAWSSign) {
            final AWSSigningRequestInterceptor requestInterceptor = getRequestInterceptor(esClusterAccessKeyId, esClusterSecretAccessKey);
            clientBuilder.setHttpClientConfigCallback(new RestClientBuilder.HttpClientConfigCallback() {
                @Override
                public HttpAsyncClientBuilder customizeHttpClient(HttpAsyncClientBuilder httpClientBuilder) {
                    RequestConfig requestConfig = RequestConfig.custom()
                            .setConnectTimeout(60000)
                            .setSocketTimeout(60000)
                            .build();
                    httpClientBuilder.setMaxConnPerRoute(30).setDefaultRequestConfig(requestConfig);

                    return httpClientBuilder.addInterceptorLast(requestInterceptor);
                }
            }).setMaxRetryTimeoutMillis(60000);
        }

        return clientBuilder.build();
    }

    private AWSSigningRequestInterceptor getRequestInterceptor() throws GTTMeteringException {
        final String AWSSIGNER_SERVICE = "es";
        String accessKeyID = config.getAccessKeyID();
        String secretAccessKey = config.getSecretAccessKey();
        String awsSigner_region = config.getAwsSignerRegion();
        AWSCredentialsProvider aWSCredentialsProvider = new StaticCredentialsProvider(
                new BasicAWSCredentials(accessKeyID, secretAccessKey)); // dev
        final AWSSigner awsSigner = new AWSSigner(aWSCredentialsProvider, awsSigner_region, AWSSIGNER_SERVICE,
                () -> LocalDateTime.now(ZoneOffset.UTC));
        final AWSSigningRequestInterceptor requestInterceptor = new AWSSigningRequestInterceptor(awsSigner);

        return requestInterceptor;
    }
    
    private AWSSigningRequestInterceptor getRequestInterceptor(String accessKeyID, String secretAccessKey) throws GTTMeteringException {
        final String AWSSIGNER_SERVICE = "es";
        String awsSigner_region = config.getAwsSignerRegion();
        AWSCredentialsProvider aWSCredentialsProvider = new StaticCredentialsProvider(
                new BasicAWSCredentials(accessKeyID, secretAccessKey));
        final AWSSigner awsSigner = new AWSSigner(aWSCredentialsProvider, awsSigner_region, AWSSIGNER_SERVICE,
                () -> LocalDateTime.now(ZoneOffset.UTC));
        final AWSSigningRequestInterceptor requestInterceptor = new AWSSigningRequestInterceptor(awsSigner);

        return requestInterceptor;
    }

    /**
     * Returns a Spring JdbcTemplate Object with Hana Credentials
     *
     * @return JdbcTemplate
     * @throws GTTMeteringException
     */
    public JdbcTemplate createHanaJdbcTemplate() throws GTTMeteringException {
        if (config.getHanaDataSource() == null) {
            throw new GTTMeteringException("No Hana present, or no JDBC Driver available.");
        }
        return new JdbcTemplate(config.getHanaDataSource());
    }

    /**
     * Returns a String with schema information
     *
     * @return String
     * @throws GTTMeteringException
     */
    public String getHanaSchema() throws GTTMeteringException {
        if (config.getHanaSchema() == null) {
            throw new GTTMeteringException("No Hana present, or no JDBC Driver available.");
        }
        return config.getHanaSchema();
    }
    
    public WebClient createWebClient(String url) {
        return  WebClient.create(url).accept(MediaType.APPLICATION_JSON_TYPE);
    }
    
    public WebClient createWebClient(String url, String user, String password) {
        return  WebClient.create(url, user, password, null).accept(MediaType.APPLICATION_JSON_TYPE);
    }

}
