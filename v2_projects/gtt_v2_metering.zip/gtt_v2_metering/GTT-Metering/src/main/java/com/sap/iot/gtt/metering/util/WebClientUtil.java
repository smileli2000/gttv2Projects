package com.sap.iot.gtt.metering.util;

import javax.ws.rs.core.Form;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.cxf.jaxrs.client.WebClient;

public class WebClientUtil {
	
	public Response put(String url, String payload, String authHeader){
		WebClient webClient = WebClient.create(url).accept(MediaType.APPLICATION_JSON_TYPE);
		
        webClient.header("Content-Type", "application/json");
        webClient.header("Authorization", authHeader);

        return webClient.put(payload);
	}
	
	public Response postWithBasicAuth(String url, String user, String pwd){
		WebClient webClient = WebClient.create(url, user, pwd, null).accept(MediaType.APPLICATION_JSON_TYPE);
		webClient.header("Content-Type", "application/x-www-form-urlencoded");
        Form body = new Form().param("grant_type", "client_credentials");

        return webClient.post(body);
	}
	
	public Response get(String url, String bearerToken) {
    	WebClient webClient = WebClient.create(url).accept(MediaType.APPLICATION_JSON_TYPE);;
    	webClient.header("Authorization", bearerToken);
        return webClient.get();
	}
}
