/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.iot.gtt.metering.service;

import com.sap.iot.gtt.metering.exception.GTTMeteringException;
import java.util.List;

/**
 *
 * @author I326335
 */
public interface KafkaReceiver {

    public void start(String topic) throws GTTMeteringException;
    public List<String> receive(String topic, int minBatchSize) throws GTTMeteringException;
    public void commit(String topic, Integer index);
    public boolean isClose(String topic);
    public void close(String topic);
    
}
