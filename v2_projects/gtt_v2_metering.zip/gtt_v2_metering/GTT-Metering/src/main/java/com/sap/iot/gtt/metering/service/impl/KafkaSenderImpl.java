/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.iot.gtt.metering.service.impl;

import com.sap.iot.gtt.metering.MeteringConnection;
import com.sap.iot.gtt.metering.exception.GTTMeteringException;
import com.sap.iot.gtt.metering.service.KafkaSender;
import com.sap.iot.gtt.metering.service.util.Util;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 *
 * @author I326335
 */
@Component
public class KafkaSenderImpl implements KafkaSender {

    private Logger logger = LoggerFactory.getLogger(KafkaSenderImpl.class);

    private MeteringConnection connection;

    protected Producer<String, String> producer;

    @Autowired
    public KafkaSenderImpl(MeteringConnection connection) throws GTTMeteringException {
        this.connection = connection;
        start();
    }

    /**
     * Start a kafka producer
     *
     * @throws GTTMeteringException
     */
    //@Override
    private void start() throws GTTMeteringException {
        Util.debug(logger, "start - start! producer != null:{}", producer != null);
        if (!isClose()) {
            Util.debug(logger, "start - end!");
            return;
        }

        setProducer(connection.createKafkaProducer());
        Util.debug(logger, "start - end!");
    }

    /**
     * Send json string into specific kafka topic
     *
     * @param topic
     * @param json
     * @throws GTTMeteringException
     */
    @Override
    public void send(String topic, String json) throws GTTMeteringException {
        Util.debug(logger, "send - start! topic:{}", topic);
        Util.debug(logger, "send - Going to send below json to topic " + topic + " with below json: " + json.replace("\n", ""));
        try {
            producer.send(new ProducerRecord<>(topic, json));
        } catch (Exception e) {
            Util.error(logger, "send - end! Fail to send message to kafka.");
            throw new GTTMeteringException("Consumer failed to send messages.", e);
        }
        Util.debug(logger, "send - end!");
    }

    /**
     * Check if producer is close
     *
     * @return
     */
    //@Override
    private boolean isClose() {
        return producer == null;
    }

    private synchronized void setProducer(final Producer<String, String> producer) {
        this.producer = producer;
    }

}
