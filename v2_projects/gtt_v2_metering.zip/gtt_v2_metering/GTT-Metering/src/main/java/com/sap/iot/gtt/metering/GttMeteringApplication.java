package com.sap.iot.gtt.metering;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
@EnableCaching
public class GttMeteringApplication {

    public static void main(String[] args) {
        SpringApplication.run(GttMeteringApplication.class, args);
    }
    
//    @Bean
//    public PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
//        PropertySourcesPlaceholderConfigurer properties = new PropertySourcesPlaceholderConfigurer();
//
//        properties.setLocation(new ClassPathResource("application.properties"));
//        properties.setIgnoreResourceNotFound(false);
//
//        return properties;
//    }
}
