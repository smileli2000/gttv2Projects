/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.iot.gtt.metering.service;

import java.util.Map;

import com.sap.iot.gtt.metering.exception.GTTMeteringException;
import java.util.List;

/**
 *
 * @author I326335
 */
public interface Metering {

    public void start(String topic) throws GTTMeteringException;
    public void close(String topic);
    
    public Boolean sendConnectivityInfoToKafka(String topic, String region, String subAccount, String cfSpaceName, Map<String, Object> jsonMap) throws GTTMeteringException;
    public Boolean sendODataInfoToKafka(String topic, String region, String subAccount, String cfSpaceName, Map<String, Object> jsonMap) throws GTTMeteringException;
    public Boolean sendCassandraInfoToKafka(String topic, String region, String subAccount, String cfSpaceName) throws GTTMeteringException;
    public Boolean sendElasticSearchInfoToKafka(String topic, String region, String subAccount, String cfSpaceName, String xsappName) throws GTTMeteringException;
    public List<Map<String, Object>> getAndSendToMeteringService(String topic);
}
