/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.iot.gtt.metering;

/**
 *
 * @author I326335
 */
public class Environment {

    public static String getEnvironmentServices(String service) {
        return System.getenv(service);
    }
}
