/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.iot.gtt.metering;

import com.sap.iot.gtt.metering.service.util.PropertyFileUtil;
import com.sap.iot.gtt.metering.service.util.Util;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.lang.StringUtils;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Profile;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.stereotype.Component;

@Component
@Profile("dev")
public class MeteringConfigurationLocal implements MeteringConfiguration {

    private String cassandraHosts;
    private String cassandraUser;
    private String cassandraPassword;
    private String zookeeperURL;
    private String kafkaURL;
    private Map<String, Object> kafkaProducerProperties;
    private Map<String, Object> kafkaConsumerProperties;
    private Map<String, Object> kafkaTopicProperties;
    private InetSocketAddress elasticSearchHost;
    private int elasticSearchPortForRest;
    private String aws_endPoint;
    private String roleArn;
    private String accessKeyID;
    private String secretAccessKey;
    private String proxyHost;
    private int proxyPort;
    private String awsSigner_region;
    private boolean needAWSSign;

    private String cf_api = "";
    private String space_id = "";

    private String meteringClientId = "";
    private String meteringClientSecret = "";
    private String resourceId = "";
    private String collectorUrl = "";
    private String xsappname = "";
    private String clientid= "";
    private String clientsecret = "";
    private String paasAuthUrl = "";    
    private String tenant = "";
    private String email = "";
    private String organizationId = "";
    private String opsAppUrl = "";
    private String scheduleCron = "";

    private String meteringServiceUrl = "";
    private String meteringServiceTokenUrl = "";
    private String meteringServiceClientId = "";
    private String meteringServiceClientSecret = "";
    private String meteringServiceRegion = "";
    private String cfSpaceName = "";
    private String kafkaUsername = "";
    private String kafkaPassword = "";
    private String kafkaServieUrl = "";
    
    private DriverManagerDataSource hanaDatasource;
    private Boolean hana = false;
    private String hanaSchema;

    private static Logger logger;

    private Map<String, String> kafkaConnectConfig = new HashMap<>();

    @Override
    public String getCassandraHosts() {
        return cassandraHosts;
    }

    @Override
    public String getCassandraUser() {
        return cassandraUser;
    }

    @Override
    public String getCassandraPassword() {
        return cassandraPassword;
    }

    @Override
    public Map<String, Object> getKafkaProducerConfig() {
        return kafkaProducerProperties;
    }

    @Override
    public Map<String, Object> getKafkaConsumerConfig() {
        return kafkaConsumerProperties;
    }

    @Override
    public String getZooKeeperConfig() {
        return this.zookeeperURL;
    }

    @Override
    public String getKafkaConfig() {
        return this.kafkaURL;
    }
    
    @Override
    public InetSocketAddress getElasticSearchHost() {
        return this.elasticSearchHost;
    }

    @Override
    public int getESPortForRest() {
        return this.elasticSearchPortForRest;
    }

    @Override
    public String getAwsEndPoint() {
        return this.aws_endPoint;
    }

    @Override
    public String getRoleArn() {
        return this.roleArn;
    }

    @Override
    public String getAccessKeyID() {
        return this.accessKeyID;
    }

    @Override
    public String getSecretAccessKey() {
        return this.secretAccessKey;
    }

    @Override
    public String getProxyHost() {
        return this.proxyHost;
    }

    @Override
    public int getProxyPort() {
        return this.proxyPort;
    }

    @Override
    public String getAwsSignerRegion() {
        return this.awsSigner_region;
    }

    @Override
    public boolean getNeedAWSSign() {
        return this.needAWSSign;
    }

    @Override
    public int getKafkaNrOfReplication() {
        return 1;
    }

    @Override
    public String getCf_api() {
        return cf_api;
    }

    @Override
    public String getSpace_id() {
        return space_id;
    }
    
    @Override
    public String getSpace_name() {
        return cfSpaceName;
    }
    
    @Override
    public String getMeteringServiceClientId() {
        return meteringServiceClientId;
    }

    @Override
    public String getMeteringServiceClientSecret() {
        return meteringServiceClientSecret;
    }
    
    @Override
    public String getMeteringServiceRegion() {
        return meteringServiceRegion;
    }

    @Override
    public String getMeteringServiceTokenUrl() {
        return meteringServiceTokenUrl;
    }
    
    @Override
    public String getMeteringServiceUrl() {
        return meteringServiceUrl;
    }
    
    @Override
	public String getKafkaUsername() {
		return "kafkaUsername";
	}

    @Override
	public String getKafkaPassword() {
		return "kafkPassword";
	}

    @Override
	public String getKafkaServieUrl() {
		return "http://localhost:1080/v1/kafkaId-1234-56789";
	}

    @Override
    public String getXSAppname() {
        return xsappname;
    }
    
    @Override
    public String getClientid() {
		return clientid;
	}

    @Override
	public String getClientsecret() {
		return clientsecret;
	}

    @Override
	public String getPaasAuthUrl() {
		return paasAuthUrl;
	}

    @Override
    public String getSecureTenant() {
        return tenant;
    }
    
    @Override
    public String getOpsAppUrl() {
        return opsAppUrl;
    }

    @Override
    public String getScheduleCron() {
        return scheduleCron;
    }

    @Override
    public DriverManagerDataSource getHanaDataSource() {
        return hanaDatasource;
    }

    @Override
    public String getHanaSchema() {
        return hanaSchema;
    }

    @Override
    public Boolean isCassandraSslEnabled() {
        return false;
    }

    @Override
    public Integer getCassandraPort() {
        return 9042;
    }

    @Override
    public synchronized Map<String, String> getKafkaConnectConfig(){
        return kafkaConnectConfig;
    }

    public MeteringConfigurationLocal() throws IOException {
        logger = LoggerFactory.getLogger(MeteringConfigurationLocal.class);
        logger.info("Building from local config.properties file.");

        String[] hostIPs = PropertyFileUtil.getProperty("Cassandra_Hosts").split(",");

        //ArrayList<String> CassandraDBHosts = new ArrayList<>(Arrays.asList(hostIPs));

        setCassandraProperties(PropertyFileUtil.getProperty("Cassandra_Hosts"), PropertyFileUtil.getProperty("Cassandra_User"),
                PropertyFileUtil.getProperty("Cassandra_Password"));

        setKafkaProducerProperties(PropertyFileUtil.getProperty("Kafka_Broker"), PropertyFileUtil.getProperty("Kafka_Zookeeper"));
        setKafkaConsumerProperties(PropertyFileUtil.getProperty("Kafka_Broker"), PropertyFileUtil.getProperty("Kafka_Zookeeper"));
        setKafkaTopicProperties(PropertyFileUtil.getProperty("Kafka_Topic_Retention_Hours"));

        setElasticSearchProperties(PropertyFileUtil.getProperty("ElasticSearch_Host"),
                Integer.valueOf(PropertyFileUtil.getProperty("ElasticSearch_Port")));

        needAWSSign = Boolean.parseBoolean(PropertyFileUtil.getProperty("AWS_NeedAWSSign"));

        setElasticSearchPortForRest(Integer.valueOf(PropertyFileUtil.getProperty("ElasticSearch_PortForRest")));
        setAws_endPoint(PropertyFileUtil.getProperty("AWS_Endpoint"));
        setRoleArn(PropertyFileUtil.getProperty("AWS_RoleArn"));
        setAccessKeyID(PropertyFileUtil.getProperty("AWS_AccessKeyId"));
        setSecretAccessKey(PropertyFileUtil.getProperty("AWS_SecretAccessKey"));
        setProxyHost(PropertyFileUtil.getProperty("Proxy_Host"));
        setProxyPort(StringUtils.isNotEmpty(PropertyFileUtil.getProperty("Proxy_Port"))
                ? Integer.valueOf(PropertyFileUtil.getProperty("Proxy_Port")) : 0);
        setAwsSigner_region(PropertyFileUtil.getProperty("AWS_Region"));

        setXSUAAInfos(
                PropertyFileUtil.getProperty("XSUAA_Name"),
                PropertyFileUtil.getProperty("XSUAA_TenantName"),
                PropertyFileUtil.getProperty("XSUAA_Email"),
                PropertyFileUtil.getProperty("XSUAA_Organization"));
        setVCAPApplicationValues(
                PropertyFileUtil.getProperty("CF_ID"),
                PropertyFileUtil.getProperty("SPACE_ID"));

        setHanaProperties(PropertyFileUtil.getProperty("HANA_URL"), PropertyFileUtil.getProperty("HANA_USER"),
				PropertyFileUtil.getProperty("HANA_PASSWORD"), PropertyFileUtil.getProperty("HANA_SCHEMA"));
    }

    /**
     * Set the Kafka Properties directly through properties file
     *
     * @param broker
     * @param zookeeper
     */
    private void setKafkaProducerProperties(String broker, String zookeeper) {
        this.kafkaProducerProperties = new HashMap<>();
        this.kafkaURL = broker;
        this.kafkaProducerProperties.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, broker);
        this.kafkaProducerProperties.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,
                "org.apache.kafka.common.serialization.StringSerializer");
        this.kafkaProducerProperties.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,
                "org.apache.kafka.common.serialization.StringSerializer");
        this.kafkaProducerProperties.put("request.required.acks", "1");
        this.zookeeperURL = zookeeper;
    }

    /**
     * Set the Kafka Properties directly through properties file
     *
     * @param broker
     * @param zookeeper
     */
    private void setKafkaConsumerProperties(String broker, String zookeeper) {

        this.kafkaConsumerProperties = new HashMap<>();
        this.kafkaURL = broker;
        this.kafkaConsumerProperties.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, broker);

        this.kafkaConsumerProperties.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG,
                "org.apache.kafka.common.serialization.StringDeserializer");
        this.kafkaConsumerProperties.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG,
                "org.apache.kafka.common.serialization.StringDeserializer");
        //this.kafkaConsumerProperties.put(ConsumerConfig.GROUP_ID_CONFIG, "gtt_metering");
        //this.kafkaConsumerProperties.put(ConsumerConfig.CLIENT_ID_CONFIG, "gtt_metering_id1");
        this.kafkaConsumerProperties.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "false");
        this.kafkaConsumerProperties.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, 100);
        this.kafkaConsumerProperties.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "latest");
        //this.kafkaConsumerProperties.put(ConsumerConfig.CONNECTIONS_MAX_IDLE_MS_CONFIG, 1200000);
        //this.kafkaConsumerProperties.put(ConsumerConfig.AUTO_COMMIT_INTERVAL_MS_CONFIG, "1000");
        //System.out.println(">>>>>>> KafkaConsumerProperties" + this.kafkaConsumerProperties);
        this.zookeeperURL = zookeeper;
    }

    /**
     * Set the Kafka Topic Properties directly through properties file
     *
     * @param retention
     */
    private void setKafkaTopicProperties(String retention) {

        this.kafkaTopicProperties = new HashMap<>();
        this.kafkaTopicProperties.put("retention_hours", Double.valueOf(retention));
    }

    /**
     * Set the C* Properties directly through properties file
     *
     * @param cassandraHosts List of Hosts
     * @param cassandraUser
     * @param cassandraKey
     */
    private void setCassandraProperties(String cassandraHosts, String cassandraUser,
            String cassandraKey) {
        this.cassandraHosts = cassandraHosts;
        this.cassandraUser = cassandraUser;
        this.cassandraPassword = cassandraKey;
    }

    private void setElasticSearchProperties(String hostname, int port) {
        this.elasticSearchHost = new InetSocketAddress(hostname, port);
    }

    private void setElasticSearchPortForRest(int port) {
        this.elasticSearchPortForRest = port;
    }

    private void setAws_endPoint(String aws_endPoint) {
        this.aws_endPoint = aws_endPoint;
    }

    private void setRoleArn(String roleArn) {
        this.roleArn = roleArn;
    }

    private void setAccessKeyID(String accessKeyID) {
        this.accessKeyID = accessKeyID;
    }

    private void setSecretAccessKey(String secretAccessKey) {
        this.secretAccessKey = secretAccessKey;
    }

    private void setProxyHost(String proxyHost) {
        this.proxyHost = proxyHost;
    }

    private void setProxyPort(int proxyPort) {
        this.proxyPort = proxyPort;
    }

    private void setAwsSigner_region(String awsSigner_region) {
        this.awsSigner_region = awsSigner_region;
    }

    private void setXSUAAInfos(String xsappname, String tenant, String email, String organizationId) {;
        this.xsappname = xsappname;
        this.tenant = tenant;
        this.email = email;
        this.organizationId = organizationId;
    }

    private void setVCAPApplicationValues(String cf_api, String space_id) {
        this.cf_api = cf_api;
        this.space_id = space_id;
    }

    /**
     * Set the Hana Properties directly through properties file
     *
     * @param url
     * @param username
     * @param key
     */
    private void setHanaProperties(String url, String username, String key, String hanaSchema) {
        try {
            Class.forName("com.sap.db.jdbc.Driver");
        } catch (final ClassNotFoundException e) {
            Util.error(logger, "No valid jdbc class found! \n" + Arrays.toString(e.getStackTrace()));
            return;
        }

        this.hanaDatasource = new DriverManagerDataSource(url, username, key);
        this.hanaSchema = hanaSchema;
    }
}
