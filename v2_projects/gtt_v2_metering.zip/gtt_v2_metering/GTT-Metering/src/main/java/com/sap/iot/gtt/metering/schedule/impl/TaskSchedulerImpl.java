/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.iot.gtt.metering.schedule.impl;

import com.sap.iot.gtt.metering.MeteringConfiguration;
import com.sap.iot.gtt.metering.MeteringConnection;
import com.sap.iot.gtt.metering.exception.GTTMeteringException;
import com.sap.iot.gtt.metering.schedule.TaskScheduler;
import com.sap.iot.gtt.metering.service.HanaService;
import com.sap.iot.gtt.metering.service.KafkaSender;
import com.sap.iot.gtt.metering.service.Metering;
import com.sap.iot.gtt.metering.service.impl.KafkaSenderImpl;
import com.sap.iot.gtt.metering.service.util.Util;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 *
 * @author I326335
 */
@Component
public class TaskSchedulerImpl implements TaskScheduler {

    private Logger logger = LoggerFactory.getLogger(TaskSchedulerImpl.class);

    MeteringConfiguration configuration;
    MeteringConnection connection;

    @Autowired
    private Metering metering;
    @Autowired
    private Metering meteringService;
    @Autowired
    private HanaService hanaService;

    KafkaSender errorTopicSender;
    KafkaSender errorTopicSenderMaaS;
    boolean isRunning;
    boolean isSending;

    @Autowired
    public TaskSchedulerImpl(MeteringConfiguration configuration, MeteringConnection connection) throws GTTMeteringException {
        this.configuration = configuration;
        this.connection = connection;
        this.isRunning = false;
        this.isSending = false; 
        startErrorTopicSender();
    }
    
    @Override
    @Scheduled(cron = "30 2/5 * * * *")//@Scheduled(cron = "${metering.schudule.interval}")//${configuration.scheduleCron}")
    public void triggerUsagesSending() {
        Util.debug(logger, ">>> triggerUsagesSending - start! isSending:{}", isSending);
        if (isSending) {
            Util.debug(logger, ">>> triggerUsagesSending - end!");
            return;
        }
        isSending = true;

        String xsappname = configuration.getXSAppname();
        try {
            Collection<String> tenants = hanaService.getTenants();
            logger.debug(">>> tenants: {}", tenants);
            tenants.stream().forEach(tenant -> {
                try {
                    String topic = Util.generateFullTopicName(tenant, xsappname, "MaaS");
                    logger.debug(">>> topic: {}", topic);
                    meteringService.start(topic);
                    List<Map<String, Object>> resultList = meteringService.getAndSendToMeteringService(topic);
                    logger.debug(">>> going to send this resultList to errorTopic: {}", resultList);
                    String errorTopic = Util.generateFullErrorTopicName(tenant, xsappname, "MaaS");
                    logger.debug(">>> errorTopic: {}", errorTopic);
                    sendMessageToErrorTopic(errorTopicSenderMaaS, errorTopic, resultList);
                } catch (GTTMeteringException ex) {
                    Util.error(logger, ">>> Fail to obtain messages from Kafka and send to Metering Service.");
                }
            });
        } catch (Exception ex) {
            Util.error(logger, ">>> Fail to obtain messages from Kafka and send to Metering Service.");
        }
        isSending = false;
        Util.debug(logger, ">>> triggerUsagesSending - end!");
    }

    /**
     * Send abnormal result into kafka error topic
     * @param topicSender
     * @param errorTopic
     * @param resultList
     * @throws GTTMeteringException 
     */
    @Override
    public void sendMessageToErrorTopic(KafkaSender topicSender, String errorTopic, List<Map<String, Object>> resultList) throws GTTMeteringException {
        resultList.stream()
                .filter(result -> {
                    return !HttpStatus.OK.equals(Util.getHttpStatus(String.valueOf(result.get("statusCode"))))
                            && !HttpStatus.CREATED.equals(Util.getHttpStatus(String.valueOf(result.get("statusCode"))))
                            && !HttpStatus.ACCEPTED.equals(Util.getHttpStatus(String.valueOf(result.get("statusCode"))));
                })
                .forEach(result -> {
                    try {
                        topicSender.send(errorTopic, Util.getJSONObject(result).toString());
                    } catch (GTTMeteringException ex) {
                        Util.warn(logger, String.format("Fail to to Kfka error topic. result:%s", result), ex);
                    }
                });
    }

    private void startErrorTopicSender() throws GTTMeteringException {
        errorTopicSender = new KafkaSenderImpl(connection);
        errorTopicSenderMaaS = new KafkaSenderImpl(connection);
    }

}
