/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.iot.gtt.metering.service.impl;

import com.sap.iot.gtt.metering.MeteringConfiguration;
import com.sap.iot.gtt.metering.MeteringConnection;
import com.sap.iot.gtt.metering.exception.GTTMeteringException;
import com.sap.iot.gtt.metering.service.ElasticSearch;
import com.sap.iot.gtt.metering.service.util.Util;
import com.sap.iot.gtt.metering.util.OAuthToken;
import com.sap.iot.gtt.metering.util.WebClientUtil;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.elasticsearch.client.Response;
import org.elasticsearch.client.RestClient;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 *
 * @author I326335
 */
@Component
public class ElasticSearchImpl implements ElasticSearch {

    private Logger logger = LoggerFactory.getLogger(ElasticSearchImpl.class);
    private OAuthToken oauthToken = new OAuthToken();
    private WebClientUtil webClientUtil = new WebClientUtil();
    
    @Autowired
    private MeteringConnection connection;

    @Autowired
    public ElasticSearchImpl(MeteringConnection connection) {
        this.connection = connection;
    }
    
    @Autowired
    private MeteringConfiguration configuration;

    /**
     * Obtain index list
     *
     * @return
     * @throws GTTMeteringException
     */
    @Override
    public List<String> getConsumedIndexes() throws GTTMeteringException {
        Util.debug(logger, "getConsumedIndexes - start!");
        try (RestClient client = connection.createESRestClient()) {
            Response response = client.performRequest("GET", "/_cat/indices");

            Scanner s = new Scanner(response.getEntity().getContent(), StandardCharsets.UTF_8.toString());
            List<String> matrix = new ArrayList<>();
            while (s.hasNextLine()) {
                String line = s.nextLine();
                matrix.add(line);
            }
            s.close();
            Util.debug(logger, "getConsumedIndexes - matrix.size:{}", matrix.size());
            Util.debug(logger, "getConsumedIndexes - end!");
            return matrix;
        } catch (Exception e) {
            Util.error(logger, "Obtaining elasticsearch indexes failed.");
            throw new GTTMeteringException("Obtaining elasticsearch indexes failed.", e);
        }
    }
    
    @Override
    public List<String> getConsumedIndexes(String tenantUUID) throws GTTMeteringException, JSONException {
        Util.debug(logger, "getConsumedIndexes with tenantUUID - start!");
        JSONObject esConnectInfo = getESConnectInfo(tenantUUID);
        
        String esClusterUrl = esConnectInfo.getJSONObject("indexing").getJSONObject("es").getJSONObject("connect").getString("url");
        String esClusterAccessKeyId = esConnectInfo.getJSONObject("indexing").getJSONObject("es").getJSONObject("connect").getString("accessKeyId");
        String esClusterSecretAccessKey = esConnectInfo.getJSONObject("indexing").getJSONObject("es").getJSONObject("connect").getString("secretAccessKey");
        Util.debug(logger, ">>>>>>> ESClusterUrl of tenant "+ tenantUUID + " => " +esClusterUrl);
        
        try (RestClient client = connection.createESRestClient(tenantUUID, esClusterUrl, esClusterAccessKeyId, esClusterSecretAccessKey)) {
            Response response = client.performRequest("GET", "/_cat/indices");

            Scanner s = new Scanner(response.getEntity().getContent(), StandardCharsets.UTF_8.toString());
            List<String> matrix = new ArrayList<>();
            while (s.hasNextLine()) {
                String line = s.nextLine();
                matrix.add(line);
            }
            s.close();
            Util.debug(logger, "getConsumedIndexes - matrix.size:{}", matrix.size());
            Util.debug(logger, "getConsumedIndexes - end!");
            return matrix;
        } catch (Exception e) {
            Util.error(logger, "Obtaining elasticsearch indexes failed.");
            throw new GTTMeteringException("Obtaining elasticsearch indexes failed.", e);
        }
    }
    
    
    private JSONObject getESConnectInfo(String tenantUUID) throws GTTMeteringException, JSONException {
    	String clientId = configuration.getClientid();
    	String clientSecret = configuration.getClientsecret();
    	String opsAppUrl = configuration.getOpsAppUrl()+"/ops/tenantConfig/services/"+tenantUUID;
        String accessToken = oauthToken.getToken(configuration, connection, "XSUAA_ClientCredentials", clientId, clientSecret);
        
        javax.ws.rs.core.Response response = webClientUtil.get(opsAppUrl, accessToken);
        String responseString = response.readEntity(String.class);
        JSONObject esConnectInfo = new JSONObject(responseString);
    	
        return esConnectInfo;
    }

}
