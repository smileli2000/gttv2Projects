package com.sap.iot.gtt.metering.controller;

import java.text.ParseException;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.sap.iot.gtt.metering.MeteringConfiguration;
import com.sap.iot.gtt.metering.exception.GTTMeteringException;
import com.sap.iot.gtt.metering.schedule.TaskScheduler;
import com.sap.iot.gtt.metering.service.KafkaSender;
import com.sap.iot.gtt.metering.service.Metering;
import com.sap.iot.gtt.metering.service.KafkaTopic;
import com.sap.iot.gtt.metering.service.util.Util;
import com.sap.iot.gtt.metering.usage.Usage;

import java.util.HashMap;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.PathVariable;

@RestController
@RequestMapping("/")
public class GTTMeteringController {

    private Logger logger = LoggerFactory.getLogger(GTTMeteringController.class);
    
    @Autowired
    private KafkaTopic kafkaTopic;
    @Autowired
    private Metering metering;
    @Autowired
    private Metering meteringService;
    @Autowired
    private MeteringConfiguration configuration;

    @RequestMapping(method = RequestMethod.POST, path = "/usageTopic", consumes = "application/json")
    public ResponseEntity<String> createTopicAndConsumer(@RequestBody Map<String, String> payload) throws GTTMeteringException {       
        String topic = payload.get("topic_name");
        //kafkaTopic.start();
        boolean status = kafkaTopic.createTopic(topic);
        //kafkaTopic.close();
        if (status == false) {
            return new ResponseEntity<>("Topic created OK and usaeg consumer starts receiving OK.", HttpStatus.CREATED);
        } else {
            return new ResponseEntity<>("Failed creating topic.", HttpStatus.FOUND);
        }
    }

    @RequestMapping(method = RequestMethod.POST, path = "/usageDocument/{type}", consumes = "application/json")
    public ResponseEntity<String> sendUsageDocument2GTTMetering(@PathVariable String type, @RequestBody Map<String, Object> measured) throws GTTMeteringException, ParseException {
        Util.debug(logger, "sendUsageDocument2GTTMetering - tenant:{} type:{}", new Object[]{configuration.getSecureTenant(), type});
        String xsappname = configuration.getXSAppname();
        String tenantId = configuration.getSecureTenant();
        String cfSpaceName = configuration.getSpace_name();
        String region = configuration.getMeteringServiceRegion();
        String metering_service_topic = Util.generateFullTopicName(tenantId, xsappname, "MaaS");

        meteringService.start(metering_service_topic);

        boolean maas_status = false;
        switch (type) {
            case "odata":
                maas_status = meteringService.sendODataInfoToKafka(metering_service_topic, region, tenantId, cfSpaceName, measured);
                break;
            case "connectivity":
                maas_status = meteringService.sendConnectivityInfoToKafka(metering_service_topic, region, tenantId, cfSpaceName, measured);
                break;
            case "cassandra":
                maas_status = metering.sendCassandraInfoToKafka(metering_service_topic, region, tenantId, cfSpaceName);
                break;
            case "elasticsearch":
                maas_status = metering.sendElasticSearchInfoToKafka(metering_service_topic, region, tenantId, cfSpaceName, xsappname);
                break;
            default:
                maas_status = false;
        }

        if (maas_status == true) {
            return new ResponseEntity<>(">>> Usage is published to GTT-Metering-Kafka properly", HttpStatus.CREATED);
        } else {
            return new ResponseEntity<>(">>> Failed sending usage.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}
