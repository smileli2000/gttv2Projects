/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.iot.gtt.metering.schedule;

import com.sap.iot.gtt.metering.exception.GTTMeteringException;
import com.sap.iot.gtt.metering.service.KafkaSender;
import java.util.List;
import java.util.Map;

/**
 *
 * @author I326335
 */
public interface TaskScheduler {
    public void triggerUsagesSending();
    public void sendMessageToErrorTopic(KafkaSender topicSender, String errorTopic, List<Map<String, Object>> resultList) throws GTTMeteringException;
}
