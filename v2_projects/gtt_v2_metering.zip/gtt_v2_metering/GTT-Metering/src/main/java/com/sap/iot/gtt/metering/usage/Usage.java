package com.sap.iot.gtt.metering.usage;

import com.sap.iot.gtt.metering.MeteringConfiguration;
import com.sap.iot.gtt.metering.MeteringConnection;
import java.util.HashMap;
import java.util.Map;
import javax.ws.rs.core.Response;
import com.sap.iot.gtt.metering.util.OAuthToken;
import com.sap.iot.gtt.metering.util.WebClientUtil;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Usage {

    private org.slf4j.Logger logger = LoggerFactory.getLogger(Usage.class);
    
    @Autowired
    private MeteringConfiguration configuration;
    @Autowired
    private MeteringConnection connection;
    private OAuthToken oauthToken = new OAuthToken();
    private WebClientUtil webClientUtil = new WebClientUtil();
    
    public Map<String, Object> sendBatchToMeteringService(String usageJsonString) {
        logger.debug(">>> Sending usage data to Metering Service. url:{}, usageJsonString:{}", configuration.getMeteringServiceUrl(), usageJsonString);
        String meteringClientId = configuration.getMeteringServiceClientId();
        String meteringClientSecret = configuration.getMeteringServiceClientSecret();
        String authHeader = oauthToken.getToken(configuration, connection, "Metering_Service_ClientCredentials", meteringClientId, meteringClientSecret);
        
        Response response = webClientUtil.put(configuration.getMeteringServiceUrl(), usageJsonString, authHeader);
        int responseCode = response.getStatus();
        String responseMessage = response.readEntity(String.class);

        Map<String, Object> result = new HashMap<>();
        result.put("statusCode", Integer.toString(responseCode));
        result.put("message", responseMessage);

        logger.debug(">>> Send2MeteringService result: {}", result);
        return result;
    }

}
