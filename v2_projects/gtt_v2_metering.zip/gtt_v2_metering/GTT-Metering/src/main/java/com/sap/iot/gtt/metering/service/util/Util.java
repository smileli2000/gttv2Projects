/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sap.iot.gtt.metering.service.util;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;
import java.io.InputStream;
import java.io.StringReader;
import java.lang.reflect.Type;
import java.math.RoundingMode;
import java.net.UnknownHostException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.TimeZone;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;

/**
 *
 * @author I326335
 */
public class Util {

    private static Logger logger = LoggerFactory.getLogger(Util.class);
    
    /**
     * Read classpath resource as InputStream
     *
     * @param path The path in the classpath
     * @return The InputStream object
     */
    public static InputStream readClassPathResourceAsStream(String path) {
        ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
        return classLoader.getResourceAsStream(path);
    }

    /**
     * Replace pattern with properties
     *
     * @param pattern The pattern
     * @param props The properties
     * @return The replaced text
     */
    public static String replace(String pattern, Properties props) {
        String result = pattern;

        if (props != null) {
            for (String key : props.stringPropertyNames()) {
                String replaceStr = String.format("${%s}", key);
                result = result.replace(replaceStr, props.getProperty(key));
            }
        }

        return result;
    }
    
    public static String getUTCTimeString() throws ParseException {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
        String timeString = formatter.format(new Date());
        return timeString;
    }

    /**
     * Create JsonObject from json string
     *
     * @param json
     * @return
     */
    public static JsonObject getJSONObject(String json) {
        GsonBuilder gsonBuilder = new GsonBuilder();
        Gson gson = gsonBuilder.create();
        StringReader reader = new StringReader(json);
        return gson.fromJson(reader, JsonObject.class);
    }

    public static Map<String, Object> getMap(String json) {
        GsonBuilder gsonBuilder = new GsonBuilder();
        Gson gson = gsonBuilder.create();
        Type type = new TypeToken<Map<String, Object>>() {
        }.getType();
        return gson.fromJson(json, type);
    }

    public static JSONObject getJSONObject(Map<String, Object> map) {
        return new JSONObject(map);
    }
    
    public static JSONArray getJSONArray(List<String> list) {
        List<JSONObject> jsonObjects = list.stream().map(s -> createJSONObject(s)).collect(Collectors.toList());
        return new JSONArray(jsonObjects);
    }

    private static JSONObject createJSONObject(String s) {
        try {
            return new JSONObject(s);
        } catch (JSONException ex) {
            return null;
        }
    }
    
    public static JsonObject getJSONObject(JsonObject jsonObject, String key) {
        return jsonObject != null && jsonObject.has(key) ? jsonObject.get(key).getAsJsonObject() : null;
    }

    /**
     * Convert to index map
     *
     * @param indexes
     * @param xsappName
     * @param tenant
     * @return
     */
    public static Map<String, Long> convertToIndexMap(List<String> indexes, String xsappName, String tenant) {
        Map<String, Long> map = new HashMap<>();
        indexes.stream().forEach(line -> {
            //System.out.println(line);
            String[] segs = line.split(" ");
            if (line.trim().length() > 0 && segs.length > 2 && segs[segs.length - 1].length() > 0) {
                List<String> segList = Arrays.asList(segs).stream().filter(seg -> {
                    return seg.trim().length() > 0;
                }).collect(Collectors.toList());
                String index = segList.get(2).trim();
                if (index.startsWith(xsappName.replace("!", "").concat("_").concat(tenant))) {
                    map.put(segList.get(2).trim(), convertToByte(segList.get(segList.size() - 2).trim()));
                }
            }
        });
        return map;
    }

    /**
     * Convert to byte
     *
     * @param storage
     * @return
     */
    public static Long convertToByte(String storage) {
        Pattern p = Pattern.compile("([a-zA-Z]+)");
        Matcher m = p.matcher(storage);
        m.find();
        String unit = m.group().toLowerCase(Locale.ENGLISH);
        String value = storage.replace(unit, "");
        long lValue = 0L;
        switch (unit) {
            case "b":
                lValue = Long.valueOf(value);
                break;
            case "kb":
                lValue = (long) (Float.parseFloat(value) * 1024);
                break;
            case "mb":
                lValue = (long) (Float.parseFloat(value) * 1048576);
                break;
            case "gb":
                lValue = (long) (Float.parseFloat(value) * 1073741824);
                break;
            case "tb":
                lValue = (long) (Float.parseFloat(value) * 1099511627776L);
                break;
            default:
                break;
        }
        return lValue;
    }

    private static String getUnitFromByte(Long storage) {
        if (storage >= 1099511627776L) {
            return "tb";
        } else if (storage >= 1073741824) {
            return "gb";
        } else if (storage >= 1048576) {
            return "mb";
        } else if (storage >= 1024) {
            return "kb";
        } else {
            return "b";

        }
    }

    /**
     * Convert to value by unit of b/kb/mb/gb/tb
     *
     * @param storage
     * @return
     */
    public static String convertFromByte(Long storage) {
        return convertFromByte(storage, getUnitFromByte(storage));
    }

    /**
     * Convert to value by unit of b/kb/mb/gb/tb
     *
     * @param storage
     * @param unit
     * @return
     */
    public static String convertFromByte(Long storage, String unit) {
        String sValue = "";
        DecimalFormat df = new DecimalFormat("#.###");
        df.setRoundingMode(RoundingMode.CEILING);
        switch (unit) {
            case "b":
                sValue = String.valueOf(storage).concat(unit);
                break;
            case "kb":
                sValue = df.format((double) storage / 1024).concat(unit);
                break;
            case "mb":
                sValue = df.format((double) storage / 1048576).concat(unit);
                break;
            case "gb":
                sValue = df.format((double) storage / 1073741824).concat(unit);
                break;
            case "tb":
                sValue = df.format((double) storage / 1099511627776L).concat(unit);
                break;
            default:
                break;
        }
        return sValue;
    }

    /**
     * Create topic name
     *
     * @param tenant
     * @param xsappname
     * @return
     */
    public static String generateFullTopicName(String tenant, String xsappname) {
        String fullTopicName = xsappname + "_" + tenant + "_usage";
        return fullTopicName.replace("!", "_").replace("\\W", "");
    }
    
    public static String generateFullTopicName(String tenant, String xsappname, String serviceType) {
        String fullTopicName = xsappname + "_" + tenant + "_usage_"+serviceType;
        return fullTopicName.replace("!", "_").replace("\\W", "");
    }

    /**
     * Create error topic name
     *
     * @param tenant
     * @param xsappname
     * @return
     */
    public static String generateFullErrorTopicName(String tenant, String xsappname) {
        String fullTopicName = xsappname + "_" + tenant + "_usage_Error";
        return fullTopicName.replace("!", "_").replace("\\W", "");
    }
    
    public static String generateFullErrorTopicName(String tenant, String xsappname, String serviceType) {
        String fullTopicName = xsappname + "_" + tenant + "_usage_Error_"+serviceType;
        return fullTopicName.replace("!", "_").replace("\\W", "");
    }

    /**
     * Create usage info map for connectivity
     *
     * @param jsonArray
     * @return
     */
    /**
     * Create usage info map for connectivity
     *
     * @param jsonObject
     * @return
     */
    public static Map<String, String> addUsageInfoToMap(Object jsonObject) {
        GsonBuilder gsonBuilder = new GsonBuilder();
        Gson gson = gsonBuilder.create();

        List<Map<String, Object>> jsonObjectList = jsonObject instanceof List ? (List<Map<String, Object>>) jsonObject : Arrays.asList((Map<String, Object>)jsonObject);
        Map<String, String> measured = new ConcurrentHashMap<>();
        Iterator<Map<String, Object>> iterator = jsonObjectList.iterator();
        long size = 0;
        while (iterator.hasNext()) {
            Map<String, Object> element = iterator.next();
            size += addUsageInfoToMap(gson, element, "applicationObjects", "tracked_process_insert_count", measured);
            size += addUsageInfoToMap(gson, element, "eventMessages", "event_insert_count", measured);
        }
        measured.put("JSON_insert_size", String.valueOf(size));
        return measured;
    }

    private static long addUsageInfoToMap(Gson gson, Map<String, Object> jsonMap, String jsonType, String usagekey, Map<String, String> measured) {
        if (jsonMap.containsKey(jsonType)) {
            measured.put(usagekey,
                    String.valueOf(jsonMap.get(jsonType) instanceof List
                            ? ((List) jsonMap.get(jsonType)).size() : 1));
            return gson.toJson(jsonMap).length();
        }
        return 0;
    }

    public static HttpStatus getHttpStatus(String status) {
        try {
            return HttpStatus.valueOf(Integer.valueOf(status));
        } catch (NumberFormatException ex) {
            warn(logger, "Fail to convert into number.", ex);
        }
        return HttpStatus.EXPECTATION_FAILED;
    }
    
    public static Map<String, Object> copyByTopic(Map<String, Object> map, String topic) {
        Map<String, Object> newMap = new HashMap<>(map);
        newMap.put(ConsumerConfig.GROUP_ID_CONFIG, "gtt_metering_".concat(topic));
        //newMap.put(ConsumerConfig.CLIENT_ID_CONFIG, topic);
        return newMap;
    }
    
    public static List<List<String>> convertToFixedSize(final List<String> messages, final int len) {
        return IntStream.range(0, messages.size()) // Iterate over the whole thing
                        .filter(i -> i % len == 0) // Filter out every 'len' number
                        .boxed() // Create a stream (instead of IntStream)
                        .map(i -> messages.subList(i, Math.min(i + len, messages.size()))) // create sublists
                        .collect(Collectors.toList());
    }
    
    public static String getBatchCollectorUrl(String collectorUrl) {
        int position = collectorUrl.indexOf("/", 9);
        return collectorUrl.substring(0, position).concat("/batch");
    }
    
    public static String getCollectorUrlRoot(String collectorUrl) {
        int position = collectorUrl.indexOf("/", 9);
        return collectorUrl.substring(position);
    }

    /**
     * create host list of type InetAddress
     *
     * @param hostname
     * @return
     * @throws UnknownHostException
     */
    public static void error(Logger logger, String info) {
        logger.error(info);
    }

    public static void error(Logger logger, String info, Throwable thrwbl) {
        logger.error(info, thrwbl);
    }

    public static void warn(Logger logger, String info) {
        logger.warn(info);
    }

    public static void warn(Logger logger, String info, Object[] o) {
        logger.warn(info, o);
    }

    public static void warn(Logger logger, String info, Throwable thrwbl) {
        logger.warn(info, thrwbl);
    }

    public static void debug(Logger logger, String info) {
        logger.debug(info);
    }

    public static void debug(Logger logger, String info, Object o) {
        logger.debug(info, o);
    }

    public static void debug(Logger logger, String info, Object[] o) {
        logger.debug(info, o);
    }
}
