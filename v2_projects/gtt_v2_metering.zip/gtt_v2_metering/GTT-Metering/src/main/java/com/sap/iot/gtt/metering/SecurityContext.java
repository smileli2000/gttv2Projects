package com.sap.iot.gtt.metering;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import com.sap.xs2.security.commons.SAPPropertyPlaceholderConfigurer;

@Configuration
public class SecurityContext {
	@Bean
	SAPPropertyPlaceholderConfigurer properties() {
        
		SAPPropertyPlaceholderConfigurer pspc = new SAPPropertyPlaceholderConfigurer();
        return pspc;
    }
}
